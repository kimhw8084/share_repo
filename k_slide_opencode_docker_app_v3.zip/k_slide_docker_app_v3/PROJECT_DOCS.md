# K-Slide Docker App v3 Project Docs

## Architecture

```text
Company DNS / ingress
  → Docker container
  → FastAPI web app
  → DB-backed queue + run history
  → opencode run --auto --command k-slide
  → embedded K-Slide v6 workspace
  → artifact validation + report serving
```

## Highest-leverage hardening implemented

### 1. DB-backed queued/running/complete/failed state
Runs are stored in `runs`. Workers claim queued runs from the DB, so upload does not depend on in-memory queue state.

### 2. Run events
Every important transition writes to `run_events`: queued, claimed, started, opencode command, complete/failed.

### 3. Artifact validation before success
The app validates `RUN_COMPLETE.md`, `05_final_report.md`, `06_verification.md`, table reconstruction signals, cardinality, number preservation, and raw tool-call leakage before accepting success.

### 4. Table/cardinality/number validators
The validators are intentionally heuristic but conservative. They are designed to prevent false confidence, not to replace human review.

### 5. Admin prompt versioning and rollback
Admin edits are snapshot/versioned. Rollback creates another versioned edit instead of silently overwriting history.

### 6. AccessKey role mapping
Users are read from `AccessKey` by default. `KSLIDE_ADMIN_USERS`, `KSLIDE_OPERATOR_USERS`, and `KSLIDE_ALLOWED_USERS` control access.

### 7. Health endpoints
- `/health/live`: cheap liveness.
- `/health/ready`: PaaS readiness.
- `/health`: deeper diagnostic.

### 8. Non-root Docker
The image creates and runs as `appuser`.

### 9. Magic-byte image validation
Pillow verifies uploads as actual supported images.

### 10. Structured JSON logs
Logs go to stdout as JSON for PaaS/Kubernetes log collection.

### 11. Smoke tests
`internal_smoke.py` exercises fake-mode upload through report and admin surfaces.

### 12. Strict/Safe rerun
Run detail pages include one-click rerun in Strict/Safe.

### 13. Polished table rendering
Markdown tables are styled and horizontally scroll on mobile.

### 14. Prompt/config checksums
Runs record active skill/orchestrator hashes and app/OpenCode version metadata.

### 15. Troubleshooting matrix
README includes observed failure modes and next actions.

## Operational guidance

For pilot deployment:

```text
KSLIDE_FAKE_MODE=1
KSLIDE_CONCURRENCY=1
KSLIDE_DATA_DIR=/data
```

After DNS and UI pass:

```text
KSLIDE_FAKE_MODE=0
```

If using Postgres:

```text
KSLIDE_DATABASE_URL=postgresql+psycopg://...
```

## Known limits

- A hard container crash cannot write a friendly final artifact; DB events/status still preserve what happened up to the crash.
- SQLite is fine for one-container MVP, not multi-replica production.
- Real K-Slide quality depends on the corporate OpenCode/Gemma configuration available in the container.
- The app uses heuristic validators to detect likely missing tables/items/numbers; they are intentionally conservative.

## Promotion checklist

1. Publish fake mode.
2. Verify `/health`.
3. Upload one image.
4. Confirm run history and artifact download.
5. Configure admin AccessKey.
6. Test admin edit and rollback.
7. Switch to real mode.
8. Upload a non-confidential Korean slide.
9. Confirm output quality and validation score.
10. Mount `/data` for persistence.
