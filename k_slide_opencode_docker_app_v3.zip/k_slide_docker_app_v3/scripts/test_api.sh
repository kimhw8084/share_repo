#!/usr/bin/env bash
set -euo pipefail
BASE="${1:-http://localhost:8000}"
echo "Health:"
curl -fsS "$BASE/health" | python -m json.tool
printf '\nCreate fake run:\n'
curl -fsS -X POST "$BASE/api/dev/fake-run" | python -m json.tool
