#!/usr/bin/env python3
from __future__ import annotations

import io
import os
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("KSLIDE_WORKSPACE_TEMPLATE_DIR", str(ROOT / "workspace_template"))
os.environ.setdefault("KSLIDE_FAKE_MODE", "1")
os.environ.setdefault("KSLIDE_ADMIN_USERS", "test-admin")
os.environ.setdefault("KSLIDE_USER_HEADER", "AccessKey")
from PIL import Image

def make_png() -> bytes:
    b = io.BytesIO()
    Image.new("RGB", (16, 16), "white").save(b, format="PNG")
    return b.getvalue()

PNG = make_png()

with tempfile.TemporaryDirectory() as td:
    os.environ["KSLIDE_DATA_DIR"] = td
    from fastapi.testclient import TestClient
    from api.main import app

    with TestClient(app) as client:
        for endpoint in ["/health/live", "/health/ready", "/health"]:
            r = client.get(endpoint, headers={"AccessKey": "test-admin"})
            assert r.status_code == 200, (endpoint, r.text)

        r = client.get("/", headers={"AccessKey": "test-admin"})
        assert r.status_code == 200 and "Drop images" in r.text, r.text[:500]

        bad = client.post("/api/runs", files={"files": ("bad.txt", io.BytesIO(b"not image"), "text/plain")}, data={"mode": "smart"}, headers={"AccessKey": "test-admin"})
        assert bad.status_code == 400, bad.text

        r = client.post(
            "/api/runs",
            files={"files": ("slide.png", io.BytesIO(PNG), "image/png")},
            data={"mode": "smart"},
            headers={"AccessKey": "test-admin"},
        )
        assert r.status_code == 200, r.text
        run_id = r.json()["run_id"]

        status = None
        for _ in range(50):
            time.sleep(0.2)
            status = client.get(f"/api/runs/{run_id}", headers={"AccessKey": "test-admin"}).json()
            if status["status"] in {"complete", "failed", "needs_review"}:
                break
        assert status and status["status"] == "complete", status
        assert status["user_name"] == "test-admin", status
        assert status["quality_score"] is not None, status

        r = client.get(f"/runs/{run_id}", headers={"AccessKey": "test-admin"})
        assert r.status_code == 200 and "Fake Mode Report" in r.text, r.text[:500]

        r = client.get(f"/api/runs/{run_id}/download", headers={"AccessKey": "test-admin"})
        assert r.status_code == 200 and r.content[:2] == b"PK", "artifact download failed"

        r = client.post(f"/api/runs/{run_id}/rerun", data={"mode": "safe"}, headers={"AccessKey": "test-admin"})
        assert r.status_code == 200, r.text

        r = client.get("/admin", headers={"AccessKey": "test-admin"})
        assert r.status_code == 200 and "Control center" in r.text, r.text[:500]

        r = client.get("/admin", headers={"AccessKey": "not-admin"})
        assert r.status_code == 403, r.text

        r = client.get("/admin/files/skill", headers={"AccessKey": "test-admin"})
        assert r.status_code == 200 and "Save versioned change" in r.text, r.text[:500]

print("internal smoke test passed")
