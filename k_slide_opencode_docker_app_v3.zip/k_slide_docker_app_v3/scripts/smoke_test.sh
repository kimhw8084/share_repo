#!/usr/bin/env bash
set -euo pipefail
python scripts/internal_smoke.py
