#!/usr/bin/env bash
set -euo pipefail
export KSLIDE_FAKE_MODE="${KSLIDE_FAKE_MODE:-1}"
export KSLIDE_DATA_DIR="${KSLIDE_DATA_DIR:-$(pwd)/data}"
uvicorn api.main:app --host 0.0.0.0 --port "${PORT:-8000}"
