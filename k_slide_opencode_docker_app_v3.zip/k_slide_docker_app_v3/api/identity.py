from __future__ import annotations

import os
from dataclasses import dataclass
from fastapi import Request

from . import config


@dataclass(frozen=True)
class UserContext:
    username: str
    source: str
    role: str
    is_admin: bool
    is_operator: bool
    allowed: bool


def _first_header(request: Request) -> tuple[str, str] | None:
    candidates = [config.USER_HEADER, *config.USER_FALLBACK_HEADERS]
    for name in candidates:
        if not name:
            continue
        v = request.headers.get(name)
        if v:
            return v.strip(), f"header:{name}"
    return None


def _first_env() -> tuple[str, str] | None:
    for name in config.USER_ENV_FALLBACKS:
        v = os.getenv(name)
        if v:
            return v.strip(), f"env:{name}"
    return None


def get_user_context(request: Request) -> UserContext:
    found = _first_header(request) or _first_env() or ("anonymous", "fallback")
    username, source = found
    username = username or "anonymous"
    is_admin = username in config.ADMIN_USERS or (config.ALLOW_ANONYMOUS_ADMIN and username == "anonymous")
    is_operator = is_admin or username in config.OPERATOR_USERS
    role = "admin" if is_admin else ("operator" if is_operator else "user")
    allowed = True if not config.ALLOWED_USERS else username in config.ALLOWED_USERS or is_admin
    return UserContext(username=username, source=source, role=role, is_admin=is_admin, is_operator=is_operator, allowed=allowed)
