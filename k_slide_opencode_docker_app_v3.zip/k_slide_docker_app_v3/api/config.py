from __future__ import annotations

import os
from pathlib import Path

APP_VERSION = "3.0.0"


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except Exception:
        return default


def _bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return v.strip().lower() in {"1", "true", "yes", "on"}


def _list(name: str, default: str = "") -> list[str]:
    raw = os.getenv(name, default)
    return [x.strip() for x in raw.split(",") if x.strip()]


APP_NAME = os.getenv("KSLIDE_APP_NAME", "K-Slide")
APP_SUBTITLE = os.getenv("KSLIDE_APP_SUBTITLE", "Korean slide images → English-native comprehension reports")
DATA_DIR = Path(os.getenv("KSLIDE_DATA_DIR", "/data")).resolve()
WORKSPACE_DIR = Path(os.getenv("KSLIDE_WORKSPACE_DIR", str(DATA_DIR / "workspace"))).resolve()
WORKSPACE_TEMPLATE_DIR = Path(os.getenv("KSLIDE_WORKSPACE_TEMPLATE_DIR", "/app/workspace_template")).resolve()
UPLOAD_DIR = Path(os.getenv("KSLIDE_UPLOAD_DIR", str(DATA_DIR / "uploads"))).resolve()
LOG_DIR = Path(os.getenv("KSLIDE_LOG_DIR", str(DATA_DIR / "logs"))).resolve()
DB_DIR = Path(os.getenv("KSLIDE_DB_DIR", str(DATA_DIR / "db"))).resolve()
BACKUP_DIR = Path(os.getenv("KSLIDE_BACKUP_DIR", str(DATA_DIR / "admin_backups"))).resolve()
DATABASE_URL = os.getenv("KSLIDE_DATABASE_URL") or f"sqlite:///{DB_DIR / 'kslide.db'}"
MAX_SECONDS = _int("KSLIDE_MAX_SECONDS", 300)
MAX_UPLOAD_MB = _int("KSLIDE_MAX_UPLOAD_MB", 25)
RETENTION_DAYS = _int("KSLIDE_RETENTION_DAYS", 7)
CONCURRENCY = max(1, _int("KSLIDE_CONCURRENCY", 1))
FAKE_MODE = _bool("KSLIDE_FAKE_MODE", False)
SHOW_DEBUG_DEFAULT = _bool("KSLIDE_SHOW_DEBUG_DEFAULT", False)
APP_PASSWORD = os.getenv("KSLIDE_APP_PASSWORD", "")
PORT = _int("PORT", 8000)
ALLOWED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}
ALLOWED_IMAGE_FORMATS = {"PNG", "JPEG", "WEBP"}
MAX_QUEUE_SIZE = _int("KSLIDE_MAX_QUEUE_SIZE", 50)
ENABLE_REAL_MODEL_SMOKE = _bool("KSLIDE_ENABLE_REAL_MODEL_SMOKE", False)

# Corporate identity / admin controls.
USER_HEADER = os.getenv("KSLIDE_USER_HEADER", "AccessKey")
USER_FALLBACK_HEADERS = _list(
    "KSLIDE_USER_FALLBACK_HEADERS",
    "X-Forwarded-User,X-Auth-Request-User,Remote-User,X-User,X-Email,X-Forwarded-Email",
)
USER_ENV_FALLBACKS = _list("KSLIDE_USER_ENV_FALLBACKS", "AccessKey,ACCESSKEY,USER,USERNAME")
ADMIN_USERS = set(_list("KSLIDE_ADMIN_USERS", ""))
OPERATOR_USERS = set(_list("KSLIDE_OPERATOR_USERS", ""))
ALLOWED_USERS = set(_list("KSLIDE_ALLOWED_USERS", ""))
ALLOW_ANONYMOUS_ADMIN = _bool("KSLIDE_ALLOW_ANONYMOUS_ADMIN", False)
ADMIN_EDIT_ENABLED = _bool("KSLIDE_ADMIN_EDIT_ENABLED", True)

# Workspace update behavior. Preserve customizations by default.
WORKSPACE_TEMPLATE_VERSION = os.getenv("KSLIDE_TEMPLATE_VERSION", "k-slide-web-v3")
WORKSPACE_UPGRADE_MODE = os.getenv("KSLIDE_WORKSPACE_UPGRADE_MODE", "preserve")  # preserve | reset_on_start

# UI behavior.
ENABLE_CLIPBOARD_PASTE = _bool("KSLIDE_ENABLE_CLIPBOARD_PASTE", True)
