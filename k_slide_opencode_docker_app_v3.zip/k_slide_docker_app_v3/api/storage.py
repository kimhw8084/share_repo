from __future__ import annotations

import hashlib
import shutil
from datetime import datetime
from pathlib import Path

from . import config


def ensure_dirs() -> None:
    for p in [config.DATA_DIR, config.UPLOAD_DIR, config.LOG_DIR, config.DB_DIR, config.BACKUP_DIR]:
        p.mkdir(parents=True, exist_ok=True)


def _copy_template(dst: Path, src: Path, *, overwrite: bool = False) -> None:
    for item in src.iterdir():
        target = dst / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        elif overwrite or not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)


def ensure_workspace() -> Path:
    ensure_dirs()
    dst = config.WORKSPACE_DIR
    src = config.WORKSPACE_TEMPLATE_DIR
    if not src.exists():
        raise RuntimeError(f"workspace template not found: {src}")
    dst.mkdir(parents=True, exist_ok=True)

    if config.WORKSPACE_UPGRADE_MODE == "reset_on_start":
        backup_workspace(reason="reset_on_start")
        if dst.exists():
            # Keep run and input data if present; reset only opencode/project template files.
            for name in [".opencode", "AGENTS.md", "PACK_MANIFEST.md", "README.md", "opencode.json"]:
                target = dst / name
                if target.is_dir():
                    shutil.rmtree(target)
                elif target.exists():
                    target.unlink()
        _copy_template(dst, src, overwrite=True)
    else:
        # Copy missing files only; preserve admin customizations.
        _copy_template(dst, src, overwrite=False)

    (dst / ".k-slide-input").mkdir(parents=True, exist_ok=True)
    (dst / ".k-slide-runs").mkdir(parents=True, exist_ok=True)
    (dst / ".kslide_template_version").write_text(config.WORKSPACE_TEMPLATE_VERSION)
    return dst


def backup_workspace(reason: str = "manual") -> Path:
    ensure_dirs()
    ts = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    out = config.BACKUP_DIR / f"workspace-{ts}-{reason}"
    src = config.WORKSPACE_DIR
    if src.exists():
        ignore = shutil.ignore_patterns(".k-slide-runs", ".k-slide-input")
        shutil.copytree(src, out, ignore=ignore, dirs_exist_ok=False)
    else:
        out.mkdir(parents=True, exist_ok=True)
    return out


def reset_workspace_from_template() -> Path:
    backup_workspace(reason="before-reset")
    dst = config.WORKSPACE_DIR
    src = config.WORKSPACE_TEMPLATE_DIR
    for name in [".opencode", "AGENTS.md", "PACK_MANIFEST.md", "README.md", "opencode.json"]:
        target = dst / name
        if target.is_dir():
            shutil.rmtree(target)
        elif target.exists():
            target.unlink()
    _copy_template(dst, src, overwrite=True)
    (dst / ".k-slide-input").mkdir(parents=True, exist_ok=True)
    (dst / ".k-slide-runs").mkdir(parents=True, exist_ok=True)
    return dst


def safe_run_dir(run_id: str) -> Path:
    if not run_id or "/" in run_id or ".." in run_id:
        raise ValueError("invalid run_id")
    return config.WORKSPACE_DIR / ".k-slide-runs" / run_id


def list_artifact_files(run_dir: Path) -> list[Path]:
    if not run_dir.exists():
        return []
    return sorted([p for p in run_dir.rglob("*") if p.is_file()])


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()
