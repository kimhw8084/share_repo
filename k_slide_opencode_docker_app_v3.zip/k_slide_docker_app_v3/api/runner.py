from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import subprocess
import time
import uuid
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Iterable

from . import config
from .db import ArtifactRecord, RunEvent, RunRecord, add_event, new_session
from .storage import ensure_workspace, file_sha256
from .validators import index_artifacts, validate_artifacts, validate_image_bytes, TOOLCALL_RE

log = logging.getLogger("kslide.runner")
_workers: list[asyncio.Task] = []
_stop = False


def _now() -> datetime:
    return datetime.utcnow()


def _tail(s: str, n: int = 4000) -> str:
    return (s or "")[-n:]


def _json_list(items: Iterable[str]) -> str:
    return json.dumps(list(items), ensure_ascii=False)


def _hash_file(workspace: Path, rel: str) -> str | None:
    p = workspace / rel
    return file_sha256(p) if p.exists() else None


def create_api_run(files: list[tuple[str, bytes]], mode: str = "smart", user_name: str = "anonymous", user_source: str = "none", user_role: str = "user") -> str:
    if mode not in {"smart", "strict", "safe"}:
        mode = "smart"
    if not files:
        raise ValueError("no files uploaded")

    # Queue backpressure for single-worker corporate deployments.
    with new_session() as session:
        queued = session.query(RunRecord).filter(RunRecord.status.in_(["queued", "running"])).count()
    if queued >= config.MAX_QUEUE_SIZE:
        raise ValueError(f"queue is full ({queued} active jobs). Try again later.")

    api_run_id = "api-" + datetime.utcnow().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8]
    upload_dir = config.UPLOAD_DIR / api_run_id
    upload_dir.mkdir(parents=True, exist_ok=False)

    workspace = ensure_workspace()
    ws_input_dir = workspace / ".k-slide-input" / api_run_id
    ws_input_dir.mkdir(parents=True, exist_ok=False)

    saved_names: list[str] = []
    for idx, (name, data) in enumerate(files, start=1):
        _fmt, ext = validate_image_bytes(name, data)
        safe_name = f"slide-{idx:03d}{ext}"
        (upload_dir / safe_name).write_bytes(data)
        shutil.copy2(upload_dir / safe_name, ws_input_dir / safe_name)
        saved_names.append(safe_name)

    with new_session() as session:
        rec = RunRecord(
            api_run_id=api_run_id,
            status="queued",
            mode=mode,
            user_name=user_name or "anonymous",
            user_source=user_source,
            user_role=user_role or "user",
            file_count=len(saved_names),
            filenames=_json_list(saved_names),
            created_at=_now(),
            queued_at=_now(),
            upload_dir=str(upload_dir),
            workspace_input_dir=str(ws_input_dir.relative_to(workspace)),
            app_version=config.APP_VERSION,
        )
        session.add(rec)
        session.commit()
    add_event(api_run_id, "queued", f"Queued {len(saved_names)} image(s) in {mode} mode")
    log.info("run queued", extra={"run_id": api_run_id, "user": user_name, "mode": mode, "status": "queued"})
    return api_run_id


def get_status(api_run_id: str, include_events: bool = False) -> dict:
    with new_session() as session:
        rec = session.query(RunRecord).filter_by(api_run_id=api_run_id).one_or_none()
        if not rec:
            return {"found": False}
        payload = {
            "found": True,
            "api_run_id": rec.api_run_id,
            "kslide_run_id": rec.kslide_run_id,
            "status": rec.status,
            "mode": rec.mode,
            "user_name": getattr(rec, "user_name", "anonymous"),
            "user_source": getattr(rec, "user_source", None),
            "user_role": getattr(rec, "user_role", "user"),
            "file_count": rec.file_count,
            "filenames": json.loads(rec.filenames or "[]"),
            "created_at": rec.created_at.isoformat() if rec.created_at else None,
            "queued_at": rec.queued_at.isoformat() if rec.queued_at else None,
            "started_at": rec.started_at.isoformat() if rec.started_at else None,
            "finished_at": rec.finished_at.isoformat() if rec.finished_at else None,
            "duration_seconds": rec.duration_seconds,
            "error_category": rec.error_category,
            "error_message": rec.error_message,
            "artifact_dir": rec.artifact_dir,
            "report_path": rec.report_path,
            "stdout_tail": rec.stdout_tail,
            "stderr_tail": rec.stderr_tail,
            "quality_score": rec.quality_score,
            "validation_status": rec.validation_status,
            "validation": json.loads(rec.validation_json) if rec.validation_json else None,
            "prompt_hash": rec.prompt_hash,
            "orchestrator_hash": rec.orchestrator_hash,
            "skill_hash": rec.skill_hash,
            "opencode_version": rec.opencode_version,
            "app_version": rec.app_version,
        }
        if include_events:
            rows = session.query(RunEvent).filter_by(api_run_id=api_run_id).order_by(RunEvent.created_at.asc()).all()
            payload["events"] = [
                {"created_at": r.created_at.isoformat(), "event_type": r.event_type, "message": r.message, "details": json.loads(r.details_json) if r.details_json else None}
                for r in rows
            ]
        return payload


def list_runs(limit: int = 50, user_name: str | None = None, admin: bool = False) -> list[dict]:
    with new_session() as session:
        query = session.query(RunRecord).order_by(RunRecord.created_at.desc())
        if user_name and not admin:
            query = query.filter_by(user_name=user_name)
        rows = query.limit(limit).all()
        ids = [r.api_run_id for r in rows]
    return [get_status(i) for i in ids]


def list_run_events(api_run_id: str) -> list[dict]:
    return get_status(api_run_id, include_events=True).get("events", [])


def _find_new_run(before: set[str], after_root: Path, input_tag: str) -> Path | None:
    if not after_root.exists():
        return None
    candidates = [p for p in after_root.iterdir() if p.is_dir() and p.name not in before]
    if not candidates:
        candidates = [p for p in after_root.iterdir() if p.is_dir()]
    for p in sorted(candidates, key=lambda x: x.stat().st_mtime, reverse=True):
        inv = p / "00_input_inventory.json"
        if inv.exists():
            try:
                txt = inv.read_text(errors="replace")
                if input_tag in txt:
                    return p
            except Exception:
                pass
    return sorted(candidates, key=lambda x: x.stat().st_mtime, reverse=True)[0] if candidates else None


def _fake_run(api_run_id: str, rec: RunRecord) -> tuple[str, str, str, str]:
    workspace = ensure_workspace()
    run_root = workspace / ".k-slide-runs"
    kslide_id = "k-slide-fake-" + api_run_id.removeprefix("api-")
    run_dir = run_root / kslide_id
    run_dir.mkdir(parents=True, exist_ok=True)
    understanding = run_dir / "01_slide_understanding.json"
    understanding.write_text(json.dumps({
        "status": "fake",
        "item_count": 3,
        "table_detected": True,
        "visible_elements": ["Title", "Item 1", "Item 2", "Item 3"],
    }, indent=2))
    report = run_dir / "05_final_report.md"
    report.write_text(
        "# K-Slide Fake Mode Report\n\n"
        "Status: COMPLETE (fake mode)\n\n"
        "This fake report proves upload, queue, database, artifact validation, run history, and UI rendering.\n\n"
        "## English-native slide reconstruction\n\n"
        "1. First visible item\n2. Second visible item\n3. Third visible item\n\n"
        "## Reconstructed table\n\n"
        "| Category | Meaning |\n|---|---|\n| Fake row 1 | Demonstrates table rendering |\n| Fake row 2 | Demonstrates artifact validation |\n\n"
        "## Next step\n\n"
        "Set `KSLIDE_FAKE_MODE=0` and confirm the corporate OpenCode/Gemma configuration is available inside the container.\n"
    )
    (run_dir / "06_verification.md").write_text("# Verification\n\nStatus: COMPLETE (fake mode)\n")
    (run_dir / "RUN_COMPLETE.md").write_text("# COMPLETE\n\nFake mode completed successfully.\n")
    (run_dir / "RUN_STATE.json").write_text(json.dumps({"status":"complete","fake_mode":True,"run_id":kslide_id}, indent=2))
    return kslide_id, str(run_dir), str(report), "fake mode complete"


def _opencode_version() -> str | None:
    try:
        proc = subprocess.run(["opencode", "--version"], text=True, capture_output=True, timeout=10)
        return (proc.stdout or proc.stderr or "").strip()[:120] or None
    except Exception:
        return None


def _index_artifacts_to_db(api_run_id: str, run_dir: Path) -> None:
    artifacts = index_artifacts(run_dir)
    with new_session() as session:
        session.query(ArtifactRecord).filter_by(api_run_id=api_run_id).delete()
        for a in artifacts:
            session.add(ArtifactRecord(api_run_id=api_run_id, **a))
        session.commit()


def _finalize_record(api_run_id: str, *, status: str, run_dir: Path | None, report_path: Path | None, stdout: str = "", stderr: str = "", error_category: str | None = None, error_message: str | None = None, start: float) -> None:
    validation = None
    if run_dir and run_dir.exists():
        try:
            validation = validate_artifacts(run_dir)
            _index_artifacts_to_db(api_run_id, run_dir)
            if status == "complete" and validation.get("overall_status") != "complete":
                status = "needs_review" if validation.get("overall_status") == "needs_review" else "failed"
                error_category = error_category or "VALIDATION_FAILED"
                error_message = "; ".join(validation.get("issues", [])) or "Artifact validation did not pass."
        except Exception as e:
            validation = {"overall_status": "failed", "issues": [f"validator crashed: {e}"]}
            if status == "complete":
                status = "failed"
                error_category = "VALIDATOR_FAILED"
                error_message = str(e)
    with new_session() as session:
        rec = session.query(RunRecord).filter_by(api_run_id=api_run_id).one()
        rec.status = status
        rec.finished_at = _now()
        rec.duration_seconds = int(time.time() - start)
        rec.error_category = error_category
        rec.error_message = error_message
        if run_dir:
            rec.kslide_run_id = run_dir.name
            rec.artifact_dir = str(run_dir)
        if report_path:
            rec.report_path = str(report_path)
        rec.stdout_tail = _tail(stdout)
        rec.stderr_tail = _tail(stderr)
        rec.validation_json = json.dumps(validation, ensure_ascii=False) if validation else None
        rec.validation_status = validation.get("overall_status") if isinstance(validation, dict) else None
        rec.quality_score = validation.get("quality_score") if isinstance(validation, dict) else None
        rec.opencode_version = _opencode_version()
        workspace = ensure_workspace()
        rec.skill_hash = _hash_file(workspace, ".opencode/skills/korean-slide-comprehension/SKILL.md")
        rec.orchestrator_hash = _hash_file(workspace, ".opencode/agents/k-slide-orchestrator.md")
        rec.prompt_hash = rec.skill_hash
        rec.app_version = config.APP_VERSION
        session.commit()
    add_event(api_run_id, status, error_message or status)
    if run_dir:
        try:
            (run_dir / "opencode_stdout.log").write_text(stdout)
            (run_dir / "opencode_stderr.log").write_text(stderr)
        except Exception:
            pass
    log.info("run finished", extra={"run_id": api_run_id, "status": status, "duration_seconds": int(time.time() - start), "error_category": error_category})


def _run_opencode(api_run_id: str) -> None:
    workspace = ensure_workspace()
    run_root = workspace / ".k-slide-runs"
    run_root.mkdir(parents=True, exist_ok=True)
    start = time.time()
    with new_session() as session:
        rec = session.query(RunRecord).filter_by(api_run_id=api_run_id).one()
        mode = rec.mode
        input_dir = rec.workspace_input_dir or f".k-slide-input/{api_run_id}"
    add_event(api_run_id, "started", "Worker started OpenCode run")
    log.info("run started", extra={"run_id": api_run_id, "mode": mode, "status": "running"})

    try:
        if config.FAKE_MODE:
            with new_session() as session:
                rec = session.query(RunRecord).filter_by(api_run_id=api_run_id).one()
                kid, adir, report, msg = _fake_run(api_run_id, rec)
            _finalize_record(api_run_id, status="complete", run_dir=Path(adir), report_path=Path(report), stdout=msg, stderr="", start=start)
            return

        before = {p.name for p in run_root.iterdir() if p.is_dir()}
        command = "k-slide" if mode == "smart" else f"k-slide-{mode}"
        cmd = ["opencode", "run", "--auto", "--dir", str(workspace), "--command", command, input_dir]
        add_event(api_run_id, "opencode_command", "Running OpenCode", json.dumps({"cmd": cmd}, ensure_ascii=False))
        proc = subprocess.run(cmd, cwd=workspace, text=True, capture_output=True, timeout=config.MAX_SECONDS, env=os.environ.copy())
        stdout, stderr = proc.stdout or "", proc.stderr or ""
        run_dir = _find_new_run(before, run_root, api_run_id)
        report_path = run_dir / "05_final_report.md" if run_dir else None
        complete = bool(run_dir and (run_dir / "RUN_COMPLETE.md").exists() and report_path and report_path.exists())
        needs_review = bool(run_dir and (run_dir / "RUN_INCOMPLETE.md").exists())
        raw_leak = bool(TOOLCALL_RE.search(stdout + "\n" + stderr))
        if complete and not raw_leak:
            status, err_cat, err_msg = "complete", None, None
        elif needs_review:
            status, err_cat, err_msg = "needs_review", "NEEDS_REVIEW", "K-Slide stopped at a review checkpoint."
        elif raw_leak:
            status, err_cat, err_msg = "failed", "RAW_TOOLCALL_LEAK", "OpenCode emitted raw tool-call/subagent text. Try Safe Mode."
        else:
            status = "failed"
            err_cat = "OPENCODE_FAILED" if proc.returncode != 0 else "REPORT_MISSING"
            err_msg = f"opencode exited with code {proc.returncode}." if proc.returncode != 0 else "K-Slide did not produce RUN_COMPLETE.md and 05_final_report.md."
        _finalize_record(api_run_id, status=status, run_dir=run_dir, report_path=report_path if report_path and report_path.exists() else None, stdout=stdout, stderr=stderr, error_category=err_cat, error_message=err_msg, start=start)
    except subprocess.TimeoutExpired as e:
        stdout = e.stdout if isinstance(e.stdout, str) else ""
        stderr = e.stderr if isinstance(e.stderr, str) else ""
        _finalize_record(api_run_id, status="failed", run_dir=None, report_path=None, stdout=stdout, stderr=stderr, error_category="TIMEOUT", error_message=f"K-Slide exceeded {config.MAX_SECONDS} seconds. Try Safe Mode or fewer images.", start=start)
    except Exception as e:
        _finalize_record(api_run_id, status="failed", run_dir=None, report_path=None, stdout="", stderr="", error_category="UNKNOWN", error_message=str(e), start=start)


def claim_next_job(worker_id: str) -> str | None:
    with new_session() as session:
        rec = session.query(RunRecord).filter_by(status="queued").order_by(RunRecord.created_at.asc()).first()
        if not rec:
            return None
        rec.status = "running"
        rec.started_at = _now()
        session.commit()
        api_run_id = rec.api_run_id
    add_event(api_run_id, "claimed", f"Claimed by {worker_id}")
    return api_run_id


async def _worker(worker_id: int) -> None:
    ident = f"worker-{worker_id}"
    while not _stop:
        api_run_id = claim_next_job(ident)
        if not api_run_id:
            await asyncio.sleep(1.0)
            continue
        try:
            await asyncio.to_thread(_run_opencode, api_run_id)
        except Exception as e:
            add_event(api_run_id, "worker_error", str(e))
            log.exception("worker error", extra={"run_id": api_run_id, "error_category": "WORKER_ERROR"})


async def start_workers() -> None:
    global _workers
    if not _workers:
        for i in range(config.CONCURRENCY):
            _workers.append(asyncio.create_task(_worker(i)))


def create_zip_for_run(api_run_id: str) -> Path | None:
    status = get_status(api_run_id)
    adir = status.get("artifact_dir")
    if not adir:
        return None
    run_dir = Path(adir)
    if not run_dir.exists():
        return None
    out = config.LOG_DIR / f"{api_run_id}-artifacts.zip"
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in run_dir.rglob("*"):
            if p.is_file():
                z.write(p, arcname=str(p.relative_to(run_dir)))
    return out


def create_completed_fake_run(user_name: str = "anonymous", user_source: str = "none", user_role: str = "user") -> str:
    api_run_id = "api-fake-" + datetime.utcnow().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8]
    workspace = ensure_workspace()
    run_root = workspace / ".k-slide-runs"
    run_root.mkdir(parents=True, exist_ok=True)
    kslide_id = "k-slide-fake-" + api_run_id.removeprefix("api-")
    run_dir = run_root / kslide_id
    run_dir.mkdir(parents=True, exist_ok=True)
    report = run_dir / "05_final_report.md"
    (run_dir / "01_slide_understanding.json").write_text(json.dumps({"item_count": 3, "table_detected": True}, indent=2))
    report.write_text("# K-Slide Fake Mode Report\n\nStatus: COMPLETE.\n\n1. First item\n2. Second item\n3. Third item\n\n| Column | Value |\n|---|---|\n| Fake | OK |\n")
    (run_dir / "06_verification.md").write_text("# Verification\n\nStatus: COMPLETE (fake direct).\n")
    (run_dir / "RUN_COMPLETE.md").write_text("# COMPLETE\n")
    (run_dir / "RUN_STATE.json").write_text(json.dumps({"status":"complete","fake_mode":True,"run_id":kslide_id}, indent=2))
    with new_session() as session:
        rec = RunRecord(
            api_run_id=api_run_id,
            kslide_run_id=kslide_id,
            status="complete",
            mode="fake",
            user_name=user_name or "anonymous",
            user_source=user_source,
            user_role=user_role,
            file_count=0,
            filenames="[]",
            started_at=_now(),
            finished_at=_now(),
            duration_seconds=0,
            artifact_dir=str(run_dir),
            report_path=str(report),
            stdout_tail="fake direct run",
            app_version=config.APP_VERSION,
        )
        session.add(rec)
        session.commit()
    _finalize_record(api_run_id, status="complete", run_dir=run_dir, report_path=report, stdout="fake direct run", stderr="", start=time.time())
    return api_run_id
