const dz = document.getElementById('dropzone');
const input = document.getElementById('file-input');
const form = document.getElementById('upload-form');
const fileList = document.getElementById('file-list');
const button = document.getElementById('run-button');
let files = [];
function humanSize(n){return n>1024*1024?(n/1024/1024).toFixed(1)+' MB':(n/1024).toFixed(0)+' KB'}
function refreshFiles(){
  if(!fileList)return;
  if(!files.length){fileList.textContent='No files selected yet.';fileList.classList.add('empty');return;}
  fileList.classList.remove('empty');
  fileList.innerHTML = files.map((f,i)=>`<div class="file-chip"><span>${i+1}. ${escapeHtml(f.name)} (${humanSize(f.size)})</span><button type="button" data-remove="${i}" aria-label="Remove ${escapeHtml(f.name)}">×</button></div>`).join('');
  fileList.querySelectorAll('button[data-remove]').forEach(b=>b.addEventListener('click',()=>{files.splice(Number(b.dataset.remove),1);refreshFiles();}));
}
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function addFiles(list){
  const incoming = Array.from(list || []).filter(f=>f && f.type && f.type.startsWith('image/'));
  files = [...files, ...incoming];
  refreshFiles();
}
if(dz){
  dz.addEventListener('click',()=>input.click());
  dz.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();input.click();}});
  input.addEventListener('change',e=>addFiles(e.target.files));
  ['dragenter','dragover'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.add('drag')}));
  ['dragleave','drop'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.remove('drag')}));
  dz.addEventListener('drop',e=>addFiles(e.dataTransfer.files));
  window.addEventListener('paste',e=>{
    const items=e.clipboardData?.items||[]; const pasted=[];
    for(const it of items){ if(it.type.startsWith('image/')){ const f=it.getAsFile(); if(f)pasted.push(new File([f],`pasted-${Date.now()}-${pasted.length+1}.png`,{type:f.type||'image/png'})); }}
    if(pasted.length){ e.preventDefault(); addFiles(pasted); dz.classList.add('drag'); setTimeout(()=>dz.classList.remove('drag'),500); }
  });
}
function updateTimeline(status){
  const steps = Array.from(document.querySelectorAll('.step'));
  const map = {queued:0,running:1,needs_review:2,failed:2,complete:3};
  const idx = map[status] ?? 0;
  steps.forEach((s,i)=>s.classList.toggle('active', i<=idx));
}
async function poll(runId){
  const statusEl=document.getElementById('status-text'); const badge=document.getElementById('status-badge'); const bar=document.getElementById('bar'); const open=document.getElementById('open-run'); let pct=25;
  while(true){
    let s;
    try{ const r=await fetch(`/api/runs/${runId}`); s=await r.json(); }catch(e){ statusEl.textContent='Waiting for server response…'; await new Promise(res=>setTimeout(res,3000)); continue; }
    const status=s.status||'unknown';
    badge.textContent=status; badge.className='status '+status;
    updateTimeline(status);
    statusEl.textContent = status==='failed' ? `Failed — ${s.error_message||s.error_category||'open run details'}` : status==='needs_review' ? 'Needs review — open run details' : status;
    pct=Math.min(96,pct+(status==='running'?8:5)); bar.style.width=pct+'%';
    if(['complete','failed','needs_review'].includes(status)){ bar.style.width='100%'; open.href=`/runs/${runId}`; open.classList.remove('hidden'); open.textContent=status==='complete'?'Open report':'Open run details'; break; }
    await new Promise(res=>setTimeout(res,2500));
  }
}
if(form){
form.addEventListener('submit',async e=>{
  e.preventDefault(); if(!files.length){alert('Choose, drop, or paste at least one image.');return;}
  button.disabled=true; button.textContent='Uploading…';
  const fd=new FormData(); for(const f of files)fd.append('files',f); fd.append('mode',document.getElementById('mode').value);
  document.getElementById('run-status').classList.remove('hidden'); document.getElementById('status-text').textContent='Uploading files…';
  let data;
  try{
    const res=await fetch('/api/runs',{method:'POST',body:fd});
    if(!res.ok){document.getElementById('status-text').textContent='Upload failed: '+await res.text(); button.disabled=false; button.textContent='Run K-Slide'; return;}
    data=await res.json();
  }catch(err){document.getElementById('status-text').textContent='Upload failed: '+err; button.disabled=false; button.textContent='Run K-Slide'; return;}
  document.getElementById('status-text').textContent='Queued'; button.textContent='Run another'; button.disabled=false; poll(data.run_id);
});
}
