from __future__ import annotations

import difflib
import hashlib
from dataclasses import dataclass
from pathlib import Path

from fastapi import HTTPException, Request

from .db import PromptVersion, new_session, record_admin_action
from .identity import UserContext, get_user_context
from .storage import ensure_workspace, file_sha256


@dataclass(frozen=True)
class EditableFile:
    id: str
    title: str
    rel_path: str
    description: str
    language: str = "markdown"


EDITABLE_FILES: dict[str, EditableFile] = {
    "skill": EditableFile("skill", "Korean Slide Comprehension Skill", ".opencode/skills/korean-slide-comprehension/SKILL.md", "Main K-Slide behavior: table/cardinality/reconstruction laws."),
    "orchestrator": EditableFile("orchestrator", "K-Slide Orchestrator Agent", ".opencode/agents/k-slide-orchestrator.md", "Main /k-slide agent. Default must stay single-agent with task denied."),
    "command": EditableFile("command", "/k-slide Command", ".opencode/commands/k-slide.md", "Smart default slash command used by the web app."),
    "strict_command": EditableFile("strict_command", "/k-slide-strict Command", ".opencode/commands/k-slide-strict.md", "Strict mode command."),
    "safe_command": EditableFile("safe_command", "/k-slide-safe Command", ".opencode/commands/k-slide-safe.md", "Safe fallback command."),
    "glossary": EditableFile("glossary", "Seed Glossary", ".opencode/skills/korean-slide-comprehension/references/glossary.seed.json", "Default Korean business glossary.", "json"),
    "opencode_config": EditableFile("opencode_config", "OpenCode Project Config", "opencode.json", "Project-level OpenCode config. Avoid secrets here.", "json"),
}


def require_admin(request: Request) -> UserContext:
    user = get_user_context(request)
    if not user.is_admin:
        raise HTTPException(status_code=403, detail="Admin access required. Set KSLIDE_ADMIN_USERS to your AccessKey/user name.")
    return user


def require_operator(request: Request) -> UserContext:
    user = get_user_context(request)
    if not user.is_operator:
        raise HTTPException(status_code=403, detail="Operator/admin access required.")
    return user


def editable_path(file_id: str) -> tuple[EditableFile, Path]:
    if file_id not in EDITABLE_FILES:
        raise HTTPException(status_code=404, detail="editable file not found")
    item = EDITABLE_FILES[file_id]
    workspace = ensure_workspace().resolve()
    path = (workspace / item.rel_path).resolve()
    if not str(path).startswith(str(workspace)):
        raise HTTPException(status_code=400, detail="unsafe path")
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"file not found: {item.rel_path}")
    return item, path


def get_editable_files() -> list[dict]:
    out = []
    for item in EDITABLE_FILES.values():
        path = ensure_workspace() / item.rel_path
        out.append({
            "id": item.id,
            "title": item.title,
            "rel_path": item.rel_path,
            "description": item.description,
            "exists": path.exists(),
            "sha256": file_sha256(path)[:16] if path.exists() else None,
        })
    return out


def validate_file_content(file_id: str, content: str) -> list[str]:
    issues: list[str] = []
    if file_id == "skill":
        if not content.lstrip().startswith("---"):
            issues.append("SKILL.md must start with YAML frontmatter.")
        if "name: korean-slide-comprehension" not in content:
            issues.append("SKILL.md frontmatter must contain name: korean-slide-comprehension.")
        for phrase in ["Table reconstruction", "Cardinality", "visible table", "item count"]:
            if phrase.lower() not in content.lower():
                issues.append(f"Skill may be missing the {phrase} law.")
    if file_id == "orchestrator":
        low = content.lower()
        if "task:" not in low or "deny" not in low:
            issues.append("Orchestrator must keep task/subagent delegation denied for default stability.")
        if "bash:" not in low:
            issues.append("Orchestrator should allow/ask bash so setup fallback can run.")
        if "table" not in low or "cardinality" not in low:
            issues.append("Orchestrator should explicitly enforce table/cardinality laws.")
    if file_id.endswith("command") or file_id == "command":
        if "k-slide" not in content:
            issues.append("Command file should mention k-slide behavior.")
    if file_id in {"glossary", "opencode_config"}:
        import json
        try:
            json.loads(content)
        except Exception as e:
            issues.append(f"Invalid JSON: {e}")
    return issues


def content_sha256(content: str) -> str:
    return hashlib.sha256(content.encode()).hexdigest()


def create_prompt_version(user_name: str, file_id: str, content: str, status: str = "snapshot", notes: str | None = None) -> PromptVersion:
    item, _ = editable_path(file_id)
    pv = PromptVersion(user_name=user_name, file_id=file_id, rel_path=item.rel_path, title=item.title, content=content, sha256=content_sha256(content), status=status, notes=notes)
    with new_session() as session:
        session.add(pv)
        session.commit()
        session.refresh(pv)
        return pv


def save_file_versioned(user_name: str, file_id: str, content: str, notes: str | None = None) -> list[str]:
    item, path = editable_path(file_id)
    old = path.read_text(errors="replace")
    issues = validate_file_content(file_id, content)
    # Always snapshot the old content before changing.
    create_prompt_version(user_name, file_id, old, status="archived", notes="automatic backup before edit")
    path.write_text(content)
    pv = create_prompt_version(user_name, file_id, content, status="active", notes=notes or "admin edit")
    diff = "\n".join(difflib.unified_diff(old.splitlines(), content.splitlines(), fromfile="before", tofile="after", lineterm=""))
    record_admin_action(user_name, "edit_file_versioned", item.rel_path, f"version={pv.id}; issues={issues}; diff_sha={content_sha256(diff)}")
    return issues


def list_prompt_versions(file_id: str | None = None, limit: int = 100) -> list[dict]:
    with new_session() as session:
        query = session.query(PromptVersion).order_by(PromptVersion.created_at.desc())
        if file_id:
            query = query.filter_by(file_id=file_id)
        rows = query.limit(limit).all()
        return [
            {
                "id": r.id,
                "created_at": r.created_at.isoformat(),
                "activated_at": r.activated_at.isoformat() if r.activated_at else None,
                "user_name": r.user_name,
                "file_id": r.file_id,
                "rel_path": r.rel_path,
                "title": r.title,
                "sha256": r.sha256[:16],
                "status": r.status,
                "notes": r.notes,
            }
            for r in rows
        ]


def rollback_to_version(user_name: str, version_id: int) -> str:
    with new_session() as session:
        pv = session.get(PromptVersion, version_id)
        if not pv:
            raise HTTPException(status_code=404, detail="prompt version not found")
        file_id = pv.file_id
        content = pv.content
    issues = save_file_versioned(user_name, file_id, content, notes=f"rollback to version {version_id}")
    record_admin_action(user_name, "rollback_prompt_version", str(version_id), f"issues={issues}")
    return file_id
