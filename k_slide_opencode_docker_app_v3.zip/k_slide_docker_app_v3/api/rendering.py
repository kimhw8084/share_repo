from __future__ import annotations

import html
import re

try:
    import markdown as _markdown
except Exception:  # pragma: no cover - fallback helps local smoke tests
    _markdown = None

_TOOL_PATTERNS = [
    re.compile(r"<\|tool_call\|>.*?(?:<\|/tool_call\|>|$)", re.S),
    re.compile(r"<tool_calls?>.*?(?:</tool_calls?>|$)", re.S | re.I),
]


def scrub_internal_noise(text: str) -> str:
    out = text or ""
    for pat in _TOOL_PATTERNS:
        out = pat.sub("[internal tool-call output hidden]", out)
    return out


def render_markdown_safe(text: str) -> str:
    cleaned = scrub_internal_noise(text)
    escaped = html.escape(cleaned)
    if _markdown is not None:
        return _markdown.markdown(escaped, extensions=["tables", "fenced_code", "sane_lists"])
    # Small no-dependency fallback: preserve readable text.
    lines = []
    for line in escaped.splitlines():
        if line.startswith("# "):
            lines.append(f"<h1>{line[2:]}</h1>")
        elif line.startswith("## "):
            lines.append(f"<h2>{line[3:]}</h2>")
        elif line.startswith("### "):
            lines.append(f"<h3>{line[4:]}</h3>")
        elif line.strip():
            lines.append(f"<p>{line}</p>")
        else:
            lines.append("")
    return "\n".join(lines)
