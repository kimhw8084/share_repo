from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from PIL import Image, UnidentifiedImageError

from . import config
from .storage import file_sha256

TOOLCALL_RE = re.compile(r"<\|tool_call\|>|<tool_calls>|call:task|subagent", re.IGNORECASE)
MD_TABLE_RE = re.compile(r"^\s*\|.+\|\s*$", re.MULTILINE)
NUMBER_RE = re.compile(r"(?<![\w.])[-+]?\d[\d,]*(?:\.\d+)?\s*(?:%|pp|원|만원|억원|개|명|건|년|월|일|Q[1-4])?", re.IGNORECASE)


def validate_image_bytes(filename: str, data: bytes) -> tuple[str, str]:
    suffix = Path(filename or "slide.png").suffix.lower() or ".png"
    if suffix not in config.ALLOWED_EXTENSIONS:
        raise ValueError(f"unsupported file type: {suffix}; allowed: {', '.join(sorted(config.ALLOWED_EXTENSIONS))}")
    if not data:
        raise ValueError("uploaded file is empty")
    if len(data) > config.MAX_UPLOAD_MB * 1024 * 1024:
        raise ValueError(f"file exceeds {config.MAX_UPLOAD_MB} MB limit: {filename}")
    try:
        from io import BytesIO
        img = Image.open(BytesIO(data))
        img.verify()
        fmt = (img.format or "").upper()
    except (UnidentifiedImageError, OSError, ValueError) as e:
        raise ValueError(f"file is not a valid supported image: {filename}") from e
    if fmt not in config.ALLOWED_IMAGE_FORMATS:
        raise ValueError(f"image format {fmt or 'unknown'} is not supported")
    ext = ".jpg" if fmt == "JPEG" else ".webp" if fmt == "WEBP" else ".png"
    return fmt, ext


def _read_text(p: Path) -> str:
    return p.read_text(errors="replace") if p.exists() and p.is_file() else ""


def _load_json(p: Path) -> Any | None:
    if not p.exists() or not p.is_file():
        return None
    try:
        return json.loads(p.read_text(errors="replace") or "{}")
    except Exception:
        return None


def detect_table_expected(run_dir: Path) -> bool:
    candidates = [run_dir / "01_slide_understanding.json", run_dir / "02_layout_coverage.json", run_dir / "04_visual_interpretation.md"]
    for p in candidates:
        txt = _read_text(p).lower()
        if any(k in txt for k in ["table", "markdown table", "row", "column", "표", "테이블"]):
            return True
    return False


def detect_cardinality_expected(run_dir: Path) -> int | None:
    data = _load_json(run_dir / "01_slide_understanding.json")
    if isinstance(data, dict):
        for key in ["item_count", "visible_item_count", "bullet_count", "count"]:
            v = data.get(key)
            if isinstance(v, int) and v > 0:
                return v
        # best effort from common array fields
        for key in ["items", "bullets", "extracted_elements", "visible_elements"]:
            v = data.get(key)
            if isinstance(v, list) and v:
                return len(v)
    return None


def validate_artifacts(run_dir: Path) -> dict[str, Any]:
    report = run_dir / "05_final_report.md"
    verification = run_dir / "06_verification.md"
    run_complete = run_dir / "RUN_COMPLETE.md"
    run_incomplete = run_dir / "RUN_INCOMPLETE.md"
    run_failed = run_dir / "RUN_FAILED.md"
    state = _load_json(run_dir / "RUN_STATE.json") or {}
    report_text = _read_text(report)
    verification_text = _read_text(verification)
    table_expected = detect_table_expected(run_dir)
    table_reconstructed = bool(MD_TABLE_RE.search(report_text))
    item_count_expected = detect_cardinality_expected(run_dir)
    cardinality_passed = True
    if item_count_expected and item_count_expected >= 3:
        # A practical heuristic: report must explicitly show at least N numbered/bullet/table rows or explain unresolved count.
        bullets = len(re.findall(r"^\s*(?:[-*]|\d+[.)])\s+", report_text, flags=re.MULTILINE))
        table_rows = max(0, len(MD_TABLE_RE.findall(report_text)) - 1)
        cardinality_passed = (bullets + table_rows) >= min(item_count_expected, 12) or "unresolved" in report_text.lower()
    numbers_in_understanding = set(NUMBER_RE.findall(_read_text(run_dir / "01_slide_understanding.json")))
    # Ignore very noisy singletons; this is a validator signal, not a blocker for all runs.
    significant_numbers = {n.strip() for n in numbers_in_understanding if len(n.strip()) >= 2}
    missing_numbers = sorted([n for n in significant_numbers if n and n not in report_text])[:20]
    number_preservation_passed = len(missing_numbers) == 0 or len(missing_numbers) <= max(1, len(significant_numbers) // 4)
    raw_toolcall_detected = bool(TOOLCALL_RE.search(report_text + "\n" + verification_text))

    exists = {
        "report": report.exists(),
        "verification": verification.exists(),
        "run_complete": run_complete.exists(),
        "run_incomplete": run_incomplete.exists(),
        "run_failed": run_failed.exists(),
    }
    complete_sentinal = exists["run_complete"] and exists["report"] and report.stat().st_size > 30
    quality_score = 100
    issues: list[str] = []
    if table_expected and not table_reconstructed:
        quality_score -= 25
        issues.append("A table appears to be present, but the report does not contain a reconstructed Markdown table.")
    if not cardinality_passed:
        quality_score -= 20
        issues.append("The report may not preserve the expected visible item count.")
    if not number_preservation_passed:
        quality_score -= 15
        issues.append("Some numbers from the understanding artifact appear to be missing from the report.")
    if raw_toolcall_detected:
        quality_score -= 30
        issues.append("Raw tool-call/subagent text was detected in generated artifacts.")
    if not exists["verification"]:
        quality_score -= 10
        issues.append("Verification artifact is missing.")
    quality_score = max(0, quality_score)

    status = "complete" if complete_sentinal else ("needs_review" if exists["run_incomplete"] else ("failed" if exists["run_failed"] else "incomplete"))
    if status == "complete" and issues:
        status = "needs_review"
    result = {
        "overall_status": status,
        "quality_score": quality_score,
        "issues": issues,
        "exists": exists,
        "state_status": state.get("status"),
        "table_expected": table_expected,
        "table_reconstructed": table_reconstructed,
        "item_count_expected": item_count_expected,
        "cardinality_passed": cardinality_passed,
        "number_preservation_passed": number_preservation_passed,
        "missing_numbers_sample": missing_numbers,
        "raw_toolcall_detected": raw_toolcall_detected,
    }
    (run_dir / "VALIDATION_REPORT.json").write_text(json.dumps(result, indent=2, ensure_ascii=False))
    return result


def index_artifacts(run_dir: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for p in sorted(run_dir.rglob("*")):
        if p.is_file():
            out.append({
                "rel_path": str(p.relative_to(run_dir)),
                "size_bytes": p.stat().st_size,
                "sha256": file_sha256(p),
                "artifact_type": "report" if p.name == "05_final_report.md" else "log" if p.suffix == ".log" else "file",
            })
    return out
