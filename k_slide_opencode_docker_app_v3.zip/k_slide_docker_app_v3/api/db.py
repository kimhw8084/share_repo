from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, Integer, String, Text, create_engine, text
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker

from . import config


class Base(DeclarativeBase):
    pass


class RunRecord(Base):
    __tablename__ = "runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    api_run_id: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    kslide_run_id: Mapped[Optional[str]] = mapped_column(String(120), nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(40), default="queued", index=True)
    mode: Mapped[str] = mapped_column(String(20), default="smart")
    user_name: Mapped[str] = mapped_column(String(180), default="anonymous", index=True)
    user_source: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    user_role: Mapped[str] = mapped_column(String(40), default="user", index=True)
    file_count: Mapped[int] = mapped_column(Integer, default=0)
    filenames: Mapped[str] = mapped_column(Text, default="[]")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    queued_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    duration_seconds: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    error_category: Mapped[Optional[str]] = mapped_column(String(80), nullable=True, index=True)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    upload_dir: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    workspace_input_dir: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    artifact_dir: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    report_path: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    stdout_tail: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    stderr_tail: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    quality_score: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    validation_status: Mapped[Optional[str]] = mapped_column(String(40), nullable=True)
    validation_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    prompt_hash: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    orchestrator_hash: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    skill_hash: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    opencode_version: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    app_version: Mapped[str] = mapped_column(String(40), default=config.APP_VERSION)


class RunEvent(Base):
    __tablename__ = "run_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    api_run_id: Mapped[str] = mapped_column(String(80), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    event_type: Mapped[str] = mapped_column(String(80), index=True)
    message: Mapped[str] = mapped_column(Text, default="")
    details_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)


class ArtifactRecord(Base):
    __tablename__ = "artifacts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    api_run_id: Mapped[str] = mapped_column(String(80), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    rel_path: Mapped[str] = mapped_column(Text)
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    sha256: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    artifact_type: Mapped[str] = mapped_column(String(80), default="file")


class AdminAuditLog(Base):
    __tablename__ = "admin_audit_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    user_name: Mapped[str] = mapped_column(String(180), default="anonymous", index=True)
    action: Mapped[str] = mapped_column(String(80), index=True)
    target: Mapped[str] = mapped_column(Text, default="")
    details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)


class PromptVersion(Base):
    __tablename__ = "prompt_versions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    activated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    user_name: Mapped[str] = mapped_column(String(180), default="anonymous", index=True)
    file_id: Mapped[str] = mapped_column(String(80), index=True)
    rel_path: Mapped[str] = mapped_column(Text)
    title: Mapped[str] = mapped_column(Text, default="")
    content: Mapped[str] = mapped_column(Text)
    sha256: Mapped[str] = mapped_column(String(80), index=True)
    status: Mapped[str] = mapped_column(String(40), default="snapshot", index=True)  # snapshot | active | archived
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)


engine = create_engine(config.DATABASE_URL, future=True, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


def _sqlite_add_missing_columns(table: str, additions: dict[str, str]) -> None:
    if not config.DATABASE_URL.startswith("sqlite"):
        return
    with engine.begin() as conn:
        rows = conn.execute(text(f"PRAGMA table_info({table})")).fetchall()
        existing = {r[1] for r in rows}
        for name, spec in additions.items():
            if name not in existing:
                conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {name} {spec}"))


def init_db() -> None:
    config.DB_DIR.mkdir(parents=True, exist_ok=True)
    Base.metadata.create_all(engine)
    _sqlite_add_missing_columns(
        "runs",
        {
            "user_name": "VARCHAR(180) DEFAULT 'anonymous'",
            "user_source": "VARCHAR(120)",
            "user_role": "VARCHAR(40) DEFAULT 'user'",
            "queued_at": "DATETIME",
            "quality_score": "INTEGER",
            "validation_status": "VARCHAR(40)",
            "validation_json": "TEXT",
            "prompt_hash": "VARCHAR(80)",
            "orchestrator_hash": "VARCHAR(80)",
            "skill_hash": "VARCHAR(80)",
            "opencode_version": "VARCHAR(120)",
            "app_version": f"VARCHAR(40) DEFAULT '{config.APP_VERSION}'",
        },
    )


def new_session() -> Session:
    return SessionLocal()


def add_event(api_run_id: str, event_type: str, message: str = "", details_json: str | None = None) -> None:
    with new_session() as session:
        session.add(RunEvent(api_run_id=api_run_id, event_type=event_type, message=message, details_json=details_json))
        session.commit()


def record_admin_action(user_name: str, action: str, target: str = "", details: str | None = None) -> None:
    with new_session() as session:
        session.add(AdminAuditLog(user_name=user_name, action=action, target=target, details=details))
        session.commit()
