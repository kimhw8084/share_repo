from __future__ import annotations

import json
import shutil
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, PlainTextResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from . import config
from .admin import editable_path, get_editable_files, list_prompt_versions, require_admin, require_operator, rollback_to_version, save_file_versioned, validate_file_content
from .db import AdminAuditLog, RunEvent, init_db, new_session, record_admin_action
from .identity import get_user_context
from .logging_setup import configure_logging
from .rendering import render_markdown_safe, scrub_internal_noise
from .runner import create_api_run, create_completed_fake_run, create_zip_for_run, get_status, list_run_events, list_runs, start_workers
from .storage import backup_workspace, ensure_workspace, file_sha256, list_artifact_files, reset_workspace_from_template

configure_logging()
app = FastAPI(title=config.APP_NAME, version=config.APP_VERSION)
BASE_DIR = Path(__file__).resolve().parent
TEMPLATE_DIR = BASE_DIR / "templates"
templates = Jinja2Templates(directory=str(TEMPLATE_DIR))
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")


def ctx(request: Request, **extra):
    user = get_user_context(request)
    base = {
        "request": request,
        "app_name": config.APP_NAME,
        "app_subtitle": config.APP_SUBTITLE,
        "app_version": config.APP_VERSION,
        "fake_mode": config.FAKE_MODE,
        "user": user,
        "clipboard_enabled": config.ENABLE_CLIPBOARD_PASTE,
        "show_debug_default": config.SHOW_DEBUG_DEFAULT,
    }
    base.update(extra)
    return base


@app.on_event("startup")
async def startup() -> None:
    ensure_workspace()
    init_db()
    await start_workers()


def _health(deep: bool = False) -> dict:
    workspace = ensure_workspace()
    opencode_path = shutil.which("opencode")
    skill = workspace / ".opencode/skills/korean-slide-comprehension/SKILL.md"
    orch = workspace / ".opencode/agents/k-slide-orchestrator.md"
    skill_text = skill.read_text(errors="replace") if skill.exists() else ""
    orch_text = orch.read_text(errors="replace") if orch.exists() else ""
    checks = {
        "opencode_found": bool(opencode_path),
        "workspace_exists": workspace.exists(),
        "k_slide_command_exists": (workspace / ".opencode/commands/k-slide.md").exists(),
        "skill_exists": skill.exists(),
        "skill_frontmatter_valid": skill_text.lstrip().startswith("---") and "name: korean-slide-comprehension" in skill_text,
        "task_denied": "task:" in orch_text and "deny" in orch_text,
        "input_dir_writable": (workspace / ".k-slide-input").exists(),
        "runs_dir_writable": (workspace / ".k-slide-runs").exists(),
        "data_dir_writable": config.DATA_DIR.exists(),
        "fake_mode": config.FAKE_MODE,
        "database_url_kind": "postgres" if config.DATABASE_URL.startswith("postgres") else "sqlite",
        "admin_edit_enabled": config.ADMIN_EDIT_ENABLED,
        "template_version": config.WORKSPACE_TEMPLATE_VERSION,
        "app_version": config.APP_VERSION,
    }
    status = "ok" if all(v for k, v in checks.items() if k not in {"fake_mode", "admin_edit_enabled", "database_url_kind", "template_version", "app_version"}) else "degraded"
    if deep:
        checks["opencode_version"] = None
        if opencode_path:
            import subprocess
            try:
                p = subprocess.run(["opencode", "--version"], capture_output=True, text=True, timeout=8)
                checks["opencode_version"] = (p.stdout or p.stderr or "").strip()[:120]
            except Exception as e:
                checks["opencode_version_error"] = str(e)
                status = "degraded"
    return {"status": status, "checks": checks, "data_dir": str(config.DATA_DIR), "workspace_dir": str(workspace)}


@app.get("/health")
async def health() -> dict:
    return _health(deep=True)


@app.get("/health/live")
async def health_live() -> dict:
    return {"status": "ok", "app_version": config.APP_VERSION}


@app.get("/health/ready")
async def health_ready() -> dict:
    h = _health(deep=False)
    if h["status"] not in {"ok", "degraded"}:
        raise HTTPException(status_code=503, detail=h)
    return h


@app.get("/", response_class=HTMLResponse)
async def index(request: Request) -> HTMLResponse:
    return templates.TemplateResponse("index.html", ctx(request))


@app.get("/runs", response_class=HTMLResponse)
async def runs_page(request: Request) -> HTMLResponse:
    user = get_user_context(request)
    return templates.TemplateResponse("runs.html", ctx(request, runs=list_runs(200, user_name=user.username, admin=user.is_admin)))


@app.get("/runs/{api_run_id}", response_class=HTMLResponse)
async def run_page(request: Request, api_run_id: str) -> HTMLResponse:
    status = get_status(api_run_id, include_events=True)
    if not status.get("found"):
        raise HTTPException(status_code=404, detail="run not found")
    user = get_user_context(request)
    if not user.is_admin and status.get("user_name") != user.username:
        raise HTTPException(status_code=403, detail="You can only view your own runs.")
    report_html = ""
    if status.get("report_path") and Path(status["report_path"]).exists():
        report_html = render_markdown_safe(scrub_internal_noise(Path(status["report_path"]).read_text(errors="replace")))
    files = []
    if status.get("artifact_dir") and Path(status["artifact_dir"]).exists():
        run_dir = Path(status["artifact_dir"])
        files = [{"name": str(p.relative_to(run_dir)), "size": p.stat().st_size} for p in list_artifact_files(run_dir)]
    return templates.TemplateResponse("run_detail.html", ctx(request, run=status, report_html=report_html, files=files))


@app.post("/api/runs")
async def api_create_run(request: Request, files: list[UploadFile] = File(...), mode: str = Form("smart")) -> dict:
    user = get_user_context(request)
    if not user.allowed:
        raise HTTPException(status_code=403, detail="This user is not allowed to use K-Slide.")
    payload: list[tuple[str, bytes]] = []
    for f in files:
        data = await f.read()
        payload.append((f.filename or "slide.png", data))
    try:
        api_run_id = create_api_run(payload, mode=mode, user_name=user.username, user_source=user.source, user_role=user.role)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"run_id": api_run_id, "status": "queued", "status_url": f"/api/runs/{api_run_id}", "page_url": f"/runs/{api_run_id}"}


@app.get("/api/runs")
async def api_list_runs(request: Request, limit: int = 50) -> list[dict]:
    user = get_user_context(request)
    return list_runs(limit, user_name=user.username, admin=user.is_admin)


@app.get("/api/runs/{api_run_id}")
async def api_run_status(request: Request, api_run_id: str) -> dict:
    status = get_status(api_run_id)
    if not status.get("found"):
        raise HTTPException(status_code=404, detail="run not found")
    user = get_user_context(request)
    if not user.is_admin and status.get("user_name") != user.username:
        raise HTTPException(status_code=403, detail="You can only view your own runs.")
    status.pop("stdout_tail", None)
    status.pop("stderr_tail", None)
    return status


@app.get("/api/runs/{api_run_id}/report")
async def api_report(request: Request, api_run_id: str, html: bool = False):
    status = get_status(api_run_id)
    if not status.get("found"):
        raise HTTPException(status_code=404, detail="run not found")
    user = get_user_context(request)
    if not user.is_admin and status.get("user_name") != user.username:
        raise HTTPException(status_code=403, detail="You can only view your own runs.")
    p = Path(status.get("report_path") or "")
    if not p.exists():
        raise HTTPException(status_code=404, detail="report not available yet")
    text = scrub_internal_noise(p.read_text(errors="replace"))
    if html:
        return HTMLResponse(render_markdown_safe(text))
    return PlainTextResponse(text)


@app.get("/api/runs/{api_run_id}/files")
async def api_files(request: Request, api_run_id: str) -> list[dict]:
    status = get_status(api_run_id)
    if not status.get("found"):
        raise HTTPException(status_code=404, detail="run not found")
    user = get_user_context(request)
    if not user.is_admin and status.get("user_name") != user.username:
        raise HTTPException(status_code=403, detail="You can only view your own runs.")
    adir = status.get("artifact_dir")
    if not adir:
        return []
    run_dir = Path(adir)
    return [{"name": str(p.relative_to(run_dir)), "size": p.stat().st_size} for p in list_artifact_files(run_dir)]


@app.get("/api/runs/{api_run_id}/files/{file_path:path}")
async def api_file(request: Request, api_run_id: str, file_path: str):
    status = get_status(api_run_id)
    if not status.get("found"):
        raise HTTPException(status_code=404, detail="run not found")
    user = get_user_context(request)
    if not user.is_admin and status.get("user_name") != user.username:
        raise HTTPException(status_code=403, detail="You can only view your own runs.")
    adir = status.get("artifact_dir")
    if not adir:
        raise HTTPException(status_code=404, detail="artifact dir not available")
    base = Path(adir).resolve()
    p = (base / file_path).resolve()
    try:
        p.relative_to(base)
    except ValueError:
        raise HTTPException(status_code=404, detail="file not found")
    if not p.exists() or not p.is_file():
        raise HTTPException(status_code=404, detail="file not found")
    return FileResponse(p)


@app.get("/api/runs/{api_run_id}/download")
async def api_download(request: Request, api_run_id: str):
    status = get_status(api_run_id)
    if not status.get("found"):
        raise HTTPException(status_code=404, detail="run not found")
    user = get_user_context(request)
    if not user.is_admin and status.get("user_name") != user.username:
        raise HTTPException(status_code=403, detail="You can only download your own runs.")
    z = create_zip_for_run(api_run_id)
    if not z or not z.exists():
        raise HTTPException(status_code=404, detail="artifacts not available")
    return FileResponse(z, filename=z.name, media_type="application/zip")



@app.post("/runs/{api_run_id}/rerun")
async def rerun_page(request: Request, api_run_id: str, mode: str = Form("strict")):
    status = get_status(api_run_id)
    if not status.get("found"):
        raise HTTPException(status_code=404, detail="run not found")
    user = get_user_context(request)
    if not user.is_admin and status.get("user_name") != user.username:
        raise HTTPException(status_code=403, detail="You can only rerun your own runs.")
    with new_session() as session:
        from .db import RunRecord
        rec = session.query(RunRecord).filter_by(api_run_id=api_run_id).one()
        upload_dir = Path(rec.upload_dir or "")
    if not upload_dir or not upload_dir.exists():
        raise HTTPException(status_code=404, detail="original uploaded files are no longer available")
    payload = [(p.name, p.read_bytes()) for p in sorted(upload_dir.iterdir()) if p.is_file()]
    new_id = create_api_run(payload, mode=mode, user_name=user.username, user_source=user.source, user_role=user.role)
    return RedirectResponse(f"/runs/{new_id}", status_code=303)

@app.post("/api/runs/{api_run_id}/rerun")
async def api_rerun(request: Request, api_run_id: str, mode: str = Form("strict")) -> dict:
    status = get_status(api_run_id)
    if not status.get("found"):
        raise HTTPException(status_code=404, detail="run not found")
    user = get_user_context(request)
    if not user.is_admin and status.get("user_name") != user.username:
        raise HTTPException(status_code=403, detail="You can only rerun your own runs.")
    # Reuse original uploads if they still exist.
    upload_dir = None
    with new_session() as session:
        from .db import RunRecord
        rec = session.query(RunRecord).filter_by(api_run_id=api_run_id).one()
        upload_dir = Path(rec.upload_dir or "")
    if not upload_dir or not upload_dir.exists():
        raise HTTPException(status_code=404, detail="original uploaded files are no longer available")
    payload = [(p.name, p.read_bytes()) for p in sorted(upload_dir.iterdir()) if p.is_file()]
    new_id = create_api_run(payload, mode=mode, user_name=user.username, user_source=user.source, user_role=user.role)
    return {"run_id": new_id, "status": "queued", "page_url": f"/runs/{new_id}"}


@app.post("/api/dev/fake-run")
async def api_fake_run(request: Request) -> dict:
    user = get_user_context(request)
    api_run_id = create_completed_fake_run(user_name=user.username, user_source=user.source, user_role=user.role)
    return {"run_id": api_run_id, "status": "complete", "status_url": f"/api/runs/{api_run_id}", "page_url": f"/runs/{api_run_id}"}


@app.get("/admin", response_class=HTMLResponse)
async def admin_home(request: Request) -> HTMLResponse:
    require_admin(request)
    return templates.TemplateResponse("admin.html", ctx(request, files=get_editable_files(), health=_health(deep=True), versions=list_prompt_versions(limit=20)))


@app.get("/admin/files/{file_id}", response_class=HTMLResponse)
async def admin_file_page(request: Request, file_id: str) -> HTMLResponse:
    require_admin(request)
    item, path = editable_path(file_id)
    content = path.read_text(errors="replace")
    issues = validate_file_content(file_id, content)
    versions = list_prompt_versions(file_id=file_id, limit=20)
    return templates.TemplateResponse("admin_file.html", ctx(request, item=item, content=content, sha256=file_sha256(path), issues=issues, versions=versions))


@app.post("/admin/files/{file_id}")
async def admin_save_file(request: Request, file_id: str, content: str = Form(...), notes: str = Form("")):
    if not config.ADMIN_EDIT_ENABLED:
        raise HTTPException(status_code=403, detail="Admin editing is disabled by KSLIDE_ADMIN_EDIT_ENABLED=0")
    user = require_admin(request)
    issues = save_file_versioned(user.username, file_id, content, notes=notes or None)
    return RedirectResponse(f"/admin/files/{file_id}?saved=1&issues={len(issues)}", status_code=303)


@app.post("/admin/versions/{version_id}/rollback")
async def admin_rollback_version(request: Request, version_id: int):
    user = require_admin(request)
    file_id = rollback_to_version(user.username, version_id)
    return RedirectResponse(f"/admin/files/{file_id}?rollback=1", status_code=303)


@app.post("/admin/workspace/reset")
async def admin_reset_workspace(request: Request):
    user = require_admin(request)
    reset_workspace_from_template()
    record_admin_action(user.username, "reset_workspace", "workspace", "Reset runtime workspace from bundled template")
    return RedirectResponse("/admin?reset=1", status_code=303)


@app.post("/admin/workspace/backup")
async def admin_backup_workspace(request: Request):
    user = require_admin(request)
    out = backup_workspace(reason="manual-admin")
    record_admin_action(user.username, "backup_workspace", "workspace", str(out))
    return RedirectResponse("/admin?backup=1", status_code=303)


@app.get("/admin/audit", response_class=HTMLResponse)
async def admin_audit(request: Request) -> HTMLResponse:
    require_admin(request)
    with new_session() as session:
        rows = session.query(AdminAuditLog).order_by(AdminAuditLog.created_at.desc()).limit(300).all()
        logs = [{"created_at": r.created_at.isoformat(), "user_name": r.user_name, "action": r.action, "target": r.target, "details": r.details} for r in rows]
    return templates.TemplateResponse("admin_audit.html", ctx(request, logs=logs))
