# K-Slide Docker/FastAPI App v3

A deployable `docker_image` web app for Korean/Korean+English slide-image comprehension using OpenCode + the embedded K-Slide v6 workspace.

Users do **not** need terminal access. They open the company DNS, paste/drop/upload slide images, and receive an English-native report with artifacts.

## What v3 adds

v3 implements the highest-leverage hardening set:

1. DB-backed queued/running/complete/failed run state.
2. Run event timeline for every job.
3. Artifact validation before a run is treated as successful.
4. Table/cardinality/number validators for K-Slide report quality.
5. Versioned admin prompt/config editing with rollback.
6. AccessKey/user role mapping and admin controls.
7. `/health/live`, `/health/ready`, and deep `/health` diagnostics.
8. Non-root Docker container.
9. Server-side magic-byte image validation via Pillow.
10. Structured JSON logs to stdout.
11. Fake-mode and real-mode smoke-test scripts.
12. One-click rerun in Strict/Safe from run detail.
13. Polished table rendering and clean Apple-like UI.
14. Prompt/config checksums recorded per run.
15. Troubleshooting matrix for observed failure modes.

## Quick start: local fake mode

Fake mode validates the Docker/PaaS/UI/DB flow without calling Gemma/OpenCode.

```bash
docker build -t k-slide-web .
docker run --rm -p 8000:8000 \
  -e KSLIDE_FAKE_MODE=1 \
  -e KSLIDE_ADMIN_USERS=admin \
  -e KSLIDE_USER_HEADER=AccessKey \
  -v "$(pwd)/data:/data" \
  k-slide-web
```

Open:

```text
http://localhost:8000
```

Upload or paste a PNG/JPG/WebP image. A fake report should complete quickly.

## Corporate PaaS deployment

Publish this repository as:

```text
docker_image
```

The container listens on:

```bash
${PORT:-8000}
```

The app is expected to be accessed through your company DNS/ingress. No separate frontend service is required.

## Real mode

After fake mode works through the company DNS, switch:

```text
KSLIDE_FAKE_MODE=0
```

The app runs:

```bash
opencode run --auto --dir <workspace> --command k-slide <uploaded-input-folder>
```

The package does **not** bake any model secrets. It expects your corporate OpenCode/Gemma configuration to be available in the environment/container exactly as your platform provides it.

## Important environment variables

| Variable | Default | Purpose |
|---|---:|---|
| `KSLIDE_FAKE_MODE` | `0` | Use `1` to test deployment without model calls. |
| `KSLIDE_DATA_DIR` | `/data` | Persistent data root. Mount this if you want history/artifacts to survive restarts. |
| `KSLIDE_DATABASE_URL` | SQLite in `/data/db` | Set to Postgres URL for shared/persistent DB logging. |
| `KSLIDE_MAX_SECONDS` | `300` | Max OpenCode run time per job. |
| `KSLIDE_MAX_UPLOAD_MB` | `25` | Per-file upload limit. |
| `KSLIDE_CONCURRENCY` | `1` | Number of worker jobs. Keep `1` unless the environment is strong. |
| `KSLIDE_MAX_QUEUE_SIZE` | `50` | Max queued/running jobs before rejecting new uploads. |
| `KSLIDE_USER_HEADER` | `AccessKey` | Main user identity header. |
| `KSLIDE_ADMIN_USERS` | empty | Comma-separated AccessKey/user names that can edit admin config. |
| `KSLIDE_OPERATOR_USERS` | empty | Comma-separated operator users. |
| `KSLIDE_ALLOWED_USERS` | empty | Optional allowlist. Empty means all authenticated/perimeter users are allowed. |
| `KSLIDE_WORKSPACE_UPGRADE_MODE` | `preserve` | Preserve runtime admin edits by default. |

## User flow

1. Open the company DNS.
2. Paste, drag, or upload one or more slide images.
3. Choose mode:
   - Smart: default.
   - Strict: slower, deeper audit.
   - Safe: fallback if a previous run failed.
4. Click **Run K-Slide**.
5. Open the report when complete.
6. Download artifacts if needed.

## Admin customization

Admins are configured with:

```text
KSLIDE_ADMIN_USERS=<AccessKey1>,<AccessKey2>
```

Admin page:

```text
/admin
```

Admins can edit:

- K-Slide skill file.
- K-Slide orchestrator agent.
- `/k-slide` command.
- Strict/Safe commands.
- Glossary.
- `opencode.json`.

Every edit is versioned. Rollback is available from the admin file page.

Runtime workspace is stored under:

```text
${KSLIDE_DATA_DIR}/workspace
```

The shipped template is under:

```text
/app/workspace_template
```

By default, the app copies missing template files but preserves admin customizations. Use admin reset only when you intentionally want to restore the bundled template.

## Health endpoints

| Endpoint | Purpose |
|---|---|
| `/health/live` | Cheap liveness check. |
| `/health/ready` | Readiness check for app, DB, workspace basics. |
| `/health` | Deep diagnostic details: OpenCode, skill, task-deny invariant, DB type, workspace. |

## API endpoints

| Endpoint | Method | Purpose |
|---|---|---|
| `/` | GET | Web UI. |
| `/runs` | GET | Run history. |
| `/api/runs` | POST | Upload images and create run. |
| `/api/runs` | GET | List runs. |
| `/api/runs/{id}` | GET | Run status. |
| `/api/runs/{id}/report` | GET | Final report as Markdown or HTML. |
| `/api/runs/{id}/download` | GET | Artifact ZIP. |
| `/api/runs/{id}/rerun` | POST | Rerun same images in Strict/Safe. |
| `/admin` | GET | Admin control center. |

Example upload:

```bash
curl -F "files=@slide.png" -F "mode=smart" http://localhost:8000/api/runs
```

## Run states

| State | Meaning |
|---|---|
| `queued` | Waiting for worker. |
| `running` | OpenCode/K-Slide is executing. |
| `complete` | `RUN_COMPLETE.md` and report exist and artifact validation passed. |
| `needs_review` | K-Slide produced review checkpoint or validation concerns. |
| `failed` | OpenCode/runtime/tooling failed or report/artifacts are missing. |

## Troubleshooting matrix

| Symptom | Likely cause | What to do |
|---|---|---|
| Upload rejects a file | Not a real PNG/JPG/WebP or too large | Re-export screenshot as PNG/JPG; check `KSLIDE_MAX_UPLOAD_MB`. |
| Health says degraded | OpenCode, skill, command, or workspace check failed | Open `/health`; verify container env and workspace. |
| Fake mode works, real mode fails | Corporate OpenCode/Gemma config unavailable in container | Confirm the PaaS exposes the same config/env inside Docker. |
| Run fails with raw tool-call text | OpenCode/model tool bridge emitted raw tool calls | Click “Run again in Safe”; download artifacts for debug. |
| Report missing tables | K-Slide output failed quality validators | Run again in Strict; inspect `VALIDATION_REPORT.json`. |
| Admin changes did not take effect | Runtime workspace differs from template or stale process | Save versioned change, then run a new job. Existing jobs are not modified. |
| History disappears after restart | `/data` was not mounted | Mount persistent storage to `KSLIDE_DATA_DIR=/data`. |
| Queue grows | Concurrency is 1 and jobs are slow | Keep queue for stability or increase `KSLIDE_CONCURRENCY` after testing. |

## Security notes

- The app trusts your company ingress/LDAP/AccessKey perimeter for identity.
- App-level arbitrary OpenCode prompts are not exposed.
- Uploaded filenames are replaced with server-side names.
- File content is validated as a real image, not by extension only.
- Normal users see only their own runs; admins see all runs.
- Container runs as non-root.
- No model secrets are baked into the image.

## Local test scripts

```bash
python scripts/internal_smoke.py
./scripts/smoke_test.sh
./scripts/test_api.sh http://localhost:8000
```

`internal_smoke.py` uses fake mode and validates upload, queue, report, artifact download, rerun, admin access, and admin file page.
