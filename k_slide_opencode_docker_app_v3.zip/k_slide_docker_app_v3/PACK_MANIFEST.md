# K-Slide Docker/FastAPI App v3 Manifest

Version: 3.0.0

## Major included improvements

- DB-backed run state and worker queue.
- Run event timeline.
- Artifact validation before success.
- Table/cardinality/number validators.
- Versioned admin prompt/config editing and rollback.
- AccessKey role mapping.
- Health/live, health/ready, and deep health endpoints.
- Non-root Docker container.
- Server-side image magic-byte validation.
- Structured JSON logs.
- Fake-mode and real-mode smoke-test scripts.
- Strict/Safe rerun actions.
- Polished table rendering.
- Prompt/config hash metadata per run.
- Troubleshooting matrix.

## Core paths

- `api/`: FastAPI web/API app.
- `workspace_template/`: bundled K-Slide v6 OpenCode workspace.
- `scripts/`: local and internal smoke scripts.
- `Dockerfile`: production image definition.
- `README.md`: deployment and user/admin guide.
- `PROJECT_DOCS.md`: engineering design notes.
