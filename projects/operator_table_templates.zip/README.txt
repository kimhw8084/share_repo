Operator Table Templates
========================

Files
-----
01_exception_first.html
02_priority_column.html
03_dense_data_grid.html
04_action_first.html
05_status_matrix.html

Design rules
------------
- Transparent page and table background.
- Plain columnar HTML tables.
- Black/gray visual structure.
- Status colors are reserved for abnormality/severity.
- Each HTML file is standalone and contains its own CSS.
- Replace the sample rows/columns with API-generated content as needed.

The templates intentionally avoid external fonts, JavaScript, frameworks, and dependencies.
