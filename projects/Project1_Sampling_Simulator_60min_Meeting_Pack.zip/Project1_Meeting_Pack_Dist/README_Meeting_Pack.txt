Project 1 - Sampling Policy Replay & ROI Simulator: 60-Minute Meeting Pack

Recommended use:
1. Send Project1_One_Page_Cheat_Sheet.pdf and Project1_Participant_Worksheet.pdf before the meeting.
2. Present Project1_One_Hour_Meeting_Deck.pptx during the meeting.
3. Use Project1_Facilitator_Guide.pdf as the moderator script.
4. Use Project1_Meeting_Capture_Workbook.xlsx for live capture of pain points, data readiness, guardrails, pilot charter, and actions.
5. Print or display Project1_Whiteboard_Canvases.pdf if using a room whiteboard.

Important wording:
- Treat all ROI and data assumptions as hypotheses to validate locally.
- Present the first release as historical replay and decision support, not production automation.
- Keep mandatory sampling rules and guardrails as hard constraints.
