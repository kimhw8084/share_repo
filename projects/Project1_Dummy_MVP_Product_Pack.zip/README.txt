PROJECT 1 DUMMY MVP — METROLOGY SAMPLING DIGITAL TWIN

PURPOSE
This is a clickable mock end product for use during the sampling-team discovery meeting.
It is not a requirements document and does not represent validated fab behavior.

HOW TO USE IN THE MEETING
1. Open the HTML file in Chrome or Edge.
2. Click "Guided tour."
3. Walk through the pages and tabs.
4. On every screen ask:
   - Would you use this?
   - What is wrong?
   - What is missing?
   - What decision would this help?
   - What would make this unsafe or untrustworthy?
5. Capture responses in the floating "Meeting feedback" panel.
6. Export feedback as JSON at the end.

FEATURE AREAS INCLUDED
- Executive dashboard
- Live operations view
- What-if scenario simulator
- Sampling policy builder
- Historical event replay
- Scenario comparison
- Risk-based sampling priority concept
- Sampling coverage and risk debt
- Queue and capacity forecast
- Recommendations and explainability
- Data quality and replay readiness
- Assumption and audit trail
- Administration and KPI ownership

IMPORTANT
All values are synthetic. The purpose is to stimulate reaction and gather requirements.
