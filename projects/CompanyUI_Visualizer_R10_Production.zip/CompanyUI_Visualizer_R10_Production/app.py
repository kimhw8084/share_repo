#!/usr/bin/env python3
"""Canonical NiceGUI PaaS entrypoint for Company UI + Visualizer 97.1.

Company deployment contract:
    python app.py

The PaaS installs the package-root requirements.txt and executes this file from
the project checkout. The complete audited application remains under source/.
This launcher resolves source/ relative to its own file, so it does not depend on
the process working directory or on an installed Company UI wheel.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
PACKAGE = SOURCE / 'company_ui' / '__init__.py'

if not PACKAGE.is_file():
    raise SystemExit(f"Bundled Company UI source is missing: {PACKAGE}")

# Bundled audited source is authoritative for the deployed application.
sys.path.insert(0, str(SOURCE))

from company_ui.products.visualizer.cli import main


if __name__ == "__main__":
    main()
