# R10 retained-editor mount and geometry certification

R10 supersedes R1-R9 for deployment. It closes the work-PC failure where the Company UI shell rendered but the Visualizer editor area appeared empty.

## Root cause

The retained editor was present in the DOM and its 248-element registry initialized, but the Visualizer root computed to approximately **2 px high** and the canvas viewport to **0 px**. A scoped `:scope { height: 100% }` declaration won the CSS cascade over the intended editor-height rule while the NiceGUI parent had automatic height. The retained editor therefore collapsed even though its JavaScript had initialized.

The integration also treated `ui.html(fragment)` as the retained editor projection boundary. R10 removes that lifecycle ambiguity: NiceGUI owns an empty mount node; a page-local bootstrap injects the trusted static retained fragment directly into that mount and restores it after host replacement.

## R10 changes

- NiceGUI owns only the mount container; the retained fragment is no longer passed through `ui.html(fragment)`.
- The mount exposes `pending`, `mounted`, and fail-visible states; a blank editor cannot fail silently.
- The mount installer detects child removal and replacement of the NiceGUI/Vue host and rehydrates the retained root.
- The editor height/min-height are explicit scoped variables rather than `height:100%` against an auto-height parent.
- The retained editor publishes `data-editor-geometry=pass|fail` using actual root/viewport/toolbar dimensions.
- Headless startup fails when the editor is collapsed even if the 248 registry initialized.
- The Import / PowerPoint disclosure is below the editor so the primary editor immediately follows report controls.

## Browser evidence

The delayed-mount browser gate creates no editor DOM initially, inserts a NiceGUI-style mount later, loads the real integrated editor modules, then replaces the mount node to simulate framework reconciliation.

Initial mount:
- root: **1440 x 844 px**
- canvas viewport: **718 px high**
- toolbar: **54 px high**
- library: **248 of 248 elements**
- mount state: **mounted**

After mount replacement / rehydration:
- root: **1440 x 844 px**
- canvas viewport: **718 px high**
- editor instance increments to 2
- library remains **248 of 248 elements**
- zero console errors
- zero page errors

The full Chromium behavior matrix also passes quick-add, undo/redo, modes, grouping/locking/layering, auto-layout, command palette, preflight, preview enter/exit, inspector close/reopen/reflow, balanced margins, zoom/fit/minimap, library search/17-engine filtering, semantic Save/PPT, pointer-local traffic, rehydration, tablet containment and phone containment with zero console/page errors.
