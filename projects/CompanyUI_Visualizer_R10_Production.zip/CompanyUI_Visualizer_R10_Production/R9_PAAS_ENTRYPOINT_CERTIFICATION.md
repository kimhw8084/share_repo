# R9 PaaS single-entrypoint certification

Canonical company NiceGUI launch contract:

```bash
python app.py
```

The package root contains exactly one Python file: `app.py`. It resolves the bundled audited `source/` tree relative to `__file__`, so the working directory does not matter and no preinstalled Company UI wheel is required by the PaaS path. Root `requirements.txt` remains the authoritative dependency file.

Local `run_visualizer.sh`, setup HTTP smoke, headless Chromium startup smoke, and full live Visualizer smoke all execute the same root `app.py` path. The installed wheel console entrypoint is retained only as a packaging cross-check, not as the company deployment contract.
