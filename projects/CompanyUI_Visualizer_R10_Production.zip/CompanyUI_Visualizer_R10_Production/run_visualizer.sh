#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="${COMPANY_UI_VENV:-$ROOT/.venv}"
[ -x "$VENV/bin/python" ] || { echo 'Run ./setup_linux.sh first.' >&2; exit 1; }
[ -f "$ROOT/app.py" ] || { echo 'Canonical app.py entrypoint is missing.' >&2; exit 1; }
HOST="${COMPANY_UI_HOST:-127.0.0.1}"
PORT="${COMPANY_UI_PORT:-8080}"
DATA_DIR="${COMPANY_UI_VISUALIZER_DATA_DIR:-$HOME/.company_ui/visualizer/reports}"
echo "Company UI + Visualizer: http://$HOST:$PORT/visualizer"
echo "Canonical launch: $VENV/bin/python $ROOT/app.py"
echo "Report data: $DATA_DIR"
exec "$VENV/bin/python" "$ROOT/app.py" --host "$HOST" --port "$PORT" --data-dir "$DATA_DIR" "$@"
