#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return int(sock.getsockname()[1])


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def get(url: str, *, follow=True, timeout=8):
    opener = urllib.request.build_opener() if follow else urllib.request.build_opener(NoRedirect)
    try:
        with opener.open(url, timeout=timeout) as response:
            return response.status, dict(response.headers), response.read()
    except urllib.error.HTTPError as exc:
        return exc.code, dict(exc.headers), exc.read()


def main() -> int:
    parser = argparse.ArgumentParser(description='Installed-wheel HTTP startup/page-construction smoke for Company UI + Visualizer.')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--installed-wheel-entrypoint', action='store_true', help='Run the installed console script instead of canonical root app.py.')
    args = parser.parse_args()
    package_root = Path(__file__).resolve().parents[1]
    if args.installed_wheel_entrypoint:
        executable = Path(sys.executable).with_name('company-ui-visualizer')
        if not executable.is_file():
            raise SystemExit(f'installed console entrypoint missing: {executable}')
        command_prefix = [str(executable)]
        entry_kind = 'installed_wheel_entrypoint'
    else:
        entry = package_root / 'app.py'
        if not entry.is_file():
            raise SystemExit(f'canonical PaaS entrypoint missing: {entry}')
        command_prefix = [sys.executable, str(entry)]
        entry_kind = 'canonical_app_py'

    port = free_port()
    result = {'pass': False, 'port': port, 'entrypoint': entry_kind, 'checks': {}}
    with tempfile.TemporaryDirectory(prefix='cui-viz-startup-') as td:
        td_path = Path(td)
        log_path = td_path / 'server.log'
        data_dir = td_path / 'reports'
        env = os.environ.copy()
        env.update({'PYTHONUNBUFFERED':'1', 'COMPANY_UI_HOST':'127.0.0.1', 'COMPANY_UI_PORT':str(port), 'COMPANY_UI_VISUALIZER_DATA_DIR':str(data_dir)})
        with log_path.open('w', encoding='utf-8') as log:
            process = subprocess.Popen(command_prefix + ['--host', '127.0.0.1', '--port', str(port), '--data-dir', str(data_dir)], stdout=log, stderr=subprocess.STDOUT, env=env)
        base = f'http://127.0.0.1:{port}'
        try:
            deadline = time.monotonic() + 25
            last = None
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise AssertionError(f'server exited early with code {process.returncode}')
                try:
                    status, _, _ = get(base + '/visualizer', timeout=2)
                    last = status
                    if status == 200:
                        break
                except Exception as exc:
                    last = repr(exc)
                time.sleep(.15)
            else:
                raise AssertionError(f'/visualizer never reached HTTP 200; last={last!r}')
            result['checks']['visualizer_200'] = True

            root_status, root_headers, _ = get(base + '/', follow=False)
            if root_status != 307 or root_headers.get('Location') != '/visualizer':
                raise AssertionError(f'root redirect mismatch: status={root_status} location={root_headers.get("Location")!r}')
            result['checks']['root_redirect_307'] = True

            for path in ('/visualizer?new=1', '/visualizer?report=default'):
                status, _, _ = get(base + path)
                if status != 200:
                    raise AssertionError(f'{path} returned HTTP {status}')
            result['checks']['route_variants_200'] = True

            for path in ('/_cui_visualizer/assets/integrated_editor.mjs', '/_cui_visualizer/assets/integrated_editor.css'):
                status, _, body = get(base + path)
                if status != 200 or not body:
                    raise AssertionError(f'{path} failed: HTTP {status}, bytes={len(body)}')
            result['checks']['editor_assets_200'] = True

            # Resolve the complete browser-side module/fetch graph from the installed
            # product package and require every URL to exist over the real static mount.
            import importlib.util
            import company_ui.products.visualizer.page as visualizer_page_module
            verifier_path = package_root / 'tools' / 'verify_visualizer_asset_graph.py'
            spec = importlib.util.spec_from_file_location('verify_visualizer_asset_graph_runtime', verifier_path)
            if not spec or not spec.loader:
                raise AssertionError(f'asset graph verifier unavailable: {verifier_path}')
            verifier = importlib.util.module_from_spec(spec); spec.loader.exec_module(verifier)
            graph = verifier.build_graph(Path(visualizer_page_module.__file__).resolve().parent)
            if not graph.get('pass'):
                raise AssertionError(f'Visualiser asset graph invalid: {graph}')
            checked = []
            for path in graph['http_urls']:
                status, headers, body = get(base + path)
                if status != 200 or not body:
                    raise AssertionError(f'browser dependency failed: {path}: HTTP {status}, bytes={len(body)}')
                content_type = headers.get('Content-Type', '').lower()
                if path.endswith('.mjs') and 'javascript' not in content_type:
                    raise AssertionError(f'browser module MIME mismatch: {path}: {content_type!r}')
                if path.endswith('.json') and 'json' not in content_type:
                    raise AssertionError(f'browser JSON MIME mismatch: {path}: {content_type!r}')
                checked.append(path)
            result['checks']['browser_dependency_graph_200'] = checked

            status, _, body = get(base + '/_cui_visualizer/vendor/production_core/contracts/runtime_registry.json')
            registry = json.loads(body.decode('utf-8')) if status == 200 else {}
            if status != 200 or registry.get('elements') != 248 or registry.get('engines') != 17:
                raise AssertionError(f'authority registry mismatch: status={status}, registry={registry!r}')
            result['checks']['authority_248_17'] = True

            status, _, _ = get(base + '/_cui_visualizer/page.py')
            if status != 404:
                raise AssertionError(f'Python product source exposed over static route: HTTP {status}')
            result['checks']['python_source_not_static'] = True

            # Give async access/error logging a moment to flush before evaluating logs.
            time.sleep(.4)
            log_text = log_path.read_text(encoding='utf-8', errors='replace')
            forbidden = ('Traceback (most recent call last)', '500 Internal Server Error', 'AttributeError:', 'TypeError:', 'KeyError:', 'ExceptionGroup:')
            hits = [token for token in forbidden if token in log_text]
            if hits:
                raise AssertionError(f'unhandled runtime errors in installed-wheel server log: {hits}')
            result['checks']['server_log_clean'] = True
            result['pass'] = True
        except Exception as exc:
            result['error'] = f'{type(exc).__name__}: {exc}'
        finally:
            process.terminate()
            try:
                process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                process.kill(); process.wait(timeout=5)
            result['server_exit'] = process.returncode
            result['server_log_tail'] = log_path.read_text(encoding='utf-8', errors='replace')[-8000:] if log_path.exists() else ''

    text = json.dumps(result, indent=2, sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + '\n', encoding='utf-8')
    print(text)
    return 0 if result.get('pass') else 1

if __name__ == '__main__':
    raise SystemExit(main())
