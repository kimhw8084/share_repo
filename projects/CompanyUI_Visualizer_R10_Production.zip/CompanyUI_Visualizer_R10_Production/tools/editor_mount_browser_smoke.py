#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from pathlib import Path


def find_browser() -> str | None:
    configured = os.getenv('COMPANY_UI_BROWSER')
    candidates = ([configured] if configured else []) + [
        '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
        '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
        '/usr/bin/google-chrome','/usr/bin/google-chrome-stable','/usr/bin/chromium','/usr/bin/chromium-browser',
        '/usr/bin/microsoft-edge','/usr/bin/microsoft-edge-stable',
    ]
    for candidate in candidates:
        if candidate and Path(candidate).is_file() and os.access(candidate, os.X_OK):
            return candidate
    for name in ('google-chrome','google-chrome-stable','chromium','chromium-browser','microsoft-edge','microsoft-edge-stable','msedge'):
        found = shutil.which(name)
        if found:
            return found
    return None


def main() -> int:
    ap = argparse.ArgumentParser(description='Browser smoke for NiceGUI-owned retained Visualizer mount/rehydration.')
    ap.add_argument('--output', type=Path)
    ap.add_argument('--require-browser', action='store_true')
    args = ap.parse_args()
    package_root = Path(__file__).resolve().parents[1]
    product = package_root / 'source/company_ui/products/visualizer'
    result: dict = {'pass': False, 'checks': {}, 'console_errors': [], 'page_errors': []}
    browser_path = find_browser()
    if not browser_path:
        result.update({'pass': not args.require_browser, 'skipped': True, 'reason': 'browser not installed'})
        text = json.dumps(result, indent=2, sort_keys=True)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(text+'\n')
        print(text); return 0 if result['pass'] else 1
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        result['error'] = 'playwright is required'
        text = json.dumps(result, indent=2, sort_keys=True); print(text); return 2

    sys.path.insert(0, str(package_root / 'source'))
    from company_ui.products.visualizer.page import _editor_mount_script

    assets = product / 'assets'; core = product / 'vendor/production_core/core'
    fragment = (assets / 'integrated_editor.html').read_text(encoding='utf-8')
    css = (assets / 'integrated_editor.css').read_text(encoding='utf-8')
    editor_js = (assets / 'integrated_editor.mjs').read_text(encoding='utf-8')
    store_js = (core / 'editor_store.mjs').read_text(encoding='utf-8')
    registry_js = (core / 'runtime_registry.mjs').read_text(encoding='utf-8')
    renderer_js = (core / 'universal_renderer.mjs').read_text(encoding='utf-8')
    contracts_json = (product / 'vendor/production_core/contracts/component_contracts.json').read_text(encoding='utf-8')
    mount_id = 'visualizer-editor-mount-browser-smoke'
    installer = _editor_mount_script(mount_id, fragment)

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, executable_path=browser_path, args=['--disable-dev-shm-usage'])
        page = browser.new_page(viewport={'width': 1440, 'height': 1000})
        page.set_default_timeout(4000)
        page.on('console', lambda msg: result['console_errors'].append(msg.text) if msg.type == 'error' else None)
        page.on('pageerror', lambda exc: result['page_errors'].append(str(exc)))
        bootstrap = "<script>window.__CUI_VISUALIZER_BOOTSTRAP__={report_id:'mount-smoke',revision:1};window.__CUI_VISUALIZER_ASSET_BUILD__='mount-smoke';</script>"
        delayed_host = f'''<script>setTimeout(()=>{{const h=document.createElement('div');h.id={json.dumps(mount_id)};h.className='cui-visualizer-host';h.dataset.visualizerMount='pending';h.setAttribute('aria-busy','true');document.body.append(h);}},50);</script>'''
        page.set_content(f'<!doctype html><html><head><meta charset="utf-8"><style>{css}</style>{bootstrap}{installer}</head><body style="margin:0;min-height:100vh">{delayed_host}</body></html>', wait_until='domcontentloaded')
        page.evaluate("""async ({registry,store,renderer,editor,contracts}) => {
          const blob = source => URL.createObjectURL(new Blob([source], {type:'text/javascript'}));
          const registryUrl=blob(registry), storeUrl=blob(store);
          const rendererUrl=blob(renderer.replace("'./runtime_registry.mjs'", JSON.stringify(registryUrl)));
          const contractsUrl=URL.createObjectURL(new Blob([contracts], {type:'application/json'}));
          const patched=editor
            .replace("'../vendor/production_core/core/editor_store.mjs'", JSON.stringify(storeUrl))
            .replace("'../vendor/production_core/core/runtime_registry.mjs'", JSON.stringify(registryUrl))
            .replace("'../vendor/production_core/core/universal_renderer.mjs'", JSON.stringify(rendererUrl))
            .replace("new URL('../vendor/production_core/contracts/component_contracts.json', import.meta.url)", JSON.stringify(contractsUrl));
          await import(blob(patched));
        }""", {'registry': registry_js, 'store': store_js, 'renderer': renderer_js, 'editor': editor_js, 'contracts': contracts_json})
        page.wait_for_function("() => document.querySelector('.cui-visualizer-root')?.dataset.editorReady==='true'")
        first = page.evaluate("""() => {const root=document.querySelector('.cui-visualizer-root');const r=root.getBoundingClientRect();return {instance:+root.dataset.editorInstance,w:r.width,h:r.height,mount:root.parentElement.dataset.visualizerMount,library:document.querySelector('#libraryCount')?.textContent,toolbar:document.querySelector('.topbar')?.getBoundingClientRect().height||0,canvas:document.querySelector('#viewport')?.getBoundingClientRect().height||0};}""")
        result['checks']['initial_mount'] = first
        if not (first['instance'] >= 1 and first['w'] > 1000 and first['h'] >= 660 and first['mount'] == 'mounted' and '248' in first['library'] and first['toolbar'] > 30 and first['canvas'] > 300):
            raise AssertionError(f'initial retained editor mount not visibly complete: {first}')

        # Simulate a Vue/NiceGUI reconciliation replacing the mount node itself.
        page.evaluate(f"""() => {{const old=document.getElementById({json.dumps(mount_id)});const fresh=document.createElement('div');fresh.id=old.id;fresh.className=old.className;fresh.dataset.visualizerMount='pending';fresh.setAttribute('aria-busy','true');old.replaceWith(fresh);}}""")
        page.wait_for_function("() => document.querySelector('.cui-visualizer-root')?.dataset.editorReady==='true' && Number(document.querySelector('.cui-visualizer-root')?.dataset.editorInstance)>=2")
        second = page.evaluate("""() => {const root=document.querySelector('.cui-visualizer-root');const r=root.getBoundingClientRect();return {instance:+root.dataset.editorInstance,w:r.width,h:r.height,mount:root.parentElement.dataset.visualizerMount,library:document.querySelector('#libraryCount')?.textContent,toolbar:document.querySelector('.topbar')?.getBoundingClientRect().height||0,canvas:document.querySelector('#viewport')?.getBoundingClientRect().height||0};}""")
        result['checks']['rehydrated_mount'] = second
        if not (second['instance'] >= 2 and second['w'] > 1000 and second['h'] >= 660 and second['mount'] == 'mounted' and '248' in second['library'] and second['toolbar'] > 30 and second['canvas'] > 300):
            raise AssertionError(f'rehydrated editor mount not visibly complete: {second}')
        if result['console_errors'] or result['page_errors']:
            raise AssertionError(f'browser errors: {result["console_errors"]!r} {result["page_errors"]!r}')
        result['pass'] = True
        browser.close()

    text = json.dumps(result, indent=2, sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(text+'\n', encoding='utf-8')
    print(text)
    return 0 if result.get('pass') else 1


if __name__ == '__main__':
    raise SystemExit(main())
