#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

IMPORT_RE = re.compile(r"(?:import\s+(?:[^'\"]+?\s+from\s+)?|export\s+[^'\"]+?\s+from\s+)[\"']([^\"']+)[\"']")
DYNAMIC_RE = re.compile(r"import\(\s*[\"']([^\"']+)[\"']\s*\)")
URL_RE = re.compile(r"new\s+URL\(\s*[\"']([^\"']+)[\"']\s*,\s*import\.meta\.url\s*\)")


def references(text: str) -> list[str]:
    refs = IMPORT_RE.findall(text) + DYNAMIC_RE.findall(text) + URL_RE.findall(text)
    return [ref for ref in refs if ref.startswith(('.', '/'))]


def build_graph(product_root: Path) -> dict:
    product_root = product_root.resolve()
    entry = product_root / 'assets' / 'integrated_editor.mjs'
    queue = [entry]
    seen: set[Path] = set()
    edges: list[dict[str, str]] = []
    missing: list[str] = []
    escaped: list[str] = []

    while queue:
        current = queue.pop(0).resolve()
        if current in seen:
            continue
        seen.add(current)
        if not current.is_file():
            missing.append(str(current))
            continue
        if current.suffix not in {'.mjs', '.js'}:
            continue
        text = current.read_text(encoding='utf-8')
        for ref in references(text):
            if ref.startswith('/'):
                # Runtime entry currently uses only relative module URLs; absolute paths
                # are recorded but not mapped back into the product filesystem.
                edges.append({'from': str(current.relative_to(product_root)), 'specifier': ref, 'to': ref})
                continue
            target = (current.parent / ref).resolve()
            try:
                rel_target = target.relative_to(product_root)
            except ValueError:
                escaped.append(f'{current.relative_to(product_root)} -> {ref} -> {target}')
                continue
            edges.append({'from': str(current.relative_to(product_root)), 'specifier': ref, 'to': str(rel_target)})
            if not target.is_file():
                missing.append(str(rel_target))
            elif target.suffix in {'.mjs', '.js'}:
                queue.append(target)

    http_urls: list[str] = []
    unsupported: list[str] = []
    for path in sorted(seen):
        rel = path.relative_to(product_root)
        parts = rel.parts
        if parts and parts[0] == 'assets':
            http_urls.append('/_cui_visualizer/assets/' + '/'.join(parts[1:]))
        elif parts[:2] == ('vendor', 'production_core'):
            http_urls.append('/_cui_visualizer/vendor/production_core/' + '/'.join(parts[2:]))
        else:
            unsupported.append(str(rel))
    # Include non-JS fetch targets such as component_contracts.json.
    for edge in edges:
        target = product_root / edge['to'] if not edge['to'].startswith('/') else None
        if target and target.is_file() and target.suffix not in {'.mjs', '.js'}:
            rel = target.relative_to(product_root)
            if rel.parts[0] == 'assets':
                http_urls.append('/_cui_visualizer/assets/' + '/'.join(rel.parts[1:]))
            elif rel.parts[:2] == ('vendor', 'production_core'):
                http_urls.append('/_cui_visualizer/vendor/production_core/' + '/'.join(rel.parts[2:]))
            else:
                unsupported.append(str(rel))

    return {
        'pass': not missing and not escaped and not unsupported,
        'entry': str(entry.relative_to(product_root)),
        'files': sorted(str(path.relative_to(product_root)) for path in seen),
        'http_urls': sorted(set(http_urls)),
        'edges': edges,
        'missing': sorted(set(missing)),
        'escaped': sorted(set(escaped)),
        'unsupported': sorted(set(unsupported)),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description='Verify the complete retained Visualizer browser module/fetch asset graph.')
    parser.add_argument('--product-root', type=Path, default=Path('source/company_ui/products/visualizer'))
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = build_graph(args.product_root)
    text = json.dumps(result, indent=2, sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + '\n', encoding='utf-8')
    print(text)
    return 0 if result['pass'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
