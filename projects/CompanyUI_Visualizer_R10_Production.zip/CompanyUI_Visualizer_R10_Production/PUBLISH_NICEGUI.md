# Company PaaS NiceGUI publish — canonical entrypoint

Use the **package root** as the project/workspace.

## Select these two files

- **NiceGUI / Python main file:** `app.py`
- **Requirements file:** `requirements.txt`

The expected platform launch is simply:

```bash
python app.py
```

Do not select a nested module, `run_visualizer.sh`, or the wheel console script. `app.py` is the one canonical PaaS entrypoint and prepends the bundled audited `source/` tree itself, so deployment does not require the Company UI wheel to be installed.

## Kubernetes / PaaS environment

`app.py` ultimately uses the governed Visualizer CLI, which resolves:

- host: `COMPANY_UI_HOST`, then `HOST`, otherwise `0.0.0.0`
- port: `COMPANY_UI_PORT`, then `PORT`, otherwise `8080`
- report persistence: `COMPANY_UI_VISUALIZER_DATA_DIR`
- runtime environment: `COMPANY_UI_ENVIRONMENT` (`dev`, `test`, `qa`, `prod`; `production` alias accepted)
- production storage secret: `COMPANY_UI_STORAGE_SECRET`

For `COMPANY_UI_ENVIRONMENT=prod`, `COMPANY_UI_STORAGE_SECRET` is mandatory and startup fails closed if it is absent. For durable reports, point `COMPANY_UI_VISUALIZER_DATA_DIR` at the approved persistent volume.

Canonical workspace: `/visualizer`. `/` redirects to `/visualizer`.
