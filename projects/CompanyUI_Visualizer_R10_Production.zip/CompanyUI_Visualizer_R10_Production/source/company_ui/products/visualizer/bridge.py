from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Mapping

from .domain import (
    REPORT_SCHEMA_VERSION,
    ReportRecord,
    RevisionConflictError,
    VisualizerContractError,
    apply_editor_command,
    canonical_model,
    fingerprint_model,
    utc_now,
)
from .repository import ReportRepository

BRIDGE_VERSION = 1
BROWSER_TO_SERVER = frozenset({
    'report.opened', 'report.commit', 'report.save_requested', 'report.save_as_requested',
    'dataset.bind_requested', 'asset.import_requested', 'ppt.export_requested', 'diagnostic.event',
})
FORBIDDEN_HIGH_FREQUENCY = frozenset({'pointermove', 'drag frame', 'hover frame', 'brush frame', 'connector reroute frame', 'virtual scroll frame', 'DOM geometry read'})


@dataclass(frozen=True, slots=True)
class BridgeResponse:
    type: str
    payload: Mapping[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {'bridge_version': BRIDGE_VERSION, 'type': self.type, 'payload': deepcopy(dict(self.payload))}


class VisualizerBridgeService:
    def __init__(self, repository: ReportRepository, *, commit_history_limit: int = 256):
        if commit_history_limit < 8:
            raise ValueError('commit_history_limit must be >= 8')
        self.repository = repository
        self.commit_history_limit = commit_history_limit

    def bootstrap(self, report_id: str) -> BridgeResponse:
        record = self.repository.get_or_create(report_id, title='Untitled report')
        return BridgeResponse('report.bootstrap', self._record_payload(record))

    def handle(self, message: Mapping[str, Any]) -> BridgeResponse | None:
        if int(message.get('bridge_version', BRIDGE_VERSION)) != BRIDGE_VERSION:
            raise VisualizerContractError('unsupported bridge_version')
        kind = message.get('type')
        if not isinstance(kind, str) or kind not in BROWSER_TO_SERVER:
            raise VisualizerContractError(f'unsupported bridge message: {kind!r}')
        if kind == 'report.opened':
            payload = message.get('payload', {})
            if not isinstance(payload, Mapping):
                raise VisualizerContractError('report.opened payload must be an object')
            return self.bootstrap(str(payload.get('report_id', 'default')))
        if kind == 'report.commit':
            return self.commit(message.get('payload', {}))
        if kind in {'report.save_requested', 'report.save_as_requested'}:
            return self._save_request(kind, message.get('payload', {}))
        if kind == 'diagnostic.event':
            return BridgeResponse('application.notification', {'level': 'debug', 'accepted': True})
        return None

    def commit(self, payload: Any) -> BridgeResponse:
        if not isinstance(payload, Mapping):
            raise VisualizerContractError('report.commit payload must be an object')
        required = ('report_id', 'schema_version', 'base_revision', 'commit_id', 'command_or_patch', 'state_fingerprint', 'canonical_state')
        missing = [key for key in required if key not in payload]
        if missing:
            raise VisualizerContractError(f'report.commit missing {missing[0]}')
        report_id = str(payload['report_id'])
        record = self.repository.get(report_id)
        if int(payload['schema_version']) != REPORT_SCHEMA_VERSION:
            return self._reject(record, str(payload['commit_id']), 'invalid_schema')
        commit_id = str(payload['commit_id'])
        if not commit_id:
            return self._reject(record, commit_id, 'invalid_commit_id')
        claimed_model = canonical_model(payload['canonical_state'] if isinstance(payload['canonical_state'], Mapping) else {})
        claimed_fingerprint = str(payload['state_fingerprint'])
        if fingerprint_model(claimed_model) != claimed_fingerprint:
            return self._reject(record, commit_id, 'fingerprint_mismatch')

        if commit_id in record.commit_ids:
            # Idempotent retry: accept only if browser has already converged to server state.
            if claimed_fingerprint == record.state_fingerprint:
                return BridgeResponse('report.commit_ack', {'report_id': report_id, 'commit_id': commit_id, 'revision': record.revision, 'state_fingerprint': record.state_fingerprint, 'duplicate': True})
            return self._reject(record, commit_id, 'duplicate_non_idempotent_commit')

        base_revision = int(payload['base_revision'])
        if base_revision != record.revision:
            return self._reject(record, commit_id, 'stale_base_revision')

        command = payload['command_or_patch']
        if not isinstance(command, Mapping):
            return self._reject(record, commit_id, 'invalid_command')
        command_kind = command.get('type')
        try:
            if command_kind == 'editor.transaction':
                expected = apply_editor_command(record.model, command, expected_revision=record.revision)
                if fingerprint_model(expected) != claimed_fingerprint:
                    return self._reject(record, commit_id, 'command_state_mismatch')
            elif command_kind in {'history.undo', 'history.redo', 'model.bootstrap_replace'}:
                # Undo/redo is canonicalized by the frozen browser EditorStore; the server
                # still owns revision ordering and validates the complete resulting state.
                pass
            else:
                return self._reject(record, commit_id, 'unsupported_command')
        except (VisualizerContractError, RevisionConflictError):
            return self._reject(record, commit_id, 'invalid_command')

        ids = (*record.commit_ids, commit_id)[-self.commit_history_limit:]
        updated = ReportRecord(
            report_id=record.report_id,
            revision=record.revision + 1,
            model=claimed_model,
            title=record.title,
            created_at=record.created_at,
            updated_at=utc_now(),
            commit_ids=ids,
            metadata=record.metadata,
        )
        self.repository.save(updated)
        return BridgeResponse('report.commit_ack', {
            'report_id': report_id,
            'commit_id': commit_id,
            'revision': updated.revision,
            'state_fingerprint': updated.state_fingerprint,
            'duplicate': False,
        })

    def _save_request(self, kind: str, payload: Any) -> BridgeResponse:
        if not isinstance(payload, Mapping):
            raise VisualizerContractError(f'{kind} payload must be an object')
        report_id = str(payload.get('report_id', ''))
        record = self.repository.get(report_id)
        if kind == 'report.save_as_requested':
            new_report_id = str(payload.get('new_report_id', '')).strip()
            if not new_report_id:
                raise VisualizerContractError('save-as requires new_report_id')
            copy = self.repository.duplicate(report_id, new_report_id, title=str(payload.get('title') or record.title))
            return BridgeResponse('report.bootstrap', self._record_payload(copy))
        return BridgeResponse('application.notification', {'level': 'success', 'message': 'Report is saved', 'report_id': record.report_id, 'revision': record.revision})

    def _reject(self, record: ReportRecord, commit_id: str, reason: str) -> BridgeResponse:
        return BridgeResponse('report.commit_rejected', {
            'report_id': record.report_id,
            'commit_id': commit_id,
            'reason': reason,
            'authoritative': self._record_payload(record),
        })

    @staticmethod
    def _record_payload(record: ReportRecord) -> dict[str, Any]:
        return {
            'report_id': record.report_id,
            'schema_version': record.schema_version,
            'revision': record.revision,
            'state_fingerprint': record.state_fingerprint,
            'model': canonical_model(record.model),
            'title': record.title,
            'updated_at': record.updated_at,
        }
