from __future__ import annotations

import importlib.util
from pathlib import Path

from company_ui.products.visualizer import page


def _load_verifier():
    root = Path(__file__).resolve().parents[2]
    path = root / 'tools' / 'verify_visualizer_asset_graph.py'
    spec = importlib.util.spec_from_file_location('verify_visualizer_asset_graph', path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_visualizer_retained_browser_dependency_graph_is_complete_and_mountable():
    verifier = _load_verifier()
    product_root = Path(page.__file__).resolve().parent
    result = verifier.build_graph(product_root)
    assert result['pass'], result
    assert '/_cui_visualizer/assets/integrated_editor.mjs' in result['http_urls']
    assert '/_cui_visualizer/vendor/production_core/core/editor_store.mjs' in result['http_urls']
    assert '/_cui_visualizer/vendor/production_core/core/runtime_registry.mjs' in result['http_urls']
    assert '/_cui_visualizer/vendor/production_core/core/universal_renderer.mjs' in result['http_urls']
    assert '/_cui_visualizer/vendor/production_core/contracts/component_contracts.json' in result['http_urls']
    assert not any('/vendor/core/' in url for url in result['http_urls'])


def test_visualizer_static_vendor_mount_matches_browser_import_namespace():
    source = Path(page.__file__).read_text(encoding='utf-8')
    assert "f'{STATIC_ROUTE}/vendor/production_core'" in source
    assert "str(Path(__file__).with_name('vendor') / 'production_core')" in source
