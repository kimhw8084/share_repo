# R8 Visualizer UX + Asset Runtime Certification

R8 supersedes R1-R7.

## Root causes closed

1. **Retained module 404s** — the editor imports `../vendor/production_core/...`; NiceGUI now mounts `/_cui_visualizer/vendor/production_core` directly to the frozen `production_core/` authority directory. The previous mount was one path segment too high/low and produced `production_core/production_core/...` resolution failures.
2. **Dead editor after host DOM replacement** — the retained editor observes/rebinds when NiceGUI/Vue replaces the product root.
3. **Plain-HTTP history failure** — secure-context-only UUID/WebCrypto dependencies were removed from browser command/history paths.
4. **Preview CSS mismatch** — preview state now lives on `.cui-visualizer-root`, inside the product's scoped CSS boundary.
5. **Inspector/workspace geometry** — the inspector has explicit close/toggle behavior; close reclaims the full center track and triggers fit/geometry recalculation.
6. **Tablet clipping** — the editor app grid now uses a constrained `minmax(0,1fr)` track so toolbar min-content cannot expand the shell beyond the host. Tablet toolbar overflow is browser-local and scrollable instead of increasing layout width.
7. **Host mobile navigation** — Company UI mobile menu/backdrop/close transitions are browser-local and do not depend on a NiceGUI round trip.
8. **Report chrome** — legacy Visualizer report titles normalize to `Untitled report`; technical `248 elements / 17 engines` copy is no longer used as the page subtitle.
9. **Stale browser assets** — integrated editor asset URLs carry a content-derived build ID and the mutable integrated asset mount uses zero cache age.

## Hard gates added

- recursive retained-browser import/fetch graph verification;
- every graph URL must resolve over the actual NiceGUI static namespace during live startup;
- `.mjs` responses must have a JavaScript MIME type and JSON fetch targets must have JSON MIME type;
- live Playwright certification records/fails same-origin 4xx/5xx responses;
- strict NiceGUI 3.15 page-builder and callback execution;
- Chromium behavior matrix for every visible editor control class used in the integrated workspace;
- desktop inspector open/closed/reopened balanced canvas margins;
- tablet/phone shell and work-area containment inside the product host;
- root-replacement/rebind behavior;
- zero pointer-move server mutation;
- no secure-context-only browser dependency, external runtime URL, or runtime Node dependency.

HTTP `304 Not Modified` responses from NiceGUI's own immutable/cacheable static files are normal successful cache validation and are not treated as errors. HTTP `404` responses for Visualizer runtime dependencies are release blockers.
