# R10 production signoff

R10 supersedes R1-R9 for deployment.

## Release status

R10 closes the final blank-editor integration defect observed on the work PC. The previous page could render Company UI report controls while the retained Visualizer root collapsed to ~2 px high with a 0 px canvas viewport. R10 corrects the CSS sizing root cause and replaces `ui.html(fragment)` projection with a NiceGUI-owned mount plus direct retained-fragment installation/rehydration.

## Final engineering gates

- **712/712** Company UI + Visualizer integration tests passing.
- Company UI governance: **0 errors / 0 warnings**.
- Strict NiceGUI-3.15-shaped `/visualizer` page construction and post-render callback contract passes.
- Delayed NiceGUI-style mount/rehydration Chromium gate passes: root **1440x844**, canvas **718px**, 248/248 library, zero console/page errors before and after host replacement.
- Full Chromium editor behavior matrix passes control/history/selection/layout/preview/inspector/zoom/library/semantic/rebind/responsive checks with zero console/page errors.
- Tablet and phone internal shell/work geometry is asserted inside the Visualizer host.
- Recursive retained-browser module/fetch graph has no missing or escaped targets.
- Headless live startup requires `data-visualizer-mount=mounted`, `data-editor-geometry=pass`, 248/248 readiness, and clean server logs.
- Live Playwright integration rejects same-origin 4xx/5xx responses.
- Frozen Visualizer authority: 123/123 files match the authority manifest; 27/27 frozen-authority evidence remains applicable because those bytes are unchanged.
- 248/248 elements and 17/17 engines preserved.
- Golden Connector Engine v5 SHA-256 remains `d8ebd4378f01b7c52a7a4be57c578c22adf29b899cc08a370cf084881195343e`.
- Installable wheel is byte-compared to audited Company UI Python source and Visualizer package data.
- Root `requirements.txt` remains the production dependency authority.
- Root `app.py` is the single-file NiceGUI PaaS entrypoint.
- Production storage secret fails closed; no predictable production fallback is shipped.
- No runtime Node dependency, `crypto.randomUUID`, or `crypto.subtle` dependency remains in the integrated browser path.

## Exact NiceGUI target-runtime gate

The build sandbox cannot install NiceGUI 3.15.0 from the package index, so that target-runtime execution is not fabricated. `setup_linux.sh` is fail-closed on the target: it installs root `requirements.txt`, verifies NiceGUI 3.15.0, starts canonical `app.py` and the wheel launcher, requires `/visualizer` HTTP 200, requires every Visualizer module/JSON dependency HTTP 200, rejects server exceptions, and when Chrome/Chromium/Edge is present requires the retained editor mount, geometry marker and 248/248 QA readiness before reporting setup complete. `test_linux.sh` adds the delayed-mount/rehydration and full interaction matrices.

HTTP 304 responses for NiceGUI's own cacheable framework assets are valid cache revalidation. Visualizer `.mjs`/JSON 404s are hard failures.

## Canonical PaaS execution

The package root contains exactly one Python file: `app.py`. Company NiceGUI PaaS must install root `requirements.txt` and execute:

```bash
python app.py
```
