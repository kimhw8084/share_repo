# Metrology Unified Observability Factory v3

Status: **APPROVED ENGINEERING BASELINE — corporate execution required**  
Version: **3.0.0**  
Approval: `approvals/v3-defaults.approved.yml`  
Production validated: **No**

## Objective

Port this repository once into the corporate environment, run one resumable
evidence campaign, process raw logs/configurations only with corporate-local
tools, and produce one sanitized return bundle for final external engineering
refinement.

V3 retains the v2 fail-closed compiler, generators, probes, and validation
controls. It adds the missing campaign layer:

```text
approved defaults + inventory
        ↓
campaign initialization
        ↓
generated owner forms + reviewed local runner bundles
        ↓
host/platform evidence + local Llama/OpenCode analysis
        ↓
evidence graph + gate-specific completeness
        ↓
draft platform/system profiles + targeted reruns
        ↓
sanitized-return-bundle.zip
```

## Boundaries

The repository does not:

- remotely execute across the fleet by default;
- deploy or mutate Prometheus, Splunk, OpenTelemetry, servers, databases,
  accounts, networks, or equipment interfaces;
- restart, fail over, delete, write production data, or remediate automatically;
- export raw logs or raw configurations;
- infer business criticality, functional success, production approval, or root
  cause.

Humans or approved corporate orchestration run the generated local bundles.
Consequential approvals and production actions remain internal.

## The one-campaign workflow

### 1. Install

```bash
python -m pip install --no-build-isolation -e ".[dev]"
python -m pytest
```

### 2. Prepare inventory

Copy:

```text
inventory/campaign-inventory-template.csv
```

Include the selected Windows pilot, Linux pilot, and relevant
Prometheus/Splunk platform hosts. Use aliases where policy requires.

### 3. Initialize

```bash
obsfactory campaign init \
  --approval approvals/v3-defaults.approved.yml \
  --inventory inventory/corporate-campaign.csv \
  --inventory-snapshot-date YYYY-MM-DD \
  --campaign-id metrology-observability-pilot \
  --output campaign
```

Initialization creates:

- campaign policy and evidence requirements;
- system-owner forms;
- platform-owner forms;
- validation and operator-acceptance forms;
- benefit-baseline form;
- evidence ledger;
- inbox and output zones.

### 4. Complete accountable forms

Complete the forms that discovery cannot answer:

```text
campaign/forms/systems/
campaign/forms/platforms/
```

Set:

```yaml
status: completed
completed_at_utc: 2026-08-03T15:00:00Z
```

only after accountable review.

### 5. Advance centrally

```bash
obsfactory campaign advance campaign
```

`advance` automatically:

- ingests completed forms;
- skips drafts;
- derives platform capability evidence from complete owner attestations;
- builds missing host runner bundles;
- creates corporate-local AI jobs when approved log sources exist;
- computes design, pilot, production, and scale completeness;
- emits targeted next actions.

### 6. Approve local runners in one batch

Review:

```text
campaign/execution/runner-approval-template.csv
```

Set each approved row to:

```csv
host_alias,approved,reviewer_role,review_reference
host-alias,true,system-owner,CHANGE-OR-REVIEW-REFERENCE
```

Then:

```bash
obsfactory campaign approve-runners campaign \
  --approval-csv campaign/execution/runner-approval-template.csv
```

Approval is bound to the exact host-run manifest SHA-256. Any subsequent
manifest change causes the local runner to refuse execution.

### 7. Execute locally

Move each ZIP from:

```text
campaign/execution/bundles/
```

to the corresponding approved host. Extract and run:

Linux:

```bash
./run.sh
```

Windows:

```powershell
.\Run.ps1
```

Copy only:

```text
output/evidence/*.json
```

back to:

```text
campaign/inbox/
```

Keep `output/local-raw/` inside the corporate environment.

### 8. Advance again

```bash
obsfactory campaign advance campaign
```

The evidence graph is updated. Missing collectors, privilege gaps, conflicts,
stale evidence, and unsupported capabilities become narrow rerun actions.

### 9. Run corporate-local AI jobs

After approved log sources exist:

```bash
python scripts/campaign/run_ai_jobs.py \
  --jobs campaign/ai-jobs \
  --command-json examples/local-ai-command.example.json \
  --output campaign/ai-results \
  --acknowledge-local-ai I_HAVE_APPROVAL
```

Replace the example command array with the approved Llama/OpenCode CLI adapter.
The runner:

- chunks files locally with overlap;
- records coverage;
- executes argv without a shell;
- validates every model result;
- rejects root-cause confirmation and secret-shaped output;
- merges signatures, sequences, telemetry candidates, and alert candidates;
- emits one campaign evidence envelope per system.

### 10. Finalize

```bash
obsfactory campaign advance campaign \
  --external-output sanitized-return-bundle.zip \
  --force
```

The return bundle contains:

- pseudonymized fleet inventory;
- draft platform profile;
- draft system profiles;
- sanitized evidence summary;
- 205-question evidence-status ledger;
- gate-specific completeness;
- conflicts and limitations;
- targeted rerun plan;
- profile-validation results;
- external security-screen report;
- hash manifest.

It never contains the pseudonymization map, raw logs, raw configurations,
credentials, exact endpoints, or production validation claims.

## When to return the bundle

For the intended final external design pass, target:

- design gate: 100%;
- pilot gate: 100%;
- conflicts: 0;
- no profile schema errors;
- external security blocking findings: 0.

Production and scale gates may remain incomplete because controlled failure
testing, routing, deployment, operator acceptance, rollback, and benefit
realization occur after final code refinement inside the corporate environment.

## Main commands

```text
obsfactory campaign init
obsfactory campaign advance
obsfactory campaign build-runners
obsfactory campaign approve-runners
obsfactory campaign ingest
obsfactory campaign build-ai-jobs
obsfactory campaign status
obsfactory campaign finalize
```

## Start here

1. `docs/30-work-environment-one-campaign-runbook.md`
2. `inventory/campaign-inventory-template.csv`
3. `approvals/v3-defaults.approved.yml`
4. `questionnaires/v3-principal-evidence-questionnaire.yml`
5. `SECURITY.md`
6. `RELEASE_VALIDATION.md`

## Truth boundary

This repository is ready for corporate review and evidence collection. No live
corporate system has been inspected, modified, deployed, or approved through
this environment.
