# Example Windows File Pipeline Observability Package

Status: REVIEW-READY — corporate validation required  
Generated: 2026-08-03  
System ID: `example-windows-file-pipeline`  
Environment: `test`  
Criticality: `TBD`  
Owner team: `metrology-software`

## Purpose

Provide a standardized Prometheus/Splunk observability onboarding package for this system. The files are generated from `profile.resolved.yml`.

## Safety boundary

- No file in this package has been deployed or validated against corporate platforms.
- All targets, endpoints, indexes, sourcetypes, routing, credentials, and deployment paths are placeholders until approved.
- Raw logs remain in the corporate environment.
- Production writes, restarts, failovers, security changes, and automatic remediation are outside this package.
- Alert conditions are candidates until tested against baseline and failure evidence.

## Contents

- `design/`: architecture and coverage analysis.
- `prometheus/`: reference scrape, recording, and alert rules.
- `splunk/`: reference searches and field model.
- `otel/`: optional reference Collector configuration.
- `dashboards/`: backend-neutral dashboard specification.
- `probes/`: generated probe plan; implementations live in the parent factory repository.
- `runbooks/`: alert response and evidence-preservation guidance.
- `tests/`: acceptance test plan.
- `deployment/`: deployment and rollback controls.
- `TBD-corporate-values.yml`: values that must be resolved internally.

## Generation

```bash
obsfactory validate profile profile.yml
obsfactory generate profile.yml --output generated/example-windows-file-pipeline
```

## Acceptance

The package is complete only after syntax validation, non-production testing, alert firing/clearing tests, dashboard usefulness review, operator validation, ownership acceptance, and approved production change.
