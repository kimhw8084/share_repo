# Compilation Diagnostics

System: `example-windows-file-pipeline`

| Severity | Code | Path | Message | Remediation |
|---|---|---|---|---|
| warning | `OWNERSHIP_UNRESOLVED` | `$.ownership.primary_owner` | primary_owner is unresolved. | Assign accountable primary and backup ownership before production enablement. |
| warning | `OWNERSHIP_UNRESOLVED` | `$.ownership.backup_owner` | backup_owner is unresolved. | Assign accountable primary and backup ownership before production enablement. |
| advisory | `DATABASE_PROBE_EXTERNAL_MANIFEST_REQUIRED` | `$.dependencies[0].probe_type` | Database dependency 'downstream-database' requires the guarded external DB manifest workflow. | Create an approved query manifest; the generic probe supervisor will not execute SQL. |
| warning | `REQUIRED_SIGNAL_UNVALIDATED` | `$.signals[0]` | Required signal 'functional-up' is unvalidated. | Attach synthetic/failure test evidence before production alerting. |
| warning | `REQUIRED_SIGNAL_UNVALIDATED` | `$.signals[1]` | Required signal 'transaction-count' is unvalidated. | Attach synthetic/failure test evidence before production alerting. |
| warning | `REQUIRED_SIGNAL_UNVALIDATED` | `$.signals[2]` | Required signal 'freshness' is unvalidated. | Attach synthetic/failure test evidence before production alerting. |
| warning | `REQUIRED_SIGNAL_UNVALIDATED` | `$.signals[3]` | Required signal 'backlog' is unvalidated. | Attach synthetic/failure test evidence before production alerting. |
| warning | `REQUIRED_SIGNAL_UNVALIDATED` | `$.signals[4]` | Required signal 'dependency' is unvalidated. | Attach synthetic/failure test evidence before production alerting. |
| warning | `REQUIRED_SIGNAL_UNVALIDATED` | `$.signals[5]` | Required signal 'probe-health' is unvalidated. | Attach synthetic/failure test evidence before production alerting. |

Errors block strict generation. Warnings and advisories require review.
