# Example Windows File Pipeline — Observability Design

Status: REVIEW-READY  
Date: 2026-08-03  
Owner: TBD  
Backup: TBD

## Business function

Process approved input files into validated downstream records.

## Goals

- Detect loss or degradation of the production function before or at the same time as user impact.
- Present standardized evidence across host, service, data flow, dependency, and log layers.
- Reduce manual server-by-server evidence collection.
- Support bounded technician action where a validated SOP exists.
- Preserve high-cardinality investigation detail in Splunk rather than Prometheus labels.

## Non-goals

- Replacement of company Prometheus or Splunk.
- Autonomous production remediation.
- Root-cause confirmation from correlation alone.
- Export of raw logs or internal identifiers outside the intranet.
- Unapproved installation of agents, exporters, or network listeners.

## Platform

- OS families: windows
- Deployment model: virtual
- Site Prometheus available: True
- Site Splunk available: True
- OpenTelemetry allowed: TBD

## Services

| ID | Runtime | Required | Functional health definition |
|---|---|---:|---|
| `processor` | windows-service | True | A controlled test input completes the processing flow within the validated objective. |

## Dependencies

| ID | Type | Criticality | Evidence | Probe |
|---|---|---|---|---|
| `downstream-database` | mssql | required | Approved read-only connectivity or transaction evidence. | query-template |
| `input-share` | file-share | required | Approved path is readable and input metadata can be enumerated within limits. | file-metadata |

## Data flows

### file-to-record

Approved input file progresses through detection, processing, and downstream delivery.

Success: A valid input produces one accepted downstream result.

| Stage | Evidence | Freshness threshold | Backlog threshold | Latency objective |
|---|---|---:|---:|---:|
| `input-detected` | file metadata | 900 | 100 | TBD |
| `processing-completed` | application metric or log-derived feature | 900 | TBD | 120 |
| `delivered` | approved database/application evidence | 1200 | TBD | 180 |

## Signal catalog

| ID | Type | Name | Coverage | Required | Validation |
|---|---|---|---|---:|---|
| `functional-up` | metric | `metrology_functional_up` | functional_availability | True | controlled failure and recovery |
| `transaction-count` | metric | `metrology_transactions_total` | traffic | True | reconcile with approved source |
| `freshness` | metric | `metrology_last_success_unixtime_seconds` | freshness | True | validate timestamp and idle behavior |
| `backlog` | metric | `metrology_backlog_items` | backlog | True | validate partial files and archive behavior |
| `dependency` | metric | `metrology_dependency_up` | dependencies | True | distinguish probe from dependency failure |
| `probe-health` | metric | `metrology_probe_success` | telemetry_path | True | none |

## Design controls

1. Prometheus labels must be bounded and stable.
2. Lot, wafer, recipe, equipment, transaction, filename, user, GUID, timestamp, and error-message values are not permitted as default metric labels.
3. Prometheus stores state and aggregate behavior; Splunk stores detailed event context.
4. Every actionable alert identifies the production symptom, scope, evidence link, first safe check, escalation condition, and recovery condition.
5. Monitoring collectors and telemetry pipelines are themselves monitored.
6. Functional health is distinct from process/host uptime.
7. Thresholds require baseline or failure evidence before production paging.

## Open questions

- What identifies a successful downstream record?
- How is planned idle time distinguished from stale processing?

## Assumptions

- Example thresholds are candidates and not production recommendations.
