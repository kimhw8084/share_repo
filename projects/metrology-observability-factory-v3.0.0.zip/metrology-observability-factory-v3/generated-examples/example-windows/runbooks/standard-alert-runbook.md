# Standard Alert Runbook — Example Windows File Pipeline

Status: REVIEW-READY  
Owner: TBD  
Backup: TBD

## Universal first response

1. Confirm alert start, affected scope, and whether production impact is observed.
2. Preserve the alert time window, relevant metrics, normalized log signatures, and recent-change evidence.
3. Compare affected with unaffected hosts, services, flows, or dependencies.
4. Do not restart, fail over, write to databases, delete files, modify accounts, or change configuration unless an approved procedure and authority exist.
5. Use the recovery signal defined for the alert; process uptime alone is not recovery evidence.

## MetrologyTelemetryMissing

### Meaning

The monitoring path is absent. Production function may still be healthy.

### Checks

- Verify whether other systems are visible in site Prometheus.
- Check exporter/Collector service state using an approved procedure.
- Check scrape status and last successful telemetry.
- Check resource saturation on the monitored host.
- Check whether a configuration or certificate change occurred.

### Stop/escalate

Escalate to the system engineer and platform owner if the monitoring process is running but telemetry is rejected, if network/security changes are suspected, or if recovery requires restart/configuration change.

### Recovery

Telemetry is present continuously for the validated stability window.

## MetrologyFunctionalUnavailable

### Meaning

The functional check cannot demonstrate the intended business operation.

### Evidence package

- Start time and scope.
- Functional signal and last successful transaction.
- Input, completion, error, latency, and backlog trends.
- Required dependency states.
- Recent deployments/configuration/service restarts.
- Top normalized Splunk signatures.
- Recovery attempts and outcomes.

### Technician-safe actions

Only actions explicitly documented in a validated system SOP.

### Engineer-only actions

Architecture diagnosis, code/configuration analysis, database/message/network work, deployment, failover, or ambiguous recovery.

### Recovery

Functional check returns to healthy, successful transactions resume, and backlog/freshness moves toward normal.

## MetrologyDataStale

### Discriminating checks

1. Is input arriving?
2. Is processing completing?
3. Is output delivery succeeding?
4. Is backlog increasing?
5. Is the timestamp source trustworthy?
6. Are only some hosts or flows affected?
7. Did throughput fall because demand stopped rather than processing failed?

### Recovery

Data age returns below the validated clear threshold and remains stable.

## MetrologyBacklogHigh

### Checks

- Compare arrival rate with completion rate.
- Determine oldest-item age; count alone may be misleading.
- Check resource saturation and dependency latency.
- Check whether planned maintenance or demand bursts explain the condition.

### Recovery

Backlog and oldest age decrease continuously and successful throughput remains normal.

## MetrologyDependencyUnavailable

### Checks

- Distinguish dependency failure from local DNS, route, certificate, account, or probe failure.
- Compare other clients of the dependency.
- Check recent changes and platform incidents.
- Preserve connection errors without exporting credentials or endpoints.

### Recovery

Dependency probe and functional transaction both succeed.

## Escalation package

- Alert name and time.
- System/flow/stage aliases.
- Observed production impact.
- Affected/unaffected scope.
- Metrics screenshots or exported values.
- Sanitized normalized signatures.
- Recent changes.
- Checks performed and results.
- Safe actions performed.
- Current recovery state.
