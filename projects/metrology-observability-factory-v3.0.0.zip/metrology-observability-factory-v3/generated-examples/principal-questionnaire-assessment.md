# Principal Technical Questionnaire Assessment

Questionnaire: `metrology-unified-observability-principal-review`
Readiness: **blocked**

## Summary

- Total questions: 55
- Open questions: 23
- Open blockers: 13
- Open high-criticality questions: 8

## Open questions in priority order

| Criticality | ID | Category | Question | Current answer | Owner | Verification |
|---|---|---|---|---|---|---|
| blocker | `OTL-001` | OpenTelemetry distribution and component safety | Is OpenTelemetry approved for this project? | The example platform disables it until corporate approval. | Platform owner | Approved distribution and version |
| blocker | `OTL-002` | OpenTelemetry distribution and component safety | Which distribution and component manifest are approved? | Corporate distribution, version, receivers, processors, exporters, and extensions required. | Platform owner | Run the approved Collector validation command |
| blocker | `OWN-001` | Ownership, support, and governance | Who owns the central standard and compiler? | A pattern owner and named backup are required; names are not supplied. | Manager | Record primary and backup in the corporate project charter |
| blocker | `PRO-001` | Prometheus capability and operating contract | Which Prometheus distribution and version are supported? | Corporate platform evidence required. | Prometheus platform owner | Supported version and validation command |
| blocker | `PRO-002` | Prometheus capability and operating contract | How are targets discovered and configured? | Corporate service-discovery and repository workflow required. | Prometheus platform owner | Approved example configuration and repository path |
| blocker | `PRO-003` | Prometheus capability and operating contract | How are rules validated? | Use the corporate-supported promtool or wrapper; exact command remains unknown. | Prometheus platform owner | Execute syntax and rule-unit tests with approved binary |
| blocker | `PRO-005` | Prometheus capability and operating contract | Who owns Alertmanager routing, inhibition, silences, and maintenance windows? | Corporate routing ownership and policy required. | Prometheus/on-call owner | Approved route and maintenance workflow |
| blocker | `SPL-001` | Splunk ingestion, normalization, and investigation | Which Splunk product, version, and topology are supported? | Corporate platform evidence required. | Splunk platform owner | Supported product/version/topology record |
| blocker | `SPL-002` | Splunk ingestion, normalization, and investigation | Which ingestion modes are approved? | Universal forwarder, HEC, OTel, or another mode must be selected internally. | Splunk platform owner | Approved source onboarding example |
| blocker | `SPL-003` | Splunk ingestion, normalization, and investigation | Which indexes, sourcetypes, and retention classes apply? | Corporate values required for each data class. | Splunk platform owner and data owner | Approved index/sourcetype/retention mapping |
| blocker | `SEC-001` | Security, privacy, and software supply chain | What corporate data may be transferred through GitHub? | Corporate data-classification and repository-boundary decision required. | Security/data owner | Approved transfer policy |
| blocker | `SEC-002` | Security, privacy, and software supply chain | How are credentials supplied? | Approved environment, file provider, credential store, or vault mechanism required. | Security/platform owner | Least-privilege credential design |
| blocker | `TEL-005` | Telemetry semantics, cardinality, and alert lifecycle | How are alert lifecycle states promoted? | Corporate process required for draft, observation, validated, and production promotion. | Manager and on-call owner | Approved promotion and rollback workflow |
| high | `OTL-003` | OpenTelemetry distribution and component safety | Which deployment modes are permitted? | Agent, gateway, or agent-to-gateway must be selected internally. | Platform owner | Architecture and failure-mode review |
| high | `OWN-003` | Ownership, support, and governance | Who approves exceptions to the standard? | Corporate decision required among manager, pattern owner, platform owner, and security. | Manager | Approved exception workflow and expiry policy |
| high | `PRO-004` | Prometheus capability and operating contract | What is the series budget per system? | The example platform uses 10,000 series per system; corporate limit is unverified. | Prometheus platform owner | Cardinality/load measurement |
| high | `PRO-006` | Prometheus capability and operating contract | Which dashboard backend and import format are approved? | Corporate dashboard technology is not supplied. | Prometheus platform owner | Approved dashboard example and deployment method |
| high | `SPL-004` | Splunk ingestion, normalization, and investigation | Is CIM required, preferred, or not used? | Preferred where applicable, with metrology domain extensions. | Splunk platform owner | Review CIM mapping against corporate practice |
| high | `SPL-005` | Splunk ingestion, normalization, and investigation | How are search cost and ingestion volume approved? | Corporate cost guardrails and validation tooling are required. | Splunk platform owner | Measured ingestion volume and search execution cost |
| high | `TEL-006` | Telemetry semantics, cardinality, and alert lifecycle | How are failover and multiple instances represented? | Stable system/service identity plus bounded instance identity. | System owner | Failover and duplicate-series test |
| high | `VAL-004` | Validation, reliability, adoption, and lifecycle | How are Splunk searches and dashboards validated? | Corporate search/parser/dashboard validation and cost tooling required. | Splunk platform owner | Execution evidence and cost approval |
| medium | `OWN-005` | Ownership, support, and governance | What review cadence governs production packages? | Monthly during pilot and rollout, quarterly after stabilization. | Manager | Approve operating cadence |
| medium | `VAL-007` | Validation, reliability, adoption, and lifecycle | How are packages reviewed and retired? | Monthly during pilot, quarterly after stabilization, and on material change/incident; retire unused or ownerless telemetry. | Manager and pattern owner | Approve lifecycle cadence |

## Established decisions and boundaries

| Status | ID | Decision/fact | Code consequence |
|---|---|---|---|
| decision | `PRD-001` | No. Company Prometheus and Splunk remain the operator-facing backends. | Factory emits integration artifacts and never operates a third backend. |
| decision | `PRD-002` | A compiler, standards library, onboarding factory, safe evidence tools, and operating controls. | CLI has compile/assess/generate functions and no live platform mutation APIs. |
| decision | `PRD-003` | No. Corporate humans review, transfer, approve, and execute through accepted tooling. | No deployment client, remote executor, database write, restart, failover, or account mutation. |
| deferred | `PRD-004` | No. Detection, evidence, diagnosis support, and recovery verification precede any separate remediation project. | Probe runtime is read-only and generation contains no remediation actions. |
| decision | `PRD-005` | A second heterogeneous system must compile and validate without a new architecture. | Rollout documentation and assessment report require the reuse gate. |
| decision | `OWN-002` | The existing system owner, with backup coverage. | System profile ownership fields are mandatory. |
| decision | `OWN-004` | Only validated SOP-level collection and response with prerequisites, expected results, stop conditions, and escalation. | Generated runbooks separate technician-safe and engineer-only actions. |
| decision | `PRO-007` | Missing telemetry is a monitoring blind spot, not proof of production failure. | Separate missing/stale telemetry alerts are generated. |
| fact | `SPL-006` | Raw logs remain inside the corporate environment. | External handoff accepts only structured pseudonymized summaries. |
| decision | `OTL-004` | Use current telemetry readers, loopback bindings, memory limiting, batching, and self-health when components are approved. | Generated reference avoids deprecated internal metric address syntax. |
| decision | `OTL-005` | Not without an explicit deduplication and cost decision. | Architecture documents prohibit duplicate ingestion by default. |
| decision | `TEL-001` | Host, functional, traffic, errors, latency, saturation, freshness, backlog, dependencies, change identity, and telemetry path as applicable. | Compiler produces capability coverage and gap diagnostics. |
| decision | `TEL-002` | No. Functional health must demonstrate intended business behavior. | Functional signals and alerts are separate from process state. |
| decision | `TEL-003` | In approved Splunk events, not Prometheus labels. | Compiler rejects known unbounded label names and declared budget violations. |
| decision | `TEL-004` | No. Production alerts require validation state and evidence. | Candidate and production rule files are separated. |
| decision | `TEL-007` | Source reconciliation, controlled failure, fire/clear, recovery, and operator acceptance evidence. | Signal validation status is explicit and unvalidated required signals generate warnings. |
| decision | `RUN-001` | No. It generates reviewed command plans; execution is local/manual. | No SSH, WinRM, remote shell, or orchestration client is included. |
| decision | `RUN-002` | Normal user; elevation requires a separate evidence-based approval. | Discovery records privilege and does not self-elevate. |
| decision | `RUN-003` | Approved roots, no symlinks, optional same-filesystem restriction, item/read/time limits. | Probe plan schema and supervisor enforce limits. |
| decision | `RUN-004` | Exact approved target aliases/hosts/ports plus CIDR/address policy and explicit enablement. | Supervisor rejects undeclared, loopback, link-local, or disallowed resolved addresses. |
| decision | `RUN-005` | Separate child process, hard deadline, supervisor budget, and termination. | A hung worker cannot hold the complete probe cycle indefinitely. |
| decision | `RUN-006` | Bounded local read, literal or constrained safe regex, count-only output. | Backreferences, advanced groups, and nested quantifiers are rejected. |
| decision | `RUN-007` | Each cycle publishes last-run time and a stale-probe alert. | Probe timestamp is distinct from success state. |
| decision | `RUN-008` | Engineer-only manifest, query hash, approved read-only account assertion, scalar bound, timeout, rollback. | Static SQL checks are defense in depth and cannot prove safety. |
| decision | `SEC-003` | Deterministic archive, hashes, repository manifest, source/input hashes, CI, and code review. | Generator and package builder produce provenance and stable ordering. |
| decision | `SEC-004` | No. It is a screening aid; human and corporate approval remain mandatory. | Approval is false by default and local alias maps are separated. |
| decision | `SEC-005` | Use approved internal indexes or an approved wheelhouse with exact corporate pins. | Bootstrap supports no-index wheelhouse mode. |
| decision | `VAL-001` | Schemas, compiler invariants, ownership, capability compatibility, metric/cardinality, and probe-plan validation. | Strict compilation fails closed on errors. |
| decision | `VAL-002` | Platform syntax, rule tests, controlled fire/clear, resource/volume, security, operator, and rollback evidence. | Generated packages remain review-ready and production rules are isolated. |
| decision | `VAL-003` | Authoritative syntax validation plus generated promtool rule-unit tests. | Rule-test artifacts accompany rule files. |
| decision | `VAL-005` | Production processing continues; observability loss is a separate blind-spot incident. | The architecture has no production control dependency on observability. |
| decision | `VAL-006` | Baseline versus pilot detection, evidence, isolation, recovery, false positives, effort, adoption, and support burden. | ROI tooling accepts internal assumptions without inventing values. |
