# OpenTelemetry Not Enabled

The system profile did not enable OpenTelemetry generation. Company Prometheus/Splunk integrations remain the active design path.
