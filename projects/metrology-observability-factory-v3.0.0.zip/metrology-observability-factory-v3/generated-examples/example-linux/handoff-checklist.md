# Corporate Handoff Checklist — Example Linux Processing Service

- [ ] Raw logs remain intranet-only.
- [ ] No credentials, tokens, keys, connection strings, certificates, or private keys are included.
- [ ] Internal hostnames, addresses, paths, account names, database names, equipment identifiers, lot/wafer/recipe identifiers, and personal identifiers are removed or approved.
- [ ] Services/processes are aliased where external identity is unnecessary.
- [ ] Normalized log templates contain placeholders rather than raw values.
- [ ] Root cause is not marked confirmed without causal evidence and human review.
- [ ] Automated screening completed with no blocking findings.
- [ ] Human reviewer inspected every file.
- [ ] Company policy permits the selected GitHub transfer path.
- [ ] Approval fields remain false until the corporate reviewer records approval in the approved system of record.
