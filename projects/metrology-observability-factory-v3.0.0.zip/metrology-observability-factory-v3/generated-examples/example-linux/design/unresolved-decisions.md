# Unresolved Decisions

These values were not invented by the generator and must be resolved in the corporate environment.

- `organization.site`
- `prometheus.version`
- `prometheus.dashboard_backend`
- `splunk.version`
- `splunk.default_index`
