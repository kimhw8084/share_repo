# Observability Coverage Report

System: `example-linux-service`

| Capability | Status | Candidate signals |
|---|---|---|
| Host health | not-defined | — |
| Functional availability | candidate | functional-up |
| Traffic/throughput | candidate | transaction-count |
| Errors | candidate | transaction-count |
| Latency | not-defined | — |
| Saturation | not-defined | — |
| Data freshness | candidate | freshness |
| Backlog | candidate | backlog |
| Dependencies | candidate | dependency |
| Version/configuration identity | not-defined | — |
| Telemetry path | covered | probe-health |

Statuses are design-time classifications. `candidate` requires corporate validation; `covered` is only used when the profile explicitly marks validation complete.
