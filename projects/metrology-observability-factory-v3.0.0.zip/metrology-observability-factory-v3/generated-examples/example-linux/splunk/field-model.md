# Splunk Field Model — Example Linux Processing Service

Status: REFERENCE  
Raw logs remain in the corporate environment.

## Common fields

| Field | Purpose | Cardinality expectation | Notes |
|---|---|---|---|
| `metrology_system` | Stable system identity | Low | `example-linux-service` |
| `deployment_environment` | Environment | Low | `test` |
| `component` | Service/component identity | Bounded | Controlled vocabulary |
| `flow` | Data-flow identity | Bounded | Controlled vocabulary |
| `stage` | Processing stage | Bounded | Controlled vocabulary |
| `outcome` | success/error/retry/rejected | Low | Normalize values |
| `severity` | Normalized severity | Low | Preserve original separately if needed |
| `event_type` | Operational event category | Bounded | Examples: transaction, dependency, change |
| `normalized_signature` | Redacted recurring pattern | Bounded | Never raw exception text |
| `correlation_id` | Detailed investigation linkage | High | Splunk only; never a Prometheus label |
| `duration_seconds` | Operation duration | Numeric | Standard unit |
| `version` | Active software version | Bounded | Review retention/cardinality |
| `config_id` | Approved configuration identity | Bounded | Hash/version, not secrets |
| `change_reference` | Change ticket or deployment reference | Bounded | Company policy applies |

## Source inventory

### application-log

- Source type: file
- Source reference: REPLACE_INSIDE_CORPORATE
- Format: unknown
- Timestamp field: TBD
- Correlation fields: TBD
- Sensitive data: TBD
- Raw external export: prohibited
- Candidate sourcetype: TBD


## Required parsing tests

- Timestamp is correct across daylight-saving transitions and server timezone differences.
- Multiline events are bounded correctly.
- Truncated and malformed records do not merge unrelated events.
- Encoding is validated.
- Sensitive values are masked at the approved point.
- Event volume and license impact are measured.
- Field extractions remain stable across versions.
- Correlation fields do not become Prometheus labels.
