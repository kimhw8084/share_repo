# Acceptance Test Plan — Example Linux Processing Service

Status: DRAFT  
Production testing requires approved change control.

## Static validation

- Profile validates against schema.
- Metric names and labels pass cardinality policy.
- Prometheus files pass `promtool check rules` and approved configuration checks.
- OpenTelemetry reference passes the approved Collector's configuration validation.
- Splunk searches parse and execute within approved cost limits.
- Dashboard specification resolves all data sources and links.
- Package security scan has no blocking finding.
- No credentials or raw logs exist in the repository.

## Functional tests

| Test | Stimulus | Expected evidence | Recovery |
|---|---|---|---|
| Telemetry loss | Stop or isolate a non-production collector through approved procedure | Telemetry-missing alert after persistence window | Telemetry resumes and alert clears |
| Functional failure | Controlled non-production failure or replayed evidence | Functional alert and useful context | Functional signal and transactions recover |
| Data stale | Pause/replay test flow | Freshness signal ages and alert fires | Age drops after processing resumes |
| Backlog | Controlled test input accumulation | Backlog and oldest-age indicators rise | Backlog drains and alert clears |
| Dependency failure | Approved test endpoint unavailable | Dependency alert, correlated functional evidence | Dependency and functional check recover |
| Log signature | Inject approved synthetic test event | Splunk signature and dashboard link work | Test event remains identifiable as synthetic |

## Negative tests

- No alert during planned idle window if idle behavior is expected.
- No duplicate pages for one dependency failure.
- No metric label receives filename, transaction, user, equipment, lot, wafer, or recipe values.
- Missing timestamp or clock skew produces an explicit quality warning.
- Probe failure is distinguishable from production functional failure.
- Large directories hit scan limits without resource exhaustion.
- Malformed logs do not break parsing or merge events incorrectly.
- Partial network loss does not cause unbounded retry or queue growth.
- Collector restart does not silently lose configuration identity.
- High-volume bursts stay within measured Splunk and Collector capacity.

## Operator acceptance

- Engineer can isolate the failing layer faster than the baseline workflow.
- Technician can understand alert meaning and gather the required package.
- First safe check, stop condition, escalation, and recovery are unambiguous.
- System owner accepts sustainment and review responsibilities.
