# Fleet Coverage

| System | Criticality | Owner | Functional | Freshness | Dependencies | Telemetry |
|---|---|---|---|---|---|---|
| `example-linux-service` | TBD | metrology-software | candidate | candidate | candidate | covered |
| `example-windows-file-pipeline` | TBD | metrology-software | candidate | candidate | candidate | covered |
