# Contribution Rules

1. Begin with an approved issue or decision.
2. Preserve the data boundary and disconnected-system truth.
3. Add or update schemas before adding unstructured fields.
4. Add tests for every generator, sanitizer, probe, or rule change.
5. Do not add raw logs, internal endpoints, credentials, production identifiers, or unrestricted command output.
6. Keep Prometheus labels bounded.
7. Keep system-specific exceptions inside profiles or approved adapters.
8. Update runbooks, deployment, rollback, and ownership when operational behavior changes.
9. Require human review before production use.
10. Record consequential architecture decisions in `planning/decision-log.csv`.
