# Changelog

## 3.0.0 — 2026-08-03

### Campaign control plane

- Added approved campaign policy and 205-question evidence ledger.
- Added campaign init, advance, ingest, status, finalize, runner build, runner
  approval, and AI-job generation.
- Added gate-specific completeness, evidence freshness, conflicts, and targeted
  reruns.

### Execution

- Added self-contained local Windows/Linux runner bundles.
- Added exact manifest-hash runner approval.
- Added read-only environment and Prometheus/Splunk/OTel capability collection.
- Added corporate-local AI chunking and deterministic merge.

### External handoff

- Added automatic profile drafting.
- Added stable system/host/platform/owner/component pseudonyms.
- Added recursive identity replacement and structured sanitization.
- Added external security screen and return-bundle manifest.

### Validation

- Added campaign, runner-authorization, AI-adapter, conflict, stable-alias,
  sanitization, and return-bundle tests.

## 2.0.0 — 2026-07-31

Fail-closed compiler, transactional generators, runtime probes, and principal
architecture review.

## 1.0.0 — 2026-07-31

Initial implementation foundation.
