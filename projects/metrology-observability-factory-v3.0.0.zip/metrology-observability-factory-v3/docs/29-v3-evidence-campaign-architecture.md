# V3 Evidence Campaign Architecture

Status: APPROVED DESIGN  
Version: 3.0.0

## Why the campaign layer exists

The v2 compiler could generate strong artifacts once correct profiles existed,
but collecting the facts required to build those profiles still required
manual interpretation. V3 makes evidence acquisition a first-class system.

## Control plane

```text
approved decisions
  + inventory snapshot
  + evidence requirements
        ↓
campaign compiler
        ↓
forms + local-run manifests + AI jobs
        ↓
validated evidence envelopes
        ↓
evidence ledger and conflicts
        ↓
gate-specific completeness and targeted reruns
        ↓
draft platform/system profiles
        ↓
sanitized external return bundle
```

## Evidence statuses

Every collector outcome is explicit:

- success;
- partial;
- denied;
- unsupported;
- timeout;
- failed.

A partial or failed collector does not erase successful evidence from the same
host. The campaign continues and emits a narrow rerun action.

## Evidence subjects

Evidence is addressed to one of:

- campaign;
- platform target;
- system;
- host.

This prevents global facts from being incorrectly applied to every system.

## Provenance

Every evidence envelope records:

- campaign and run ID;
- evidence ID and type;
- subject;
- collector and version;
- start/completion time;
- privilege;
- status/error code;
- classification;
- source hash;
- raw-log/raw-config exclusion;
- human-review requirement.

## Gate model

Completeness is calculated separately for:

- design;
- pilot;
- production;
- scale.

There is no single percentage that could hide a production blocker behind
large quantities of low-value evidence.

## Conflict model

The same evidence ID with a different canonical hash becomes a conflict. Both
versions are preserved. The system does not silently overwrite or reconcile
them.

## Local runner authorization

Runner approval contains the exact host-run manifest SHA-256. The local runner
recalculates the hash and refuses execution when:

- approval is missing;
- host/campaign identity differs;
- the manifest changed;
- reviewer role/reference is absent;
- production changes are marked approved.

## AI boundary

Raw logs, chunks, prompts, and model outputs remain local. The campaign accepts
only schema-valid normalized feature evidence with root-cause confirmation
disabled and human review still required.
