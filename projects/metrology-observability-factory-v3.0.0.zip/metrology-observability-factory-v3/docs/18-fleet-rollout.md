# Fleet Rollout Strategy

## Inventory

Maintain one row per system/host group with:

- system ID;
- business function;
- owner/backup;
- OS/deployment model;
- criticality/support tier;
- current Prometheus/Splunk coverage;
- data flows/dependencies;
- discovery/profile/package status;
- exception;
- next action;
- completion evidence.

## Prioritization

1. Silent production/data-flow risk.
2. Repeated engineer support.
3. High manual evidence effort.
4. High-impact change/configuration risk.
5. Technician shift-left potential.
6. Shared architecture reuse.
7. Strategic advanced analytics prerequisites.

## Batch design

Onboard similar systems together, then validate one different system before declaring a template universal.

## Coverage states

- not inventoried;
- discovered;
- profiled;
- generated;
- validated non-production;
- observation mode;
- production alerts;
- sustained;
- exception;
- retired.

## Exception handling

Every exception states why the standard cannot apply, alternative controls, owner, expiration/review date, and convergence or retirement plan.
