# Technician SOP Candidate — Read-Only Discovery

Status: DRAFT; technician-safe only after corporate validation

## Purpose

Produce a bounded discovery package for an approved server.

## Preconditions

- Approved server/system ID.
- Approved script version/hash.
- Approved output location.
- Normal user access unless elevation is separately approved.
- No active production instability unless incident owner authorizes collection.
- Sufficient disk space.
- Owner and escalation contact available.

## Warnings

Stop if CPU/I/O impact becomes material, command hangs, security tooling flags activity, sensitive content appears, output grows unexpectedly, or elevation is requested unexpectedly.

## Steps

1. Confirm script hash and parameters.
2. Start with no approved paths and no event/task options.
3. Run the OS-specific command.
4. Record elapsed time and warnings.
5. Inspect JSON for raw text, addresses, accounts, credentials, or internal identifiers.
6. Validate schema.
7. Escalate warnings or unexpected content.
8. Store output in the approved corporate location.
9. Do not transfer externally until handoff screening and human approval.

## Stop conditions

Any material production impact, unexpected sensitive output, uncontrolled traversal, unapproved privilege, failed lock/mutex, or uncertain output destination.

## Escalation package

Script version/hash, server alias, time, parameters, output size, warnings/errors, observed impact, and whether any files left the corporate environment.

## Completion evidence

Schema-valid discovery, no raw content, reviewed output, and recorded owner approval.
