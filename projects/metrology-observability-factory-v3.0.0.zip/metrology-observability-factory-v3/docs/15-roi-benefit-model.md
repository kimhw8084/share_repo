# ROI and Benefit Model

Status: INPUT MODEL — internal data required

## Narrow benefit model

### Labor savings

Incident frequency × responders × evidence/diagnosis time saved × loaded labor value.

### Error avoidance

Expected preventable incidents × expected impact per incident × preventable fraction.

### Capacity value

Recovered engineering hours × probability recovered time produces useful project/support value.

### Adoption adjustment

Gross benefit × actual usage/adoption rate.

### Net first-year value

Adoption-adjusted labor/capacity benefit + avoided loss − build − platform − support − training/change cost.

## Baseline measures

- monthly incident count by family/system;
- detection source;
- time to detection;
- time to useful evidence;
- time to isolate layer;
- time to recovery;
- engineering/technician hours;
- repeated manual checks;
- missed/silent data-flow events;
- alert false positives;
- current platform/ingestion cost.

## Pilot measures

Same measures for the selected workflow, plus onboarding effort, resource overhead, ingestion volume, operator acceptance, and support burden.

## Decision sensitivity

High-weight unknowns are incident manufacturing impact, incident frequency, actual time saved, and adoption. Use low/base/high cases; do not claim measured ROI before evidence exists.

## Scale gate

Scale when the second-system result shows positive expected net value, acceptable operational risk, reusable implementation, and sustainable ownership.
