# Alert, Dashboard, and Troubleshooting Standard

## Alert design

Every actionable alert includes:

- production symptom;
- affected system/flow/stage;
- persistence window;
- impact hypothesis;
- evidence link;
- first safe check;
- runbook;
- escalation;
- recovery condition;
- owner.

Alert on symptoms that require action. Use dashboards and logs to isolate cause.

## Severity

- **Info:** record/observe; no immediate action.
- **Warning:** degradation or risk requiring scheduled/near-term response.
- **High:** likely production-function impact requiring prompt engineering response.
- **Critical:** confirmed or highly credible broad manufacturing impact with an approved paging policy.

Severity requires corporate routing alignment.

## Dashboard views

1. **Fleet:** functional state, freshness, errors, backlog, dependencies, alerts, telemetry, owner.
2. **System:** fixed layout across all systems.
3. **Troubleshooting workbench:** alert-context time window, affected/unaffected comparison, metrics, Splunk signatures, recent changes, dependencies, recovery.
4. **Coverage:** onboarding, missing signals, stale telemetry, runbooks, owner/backup, exceptions.

## Troubleshooting sequence

Impact/containment → observed facts → recent changes → ranked hypotheses → discriminating checks → recovery → confirmation → corrective/preventive action → knowledge update.

## Root-cause control

Temporary recovery, correlation, or plausible narrative does not confirm cause. Confirm only when evidence demonstrates the causal mechanism and explains scope/timing.
