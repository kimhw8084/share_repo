# Sanitized Return Bundle Contract

## Included

- pseudonymized fleet inventory;
- draft platform profile;
- draft system profiles;
- normalized evidence summary;
- 205-question evidence-status ledger;
- gate completeness;
- conflicts;
- blocking gaps;
- targeted rerun plan;
- profile validation;
- external security-screen result;
- SHA-256 file manifest.

## Excluded

- raw logs;
- raw configurations;
- credentials/tokens/keys;
- exact endpoints;
- internal host/system/owner IDs;
- pseudonymization salt and alias map;
- production approval;
- production validation claims;
- deployment or remediation actions.

## Stable aliases

Aliases use a corporate-local persistent salt. Repeated finalization produces
stable aliases. The salt and reverse map never enter the ZIP.

## Transfer gate

The bundle is screened for denied file types and secret-shaped content. Human
file-by-file review and corporate transfer approval remain mandatory.
