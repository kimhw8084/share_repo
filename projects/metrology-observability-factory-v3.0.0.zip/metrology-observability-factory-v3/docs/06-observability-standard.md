# Metrology Observability Standard

Status: REVIEW-READY

## Required layers

### Host

CPU, memory, disk/filesystem, network, time service, critical services/processes, boot/restart context, telemetry-agent health.

### Functional service

A check that demonstrates intended system function, not merely process state.

### Traffic

Accepted, completed, rejected, retried, and failed work rates.

### Errors

Normalized categories, not unbounded raw messages.

### Latency

Meaningful operation or stage duration in seconds.

### Saturation

Queue, pool, thread, connection, memory, disk, or other constrained resource.

### Freshness

Time since last successful meaningful event.

### Backlog

Count and oldest-item age where applicable.

### Dependencies

Required database, file, messaging, API, equipment, DNS/time/certificate, and shared platform state.

### Change identity

Software version, configuration identity, deployment/change reference, restart events.

### Telemetry path

Exporter/Collector/probe health, scrape/ingestion success, queue/drop/error state.

## Standard metric family

Custom probes should converge on these names:

- `metrology_probe_success`
- `metrology_probe_duration_seconds`
- `metrology_probe_last_run_unixtime_seconds`
- `metrology_functional_up`
- `metrology_transactions_total`
- `metrology_operation_duration_seconds`
- `metrology_last_success_unixtime_seconds`
- `metrology_backlog_items`
- `metrology_dependency_up`
- `metrology_build_info`
- `metrology_file_count`
- `metrology_oldest_file_age_seconds`
- `metrology_newest_file_age_seconds`
- `metrology_tls_certificate_expiry_seconds`
- `metrology_log_signature_matches_total`

## Required resource attributes

- `service.namespace`
- `service.name`
- `deployment.environment.name`
- `metrology.system`
- `metrology.owner_team`
- `metrology.criticality`
- `metrology.support_tier`

## Cardinality policy

Never use default Prometheus labels containing:

- lot, wafer, recipe, equipment;
- transaction, GUID, timestamp;
- filename or path;
- user/account;
- raw error or stack trace.

Use bounded aliases and controlled vocabularies. Keep detailed IDs in Splunk.

## Threshold policy

No production paging threshold is “standard” across systems. Candidate thresholds must be validated against normal behavior, maintenance/idle periods, bursts, clock behavior, and real or controlled failure evidence.

## Missing-data behavior

Absence of telemetry is a monitoring blind spot, not proof that production failed. Separate telemetry-missing alerts from functional-failure alerts.
