# Offline or Controlled-Repository Installation

## Dependencies

Runtime:

- Python 3.9 or later.
- Jinja2.
- PyYAML.
- jsonschema.

Development/testing:

- pytest.
- ruff, optional for linting.

Database probes additionally require an approved corporate `pyodbc` or `oracledb` installation and are not part of the default runtime dependency.

## Approved internal package repository

Configure `pip` according to company policy, then run the bootstrap script.

## Wheelhouse

Prepare approved wheels inside the corporate environment, including transitive dependencies. Set:

Linux:

```bash
export WHEELHOUSE=/approved/path/to/wheels
sh scripts/common/bootstrap.sh
```

Windows:

```powershell
$env:WHEELHOUSE = "C:\approved\wheels"
.\scripts\common\Bootstrap.ps1
```

The bootstrap uses `--no-index`, `--find-links`, and `--no-build-isolation` when a wheelhouse is supplied.

## No-install validation

Where dependencies already exist, the source can be tested without installation:

Linux:

```bash
export PYTHONPATH="$PWD/src"
python -m pytest
python -m obsfactory validate profile profiles/example-linux-service.yml
```

PowerShell:

```powershell
$env:PYTHONPATH = "$PWD\src"
python -m pytest
python -m obsfactory validate profile profiles\example-windows-file-pipeline.yml
```

## Version control

Corporate-supported versions override the planning ranges in `pyproject.toml`. Test and record the exact approved dependency set before production use.
