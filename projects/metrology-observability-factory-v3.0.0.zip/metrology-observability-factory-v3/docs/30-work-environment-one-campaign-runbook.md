# Work-Environment One-Campaign Runbook

Status: CORPORATE EXECUTION GUIDE  
Audience: manager, pattern owner, system owners, platform owners, technicians

## Desired result

One corporate execution cycle produces a sanitized return bundle containing
enough evidence to perform the last external architecture/code refinement
without another exploratory questionnaire cycle.

## Preconditions

- Repository imported through the approved path.
- Archive/repository hash verified.
- Python dependencies installed from approved sources.
- Pattern owner and backup named.
- Inventory snapshot available.
- Selected Windows and Linux pilot systems.
- Prometheus and Splunk owners identified.
- No active production incident that would make discovery unsafe.

## Stage 1 — Repository validation

```bash
python -m pytest
python scripts/common/release_validate.py \
  --output output/release-validation.json
```

Use Windows CI or `Validate-PowerShellSyntax.ps1` for PowerShell parsing.

## Stage 2 — Inventory

Fill `inventory/campaign-inventory-template.csv`.

Do not infer:

- production environment from hostname;
- criticality from resource utilization;
- ownership from service account;
- functional health from process state.

## Stage 3 — Initialize

Run the README `campaign init` command. Confirm design completeness is 100%.

## Stage 4 — Complete forms

### System owner

Define:

- business capability;
- functional success;
- required services;
- required/optional dependencies;
- input-to-output stages;
- normal idle and burst behavior;
- recovery confirmation;
- approved log sources;
- safe non-production test path;
- technician and engineer boundaries.

### Platform owner

Define:

- supported product/version;
- validation command;
- repository/deployment workflow;
- credential delivery mechanism;
- approved configuration paths;
- routing/retention/cost limits;
- rollback method.

Exact credentials, endpoints, and raw configs do not belong in forms.

## Stage 5 — First advance

`campaign advance` ingests completed forms and generates host bundles and AI
jobs. Review `state/last-advance.json`.

## Stage 6 — Runner review and approval

Review every host manifest for:

- correct host alias;
- system mapping;
- approved paths;
- collectors;
- normal privilege;
- limits;
- platform targets.

Approve through the generated CSV. This is approval for read-only evidence
collection only.

## Stage 7 — Local execution

Run each bundle on its intended host. Stop and escalate when:

- production resource impact is material;
- security tooling reports unexpected behavior;
- an unapproved path or privilege is requested;
- output contains unexpected raw/sensitive content;
- a filesystem/provider call blocks;
- the host identity is uncertain.

Copy only evidence envelopes back to the campaign.

## Stage 8 — Evidence ingest and targeted reruns

Run `campaign advance`. Execute only actions listed in the targeted rerun plan.
Do not repeat the whole campaign unless the campaign manifest itself changed.

## Stage 9 — Corporate-local AI

Review approved log sources and coverage windows. Run the local AI adapter.
Review normalized output samples. Copy only `*.evidence.json` into
`campaign/ai-results/`.

## Stage 10 — Return readiness

Run:

```bash
obsfactory campaign status campaign \
  --output campaign/state/final-status.json
```

Return readiness target:

- design 100%;
- pilot 100%;
- conflicts 0;
- AI summaries reviewed;
- profile validation empty;
- external security screen blocking count 0.

## Stage 11 — Finalize

Create the sanitized ZIP. Review every file internally before transfer.
Approval inside the bundle remains false.

## Stage 12 — After final external refinement

The corporate team still performs:

- authoritative Prometheus/Splunk/OTel validation;
- non-production failure/recovery tests;
- resource and ingestion measurements;
- change approval;
- deployment and rollback;
- alert observation;
- operator acceptance;
- production promotion;
- benefit realization.

## Completion evidence

The campaign is successful when the second heterogeneous system uses the same
compiler and operating pattern with only profile/evidence differences, and the
new workflow materially reduces evidence or isolation effort without
unsustainable support burden.
