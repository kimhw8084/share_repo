# Prometheus, Splunk, and OpenTelemetry Integration

Status: REFERENCE — corporate owner decisions required

## Prometheus responsibility

- host/service/data-flow/dependency metrics;
- recording rules;
- symptom alerts;
- fleet/system visual state;
- bounded operational labels.

## Splunk responsibility

- raw logs inside the corporate environment;
- parsing and normalized fields;
- detailed signatures;
- change/audit context;
- correlation identifiers;
- evidence-window searches.

## OpenTelemetry responsibility

Optional collection/enrichment/routing where it reduces duplication. Default reference uses host metrics, memory limiting, resource enrichment, batching, a local Prometheus exporter endpoint, and Collector self-health.

## Avoid duplicate ingestion

Do not collect the same logs through both existing Splunk forwarders and a new OTel pipeline without an explicit design decision, cost model, and deduplication plan.

## Platform questions

- What Prometheus distribution/version and config validation process are approved?
- Is service discovery preferred over static targets?
- What exporter/Collector agents are already deployed?
- Which dashboards are approved?
- How are rules, alerts, ownership, and silences managed?
- Which Splunk indexes/sourcetypes and field-extraction methods are approved?
- What ingestion/licensing constraints apply?
- Which OTel distribution/components/modes are approved?
- How are secrets delivered?
- Which network listeners/endpoints are permitted?
