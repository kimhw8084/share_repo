# Security and Data Handling — v2

## Data zones

- **Zone A — corporate raw:** logs, configurations, endpoints, identifiers, incident evidence.
- **Zone B — corporate structured:** discovery metadata, normalized signatures, aggregate counts, telemetry candidates.
- **Zone C — approved external handoff:** pseudonymized allowlisted structured summaries only.

## Platform profile is the policy boundary

The organization profile declares:

- whether external handoff is allowed;
- approved credential sources;
- allowed network probe targets and CIDRs;
- address-class policy;
- data classifications;
- backend and collector capabilities.

The example profile denies external handoff, network probes, and OpenTelemetry.

## Discovery controls

- local/manual execution only;
- normal privilege first;
- metadata only;
- no raw logs/configuration content;
- explicit approved roots;
- no symlink/reparse traversal;
- Linux same-filesystem default;
- item and cooperative elapsed limits;
- atomic output;
- Linux file-mode policy and Windows inherited ACL warning;
- process/mutex exclusion.

A cooperative deadline cannot interrupt a blocked kernel/provider call. Remote or unhealthy mounts require separate corporate process supervision.

## Probe controls

- typed schema and semantic validation before workers start;
- no shell execution;
- no service restart, configuration mutation, deployment, or automatic recovery;
- spawned worker process per probe;
- hard per-probe and total-cycle deadlines;
- exact allowlisted target and CIDR policy;
- DNS-pinned connections;
- no redirects;
- mandatory TLS certificate verification;
- approved filesystem roots and no symlinks;
- bounded reads and safe-regex restrictions;
- code-only error output;
- locked atomic textfile publication with explicit permissions;
- stale-lock recovery only when the recorded process is dead.

## Database probe controls

- separate engineer-only workflow;
- exact approved manifest and query hash;
- manifest/query confinement and symlink rejection;
- database-owner-approved read-only account assertion;
- driver-level read-only hints plus rollback;
- one finite scalar row;
- expected range;
- timeout;
- no endpoint, query, or credential in reports.

These controls do not prove a SQL query harmless or inexpensive. Database permissions, query-plan review, resource testing, and approval remain authoritative.

## Handoff controls

- platform permission or explicit human approval acknowledgement;
- discovery/log-feature system ID consistency;
- persistent local pseudonymization salt option;
- paths and identities aggregated or aliased;
- secret/JWT/credential-URL scanning;
- local alias map isolated;
- output transactionality;
- human approval remains false.

Automated sanitization cannot guarantee confidentiality.

## Supply-chain controls

- installed schema resources;
- deterministic archive timestamps/order/permissions;
- input and output hashes;
- package manifest;
- source scan;
- CI;
- corporate dependency repository or wheelhouse.

## Human approval

Required for broad fleet discovery, privileged collection, new agents/listeners, network/account/certificate changes, production routing, database probes, high-volume Splunk ingestion, failover, or any remediation.
