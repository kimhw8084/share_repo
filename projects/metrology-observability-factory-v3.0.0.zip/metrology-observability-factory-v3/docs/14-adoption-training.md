# Adoption and Training Plan

## Users

- System engineers.
- Pattern/platform engineers.
- Technicians.
- Manager.
- Prometheus/Splunk operators.

## Desired behavior

- Start incidents from the standard fleet/system view.
- Preserve evidence before destructive recovery.
- Use standard escalation packages.
- Add monitoring and runbook changes to incident corrective actions.
- Onboard systems through profiles and generation, not one-off dashboards.

## Adoption barriers

- existing personal dashboards/scripts;
- unclear ownership;
- alert fatigue;
- fear of exposing system weaknesses;
- profile/data-entry burden;
- poor Splunk links;
- platform access delays;
- low trust in generated files.

## Controls

- pilot a real recurring pain;
- fixed dashboard layout;
- demonstrate faster evidence collection;
- generate rather than hand-author;
- preserve system-specific extensions;
- train using controlled failures;
- measure use and retire old paths.

## Competency checks

### Technician

Can interpret severity, collect evidence, follow stop conditions, escalate, and verify recovery without performing engineer-only actions.

### Engineer

Can edit/validate a profile, generate package, interpret metrics/logs, test alerts, distinguish correlation from cause, and update runbooks.

### Pattern owner

Can review cardinality, security, performance, platform compatibility, exceptions, and sustainment.
