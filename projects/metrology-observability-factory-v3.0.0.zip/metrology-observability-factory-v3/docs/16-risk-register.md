# Risk Register

| ID | Risk | Probability | Impact | Control | Trigger/owner |
|---|---|---|---|---|---|
| R-001 | Duplicate company platform capability | Medium | Medium | Platform review before custom build | Pattern owner |
| R-002 | Raw/sensitive data exported | Low/Medium | Critical | Zones, schemas, scanner, human approval | Security |
| R-003 | Discovery/probe production impact | Low | High | Limits, normal privilege, pilot, stop conditions | System owner |
| R-004 | Alert fatigue | High | High | Symptom alerts, persistence, observation mode, tests | System owner |
| R-005 | Prometheus cardinality explosion | Medium | High | Prohibited labels, tests, controlled vocabularies | Pattern owner |
| R-006 | Splunk ingestion/search cost | Medium | High | Measure volume/cost, normalize, avoid duplicates | Splunk owner |
| R-007 | Monitoring reports host up but function failed | High | High | Functional/data-flow checks | System owner |
| R-008 | AI overstates root cause | Medium | High | Schema forces false; causal evidence standard | Engineer |
| R-009 | Custom probes become unsupported products | Medium | Medium/High | Reuse-first, owner/backup, tests, retirement | Pattern owner |
| R-010 | Collector instability/backpressure | Medium | High | Memory limit, self-health, load tests, rollback | Platform owner |
| R-011 | Platform/version mismatch | Medium | Medium | Corporate binary validation | Platform owner |
| R-012 | Single-person knowledge concentration | Medium | High | Backup, reviews, competency evidence | Manager |
| R-013 | Low adoption | Medium | High | Workflow integration, pilot pain, training, retirement | Manager |
| R-014 | Scope explosion | High | Medium | Vertical slice and explicit gates | Manager |
| R-015 | Autonomous remediation causes fab impact | Low | Critical | Out of initial scope; manager approval | Manager |
| R-016 | Internal identifier leaks through metadata | Medium | High | Pseudonymization, aggregation, manual review | Reviewer |
| R-017 | Clock skew corrupts freshness/sequence | Medium | High | Time-service signal and skew tests | System owner |
| R-018 | Monitoring backend outage creates blindness | Medium | High | Telemetry-path alerts and fallback procedure | Platform owner |
| R-019 | Failover creates duplicate/missing telemetry | Medium | High | Instance identity and failover tests | System owner |
| R-020 | Static thresholds do not fit variable demand | Medium | Medium | Baseline, seasonality, oldest-age/ratio measures | System owner |
