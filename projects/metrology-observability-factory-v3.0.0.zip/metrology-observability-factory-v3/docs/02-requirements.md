# Requirements

Status: REVIEW-READY  
Priority convention: MUST, SHOULD, MAY

## Functional requirements

| ID | Requirement | Priority | Completion evidence |
|---|---|---|---|
| FR-001 | Produce a common system profile for every onboarded system | MUST | Schema-valid profile |
| FR-002 | Discover Windows/Linux host facts read-only and without raw logs | MUST | Schema-valid discovery output |
| FR-003 | Represent functional health separately from process/host uptime | MUST | Functional metric and failure test |
| FR-004 | Measure traffic, errors, latency, saturation, freshness, backlog, dependencies, change identity, and telemetry health where applicable | MUST | Coverage report |
| FR-005 | Link Prometheus alerts to Splunk evidence windows and runbooks | MUST | Operator acceptance |
| FR-006 | Generate Prometheus scrape/rule references | MUST | `promtool` validation |
| FR-007 | Generate Splunk field/search references | MUST | Corporate Splunk validation |
| FR-008 | Generate optional OTel reference only when approved | SHOULD | Collector validation |
| FR-009 | Generate dashboards, alerts, runbooks, tests, deployment, and rollback | MUST | Complete package |
| FR-010 | Support intranet AI normalized log-feature extraction | MUST | Schema-valid summary |
| FR-011 | Create sanitized external handoff with human approval false by default | MUST | Handoff schema and review report |
| FR-012 | Compare discovery snapshots | SHOULD | Change report |
| FR-013 | Produce fleet coverage and ownership reporting | SHOULD | Fleet report |
| FR-014 | Support bounded local file/network/log-signature probes | SHOULD | Controlled tests |
| FR-015 | Monitor collector/exporter health | MUST | Telemetry-path signal |
| FR-016 | Support system-specific extensions without breaking the standard | MUST | Exception record and tests |

## Nonfunctional requirements

| ID | Requirement | Target |
|---|---|---|
| NFR-001 | Safety | No write/restart/deploy/remediation behavior in default tools |
| NFR-002 | Privacy | Raw logs and credentials excluded from external handoff |
| NFR-003 | Performance | Discovery and probes bounded by item/time limits |
| NFR-004 | Portability | Windows PowerShell and Linux Python paths |
| NFR-005 | Maintainability | Schema-driven generator and tests |
| NFR-006 | Observability | Collectors/probes expose self-health |
| NFR-007 | Reliability | Atomic Prometheus textfile writes |
| NFR-008 | Cardinality | Bounded metric labels; detailed IDs stay in Splunk |
| NFR-009 | Testability | Static, functional, negative, load, failure, recovery tests |
| NFR-010 | Auditability | Versioned profile, manifest, change reference, completion evidence |
| NFR-011 | Adoption | Technician and engineer workflow acceptance |
| NFR-012 | Sustainability | Owner, backup, review trigger, support burden measured |

## Corporate requirements still unknown

Approved platform versions, repositories, service discovery, authentication, TLS, routing, dashboards, indexes, sourcetypes, retention, access control, deployment tooling, maintenance windows, and data-classification rules.
