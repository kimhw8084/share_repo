# Principal Engineering Review Results

Status: REVIEW-READY  
Version: 2.0.0  
Date: 2026-07-31

## Review method

The repository was reviewed as a production-adjacent compiler and runtime toolkit, not as a documentation exercise. The principal questionnaire converted each material unknown into one of:

- an organization platform capability;
- a system-profile requirement;
- a compiler invariant;
- a runtime policy;
- an evidence gate;
- a corporate verification action;
- an explicit deferral.

## Material v1 deficiencies and v2 corrections

| Area | Deficiency identified | v2 correction |
|---|---|---|
| Source of truth | Templates interpreted raw profiles and hidden assumptions | Platform profile plus system profile compile into a normalized intermediate plan; templates consume only that plan |
| Unsupported combinations | OTel/backend assumptions could survive until runtime | Fail-closed platform capability and component/mode checks |
| Generation integrity | Partial output could replace a valid package | Staging, pre-install validation, manifest verification, and atomic replacement with rollback |
| Installed execution | Schemas depended on repository-relative paths | Packaged schema resources with parity tests |
| Alert lifecycle | Candidate rules could be confused with deployable rules | Separate candidate and production files; production gates require evidence and approvals |
| Rule correctness | Syntax artifacts without generated unit-test contract | Prometheus rule-test files and corporate promtool validation gate |
| Dependency claims | Generic metric could imply every dependency was monitored | Per-dependency monitoring state, signal reference, evidence, and exception control |
| Cardinality | Per-metric estimate did not enforce per-system total | Aggregate series budget in the compiled plan |
| Probe containment | In-process probes and weak network policy | Spawned workers, deadlines, total budget, exact target/CIDR policy, DNS-pinned connections |
| Filesystem safety | Traversal limits did not prevent mount crossing | Approved roots, no symlinks, same-filesystem default, item/byte/time limits |
| HTTP safety | Redirects and second DNS resolution could bypass target review | Redirect rejection and pinned validated addresses with Host/SNI preservation |
| Regex safety | Arbitrary regex could consume excessive CPU | Literal mode or restricted regex with unsafe constructs rejected |
| Output integrity | Stale locks and fixed restrictive modes could break operations | Dead-PID stale-lock recovery and explicit file-mode policy |
| Database probes | SQL text check alone was insufficient | Approved manifest, query hash, path confinement, read-only assertion, range and finite scalar enforcement, locked atomic output |
| Handoff policy | Screening existed without an explicit corporate permission gate | Platform permission or explicit approval acknowledgement; system-ID consistency; persistent salt |
| Release integrity | Archive reproducibility and tamper evidence incomplete | Fixed timestamps/order/modes, hashes, manifests, provenance, scanner |
| Validation | Happy-path tests dominated | 68 tests covering compiler failure modes, tampering, lifecycle contamination, runtime policy, path escape, symlinks, and transactionality |

## Current architecture decision

Use company Prometheus and Splunk. Do not build a third backend. Use OpenTelemetry only when the approved corporate distribution and component manifest make it the lowest-risk collection/enrichment mechanism.

## Current production decision

Do not enable production rules from the example profiles. The compiler correctly keeps them in candidate/observation artifacts because system ownership, corporate platform details, validation evidence, approval, operator acceptance, and rollback references are unresolved.

## Highest-leverage corporate work

1. Resolve the 13 blocker questionnaire items.
2. Create the real corporate platform profile.
3. Select one Windows and one Linux pilot.
4. Define one functional transaction and one recurring failure/data-flow concern.
5. Compile and test a minimal vertical slice.
6. Prove reuse on the second heterogeneous system.
7. Decide scale from measured diagnosis time, false positives, overhead, adoption, and support burden.

## Remaining technical risks

- Corporate versions may require generator adapters.
- A user-space timeout cannot interrupt a blocked kernel/provider filesystem call.
- Static SQL screening cannot prove a query nonblocking or inexpensive.
- Sanitization cannot guarantee confidentiality.
- Generated PromQL and Splunk searches need authoritative corporate platform execution.
- Functional health and thresholds cannot be inferred from host discovery.
- Monitoring can still create operational burden if ownership, maintenance, and retirement are weak.

## Completion evidence

The codebase is complete enough for corporate architecture and pilot review. Production readiness remains intentionally blocked by missing corporate facts and validation evidence.
