# Remaining Human Decisions

V3 removes avoidable interaction but does not automate accountable judgment.

## Manager

- central owner and backup;
- project priority and capacity;
- criticality/support tier;
- broad fleet scope;
- platform/security commitments;
- production promotion;
- scale/stop decision.

## System owner

- business function;
- functional success;
- dependency criticality;
- maintenance/degradation behavior;
- recovery confirmation;
- safe failure test;
- system-specific correctness.

## Platform owner

- supported products/versions/components;
- repositories and validation commands;
- credentials and access;
- routing, retention, cost, and capacity;
- deployment and rollback.

## Technician and engineer operators

- alert/runbook usability;
- stop/escalation clarity;
- evidence-package completeness;
- recovery confirmation.

## Security/data owner

- data classification;
- repository/transfer boundary;
- identity policy;
- credential delivery;
- target/CIDR approval;
- external bundle approval.

No collector or AI model may substitute for these decisions.
