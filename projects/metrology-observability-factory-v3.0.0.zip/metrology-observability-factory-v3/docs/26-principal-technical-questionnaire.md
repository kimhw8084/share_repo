# Principal Technical Questionnaire and Architecture Decisions

Status: REVIEW-READY  
Version: 2.0.0  
Date: 2026-07-31  
Purpose: Convert unknowns into explicit architecture decisions, configuration inputs, validation gates, or documented deferrals.

## Decision method

Each question is classified as:

- **FACT:** supported by supplied context.
- **DECISION:** selected design for this repository.
- **ASSUMPTION:** safe default that must be verified internally.
- **UNKNOWN:** corporate or system evidence is required.
- **DEFERRED:** intentionally excluded from the current delivery.
- **CODE CONSEQUENCE:** implementation generated from the answer.

## 1. Product and ownership

| Question | Answer/classification | Code consequence |
|---|---|---|
| Is this a new monitoring backend? | **DECISION:** No. Company Prometheus and Splunk remain the primary backends. | Generator emits integration artifacts, not a new server platform. |
| What is the product? | **DECISION:** A standard, compiler, onboarding factory, validation suite, and operating model. | Profiles compile into review-ready packages. |
| Who owns the standard? | **UNKNOWN:** central pattern owner and backup must be assigned. | Production enablement fails when required ownership is unresolved. |
| Who owns system-specific correctness? | **DECISION:** existing system owner, with backup. | Ownership is mandatory profile metadata. |
| Is live platform mutation allowed? | **DECISION:** No. Git-reviewed/manual corporate deployment only. | CLI has no Prometheus, Splunk, server, database, or deployment write API. |
| Is autonomous remediation in scope? | **DEFERRED:** No. | Probe and generation code is read-only; no restart/failover/write actions. |

## 2. Sources of truth and compilation

| Question | Answer/classification | Code consequence |
|---|---|---|
| What is the architecture source of truth? | **DECISION:** organization capability profile plus system profile. | New `platform-profile.schema.json`. |
| Should templates interpret raw profiles directly? | **DECISION:** No. | A compiler creates a validated intermediate plan. |
| How are unsupported combinations handled? | **DECISION:** fail closed. | Structured compiler diagnostics block generation. |
| How are unknown corporate values represented? | **DECISION:** explicit null/TBD fields and diagnostics, never invented values. | Generated package contains unresolved-decision register. |
| Is generation transactional? | **DECISION:** Yes. | Temporary directory and atomic replacement prevent partial packages. |
| Is generation reproducible? | **DECISION:** Yes where inputs are fixed. | Source hashes, generator version, UTC timestamp, and `SOURCE_DATE_EPOCH` support. |
| How are schema changes managed? | **DECISION:** schema versions and compatibility gates; migration automation is deferred until a real version transition exists. | Compiler rejects unsupported schema versions; migration tooling is not claimed. |

## 3. Platform capability

| Question | Answer/classification | Code consequence |
|---|---|---|
| Prometheus distribution/version? | **UNKNOWN.** | Platform profile records version and supported validation commands. |
| Prometheus service discovery model? | **UNKNOWN.** | Static target is reference-only; compiler identifies unresolved discovery. |
| Alertmanager routing ownership? | **UNKNOWN.** | Generated alerts contain routing labels, not receivers. |
| Splunk product/version/topology? | **UNKNOWN.** | Platform profile records supported ingestion and deployment modes. |
| Splunk CIM use? | **ASSUMPTION:** normalize common fields where useful, with metrology extensions. | Field catalog separates CIM candidates from domain fields. |
| OpenTelemetry distribution? | **UNKNOWN.** | Collector artifact generation requires a declared distribution/component manifest. |
| Agent or gateway mode? | **UNKNOWN.** | Platform profile explicitly selects permitted modes; no universal assumption. |
| Can the factory install agents? | **DECISION:** No. | Installation remains corporate deployment work. |

## 4. Telemetry contract

| Question | Answer/classification | Code consequence |
|---|---|---|
| Is host/process uptime enough? | **DECISION:** No. | Functional health is a separate capability and alert family. |
| Which common capabilities are required? | **DECISION:** host, functional, traffic, errors, latency, saturation, freshness, backlog, dependency, change identity, telemetry path—as applicable. | Compiler creates a coverage matrix and gap diagnostics. |
| Where do high-cardinality identifiers live? | **DECISION:** Splunk/logs, not Prometheus labels. | Label policy and series-budget compiler checks. |
| How are metric names controlled? | **DECISION:** stable standard metric families and Prometheus-compatible names. | Metric contract validation. |
| Are thresholds universal? | **DECISION:** No. | Production alerts require validation status and evidence reference. |
| How is missing telemetry interpreted? | **DECISION:** monitoring blind spot, not production failure. | Separate telemetry-missing/stale alerts. |
| How are failover instances represented? | **DECISION:** stable system/service identity plus bounded instance identity. | Instance labels are permitted only with explicit bounded budgets. |
| Should metrics include raw error text? | **DECISION:** No. | Error categories/signatures are bounded aliases. |

## 5. Logs and AI

| Question | Answer/classification | Code consequence |
|---|---|---|
| Can raw logs leave the intranet? | **FACT/DECISION:** No. | Handoff accepts structured summaries only. |
| Is log content trusted as instructions? | **DECISION:** No. | Corporate AI prompts explicitly treat logs as untrusted evidence. |
| Can AI confirm root cause? | **DECISION:** Not without causal evidence and human review. | Schema forces `root_cause_confirmed=false` for exportable feature summaries. |
| What does external AI receive? | **DECISION:** pseudonymized inventory, normalized signatures, counts, sequences, telemetry candidates, limitations. | Handoff compiler and local-only alias map. |
| Should Splunk retain detailed correlation IDs? | **DECISION:** Yes when approved. | Splunk field model; prohibited as Prometheus labels. |

## 6. Discovery and probes

| Question | Answer/classification | Code consequence |
|---|---|---|
| Is remote fleet scanning permitted? | **DECISION:** Not by this repository. | Command plans are generated; execution is local/manual. |
| What is the default privilege? | **DECISION:** normal user. | Elevation is an explicit corporate decision. |
| What data is collected by default? | **DECISION:** bounded metadata only. | No file contents, raw logs, accounts, environment values, command lines, routes, or addresses. |
| Can probes access the network? | **DECISION:** only by explicit opt-in and exact allowlist. | Probe-plan network policy and target validation. |
| Can probes read logs? | **DECISION:** only locally, explicitly, and with bounded output. | Isolated child process and normalized counts only. |
| How are hanging/risky probes contained? | **DECISION:** process isolation and hard timeout. | Probe worker is terminated on deadline. |
| How are probe outputs written? | **DECISION:** atomic textfile replacement with lock. | No partial exposition files. |
| Can HTTP probes follow redirects? | **DECISION:** No by default. | Redirects are blocked unless explicitly implemented and approved later. |
| Can TLS verification be disabled? | **DECISION:** No. | Hard validation. |
| How are DB probes authorized? | **DECISION:** query hash, approved manifest, read-only account assertion, timeout, scalar result, rollback. | Guarded engineer-only DB probe v2. |
| Can static SQL parsing prove safety? | **DECISION:** No. | Parser is defense-in-depth; permissions/approval are primary controls. |

## 7. Validation

| Question | Answer/classification | Code consequence |
|---|---|---|
| What validations are mandatory before generation? | **DECISION:** schema, compiler invariants, metric/cardinality, ownership, capability compatibility. | Structured diagnostics. |
| What validates Prometheus rules? | **DECISION:** syntax plus generated `promtool test rules` cases. | Rule-test artifact and validation runner. |
| What validates OTel? | **DECISION:** corporate distribution binary and declared component manifest. | Capability-gated generation. |
| What validates Splunk? | **UNKNOWN:** corporate search/dashboard tooling. | Query catalog includes cost/validation state; package remains reference until validated. |
| How are production alerts introduced? | **DECISION:** disabled/test route → observation → approved production route. | Deployment gates and alert lifecycle state. |
| What proves reuse? | **DECISION:** second heterogeneous system before fleet scale. | Scale-gate report. |
| What proves value? | **DECISION:** baseline versus pilot on detection, evidence, isolation, false positives, effort, adoption, and support burden. | Benefit register and ROI input model. |

## 8. Reliability, security, and lifecycle

| Question | Answer/classification | Code consequence |
|---|---|---|
| What happens if Prometheus/Splunk is unavailable? | **DECISION:** production continues; monitoring blind spot is handled separately. | No production dependency on observability. |
| How is collector health monitored? | **DECISION:** self-metrics, last-run timestamp, queue/drop/resource indicators. | Telemetry-path capability and alerts. |
| How are secrets supplied? | **UNKNOWN corporate mechanism; DECISION:** never repository or CLI arguments. | Environment/file-provider placeholders only. |
| How is software supply chain handled? | **DECISION:** hashes, manifest, pinned corporate dependency set, CI, review. | Provenance and deterministic package archive. |
| How are exceptions governed? | **DECISION:** owner, reason, alternative control, review/expiry date. | Exception schema and coverage status. |
| How are packages retired? | **DECISION:** owner review, telemetry-use evidence, duplicate removal, rollback plan. | Lifecycle metadata and retirement checklist. |

## Highest-priority unresolved corporate questions

1. Approved Prometheus distribution/version, repositories, service discovery, rule validation, dashboards, and Alertmanager routing.
2. Approved Splunk product/version, indexes, sourcetypes, ingestion modes, CIM expectations, search/dashboard deployment, retention, and cost controls.
3. Approved OpenTelemetry distribution/components/mode—or explicit decision not to use it.
4. Security classification and approved GitHub transfer boundary.
5. Pilot systems, owners/backups, functional definitions, and non-production failure-test path.
6. Credential delivery and least-privilege account model for any network/database probes.
7. Production alert lifecycle, maintenance/silence process, and on-call route.
8. Platform and application resource-overhead limits.
