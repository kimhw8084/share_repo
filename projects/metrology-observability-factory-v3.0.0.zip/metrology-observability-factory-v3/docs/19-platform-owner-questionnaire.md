# Platform Owner Questionnaire

## Prometheus

- Distribution/version?
- Service discovery?
- Approved exporters?
- Scrape authentication/TLS?
- Network zones/firewalls?
- Rule/config repository and validation?
- Alertmanager ownership/routing?
- Dashboard platform?
- Retention/cardinality limits?
- HA/failover behavior?
- Self-monitoring requirements?

## Splunk

- Enterprise/Cloud topology relevant to this use?
- Universal forwarder/HEC/OTel ingestion options?
- Index/sourcetype standards?
- Parsing location and ownership?
- Retention and license constraints?
- Saved-search/dashboard repositories?
- RBAC?
- Field naming standards?
- Scheduled-search cost controls?
- Alert routing/inhibition?
- Data masking policy?

## OpenTelemetry

- Approved distribution/version/components?
- Agent, gateway, or agent-to-gateway?
- Allowed receivers/processors/exporters?
- Credential delivery?
- Config validation and deployment?
- Queue/retry/storage policy?
- Internal telemetry?
- Upgrade cadence?

## Security/change

- Data classification?
- Approved GitHub transfer process?
- Service accounts/certificates?
- Endpoint exposure?
- Production change/rollback requirements?
- Broad discovery approval?
