# Testing and Validation Strategy — v2

## Repository validation

- schema-resource parity;
- questionnaire/platform/profile validation;
- compiler invariants and fail-closed diagnostics;
- aggregate cardinality;
- dependency monitoring truthfulness;
- production alert promotion gates;
- transactional generation and rollback;
- candidate/production rule separation;
- generated artifact and manifest integrity;
- reproducible archives;
- handoff denial, system-ID consistency, pseudonymization, and secret screening;
- probe policy, DNS pinning, redirect blocking, safe regex, deadlines, locks, and output modes;
- database query hash/path/symlink/range gates;
- Linux discovery path bounds and permissions.

## Corporate platform validation

- supported `promtool` syntax and rule-unit-test execution;
- supported OpenTelemetry distribution/component validation;
- Splunk parser, search, dashboard, ingestion, retention, RBAC, and execution-cost validation;
- PowerShell execution on supported Windows versions;
- approved drivers and database query-plan/resource validation.

## Functional validation

- source reconciliation;
- missing versus zero;
- counter reset/stale series;
- controlled fire and clear;
- idle, maintenance, burst, and baseline shift;
- partial dependency failure;
- collector/backend outage;
- clock skew;
- failover and duplicate instance identity;
- resource and ingestion overhead;
- operator evidence usefulness;
- rollback.

## Production gate

No production routing until platform syntax, unit tests, controlled failure/recovery, threshold evidence, security, resource/cost, operator acceptance, ownership, approval, and rollback evidence are recorded in the system profile.
