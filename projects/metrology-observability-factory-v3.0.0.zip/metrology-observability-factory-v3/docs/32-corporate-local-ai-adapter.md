# Corporate-Local AI Adapter

## Purpose

Use the approved Llama/OpenCode environment to transform raw intranet logs into
reviewable structured features without exporting raw evidence.

## Command adapter

The adapter consumes a JSON argv array, not a shell string:

```json
[
  "opencode",
  "run",
  "--prompt-file",
  "{prompt_file}",
  "--output",
  "{output_file}"
]
```

Replace it with the approved corporate CLI syntax.

## Controls

- exact approved sources;
- local regular files only;
- bounded byte chunks;
- line overlap;
- prompt and model-output local-only directories;
- per-command timeout;
- schema validation;
- system-ID consistency;
- root-cause confirmation prohibited;
- secret-shaped output rejection;
- deterministic conservative merge;
- human review false after merge.

## Merge behavior

- normalized signatures merge by normalized template;
- counts add;
- first/last timestamps expand;
- component/features/risks union;
- confidence uses the most conservative value;
- sequence IDs are deterministic;
- telemetry conflicts add a validation warning;
- alert candidates deduplicate by symptom and condition.

## Human review

Review source coverage, template quality, rare severe events, contradictions,
false-positive risks, and missing evidence before campaign ingestion.
