# Database Probe Safety

Status: ENGINEER-ONLY REFERENCE

## Recommendation

Prefer approved database exporters, application-native metrics, or existing Splunk evidence. Use the guarded DB-API probe only when a specific signal cannot be obtained safely another way.

## Controls

- Explicit human acknowledgement.
- Exactly one query.
- Query begins with `SELECT` or `WITH`.
- Conservative keyword rejection.
- `SELECT INTO` prohibited.
- Query text stored in an approved local file.
- Credentials delivered by approved environment mechanism.
- No credentials, endpoint, or query text printed.
- Timeout required.
- One scalar row fetched.
- Transaction rolled back and connection closed.
- Atomic metric output.
- Non-production validation and database-owner review required.

## Limitations

SQL parsing is not complete. A SELECT can still be expensive, block resources, call functions, or expose restricted data. Database permissions, query plan review, least privilege, timeout, resource testing, and human approval are the real controls.

## MSSQL

The `pyodbc` path expects `OBS_DB_CONNECTION_STRING` and the corporate-supported ODBC driver. Integrated authentication or an approved secret mechanism is preferred.

## Oracle

The `oracledb` path expects `OBS_DB_USER`, `OBS_DB_PASSWORD`, and `OBS_DB_DSN` from an approved secret mechanism.

## Prohibited use

- Production writes.
- Stored procedure execution.
- Schema changes.
- Broad table scans without plan review.
- Credentials in command line, repository, output, or handoff.
- Automatic remediation based on query result.
