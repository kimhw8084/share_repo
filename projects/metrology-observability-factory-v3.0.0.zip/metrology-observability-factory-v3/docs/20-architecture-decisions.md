# Architecture Decision Records

## ADR-001 — Use company Prometheus and Splunk

Decision: Accepted provisionally.  
Reason: Avoid duplicate platforms and align operations.  
Verification: Platform-owner constraints.

## ADR-002 — OpenTelemetry is optional plumbing

Decision: Accepted provisionally.  
Reason: Common collection/enrichment may reduce diversity; it does not replace operator-facing platforms.  
Verification: Approved distribution/components/mode.

## ADR-003 — Schema-driven system profiles

Decision: Accepted.  
Reason: Convert onboarding from one-off coding into profile, generation, and validation.

## ADR-004 — Raw logs remain intranet-only

Decision: Accepted.  
Reason: Disconnected boundary, privacy, and evidence integrity.

## ADR-005 — Bounded metrics, detailed logs

Decision: Accepted.  
Reason: Protect Prometheus cardinality while preserving Splunk investigation detail.

## ADR-006 — No autonomous remediation in initial scope

Decision: Accepted.  
Reason: Production change risk, uncertain rollback, and need to establish trustworthy signals first.

## ADR-007 — Second-system gate before scale

Decision: Accepted.  
Reason: Prove reuse rather than overfitting the pilot.
