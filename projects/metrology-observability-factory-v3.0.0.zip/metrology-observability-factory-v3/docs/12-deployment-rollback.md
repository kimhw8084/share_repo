# Deployment and Rollback Standard

## Deployment stages

1. Review-only generated package.
2. Corporate values resolved.
3. Platform syntax validation.
4. Non-production deployment.
5. Collection verification.
6. Dashboard-only observation.
7. Warning alerts to test route.
8. Failure/recovery validation.
9. Approved high/critical routing.
10. Benefit and sustainment review.

## Separation of changes

Separate where possible:

- exporter/Collector installation;
- network/account/certificate access;
- application instrumentation;
- Prometheus scrape/rule changes;
- Splunk ingestion/parsing;
- dashboard creation;
- alert routing.

This reduces blast radius and improves rollback evidence.

## Rollback triggers

Material production impact, resource overhead, sensitive-data ingestion, collector instability, telemetry duplication, alert storm, unsupported platform behavior, or uncertain rollback.

## Completion evidence

Change reference, versions, configuration identity, telemetry screenshots, fire/clear evidence, overhead measurements, operator acceptance, and rollback result.
