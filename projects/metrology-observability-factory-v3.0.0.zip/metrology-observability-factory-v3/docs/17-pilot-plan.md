# Pilot Plan

## Selection criteria

Choose systems with:

- meaningful recurring support or data-flow risk;
- accessible logs/metrics;
- clear functional transaction;
- cooperative owner;
- non-production validation path;
- different OS/architecture characteristics;
- moderate rather than maximum initial blast radius.

## Pilot package

- Windows discovery.
- Linux discovery.
- system profile.
- local AI log features.
- telemetry gap report.
- one functional signal.
- one freshness/backlog signal.
- one dependency signal.
- collector self-health.
- fleet/system/workbench/coverage views.
- three actionable alerts.
- runbook and escalation package.
- fire/clear/resource/rollback tests.

## Baseline

Observe current workflow for selected incidents or replay exercises:

- detection path;
- tools/server hops;
- evidence time;
- isolation time;
- recovery confirmation;
- engineer and technician effort.

## Acceptance criteria

- no raw-log export;
- no material production/resource impact;
- alert detects selected failure;
- evidence package identifies next discriminating check;
- recovery condition is accurate;
- operator workflow is faster or materially safer;
- second system uses the same schemas/templates.

## Pilot stop conditions

Security concern, production impact, unavailable rollback, non-actionable alert, unsupported platform path, or inability to demonstrate a functional check.
