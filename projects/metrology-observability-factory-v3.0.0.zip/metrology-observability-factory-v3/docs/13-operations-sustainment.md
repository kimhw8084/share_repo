# Operations and Sustainment

## Ownership

- Central pattern owner: standard, generator, tests, releases, exceptions.
- System owner: system-specific signals, thresholds, runbooks, support.
- Backup: independent continuity.
- Platform owners: backend operations.
- Technicians: validated first response.

## Review cadence

### Monthly during pilot/rollout

- incidents detected/missed;
- false positives;
- telemetry gaps;
- ingestion/resource cost;
- onboarding progress;
- blocked actions;
- support burden;
- operator feedback.

### Quarterly after stabilization

- coverage;
- stale systems/profiles;
- owner/backup changes;
- version compatibility;
- unused alerts/dashboards;
- recurring incidents and preventive projects;
- realized benefit;
- retire/replace decisions.

## Required operational metrics

- systems/hosts onboarded;
- required signals present;
- last telemetry;
- alert count by severity/outcome;
- user-reported-before-monitoring events;
- alert-to-evidence time;
- alert-to-isolation time;
- false-positive rate;
- runbook usage;
- technician escalation completeness;
- collector resource/queue/drop state;
- package age and owner/backup coverage.

## Retirement

Remove obsolete probes, duplicate ingestion, unused dashboards, and replaced workflows. Monitoring that no longer has an owner or action must be retired or corrected.
