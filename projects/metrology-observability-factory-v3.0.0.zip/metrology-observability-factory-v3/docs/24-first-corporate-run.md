# First Corporate Run — v2

Status: EXECUTION GUIDE  
Purpose: reach one validated vertical slice without bypassing architecture or safety gates.

## 1. Import and preserve

- Transfer through the approved GitHub workflow.
- Verify the release SHA-256.
- Preserve the release tag/branch.
- Create a corporate adaptation branch.
- Keep raw logs, credentials, endpoints, production identifiers, and local pseudonymization maps out of externally synchronized repositories.

## 2. Run the principal questionnaire

```bash
obsfactory questionnaire \
  questionnaires/principal-architecture-review.yml \
  --output output/principal-questionnaire-assessment.md
```

Resolve blocker questions with the named corporate owners. Record evidence and code consequences. Do not convert unknowns into guessed configuration.

## 3. Create the corporate platform profile

Copy and replace:

```text
platforms/example-company-platform.yml
```

Confirm Prometheus, Splunk, optional OpenTelemetry, security, credentials, network-probe policy, data transfer, and validation commands. Validate:

```bash
obsfactory validate platform platforms/corporate-platform.yml
```

## 4. Validate the repository

```bash
python -m pytest
python scripts/common/check_environment.py --output output/environment.json
```

Windows:

```powershell
.\scripts\common\Validate-PowerShellSyntax.ps1
```

Use corporate-supported binaries for authoritative platform validation.

## 5. Select the pilot

Choose one Windows system, one Linux system, and one meaningful recurring failure or data flow. Identify pattern owner, backup, system owners, technician reviewers, platform contacts, and rollback authority.

## 6. Establish the baseline

Measure current detection source, time to useful evidence, time to isolate layer, recovery confirmation, responder effort, repeated manual checks, false positives, and support burden.

## 7. Review and run discovery

Start with normal privilege, local host facts, no approved paths, no event/task summaries, no hostname export, and conservative limits.

Linux discovery does not cross filesystems by default. The cooperative elapsed limit cannot interrupt a blocked filesystem syscall; do not begin with unhealthy or remote mounts without separate corporate process supervision.

Validate:

```bash
obsfactory validate discovery output/.../server-discovery.json
```

## 8. Build and review the system profile

Scaffold conservatively, then supply business truth:

```bash
python scripts/common/scaffold_profile_from_discovery.py \
  --discovery output/.../server-discovery.json \
  --output profiles/<system-id>.yml \
  --service-pattern "<approved bounded pattern>"
```

Define functional success, required services, dependency monitoring state, data-flow stages, idle/burst behavior, signal labels and cardinality limits, logs/sensitivity, ownership, lifecycle, and alert evidence status.

## 9. Assess before generation

```bash
obsfactory assess \
  profiles/<system-id>.yml \
  --platform platforms/corporate-platform.yml \
  --output output/<system-id>-assessment.md
```

Do not proceed when assessment contains errors. Warnings require documented review.

## 10. Conduct intranet-only log research

Use the supplied corporate-AI prompt on a bounded approved window. Validate the normalized feature summary. Do not export raw lines or mark cause confirmed.

## 11. Compile and generate

```bash
obsfactory compile \
  profiles/<system-id>.yml \
  --platform platforms/corporate-platform.yml \
  --output output/<system-id>-compiled-plan.json

obsfactory generate \
  profiles/<system-id>.yml \
  --platform platforms/corporate-platform.yml \
  --output generated/<system-id>
```

The generator validates the staging package and manifest before atomic installation.

## 12. Implement the smallest vertical slice

Prefer supported exporters and existing Splunk ingestion. Add custom probes only for a verified gap.

Minimum slice:

- functional state;
- freshness or oldest backlog age;
- required dependency state;
- telemetry/probe self-health;
- Splunk evidence-window link;
- runbook and recovery confirmation.

## 13. Validate in observation mode

Validate syntax, source reconciliation, missing-versus-zero behavior, controlled failure and clear, idle/burst conditions, resource and ingestion overhead, failover/instance behavior, security, operator workflow, and rollback.

Candidate rules remain outside production routing.

## 14. Promote deliberately

Production alert files remain empty unless the system lifecycle is production and the profile contains:

- validated alert state;
- validation evidence;
- production approval reference;
- operator acceptance reference;
- rollback validation reference;
- primary and backup owner.

## 15. Prove reuse

Repeat on a heterogeneous second system. Record reused artifacts, exceptions, actual effort, support burden, and benefit. Do not scale if a new architecture was required.

## 16. Continue, pivot, or stop

Use measured value, adoption, operational risk, and sustainment—not dashboard count.
