# Corner-Case Design Checklist

## Hosts and operating systems

- Unsupported PowerShell/Python.
- Missing CIM, `systemctl`, `ss`, or journal.
- Non-admin/non-root permissions.
- Clustered/failover instances.
- Containers and PaaS.
- Ephemeral hosts.
- Multiple services with same process name.
- Service wrapper reports running while child failed.
- Reboot during collection.
- Very large service/process inventories.

## Files and data flows

- Millions of files.
- Deep paths and access denied.
- Symlinks/reparse points.
- Same file copied/renamed repeatedly.
- Future/incorrect timestamps.
- Planned idle periods.
- Burst arrival.
- Partial processing.
- Output generated but downstream not acknowledged.
- Duplicate/replayed inputs.
- Files still being written.
- Network-share outage.
- Disk full/inodes exhausted.
- Daylight-saving and timezone mismatch.

## Logs

- Multiline stack traces.
- Mixed encodings.
- Truncation/rotation.
- Duplicate ingestion.
- Missing timestamps.
- Unbounded dynamic tokens.
- Sensitive data in messages.
- Log storm.
- Logging failure during incident.
- Regex performance risk.
- AI prompt injection inside log text.

## Metrics and alerts

- Missing versus zero.
- Counter reset.
- Stale series.
- Aggregation hides one failed instance.
- Failover duplicates labels.
- High cardinality.
- Alert resolves before evidence is collected.
- Dependency failure creates many secondary alerts.
- Maintenance/idle false positives.
- Baseline shifts after release.
- Long-tail latency.
- Sampling hides rare severe failures.

## Backends

- Prometheus unavailable.
- Splunk unavailable.
- Collector queue/backpressure/drop.
- Certificate/account expiry.
- Network partition.
- Clock skew.
- Retention too short for investigation.
- Dashboard permissions block operators.
- Saved search exceeds cost limits.

## Human workflow

- No owner/backup.
- Technician lacks access.
- Runbook step is ambiguous.
- Alert route points to wrong team.
- Existing dashboard remains preferred.
- AI summary is trusted without evidence.
- Monitoring change is deployed without rollback.
