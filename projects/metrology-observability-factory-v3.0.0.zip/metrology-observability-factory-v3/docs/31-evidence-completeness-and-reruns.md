# Evidence Completeness and Targeted Reruns

## Principle

Missing evidence should create the smallest possible next action.

## Design gate

Required:

- approved decision record;
- current inventory snapshot.

## Pilot gate

Required per applicable subject:

- host discovery;
- environment/tool capability;
- system-owner semantics;
- normalized log-feature summary;
- Prometheus/Splunk/OTel capability evidence where targeted;
- platform-owner response.

## Production gate

Required per system:

- controlled validation result;
- operator acceptance.

## Scale gate

Required:

- benefit baseline and support-burden evidence;
- second-system reuse evidence through the existing project decision process.

## Freshness

Evidence expires by type. Stale evidence is not silently accepted.

## Rerun policy

The plan identifies:

- exact subject;
- missing/stale evidence type;
- command or form;
- reason;
- limited scope.

`broad_campaign_rerun_required` remains false unless the campaign definition or
inventory scope materially changes.
