# Architecture — v2

Status: REVIEW-READY  
Version: 2.0.0  
Date: 2026-07-31

## Control plane

```text
principal questionnaire
     |
organization platform capability profile
     |
system profile + reviewed evidence
     |
fail-closed compiler
     |
normalized compiled plan
     |
transactional artifact generator
     |
pre-install structural and manifest validation
     |
Git review / corporate platform validation / controlled deployment
```

The compiled plan is the only generation input. Templates do not reinterpret raw profiles.

## Runtime evidence plane

```text
host/application
  +-- supported host exporter or application metric
  +-- existing approved Splunk ingestion
  +-- bounded probe for a verified gap
  +-- optional approved OTel collection
          |
          +------------------+
          |                  |
          v                  v
      Prometheus           Splunk
 bounded state/rates    detailed event context
 alert candidates       normalized signatures
          |                  |
          +--------+---------+
                   v
 fleet -> system -> troubleshooting -> coverage
                   |
                   v
 runbook -> escalation package -> recovery confirmation
```

Monitoring is not a production control dependency. Loss of observability creates a blind-spot incident but must not stop manufacturing processing.

## Sources of truth

1. Corporate platform profile: supported products, versions, modes, components, limits, security, and validation controls.
2. System profile: business function, lifecycle, ownership, services, dependencies, flows, signals, logs, alerts, and evidence state.
3. Compiled plan: normalized capabilities, aggregate cardinality, diagnostics, recording rules, alerts, probes, unresolved decisions, and input hashes.
4. Generated package: a deterministic review artifact, not a deployed state.

## Compiler invariants

Generation fails on material violations such as:

- unsupported backend or OpenTelemetry component/mode;
- duplicate IDs;
- unsafe metric names or known unbounded labels;
- combined series estimate above the platform budget;
- production alerts without lifecycle, evidence, approval, operator acceptance, rollback proof, and owner/backup;
- validated dependency monitoring without evidence;
- dependency exceptions without an approved reference;
- malformed or unsafe probe plans.

Warnings remain visible for unresolved owners, unvalidated required signals, and platform facts that must be verified.

## Alert lifecycle

```text
draft -> observation -> validated -> production
```

Candidate and production rule files are physically separate. Only production-lifecycle alerts enter the production file, and the compiler requires explicit evidence and approvals.

## Dependency truthfulness

A generic dependency metric does not imply every dependency is monitored. Each dependency declares:

- `uninstrumented`
- `candidate`
- `validated`
- `exception`

Alerts are generated only for candidate or validated dependencies.

## Probe supervisor

Each enabled probe runs in a spawned child process with a hard deadline. The supervisor enforces a total cycle budget and publishes one locked atomic textfile.

Network probes require an exact alias, host, port, address-class policy, and CIDR match. DNS results are validated once and pinned to the actual connection while preserving HTTP Host and TLS SNI. Redirects are rejected.

File/log probes require approved roots, no symlink traversal, optional same-filesystem confinement, and item/byte/time bounds. Log output is count-only.

## Data placement

- Prometheus: bounded state, rates, durations, freshness, backlog, dependency state, and collector/probe health.
- Splunk: detailed event context, correlation IDs, normalized signatures, changes, and high-cardinality investigation data.
- Nowhere: credentials, unnecessary production identifiers, or raw external log exports.

## AI boundary

Raw logs remain intranet-only. Corporate AI produces a reviewed schema-valid summary. External design uses that summary, never implied live access.

## Availability and rollback

Generated monitoring remains disabled or observation-only until corporate syntax, resource, ingestion, fire/clear, operator, security, and rollback evidence is accepted.
