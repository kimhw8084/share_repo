from __future__ import annotations

from collections import Counter
from typing import Any

from .schema import validate_data


OPEN_STATUSES = {"unknown", "assumption"}
SEVERITY_ORDER = {"blocker": 0, "high": 1, "medium": 2, "low": 3}


def assess_questionnaire(value: dict[str, Any]) -> dict[str, Any]:
    errors = validate_data("questionnaire", value)
    if errors:
        return {
            "schema_version": "1.0.0",
            "questionnaire_id": value.get("questionnaire_id", "unknown"),
            "readiness": "invalid",
            "schema_errors": errors,
            "counts": {},
            "open_questions": [],
            "decisions": [],
        }

    questions: list[dict[str, Any]] = []
    for category in value["categories"]:
        for question in category["questions"]:
            item = dict(question)
            item["category_id"] = category["id"]
            item["category_title"] = category["title"]
            questions.append(item)

    status_counts = Counter(item["status"] for item in questions)
    criticality_counts = Counter(item["criticality"] for item in questions)
    open_items = [
        item for item in questions
        if item["status"] in OPEN_STATUSES
    ]
    open_items.sort(
        key=lambda item: (
            SEVERITY_ORDER[item["criticality"]],
            item["category_id"],
            item["id"],
        )
    )
    blockers = [
        item for item in open_items if item["criticality"] == "blocker"
    ]
    high = [item for item in open_items if item["criticality"] == "high"]

    if blockers:
        readiness = "blocked"
    elif high:
        readiness = "architecture-review-required"
    elif open_items:
        readiness = "conditional"
    else:
        readiness = "resolved"

    decisions = [
        item for item in questions
        if item["status"] in {"fact", "decision", "deferred"}
    ]
    return {
        "schema_version": "1.0.0",
        "questionnaire_id": value["questionnaire_id"],
        "title": value["title"],
        "readiness": readiness,
        "counts": {
            "total": len(questions),
            "by_status": dict(status_counts),
            "by_criticality": dict(criticality_counts),
            "open": len(open_items),
            "open_blockers": len(blockers),
            "open_high": len(high),
        },
        "open_questions": open_items,
        "decisions": decisions,
        "review_owner": value["review_owner"],
        "review_trigger": value["review_trigger"],
    }


def questionnaire_markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Principal Technical Questionnaire Assessment",
        "",
        f"Questionnaire: `{report.get('questionnaire_id', 'unknown')}`",
        f"Readiness: **{report['readiness']}**",
        "",
    ]
    if report.get("schema_errors"):
        lines.extend(["## Schema errors", ""])
        lines.extend(f"- {error}" for error in report["schema_errors"])
        lines.append("")
        return "\n".join(lines)

    counts = report["counts"]
    lines.extend([
        "## Summary",
        "",
        f"- Total questions: {counts['total']}",
        f"- Open questions: {counts['open']}",
        f"- Open blockers: {counts['open_blockers']}",
        f"- Open high-criticality questions: {counts['open_high']}",
        "",
        "## Open questions in priority order",
        "",
        "| Criticality | ID | Category | Question | Current answer | Owner | Verification |",
        "|---|---|---|---|---|---|---|",
    ])
    for item in report["open_questions"]:
        values = [
            item["criticality"], f"`{item['id']}`", item["category_title"],
            item["prompt"], item["answer"], item["owner"], item["verification"],
        ]
        lines.append("| " + " | ".join(str(v).replace("|", "\\|") for v in values) + " |")
    if not report["open_questions"]:
        lines.append("| — | — | — | None | — | — | — |")

    lines.extend([
        "",
        "## Established decisions and boundaries",
        "",
        "| Status | ID | Decision/fact | Code consequence |",
        "|---|---|---|---|",
    ])
    for item in report["decisions"]:
        values = [
            item["status"], f"`{item['id']}`", item["answer"],
            item["code_consequence"],
        ]
        lines.append("| " + " | ".join(str(v).replace("|", "\\|") for v in values) + " |")
    lines.append("")
    return "\n".join(lines)
