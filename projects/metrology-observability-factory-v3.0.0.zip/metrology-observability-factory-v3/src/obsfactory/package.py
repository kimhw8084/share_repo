from __future__ import annotations

from datetime import datetime, timezone
import os
from pathlib import Path
import stat
import zipfile

from .constants import DENIED_HANDOFF_SUFFIXES
from .security import scan_tree
from .timeutil import build_time_utc


EXCLUDED_PARTS = {
    ".git",
    ".venv",
    "__pycache__",
    ".pytest_cache",
    "output",
    "generated",
    "local-only",
    "dist",
    "build",
}


def _zip_datetime() -> tuple[int, int, int, int, int, int]:
    value = build_time_utc().astimezone(timezone.utc)
    if value.year < 1980:
        value = datetime(1980, 1, 1, tzinfo=timezone.utc)
    # ZIP timestamps have two-second precision.
    return (value.year, value.month, value.day, value.hour, value.minute, value.second // 2 * 2)


def create_zip(source: Path, destination: Path) -> Path:
    source = source.resolve()
    destination = destination.resolve()
    try:
        destination.relative_to(source)
    except ValueError:
        pass
    else:
        raise ValueError("Destination archive must not be inside the source tree")

    findings = scan_tree(source)
    blocking = [item for item in findings if item.blocking]
    if blocking:
        summary = "; ".join(f"{item.path}:{item.category}" for item in blocking[:20])
        raise ValueError(f"Package blocked by security scan: {summary}")

    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + f".tmp-{os.getpid()}")
    if temporary.exists():
        temporary.unlink()

    timestamp = _zip_datetime()
    try:
        with zipfile.ZipFile(
            temporary,
            "w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=9,
            strict_timestamps=True,
        ) as archive:
            for path in sorted(source.rglob("*"), key=lambda item: str(item.relative_to(source))):
                if path.is_symlink():
                    raise ValueError(f"Symlink is prohibited in release package: {path}")
                if not path.is_file():
                    continue
                relative = path.relative_to(source)
                if any(part in EXCLUDED_PARTS or part.endswith(".egg-info") for part in relative.parts):
                    continue
                if path.suffix.lower() in DENIED_HANDOFF_SUFFIXES:
                    continue
                archive_name = str(Path(source.name) / relative).replace("\\", "/")
                info = zipfile.ZipInfo(archive_name, timestamp)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                mode = 0o755 if os.access(path, os.X_OK) else 0o644
                info.external_attr = (stat.S_IFREG | mode) << 16
                info.flag_bits |= 0x800  # UTF-8
                archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED)
        os.replace(temporary, destination)
    finally:
        if temporary.exists():
            temporary.unlink()
    return destination
