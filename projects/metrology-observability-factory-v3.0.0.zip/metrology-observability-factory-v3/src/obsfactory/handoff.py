from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import secrets
import hashlib
import shutil
import tempfile
from typing import Any

from .io import dump_json, load_data
from .schema import validate_data
from .security import Finding, findings_to_dicts, pseudonym, sanitize_value
from .timeutil import build_time_iso


def _alias_discovery(
    discovery: dict[str, Any],
    salt: bytes,
) -> tuple[dict[str, Any], dict[str, str], str]:
    value = json.loads(json.dumps(discovery))
    mapping: dict[str, str] = {}

    identity = value.get("identity", {})
    original_system_id = str(identity.get("system_id", "system"))
    system_alias = pseudonym(original_system_id, salt, "sys")
    mapping[system_alias] = original_system_id
    identity["system_id"] = system_alias

    original_fingerprint = identity.get("host_fingerprint")
    if original_fingerprint:
        host_alias = pseudonym(str(original_fingerprint), salt, "host")
        mapping[host_alias] = str(original_fingerprint)
        identity["host_fingerprint"] = host_alias
    identity.pop("host_name", None)
    identity["host_name_included"] = False

    for collection_name, prefix, key in [
        ("services", "svc", "name"),
        ("process_summary", "proc", "name"),
    ]:
        for item in value.get(collection_name, []) or []:
            original = item.get(key)
            if original:
                alias = pseudonym(str(original), salt, prefix)
                mapping[alias] = str(original)
                item[key] = alias
            if "display_name" in item:
                item["display_name"] = "<REDACTED>"

    for item in value.get("listening_ports", []) or []:
        original = item.get("process_name")
        if original:
            alias = pseudonym(str(original), salt, "proc")
            mapping[alias] = str(original)
            item["process_name"] = alias
        item.pop("address", None)

    # Filesystem names and mount points can expose internal architecture.
    for item in value.get("resources", {}).get("filesystems", []) or []:
        for key in ("device_or_filesystem", "filesystem_type_or_device", "device_id", "mountpoint"):
            original = item.get(key)
            if original:
                alias = pseudonym(str(original), salt, "fs")
                mapping[alias] = str(original)
                item[key] = alias

    time_candidates = value.get("time_service", {}).get("candidate_services", {})
    if isinstance(time_candidates, dict):
        aliased_candidates = {}
        for original, state in time_candidates.items():
            alias = pseudonym(str(original), salt, "svc")
            mapping[alias] = str(original)
            aliased_candidates[alias] = state
        value["time_service"]["candidate_services"] = aliased_candidates

    for item in value.get("event_summary", []) or []:
        for key in ("unit", "identifier", "provider"):
            original = item.get(key)
            if original:
                alias = pseudonym(str(original), salt, "evt")
                mapping[alias] = str(original)
                item[key] = alias

    for item in value.get("scheduled_task_summary", []) or []:
        for key in ("task_name", "task_path"):
            original = item.get(key)
            if original:
                alias = pseudonym(str(original), salt, "task")
                mapping[alias] = str(original)
                item[key] = alias

    # Absolute roots and relative filenames can reveal internal product names.
    # Preserve only aggregate file metadata by suffix.
    aggregates: dict[str, dict[str, int]] = {}
    for item in value.get("approved_path_inventory", []) or []:
        suffix = item.get("suffix") or "<none>"
        aggregate = aggregates.setdefault(suffix, {"count": 0, "total_size_bytes": 0})
        aggregate["count"] += 1
        aggregate["total_size_bytes"] += int(item.get("size_bytes") or 0)
    value["approved_path_inventory"] = [
        {"suffix": suffix, **data, "content_collected": False}
        for suffix, data in sorted(aggregates.items())
    ]
    return value, mapping, system_alias


def _alias_log_features(
    features: dict[str, Any],
    salt: bytes,
    mapping: dict[str, str],
    system_alias: str,
) -> dict[str, Any]:
    value = json.loads(json.dumps(features))
    original_system_id = value.get("system_id")
    if original_system_id:
        mapping[system_alias] = str(original_system_id)
    value["system_id"] = system_alias

    for source in value.get("sources", []) or []:
        original = source.get("source_id")
        if original:
            alias = pseudonym(str(original), salt, "source")
            mapping[alias] = str(original)
            source["source_id"] = alias

    for signature in value.get("signatures", []) or []:
        components = []
        for original in signature.get("affected_components", []) or []:
            alias = pseudonym(str(original), salt, "component")
            mapping[alias] = str(original)
            components.append(alias)
        signature["affected_components"] = components

    return value



def _load_or_create_salt(path: Path | None) -> tuple[bytes, str]:
    if path is None:
        salt = secrets.token_bytes(32)
        return salt, "ephemeral"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        salt = path.read_bytes()
        if len(salt) < 32:
            raise ValueError("Pseudonymization salt file must contain at least 32 bytes")
        return salt, "persistent-local"
    salt = secrets.token_bytes(32)
    fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    try:
        os.write(fd, salt)
        os.fsync(fd)
    finally:
        os.close(fd)
    return salt, "persistent-local"


def _install_directory(staging: Path, output: Path, *, force: bool) -> None:
    backup: Path | None = None
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        if not force:
            raise FileExistsError(f"Output exists: {output}; use force to replace it")
        backup = output.with_name(f".{output.name}.backup-{os.getpid()}")
        if backup.exists():
            shutil.rmtree(backup)
        output.rename(backup)
    try:
        staging.rename(output)
    except Exception:
        if backup is not None and backup.exists() and not output.exists():
            backup.rename(output)
        raise
    else:
        if backup is not None:
            shutil.rmtree(backup, ignore_errors=True)


def prepare_handoff(
    discovery_path: Path,
    output_directory: Path,
    log_features_path: Path | None = None,
    *,
    platform_path: Path | None = None,
    policy_acknowledged: bool = False,
    salt_path: Path | None = None,
    force: bool = False,
) -> dict[str, Any]:
    discovery = load_data(discovery_path)
    errors = validate_data("discovery", discovery)
    if errors:
        raise ValueError("Discovery validation failed: " + "; ".join(errors))

    if platform_path is not None:
        platform = load_data(platform_path)
        errors = validate_data("platform", platform)
        if errors:
            raise ValueError("Platform validation failed: " + "; ".join(errors))
        if platform["security"]["external_handoff_allowed"] is not True:
            raise PermissionError(
                "Platform profile does not permit external handoff"
            )
    elif not policy_acknowledged:
        raise PermissionError(
            "External handoff requires a permitting platform profile or explicit policy acknowledgement"
        )

    log_features = None
    if log_features_path:
        log_features = load_data(log_features_path)
        errors = validate_data("log-features", log_features)
        if errors:
            raise ValueError("Log-feature validation failed: " + "; ".join(errors))
        discovery_system = discovery.get("identity", {}).get("system_id")
        if log_features.get("system_id") != discovery_system:
            raise ValueError(
                "Discovery and log-feature system IDs do not match"
            )

    if output_directory.exists() and not force:
        raise FileExistsError(
            f"Output exists: {output_directory}; use force to replace it"
        )
    output_directory.parent.mkdir(parents=True, exist_ok=True)
    salt, salt_mode = _load_or_create_salt(salt_path)
    created_at = build_time_iso()
    staging = Path(
        tempfile.mkdtemp(
            prefix=f".{output_directory.name}.handoff-",
            dir=output_directory.parent.resolve(),
        )
    )
    try:
        local_only = staging / "local-only"
        local_only.mkdir(parents=True)

        aliased_discovery, mapping, system_alias = _alias_discovery(discovery, salt)
        findings: list[Finding] = []
        payload: dict[str, Any] = {
            "server_discovery": sanitize_value(aliased_discovery, findings)
        }
        if log_features is not None:
            aliased_features = _alias_log_features(
                log_features,
                salt,
                mapping,
                system_alias,
            )
            payload["log_feature_summary"] = sanitize_value(
                aliased_features,
                findings,
            )

        blocking = [item for item in findings if item.blocking]
        report = {
            "schema_version": "2.0.0",
            "created_at_utc": created_at,
            "findings": findings_to_dicts(findings),
            "blocking_findings": findings_to_dicts(blocking),
            "human_review_required": True,
            "transfer_approved": False,
            "salt_mode": salt_mode,
            "salt_fingerprint": hashlib.sha256(salt).hexdigest()[:16],
            "warning": (
                "Automated screening cannot guarantee removal of all sensitive data. "
                "Company review remains mandatory."
            ),
        }
        dump_json(staging / "handoff-review-report.json", report)
        dump_json(local_only / "alias-map.DO-NOT-TRANSFER.json", mapping)
        try:
            os.chmod(local_only / "alias-map.DO-NOT-TRANSFER.json", 0o600)
        except OSError:
            pass

        if blocking:
            raise ValueError(
                "Blocking sensitive patterns were detected. "
                "Review the staged handoff report inside the corporate environment."
            )

        handoff = {
            "schema_version": "1.0.0",
            "created_at_utc": created_at,
            "policy": {
                "raw_logs_included": False,
                "configuration_contents_included": False,
                "identifiers_pseudonymized": True,
                "credentials_prohibited": True,
                "external_handoff_policy_verified": True,
            },
            "human_approval": {
                "approved": False,
                "approved_by": "TBD",
                "approved_at_utc": "TBD",
            },
            "payload": payload,
            "screening": {
                "blocking_findings": 0,
                "nonblocking_findings": len(findings),
                "report": "handoff-review-report.json",
            },
        }
        errors = validate_data("handoff", handoff)
        if errors:
            raise ValueError(
                "Generated handoff failed schema validation: " + "; ".join(errors)
            )
        dump_json(staging / "external-handoff.json", handoff)
        _install_directory(staging, output_directory, force=force)
        return report
    except Exception:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        raise
