from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .assessment import assess, assessment_markdown
from .compiler import compile_profile
from .coverage import build_coverage, coverage_markdown
from .diffing import semantic_diff
from .generate import generate_package
from .handoff import prepare_handoff
from .io import dump_json, load_data
from .package import create_zip
from .schema import SCHEMA_FILES, validate_file
from .security import findings_to_dicts, scan_tree
from .metrics import validate_metric_catalog
from .questionnaire import assess_questionnaire, questionnaire_markdown
from .campaign import (
    advance_campaign,
    approve_runners,
    build_ai_jobs,
    build_runners,
    finalize_campaign,
    ingest_campaign,
    init_campaign,
    status_campaign,
)


def cmd_validate(args: argparse.Namespace) -> int:
    errors = validate_file(args.kind, args.path)
    if args.kind == "profile" and not errors:
        profile = load_data(args.path)
        errors.extend(
            f"{issue.metric}: {issue.message}"
            for issue in validate_metric_catalog(profile.get("signals", []))
        )
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print(f"VALID: {args.kind}: {args.path}")
    return 0



def cmd_questionnaire(args: argparse.Namespace) -> int:
    value = load_data(args.path)
    report = assess_questionnaire(value)
    if args.output:
        if args.output.suffix.lower() == ".json":
            dump_json(args.output, report)
        else:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(questionnaire_markdown(report), encoding="utf-8")
    else:
        print(questionnaire_markdown(report))
    return 1 if report["readiness"] in {"invalid", "blocked"} else 0


def cmd_compile(args: argparse.Namespace) -> int:
    profile = load_data(args.profile)
    platform = load_data(args.platform) if args.platform else None
    plan = compile_profile(profile, platform, strict=not args.allow_errors)
    if args.output:
        dump_json(args.output, plan)
    else:
        print(json.dumps(plan, indent=2))
    return 1 if any(item["severity"] == "error" for item in plan["diagnostics"]) else 0


def cmd_assess(args: argparse.Namespace) -> int:
    profile = load_data(args.profile)
    platform = load_data(args.platform) if args.platform else None
    report = assess(profile, platform)
    if args.output:
        if args.output.suffix.lower() == ".json":
            dump_json(args.output, report)
        else:
            args.output.write_text(assessment_markdown(report), encoding="utf-8")
    else:
        print(assessment_markdown(report))
    return 1 if report["readiness"] == "blocked" else 0


def cmd_generate(args: argparse.Namespace) -> int:
    path = generate_package(
        args.profile,
        args.output,
        platform_path=args.platform,
        force=args.force,
        strict=not args.allow_errors,
    )
    print(f"Generated review-ready package: {path}")
    print("No production deployment or platform validation has occurred.")
    return 0


def cmd_diff(args: argparse.Namespace) -> int:
    before = load_data(args.before)
    after = load_data(args.after)
    changes = [item.to_dict() for item in semantic_diff(before, after)]
    report = {
        "schema_version": "1.0.0",
        "before": args.before.name,
        "after": args.after.name,
        "change_count": len(changes),
        "high_risk_count": sum(item["risk"] == "high" for item in changes),
        "changes": changes,
        "human_review_required": True,
    }
    if args.output:
        dump_json(args.output, report)
    else:
        print(json.dumps(report, indent=2))
    return 0


def cmd_handoff(args: argparse.Namespace) -> int:
    report = prepare_handoff(
        args.discovery,
        args.output,
        args.log_features,
        platform_path=args.platform,
        policy_acknowledged=args.acknowledge_policy_review
        == "I_HAVE_APPROVAL",
        salt_path=args.salt_file,
        force=args.force,
    )
    print(f"Created: {args.output / 'external-handoff.json'}")
    print("Human review and company approval remain required.")
    print(json.dumps(report, indent=2))
    return 0


def cmd_scan(args: argparse.Namespace) -> int:
    findings = scan_tree(args.path, max_file_bytes=args.max_file_bytes)
    if args.output:
        dump_json(args.output, {"findings": findings_to_dicts(findings)})
    for finding in findings:
        level = "BLOCK" if finding.blocking else "REVIEW"
        print(f"{level}: {finding.path}: {finding.category}: {finding.detail}")
    return 1 if any(item.blocking for item in findings) else 0


def cmd_coverage(args: argparse.Namespace) -> int:
    profile = load_data(args.profile)
    report = build_coverage(profile)
    if args.output:
        if args.output.suffix.lower() == ".json":
            dump_json(args.output, report)
        else:
            args.output.write_text(coverage_markdown(report), encoding="utf-8")
    else:
        print(coverage_markdown(report))
    return 0



def cmd_campaign_init(args: argparse.Namespace) -> int:
    path = init_campaign(
        args.approval,
        args.inventory,
        args.output,
        campaign_id=args.campaign_id,
        title=args.title,
        inventory_snapshot_date=args.inventory_snapshot_date,
        force=args.force,
    )
    print(f"Initialized evidence campaign: {path}")
    print("Next: review generated forms and build local execution bundles.")
    return 0


def cmd_campaign_build_runners(args: argparse.Namespace) -> int:
    result = build_runners(args.directory, force=args.force)
    print(json.dumps(result, indent=2))
    print("Each host manifest remains blocked until approved_for_host is set true internally.")
    return 0



def cmd_campaign_approve_runners(args: argparse.Namespace) -> int:
    result = approve_runners(args.directory, args.approval_csv)
    print(json.dumps(result, indent=2))
    print("This approves local evidence collection only, not production changes.")
    return 0


def cmd_campaign_advance(args: argparse.Namespace) -> int:
    result = advance_campaign(
        args.directory,
        external_output=args.external_output,
        force=args.force,
    )
    print(json.dumps(result, indent=2))
    status = result["status"]
    return 1 if status["conflict_count"] else 0


def cmd_campaign_ingest(args: argparse.Namespace) -> int:
    result = ingest_campaign(args.directory, args.inbox)
    print(json.dumps(result, indent=2))
    return 1 if result["invalid"] or result["conflicts"] else 0


def cmd_campaign_build_ai_jobs(args: argparse.Namespace) -> int:
    result = build_ai_jobs(args.directory)
    print(json.dumps(result, indent=2))
    return 1 if result["blocker_count"] else 0


def cmd_campaign_status(args: argparse.Namespace) -> int:
    result = status_campaign(args.directory)
    if args.output:
        dump_json(args.output, result)
    else:
        print(json.dumps(result, indent=2))
    return 1 if result["blocking_gap_count"] else 0


def cmd_campaign_finalize(args: argparse.Namespace) -> int:
    result = finalize_campaign(
        args.directory,
        args.external_output,
        force=args.force,
    )
    print(json.dumps(result, indent=2))
    print("The return bundle is sanitized and production_validated remains false.")
    return 1 if result["blocking_gap_count"] or result["conflict_count"] else 0


def cmd_package(args: argparse.Namespace) -> int:
    path = create_zip(args.source, args.output)
    print(f"Created package: {path}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="obsfactory",
        description="Metrology unified observability compiler and package factory",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    validate = sub.add_parser("validate", help="Validate JSON/YAML against a project schema")
    validate.add_argument("kind", choices=sorted(SCHEMA_FILES))
    validate.add_argument("path", type=Path)
    validate.set_defaults(func=cmd_validate)


    questionnaire = sub.add_parser(
        "questionnaire",
        help="Assess the principal technical questionnaire and list blocking unknowns",
    )
    questionnaire.add_argument("path", type=Path)
    questionnaire.add_argument("--output", type=Path)
    questionnaire.set_defaults(func=cmd_questionnaire)

    compile_cmd = sub.add_parser("compile", help="Compile profiles into an intermediate plan")
    compile_cmd.add_argument("profile", type=Path)
    compile_cmd.add_argument("--platform", type=Path)
    compile_cmd.add_argument("--output", type=Path)
    compile_cmd.add_argument("--allow-errors", action="store_true")
    compile_cmd.set_defaults(func=cmd_compile)

    assess_cmd = sub.add_parser("assess", help="Run architecture-readiness assessment")
    assess_cmd.add_argument("profile", type=Path)
    assess_cmd.add_argument("--platform", type=Path)
    assess_cmd.add_argument("--output", type=Path)
    assess_cmd.set_defaults(func=cmd_assess)

    generate = sub.add_parser("generate", help="Generate a transactional onboarding package")
    generate.add_argument("profile", type=Path)
    generate.add_argument("--platform", type=Path)
    generate.add_argument("--output", required=True, type=Path)
    generate.add_argument("--force", action="store_true")
    generate.add_argument("--allow-errors", action="store_true")
    generate.set_defaults(func=cmd_generate)

    diff = sub.add_parser("diff", help="Create a risk-classified semantic configuration diff")
    diff.add_argument("before", type=Path)
    diff.add_argument("after", type=Path)
    diff.add_argument("--output", type=Path)
    diff.set_defaults(func=cmd_diff)

    handoff = sub.add_parser("prepare-handoff", help="Create a sanitized external handoff")
    handoff.add_argument("--discovery", required=True, type=Path)
    handoff.add_argument("--log-features", type=Path)
    handoff.add_argument("--platform", type=Path)
    handoff.add_argument(
        "--acknowledge-policy-review",
        choices=["I_HAVE_APPROVAL"],
    )
    handoff.add_argument("--salt-file", type=Path)
    handoff.add_argument("--force", action="store_true")
    handoff.add_argument("--output", required=True, type=Path)
    handoff.set_defaults(func=cmd_handoff)

    scan = sub.add_parser("scan", help="Screen a directory for prohibited handoff content")
    scan.add_argument("path", type=Path)
    scan.add_argument("--max-file-bytes", type=int, default=5_000_000)
    scan.add_argument("--output", type=Path)
    scan.set_defaults(func=cmd_scan)

    coverage = sub.add_parser("coverage", help="Create observability coverage report")
    coverage.add_argument("profile", type=Path)
    coverage.add_argument("--output", type=Path)
    coverage.set_defaults(func=cmd_coverage)


    campaign = sub.add_parser(
        "campaign",
        help="Run the one-campaign evidence collection and finalization workflow",
    )
    campaign_sub = campaign.add_subparsers(dest="campaign_command", required=True)

    campaign_init = campaign_sub.add_parser(
        "init",
        help="Initialize a campaign from approved defaults and corporate inventory",
    )
    campaign_init.add_argument("--approval", required=True, type=Path)
    campaign_init.add_argument("--inventory", required=True, type=Path)
    campaign_init.add_argument("--output", required=True, type=Path)
    campaign_init.add_argument("--campaign-id")
    campaign_init.add_argument("--title")
    campaign_init.add_argument("--inventory-snapshot-date")
    campaign_init.add_argument("--force", action="store_true")
    campaign_init.set_defaults(func=cmd_campaign_init)

    campaign_runners = campaign_sub.add_parser(
        "build-runners",
        help="Create reviewed local execution bundles for every campaign host",
    )
    campaign_runners.add_argument("directory", type=Path)
    campaign_runners.add_argument("--force", action="store_true")
    campaign_runners.set_defaults(func=cmd_campaign_build_runners)

    campaign_approve = campaign_sub.add_parser(
        "approve-runners",
        help="Apply a reviewed batch approval CSV and rebuild signed host bundles",
    )
    campaign_approve.add_argument("directory", type=Path)
    campaign_approve.add_argument("--approval-csv", required=True, type=Path)
    campaign_approve.set_defaults(func=cmd_campaign_approve_runners)

    campaign_advance = campaign_sub.add_parser(
        "advance",
        help="Auto-ingest completed evidence, build missing artifacts, and report targeted gaps",
    )
    campaign_advance.add_argument("directory", type=Path)
    campaign_advance.add_argument("--external-output", type=Path)
    campaign_advance.add_argument("--force", action="store_true")
    campaign_advance.set_defaults(func=cmd_campaign_advance)

    campaign_ingest = campaign_sub.add_parser(
        "ingest",
        help="Validate and ingest completed forms or evidence envelopes",
    )
    campaign_ingest.add_argument("directory", type=Path)
    campaign_ingest.add_argument("inbox", type=Path)
    campaign_ingest.set_defaults(func=cmd_campaign_ingest)

    campaign_ai = campaign_sub.add_parser(
        "build-ai-jobs",
        help="Create corporate-local AI jobs from approved system log sources",
    )
    campaign_ai.add_argument("directory", type=Path)
    campaign_ai.set_defaults(func=cmd_campaign_build_ai_jobs)

    campaign_status = campaign_sub.add_parser(
        "status",
        help="Report gate-specific completeness and targeted next actions",
    )
    campaign_status.add_argument("directory", type=Path)
    campaign_status.add_argument("--output", type=Path)
    campaign_status.set_defaults(func=cmd_campaign_status)

    campaign_finalize = campaign_sub.add_parser(
        "finalize",
        help="Draft profiles and create the sanitized final-return bundle",
    )
    campaign_finalize.add_argument("directory", type=Path)
    campaign_finalize.add_argument("--external-output", required=True, type=Path)
    campaign_finalize.add_argument("--force", action="store_true")
    campaign_finalize.set_defaults(func=cmd_campaign_finalize)

    package = sub.add_parser("package", help="Create a screened ZIP package")
    package.add_argument("source", type=Path)
    package.add_argument("--output", required=True, type=Path)
    package.set_defaults(func=cmd_package)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        return args.func(args)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
