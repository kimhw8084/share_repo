from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any

from jinja2 import Environment, FileSystemLoader, StrictUndefined

from . import __version__
from .artifact_validation import validate_generated_directory
from .compiler import compile_profile
from .coverage import build_coverage, coverage_markdown
from .io import dump_json, dump_yaml, load_data
from .manifest import write_manifest
from .timeutil import build_date_iso, build_time_iso
from .schema import validate_data


def _env() -> Environment:
    template_dir = Path(__file__).resolve().parent / "templates"
    return Environment(
        loader=FileSystemLoader(str(template_dir)),
        undefined=StrictUndefined,
        trim_blocks=True,
        lstrip_blocks=True,
        autoescape=False,
        keep_trailing_newline=True,
    )


def _render(template: str, destination: Path, context: dict[str, Any]) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(_env().get_template(template).render(**context), encoding="utf-8")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _diagnostics_markdown(plan: dict[str, Any]) -> str:
    lines = [
        "# Compilation Diagnostics",
        "",
        f"System: `{plan['system']['id']}`",
        "",
        "| Severity | Code | Path | Message | Remediation |",
        "|---|---|---|---|---|",
    ]
    for item in plan["diagnostics"]:
        lines.append(
            "| {severity} | `{code}` | `{path}` | {message} | {remediation} |".format(
                severity=item["severity"],
                code=item["code"],
                path=item["path"],
                message=str(item["message"]).replace("|", "\\|"),
                remediation=str(item.get("remediation") or "—").replace("|", "\\|"),
            )
        )
    if not plan["diagnostics"]:
        lines.append("| — | — | — | No diagnostics. | — |")
    lines.extend(["", "Errors block strict generation. Warnings and advisories require review.", ""])
    return "\n".join(lines)


def _unresolved_markdown(plan: dict[str, Any]) -> str:
    lines = [
        "# Unresolved Decisions",
        "",
        "These values were not invented by the generator and must be resolved in the corporate environment.",
        "",
    ]
    for item in plan.get("unresolved_decisions", []):
        lines.append(f"- `{item}`")
    if not plan.get("unresolved_decisions"):
        lines.append("- None identified by the compiler.")
    lines.append("")
    return "\n".join(lines)


def _atomic_install(staging: Path, output: Path, *, force: bool) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    backup: Path | None = None
    if output.exists():
        if not force:
            raise FileExistsError(f"Output exists: {output}; use --force to replace it")
        backup = output.with_name(f".{output.name}.backup-{os.getpid()}")
        if backup.exists():
            shutil.rmtree(backup)
        output.rename(backup)

    try:
        staging.rename(output)
    except Exception:
        if backup is not None and backup.exists() and not output.exists():
            backup.rename(output)
        raise
    else:
        if backup is not None:
            shutil.rmtree(backup, ignore_errors=True)


def generate_package(
    profile_path: Path,
    output: Path,
    *,
    platform_path: Path | None = None,
    force: bool = False,
    strict: bool = True,
) -> Path:
    profile = load_data(profile_path)
    platform = load_data(platform_path) if platform_path else None
    plan = compile_profile(profile, platform, strict=strict)

    build_time = build_time_iso()
    implementation = profile.get("implementation", {})
    approved_roots = sorted({
        probe.get("path")
        for probe in plan["probes"]
        if probe.get("type") in {"file-flow", "log-signature"}
        and probe.get("path")
        and not str(probe.get("path")).startswith("REPLACE_")
    })
    allowed_targets = []
    for probe in plan["probes"]:
        if probe.get("type") not in {"tcp", "http", "tls-certificate"}:
            continue
        host = probe.get("host")
        port = probe.get("port")
        if host and port and not str(host).startswith("REPLACE_"):
            allowed_targets.append(
                {"alias": probe["target_alias"], "host": host, "ports": [int(port)]}
            )
    security = plan["platform"]["security"]
    probe_plan = {
        "schema_version": "2.0.0",
        "system_id": profile["system"]["id"],
        "policy": {
            "max_total_runtime_seconds": 120,
            "max_parallel_probes": 4,
            "worker_startup_grace_seconds": 5,
            "report_error_detail": "code-only",
            "output_file_mode": "0640",
            "lock_stale_seconds": 300,
            "filesystem": {
                "approved_roots": approved_roots,
                "follow_symlinks": False,
                "cross_filesystems": False,
                "max_items": 10000,
                "max_bytes_read": 5000000,
            },
            "network": {
                "enabled": security.get("network_probe_default") == "allow-approved-targets",
                "allowed_targets": allowed_targets,
                "allowed_cidrs": security.get("allowed_network_cidrs", []),
                "allow_loopback": security.get("allow_loopback", False),
                "allow_link_local": security.get("allow_link_local", False),
                "allow_private_addresses": security.get("allow_private_addresses", False),
                "allow_multicast": False,
                "allow_reserved": False,
                "require_cidr_match": True,
                "allow_redirects": False,
            },
        },
        "probes": plan["probes"],
    }
    probe_messages = validate_data("probe-plan", probe_plan)
    if probe_messages:
        raise ValueError("Generated probe plan is invalid:\n- " + "\n- ".join(probe_messages))

    context = {
        "plan": plan,
        "system": plan["system"],
        "platform": plan["system_platform"],
        "organization_platform": plan["platform"],
        "ownership": plan["ownership"],
        "services": plan["services"],
        "dependencies": plan["dependencies"],
        "flows": plan["data_flows"],
        "signals": plan["signals"],
        "logs": plan["logs"],
        "alerts": plan["generated_alerts"],
        "recording_rules": plan["recording_rules"],
        "probes": plan["probes"],
        "probe_plan": probe_plan,
        "capabilities": plan["capabilities"],
        "implementation": plan["implementation"],
        "assumptions": plan["assumptions"],
        "open_questions": plan["open_questions"],
        "generated_date": build_date_iso(),
        "generated_at_utc": build_time,
        "generator_version": __version__,
    }

    output_parent = output.parent.resolve()
    output_parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{output.name}.staging-", dir=output_parent))

    try:
        dump_yaml(staging / "profile.resolved.yml", profile)
        dump_json(staging / "compiled-plan.json", plan)
        if platform_path:
            dump_yaml(staging / "platform.resolved.yml", platform)

        report = build_coverage(plan)
        dump_json(
            staging / "design/telemetry-catalog.json",
            {
                "schema_version": "1.0.0",
                "system_id": profile["system"]["id"],
                "signals": plan["signals"],
                "coverage": report["coverage"],
            },
        )
        dump_json(staging / "design/coverage-report.json", report)
        (staging / "design/coverage-report.md").write_text(
            coverage_markdown(report), encoding="utf-8"
        )
        (staging / "design/compilation-diagnostics.md").write_text(
            _diagnostics_markdown(plan), encoding="utf-8"
        )
        (staging / "design/unresolved-decisions.md").write_text(
            _unresolved_markdown(plan), encoding="utf-8"
        )

        _render("README.md.j2", staging / "README.md", context)
        _render("design.md.j2", staging / "design/observability-design.md", context)
        _render("corporate-values.yml.j2", staging / "TBD-corporate-values.yml", context)
        _render("dashboard-spec.json.j2", staging / "dashboards/dashboard-spec.json", context)
        _render("runbook.md.j2", staging / "runbooks/standard-alert-runbook.md", context)
        _render("test-plan.md.j2", staging / "tests/acceptance-test-plan.md", context)
        _render("deployment.md.j2", staging / "deployment/deployment-and-rollback.md", context)
        _render("probe-plan.json.j2", staging / "probes/probe-plan.json", context)
        _render("handoff-checklist.md.j2", staging / "handoff-checklist.md", context)

        if implementation.get("enable_prometheus", True):
            _render(
                "prometheus/scrape.yml.j2",
                staging / "prometheus/scrape-job.reference.yml",
                context,
            )
            _render(
                "prometheus/recording-rules.yml.j2",
                staging / "prometheus/recording-rules.yml",
                context,
            )
            _render(
                "prometheus/alert-rules.yml.j2",
                staging / "prometheus/alert-rules.candidate.yml",
                context,
            )
            _render(
                "prometheus/production-alert-rules.yml.j2",
                staging / "prometheus/alert-rules.production.yml",
                context,
            )
            _render(
                "prometheus/rule-tests.yml.j2",
                staging / "prometheus/rule-tests.yml",
                context,
            )
            _render(
                "prometheus/metric-contract.json.j2",
                staging / "prometheus/metric-contract.json",
                context,
            )
            _render(
                "prometheus/service-discovery-contract.yml.j2",
                staging / "prometheus/service-discovery-contract.yml",
                context,
            )

        if implementation.get("enable_splunk", True):
            _render(
                "splunk/searches.spl.j2",
                staging / "splunk/searches.reference.spl",
                context,
            )
            _render(
                "splunk/field-model.md.j2",
                staging / "splunk/field-model.md",
                context,
            )
            _render(
                "splunk/query-catalog.json.j2",
                staging / "splunk/query-catalog.json",
                context,
            )
            _render(
                "splunk/cim-mapping.yml.j2",
                staging / "splunk/cim-mapping.yml",
                context,
            )
            _render(
                "splunk/source-contracts.yml.j2",
                staging / "splunk/source-contracts.yml",
                context,
            )

        if implementation.get("enable_otel", False):
            _render(
                "otel/collector.yml.j2",
                staging / "otel/collector.reference.yml",
                context,
            )
        else:
            (staging / "otel").mkdir(parents=True, exist_ok=True)
            (staging / "otel/NOT_ENABLED.md").write_text(
                "# OpenTelemetry Not Enabled\n\n"
                "The system profile did not enable OpenTelemetry generation. "
                "Company Prometheus/Splunk integrations remain the active design path.\n",
                encoding="utf-8",
            )

        provenance = {
            "schema_version": "1.0.0",
            "generator": "metrology-observability-factory",
            "generator_version": __version__,
            "generated_at_utc": build_time,
            "profile_path": profile_path.name,
            "profile_file_sha256": _sha256(profile_path),
            "profile_content_sha256": plan["profile_sha256"],
            "platform_path": platform_path.name if platform_path else None,
            "platform_file_sha256": _sha256(platform_path) if platform_path else None,
            "platform_content_sha256": plan["platform_sha256"],
            "strict_compilation": strict,
            "source_date_epoch_used": bool(os.environ.get("SOURCE_DATE_EPOCH")),
            "production_validated": False,
            "human_review_required": True,
        }
        dump_json(staging / "provenance.json", provenance)

        structural_errors, _ = validate_generated_directory(
            staging,
            require_manifest=False,
        )
        if structural_errors:
            raise ValueError(
                "Generated package failed pre-install structural validation:\n- "
                + "\n- ".join(structural_errors)
            )

        write_manifest(staging)
        manifest_errors, _ = validate_generated_directory(
            staging,
            require_manifest=True,
        )
        if manifest_errors:
            raise ValueError(
                "Generated package failed manifest validation:\n- "
                + "\n- ".join(manifest_errors)
            )

        _atomic_install(staging, output, force=force)
        return output
    except Exception:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        raise
