from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml


class InputError(ValueError):
    pass


def load_data(path: Path) -> Any:
    if not path.exists():
        raise InputError(f"Input does not exist: {path}")
    suffix = path.suffix.lower()
    text = path.read_text(encoding="utf-8")
    try:
        if suffix == ".json":
            return json.loads(text)
        if suffix in {".yaml", ".yml"}:
            return yaml.safe_load(text)
    except Exception as exc:
        raise InputError(f"Could not parse {path}: {exc}") from exc
    raise InputError(f"Unsupported input type {suffix}; use JSON or YAML")


def dump_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=False) + "\n", encoding="utf-8")


def dump_yaml(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump(value, sort_keys=False, default_flow_style=False),
        encoding="utf-8",
    )


def read_text(path: Path, *, max_bytes: int = 5_000_000) -> str:
    size = path.stat().st_size
    if size > max_bytes:
        raise InputError(f"File exceeds {max_bytes} bytes: {path}")
    return path.read_text(encoding="utf-8", errors="replace")
