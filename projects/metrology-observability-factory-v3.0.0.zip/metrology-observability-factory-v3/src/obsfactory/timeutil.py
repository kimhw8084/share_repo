from __future__ import annotations

from datetime import datetime, timezone
import os


def build_time_utc() -> datetime:
    source_epoch = os.environ.get("SOURCE_DATE_EPOCH")
    if source_epoch:
        try:
            return datetime.fromtimestamp(int(source_epoch), timezone.utc)
        except (TypeError, ValueError, OSError) as exc:
            raise ValueError("SOURCE_DATE_EPOCH must be an integer Unix timestamp") from exc
    return datetime.now(timezone.utc)


def build_time_iso() -> str:
    return build_time_utc().isoformat()


def build_date_iso() -> str:
    return build_time_utc().date().isoformat()
