from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .constants import (
    FORBIDDEN_HIGH_CARDINALITY_LABELS,
    PROM_LABEL_RE,
    PROM_METRIC_RE,
)


@dataclass(frozen=True)
class MetricIssue:
    metric: str
    message: str


def validate_metric_name(name: str) -> list[MetricIssue]:
    issues: list[MetricIssue] = []
    if not PROM_METRIC_RE.fullmatch(name):
        issues.append(MetricIssue(name, "invalid Prometheus metric name"))
    if name.startswith("__"):
        issues.append(MetricIssue(name, "double-underscore names are reserved"))
    return issues


def validate_labels(metric: str, labels: Iterable[str]) -> list[MetricIssue]:
    issues: list[MetricIssue] = []
    for label in labels:
        if not PROM_LABEL_RE.fullmatch(label):
            issues.append(MetricIssue(metric, f"invalid label name: {label}"))
        if label.lower() in FORBIDDEN_HIGH_CARDINALITY_LABELS:
            issues.append(
                MetricIssue(
                    metric,
                    f"label '{label}' is prohibited by the default cardinality policy",
                )
            )
    return issues


def validate_metric_catalog(signals: list[dict]) -> list[MetricIssue]:
    issues: list[MetricIssue] = []
    seen = set()
    for signal in signals:
        if signal.get("signal_type") != "metric":
            continue
        name = signal.get("name", "")
        issues.extend(validate_metric_name(name))
        issues.extend(validate_labels(name, signal.get("labels", [])))
        if name in seen:
            issues.append(MetricIssue(name, "duplicate metric name"))
        seen.add(name)
        metric_type = signal.get("metric_type")
        if name.endswith("_total") and metric_type not in {"counter", None}:
            issues.append(MetricIssue(name, "_total metrics should be counters"))
        unit = signal.get("unit")
        if unit == "seconds" and not (
            name.endswith("_seconds")
            or name.endswith("_seconds_total")
            or "_seconds_" in name
        ):
            issues.append(MetricIssue(name, "seconds unit should appear in metric name"))
        if unit == "bytes" and "_bytes" not in name:
            issues.append(MetricIssue(name, "bytes unit should appear in metric name"))
    return issues
