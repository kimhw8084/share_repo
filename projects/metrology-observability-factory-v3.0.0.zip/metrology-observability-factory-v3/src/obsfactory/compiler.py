from __future__ import annotations

from collections import Counter
import hashlib
import json
import math
import re
from typing import Any, Iterable

from . import __version__
from .constants import FORBIDDEN_HIGH_CARDINALITY_LABELS
from .diagnostics import CompilationError, Diagnostic, Severity, has_errors
from .metrics import validate_metric_catalog
from .schema import validate_data


PROMQL_METRIC_TOKEN = re.compile(r"(?<![A-Za-z0-9_:])([A-Za-z_:][A-Za-z0-9_:]*)(?![A-Za-z0-9_:])")
PROMQL_KEYWORDS = {
    "and", "or", "unless", "by", "without", "on", "ignoring", "group_left",
    "group_right", "bool", "offset", "sum", "min", "max", "avg", "count",
    "topk", "bottomk", "quantile", "count_values", "stddev", "stdvar",
    "rate", "irate", "increase", "delta", "idelta", "changes", "resets",
    "absent", "absent_over_time", "min_over_time", "max_over_time",
    "avg_over_time", "sum_over_time", "count_over_time", "last_over_time",
    "clamp_min", "clamp_max", "time", "vector", "scalar", "label_replace",
    "histogram_quantile",
}

STANDARD_RECORDING_METRICS = {
    "metrology_system:functional_up:min",
    "metrology_system:transactions_total:rate5m",
    "metrology_system:transaction_error_ratio:rate5m",
    "metrology_system:data_age_seconds:max",
}

CAPABILITY_CATEGORIES = (
    "host_health",
    "functional_availability",
    "traffic",
    "errors",
    "latency",
    "saturation",
    "freshness",
    "backlog",
    "dependencies",
    "change_identity",
    "telemetry_path",
)


def _stable_hash(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _duplicates(items: Iterable[str]) -> list[str]:
    counts = Counter(items)
    return sorted(key for key, count in counts.items() if count > 1)


def _is_unresolved(value: Any) -> bool:
    return value is None or (isinstance(value, str) and value.strip().upper() == "TBD")


def _estimate_cardinality(signal: dict[str, Any]) -> int | None:
    explicit = signal.get("cardinality_limit")
    if isinstance(explicit, int):
        return explicit
    limits = signal.get("label_value_limits") or {}
    labels = signal.get("labels") or []
    if labels and all(label in limits for label in labels):
        value = 1
        for label in labels:
            value *= int(limits[label])
        return value
    expected = signal.get("expected_cardinality")
    return {"low": 20, "bounded": 200, "high": 2000}.get(expected)


def _metric_tokens(expression: str) -> set[str]:
    # Remove strings, label matchers, and range selectors before extracting
    # potential metric identifiers. This is intentionally conservative and not
    # a replacement for promtool's PromQL parser.
    sanitized = re.sub(r'"(?:\\.|[^"\\])*"', '""', expression)
    sanitized = re.sub(r"\{[^{}]*\}", "", sanitized)
    sanitized = re.sub(r"\[[^\]]*\]", "", sanitized)
    tokens = set()
    for token in PROMQL_METRIC_TOKEN.findall(sanitized):
        if token in PROMQL_KEYWORDS:
            continue
        if token[0].isdigit():
            continue
        if token in {"m", "s", "h", "d", "w", "y"}:
            continue
        tokens.add(token)
    return tokens


def _platform_default() -> dict[str, Any]:
    return {
        "schema_version": "1.0.0",
        "organization": {"id": "unknown", "site": "TBD", "owner_team": None},
        "prometheus": {
            "enabled": True,
            "distribution": None,
            "version": None,
            "service_discovery": "unknown",
            "rule_validation": "unknown",
            "dashboard_backend": None,
            "alertmanager_managed": None,
            "max_series_per_system": 10000,
            "max_labels_per_metric": 10,
            "allowed_exporters": [],
            "external_labels": {},
        },
        "splunk": {
            "enabled": True,
            "product": "unknown",
            "version": None,
            "ingestion_modes": ["unknown"],
            "cim_policy": "unknown",
            "default_index": None,
            "default_retention_class": None,
            "scheduled_search_cost_review": None,
            "dashboard_backend": None,
        },
        "opentelemetry": {
            "allowed": False,
            "distribution": "unknown",
            "version": None,
            "modes": [],
            "components": {
                "receivers": [],
                "processors": [],
                "exporters": [],
                "extensions": [],
            },
        },
        "security": {
            "external_handoff_allowed": False,
            "credential_sources": [],
            "network_probe_default": "deny",
            "allowed_network_cidrs": [],
            "allow_private_addresses": True,
            "allow_loopback": False,
            "allow_link_local": False,
        },
        "delivery": {
            "config_delivery": "unknown",
            "canary_required": True,
            "production_approval_required": True,
            "supported_environments": ["development", "test", "staging", "production"],
        },
    }


def _check_unique_ids(profile: dict[str, Any], diagnostics: list[Diagnostic]) -> None:
    collections = {
        "services": profile.get("services", []),
        "dependencies": profile.get("dependencies", []),
        "data_flows": profile.get("data_flows", []),
        "signals": profile.get("signals", []),
        "logs": profile.get("logs", []),
        "alerts": profile.get("alerts", []),
        "exceptions": profile.get("exceptions", []),
    }
    for name, items in collections.items():
        duplicates = _duplicates(str(item.get("id")) for item in items if item.get("id"))
        for duplicate in duplicates:
            diagnostics.append(
                Diagnostic(
                    "PROFILE_DUPLICATE_ID",
                    Severity.ERROR,
                    f"$.{name}",
                    f"Duplicate ID '{duplicate}'.",
                    "Use stable unique IDs within each collection.",
                )
            )

    for flow_index, flow in enumerate(profile.get("data_flows", [])):
        duplicates = _duplicates(
            str(stage.get("id")) for stage in flow.get("stages", []) if stage.get("id")
        )
        for duplicate in duplicates:
            diagnostics.append(
                Diagnostic(
                    "FLOW_DUPLICATE_STAGE",
                    Severity.ERROR,
                    f"$.data_flows[{flow_index}].stages",
                    f"Duplicate stage ID '{duplicate}'.",
                )
            )


def _check_ownership(profile: dict[str, Any], diagnostics: list[Diagnostic]) -> None:
    system = profile["system"]
    ownership = profile["ownership"]
    production_like = system.get("environment") == "production" or system.get("lifecycle") == "production"
    for field in ("owner_team", "primary_owner", "backup_owner"):
        if _is_unresolved(ownership.get(field)):
            diagnostics.append(
                Diagnostic(
                    "OWNERSHIP_UNRESOLVED",
                    Severity.ERROR if production_like else Severity.WARNING,
                    f"$.ownership.{field}",
                    f"{field} is unresolved.",
                    "Assign accountable primary and backup ownership before production enablement.",
                )
            )
    if ownership.get("primary_owner") == ownership.get("backup_owner") and not _is_unresolved(
        ownership.get("primary_owner")
    ):
        diagnostics.append(
            Diagnostic(
                "OWNERSHIP_NO_INDEPENDENT_BACKUP",
                Severity.WARNING,
                "$.ownership.backup_owner",
                "Primary and backup owner are the same.",
                "Assign an independent backup to reduce knowledge concentration.",
            )
        )



def _check_dependencies(
    profile: dict[str, Any],
    diagnostics: list[Diagnostic],
) -> list[dict[str, Any]]:
    signal_ids = {
        str(signal.get("id"))
        for signal in profile.get("signals", [])
        if signal.get("id") and signal.get("enabled", True)
    }
    normalized: list[dict[str, Any]] = []

    for index, source in enumerate(profile.get("dependencies", [])):
        dependency = dict(source)
        status = dependency.get("monitoring_status", "candidate")
        dependency["monitoring_status"] = status
        signal_id = dependency.get("signal_id")
        path = f"$.dependencies[{index}]"

        if status in {"candidate", "validated"}:
            if _is_unresolved(signal_id):
                diagnostics.append(
                    Diagnostic(
                        "DEPENDENCY_SIGNAL_UNRESOLVED",
                        Severity.ERROR if status == "validated" else Severity.WARNING,
                        f"{path}.signal_id",
                        f"Dependency '{dependency['id']}' has {status} monitoring without a signal ID.",
                        "Reference a declared bounded signal or mark the dependency uninstrumented.",
                    )
                )
            elif str(signal_id) not in signal_ids:
                diagnostics.append(
                    Diagnostic(
                        "DEPENDENCY_SIGNAL_NOT_DECLARED",
                        Severity.ERROR if status == "validated" else Severity.WARNING,
                        f"{path}.signal_id",
                        f"Dependency '{dependency['id']}' references undeclared signal '{signal_id}'.",
                        "Declare and validate the signal before production promotion.",
                    )
                )

        if status == "validated" and _is_unresolved(dependency.get("evidence_reference")):
            diagnostics.append(
                Diagnostic(
                    "DEPENDENCY_VALIDATION_EVIDENCE_MISSING",
                    Severity.ERROR,
                    f"{path}.evidence_reference",
                    f"Validated dependency '{dependency['id']}' lacks evidence.",
                    "Reference controlled failure, recovery, and false-positive validation.",
                )
            )

        if status == "exception" and _is_unresolved(dependency.get("exception_reference")):
            diagnostics.append(
                Diagnostic(
                    "DEPENDENCY_EXCEPTION_REFERENCE_MISSING",
                    Severity.ERROR,
                    f"{path}.exception_reference",
                    f"Dependency '{dependency['id']}' is excepted without an approved exception reference.",
                    "Record owner, alternative control, review date, and expiry.",
                )
            )

        if dependency.get("criticality") == "required" and status == "uninstrumented":
            diagnostics.append(
                Diagnostic(
                    "REQUIRED_DEPENDENCY_UNINSTRUMENTED",
                    Severity.WARNING,
                    path,
                    f"Required dependency '{dependency['id']}' has no declared monitoring.",
                    "Add a bounded signal or record an approved exception.",
                )
            )

        if dependency.get("probe_type") == "query-template":
            diagnostics.append(
                Diagnostic(
                    "DATABASE_PROBE_EXTERNAL_MANIFEST_REQUIRED",
                    Severity.ADVISORY,
                    f"{path}.probe_type",
                    f"Database dependency '{dependency['id']}' requires the guarded external DB manifest workflow.",
                    "Create an approved query manifest; the generic probe supervisor will not execute SQL.",
                )
            )

        normalized.append(dependency)

    return normalized

def _check_signals(
    profile: dict[str, Any],
    platform: dict[str, Any],
    diagnostics: list[Diagnostic],
) -> tuple[list[dict[str, Any]], dict[str, bool], dict[str, Any]]:
    signals = [dict(item) for item in profile.get("signals", []) if item.get("enabled", True)]
    for issue in validate_metric_catalog(signals):
        diagnostics.append(
            Diagnostic("METRIC_CONTRACT", Severity.ERROR, "$.signals", f"{issue.metric}: {issue.message}")
        )

    max_labels = int(platform["prometheus"].get("max_labels_per_metric", 10))
    max_series = int(platform["prometheus"].get("max_series_per_system", 10000))
    capabilities = {category: False for category in CAPABILITY_CATEGORIES}

    for index, signal in enumerate(signals):
        path = f"$.signals[{index}]"
        categories = list(signal.get("coverage_categories") or [])
        category = signal.get("coverage_category", "other")
        if category not in categories:
            categories.append(category)
        for item in categories:
            if item in capabilities:
                capabilities[item] = True
        labels = signal.get("labels", [])
        if len(labels) > max_labels:
            diagnostics.append(
                Diagnostic(
                    "METRIC_TOO_MANY_LABELS",
                    Severity.ERROR,
                    f"{path}.labels",
                    f"Metric has {len(labels)} labels; platform limit is {max_labels}.",
                )
            )
        forbidden = sorted(
            label for label in labels if label.lower() in FORBIDDEN_HIGH_CARDINALITY_LABELS
        )
        if forbidden:
            diagnostics.append(
                Diagnostic(
                    "METRIC_FORBIDDEN_LABEL",
                    Severity.ERROR,
                    f"{path}.labels",
                    f"Forbidden high-cardinality labels: {', '.join(forbidden)}.",
                )
            )
        estimate = _estimate_cardinality(signal)
        signal["estimated_series"] = estimate
        if estimate is None:
            diagnostics.append(
                Diagnostic(
                    "METRIC_CARDINALITY_UNKNOWN",
                    Severity.WARNING,
                    path,
                    f"Series cardinality for '{signal.get('name')}' cannot be estimated.",
                    "Set cardinality_limit or label_value_limits.",
                )
            )
        elif estimate > max_series:
            diagnostics.append(
                Diagnostic(
                    "METRIC_CARDINALITY_BUDGET_EXCEEDED",
                    Severity.ERROR,
                    path,
                    f"Estimated {estimate} series exceeds platform budget {max_series}.",
                    "Reduce dimensions, bound values, or keep detailed identifiers in Splunk.",
                )
            )
        if signal.get("required") and signal.get("validation_status", "unvalidated") == "unvalidated":
            diagnostics.append(
                Diagnostic(
                    "REQUIRED_SIGNAL_UNVALIDATED",
                    Severity.WARNING,
                    path,
                    f"Required signal '{signal.get('id')}' is unvalidated.",
                    "Attach synthetic/failure test evidence before production alerting.",
                )
            )
    known_estimates = [
        int(signal["estimated_series"])
        for signal in signals
        if signal.get("estimated_series") is not None
    ]
    unknown_signal_ids = [
        str(signal.get("id"))
        for signal in signals
        if signal.get("estimated_series") is None
    ]
    estimated_total = sum(known_estimates)
    within_budget = estimated_total <= max_series
    if not within_budget:
        diagnostics.append(
            Diagnostic(
                "SYSTEM_CARDINALITY_BUDGET_EXCEEDED",
                Severity.ERROR,
                "$.signals",
                f"Combined estimated series {estimated_total} exceeds the per-system platform budget {max_series}.",
                "Reduce label dimensions, split bounded ownership domains only when justified, or keep detail in Splunk.",
            )
        )
    cardinality = {
        "platform_limit": max_series,
        "estimated_total": estimated_total,
        "unknown_signal_ids": unknown_signal_ids,
        "within_declared_budget": within_budget and not unknown_signal_ids,
    }
    return signals, capabilities, cardinality


def _check_flows(profile: dict[str, Any], diagnostics: list[Diagnostic]) -> None:
    for flow_index, flow in enumerate(profile.get("data_flows", [])):
        high = {field.lower() for field in flow.get("high_cardinality_fields", [])}
        for signal_index, signal in enumerate(profile.get("signals", [])):
            collision = high.intersection(label.lower() for label in signal.get("labels", []))
            if collision:
                diagnostics.append(
                    Diagnostic(
                        "FLOW_IDENTIFIER_USED_AS_METRIC_LABEL",
                        Severity.ERROR,
                        f"$.signals[{signal_index}].labels",
                        f"Data-flow high-cardinality fields used as labels: {', '.join(sorted(collision))}.",
                    )
                )
        for stage_index, stage in enumerate(flow.get("stages", [])):
            if _is_unresolved(stage.get("evidence_source")):
                diagnostics.append(
                    Diagnostic(
                        "FLOW_STAGE_EVIDENCE_UNRESOLVED",
                        Severity.ERROR,
                        f"$.data_flows[{flow_index}].stages[{stage_index}].evidence_source",
                        "Stage evidence source is unresolved.",
                    )
                )
            if all(
                stage.get(field) is None
                for field in (
                    "freshness_threshold_seconds",
                    "backlog_threshold",
                    "latency_objective_seconds",
                )
            ):
                diagnostics.append(
                    Diagnostic(
                        "FLOW_STAGE_NOT_MEASURABLE",
                        Severity.ADVISORY,
                        f"$.data_flows[{flow_index}].stages[{stage_index}]",
                        "Stage has no freshness, backlog, or latency objective.",
                    )
                )


def _recording_rules(capabilities: dict[str, bool]) -> list[dict[str, str]]:
    rules: list[dict[str, str]] = []
    if capabilities["functional_availability"]:
        rules.append(
            {
                "record": "metrology_system:functional_up:min",
                "expr": "min by (metrology_system) (metrology_functional_up)",
            }
        )
    if capabilities["traffic"]:
        rules.append(
            {
                "record": "metrology_system:transactions_total:rate5m",
                "expr": (
                    "sum by (metrology_system, flow, stage, outcome) "
                    "(rate(metrology_transactions_total[5m]))"
                ),
            }
        )
    if capabilities["traffic"] and capabilities["errors"]:
        rules.append(
            {
                "record": "metrology_system:transaction_error_ratio:rate5m",
                "expr": (
                    'sum by (metrology_system, flow, stage) '
                    '(rate(metrology_transactions_total{outcome="error"}[5m])) '
                    '/ clamp_min(sum by (metrology_system, flow, stage) '
                    "(rate(metrology_transactions_total[5m])), 0.000001)"
                ),
            }
        )
    if capabilities["freshness"]:
        rules.append(
            {
                "record": "metrology_system:data_age_seconds:max",
                "expr": "time() - metrology_last_success_unixtime_seconds",
            }
        )
    return rules


def _generated_alerts(
    profile: dict[str, Any],
    capabilities: dict[str, bool],
    diagnostics: list[Diagnostic],
) -> list[dict[str, Any]]:
    system = profile["system"]
    ownership = profile["ownership"]
    system_id = system["id"]
    owner_team = ownership["owner_team"]
    implementation = profile.get("implementation", {})
    generated_lifecycle = implementation.get("generated_alert_lifecycle", "draft")
    generated_validation = implementation.get(
        "generated_alert_validation_status",
        "unvalidated",
    )
    if generated_lifecycle == "production":
        production_requirements = [
            (
                implementation.get("production_alerts_allowed", False) is True,
                "GENERATED_PRODUCTION_ALERTS_NOT_ALLOWED",
                "$.implementation.production_alerts_allowed",
                "Generated alerts request production lifecycle without explicit permission.",
                "Set permission only after corporate alert-route approval.",
            ),
            (
                generated_validation in {"operator-accepted", "production-validated"},
                "GENERATED_PRODUCTION_ALERTS_UNVALIDATED",
                "$.implementation.generated_alert_validation_status",
                "Generated production alerts require fire/clear and operator validation.",
                "Attach controlled test and operator acceptance evidence.",
            ),
            (
                not _is_unresolved(implementation.get("generated_alert_evidence_reference")),
                "GENERATED_PRODUCTION_ALERTS_EVIDENCE_MISSING",
                "$.implementation.generated_alert_evidence_reference",
                "Generated production alerts require a validation evidence reference.",
                "Reference the approved fire/clear and threshold-validation record.",
            ),
            (
                not _is_unresolved(implementation.get("production_approval_reference")),
                "PRODUCTION_APPROVAL_REFERENCE_MISSING",
                "$.implementation.production_approval_reference",
                "Production alert generation requires an approval reference.",
                "Record the corporate approval/change reference.",
            ),
            (
                not _is_unresolved(implementation.get("operator_acceptance_reference")),
                "OPERATOR_ACCEPTANCE_REFERENCE_MISSING",
                "$.implementation.operator_acceptance_reference",
                "Production alert generation requires operator acceptance evidence.",
                "Reference the engineer/technician workflow acceptance record.",
            ),
            (
                not _is_unresolved(implementation.get("rollback_validation_reference")),
                "ROLLBACK_VALIDATION_REFERENCE_MISSING",
                "$.implementation.rollback_validation_reference",
                "Production alert generation requires rollback validation evidence.",
                "Reference the approved rollback test or change plan.",
            ),
            (
                system.get("lifecycle") == "production",
                "SYSTEM_NOT_PRODUCTION",
                "$.system.lifecycle",
                "Production alert rules cannot be emitted for a non-production lifecycle system.",
                "Promote the system lifecycle only through the approved readiness process.",
            ),
            (
                not _is_unresolved(ownership.get("primary_owner"))
                and not _is_unresolved(ownership.get("backup_owner")),
                "PRODUCTION_OWNERSHIP_UNRESOLVED",
                "$.ownership",
                "Production alert rules require named primary and backup ownership.",
                "Assign accountable production support coverage.",
            ),
        ]
        for passed, code, path, message, remediation in production_requirements:
            if not passed:
                diagnostics.append(
                    Diagnostic(code, Severity.ERROR, path, message, remediation)
                )
    alerts: list[dict[str, Any]] = []

    if capabilities["telemetry_path"]:
        alerts.extend(
            [
                {
                    "id": "MetrologyTelemetryMissing",
                    "expr": f'absent(metrology_probe_success{{metrology_system="{system_id}"}})',
                    "for": "10m",
                    "severity": "warning",
                    "owner_team": owner_team,
                    "lifecycle": generated_lifecycle,
                    "validation_status": generated_validation,
                    "kind": "telemetry-missing",
                    "summary": f"Observability telemetry is missing for {system['display_name']}",
                    "impact": "Monitoring blind spot; production impact is not established.",
                    "first_check": "Verify probe/collector state and the site Prometheus scrape target.",
                    "runbook_ref": "runbooks/standard-alert-runbook.md#metrologytelemetrymissing",
                    "recovery_condition": "Telemetry resumes and current probe executions succeed.",
                },
                {
                    "id": "MetrologyProbeStale",
                    "expr": (
                        f'time() - max(metrology_probe_last_run_unixtime_seconds'
                        f'{{metrology_system="{system_id}"}}) > 300'
                    ),
                    "for": "5m",
                    "severity": "warning",
                    "owner_team": owner_team,
                    "lifecycle": generated_lifecycle,
                    "validation_status": generated_validation,
                    "kind": "telemetry-stale",
                    "summary": f"Observability probes are stale for {system['display_name']}",
                    "impact": "Published probe metrics may no longer represent current state.",
                    "first_check": "Verify scheduler, output timestamp, collector scrape, and probe report.",
                    "runbook_ref": "runbooks/standard-alert-runbook.md#metrologytelemetrymissing",
                    "recovery_condition": "Probe timestamps update continuously and executions succeed.",
                },
            ]
        )
    if capabilities["functional_availability"]:
        alerts.append(
            {
                "id": "MetrologyFunctionalUnavailable",
                "expr": (
                    f'min_over_time(metrology_functional_up'
                    f'{{metrology_system="{system_id}"}}[5m]) == 0'
                ),
                "for": "5m",
                "severity": "high",
                "owner_team": owner_team,
                "lifecycle": generated_lifecycle,
                "validation_status": generated_validation,
                "kind": "functional",
                "summary": f"Functional health check is failing for {system['display_name']}",
                "impact": system["business_function"],
                "first_check": "Open the troubleshooting view and preserve evidence before recovery.",
                "runbook_ref": "runbooks/standard-alert-runbook.md#metrologyfunctionalunavailable",
                "recovery_condition": "Functional check returns healthy and successful transactions resume.",
            }
        )
    for flow in profile.get("data_flows", []):
        for stage in flow.get("stages", []):
            suffix = re.sub(r"[^A-Za-z0-9]", "_", f"{flow['id']}_{stage['id']}")
            if capabilities["freshness"] and stage.get("freshness_threshold_seconds") is not None:
                alerts.append(
                    {
                        "id": f"MetrologyDataStale_{suffix}",
                        "expr": (
                            f'time() - metrology_last_success_unixtime_seconds'
                            f'{{metrology_system="{system_id}",flow="{flow["id"]}",'
                            f'stage="{stage["id"]}"}} > {stage["freshness_threshold_seconds"]}'
                        ),
                        "for": "5m",
                        "severity": "high",
                        "owner_team": owner_team,
                        "lifecycle": generated_lifecycle,
                        "validation_status": generated_validation,
                        "kind": "freshness",
                        "flow": flow["id"],
                        "stage": stage["id"],
                        "summary": f"Data is stale at {flow['id']}/{stage['id']}",
                        "impact": flow.get("failure_impact") or "Production impact requires verification.",
                        "first_check": "Compare input, completion, backlog, dependency, and log evidence.",
                        "runbook_ref": "runbooks/standard-alert-runbook.md#metrologydatastale",
                        "recovery_condition": "Data age returns below the validated threshold and remains stable.",
                    }
                )
            if capabilities["backlog"] and stage.get("backlog_threshold") is not None:
                alerts.append(
                    {
                        "id": f"MetrologyBacklogHigh_{suffix}",
                        "expr": (
                            f'metrology_backlog_items{{metrology_system="{system_id}",'
                            f'flow="{flow["id"]}",stage="{stage["id"]}"}} '
                            f'> {stage["backlog_threshold"]}'
                        ),
                        "for": "5m",
                        "severity": "warning",
                        "owner_team": owner_team,
                        "lifecycle": generated_lifecycle,
                        "validation_status": generated_validation,
                        "kind": "backlog",
                        "flow": flow["id"],
                        "stage": stage["id"],
                        "summary": f"Backlog exceeds the candidate threshold at {flow['id']}/{stage['id']}",
                        "impact": "Processing delay may be developing; verify trend and downstream impact.",
                        "first_check": "Compare arrival rate, completion rate, oldest age, and dependencies.",
                        "runbook_ref": "runbooks/standard-alert-runbook.md#metrologybackloghigh",
                        "recovery_condition": "Backlog and oldest age remain below validated clear thresholds.",
                    }
                )
    if capabilities["dependencies"]:
        for dependency in profile.get("dependencies", []):
            if dependency.get("criticality") != "required":
                continue
            if dependency.get("monitoring_status", "candidate") not in {
                "candidate",
                "validated",
            }:
                continue
            suffix = re.sub(r"[^A-Za-z0-9]", "_", dependency["id"])
            alerts.append(
                {
                    "id": f"MetrologyDependencyUnavailable_{suffix}",
                    "expr": (
                        f'max_over_time(metrology_dependency_up'
                        f'{{metrology_system="{system_id}",dependency="{dependency["id"]}"}}'
                        f'[5m]) == 0'
                    ),
                    "for": "5m",
                    "severity": "high",
                    "owner_team": owner_team,
                    "lifecycle": generated_lifecycle,
                    "validation_status": generated_validation,
                    "kind": "dependency",
                    "dependency": dependency["id"],
                    "summary": f"Required dependency {dependency['id']} is unavailable",
                    "impact": dependency["health_evidence"],
                    "first_check": "Distinguish shared dependency failure from local DNS, route, account, certificate, or probe failure.",
                    "runbook_ref": "runbooks/standard-alert-runbook.md#metrologydependencyunavailable",
                    "recovery_condition": "Dependency probe and functional transaction both succeed.",
                }
            )

    known_metrics = {
        signal["name"] for signal in profile.get("signals", [])
        if signal.get("signal_type") == "metric" and signal.get("enabled", True)
    } | {rule["record"] for rule in _recording_rules(capabilities)}

    for index, alert in enumerate(profile.get("alerts", [])):
        if not alert.get("enabled", True):
            continue
        lifecycle = alert.get("lifecycle", "draft")
        validation_status = alert.get("validation_status", "unvalidated")
        if lifecycle == "production":
            checks = [
                (
                    validation_status in {"operator-accepted", "production-validated"},
                    "PRODUCTION_ALERT_NOT_VALIDATED",
                    f"Production alert '{alert['id']}' lacks operator/fire-clear validation.",
                    "Set production lifecycle only after controlled fire/clear and operator acceptance.",
                ),
                (
                    not _is_unresolved(alert.get("evidence_reference")),
                    "PRODUCTION_ALERT_EVIDENCE_MISSING",
                    f"Production alert '{alert['id']}' lacks a validation evidence reference.",
                    "Reference threshold, fire/clear, and false-positive validation evidence.",
                ),
                (
                    not _is_unresolved(alert.get("production_approval_reference"))
                    or not _is_unresolved(implementation.get("production_approval_reference")),
                    "PRODUCTION_ALERT_APPROVAL_MISSING",
                    f"Production alert '{alert['id']}' lacks a production approval reference.",
                    "Record the approved corporate change or alert-promotion decision.",
                ),
                (
                    not _is_unresolved(alert.get("operator_acceptance_reference"))
                    or not _is_unresolved(implementation.get("operator_acceptance_reference")),
                    "PRODUCTION_ALERT_OPERATOR_ACCEPTANCE_MISSING",
                    f"Production alert '{alert['id']}' lacks operator acceptance evidence.",
                    "Reference the accepted engineer/technician response workflow.",
                ),
                (
                    system.get("lifecycle") == "production",
                    "PRODUCTION_ALERT_SYSTEM_NOT_PRODUCTION",
                    f"Production alert '{alert['id']}' belongs to a non-production lifecycle system.",
                    "Keep the alert in observation until the system lifecycle is approved.",
                ),
            ]
            for passed, code, message, remediation in checks:
                if not passed:
                    diagnostics.append(
                        Diagnostic(
                            code,
                            Severity.ERROR,
                            f"$.alerts[{index}]",
                            message,
                            remediation,
                        )
                    )
        expression_metrics = {
            token for token in _metric_tokens(alert.get("condition", ""))
            if token.startswith("metrology")
        }
        unresolved = sorted(expression_metrics - known_metrics - STANDARD_RECORDING_METRICS)
        if unresolved:
            diagnostics.append(
                Diagnostic(
                    "ALERT_UNKNOWN_METRIC",
                    Severity.ERROR if lifecycle == "production" else Severity.WARNING,
                    f"$.alerts[{index}].condition",
                    f"Alert references metrics not declared by the profile/compiler: {', '.join(unresolved)}.",
                    "Declare the signal or document and validate the external exporter contract.",
                )
            )
        alerts.append(
            {
                "id": alert["id"],
                "expr": alert["condition"],
                "for": alert["for_duration"],
                "severity": alert["severity"],
                "owner_team": owner_team,
                "kind": "custom",
                "title": alert["title"],
                "symptom": alert["symptom"],
                "impact": alert.get("impact", alert["symptom"]),
                "runbook_ref": alert["runbook_ref"],
                "recovery_condition": alert["recovery_condition"],
                "lifecycle": lifecycle,
                "validation_status": validation_status,
            }
        )
    return alerts


def _build_probes(profile: dict[str, Any], platform: dict[str, Any]) -> list[dict[str, Any]]:
    probes: list[dict[str, Any]] = [
        {"id": "probe-self-health", "type": "self", "enabled": True, "timeout_seconds": 5}
    ]
    for flow in profile.get("data_flows", []):
        for stage in flow.get("stages", []):
            evidence = stage.get("evidence_source", "").lower()
            if evidence.startswith("file"):
                probes.append(
                    {
                        "id": f"{flow['id']}-{stage['id']}-file",
                        "type": "file-flow",
                        "enabled": False,
                        "timeout_seconds": 15,
                        "path_alias": f"{flow['id']}-{stage['id']}",
                        "path": "REPLACE_WITH_APPROVED_PATH",
                        "flow": flow["id"],
                        "stage": stage["id"],
                        "max_items": 10000,
                        "suffixes": [],
                    }
                )
    for dependency in profile.get("dependencies", []):
        approved = dependency.get("network_probe_approved") is True
        probe_type = dependency.get("probe_type")
        common = {
            "id": f"{dependency['id']}-{probe_type}",
            "enabled": False,
            "timeout_seconds": 5,
            "target_alias": dependency["id"],
        }
        if probe_type == "tcp-connect":
            probes.append({**common, "type": "tcp", "host": "REPLACE_WITH_APPROVED_HOST", "port": 1})
        elif probe_type == "http-head":
            probes.append(
                {
                    **common,
                    "type": "http",
                    "url": "https://REPLACE_WITH_APPROVED_HOST/",
                    "method": "HEAD",
                    "expected_statuses": [200, 204],
                    "max_response_bytes": 0,
                }
            )
        elif probe_type == "tls-certificate":
            probes.append(
                {
                    **common,
                    "type": "tls-certificate",
                    "host": "REPLACE_WITH_APPROVED_HOST",
                    "port": 443,
                }
            )
    return probes


def compile_profile(
    profile: dict[str, Any],
    platform: dict[str, Any] | None = None,
    *,
    strict: bool = True,
) -> dict[str, Any]:
    diagnostics: list[Diagnostic] = []
    for message in validate_data("profile", profile):
        diagnostics.append(Diagnostic("PROFILE_SCHEMA", Severity.ERROR, "$", message))

    platform_value = platform or _platform_default()
    if platform is None:
        diagnostics.append(
            Diagnostic(
                "PLATFORM_PROFILE_MISSING",
                Severity.WARNING,
                "$.implementation.platform_profile_ref",
                "No organization platform profile was supplied; conservative defaults are used.",
                "Create a platform profile from the principal questionnaire.",
            )
        )
    else:
        for message in validate_data("platform", platform):
            diagnostics.append(Diagnostic("PLATFORM_SCHEMA", Severity.ERROR, "$", message))

    if has_errors(diagnostics):
        raise CompilationError(diagnostics)

    _check_unique_ids(profile, diagnostics)
    _check_ownership(profile, diagnostics)
    _check_flows(profile, diagnostics)
    dependencies = _check_dependencies(profile, diagnostics)
    signals, capabilities, cardinality = _check_signals(profile, platform_value, diagnostics)

    implementation = profile.get("implementation", {})
    if implementation.get("enable_prometheus", True) and not platform_value["prometheus"]["enabled"]:
        diagnostics.append(
            Diagnostic(
                "PROMETHEUS_DISABLED_BY_PLATFORM",
                Severity.ERROR,
                "$.implementation.enable_prometheus",
                "System profile enables Prometheus but platform profile disables it.",
            )
        )
    if implementation.get("enable_splunk", True) and not platform_value["splunk"]["enabled"]:
        diagnostics.append(
            Diagnostic(
                "SPLUNK_DISABLED_BY_PLATFORM",
                Severity.ERROR,
                "$.implementation.enable_splunk",
                "System profile enables Splunk but platform profile disables it.",
            )
        )
    if implementation.get("enable_otel", False):
        otel_mode = implementation.get("otel_mode", "TBD")
        if otel_mode not in {"agent", "agent-to-gateway"}:
            diagnostics.append(
                Diagnostic(
                    "OTEL_MODE_UNSUPPORTED_BY_GENERATOR",
                    Severity.ERROR,
                    "$.implementation.otel_mode",
                    "The current generated hostmetrics fragment supports agent or agent-to-gateway mode only.",
                    "Use an approved agent mode or implement a reviewed gateway template.",
                )
            )
        if otel_mode not in platform_value["opentelemetry"].get("modes", []):
            diagnostics.append(
                Diagnostic(
                    "OTEL_MODE_NOT_ALLOWED_BY_PLATFORM",
                    Severity.ERROR,
                    "$.implementation.otel_mode",
                    f"OpenTelemetry mode '{otel_mode}' is not declared by the platform profile.",
                )
            )
        if not platform_value["opentelemetry"]["allowed"]:
            diagnostics.append(
                Diagnostic(
                    "OTEL_NOT_ALLOWED",
                    Severity.ERROR,
                    "$.implementation.enable_otel",
                    "OpenTelemetry is enabled by the system profile but not allowed by the platform profile.",
                )
            )
        required_components = {
            "receivers": {"hostmetrics"},
            "processors": {"memory_limiter", "resource", "batch"},
            "exporters": {"prometheus"},
            "extensions": {"health_check"},
        }
        components = platform_value["opentelemetry"]["components"]
        for category, required in required_components.items():
            missing = sorted(required - set(components.get(category, [])))
            if missing:
                diagnostics.append(
                    Diagnostic(
                        "OTEL_COMPONENT_UNAVAILABLE",
                        Severity.ERROR,
                        f"$.opentelemetry.components.{category}",
                        f"Required generated components are unavailable: {', '.join(missing)}.",
                        "Declare an approved distribution manifest or disable OTel generation.",
                    )
                )

    normalized_profile = dict(profile)
    normalized_profile["dependencies"] = dependencies
    alerts = _generated_alerts(normalized_profile, capabilities, diagnostics)
    rules = _recording_rules(capabilities)
    probes = _build_probes(normalized_profile, platform_value)

    unresolved: list[str] = []
    for path, value in (
        ("organization.site", platform_value["organization"].get("site")),
        ("prometheus.distribution", platform_value["prometheus"].get("distribution")),
        ("prometheus.version", platform_value["prometheus"].get("version")),
        ("prometheus.dashboard_backend", platform_value["prometheus"].get("dashboard_backend")),
        ("splunk.version", platform_value["splunk"].get("version")),
        ("splunk.default_index", platform_value["splunk"].get("default_index")),
    ):
        if _is_unresolved(value):
            unresolved.append(path)

    output = {
        "schema_version": "1.0.0",
        "compiler_version": __version__,
        "profile_sha256": _stable_hash(profile),
        "platform_sha256": _stable_hash(platform_value),
        "system": dict(profile["system"]),
        "ownership": dict(profile["ownership"]),
        "system_platform": dict(profile["platform"]),
        "platform": platform_value,
        "services": [dict(item) for item in profile.get("services", [])],
        "dependencies": dependencies,
        "data_flows": json.loads(json.dumps(profile.get("data_flows", []))),
        "logs": json.loads(json.dumps(profile.get("logs", []))),
        "implementation": dict(profile.get("implementation", {})),
        "data_handling": dict(profile.get("data_handling", {})),
        "exceptions": json.loads(json.dumps(profile.get("exceptions", []))),
        "assumptions": list(profile.get("assumptions", [])),
        "open_questions": list(profile.get("open_questions", [])),
        "capabilities": capabilities,
        "cardinality_budget": cardinality,
        "signals": signals,
        "recording_rules": rules,
        "generated_alerts": alerts,
        "probes": probes,
        "diagnostics": [item.to_dict() for item in diagnostics],
        "unresolved_decisions": unresolved,
    }

    schema_messages = validate_data("compiled-plan", output)
    diagnostics.extend(
        Diagnostic("COMPILED_PLAN_SCHEMA", Severity.ERROR, "$", message)
        for message in schema_messages
    )
    output["diagnostics"] = [item.to_dict() for item in diagnostics]

    if strict and has_errors(diagnostics):
        raise CompilationError(diagnostics)
    return output
