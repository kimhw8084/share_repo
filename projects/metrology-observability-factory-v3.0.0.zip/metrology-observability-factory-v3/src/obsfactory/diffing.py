from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any


@dataclass(frozen=True)
class Change:
    path: str
    change_type: str
    before: Any
    after: Any
    risk: str
    approval: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _risk(path: str, before: Any, after: Any) -> tuple[str, str]:
    critical_fragments = (
        ".data_handling",
        ".implementation.enable_otel",
        ".implementation.production_alerts_allowed",
        ".alerts",
        ".dependencies",
        ".probes",
        ".security",
    )
    high_fragments = (
        ".signals",
        ".data_flows",
        ".services",
        ".ownership",
        ".criticality",
        ".support_tier",
    )
    if any(fragment in path for fragment in critical_fragments):
        return "high", "system owner and applicable platform/security approval"
    if any(fragment in path for fragment in high_fragments):
        return "medium", "system owner and pattern-owner review"
    return "low", "normal code review"


def semantic_diff(before: Any, after: Any, path: str = "$") -> list[Change]:
    changes: list[Change] = []
    if type(before) is not type(after):
        risk, approval = _risk(path, before, after)
        return [Change(path, "type-changed", before, after, risk, approval)]

    if isinstance(before, dict):
        keys = sorted(set(before) | set(after))
        for key in keys:
            child = f"{path}.{key}"
            if key not in before:
                risk, approval = _risk(child, None, after[key])
                changes.append(Change(child, "added", None, after[key], risk, approval))
            elif key not in after:
                risk, approval = _risk(child, before[key], None)
                changes.append(Change(child, "removed", before[key], None, risk, approval))
            else:
                changes.extend(semantic_diff(before[key], after[key], child))
        return changes

    if isinstance(before, list):
        # ID-addressable lists are compared by ID to avoid false positional changes.
        if all(isinstance(item, dict) and "id" in item for item in before + after):
            old = {str(item["id"]): item for item in before}
            new = {str(item["id"]): item for item in after}
            for key in sorted(set(old) | set(new)):
                child = f"{path}[id={key}]"
                if key not in old:
                    risk, approval = _risk(child, None, new[key])
                    changes.append(Change(child, "added", None, new[key], risk, approval))
                elif key not in new:
                    risk, approval = _risk(child, old[key], None)
                    changes.append(Change(child, "removed", old[key], None, risk, approval))
                else:
                    changes.extend(semantic_diff(old[key], new[key], child))
            return changes
        if before != after:
            risk, approval = _risk(path, before, after)
            changes.append(Change(path, "changed", before, after, risk, approval))
        return changes

    if before != after:
        risk, approval = _risk(path, before, after)
        changes.append(Change(path, "changed", before, after, risk, approval))
    return changes
