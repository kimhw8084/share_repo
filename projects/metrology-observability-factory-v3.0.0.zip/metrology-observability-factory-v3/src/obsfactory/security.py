from __future__ import annotations

from dataclasses import dataclass, asdict
import hashlib
import hmac
import json
from pathlib import Path
import re
from typing import Any, Iterable

from .constants import (
    ALLOWED_HANDOFF_SUFFIXES,
    DENIED_HANDOFF_SUFFIXES,
)

PATTERNS = {
    "private_key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "credential_assignment": re.compile(
        r"(?i)\b(password|passwd|secret|token|api[_-]?key|client[_-]?secret|"
        r"connection[_-]?string)\b\s*[:=]\s*[^\s,;]+"
    ),
    "authorization_header": re.compile(r"(?i)\bauthorization\s*:\s*(?:bearer|basic)\s+\S+"),
    "email": re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
    "ipv4": re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
    "ipv6": re.compile(r"\b(?:[0-9A-Fa-f]{1,4}:){2,7}[0-9A-Fa-f]{1,4}\b"),
    "unc_path": re.compile(r"\\\\[^\\\s]+\\[^\\\s]+"),
    "windows_account": re.compile(r"\b[A-Za-z0-9._-]+\\[A-Za-z0-9._$-]+\b"),
    "guid": re.compile(
        r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-"
        r"[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}\b"
    ),
    "jdbc_url": re.compile(r"(?i)\bjdbc:[a-z0-9]+:[^\s\"']+"),
    "jwt": re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"),
    "credential_url": re.compile(r"(?i)\b[a-z][a-z0-9+.-]*://[^\s/@:]+:[^\s/@]+@"),
    "windows_absolute_path": re.compile(r"\b[A-Za-z]:\\(?:[^\\\r\n]+\\?)+"),
    "unix_absolute_path": re.compile(r"(?<![A-Za-z0-9_])/(?:opt|var|etc|home|srv|mnt|data|app)/[^\s\"']+"),
    "fqdn": re.compile(r"\b(?=.{4,253}\b)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}\b"),
}

REPLACEMENTS = {
    "email": "<EMAIL>",
    "ipv4": "<IP>",
    "ipv6": "<IPV6>",
    "unc_path": "<UNC_PATH>",
    "windows_account": "<ACCOUNT>",
    "guid": "<GUID>",
    "jdbc_url": "<DATABASE_ENDPOINT>",
    "credential_url": "<REDACTED_URL>",
    "windows_absolute_path": "<PATH>",
    "unix_absolute_path": "<PATH>",
    "fqdn": "<HOST>",
}


@dataclass
class Finding:
    path: str
    category: str
    blocking: bool
    detail: str = ""


def pseudonym(value: str, salt: bytes, prefix: str) -> str:
    digest = hmac.new(salt, value.encode("utf-8"), hashlib.sha256).hexdigest()[:12]
    return f"{prefix}_{digest}"


def scan_text(text: str, logical_path: str) -> list[Finding]:
    findings = []
    for category, pattern in PATTERNS.items():
        if pattern.search(text):
            findings.append(
                Finding(
                    path=logical_path,
                    category=category,
                    blocking=category
                    in {"private_key", "credential_assignment", "authorization_header", "jwt", "credential_url"},
                )
            )
    return findings


def sanitize_value(value: Any, findings: list[Finding], path: str = "$") -> Any:
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            lowered = key.lower()
            if lowered in {
                "password",
                "passwd",
                "secret",
                "token",
                "api_key",
                "client_secret",
                "connection_string",
            }:
                findings.append(Finding(path=f"{path}.{key}", category="secret_field", blocking=True))
                continue
            if lowered in {"host_name", "hostname", "ip_address", "address"}:
                findings.append(Finding(path=f"{path}.{key}", category="identity_field", blocking=False))
                result[key] = "<REDACTED>"
                continue
            result[key] = sanitize_value(item, findings, f"{path}.{key}")
        return result
    if isinstance(value, list):
        return [sanitize_value(item, findings, f"{path}[{i}]") for i, item in enumerate(value)]
    if not isinstance(value, str):
        return value

    original = value
    matched = [
        (category, pattern)
        for category, pattern in PATTERNS.items()
        if pattern.search(original)
    ]
    for category, _ in matched:
        is_blocking = category in {
            "private_key",
            "credential_assignment",
            "authorization_header",
            "jwt",
            "credential_url",
        }
        findings.append(Finding(path=path, category=category, blocking=is_blocking))

    text = original
    replacement_order = [
        "credential_url",
        "jdbc_url",
        "email",
        "ipv4",
        "ipv6",
        "unc_path",
        "windows_account",
        "guid",
        "windows_absolute_path",
        "unix_absolute_path",
        "fqdn",
    ]
    for category in replacement_order:
        if category in REPLACEMENTS:
            text = PATTERNS[category].sub(REPLACEMENTS[category], text)
    return text


def scan_tree(root: Path, *, max_file_bytes: int = 5_000_000) -> list[Finding]:
    """Screen a review package.

    Build/test/cache directories are excluded. Secret-like assignments found in
    source code are marked for review rather than treated as proof of an
    embedded secret, because validators and tests necessarily contain those
    patterns. Structured data/configuration files retain blocking behavior.
    """
    findings: list[Finding] = []
    excluded_parts = {
        ".git", ".venv", "__pycache__", ".pytest_cache", "output", "generated",
        "local-only", "dist", "build", "*.egg-info",
    }
    source_suffixes = {".py", ".ps1", ".sh", ".j2", ".spl"}

    for path in root.rglob("*"):
        if path.is_symlink():
            relative = str(path.relative_to(root))
            findings.append(Finding(relative, "symlink_prohibited", True))
            continue
        if not path.is_file():
            continue
        relative_path = path.relative_to(root)
        if any(
            part in excluded_parts or part.endswith(".egg-info")
            for part in relative_path.parts
        ):
            continue
        relative = str(relative_path)
        suffix = path.suffix.lower()
        if suffix in DENIED_HANDOFF_SUFFIXES:
            findings.append(Finding(relative, "denied_file_type", True, suffix))
            continue
        if suffix and suffix not in ALLOWED_HANDOFF_SUFFIXES:
            findings.append(Finding(relative, "unreviewed_file_type", True, suffix))
            continue
        if path.stat().st_size > max_file_bytes:
            findings.append(Finding(relative, "file_too_large", True, str(path.stat().st_size)))
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            findings.append(Finding(relative, "unreadable", True, str(exc)))
            continue

        file_findings = scan_text(text, relative)
        if suffix in source_suffixes:
            for item in file_findings:
                if item.category == "credential_assignment":
                    item.blocking = False
                    item.detail = "source/template pattern requires human review"
        findings.extend(file_findings)
    return findings


def findings_to_dicts(findings: Iterable[Finding]) -> list[dict]:
    return [asdict(item) for item in findings]
