from __future__ import annotations

from collections import Counter
from typing import Any

from .compiler import compile_profile
from .diagnostics import CompilationError


def assess(profile: dict[str, Any], platform: dict[str, Any] | None) -> dict[str, Any]:
    try:
        plan = compile_profile(profile, platform, strict=False)
    except CompilationError as exc:
        return {
            "schema_version": "1.0.0",
            "compilable": False,
            "diagnostics": [item.to_dict() for item in exc.diagnostics],
            "readiness": "blocked",
        }

    counts = Counter(item["severity"] for item in plan["diagnostics"])
    if counts["error"]:
        readiness = "blocked"
    elif counts["warning"]:
        readiness = "design-review"
    elif plan["unresolved_decisions"]:
        readiness = "corporate-values-required"
    else:
        readiness = "generation-ready"

    required = [signal for signal in plan["signals"] if signal.get("required")]
    validated = [
        signal
        for signal in required
        if signal.get("validation_status") in {
            "failure-tested",
            "production-observed",
            "validated",
        }
    ]
    coverage_count = sum(plan["capabilities"].values())
    return {
        "schema_version": "1.0.0",
        "system_id": plan["system"]["id"],
        "compilable": not counts["error"],
        "readiness": readiness,
        "diagnostic_counts": dict(counts),
        "capability_coverage": {
            "covered_categories": coverage_count,
            "total_categories": len(plan["capabilities"]),
            "detail": plan["capabilities"],
        },
        "required_signal_validation": {
            "required": len(required),
            "validated": len(validated),
            "ratio": len(validated) / len(required) if required else 1.0,
        },
        "generated_artifacts": {
            "recording_rules": len(plan["recording_rules"]),
            "alerts": len(plan["generated_alerts"]),
            "probes": len(plan["probes"]),
        },
        "unresolved_decisions": plan["unresolved_decisions"],
        "diagnostics": plan["diagnostics"],
    }


def assessment_markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Architecture Readiness Assessment",
        "",
        f"System: `{report.get('system_id', 'unknown')}`",
        f"Readiness: **{report['readiness']}**",
        "",
        "## Capability coverage",
        "",
        "| Capability | Present |",
        "|---|---:|",
    ]
    for name, present in report.get("capability_coverage", {}).get("detail", {}).items():
        lines.append(f"| {name} | {present} |")
    lines.extend(
        [
            "",
            "## Unresolved decisions",
            "",
        ]
    )
    for item in report.get("unresolved_decisions", []):
        lines.append(f"- `{item}`")
    if not report.get("unresolved_decisions"):
        lines.append("- None.")
    lines.extend(
        [
            "",
            "## Diagnostics",
            "",
            "| Severity | Code | Path | Message |",
            "|---|---|---|---|",
        ]
    )
    for item in report.get("diagnostics", []):
        lines.append(
            f"| {item['severity']} | `{item['code']}` | `{item['path']}` | "
            f"{str(item['message']).replace('|', '\\|')} |"
        )
    if not report.get("diagnostics"):
        lines.append("| — | — | — | None. |")
    lines.append("")
    return "\n".join(lines)
