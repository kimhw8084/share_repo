from __future__ import annotations

from dataclasses import dataclass, asdict
from enum import Enum
from typing import Iterable


class Severity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    ADVISORY = "advisory"


@dataclass(frozen=True)
class Diagnostic:
    code: str
    severity: Severity
    path: str
    message: str
    remediation: str | None = None

    def to_dict(self) -> dict:
        value = asdict(self)
        value["severity"] = self.severity.value
        return value


class CompilationError(ValueError):
    def __init__(self, diagnostics: Iterable[Diagnostic]):
        self.diagnostics = list(diagnostics)
        rendered = "\n".join(
            f"- [{item.severity.value}] {item.code} {item.path}: {item.message}"
            for item in self.diagnostics
        )
        super().__init__(f"Compilation failed:\n{rendered}")


def has_errors(diagnostics: Iterable[Diagnostic]) -> bool:
    return any(item.severity == Severity.ERROR for item in diagnostics)
