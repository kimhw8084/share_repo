from __future__ import annotations

from collections import defaultdict
from typing import Any

CATEGORIES = [
    "host_health",
    "functional_availability",
    "traffic",
    "errors",
    "latency",
    "saturation",
    "freshness",
    "backlog",
    "dependencies",
    "change_identity",
    "telemetry_path",
]


def build_coverage(profile: dict[str, Any]) -> dict[str, Any]:
    by_category: dict[str, list[dict]] = defaultdict(list)
    for signal in profile.get("signals", []):
        categories = list(signal.get("coverage_categories") or [])
        category = signal.get("coverage_category", "other")
        if category not in categories:
            categories.append(category)
        for item in categories:
            by_category[item].append(signal)

    coverage = {}
    detail = {}
    for category in CATEGORIES:
        signals = by_category.get(category, [])
        enabled = [s for s in signals if s.get("enabled", True)]
        required = [s for s in signals if s.get("required")]
        validated_states = {
            "synthetic-tested",
            "failure-tested",
            "production-observed",
            "validated",
        }
        if enabled and all(
            s.get("validation_status") in validated_states
            or s.get("validation_needed") in {"none", "validated"}
            for s in enabled
        ):
            status = "covered"
        elif enabled:
            status = "candidate"
        elif required:
            status = "gap"
        else:
            status = "not-defined"
        coverage[category] = status
        detail[category] = {
            "signals": [s.get("id") for s in signals],
            "required_count": len(required),
            "enabled_count": len(enabled),
        }

    return {
        "schema_version": "1.0.0",
        "system_id": profile["system"]["id"],
        "coverage": coverage,
        "detail": detail,
    }


def coverage_markdown(report: dict[str, Any]) -> str:
    labels = {
        "host_health": "Host health",
        "functional_availability": "Functional availability",
        "traffic": "Traffic/throughput",
        "errors": "Errors",
        "latency": "Latency",
        "saturation": "Saturation",
        "freshness": "Data freshness",
        "backlog": "Backlog",
        "dependencies": "Dependencies",
        "change_identity": "Version/configuration identity",
        "telemetry_path": "Telemetry path",
    }
    lines = [
        "# Observability Coverage Report",
        "",
        f"System: `{report['system_id']}`",
        "",
        "| Capability | Status | Candidate signals |",
        "|---|---|---|",
    ]
    for category, status in report["coverage"].items():
        signals = ", ".join(report["detail"][category]["signals"]) or "—"
        lines.append(f"| {labels[category]} | {status} | {signals} |")
    lines.extend([
        "",
        "Statuses are design-time classifications. `candidate` requires corporate validation; "
        "`covered` is only used when the profile explicitly marks validation complete.",
        "",
    ])
    return "\n".join(lines)
