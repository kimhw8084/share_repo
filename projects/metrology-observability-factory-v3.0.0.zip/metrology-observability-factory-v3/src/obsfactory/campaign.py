from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from datetime import datetime, timezone
import csv
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
from typing import Any
import zipfile

import yaml

from . import __version__
from .io import load_data
from .schema import validate_data
from .security import findings_to_dicts, sanitize_value, scan_tree


CAMPAIGN_FILE = "campaign.yml"
LEDGER_FILE = "state/evidence-ledger.json"
STATE_FILE = "state/campaign-state.json"
SAFE_ID = re.compile(r"^[A-Za-z0-9_.:-]{1,180}$")
PLACEHOLDER = re.compile(r"(?i)^(?:TBD|TODO|UNKNOWN|REPLACE|<REPLACE)")


class CampaignError(ValueError):
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def slug(value: str, *, fallback: str = "item") -> str:
    normalized = re.sub(r"[^a-z0-9-]+", "-", value.strip().lower()).strip("-")
    normalized = re.sub(r"-{2,}", "-", normalized)
    if not normalized:
        normalized = fallback
    if not normalized[0].isalpha():
        normalized = f"{fallback}-{normalized}"
    return normalized[:63]


def split_values(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return [item.strip() for item in str(value).split("|") if item.strip()]


def atomic_write(path: Path, text: str, mode: int = 0o640) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        try:
            os.fchmod(fd, mode)
        except OSError:
            pass
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        try:
            os.chmod(path, mode)
        except OSError:
            pass
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def dump_json(path: Path, value: Any) -> None:
    atomic_write(path, json.dumps(value, indent=2, sort_keys=False) + "\n")


def dump_yaml(path: Path, value: Any) -> None:
    atomic_write(
        path,
        yaml.safe_dump(value, sort_keys=False, default_flow_style=False, width=120),
    )


def load_campaign(directory: Path) -> dict[str, Any]:
    path = directory / CAMPAIGN_FILE
    if not path.exists():
        raise CampaignError(f"Campaign file does not exist: {path}")
    value = load_data(path)
    errors = validate_data("campaign", value)
    if errors:
        raise CampaignError("Campaign is invalid:\n- " + "\n- ".join(errors))
    return value


def _normalize_environment(value: Any) -> str:
    candidate = str(value or "unknown").strip().lower()
    aliases = {
        "dev": "development",
        "qa": "test",
        "prod": "production",
        "preprod": "staging",
    }
    candidate = aliases.get(candidate, candidate)
    allowed = {"development", "test", "staging", "production", "unknown"}
    return candidate if candidate in allowed else "unknown"


def _normalize_os(value: Any) -> str:
    candidate = str(value or "unknown").strip().lower()
    if candidate.startswith("win"):
        return "windows"
    if candidate in {"linux", "rhel", "redhat", "ubuntu", "centos", "sles"}:
        return "linux"
    return "unknown"


def _default_collectors(roles: list[str]) -> list[str]:
    collectors = ["host-discovery", "environment"]
    if "prometheus" in roles:
        collectors.append("prometheus-capabilities")
    if "splunk" in roles:
        collectors.append("splunk-capabilities")
    if "opentelemetry" in roles:
        collectors.append("otel-capabilities")
    return collectors


def _load_inventory(path: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    if not path.exists():
        raise CampaignError(f"Inventory does not exist: {path}")

    if path.suffix.lower() in {".yml", ".yaml", ".json"}:
        value = load_data(path)
        systems = value.get("systems", [])
        hosts = value.get("hosts", [])
        platform_targets = value.get("platform_targets", [])
        if not isinstance(systems, list) or not isinstance(hosts, list):
            raise CampaignError("Structured inventory requires systems and hosts arrays")
        return systems, hosts, platform_targets

    if path.suffix.lower() != ".csv":
        raise CampaignError("Inventory must be CSV, YAML, or JSON")

    with path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise CampaignError("Inventory CSV has no rows")

    required_columns = {"system_id", "host_alias"}
    missing = required_columns - set(rows[0])
    if missing:
        raise CampaignError(
            "Inventory CSV is missing columns: " + ", ".join(sorted(missing))
        )

    systems_by_id: dict[str, dict[str, Any]] = {}
    hosts_by_alias: dict[str, dict[str, Any]] = {}
    platform_targets: dict[str, dict[str, Any]] = {}

    for row_number, row in enumerate(rows, start=2):
        system_id = slug(row.get("system_id", ""), fallback="system")
        host_alias = slug(row.get("host_alias", ""), fallback="host")
        if not system_id or not host_alias:
            raise CampaignError(f"Invalid system or host ID at inventory row {row_number}")

        system = {
            "id": system_id,
            "display_name": row.get("system_display_name") or system_id,
            "environment": _normalize_environment(row.get("environment")),
            "criticality": row.get("criticality") or "TBD",
            "support_tier": row.get("support_tier") or "TBD",
            "owner": row.get("system_owner") or "TBD",
            "backup": row.get("system_backup") or "TBD",
            "business_function": row.get("business_function")
            or "TBD: system owner must define intended business capability.",
            "lifecycle": row.get("lifecycle") or "candidate",
        }
        existing_system = systems_by_id.get(system_id)
        if existing_system and existing_system != system:
            differing = [
                key for key in system if existing_system.get(key) != system.get(key)
            ]
            raise CampaignError(
                f"Conflicting system fields for {system_id} at row {row_number}: "
                + ", ".join(differing)
            )
        systems_by_id[system_id] = system

        roles = split_values(row.get("host_roles")) or ["application"]
        collectors = split_values(row.get("collectors")) or _default_collectors(roles)
        host = hosts_by_alias.get(host_alias)
        if host is None:
            host = {
                "alias": host_alias,
                "system_ids": [],
                "os_hint": _normalize_os(row.get("os_hint")),
                "environment": _normalize_environment(row.get("environment")),
                "roles": roles,
                "approved_paths": split_values(row.get("approved_paths")),
                "collectors": collectors,
                "owner": row.get("host_owner") or row.get("system_owner") or "TBD",
                "run_mode": row.get("run_mode") or "local-manual",
            }
            hosts_by_alias[host_alias] = host
        elif any(
            host.get(key) != value
            for key, value in {
                "os_hint": _normalize_os(row.get("os_hint")),
                "environment": _normalize_environment(row.get("environment")),
                "roles": roles,
                "approved_paths": split_values(row.get("approved_paths")),
                "collectors": collectors,
                "run_mode": row.get("run_mode") or "local-manual",
            }.items()
        ):
            raise CampaignError(
                f"Conflicting host fields for {host_alias} at row {row_number}"
            )
        if system_id not in host["system_ids"]:
            host["system_ids"].append(system_id)

        for role, kind in [
            ("prometheus", "prometheus"),
            ("splunk", "splunk"),
            ("opentelemetry", "opentelemetry"),
        ]:
            if role in roles:
                target_id = f"{kind}-{host_alias}"
                platform_targets[target_id] = {
                    "id": target_id,
                    "kind": kind,
                    "host_alias": host_alias,
                    "owner": row.get(f"{kind}_owner") or row.get("host_owner") or "TBD",
                    "enabled": True,
                }

    return (
        sorted(systems_by_id.values(), key=lambda item: item["id"]),
        sorted(hosts_by_alias.values(), key=lambda item: item["alias"]),
        sorted(platform_targets.values(), key=lambda item: item["id"]),
    )


def _approved_policy(approval: dict[str, Any]) -> dict[str, Any]:
    decisions = {item["id"]: item for item in approval["decisions"]}
    not_approved = [
        item["id"] for item in approval["decisions"] if item.get("approved") is not True
    ]
    if approval.get("approval_status") != "approved" or not_approved:
        raise CampaignError(
            "Campaign defaults are not fully approved: " + ", ".join(not_approved)
        )

    return {
        "remote_execution": (
            "approved-orchestrator-adapter"
            if decisions["D03"].get("override")
            else "local-bundles-only"
        ),
        "normal_privilege_first": True,
        "raw_logs_external": False,
        "raw_configs_external": False,
        "external_identity_policy": "pseudonymize",
        "autonomous_remediation": False,
        "network_probe_default": "approved-targets-only",
        "database_probe_default": "manifest-approved-only",
        "external_return_enabled": True,
        "evidence_freshness_days": {
            "host-discovery": 30,
            "environment": 30,
            "prometheus-capabilities": 30,
            "splunk-capabilities": 30,
            "otel-capabilities": 30,
            "system-interview": 90,
            "platform-owner-response": 90,
            "log-feature-summary": 90,
            "validation-result": 30,
            "operator-acceptance": 180,
            "benefit-baseline": 90,
            "approval-record": 365,
            "inventory-snapshot": 30,
        },
    }


def _requirements(platform_targets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    requirements = [
        {
            "id": "REQ-APPROVAL",
            "gate": "design",
            "evidence_type": "approval-record",
            "subject_kind": "campaign",
            "required": True,
            "freshness_days": 365,
            "human_decision": True,
        },
        {
            "id": "REQ-INVENTORY",
            "gate": "design",
            "evidence_type": "inventory-snapshot",
            "subject_kind": "campaign",
            "required": True,
            "freshness_days": 30,
            "human_decision": False,
        },
        {
            "id": "REQ-HOST-DISCOVERY",
            "gate": "pilot",
            "evidence_type": "host-discovery",
            "subject_kind": "host",
            "required": True,
            "freshness_days": 30,
            "human_decision": False,
        },
        {
            "id": "REQ-ENVIRONMENT",
            "gate": "pilot",
            "evidence_type": "environment",
            "subject_kind": "host",
            "required": True,
            "freshness_days": 30,
            "human_decision": False,
        },
        {
            "id": "REQ-SYSTEM-INTERVIEW",
            "gate": "pilot",
            "evidence_type": "system-interview",
            "subject_kind": "system",
            "required": True,
            "freshness_days": 90,
            "human_decision": True,
        },
        {
            "id": "REQ-LOG-FEATURES",
            "gate": "pilot",
            "evidence_type": "log-feature-summary",
            "subject_kind": "system",
            "required": True,
            "freshness_days": 90,
            "human_decision": False,
        },
        {
            "id": "REQ-VALIDATION",
            "gate": "production",
            "evidence_type": "validation-result",
            "subject_kind": "system",
            "required": True,
            "freshness_days": 30,
            "human_decision": True,
        },
        {
            "id": "REQ-OPERATOR-ACCEPTANCE",
            "gate": "production",
            "evidence_type": "operator-acceptance",
            "subject_kind": "system",
            "required": True,
            "freshness_days": 180,
            "human_decision": True,
        },
        {
            "id": "REQ-BENEFIT-BASELINE",
            "gate": "scale",
            "evidence_type": "benefit-baseline",
            "subject_kind": "campaign",
            "required": True,
            "freshness_days": 90,
            "human_decision": True,
        },
    ]
    kinds = {target["kind"] for target in platform_targets if target["enabled"]}
    for kind in sorted(kinds):
        evidence_type = f"{kind}-capabilities"
        if kind == "opentelemetry":
            evidence_type = "otel-capabilities"
        requirements.extend(
            [
                {
                    "id": f"REQ-{kind.upper()}-CAPABILITIES",
                    "gate": "pilot",
                    "evidence_type": evidence_type,
                    "subject_kind": "platform",
                    "required": True,
                    "freshness_days": 30,
                    "human_decision": False,
                },
                {
                    "id": f"REQ-{kind.upper()}-OWNER",
                    "gate": "pilot",
                    "evidence_type": "platform-owner-response",
                    "subject_kind": "platform",
                    "required": True,
                    "freshness_days": 90,
                    "human_decision": True,
                },
            ]
        )
    return requirements


def _envelope(
    *,
    campaign_id: str,
    run_id: str,
    evidence_id: str,
    evidence_type: str,
    subject_kind: str,
    subject_id: str,
    collector_name: str,
    payload: Any,
    source_file: Path,
    classification: str = "internal",
    status: str = "success",
    privilege: str = "normal",
) -> dict[str, Any]:
    timestamp = utc_now()
    value = {
        "schema_version": "3.0.0",
        "campaign_id": campaign_id,
        "run_id": run_id,
        "evidence_id": evidence_id,
        "evidence_type": evidence_type,
        "subject": {"kind": subject_kind, "id": subject_id},
        "collector": {
            "name": collector_name,
            "version": __version__,
            "started_at_utc": timestamp,
            "completed_at_utc": timestamp,
            "status": status,
            "privilege": privilege,
            "error_code": None,
        },
        "classification": classification,
        "payload": payload,
        "provenance": {
            "source_file": source_file.name,
            "source_sha256": sha256_file(source_file),
            "raw_logs_included": False,
            "raw_configs_included": False,
            "human_review_required": True,
        },
    }
    errors = validate_data("evidence", value)
    if errors:
        raise CampaignError("Generated evidence envelope is invalid:\n- " + "\n- ".join(errors))
    return value


def _initial_ledger() -> dict[str, Any]:
    return {
        "schema_version": "3.0.0",
        "evidence": {},
        "conflicts": [],
        "ingest_runs": [],
    }


def _store_evidence(
    directory: Path,
    ledger: dict[str, Any],
    envelope: dict[str, Any],
    *,
    source_label: str,
) -> str:
    evidence_id = envelope["evidence_id"]
    if not SAFE_ID.fullmatch(evidence_id):
        raise CampaignError(f"Unsafe evidence ID: {evidence_id}")

    canonical_hash = sha256_text(json.dumps(envelope, sort_keys=True, separators=(",", ":")))
    existing = ledger["evidence"].get(evidence_id)
    if existing:
        if existing["canonical_sha256"] == canonical_hash:
            return "duplicate-identical"
        conflict = {
            "evidence_id": evidence_id,
            "existing_sha256": existing["canonical_sha256"],
            "new_sha256": canonical_hash,
            "source": source_label,
            "detected_at_utc": utc_now(),
            "resolution": None,
        }
        ledger["conflicts"].append(conflict)
        conflict_path = (
            directory
            / "evidence/conflicts"
            / f"{slug(evidence_id, fallback='evidence')}.{canonical_hash[:12]}.json"
        )
        dump_json(conflict_path, envelope)
        return "conflict"

    relative = (
        Path("evidence/records")
        / f"{slug(evidence_id, fallback='evidence')}.{canonical_hash[:12]}.json"
    )
    dump_json(directory / relative, envelope)
    ledger["evidence"][evidence_id] = {
        "path": str(relative).replace("\\", "/"),
        "canonical_sha256": canonical_hash,
        "evidence_type": envelope["evidence_type"],
        "subject": envelope["subject"],
        "status": envelope["collector"]["status"],
        "completed_at_utc": envelope["collector"]["completed_at_utc"],
        "classification": envelope["classification"],
        "source": source_label,
    }
    return "stored"


def _system_form(campaign_id: str, system: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "3.0.0",
        "campaign_id": campaign_id,
        "response_id": f"system-interview:{system['id']}",
        "response_type": "system-interview",
        "subject": {"kind": "system", "id": system["id"]},
        "status": "draft",
        "respondent_role": "system-owner",
        "classification": "confidential",
        "answers": {
            "business_function": system["business_function"],
            "criticality": system["criticality"],
            "support_tier": system["support_tier"],
            "primary_owner": system["owner"],
            "backup_owner": system["backup"],
            "functional_success": "TBD: define an observable successful transaction or output.",
            "graceful_degradation": "TBD",
            "maintenance_states": [],
            "required_services": [],
            "dependencies": [],
            "data_flows": [],
            "normal_idle_behavior": "TBD",
            "normal_burst_behavior": "TBD",
            "recovery_confirmation": "TBD: successful functional transaction plus fresh evidence.",
            "log_sources": [],
            "normal_log_window": None,
            "high_load_log_window": None,
            "incident_log_windows": [],
            "known_incident_classes": [],
            "safe_nonproduction_test_path": "TBD",
            "technician_safe_scope": "TBD",
            "engineer_only_scope": (
                "Architecture, code, database/network, failover, deployment, "
                "ambiguous diagnosis, and uncertain rollback."
            ),
        },
        "evidence_references": [],
        "completed_at_utc": None,
        "human_review_required": True,
        "review_notes": [
            "Set status to completed and completed_at_utc only after system-owner review.",
            "Do not include credentials, raw logs, exact external endpoints, or unnecessary identifiers.",
        ],
    }


def _platform_form(campaign_id: str, target: dict[str, Any]) -> dict[str, Any]:
    kind = target["kind"]
    common = {
        "owner": target["owner"],
        "supported_version": "TBD",
        "validation_command": "TBD",
        "repository_workflow": "TBD",
        "credential_delivery": "TBD",
        "production_change_workflow": "TBD",
        "rollback_workflow": "TBD",
        "approved_config_paths": [],
        "collect_components": False,
    }
    if kind == "prometheus":
        common.update(
            {
                "distribution": "TBD",
                "service_discovery": [],
                "approved_exporters": [],
                "max_series_per_system": "TBD",
                "max_labels_per_metric": "TBD",
                "alertmanager_routing_owner": "TBD",
                "dashboard_backend": "TBD",
                "retention_policy": "TBD",
            }
        )
    elif kind == "splunk":
        common.update(
            {
                "product": "TBD",
                "topology": "TBD",
                "ingestion_modes": [],
                "index_mapping": {},
                "sourcetype_policy": "TBD",
                "retention_policy": "TBD",
                "cim_policy": "preferred",
                "ingestion_volume_budget": "TBD",
                "scheduled_search_cost_review": True,
                "dashboard_backend": "TBD",
            }
        )
    else:
        common.update(
            {
                "allowed": False,
                "distribution": "TBD",
                "modes": [],
                "components": {
                    "receivers": [],
                    "processors": [],
                    "exporters": [],
                    "extensions": [],
                },
                "resource_budget": "TBD",
                "duplicate_ingestion_control": "required",
            }
        )
    return {
        "schema_version": "3.0.0",
        "campaign_id": campaign_id,
        "response_id": f"platform-owner-response:{target['id']}",
        "response_type": "platform-owner-response",
        "subject": {"kind": "platform", "id": target["id"]},
        "status": "draft",
        "respondent_role": f"{kind}-platform-owner",
        "classification": "confidential",
        "answers": common,
        "evidence_references": [],
        "completed_at_utc": None,
        "human_review_required": True,
        "review_notes": [
            "Use aliases for endpoints and repositories in any external-returnable fields.",
            "Do not include credentials, tokens, private keys, or connection strings.",
        ],
    }



def _validation_form(campaign_id: str, system: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "3.0.0",
        "campaign_id": campaign_id,
        "response_id": f"validation-result:{system['id']}",
        "response_type": "validation-result",
        "subject": {"kind": "system", "id": system["id"]},
        "status": "draft",
        "respondent_role": "system-owner-and-platform-validator",
        "classification": "confidential",
        "answers": {
            "environment": "TBD",
            "platform_syntax_passed": False,
            "source_reconciliation_passed": False,
            "missing_zero_stale_nan_tested": False,
            "controlled_fire_clear_passed": False,
            "resource_overhead_acceptable": False,
            "ingestion_volume_acceptable": False,
            "security_review_passed": False,
            "failover_or_instance_behavior_tested": False,
            "rollback_tested": False,
            "production_function_affected": False,
            "evidence_summary": "TBD",
            "blocking_findings": [],
        },
        "evidence_references": [],
        "completed_at_utc": None,
        "human_review_required": True,
        "review_notes": [
            "Complete only after approved internal validation.",
            "Do not mark passed without referenced evidence.",
        ],
    }


def _operator_acceptance_form(campaign_id: str, system: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "3.0.0",
        "campaign_id": campaign_id,
        "response_id": f"operator-acceptance:{system['id']}",
        "response_type": "operator-acceptance",
        "subject": {"kind": "system", "id": system["id"]},
        "status": "draft",
        "respondent_role": "engineer-and-technician-operators",
        "classification": "confidential",
        "answers": {
            "engineer_workflow_accepted": False,
            "technician_workflow_accepted": False,
            "alert_meaning_clear": False,
            "first_safe_check_clear": False,
            "stop_conditions_clear": False,
            "escalation_package_complete": False,
            "recovery_condition_clear": False,
            "runbook_exercised": False,
            "primary_owner_accepts_support": False,
            "backup_owner_demonstrated_capability": False,
            "acceptance_notes": [],
        },
        "evidence_references": [],
        "completed_at_utc": None,
        "human_review_required": True,
        "review_notes": [
            "This is operational acceptance, not an employee performance evaluation."
        ],
    }


def _benefit_form(campaign_id: str) -> dict[str, Any]:
    return {
        "schema_version": "3.0.0",
        "campaign_id": campaign_id,
        "response_id": f"benefit-baseline:{campaign_id}",
        "response_type": "benefit-baseline",
        "subject": {"kind": "campaign", "id": campaign_id},
        "status": "draft",
        "respondent_role": "manager-or-project-owner",
        "classification": "confidential",
        "answers": {
            "measurement_period": "TBD",
            "incident_count": None,
            "user_reported_before_monitoring_count": None,
            "median_detection_minutes": None,
            "median_evidence_minutes": None,
            "median_isolation_minutes": None,
            "median_recovery_minutes": None,
            "engineering_hours": None,
            "technician_hours": None,
            "off_hours_incidents": None,
            "false_positive_alerts": None,
            "repeated_manual_checks": [],
            "notes": [],
        },
        "evidence_references": [],
        "completed_at_utc": None,
        "human_review_required": True,
        "review_notes": ["Use aggregate values. Do not include employee performance ratings."],
    }


def init_campaign(
    approval_path: Path,
    inventory_path: Path,
    output: Path,
    *,
    campaign_id: str | None = None,
    title: str | None = None,
    inventory_snapshot_date: str | None = None,
    force: bool = False,
) -> Path:
    if output.exists():
        if not force:
            raise CampaignError(f"Output already exists: {output}")
        shutil.rmtree(output)

    approval = load_data(approval_path)
    approval_errors = validate_data("campaign-approval", approval)
    if approval_errors:
        raise CampaignError("Approval is invalid:\n- " + "\n- ".join(approval_errors))

    systems, hosts, platform_targets = _load_inventory(inventory_path)
    if not systems or not hosts:
        raise CampaignError("Campaign requires at least one system and one host")

    known_systems = {item["id"] for item in systems}
    for host in hosts:
        unknown = sorted(set(host["system_ids"]) - known_systems)
        if unknown:
            raise CampaignError(
                f"Host {host['alias']} references unknown systems: {', '.join(unknown)}"
            )

    campaign_id = campaign_id or f"metrology-observability-{datetime.now().strftime('%Y%m%d')}"
    campaign_id = slug(campaign_id, fallback="campaign")
    staging = output.parent / f".{output.name}.staging-{os.getpid()}"
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True)

    try:
        approval_copy = staging / "approvals/v3-defaults.approved.yml"
        inventory_copy = staging / f"inputs/inventory{inventory_path.suffix.lower()}"
        approval_copy.parent.mkdir(parents=True, exist_ok=True)
        inventory_copy.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(approval_path, approval_copy)
        shutil.copy2(inventory_path, inventory_copy)

        campaign = {
            "schema_version": "3.0.0",
            "campaign": {
                "id": campaign_id,
                "title": title or "Metrology Unified Observability Evidence Campaign",
                "created_at_utc": utc_now(),
                "status": "initialized",
                "repository_version": __version__,
                "inventory_snapshot_date": inventory_snapshot_date,
            },
            "approval": {
                "path": str(approval_copy.relative_to(staging)).replace("\\", "/"),
                "sha256": sha256_file(approval_copy),
                "status": "approved",
            },
            "policies": _approved_policy(approval),
            "systems": systems,
            "hosts": hosts,
            "platform_targets": platform_targets,
            "evidence_requirements": _requirements(platform_targets),
            "state": {
                "evidence_count": 0,
                "conflict_count": 0,
                "blocking_gap_count": 0,
                "last_ingested_at_utc": None,
            },
        }
        errors = validate_data("campaign", campaign)
        if errors:
            raise CampaignError("Generated campaign is invalid:\n- " + "\n- ".join(errors))
        dump_yaml(staging / CAMPAIGN_FILE, campaign)

        ledger = _initial_ledger()
        approval_evidence = _envelope(
            campaign_id=campaign_id,
            run_id="campaign-init",
            evidence_id=f"approval-record:{campaign_id}",
            evidence_type="approval-record",
            subject_kind="campaign",
            subject_id=campaign_id,
            collector_name="campaign-init",
            payload={
                "approval_status": approval["approval_status"],
                "approved_decisions": [
                    item["id"] for item in approval["decisions"] if item["approved"]
                ],
                "approval_basis": approval["approval_basis"],
                "approved_by_role": approval["approved_by_role"],
                "approved_at_utc": approval["approved_at_utc"],
            },
            source_file=approval_copy,
        )
        inventory_evidence = _envelope(
            campaign_id=campaign_id,
            run_id="campaign-init",
            evidence_id=f"inventory-snapshot:{campaign_id}",
            evidence_type="inventory-snapshot",
            subject_kind="campaign",
            subject_id=campaign_id,
            collector_name="campaign-init",
            payload={
                "system_count": len(systems),
                "host_count": len(hosts),
                "platform_target_count": len(platform_targets),
                "snapshot_date": inventory_snapshot_date,
                "systems": [
                    {
                        "id": item["id"],
                        "environment": item["environment"],
                        "criticality": item["criticality"],
                        "lifecycle": item["lifecycle"],
                    }
                    for item in systems
                ],
                "hosts": [
                    {
                        "alias": item["alias"],
                        "system_ids": item["system_ids"],
                        "os_hint": item["os_hint"],
                        "roles": item["roles"],
                    }
                    for item in hosts
                ],
            },
            source_file=inventory_copy,
        )
        _store_evidence(staging, ledger, approval_evidence, source_label="campaign-init")
        _store_evidence(staging, ledger, inventory_evidence, source_label="campaign-init")
        dump_json(staging / LEDGER_FILE, ledger)

        for system in systems:
            forms = {
                f"forms/systems/{system['id']}.yml": _system_form(campaign_id, system),
                f"forms/validation/{system['id']}.yml": _validation_form(campaign_id, system),
                f"forms/operator-acceptance/{system['id']}.yml": _operator_acceptance_form(campaign_id, system),
            }
            for relative, form in forms.items():
                errors = validate_data("semantic-response", form)
                if errors:
                    raise CampaignError(
                        f"Generated response form is invalid ({relative}):\n- "
                        + "\n- ".join(errors)
                    )
                dump_yaml(staging / relative, form)

        for target in platform_targets:
            form = _platform_form(campaign_id, target)
            errors = validate_data("semantic-response", form)
            if errors:
                raise CampaignError("Generated platform form is invalid:\n- " + "\n- ".join(errors))
            dump_yaml(staging / f"forms/platforms/{target['id']}.yml", form)

        benefit = _benefit_form(campaign_id)
        dump_yaml(staging / "forms/campaign/benefit-baseline.yml", benefit)

        for directory in [
            "inbox",
            "evidence/records",
            "evidence/conflicts",
            "execution",
            "ai-jobs",
            "output/internal",
            "output/external",
            "state",
        ]:
            (staging / directory).mkdir(parents=True, exist_ok=True)

        state = {
            "schema_version": "3.0.0",
            "campaign_id": campaign_id,
            "status": "initialized",
            "created_at_utc": campaign["campaign"]["created_at_utc"],
            "last_action": "campaign-init",
            "next_action": "Build local execution bundles and complete generated owner forms.",
            "human_approval_required": True,
        }
        dump_json(staging / STATE_FILE, state)
        _write_campaign_readme(staging, campaign)

        os.replace(staging, output)
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise
    return output


def _write_campaign_readme(directory: Path, campaign: dict[str, Any]) -> None:
    text = f"""# Evidence Campaign — {campaign['campaign']['id']}

Status: initialized  
Repository version: {__version__}

## Execution

Complete the system and platform-owner forms first. Set `status: completed`
and `completed_at_utc` only after accountable review, then ingest those forms:

```bash
obsfactory campaign ingest {directory.name} {directory.name}/inbox
obsfactory campaign build-runners {directory.name}
```

The runner manifests will then include any approved platform configuration
paths from the owner responses. Run the reviewed host bundles, copy only their
`output/evidence/*.json` files to `inbox/`, and ingest again:

```bash
obsfactory campaign ingest {directory.name} {directory.name}/inbox
obsfactory campaign build-ai-jobs {directory.name}
obsfactory campaign status {directory.name}
obsfactory campaign finalize {directory.name} \\
  --external-output sanitized-return-bundle.zip
```

## Boundaries

- Raw logs and configurations remain inside the corporate environment.
- Local runner bundles are read-only and start with normal privilege.
- No deployment, restart, failover, database write, network change, or
  autonomous remediation is performed.
- A failed collector produces structured evidence and a targeted rerun action.
- Generated external approval remains false.
"""
    atomic_write(directory / "README-CAMPAIGN.md", text)


def _load_ledger(directory: Path) -> dict[str, Any]:
    path = directory / LEDGER_FILE
    if not path.exists():
        return _initial_ledger()
    return json.loads(path.read_text(encoding="utf-8"))


def _update_campaign_state(directory: Path, campaign: dict[str, Any], ledger: dict[str, Any], status: str) -> None:
    campaign["campaign"]["status"] = status
    campaign["state"].update(
        {
            "evidence_count": len(ledger["evidence"]),
            "conflict_count": len(ledger["conflicts"]),
            "last_ingested_at_utc": utc_now(),
        }
    )
    dump_yaml(directory / CAMPAIGN_FILE, campaign)
    dump_json(directory / LEDGER_FILE, ledger)
    state = {
        "schema_version": "3.0.0",
        "campaign_id": campaign["campaign"]["id"],
        "status": status,
        "updated_at_utc": utc_now(),
        "evidence_count": len(ledger["evidence"]),
        "conflict_count": len(ledger["conflicts"]),
        "human_approval_required": True,
    }
    dump_json(directory / STATE_FILE, state)


def _convert_response(path: Path, value: dict[str, Any]) -> dict[str, Any]:
    errors = validate_data("semantic-response", value)
    if errors:
        raise CampaignError(f"Invalid semantic response {path}:\n- " + "\n- ".join(errors))
    if value["status"] != "completed" or not value["completed_at_utc"]:
        raise CampaignError(
            f"Semantic response is not completed and cannot be ingested: {path}"
        )
    timestamp = value["completed_at_utc"]
    return {
        "schema_version": "3.0.0",
        "campaign_id": value["campaign_id"],
        "run_id": f"human-response:{value['response_id']}",
        "evidence_id": value["response_id"],
        "evidence_type": value["response_type"],
        "subject": value["subject"],
        "collector": {
            "name": "human-semantic-response",
            "version": __version__,
            "started_at_utc": timestamp,
            "completed_at_utc": timestamp,
            "status": "success",
            "privilege": "normal",
            "error_code": None,
        },
        "classification": value["classification"],
        "payload": {
            "respondent_role": value["respondent_role"],
            "answers": value["answers"],
            "evidence_references": value["evidence_references"],
            "review_notes": value.get("review_notes", []),
        },
        "provenance": {
            "source_file": path.name,
            "source_sha256": sha256_file(path),
            "raw_logs_included": False,
            "raw_configs_included": False,
            "human_review_required": True,
        },
    }


def ingest_campaign(directory: Path, inbox: Path) -> dict[str, Any]:
    campaign = load_campaign(directory)
    if not inbox.exists():
        raise CampaignError(f"Inbox does not exist: {inbox}")
    ledger = _load_ledger(directory)
    result = {
        "stored": 0,
        "duplicate_identical": 0,
        "conflicts": 0,
        "skipped_drafts": 0,
        "invalid": [],
    }

    files = [
        path
        for path in sorted(inbox.rglob("*"))
        if path.is_file() and path.suffix.lower() in {".json", ".yml", ".yaml"}
    ]
    if not files:
        raise CampaignError(f"No JSON/YAML evidence files found in {inbox}")

    for path in files:
        try:
            value = load_data(path)
            if isinstance(value, dict) and value.get("response_type"):
                if value.get("status") != "completed":
                    result["skipped_drafts"] += 1
                    continue
                envelope = _convert_response(path, value)
            else:
                envelope = value
                errors = validate_data("evidence", envelope)
                if errors:
                    raise CampaignError("; ".join(errors))

            if envelope["campaign_id"] != campaign["campaign"]["id"]:
                raise CampaignError(
                    f"campaign ID mismatch: {envelope['campaign_id']}"
                )
            action = _store_evidence(
                directory,
                ledger,
                envelope,
                source_label=str(path),
            )
            if action == "stored":
                result["stored"] += 1

                if envelope["evidence_type"] == "platform-owner-response":
                    target = next(
                        (
                            item
                            for item in campaign["platform_targets"]
                            if item["id"] == envelope["subject"]["id"]
                        ),
                        None,
                    )
                    answers = envelope.get("payload", {}).get("answers", {})
                    version = answers.get("supported_version")
                    validation = answers.get("validation_command")
                    if target and not PLACEHOLDER.match(str(version or "TBD")) and not PLACEHOLDER.match(str(validation or "TBD")):
                        capability_type = (
                            "otel-capabilities"
                            if target["kind"] == "opentelemetry"
                            else f"{target['kind']}-capabilities"
                        )
                        derived = deepcopy(envelope)
                        derived["run_id"] = f"derived:{envelope['run_id']}"
                        derived["evidence_id"] = (
                            f"{capability_type}:{target['id']}:owner-attestation"
                        )
                        derived["evidence_type"] = capability_type
                        derived["collector"] = {
                            **derived["collector"],
                            "name": "platform-owner-attestation",
                            "status": "success",
                            "error_code": None,
                        }
                        derived["payload"] = {
                            **answers,
                            "evidence_basis": "completed platform-owner response",
                            "auto_collected": False,
                        }
                        derived_action = _store_evidence(
                            directory,
                            ledger,
                            derived,
                            source_label=f"{path}:derived-capability",
                        )
                        if derived_action == "stored":
                            result["stored"] += 1
                        elif derived_action == "conflict":
                            result["conflicts"] += 1
            elif action == "duplicate-identical":
                result["duplicate_identical"] += 1
            else:
                result["conflicts"] += 1
        except Exception as exc:
            result["invalid"].append({"path": str(path), "error": str(exc)})

    ledger["ingest_runs"].append(
        {
            "at_utc": utc_now(),
            "inbox": str(inbox),
            "result": result,
        }
    )
    _update_campaign_state(directory, campaign, ledger, "ingested")
    return result


def _evidence_records(directory: Path, ledger: dict[str, Any]) -> list[dict[str, Any]]:
    records = []
    for evidence_id, metadata in ledger["evidence"].items():
        path = directory / metadata["path"]
        try:
            records.append(json.loads(path.read_text(encoding="utf-8")))
        except Exception as exc:
            raise CampaignError(f"Could not load evidence {evidence_id}: {exc}") from exc
    return records


def _subject_ids(campaign: dict[str, Any], kind: str) -> list[str]:
    if kind == "campaign":
        return [campaign["campaign"]["id"]]
    if kind == "system":
        return [item["id"] for item in campaign["systems"]]
    if kind == "host":
        return [item["alias"] for item in campaign["hosts"]]
    if kind == "platform":
        return [item["id"] for item in campaign["platform_targets"] if item["enabled"]]
    return []


def _parse_timestamp(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def coverage_report(
    campaign: dict[str, Any],
    records: list[dict[str, Any]],
    conflicts: list[dict[str, Any]],
) -> dict[str, Any]:
    index: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        key = (
            record["evidence_type"],
            record["subject"]["kind"],
            record["subject"]["id"],
        )
        index[key].append(record)

    now = datetime.now(timezone.utc)
    instances = []
    gate_totals: dict[str, dict[str, int]] = defaultdict(
        lambda: {"required": 0, "satisfied": 0}
    )
    for requirement in campaign["evidence_requirements"]:
        for subject_id in _subject_ids(campaign, requirement["subject_kind"]):
            candidates = index.get(
                (
                    requirement["evidence_type"],
                    requirement["subject_kind"],
                    subject_id,
                ),
                [],
            )
            usable = []
            for candidate in candidates:
                if candidate["collector"]["status"] != "success":
                    continue
                completed = _parse_timestamp(candidate["collector"]["completed_at_utc"])
                age_days = (now - completed).total_seconds() / 86400
                if age_days <= requirement["freshness_days"]:
                    usable.append(candidate)
            satisfied = bool(usable)
            instance = {
                "requirement_id": requirement["id"],
                "gate": requirement["gate"],
                "evidence_type": requirement["evidence_type"],
                "subject_kind": requirement["subject_kind"],
                "subject_id": subject_id,
                "required": requirement["required"],
                "human_decision": requirement["human_decision"],
                "satisfied": satisfied,
                "evidence_ids": [item["evidence_id"] for item in usable],
                "status": "satisfied" if satisfied else "missing-or-stale",
            }
            instances.append(instance)
            if requirement["required"]:
                gate_totals[requirement["gate"]]["required"] += 1
                gate_totals[requirement["gate"]]["satisfied"] += int(satisfied)

    gates = {}
    for gate in ["design", "pilot", "production", "scale"]:
        total = gate_totals[gate]
        percentage = (
            100.0
            if total["required"] == 0
            else round(100 * total["satisfied"] / total["required"], 1)
        )
        gates[gate] = {**total, "percentage": percentage}

    return {
        "schema_version": "3.0.0",
        "campaign_id": campaign["campaign"]["id"],
        "generated_at_utc": utc_now(),
        "gates": gates,
        "instances": instances,
        "blocking_gaps": [
            item for item in instances if item["required"] and not item["satisfied"]
        ],
        "conflicts": conflicts,
    }


def _targeted_action(gap: dict[str, Any], campaign: dict[str, Any]) -> dict[str, Any]:
    kind = gap["subject_kind"]
    subject = gap["subject_id"]
    evidence_type = gap["evidence_type"]
    if kind == "host":
        return {
            "action": "rerun-host-bundle",
            "subject": subject,
            "command": f"Use execution/{subject}/Run.ps1 or execution/{subject}/run.sh",
            "reason": f"Missing or stale {evidence_type}",
            "scope": [evidence_type],
        }
    if evidence_type == "system-interview":
        return {
            "action": "complete-system-form",
            "subject": subject,
            "command": f"Complete forms/systems/{subject}.yml and ingest it.",
            "reason": "System semantics require accountable owner input.",
            "scope": [evidence_type],
        }
    if evidence_type == "platform-owner-response":
        return {
            "action": "complete-platform-form",
            "subject": subject,
            "command": f"Complete forms/platforms/{subject}.yml and ingest it.",
            "reason": "Corporate platform ownership and policy cannot be inferred.",
            "scope": [evidence_type],
        }
    if evidence_type == "log-feature-summary":
        return {
            "action": "run-local-ai-job",
            "subject": subject,
            "command": "Run the generated intranet AI job after the system interview supplies approved log sources.",
            "reason": "Normalized log features are missing or stale.",
            "scope": [evidence_type],
        }
    if evidence_type in {"validation-result", "operator-acceptance"}:
        return {
            "action": "complete-validation-evidence",
            "subject": subject,
            "command": f"Create a completed {evidence_type} response after approved testing.",
            "reason": "This gate requires human-reviewed internal execution evidence.",
            "scope": [evidence_type],
        }
    if evidence_type == "benefit-baseline":
        return {
            "action": "complete-benefit-baseline",
            "subject": subject,
            "command": "Complete forms/campaign/benefit-baseline.yml and ingest it.",
            "reason": "Scale decision requires baseline value and support burden.",
            "scope": [evidence_type],
        }
    if kind == "platform":
        target = next(
            (item for item in campaign["platform_targets"] if item["id"] == subject),
            None,
        )
        host = target["host_alias"] if target else subject
        return {
            "action": "rerun-platform-collector",
            "subject": subject,
            "command": f"Use execution/{host}/Run.ps1 or execution/{host}/run.sh",
            "reason": f"Missing or stale {evidence_type}",
            "scope": [evidence_type],
        }
    return {
        "action": "supply-evidence",
        "subject": subject,
        "command": f"Supply schema-valid evidence for {evidence_type}.",
        "reason": "Required evidence is missing or stale.",
        "scope": [evidence_type],
    }


def targeted_rerun_plan(report: dict[str, Any], campaign: dict[str, Any]) -> dict[str, Any]:
    actions = []
    seen = set()
    for gap in report["blocking_gaps"]:
        action = _targeted_action(gap, campaign)
        key = (action["action"], action["subject"], tuple(action["scope"]))
        if key not in seen:
            actions.append(action)
            seen.add(key)
    return {
        "schema_version": "3.0.0",
        "campaign_id": campaign["campaign"]["id"],
        "generated_at_utc": utc_now(),
        "action_count": len(actions),
        "actions": actions,
        "broad_campaign_rerun_required": False,
    }


def status_campaign(directory: Path) -> dict[str, Any]:
    campaign = load_campaign(directory)
    ledger = _load_ledger(directory)
    records = _evidence_records(directory, ledger)
    report = coverage_report(campaign, records, ledger["conflicts"])
    plan = targeted_rerun_plan(report, campaign)
    return {
        "schema_version": "3.0.0",
        "campaign": campaign["campaign"],
        "evidence_count": len(records),
        "conflict_count": len(ledger["conflicts"]),
        "coverage": report["gates"],
        "blocking_gap_count": len(report["blocking_gaps"]),
        "targeted_action_count": plan["action_count"],
        "next_actions": plan["actions"],
    }


def _response_records(records: list[dict[str, Any]], response_type: str) -> dict[str, dict[str, Any]]:
    result = {}
    for record in records:
        if record["evidence_type"] == response_type and record["collector"]["status"] == "success":
            result[record["subject"]["id"]] = record
    return result


def build_ai_jobs(directory: Path) -> dict[str, Any]:
    campaign = load_campaign(directory)
    ledger = _load_ledger(directory)
    records = _evidence_records(directory, ledger)
    interviews = _response_records(records, "system-interview")
    jobs = []
    blockers = []

    jobs_dir = directory / "ai-jobs"
    jobs_dir.mkdir(parents=True, exist_ok=True)
    prompt_source = Path(__file__).resolve().parents[2] / "prompts/intranet-log-feature-extraction.md"
    if prompt_source.exists():
        shutil.copy2(prompt_source, jobs_dir / "intranet-log-feature-extraction.md")

    for system in campaign["systems"]:
        system_id = system["id"]
        interview = interviews.get(system_id)
        if not interview:
            blockers.append(
                {
                    "system_id": system_id,
                    "reason": "Completed system interview is required before approved log sources can be selected.",
                    "action": f"Complete forms/systems/{system_id}.yml and ingest it.",
                }
            )
            continue
        answers = interview["payload"]["answers"]
        sources = [
            item
            for item in answers.get("log_sources", [])
            if isinstance(item, dict) and item.get("approved") is True
        ]
        if not sources:
            blockers.append(
                {
                    "system_id": system_id,
                    "reason": "No approved local log sources were supplied.",
                    "action": f"Add approved log sources to forms/systems/{system_id}.yml and re-ingest.",
                }
            )
            continue
        job = {
            "schema_version": "3.0.0",
            "job_id": f"log-feature-extraction:{system_id}",
            "campaign_id": campaign["campaign"]["id"],
            "system_id": system_id,
            "purpose": "log-feature-extraction",
            "input_policy": {
                "raw_evidence_remains_intranet": True,
                "max_bytes_per_chunk": 5_000_000,
                "chunk_overlap_lines": 25,
                "rare_event_pass": True,
            },
            "sources": sources,
            "prompt_file": "ai-jobs/intranet-log-feature-extraction.md",
            "output_schema": "schemas/log-feature-summary.schema.json",
            "output_file": f"ai-results/{system_id}.log-feature-summary.json",
            "coverage": {
                "normal_window": answers.get("normal_log_window"),
                "high_load_window": answers.get("high_load_log_window"),
                "incident_windows": answers.get("incident_log_windows", []),
            },
            "root_cause_confirmation_allowed": False,
        }
        errors = validate_data("ai-job", job)
        if errors:
            raise CampaignError(
                f"Generated AI job for {system_id} is invalid:\n- " + "\n- ".join(errors)
            )
        dump_json(jobs_dir / f"{system_id}.json", job)
        jobs.append(job)

    summary = {
        "schema_version": "3.0.0",
        "campaign_id": campaign["campaign"]["id"],
        "generated_at_utc": utc_now(),
        "job_count": len(jobs),
        "blocker_count": len(blockers),
        "jobs": [item["job_id"] for item in jobs],
        "blockers": blockers,
        "execution": (
            "Run scripts/campaign/run_ai_jobs.py inside the corporate environment "
            "with the approved OpenCode/Llama command adapter."
        ),
    }
    dump_json(jobs_dir / "job-index.json", summary)
    campaign["campaign"]["status"] = "ai-jobs-built"
    dump_yaml(directory / CAMPAIGN_FILE, campaign)
    return summary


def _safe_answers(record: dict[str, Any] | None) -> dict[str, Any]:
    if not record:
        return {}
    return deepcopy(record.get("payload", {}).get("answers", {}))


def _service_items(answers: dict[str, Any]) -> list[dict[str, Any]]:
    result = []
    for index, item in enumerate(answers.get("required_services", [])):
        if isinstance(item, str):
            value = {
                "id": slug(item, fallback=f"service-{index+1}"),
                "display_name": item,
                "required": True,
                "runtime": "unknown",
                "health_definition": "TBD: service state is not sufficient for functional health.",
            }
        elif isinstance(item, dict):
            value = {
                "id": slug(str(item.get("id") or item.get("name") or f"service-{index+1}")),
                "display_name": str(item.get("display_name") or item.get("name") or f"Service {index+1}"),
                "required": bool(item.get("required", True)),
                "runtime": item.get("runtime", "unknown"),
                "service_name_ref": item.get("service_name_ref"),
                "process_name_ref": item.get("process_name_ref"),
                "host_group": item.get("host_group"),
                "health_definition": item.get("health_definition")
                or "TBD: define functional evidence, not only process state.",
                "restart_policy": item.get("restart_policy"),
                "safe_restart": item.get("safe_restart", "TBD"),
                "notes": list(item.get("notes", [])),
            }
        else:
            continue
        result.append(value)
    return result


def _dependency_items(answers: dict[str, Any]) -> list[dict[str, Any]]:
    result = []
    allowed_types = {
        "mssql", "oracle", "database", "file-share", "local-filesystem",
        "tibco-rv", "message-bus", "http-api", "tcp-service",
        "equipment-interface", "dns", "time-service", "certificate", "other",
    }
    for index, item in enumerate(answers.get("dependencies", [])):
        if not isinstance(item, dict):
            continue
        dep_type = item.get("type", "other")
        if dep_type not in allowed_types:
            dep_type = "other"
        status = item.get("monitoring_status", "uninstrumented")
        if status not in {"uninstrumented", "candidate", "validated", "exception"}:
            status = "uninstrumented"
        result.append(
            {
                "id": slug(str(item.get("id") or item.get("name") or f"dependency-{index+1}")),
                "type": dep_type,
                "criticality": item.get("criticality", "TBD"),
                "health_evidence": item.get("health_evidence")
                or "TBD: define evidence that distinguishes dependency failure from probe failure.",
                "target_ref": item.get("target_ref"),
                "probe_type": item.get("probe_type", "none"),
                "network_probe_approved": item.get("network_probe_approved", "TBD"),
                "notes": list(item.get("notes", [])),
                "monitoring_status": status,
                "signal_id": item.get("signal_id"),
                "evidence_reference": item.get("evidence_reference"),
                "exception_reference": item.get("exception_reference"),
            }
        )
    return result


def _flow_items(answers: dict[str, Any]) -> list[dict[str, Any]]:
    result = []
    for index, item in enumerate(answers.get("data_flows", [])):
        if not isinstance(item, dict):
            continue
        stages = []
        for stage_index, stage in enumerate(item.get("stages", [])):
            if not isinstance(stage, dict):
                continue
            stages.append(
                {
                    "id": slug(str(stage.get("id") or stage.get("name") or f"stage-{stage_index+1}")),
                    "description": stage.get("description") or "TBD",
                    "evidence_source": stage.get("evidence_source") or "TBD",
                    "freshness_threshold_seconds": stage.get("freshness_threshold_seconds"),
                    "backlog_threshold": stage.get("backlog_threshold"),
                    "latency_objective_seconds": stage.get("latency_objective_seconds"),
                }
            )
        if not stages:
            stages = [
                {
                    "id": "functional-success",
                    "description": "TBD: functional success stage",
                    "evidence_source": "TBD",
                    "freshness_threshold_seconds": None,
                    "backlog_threshold": None,
                    "latency_objective_seconds": None,
                }
            ]
        result.append(
            {
                "id": slug(str(item.get("id") or item.get("name") or f"flow-{index+1}")),
                "description": item.get("description") or "TBD",
                "stages": stages,
                "success_definition": item.get("success_definition")
                or answers.get("functional_success")
                or "TBD",
                "failure_impact": item.get("failure_impact") or "TBD",
                "correlation_id_available": item.get("correlation_id_available", "TBD"),
                "high_cardinality_fields": list(item.get("high_cardinality_fields", [])),
                "notes": list(item.get("notes", [])),
            }
        )
    return result


def _candidate_signals(flows: list[dict[str, Any]], dependencies: list[dict[str, Any]]) -> list[dict[str, Any]]:
    signals = [
        {
            "id": "functional-up",
            "signal_type": "metric",
            "name": "metrology_functional_up",
            "purpose": "Demonstrate the intended system function.",
            "source": "TBD: approved synthetic or transaction evidence",
            "required": True,
            "metric_type": "gauge",
            "unit": "ratio",
            "labels": ["metrology_system", "service"],
            "collection_interval_seconds": 60,
            "expected_cardinality": "bounded",
            "retention_class": "company-default",
            "privacy_risk": "low",
            "validation_needed": "Controlled functional failure and recovery.",
            "enabled": False,
            "coverage_category": "functional_availability",
            "cardinality_limit": 100,
            "label_value_limits": {"metrology_system": 1, "service": 20},
            "validation_status": "unvalidated",
            "evidence_reference": None,
        },
        {
            "id": "probe-health",
            "signal_type": "metric",
            "name": "metrology_probe_success",
            "purpose": "Show whether the evidence probe executed successfully.",
            "source": "bounded probe supervisor",
            "required": True,
            "metric_type": "gauge",
            "unit": "ratio",
            "labels": ["metrology_system", "probe"],
            "collection_interval_seconds": 60,
            "expected_cardinality": "bounded",
            "retention_class": "company-default",
            "privacy_risk": "none",
            "validation_needed": "Scheduler stop and probe failure tests.",
            "enabled": False,
            "coverage_category": "telemetry_path",
            "cardinality_limit": 100,
            "label_value_limits": {"metrology_system": 1, "probe": 50},
            "validation_status": "unvalidated",
            "evidence_reference": None,
        },
    ]
    if flows:
        signals.extend(
            [
                {
                    "id": "transactions",
                    "signal_type": "metric",
                    "name": "metrology_transactions_total",
                    "purpose": "Count bounded stage outcomes.",
                    "source": "TBD: application or log-derived aggregate",
                    "required": True,
                    "metric_type": "counter",
                    "unit": "transactions",
                    "labels": ["metrology_system", "flow", "stage", "outcome"],
                    "collection_interval_seconds": 60,
                    "expected_cardinality": "bounded",
                    "retention_class": "company-default",
                    "privacy_risk": "low",
                    "validation_needed": "Reconcile with approved source.",
                    "enabled": False,
                    "coverage_category": "traffic",
                    "cardinality_limit": 1000,
                    "label_value_limits": {
                        "metrology_system": 1,
                        "flow": 20,
                        "stage": 20,
                        "outcome": 6,
                    },
                    "validation_status": "unvalidated",
                    "evidence_reference": None,
                },
                {
                    "id": "freshness",
                    "signal_type": "metric",
                    "name": "metrology_last_success_unixtime_seconds",
                    "purpose": "Expose time of last successful bounded stage.",
                    "source": "TBD",
                    "required": True,
                    "metric_type": "gauge",
                    "unit": "seconds",
                    "labels": ["metrology_system", "flow", "stage"],
                    "collection_interval_seconds": 60,
                    "expected_cardinality": "bounded",
                    "retention_class": "company-default",
                    "privacy_risk": "low",
                    "validation_needed": "Validate timestamps, idle behavior, and clock skew.",
                    "enabled": False,
                    "coverage_category": "freshness",
                    "cardinality_limit": 400,
                    "label_value_limits": {
                        "metrology_system": 1,
                        "flow": 20,
                        "stage": 20,
                    },
                    "validation_status": "unvalidated",
                    "evidence_reference": None,
                },
                {
                    "id": "backlog",
                    "signal_type": "metric",
                    "name": "metrology_backlog_items",
                    "purpose": "Measure bounded pending items and support oldest-age analysis.",
                    "source": "TBD",
                    "required": False,
                    "metric_type": "gauge",
                    "unit": "items",
                    "labels": ["metrology_system", "flow", "stage"],
                    "collection_interval_seconds": 60,
                    "expected_cardinality": "bounded",
                    "retention_class": "company-default",
                    "privacy_risk": "low",
                    "validation_needed": "Validate demand bursts, partial work, and drain behavior.",
                    "enabled": False,
                    "coverage_category": "backlog",
                    "cardinality_limit": 400,
                    "label_value_limits": {
                        "metrology_system": 1,
                        "flow": 20,
                        "stage": 20,
                    },
                    "validation_status": "unvalidated",
                    "evidence_reference": None,
                },
            ]
        )
    if dependencies:
        signals.append(
            {
                "id": "dependency",
                "signal_type": "metric",
                "name": "metrology_dependency_up",
                "purpose": "Expose specifically declared dependency evidence.",
                "source": "approved exporter, application metric, or bounded probe",
                "required": False,
                "metric_type": "gauge",
                "unit": "ratio",
                "labels": ["metrology_system", "dependency"],
                "collection_interval_seconds": 60,
                "expected_cardinality": "bounded",
                "retention_class": "company-default",
                "privacy_risk": "low",
                "validation_needed": "Distinguish dependency failure from probe failure.",
                "enabled": False,
                "coverage_category": "dependencies",
                "cardinality_limit": 100,
                "label_value_limits": {
                    "metrology_system": 1,
                    "dependency": 100,
                },
                "validation_status": "unvalidated",
                "evidence_reference": None,
            }
        )
    return signals


def _log_items(answers: dict[str, Any]) -> list[dict[str, Any]]:
    result = []
    for index, item in enumerate(answers.get("log_sources", [])):
        if not isinstance(item, dict):
            continue
        result.append(
            {
                "id": slug(str(item.get("source_alias") or f"log-{index+1}")),
                "source_type": item.get("source_type", "file"),
                "path_or_source_ref": str(item.get("source_alias") or f"log-source-{index+1}"),
                "format": item.get("format", "unknown"),
                "timestamp_field": item.get("timestamp_field"),
                "severity_field": item.get("severity_field"),
                "correlation_fields": list(item.get("correlation_fields", [])),
                "contains_sensitive_data": item.get("classification", "confidential")
                in {"confidential", "restricted"},
                "raw_export_allowed": False,
                "splunk_sourcetype": item.get("splunk_sourcetype"),
                "retention_class": item.get("retention_class"),
                "notes": ["Exact local path remains inside the corporate environment."],
            }
        )
    return result


def _profile_environment(value: str) -> str:
    return value if value in {"development", "test", "staging", "production"} else "mixed"


def _draft_profiles(
    campaign: dict[str, Any],
    records: list[dict[str, Any]],
    system_aliases: dict[str, str],
    owner_alias: callable,
    technical_alias: callable,
) -> tuple[dict[str, dict[str, Any]], dict[str, list[str]]]:
    interviews = _response_records(records, "system-interview")
    discoveries = defaultdict(list)
    for record in records:
        if record["evidence_type"] == "host-discovery":
            for system_id in record["subject"].get("system_ids", []):
                discoveries[system_id].append(record)

    profiles = {}
    validation_errors = {}
    for system in campaign["systems"]:
        internal_id = system["id"]
        external_id = system_aliases[internal_id]
        answers = _safe_answers(interviews.get(internal_id))
        services = _service_items(answers)
        dependencies = _dependency_items(answers)
        flows = _flow_items(answers)
        signals = _candidate_signals(flows, dependencies)
        for service in services:
            original_id = service["id"]
            alias_id = technical_alias(original_id, "svc")
            service["id"] = alias_id
            service["display_name"] = alias_id
            if service.get("service_name_ref"):
                service["service_name_ref"] = technical_alias(
                    str(service["service_name_ref"]), "svc"
                )
            if service.get("process_name_ref"):
                service["process_name_ref"] = technical_alias(
                    str(service["process_name_ref"]), "proc"
                )
            if service.get("host_group"):
                service["host_group"] = technical_alias(
                    str(service["host_group"]), "hostgroup"
                )
        for dependency in dependencies:
            dependency["id"] = technical_alias(dependency["id"], "dep")
            if dependency.get("target_ref"):
                dependency["target_ref"] = "CORPORATE-INTERNAL"
        for flow in flows:
            flow["id"] = technical_alias(flow["id"], "flow")
            for stage in flow["stages"]:
                stage["id"] = technical_alias(stage["id"], "stage")
        logs = _log_items(answers)
        for log in logs:
            log["id"] = technical_alias(log["id"], "log")
            log["path_or_source_ref"] = log["id"]
        os_families = sorted(
            {
                str(record.get("payload", {}).get("os", {}).get("family", "unknown"))
                for record in discoveries.get(internal_id, [])
            }
        ) or ["unknown"]
        os_families = [
            item if item in {"windows", "linux", "container", "mixed"} else "unknown"
            for item in os_families
        ]
        profile = {
            "schema_version": "1.0.0",
            "system": {
                "id": external_id,
                "display_name": f"System {external_id}",
                "environment": _profile_environment(system["environment"]),
                "criticality": answers.get("criticality", system["criticality"]),
                "support_tier": answers.get("support_tier", system["support_tier"]),
                "business_function": answers.get(
                    "business_function", system["business_function"]
                ),
                "related_systems": [],
                "tags": ["campaign-draft", "external-pseudonymized"],
                "lifecycle": "pilot"
                if system["lifecycle"] in {"candidate", "pilot"}
                else system["lifecycle"],
            },
            "platform": {
                "os_families": os_families,
                "deployment_model": "unknown",
                "host_count": sum(
                    internal_id in host["system_ids"] for host in campaign["hosts"]
                ),
                "site_prometheus_available": True,
                "site_splunk_available": True,
                "otel_allowed": "TBD",
                "notes": [
                    "Generated from campaign evidence; exact topology requires corporate verification."
                ],
            },
            "ownership": {
                "owner_team": "metrology-software",
                "primary_owner": owner_alias(
                    str(answers.get("primary_owner", system["owner"]))
                ),
                "backup_owner": owner_alias(
                    str(answers.get("backup_owner", system["backup"]))
                ),
                "technician_sop_coverage": "TBD",
                "escalation_path": "TBD",
            },
            "services": services,
            "dependencies": dependencies,
            "data_flows": flows,
            "signals": signals,
            "logs": logs,
            "alerts": [],
            "data_handling": {
                "raw_logs_remain_intranet": True,
                "credentials_prohibited": True,
                "internal_identifiers_external_policy": "pseudonymize",
                "high_cardinality_policy": "logs-only",
                "approved_external_fields": [
                    "pseudonymized_system_id",
                    "os_family",
                    "bounded_capabilities",
                    "normalized_log_features",
                    "aggregate_counts",
                ],
                "notes": [
                    "Candidate signals are disabled until corporate validation."
                ],
            },
            "implementation": {
                "enable_prometheus": True,
                "enable_splunk": True,
                "enable_otel": False,
                "scrape_interval": "60s",
                "evaluation_interval": "60s",
                "prometheus_job_name": external_id,
                "metrics_path": "/metrics",
                "otel_mode": "none",
                "deployment_owner": "TBD",
                "change_ticket": "TBD",
                "platform_profile_ref": "../platform-profile.draft.yml",
                "generation_mode": "reference",
                "production_alerts_allowed": False,
                "generated_alert_lifecycle": "draft",
                "generated_alert_validation_status": "unvalidated",
                "generated_alert_evidence_reference": None,
                "production_approval_reference": None,
                "operator_acceptance_reference": None,
                "rollback_validation_reference": None,
            },
            "assumptions": [
                "Candidate signals remain disabled until source reconciliation and failure testing.",
                "Discovery does not establish business criticality or functional success.",
            ],
            "open_questions": [
                question
                for question in [
                    None
                    if answers.get("functional_success")
                    and not PLACEHOLDER.match(str(answers["functional_success"]))
                    else "What exact observable transaction proves functional success?",
                    None
                    if services
                    else "Which services are required for the business function?",
                    None
                    if flows
                    else "What are the input-to-output stages and success evidence?",
                    None
                    if dependencies
                    else "Which dependencies are required and how is failure distinguished from probe failure?",
                ]
                if question
            ],
        }
        errors = validate_data("profile", profile)
        profiles[external_id] = profile
        validation_errors[external_id] = errors
    return profiles, validation_errors


def _draft_platform_profile(
    campaign: dict[str, Any],
    records: list[dict[str, Any]],
    organization_alias: str,
    owner_alias: callable,
) -> dict[str, Any]:
    owner_records = _response_records(records, "platform-owner-response")
    capability_records = {
        record["subject"]["id"]: record
        for record in records
        if record["evidence_type"]
        in {"prometheus-capabilities", "splunk-capabilities", "otel-capabilities"}
    }

    by_kind: dict[str, list[tuple[dict[str, Any], dict[str, Any]]]] = defaultdict(list)
    for target in campaign["platform_targets"]:
        owner = owner_records.get(target["id"])
        capability = capability_records.get(target["id"])
        by_kind[target["kind"]].append(
            (_safe_answers(owner), capability.get("payload", {}) if capability else {})
        )

    prometheus_owner = by_kind.get("prometheus", [({}, {})])[0][0]
    prometheus_cap = by_kind.get("prometheus", [({}, {})])[0][1]
    splunk_owner = by_kind.get("splunk", [({}, {})])[0][0]
    splunk_cap = by_kind.get("splunk", [({}, {})])[0][1]
    otel_owner = by_kind.get("opentelemetry", [({}, {})])[0][0]
    otel_cap = by_kind.get("opentelemetry", [({}, {})])[0][1]

    def nullable(value: Any) -> Any:
        return None if value in {None, "", "TBD"} else value

    return {
        "schema_version": "1.0.0",
        "organization": {
            "id": organization_alias,
            "site": "TBD",
            "owner_team": owner_alias(
                str(
                    nullable(prometheus_owner.get("owner"))
                    or nullable(splunk_owner.get("owner"))
                    or "TBD"
                )
            ),
        },
        "prometheus": {
            "enabled": True,
            "distribution": prometheus_owner.get("distribution")
            or prometheus_cap.get("distribution")
            or "corporate-managed",
            "version": nullable(
                prometheus_owner.get("supported_version")
                or prometheus_cap.get("version")
            ),
            "service_discovery": prometheus_owner.get("service_discovery")
            or "corporate-managed",
            "rule_validation": prometheus_owner.get("validation_command")
            or "promtool",
            "dashboard_backend": nullable(prometheus_owner.get("dashboard_backend")),
            "alertmanager_managed": True,
            "max_series_per_system": (
                prometheus_owner.get("max_series_per_system")
                if isinstance(prometheus_owner.get("max_series_per_system"), int)
                else 10000
            ),
            "max_labels_per_metric": (
                prometheus_owner.get("max_labels_per_metric")
                if isinstance(prometheus_owner.get("max_labels_per_metric"), int)
                else 10
            ),
            "allowed_exporters": prometheus_owner.get("approved_exporters", []),
            "external_labels": {},
        },
        "splunk": {
            "enabled": True,
            "product": splunk_owner.get("product")
            or splunk_cap.get("product")
            or "unknown",
            "version": nullable(
                splunk_owner.get("supported_version") or splunk_cap.get("version")
            ),
            "ingestion_modes": splunk_owner.get("ingestion_modes") or ["unknown"],
            "cim_policy": splunk_owner.get("cim_policy", "preferred"),
            "default_index": nullable(
                next(iter(splunk_owner.get("index_mapping", {}).values()), None)
            ),
            "default_retention_class": nullable(
                splunk_owner.get("retention_policy")
            ),
            "scheduled_search_cost_review": True,
            "dashboard_backend": nullable(splunk_owner.get("dashboard_backend")),
        },
        "opentelemetry": {
            "allowed": bool(otel_owner.get("allowed", False)),
            "distribution": otel_owner.get("distribution")
            or otel_cap.get("distribution")
            or "unknown",
            "version": nullable(
                otel_owner.get("supported_version") or otel_cap.get("version")
            ),
            "modes": otel_owner.get("modes", []),
            "components": otel_owner.get(
                "components",
                {
                    "receivers": [],
                    "processors": [],
                    "exporters": [],
                    "extensions": [],
                },
            ),
        },
        "security": {
            "external_handoff_allowed": False,
            "credential_sources": ["environment", "file-provider"],
            "network_probe_default": "deny",
            "allowed_network_cidrs": [],
            "allow_private_addresses": True,
            "allow_loopback": False,
            "allow_link_local": False,
        },
        "delivery": {
            "config_delivery": "git-review",
            "canary_required": True,
            "production_approval_required": True,
            "supported_environments": [
                "development",
                "test",
                "staging",
                "production",
            ],
        },
    }


def _external_summary(
    campaign: dict[str, Any],
    records: list[dict[str, Any]],
    system_aliases: dict[str, str],
    host_aliases: dict[str, str],
    platform_aliases: dict[str, str],
    campaign_alias: str,
    evidence_alias: callable,
) -> dict[str, Any]:
    summaries = []
    for record in records:
        evidence_type = record["evidence_type"]
        subject = record["subject"]
        safe_subject = {
            "kind": subject["kind"],
            "id": (
                system_aliases.get(subject["id"])
                if subject["kind"] == "system"
                else host_aliases.get(subject["id"])
                if subject["kind"] == "host"
                else platform_aliases.get(subject["id"], subject["id"])
                if subject["kind"] == "platform"
                else campaign_alias
                if subject["kind"] == "campaign"
                else subject["id"]
            ),
        }
        payload = record.get("payload", {})
        if evidence_type == "host-discovery":
            safe_payload = {
                "os": payload.get("os", {}),
                "resource_summary": {
                    "logical_cpu_count": payload.get("resources", {}).get(
                        "logical_cpu_count"
                    ),
                    "filesystem_count": len(
                        payload.get("resources", {}).get("filesystems", [])
                    ),
                },
                "service_count": len(payload.get("services", [])),
                "process_name_count": len(payload.get("process_summary", [])),
                "listening_port_count": len(payload.get("listening_ports", [])),
                "observability": payload.get("observability", {}),
                "warning_count": len(payload.get("warnings", [])),
                "raw_content_included": False,
            }
        elif evidence_type in {
            "prometheus-capabilities",
            "splunk-capabilities",
            "otel-capabilities",
            "environment",
        }:
            safe_payload = {
                key: value
                for key, value in payload.items()
                if key
                not in {
                    "paths",
                    "config_paths",
                    "environment_variables",
                    "endpoints",
                    "addresses",
                    "credentials",
                }
            }
        elif evidence_type == "system-interview":
            answers = deepcopy(payload.get("answers", {}))
            for source in answers.get("log_sources", []):
                if isinstance(source, dict):
                    source.pop("path", None)
            safe_payload = {"answers": answers}
        elif evidence_type == "platform-owner-response":
            answers = deepcopy(payload.get("answers", {}))
            for key in list(answers):
                if any(token in key.lower() for token in ("endpoint", "path", "repository")):
                    answers[key] = "CORPORATE-INTERNAL"
            safe_payload = {"answers": answers}
        elif evidence_type == "log-feature-summary":
            safe_payload = payload
        else:
            safe_payload = {
                "status": record["collector"]["status"],
                "evidence_references": payload.get("evidence_references", []),
                "summary": payload.get("summary"),
            }
        summaries.append(
            {
                "evidence_id": evidence_alias(record["evidence_id"]),
                "evidence_type": evidence_type,
                "subject": safe_subject,
                "completed_at_utc": record["collector"]["completed_at_utc"],
                "status": record["collector"]["status"],
                "payload": safe_payload,
                "raw_logs_included": False,
                "raw_configs_included": False,
            }
        )
    return {
        "schema_version": "3.0.0",
        "campaign_id": campaign_alias,
        "generated_at_utc": utc_now(),
        "records": summaries,
    }



def _questionnaire_status(
    campaign: dict[str, Any],
    records: list[dict[str, Any]],
) -> dict[str, Any]:
    questionnaire_path = (
        Path(__file__).resolve().parents[2]
        / "questionnaires/v3-principal-evidence-questionnaire.yml"
    )
    questionnaire = load_data(questionnaire_path)
    available_types = {record["evidence_type"] for record in records}
    approval = load_data(
        Path(__file__).resolve().parents[2]
        / "approvals/v3-defaults.approved.yml"
    )
    approved_defaults = {
        item["id"]: item.get("override") or item["recommended_default"]
        for item in approval["decisions"]
        if item.get("approved") is True
    }

    rows = []
    counts = defaultdict(int)
    for question in questionnaire["questions"]:
        method = question["collection_method"]
        category = question["category"]
        evidence_types = []
        status = "unresolved"
        answer = None

        if method == "pre-answered":
            status = "design-decision"
            answer = question["recommended_answer"]
        elif question.get("manager_approval_required"):
            status = "approved-default"
            answer = question["recommended_answer"]
        elif method == "auto":
            if category == "06-host-os-discovery":
                evidence_types = ["host-discovery", "environment"]
        elif method == "platform-collector":
            if category == "07-prometheus":
                evidence_types = ["prometheus-capabilities"]
            elif category == "08-splunk":
                evidence_types = ["splunk-capabilities"]
            elif category == "09-opentelemetry":
                evidence_types = ["otel-capabilities"]
        elif method in {"interview", "interview-and-analysis", "auto-plus-review"}:
            if category in {"10-application-semantics", "11-integrations"}:
                evidence_types = ["system-interview"]
            elif category in {"07-prometheus", "08-splunk", "09-opentelemetry"}:
                evidence_types = ["platform-owner-response"]
        elif method == "local-ai":
            evidence_types = ["log-feature-summary"]
        elif method in {"import", "import-and-review"}:
            evidence_types = ["inventory-snapshot"]
        elif method in {"validation-plan", "operator-test"}:
            evidence_types = ["validation-result", "operator-acceptance"]
        elif method in {"import-and-measure"}:
            evidence_types = ["benefit-baseline"]

        matched = sorted(set(evidence_types) & available_types)
        if status == "unresolved" and matched:
            status = "evidence-available"
            answer = "See referenced campaign evidence."
        counts[status] += 1
        rows.append(
            {
                "id": question["id"],
                "category": category,
                "prompt": question["prompt"],
                "recommended_answer": question["recommended_answer"],
                "status": status,
                "answer": answer,
                "evidence_types": matched,
                "owner": question.get("preferred_evidence_source"),
                "gate": question.get("blocks"),
            }
        )
    return {
        "schema_version": "3.0.0",
        "campaign_id": campaign["campaign"]["id"],
        "question_count": len(rows),
        "counts": dict(counts),
        "approved_decision_count": len(approved_defaults),
        "questions": rows,
        "limitations": [
            "Evidence availability does not by itself prove a question is fully answered.",
            "Question-specific human review remains required for consequential decisions.",
        ],
    }


def _alias_factory(salt: bytes):
    mapping: dict[str, str] = {}

    def alias(value: str, prefix: str) -> str:
        if not value or PLACEHOLDER.match(value):
            return "TBD"
        digest = hmac.new(salt, value.encode("utf-8"), hashlib.sha256).hexdigest()[:12]
        result = f"{prefix}-{digest}"
        mapping[result] = value
        return result

    return alias, mapping


def _zip_directory(source: Path, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    if temporary.exists():
        temporary.unlink()
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(source.rglob("*"), key=lambda item: str(item.relative_to(source))):
            if not path.is_file():
                continue
            relative = str(path.relative_to(source)).replace("\\", "/")
            info = zipfile.ZipInfo(relative, date_time=(2026, 8, 3, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100640 << 16
            archive.writestr(info, path.read_bytes())
    os.replace(temporary, output)



def _replace_identities(value: Any, replacements: dict[str, str]) -> Any:
    ordered = sorted(replacements.items(), key=lambda item: len(item[0]), reverse=True)
    protected = {
        external: f"__OBS_ALIAS_{index:06d}__"
        for index, external in enumerate(
            sorted(set(replacements.values()), key=len, reverse=True)
        )
        if external and external != "TBD"
    }

    def replace_string(source: str) -> str:
        result = source
        for external, token in protected.items():
            result = result.replace(external, token)
        for internal, external in ordered:
            if internal and internal != external:
                result = result.replace(internal, external)
        for external, token in protected.items():
            result = result.replace(token, external)
        return result

    if isinstance(value, dict):
        return {
            replace_string(key) if isinstance(key, str) else key:
            _replace_identities(item, replacements)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_replace_identities(item, replacements) for item in value]
    if not isinstance(value, str):
        return value
    return replace_string(value)


def finalize_campaign(
    directory: Path,
    external_output: Path,
    *,
    force: bool = False,
) -> dict[str, Any]:
    campaign = load_campaign(directory)
    ledger = _load_ledger(directory)
    records = _evidence_records(directory, ledger)
    coverage = coverage_report(campaign, records, ledger["conflicts"])
    rerun = targeted_rerun_plan(coverage, campaign)

    internal = directory / "output/internal"
    external = directory / "output/external"
    if internal.exists():
        shutil.rmtree(internal)
    if external.exists():
        shutil.rmtree(external)
    internal.mkdir(parents=True)
    external.mkdir(parents=True)

    dump_json(internal / "evidence-coverage.json", coverage)
    dump_json(internal / "targeted-rerun-plan.json", rerun)
    dump_json(internal / "conflicts.json", ledger["conflicts"])

    salt_path = directory / "state/external-pseudonymization-salt.bin"
    if salt_path.exists():
        try:
            salt = bytes.fromhex(
                salt_path.read_text(encoding="ascii").strip()
            )
        except ValueError as exc:
            raise CampaignError(
                "Existing external pseudonymization salt is invalid"
            ) from exc
        if len(salt) < 32:
            raise CampaignError("Existing external pseudonymization salt is too short")
    else:
        salt = os.urandom(32)
        salt_path.parent.mkdir(parents=True, exist_ok=True)
        atomic_write(salt_path, salt.hex() + "\n", 0o600)

    alias, mapping = _alias_factory(salt)
    campaign_alias = alias(campaign["campaign"]["id"], "campaign")
    system_aliases = {
        item["id"]: alias(item["id"], "sys") for item in campaign["systems"]
    }
    host_aliases = {
        item["alias"]: alias(item["alias"], "host") for item in campaign["hosts"]
    }
    platform_aliases = {
        item["id"]: alias(item["id"], "platform")
        for item in campaign["platform_targets"]
    }
    owner_alias = lambda value: alias(value, "owner")
    evidence_alias = lambda value: alias(value, "evidence")
    organization_alias = alias("corporate-organization", "org")
    identity_replacements = {
        campaign["campaign"]["id"]: campaign_alias,
        **system_aliases,
        **host_aliases,
        **platform_aliases,
    }

    profiles, profile_errors = _draft_profiles(
        campaign,
        records,
        system_aliases,
        owner_alias,
        alias,
    )
    platform_profile = _draft_platform_profile(
        campaign,
        records,
        organization_alias,
        owner_alias,
    )
    # Alias calls made while drafting profiles/platform ownership are now
    # available in the local-only reverse map.
    identity_replacements.update(
        {
            internal: external
            for external, internal in mapping.items()
            if internal and external != "TBD"
        }
    )

    external_findings = []
    platform_profile = sanitize_value(
        _replace_identities(platform_profile, identity_replacements),
        external_findings,
        "$.platform_profile",
    )
    profiles = {
        system_id: sanitize_value(
            _replace_identities(profile, identity_replacements),
            external_findings,
            f"$.system_profiles.{system_id}",
        )
        for system_id, profile in profiles.items()
    }
    blocking_external = [item for item in external_findings if item.blocking]
    if blocking_external:
        raise CampaignError(
            "External profile sanitization found prohibited content: "
            + ", ".join(
                f"{item.path}:{item.category}" for item in blocking_external
            )
        )

    platform_errors = validate_data("platform", platform_profile)
    for profile in profiles.values():
        profile["implementation"]["platform_profile_ref"] = (
            "../platform-profile.draft.yml"
        )
    profile_errors = {
        system_id: validate_data("profile", profile)
        for system_id, profile in profiles.items()
    }

    dump_yaml(external / "platform-profile.draft.yml", platform_profile)
    for system_id, profile in profiles.items():
        dump_yaml(external / f"system-profiles/{system_id}.yml", profile)

    fleet = {
        "schema_version": "3.0.0",
        "campaign_id": campaign_alias,
        "systems": [
            {
                "system_id": system_aliases[item["id"]],
                "environment": item["environment"],
                "criticality": item["criticality"],
                "support_tier": item["support_tier"],
                "lifecycle": item["lifecycle"],
                "host_count": sum(
                    item["id"] in host["system_ids"] for host in campaign["hosts"]
                ),
            }
            for item in campaign["systems"]
        ],
        "hosts": [
            {
                "host_alias": host_aliases[item["alias"]],
                "system_ids": [system_aliases[value] for value in item["system_ids"]],
                "os_hint": item["os_hint"],
                "roles": item["roles"],
            }
            for item in campaign["hosts"]
        ],
    }
    safe_summary = _replace_identities(
        _external_summary(
            campaign,
            records,
            system_aliases,
            host_aliases,
            platform_aliases,
            campaign_alias,
            evidence_alias,
        ),
        identity_replacements,
    )
    questionnaire_status = _replace_identities(
        _questionnaire_status(campaign, records),
        identity_replacements,
    )
    external_coverage = _replace_identities(coverage, identity_replacements)
    external_conflicts = _replace_identities(
        ledger["conflicts"], identity_replacements
    )
    external_rerun = _replace_identities(rerun, identity_replacements)

    # Only evidence-derived structures require value sanitization. Generated
    # relative filenames and command guidance are identity-replaced but not run
    # through the broad FQDN detector, which would misclassify names like run.sh.
    safe_summary = sanitize_value(
        safe_summary, external_findings, "$.evidence_summary"
    )
    external_conflicts = sanitize_value(
        external_conflicts, external_findings, "$.conflicts"
    )
    blocking_external = [item for item in external_findings if item.blocking]
    if blocking_external:
        raise CampaignError(
            "External evidence sanitization found prohibited content: "
            + ", ".join(
                f"{item.path}:{item.category}" for item in blocking_external
            )
        )
    dump_yaml(external / "fleet-inventory.sanitized.yml", fleet)
    dump_json(external / "evidence-summary.sanitized.json", safe_summary)
    dump_json(external / "questionnaire-evidence-status.json", questionnaire_status)
    dump_json(external / "evidence-coverage.json", external_coverage)
    dump_json(
        external / "blocking-gaps.json",
        external_coverage["blocking_gaps"],
    )
    dump_json(external / "conflicts.json", external_conflicts)
    dump_json(external / "targeted-rerun-plan.json", external_rerun)
    dump_json(
        external / "profile-validation.json",
        {
            "platform_profile_errors": platform_errors,
            "system_profile_errors": profile_errors,
        },
    )
    atomic_write(
        external / "README.md",
        f"""# Sanitized Observability Campaign Return Bundle

Campaign: `{campaign_alias}`  
Generated: {utc_now()}  
Production validated: **No**

This bundle contains pseudonymized structured evidence, draft profiles,
coverage, conflicts, and targeted rerun actions. It contains no raw logs,
raw configurations, credentials, endpoint inventories, or pseudonymization map.

Gate completeness:

- Design: {coverage['gates']['design']['percentage']}%
- Pilot: {coverage['gates']['pilot']['percentage']}%
- Production: {coverage['gates']['production']['percentage']}%
- Scale: {coverage['gates']['scale']['percentage']}%

Corporate deployment, failure testing, routing, operator acceptance, and
production approval remain internal actions.
""",
    )

    files = []
    for path in sorted(external.rglob("*")):
        if path.is_file() and path.name != "return-bundle-manifest.json":
            files.append(
                {
                    "path": str(path.relative_to(external)).replace("\\", "/"),
                    "sha256": sha256_file(path),
                    "size_bytes": path.stat().st_size,
                }
            )
    manifest = {
        "schema_version": "3.0.0",
        "campaign_id": campaign_alias,
        "generated_at_utc": utc_now(),
        "completeness": external_coverage["gates"],
        "files": files,
        "blocking_gaps": external_coverage["blocking_gaps"],
        "conflicts": external_conflicts,
        "policy": {
            "raw_logs_included": False,
            "raw_configs_included": False,
            "identities_pseudonymized": True,
            "production_validated": False,
        },
        "human_approval": {"approved": False},
    }
    errors = validate_data("campaign-return", manifest)
    if errors:
        raise CampaignError("Return manifest is invalid:\n- " + "\n- ".join(errors))
    dump_json(external / "return-bundle-manifest.json", manifest)

    findings = scan_tree(external)
    blocking_findings = [item for item in findings if item.blocking]
    dump_json(
        external / "external-security-screen.json",
        {
            "schema_version": "3.0.0",
            "blocking_count": len(blocking_findings),
            "review_count": sum(1 for item in findings if not item.blocking),
            "findings": findings_to_dicts(findings),
            "human_review_required": True,
        },
    )
    if blocking_findings:
        raise CampaignError(
            "External return bundle failed security screening: "
            + ", ".join(
                f"{item.path}:{item.category}" for item in blocking_findings
            )
        )

    # Rebuild the manifest after adding the security-screen report.
    files = []
    for item_path in sorted(external.rglob("*")):
        if item_path.is_file() and item_path.name != "return-bundle-manifest.json":
            files.append(
                {
                    "path": str(item_path.relative_to(external)).replace("\\", "/"),
                    "sha256": sha256_file(item_path),
                    "size_bytes": item_path.stat().st_size,
                }
            )
    manifest["files"] = files
    manifest_errors = validate_data("campaign-return", manifest)
    if manifest_errors:
        raise CampaignError(
            "Final return manifest is invalid:\n- "
            + "\n- ".join(manifest_errors)
        )
    dump_json(external / "return-bundle-manifest.json", manifest)

    if external_output.exists():
        if not force:
            raise CampaignError(f"External output already exists: {external_output}")
        external_output.unlink()
    _zip_directory(external, external_output)

    # The alias map is intentionally corporate-local and excluded from the ZIP.
    dump_json(
        directory / "state/external-alias-map.DO-NOT-TRANSFER.json",
        {"schema_version": "3.0.0", "mapping": mapping},
    )
    campaign["campaign"]["status"] = (
        "blocked" if coverage["blocking_gaps"] or ledger["conflicts"] else "finalized"
    )
    campaign["state"]["blocking_gap_count"] = len(coverage["blocking_gaps"])
    _update_campaign_state(
        directory,
        campaign,
        ledger,
        campaign["campaign"]["status"],
    )
    return {
        "external_output": str(external_output),
        "sha256": sha256_file(external_output),
        "status": campaign["campaign"]["status"],
        "coverage": coverage["gates"],
        "blocking_gap_count": len(coverage["blocking_gaps"]),
        "conflict_count": len(ledger["conflicts"]),
        "targeted_action_count": rerun["action_count"],
        "production_validated": False,
    }


def build_runners(directory: Path, *, force: bool = False) -> dict[str, Any]:
    campaign = load_campaign(directory)
    repository_root = Path(__file__).resolve().parents[2]
    runner_source = repository_root / "scripts/campaign/run_campaign.py"
    linux_source = repository_root / "scripts/linux/collect_server_discovery.py"
    windows_source = repository_root / "scripts/windows/Collect-ServerDiscovery.ps1"
    for required in [runner_source, linux_source, windows_source]:
        if not required.exists():
            raise CampaignError(f"Required runner source is missing: {required}")

    ledger = _load_ledger(directory)
    records = _evidence_records(directory, ledger)
    platform_responses = _response_records(records, "platform-owner-response")

    execution = directory / "execution"
    bundles = execution / "bundles"
    bundles.mkdir(parents=True, exist_ok=True)
    created = []

    for host in campaign["hosts"]:
        host_dir = execution / host["alias"]
        if host_dir.exists():
            if not force:
                raise CampaignError(
                    f"Runner directory already exists: {host_dir}; use --force"
                )
            shutil.rmtree(host_dir)
        host_dir.mkdir(parents=True)

        targets = []
        for target in campaign["platform_targets"]:
            if target["host_alias"] != host["alias"]:
                continue
            response = platform_responses.get(target["id"])
            answers = _safe_answers(response)
            targets.append(
                {
                    **target,
                    "approved_config_paths": list(
                        answers.get("approved_config_paths", [])
                    ),
                    "collect_components": bool(
                        answers.get("collect_components", False)
                    ),
                }
            )
        manifest = {
            "schema_version": "3.0.0",
            "campaign_id": campaign["campaign"]["id"],
            "run_id": f"{host['alias']}-{datetime.now().strftime('%Y%m%dT%H%M%S')}",
            "repository_version": __version__,
            "host": host,
            "platform_targets": targets,
            "policies": {
                "normal_privilege_first": True,
                "raw_logs_external": False,
                "raw_configs_external": False,
                "output_file_mode": "0640",
                "network_connections_allowed": False,
                "production_changes_allowed": False,
            },
            "limits": {
                "host_discovery_seconds": 120,
                "max_services": 5000,
                "max_processes": 2000,
                "max_ports": 2000,
            },
            "review": {
                "approved_for_host": False,
                "reviewer_role": None,
                "review_reference": None,
                "instruction": (
                    "Review the host alias, paths, collectors, and limits. Set "
                    "approved_for_host true only in the corporate copy."
                ),
            },
        }
        manifest_errors = validate_data("host-run", manifest)
        if manifest_errors:
            raise CampaignError(
                f"Generated host-run manifest is invalid for {host['alias']}:\n- "
                + "\n- ".join(manifest_errors)
            )
        dump_json(host_dir / "host-run-manifest.json", manifest)
        shutil.copy2(runner_source, host_dir / "run_campaign.py")
        shutil.copy2(linux_source, host_dir / "collect_server_discovery.py")
        shutil.copy2(windows_source, host_dir / "Collect-ServerDiscovery.ps1")
        atomic_write(
            host_dir / "run.sh",
            '#!/usr/bin/env sh\nset -eu\npython3 run_campaign.py '
            '--manifest host-run-manifest.json --output output\n',
            0o750,
        )
        atomic_write(
            host_dir / "Run.ps1",
            '[CmdletBinding()]\nparam()\n$ErrorActionPreference = "Stop"\n'
            'python .\\run_campaign.py --manifest .\\host-run-manifest.json '
            '--output .\\output\n',
        )
        atomic_write(
            host_dir / "README.md",
            f"""# Local campaign bundle — {host['alias']}

1. Review `host-run-manifest.json`.
2. Confirm this bundle is on the intended local host.
3. Confirm approved paths and collectors.
4. Set `review.approved_for_host: true` only in the corporate copy.
5. Run `run.sh` on Linux or `Run.ps1` on Windows.
6. Review `output/run-summary.json`.
7. Copy only `output/evidence/*.json` to the campaign inbox.
8. Keep `output/local-raw/` inside the corporate environment.

The bundle performs no deployment, restart, failover, database write, remote
execution, or network probe.
""",
        )
        archive = bundles / f"{host['alias']}.zip"
        if archive.exists():
            archive.unlink()
        _zip_directory(host_dir, archive)
        created.append(
            {
                "host_alias": host["alias"],
                "directory": str(host_dir.relative_to(directory)).replace("\\", "/"),
                "archive": str(archive.relative_to(directory)).replace("\\", "/"),
                "archive_sha256": sha256_file(archive),
                "collectors": host["collectors"],
            }
        )

    index = {
        "schema_version": "3.0.0",
        "campaign_id": campaign["campaign"]["id"],
        "generated_at_utc": utc_now(),
        "bundle_count": len(created),
        "bundles": created,
        "execution_boundary": "local-manual",
        "human_host_review_required": True,
    }
    dump_json(execution / "bundle-index.json", index)
    approval_template = execution / "runner-approval-template.csv"
    with approval_template.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "host_alias",
                "approved",
                "reviewer_role",
                "review_reference",
            ],
        )
        writer.writeheader()
        for host in campaign["hosts"]:
            writer.writerow(
                {
                    "host_alias": host["alias"],
                    "approved": "false",
                    "reviewer_role": "",
                    "review_reference": "",
                }
            )
    campaign["campaign"]["status"] = "runners-built"
    dump_yaml(directory / CAMPAIGN_FILE, campaign)
    return index


def approve_runners(
    directory: Path,
    approval_csv: Path,
) -> dict[str, Any]:
    campaign = load_campaign(directory)
    if not approval_csv.exists():
        raise CampaignError(f"Runner approval CSV does not exist: {approval_csv}")
    with approval_csv.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    required = {"host_alias", "approved", "reviewer_role", "review_reference"}
    if not rows:
        raise CampaignError("Runner approval CSV has no rows")
    missing = required - set(rows[0])
    if missing:
        raise CampaignError(
            "Runner approval CSV is missing columns: "
            + ", ".join(sorted(missing))
        )

    by_host = {}
    for row_number, row in enumerate(rows, start=2):
        host_alias = row["host_alias"].strip()
        if host_alias in by_host:
            raise CampaignError(f"Duplicate host approval at row {row_number}: {host_alias}")
        approved = row["approved"].strip().lower() in {"true", "yes", "1"}
        if not approved:
            raise CampaignError(f"Host is not approved at row {row_number}: {host_alias}")
        if not row["reviewer_role"].strip() or not row["review_reference"].strip():
            raise CampaignError(
                f"Reviewer role and reference are required at row {row_number}"
            )
        by_host[host_alias] = row

    expected = {host["alias"] for host in campaign["hosts"]}
    supplied = set(by_host)
    if expected != supplied:
        raise CampaignError(
            "Runner approvals do not match campaign hosts; missing="
            + ",".join(sorted(expected - supplied))
            + " extra="
            + ",".join(sorted(supplied - expected))
        )

    execution = directory / "execution"
    index_path = execution / "bundle-index.json"
    index = json.loads(index_path.read_text(encoding="utf-8"))
    approved_rows = []
    for host_alias in sorted(expected):
        manifest_path = execution / host_alias / "host-run-manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        row = by_host[host_alias]
        manifest["review"].update(
            {
                "approved_for_host": True,
                "reviewer_role": row["reviewer_role"].strip(),
                "review_reference": row["review_reference"].strip(),
                "approved_at_utc": utc_now(),
            }
        )
        manifest_errors = validate_data("host-run", manifest)
        if manifest_errors:
            raise CampaignError(
                f"Approved manifest is invalid for {host_alias}:\n- "
                + "\n- ".join(manifest_errors)
            )
        dump_json(manifest_path, manifest)
        approval_value = {
            "schema_version": "3.0.0",
            "campaign_id": campaign["campaign"]["id"],
            "host_alias": host_alias,
            "manifest_sha256": sha256_file(manifest_path),
            "reviewer_role": row["reviewer_role"].strip(),
            "review_reference": row["review_reference"].strip(),
            "approved_at_utc": manifest["review"]["approved_at_utc"],
            "local_collection_approved": True,
            "production_changes_approved": False,
        }
        approval_errors = validate_data("runner-approval", approval_value)
        if approval_errors:
            raise CampaignError(
                f"Runner approval is invalid for {host_alias}:\n- "
                + "\n- ".join(approval_errors)
            )
        dump_json(execution / host_alias / "runner-approval.json", approval_value)
        archive = execution / "bundles" / f"{host_alias}.zip"
        if archive.exists():
            archive.unlink()
        _zip_directory(execution / host_alias, archive)
        approved_rows.append(
            {
                "host_alias": host_alias,
                "manifest_sha256": sha256_file(manifest_path),
                "archive_sha256": sha256_file(archive),
                "reviewer_role": row["reviewer_role"].strip(),
                "review_reference": row["review_reference"].strip(),
            }
        )
        for item in index["bundles"]:
            if item["host_alias"] == host_alias:
                item["archive_sha256"] = sha256_file(archive)
                item["approved_for_host"] = True
                item["review_reference"] = row["review_reference"].strip()
    index["approved_bundle_count"] = len(approved_rows)
    index["all_hosts_approved"] = len(approved_rows) == len(expected)
    dump_json(index_path, index)
    report = {
        "schema_version": "3.0.0",
        "campaign_id": campaign["campaign"]["id"],
        "approved_at_utc": utc_now(),
        "approved_host_count": len(approved_rows),
        "hosts": approved_rows,
        "production_changes_approved": False,
    }
    dump_json(execution / "runner-approval-record.json", report)
    return report


def _has_ingestable_files(path: Path) -> bool:
    return path.exists() and any(
        item.is_file() and item.suffix.lower() in {".json", ".yml", ".yaml"}
        for item in path.rglob("*")
    )


def advance_campaign(
    directory: Path,
    *,
    external_output: Path | None = None,
    force: bool = False,
) -> dict[str, Any]:
    campaign = load_campaign(directory)
    actions = []

    # Completed forms are ingested directly from their generated locations.
    forms = directory / "forms"
    if _has_ingestable_files(forms):
        form_result = ingest_campaign(directory, forms)
        actions.append({"action": "ingest-forms", "result": form_result})

    inbox = directory / "inbox"
    if _has_ingestable_files(inbox):
        inbox_result = ingest_campaign(directory, inbox)
        actions.append({"action": "ingest-inbox", "result": inbox_result})

    ai_results = directory / "ai-results"
    if _has_ingestable_files(ai_results):
        ai_result = ingest_campaign(directory, ai_results)
        actions.append({"action": "ingest-ai-results", "result": ai_result})

    bundle_index = directory / "execution/bundle-index.json"
    if not bundle_index.exists():
        runner_result = build_runners(directory, force=force)
        actions.append({"action": "build-runners", "result": runner_result})

    try:
        ai_jobs = build_ai_jobs(directory)
        actions.append({"action": "build-ai-jobs", "result": ai_jobs})
    except CampaignError as exc:
        actions.append(
            {
                "action": "build-ai-jobs",
                "result": {"error": str(exc), "blocker": True},
            }
        )

    status = status_campaign(directory)
    result = {
        "schema_version": "3.0.0",
        "campaign_id": campaign["campaign"]["id"],
        "advanced_at_utc": utc_now(),
        "actions": actions,
        "status": status,
        "finalized": None,
    }
    if external_output is not None:
        result["finalized"] = finalize_campaign(
            directory,
            external_output,
            force=force,
        )
    dump_json(directory / "state/last-advance.json", result)
    return result
