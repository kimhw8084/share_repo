from __future__ import annotations

import re

VERSION = "3.0.0"

PROM_METRIC_RE = re.compile(r"^[a-zA-Z_:][a-zA-Z0-9_:]*$")
PROM_LABEL_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")
SYSTEM_ID_RE = re.compile(r"^[a-z][a-z0-9-]{1,62}$")

FORBIDDEN_HIGH_CARDINALITY_LABELS = {
    "lot",
    "lot_id",
    "wafer",
    "wafer_id",
    "recipe",
    "recipe_id",
    "equipment",
    "equipment_id",
    "transaction",
    "transaction_id",
    "file",
    "file_name",
    "filename",
    "path",
    "user",
    "username",
    "guid",
    "uuid",
    "timestamp",
    "error_message",
    "stacktrace",
}

DENIED_HANDOFF_SUFFIXES = {
    ".log",
    ".evtx",
    ".dmp",
    ".pcap",
    ".pcapng",
    ".db",
    ".sqlite",
    ".sqlite3",
    ".bak",
    ".key",
    ".pem",
    ".pfx",
    ".p12",
    ".cer",
    ".crt",
    ".der",
}

ALLOWED_HANDOFF_SUFFIXES = {".json", ".yaml", ".yml", ".md", ".csv", ".txt", ".py", ".ps1", ".sh", ".j2", ".toml", ".spl", ".sql", ".cfg", ".ini"}

DEFAULT_REQUIRED_RESOURCE_ATTRIBUTES = [
    "service.namespace",
    "service.name",
    "deployment.environment.name",
    "metrology.system",
    "metrology.owner_team",
    "metrology.criticality",
    "metrology.support_tier",
]
