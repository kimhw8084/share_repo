from __future__ import annotations

from importlib import resources
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .io import load_data


SCHEMA_FILES = {
    "profile": "system-profile.schema.json",
    "platform": "platform-profile.schema.json",
    "discovery": "server-discovery.schema.json",
    "log-features": "log-feature-summary.schema.json",
    "telemetry-catalog": "telemetry-catalog.schema.json",
    "probe-plan": "probe-plan.schema.json",
    "db-probe-manifest": "db-probe-manifest.schema.json",
    "compiled-plan": "compiled-plan.schema.json",
    "questionnaire": "technical-questionnaire.schema.json",
    "handoff": "handoff.schema.json",
    "campaign-approval": "campaign-approval.schema.json",
    "campaign": "evidence-campaign.schema.json",
    "evidence": "evidence-envelope.schema.json",
    "semantic-response": "semantic-response.schema.json",
    "ai-job": "ai-job.schema.json",
    "campaign-return": "campaign-return-bundle.schema.json",
    "host-run": "host-run-manifest.schema.json",
    "runner-approval": "runner-approval.schema.json",
    "evidence-questionnaire": "evidence-questionnaire.schema.json",
}


def _resource_schema_text(filename: str) -> str | None:
    try:
        resource = resources.files("obsfactory.resources.schemas").joinpath(filename)
        if resource.is_file():
            return resource.read_text(encoding="utf-8")
    except (ModuleNotFoundError, FileNotFoundError, AttributeError):
        return None
    return None


def repository_schema_dir() -> Path | None:
    candidate = Path(__file__).resolve().parents[2] / "schemas"
    return candidate if candidate.exists() else None


def load_schema(kind: str) -> dict[str, Any]:
    if kind not in SCHEMA_FILES:
        raise ValueError(f"Unknown schema kind: {kind}")
    filename = SCHEMA_FILES[kind]
    text = _resource_schema_text(filename)
    if text is not None:
        import json
        return json.loads(text)

    directory = repository_schema_dir()
    if directory is not None:
        return load_data(directory / filename)
    raise FileNotFoundError(
        f"Schema '{filename}' was not packaged and no repository schema directory was found"
    )


def validate_data(kind: str, value: Any) -> list[str]:
    schema = load_schema(kind)
    validator = Draft202012Validator(schema)
    errors = []
    for err in sorted(validator.iter_errors(value), key=lambda e: list(e.absolute_path)):
        location = "$"
        for part in err.absolute_path:
            location += f"[{part}]" if isinstance(part, int) else f".{part}"
        errors.append(f"{location}: {err.message}")
    return errors


def validate_file(kind: str, path: Path) -> list[str]:
    return validate_data(kind, load_data(path))
