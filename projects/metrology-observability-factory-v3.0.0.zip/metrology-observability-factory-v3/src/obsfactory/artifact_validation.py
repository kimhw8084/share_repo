from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import yaml

from .schema import validate_data


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _load_yaml(path: Path, errors: list[str]) -> Any:
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"YAML parse failed: {path}: {exc}")
        return None


def _load_json(path: Path, errors: list[str]) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"JSON parse failed: {path}: {exc}")
        return None


def _alert_records(value: Any, path: Path, errors: list[str]) -> list[dict[str, Any]]:
    if not isinstance(value, dict):
        errors.append(f"Prometheus rule file is not an object: {path}")
        return []
    groups = value.get("groups", [])
    if groups is None:
        groups = []
    if not isinstance(groups, list):
        errors.append(f"Prometheus groups must be a list: {path}")
        return []
    records: list[dict[str, Any]] = []
    for group_index, group in enumerate(groups):
        if not isinstance(group, dict):
            errors.append(f"Invalid group at {path}:groups[{group_index}]")
            continue
        rules = group.get("rules", [])
        if not isinstance(rules, list):
            errors.append(f"Rules must be a list at {path}:groups[{group_index}]")
            continue
        for rule_index, rule in enumerate(rules):
            if isinstance(rule, dict) and "alert" in rule:
                records.append(rule)
            elif not isinstance(rule, dict):
                errors.append(
                    f"Invalid rule at {path}:groups[{group_index}].rules[{rule_index}]"
                )
    return records


def validate_generated_directory(
    package: Path,
    *,
    require_manifest: bool = True,
) -> tuple[list[str], list[str]]:
    package = package.resolve()
    errors: list[str] = []
    reviews: list[str] = []

    if not package.exists() or not package.is_dir():
        return [f"Generated package directory does not exist: {package}"], reviews

    parsed_yaml: dict[Path, Any] = {}
    parsed_json: dict[Path, Any] = {}
    for path in sorted(package.rglob("*.yml")) + sorted(package.rglob("*.yaml")):
        parsed_yaml[path] = _load_yaml(path, errors)
    for path in sorted(package.rglob("*.json")):
        parsed_json[path] = _load_json(path, errors)

    compiled_path = package / "compiled-plan.json"
    compiled = parsed_json.get(compiled_path)
    if compiled is None:
        errors.append("compiled-plan.json is missing or invalid")
        compiled = {}
    else:
        errors.extend(
            f"compiled-plan.json: {message}"
            for message in validate_data("compiled-plan", compiled)
        )
        if any(
            item.get("severity") == "error"
            for item in compiled.get("diagnostics", [])
        ):
            errors.append("compiled-plan.json contains error diagnostics")

    probe_path = package / "probes/probe-plan.json"
    probe_plan = parsed_json.get(probe_path)
    if probe_plan is None:
        errors.append("probes/probe-plan.json is missing or invalid")
    else:
        errors.extend(
            f"probes/probe-plan.json: {message}"
            for message in validate_data("probe-plan", probe_plan)
        )

    provenance_path = package / "provenance.json"
    provenance = parsed_json.get(provenance_path)
    if provenance is None:
        errors.append("provenance.json is missing or invalid")
    elif provenance.get("production_validated") is not False:
        errors.append("provenance.production_validated must remain false at generation")

    implementation = compiled.get("implementation", {})
    prometheus_enabled = implementation.get("enable_prometheus", True)
    splunk_enabled = implementation.get("enable_splunk", True)
    otel_enabled = implementation.get("enable_otel", False)

    prom_dir = package / "prometheus"
    candidate_path = prom_dir / "alert-rules.candidate.yml"
    production_path = prom_dir / "alert-rules.production.yml"
    if prometheus_enabled:
        required_prometheus = [
            prom_dir / "recording-rules.yml",
            candidate_path,
            production_path,
            prom_dir / "rule-tests.yml",
            prom_dir / "metric-contract.json",
            prom_dir / "service-discovery-contract.yml",
        ]
        for path in required_prometheus:
            if not path.exists():
                errors.append(f"Required Prometheus artifact is missing: {path.relative_to(package)}")

        candidate_rules = _alert_records(
            parsed_yaml.get(candidate_path),
            candidate_path,
            errors,
        )
        production_rules = _alert_records(
            parsed_yaml.get(production_path),
            production_path,
            errors,
        )
        candidate_ids = [str(rule["alert"]) for rule in candidate_rules]
        production_ids = [str(rule["alert"]) for rule in production_rules]
        overlap = sorted(set(candidate_ids) & set(production_ids))
        if overlap:
            errors.append(
                "Candidate and production rule files contain duplicate alerts: "
                + ", ".join(overlap)
            )
        if len(candidate_ids) != len(set(candidate_ids)):
            errors.append("Candidate alert rule IDs are not unique")
        if len(production_ids) != len(set(production_ids)):
            errors.append("Production alert rule IDs are not unique")

        expected_candidate = {
            item["id"]
            for item in compiled.get("generated_alerts", [])
            if item.get("lifecycle") != "production"
        }
        expected_production = {
            item["id"]
            for item in compiled.get("generated_alerts", [])
            if item.get("lifecycle") == "production"
        }
        if set(candidate_ids) != expected_candidate:
            errors.append(
                "Candidate rule IDs do not match the compiled plan: "
                f"expected={sorted(expected_candidate)} actual={sorted(candidate_ids)}"
            )
        if set(production_ids) != expected_production:
            errors.append(
                "Production rule IDs do not match the compiled plan: "
                f"expected={sorted(expected_production)} actual={sorted(production_ids)}"
            )

        for rule in candidate_rules:
            lifecycle = rule.get("annotations", {}).get("lifecycle")
            if lifecycle == "production":
                errors.append(
                    f"Candidate rule {rule['alert']} is marked production"
                )
        for rule in production_rules:
            lifecycle = rule.get("annotations", {}).get("lifecycle")
            if lifecycle != "production":
                errors.append(
                    f"Production rule {rule['alert']} is not marked production"
                )

        if production_path.exists():
            content = production_path.read_text(encoding="utf-8")
            if "REPLACE_WITH_" in content or "TBD" in content:
                errors.append("Production alert rules contain unresolved placeholders")
    elif prom_dir.exists() and any(prom_dir.iterdir()):
        errors.append("Prometheus artifacts exist although Prometheus generation is disabled")

    splunk_dir = package / "splunk"
    if splunk_enabled:
        required_splunk = [
            splunk_dir / "query-catalog.json",
            splunk_dir / "cim-mapping.yml",
            splunk_dir / "source-contracts.yml",
            splunk_dir / "searches.reference.spl",
        ]
        for path in required_splunk:
            if not path.exists():
                errors.append(f"Required Splunk artifact is missing: {path.relative_to(package)}")
    elif splunk_dir.exists() and any(splunk_dir.iterdir()):
        errors.append("Splunk artifacts exist although Splunk generation is disabled")

    collector_path = package / "otel/collector.reference.yml"
    disabled_path = package / "otel/NOT_ENABLED.md"
    if otel_enabled:
        if not collector_path.exists():
            errors.append("OpenTelemetry is enabled but collector.reference.yml is missing")
        if disabled_path.exists():
            errors.append("OpenTelemetry enabled package contains NOT_ENABLED.md")
    else:
        if collector_path.exists():
            errors.append("OpenTelemetry is disabled but collector configuration exists")
        if not disabled_path.exists():
            errors.append("OpenTelemetry disabled package lacks NOT_ENABLED.md")

    manifest_path = package / "package-manifest.json"
    manifest = parsed_json.get(manifest_path)
    if require_manifest:
        if manifest is None:
            errors.append("package-manifest.json is missing or invalid")
        else:
            manifest_paths = set()
            for item in manifest.get("files", []):
                relative = item.get("path")
                if not relative:
                    errors.append("Manifest contains a file entry without a path")
                    continue
                if relative in manifest_paths:
                    errors.append(f"Manifest contains duplicate path: {relative}")
                    continue
                manifest_paths.add(relative)
                path = package / relative
                try:
                    resolved = path.resolve()
                    resolved.relative_to(package)
                except (FileNotFoundError, ValueError):
                    errors.append(f"Manifest path escapes or is invalid: {relative}")
                    continue
                if not path.exists():
                    errors.append(f"Manifest file missing: {relative}")
                elif sha256_file(path) != item.get("sha256"):
                    errors.append(f"Manifest hash mismatch: {relative}")

            actual_paths = {
                str(path.relative_to(package)).replace("\\", "/")
                for path in package.rglob("*")
                if path.is_file() and path.name != "package-manifest.json"
            }
            if manifest_paths != actual_paths:
                missing = sorted(actual_paths - manifest_paths)
                extra = sorted(manifest_paths - actual_paths)
                if missing:
                    errors.append("Manifest omits files: " + ", ".join(missing))
                if extra:
                    errors.append("Manifest references extra files: " + ", ".join(extra))

    return errors, reviews
