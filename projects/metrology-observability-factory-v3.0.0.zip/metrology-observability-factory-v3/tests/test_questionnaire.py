from pathlib import Path

from obsfactory.io import load_data
from obsfactory.questionnaire import assess_questionnaire
from obsfactory.schema import validate_data


ROOT = Path(__file__).resolve().parents[1]


def test_principal_questionnaire_is_valid_and_actionable():
    value = load_data(ROOT / "questionnaires/principal-architecture-review.yml")
    assert validate_data("questionnaire", value) == []
    report = assess_questionnaire(value)
    assert report["counts"]["total"] >= 50
    assert report["readiness"] == "blocked"
    assert report["counts"]["open_blockers"] > 0
    assert report["open_questions"][0]["criticality"] == "blocker"


def test_resolved_questionnaire_becomes_resolved():
    value = load_data(ROOT / "questionnaires/principal-architecture-review.yml")
    for category in value["categories"]:
        for question in category["questions"]:
            if question["status"] in {"unknown", "assumption"}:
                question["status"] = "decision"
                question["answer"] = "Approved test answer."
    report = assess_questionnaire(value)
    assert report["readiness"] == "resolved"
    assert report["counts"]["open"] == 0
