import importlib.util
from pathlib import Path
import stat


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "linux_discovery",
    ROOT / "scripts/linux/collect_server_discovery.py",
)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


def test_inventory_excludes_symlinks_and_collects_metadata_only(tmp_path):
    approved = tmp_path / "approved"
    approved.mkdir()
    (approved / "a.dat").write_text("a", encoding="utf-8")
    nested = approved / "nested"
    nested.mkdir()
    (nested / "b.txt").write_text("b", encoding="utf-8")
    (approved / "linked.dat").symlink_to(approved / "a.dat")
    rows, warnings = MODULE.path_inventory(
        [approved],
        max_items_per_path=10,
        max_elapsed_seconds=10,
        allow_cross_filesystems=False,
    )
    paths = {row["relative_path"] for row in rows}
    assert paths == {"a.dat", "nested/b.txt"}
    assert all(row["content_collected"] is False for row in rows)
    assert warnings == []


def test_inventory_limit_is_enforced(tmp_path):
    approved = tmp_path / "approved"
    approved.mkdir()
    for index in range(5):
        (approved / f"{index}.dat").write_text("x", encoding="utf-8")
    rows, warnings = MODULE.path_inventory(
        [approved],
        max_items_per_path=2,
        max_elapsed_seconds=10,
        allow_cross_filesystems=False,
    )
    assert len(rows) == 2
    assert any("item limit" in warning for warning in warnings)


def test_atomic_write_applies_requested_mode(tmp_path):
    output = tmp_path / "discovery.json"
    MODULE.atomic_write(output, "{}\n", 0o640)
    assert output.read_text(encoding="utf-8") == "{}\n"
    assert stat.S_IMODE(output.stat().st_mode) == 0o640
