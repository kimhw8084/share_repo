from pathlib import Path

from obsfactory.io import load_data
from obsfactory.schema import validate_data


ROOT = Path(__file__).resolve().parents[1]


def test_example_profiles_validate():
    for name in [
        "example-windows-file-pipeline.yml",
        "example-linux-service.yml",
    ]:
        data = load_data(ROOT / "profiles" / name)
        assert validate_data("profile", data) == []


def test_example_discovery_validates():
    data = load_data(ROOT / "examples/server-discovery.json")
    assert validate_data("discovery", data) == []


def test_example_log_features_validate():
    data = load_data(ROOT / "examples/log-feature-summary.json")
    assert validate_data("log-features", data) == []
