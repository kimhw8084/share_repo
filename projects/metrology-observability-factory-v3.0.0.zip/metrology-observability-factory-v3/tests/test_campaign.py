from copy import deepcopy
from pathlib import Path
import json
import shutil
import subprocess
import sys
import zipfile

import pytest
import yaml

from obsfactory.campaign import (
    CampaignError,
    advance_campaign,
    approve_runners,
    build_ai_jobs,
    build_runners,
    finalize_campaign,
    ingest_campaign,
    init_campaign,
    status_campaign,
)
from obsfactory.io import load_data
from obsfactory.schema import validate_data


ROOT = Path(__file__).resolve().parents[1]
APPROVAL = ROOT / "approvals/v3-defaults.approved.yml"


def inventory(path: Path, *, collectors: str = "environment") -> Path:
    path.write_text(
        "system_id,system_display_name,environment,criticality,support_tier,"
        "business_function,system_owner,system_backup,lifecycle,host_alias,"
        "os_hint,host_roles,approved_paths,collectors,host_owner,run_mode,"
        "prometheus_owner,splunk_owner,opentelemetry_owner\n"
        "pilot-system,Pilot System,test,high,24x7,Process metrology data,"
        "owner-a,backup-a,pilot,pilot-linux,linux,application,,"
        f"{collectors},owner-a,local-manual,,,\n",
        encoding="utf-8",
    )
    return path


def initialize(tmp_path: Path, *, collectors: str = "environment") -> Path:
    output = tmp_path / "campaign"
    init_campaign(
        APPROVAL,
        inventory(tmp_path / "inventory.csv", collectors=collectors),
        output,
        campaign_id="unit-campaign",
        inventory_snapshot_date="2026-08-03",
    )
    return output


def complete_form(path: Path, **answer_updates) -> Path:
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    value["status"] = "completed"
    value["completed_at_utc"] = "2026-08-03T12:00:00Z"
    value["answers"].update(answer_updates)
    completed = path.parent / f"{path.stem}.completed.yml"
    completed.write_text(yaml.safe_dump(value, sort_keys=False), encoding="utf-8")
    return completed


def test_approved_defaults_validate():
    value = load_data(APPROVAL)
    assert validate_data("campaign-approval", value) == []
    assert value["approval_status"] == "approved"
    assert len(value["decisions"]) == 24
    assert all(item["approved"] is True for item in value["decisions"])


def test_campaign_init_creates_design_evidence_and_forms(tmp_path):
    output = initialize(tmp_path)
    campaign = load_data(output / "campaign.yml")
    assert validate_data("campaign", campaign) == []
    status = status_campaign(output)
    assert status["coverage"]["design"]["percentage"] == 100.0
    assert status["evidence_count"] == 2
    assert (output / "forms/systems/pilot-system.yml").exists()
    assert (output / "forms/campaign/benefit-baseline.yml").exists()


def test_unapproved_decision_blocks_initialization(tmp_path):
    approval = load_data(APPROVAL)
    approval["decisions"][0]["approved"] = False
    approval["approval_status"] = "partially-approved"
    path = tmp_path / "approval.yml"
    path.write_text(yaml.safe_dump(approval, sort_keys=False), encoding="utf-8")
    with pytest.raises(CampaignError):
        init_campaign(
            path,
            inventory(tmp_path / "inventory.csv"),
            tmp_path / "campaign",
        )


def test_runner_bundle_is_review_blocked(tmp_path):
    output = initialize(tmp_path)
    index = build_runners(output)
    assert index["bundle_count"] == 1
    manifest = json.loads(
        (output / "execution/pilot-linux/host-run-manifest.json").read_text()
    )
    assert manifest["review"]["approved_for_host"] is False
    archive = output / "execution/bundles/pilot-linux.zip"
    assert archive.exists()
    with zipfile.ZipFile(archive) as bundle:
        assert "host-run-manifest.json" in bundle.namelist()
        assert "run_campaign.py" in bundle.namelist()


def test_local_runner_refuses_unapproved_manifest(tmp_path):
    output = initialize(tmp_path)
    build_runners(output)
    host_dir = output / "execution/pilot-linux"
    completed = subprocess.run(
        [
            sys.executable,
            str(host_dir / "run_campaign.py"),
            "--manifest",
            str(host_dir / "host-run-manifest.json"),
            "--output",
            str(host_dir / "output"),
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    assert completed.returncode == 2
    assert "approval file is missing" in completed.stderr


def test_local_runner_collects_environment_after_host_review(tmp_path):
    output = initialize(tmp_path)
    build_runners(output)
    host_dir = output / "execution/pilot-linux"
    approval = output / "execution/runner-approval-template.csv"
    approval.write_text(
        "host_alias,approved,reviewer_role,review_reference\n"
        "pilot-linux,true,system-owner,TEST-ONLY\n",
        encoding="utf-8",
    )
    approve_runners(output, approval)
    manifest_path = host_dir / "host-run-manifest.json"
    completed = subprocess.run(
        [
            sys.executable,
            str(host_dir / "run_campaign.py"),
            "--manifest",
            str(manifest_path),
            "--output",
            str(host_dir / "output"),
        ],
        text=True,
        capture_output=True,
        check=False,
        timeout=60,
    )
    assert completed.returncode == 0, completed.stderr
    evidence = list((host_dir / "output/evidence").glob("*.json"))
    assert len(evidence) == 1
    value = json.loads(evidence[0].read_text())
    assert validate_data("evidence", value) == []
    assert value["evidence_type"] == "environment"
    assert value["provenance"]["raw_logs_included"] is False


def test_completed_system_form_ingests_and_builds_ai_job(tmp_path):
    output = initialize(tmp_path)
    source = tmp_path / "application.log"
    source.write_text("synthetic local line\n", encoding="utf-8")
    completed = complete_form(
        output / "forms/systems/pilot-system.yml",
        functional_success="A controlled input produces one accepted output.",
        log_sources=[
            {
                "source_alias": "application-log",
                "path": str(source),
                "classification": "restricted",
                "approved": True,
            }
        ],
    )
    inbox = output / "inbox"
    shutil.copy2(completed, inbox / completed.name)
    result = ingest_campaign(output, inbox)
    assert result["stored"] == 1
    jobs = build_ai_jobs(output)
    assert jobs["job_count"] == 1
    job = load_data(output / "ai-jobs/pilot-system.json")
    assert validate_data("ai-job", job) == []
    assert job["root_cause_confirmation_allowed"] is False


def test_duplicate_evidence_conflict_is_preserved(tmp_path):
    output = initialize(tmp_path)
    completed = complete_form(output / "forms/systems/pilot-system.yml")
    inbox = output / "inbox"
    shutil.copy2(completed, inbox / completed.name)
    assert ingest_campaign(output, inbox)["stored"] == 1

    value = yaml.safe_load(completed.read_text())
    value["answers"]["business_function"] = "Conflicting value"
    conflict = inbox / "conflict.yml"
    conflict.write_text(yaml.safe_dump(value, sort_keys=False), encoding="utf-8")
    result = ingest_campaign(output, inbox)
    assert result["conflicts"] == 1
    status = status_campaign(output)
    assert status["conflict_count"] == 1
    assert list((output / "evidence/conflicts").glob("*.json"))


def test_finalize_creates_sanitized_blocked_bundle(tmp_path):
    output = initialize(tmp_path)
    external = tmp_path / "return.zip"
    result = finalize_campaign(output, external)
    assert result["status"] == "blocked"
    assert result["production_validated"] is False
    assert external.exists()
    with zipfile.ZipFile(external) as archive:
        names = set(archive.namelist())
        assert "return-bundle-manifest.json" in names
        assert "evidence-summary.sanitized.json" in names
        assert not any("alias-map" in name for name in names)
        assert not any("local-raw" in name for name in names)
        manifest = json.loads(
            archive.read("return-bundle-manifest.json").decode("utf-8")
        )
    assert validate_data("campaign-return", manifest) == []
    assert manifest["policy"]["raw_logs_included"] is False
    assert manifest["human_approval"]["approved"] is False


def test_targeted_actions_do_not_request_broad_rerun(tmp_path):
    output = initialize(tmp_path)
    finalize_campaign(output, tmp_path / "return.zip")
    plan = json.loads(
        (output / "output/internal/targeted-rerun-plan.json").read_text()
    )
    assert plan["broad_campaign_rerun_required"] is False
    assert plan["action_count"] > 0
    assert all("scope" in item for item in plan["actions"])


def test_batch_runner_approval_rebuilds_approved_bundles(tmp_path):
    output = initialize(tmp_path)
    build_runners(output)
    approval = output / "execution/runner-approval-template.csv"
    approval.write_text(
        "host_alias,approved,reviewer_role,review_reference\n"
        "pilot-linux,true,system-owner,TEST-REVIEW\n",
        encoding="utf-8",
    )
    report = approve_runners(output, approval)
    assert report["approved_host_count"] == 1
    manifest = json.loads(
        (output / "execution/pilot-linux/host-run-manifest.json").read_text()
    )
    assert manifest["review"]["approved_for_host"] is True
    assert manifest["review"]["review_reference"] == "TEST-REVIEW"
    index = json.loads(
        (output / "execution/bundle-index.json").read_text()
    )
    assert index["all_hosts_approved"] is True


def test_advance_ingests_completed_forms_and_builds_artifacts(tmp_path):
    output = initialize(tmp_path)
    source = tmp_path / "application.log"
    source.write_text("synthetic local line\n", encoding="utf-8")
    form_path = output / "forms/systems/pilot-system.yml"
    value = yaml.safe_load(form_path.read_text(encoding="utf-8"))
    value["status"] = "completed"
    value["completed_at_utc"] = "2026-08-03T12:00:00Z"
    value["answers"]["functional_success"] = (
        "A controlled input produces one accepted output."
    )
    value["answers"]["log_sources"] = [
        {
            "source_alias": "application-log",
            "path": str(source),
            "classification": "restricted",
            "approved": True,
        }
    ]
    form_path.write_text(yaml.safe_dump(value, sort_keys=False), encoding="utf-8")
    result = advance_campaign(output)
    assert (output / "execution/bundle-index.json").exists()
    assert (output / "ai-jobs/pilot-system.json").exists()
    assert any(item["action"] == "ingest-forms" for item in result["actions"])
    assert result["status"]["evidence_count"] >= 3


def test_platform_owner_response_derives_capability_evidence(tmp_path):
    inventory_path = tmp_path / "inventory.csv"
    inventory_path.write_text(
        "system_id,system_display_name,environment,criticality,support_tier,"
        "business_function,system_owner,system_backup,lifecycle,host_alias,"
        "os_hint,host_roles,approved_paths,collectors,host_owner,run_mode,"
        "prometheus_owner,splunk_owner,opentelemetry_owner\n"
        "platform-system,Platform System,production,high,24x7,"
        "Prometheus platform,owner-a,backup-a,production,prom-host,linux,"
        "prometheus,,environment|prometheus-capabilities,owner-a,"
        "local-manual,platform-owner,,\n",
        encoding="utf-8",
    )
    output = tmp_path / "campaign"
    init_campaign(
        APPROVAL,
        inventory_path,
        output,
        campaign_id="platform-campaign",
    )
    form_path = output / "forms/platforms/prometheus-prom-host.yml"
    form = yaml.safe_load(form_path.read_text(encoding="utf-8"))
    form["status"] = "completed"
    form["completed_at_utc"] = "2026-08-03T12:00:00Z"
    form["answers"]["supported_version"] = "approved-version"
    form["answers"]["validation_command"] = "approved-promtool-wrapper"
    form_path.write_text(yaml.safe_dump(form, sort_keys=False), encoding="utf-8")
    result = ingest_campaign(output, output / "forms/platforms")
    assert result["stored"] == 2
    ledger = json.loads(
        (output / "state/evidence-ledger.json").read_text()
    )
    assert any(
        item["evidence_type"] == "prometheus-capabilities"
        for item in ledger["evidence"].values()
    )


def test_external_aliases_are_stable_and_internal_ids_absent(tmp_path):
    output = initialize(tmp_path)
    first = tmp_path / "first.zip"
    second = tmp_path / "second.zip"
    finalize_campaign(output, first)
    finalize_campaign(output, second, force=True)

    def archive_text(path):
        with zipfile.ZipFile(path) as archive:
            return "\n".join(
                archive.read(name).decode("utf-8", errors="replace")
                for name in archive.namelist()
                if name.endswith((".json", ".yml", ".yaml", ".md"))
            )

    first_text = archive_text(first)
    second_text = archive_text(second)
    for internal in ["unit-campaign", "pilot-system", "pilot-linux", "owner-a"]:
        assert internal not in first_text
        assert internal not in second_text

    with zipfile.ZipFile(first) as archive:
        first_fleet = yaml.safe_load(
            archive.read("fleet-inventory.sanitized.yml")
        )
    with zipfile.ZipFile(second) as archive:
        second_fleet = yaml.safe_load(
            archive.read("fleet-inventory.sanitized.yml")
        )
    assert first_fleet["systems"][0]["system_id"] == second_fleet["systems"][0]["system_id"]
    assert first_fleet["hosts"][0]["host_alias"] == second_fleet["hosts"][0]["host_alias"]


def test_validation_and_operator_forms_are_pre_generated(tmp_path):
    output = initialize(tmp_path)
    assert (output / "forms/validation/pilot-system.yml").exists()
    assert (output / "forms/operator-acceptance/pilot-system.yml").exists()


def test_runner_rejects_post_approval_manifest_tamper(tmp_path):
    output = initialize(tmp_path)
    build_runners(output)
    approval = output / "execution/runner-approval-template.csv"
    approval.write_text(
        "host_alias,approved,reviewer_role,review_reference\n"
        "pilot-linux,true,system-owner,TEST-ONLY\n",
        encoding="utf-8",
    )
    approve_runners(output, approval)
    host_dir = output / "execution/pilot-linux"
    manifest_path = host_dir / "host-run-manifest.json"
    manifest = json.loads(manifest_path.read_text())
    manifest["limits"]["max_processes"] += 1
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    completed = subprocess.run(
        [
            sys.executable,
            str(host_dir / "run_campaign.py"),
            "--manifest",
            str(manifest_path),
            "--output",
            str(host_dir / "output"),
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    assert completed.returncode == 2
    assert "does not match" in completed.stderr
