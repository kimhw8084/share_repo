from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import os
import socket
import threading
import time

import pytest

from obsfactory.probes import (
    OutputLock,
    ProbePolicyError,
    _allowed_target,
    _http_probe,
    _validate_safe_regex,
)


def policy(*, enabled=True, cidrs=None, allow_loopback=False, allow_private=False):
    return {
        "network": {
            "enabled": enabled,
            "allowed_targets": [
                {"alias": "dep", "host": "127.0.0.1", "ports": [1, 8080]}
            ],
            "allowed_cidrs": cidrs or [],
            "allow_loopback": allow_loopback,
            "allow_link_local": False,
            "allow_private_addresses": allow_private,
            "allow_multicast": False,
            "allow_reserved": False,
            "require_cidr_match": True,
            "allow_redirects": False,
        }
    }


def test_cidr_is_required_for_enabled_network():
    probe = {
        "target_alias": "dep",
        "host": "127.0.0.1",
        "port": 1,
    }
    with pytest.raises(ProbePolicyError, match="NETWORK_CIDR_REQUIRED"):
        _allowed_target(probe, policy(allow_loopback=True))


def test_loopback_requires_explicit_policy():
    probe = {
        "target_alias": "dep",
        "host": "127.0.0.1",
        "port": 1,
    }
    with pytest.raises(ProbePolicyError, match="TARGET_LOOPBACK_PROHIBITED"):
        _allowed_target(probe, policy(cidrs=["127.0.0.0/8"]))


def test_validated_addresses_are_returned_for_pinned_connection():
    probe = {
        "target_alias": "dep",
        "host": "127.0.0.1",
        "port": 1,
    }
    host, port, addresses = _allowed_target(
        probe,
        policy(cidrs=["127.0.0.0/8"], allow_loopback=True),
    )
    assert host == "127.0.0.1"
    assert port == 1
    assert addresses == ("127.0.0.1",)


def test_private_address_can_be_denied(monkeypatch):
    monkeypatch.setattr(
        socket,
        "getaddrinfo",
        lambda *args, **kwargs: [
            (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("10.1.2.3", 8080))
        ],
    )
    probe = {
        "target_alias": "dep",
        "host": "127.0.0.1",
        "port": 8080,
    }
    with pytest.raises(ProbePolicyError, match="TARGET_PRIVATE_PROHIBITED"):
        _allowed_target(
            probe,
            policy(cidrs=["10.0.0.0/8"], allow_private=False),
        )


@pytest.mark.parametrize(
    "expression",
    [
        r"(a+)+",
        r"(a*)*",
        r"(a)\1",
        r"(?=secret)",
    ],
)
def test_unsafe_regex_constructs_are_rejected(expression):
    with pytest.raises(ProbePolicyError):
        _validate_safe_regex(expression)


def test_stale_dead_process_lock_can_be_recovered(tmp_path):
    output = tmp_path / "metrics.prom"
    lock = output.with_suffix(".prom.lock")
    lock.write_text("99999999\n0\n", encoding="ascii")
    old = time.time() - 3600
    os.utime(lock, (old, old))
    with OutputLock(output, stale_seconds=30):
        assert lock.exists()
    assert not lock.exists()


class RedirectHandler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.send_response(302)
        self.send_header("Location", "/other")
        self.end_headers()

    def log_message(self, format, *args):
        pass


def test_http_redirect_is_rejected_without_following(tmp_path):
    server = HTTPServer(("127.0.0.1", 0), RedirectHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        port = server.server_port
        probe = {
            "target_alias": "dep",
            "url": f"http://127.0.0.1:{port}/",
            "timeout_seconds": 2,
            "method": "HEAD",
            "expected_statuses": [200],
            "max_response_bytes": 0,
        }
        runtime_policy = policy(
            cidrs=["127.0.0.0/8"],
            allow_loopback=True,
        )
        runtime_policy["network"]["allowed_targets"] = [
            {"alias": "dep", "host": "127.0.0.1", "ports": [port]}
        ]
        with pytest.raises(ProbePolicyError, match="HTTP_REDIRECT_PROHIBITED"):
            _http_probe(probe, runtime_policy)
    finally:
        server.shutdown()
        server.server_close()
