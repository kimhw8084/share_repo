from pathlib import Path
import json
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]


def base_policy(root: Path, *, network_enabled: bool = False) -> dict:
    return {
        "max_total_runtime_seconds": 30,
        "max_parallel_probes": 2,
        "worker_startup_grace_seconds": 10,
        "report_error_detail": "code-only",
        "output_file_mode": "0640",
        "lock_stale_seconds": 60,
        "filesystem": {
            "approved_roots": [str(root)],
            "follow_symlinks": False,
            "cross_filesystems": False,
            "max_items": 100,
            "max_bytes_read": 1_000_000,
        },
        "network": {
            "enabled": network_enabled,
            "allowed_targets": [],
            "allowed_cidrs": [],
            "allow_loopback": False,
            "allow_link_local": False,
            "allow_private_addresses": False,
            "allow_multicast": False,
            "allow_reserved": False,
            "require_cidr_match": True,
            "allow_redirects": False,
        },
    }


def run_plan(tmp_path: Path, plan: dict):
    plan_path = tmp_path / "plan.json"
    output = tmp_path / "metrics.prom"
    report = tmp_path / "report.json"
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    completed = subprocess.run(
        [
            sys.executable,
            str(ROOT / "scripts/probes/run_probes.py"),
            "--plan",
            str(plan_path),
            "--output",
            str(output),
            "--report",
            str(report),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    return completed, output, report


def test_file_flow_probe(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    (data_dir / "a.dat").write_text("test", encoding="utf-8")
    plan = {
        "schema_version": "2.0.0",
        "system_id": "example-system",
        "policy": base_policy(data_dir),
        "probes": [
            {
                "id": "file-flow",
                "type": "file-flow",
                "enabled": True,
                "path": str(data_dir),
                "path_alias": "input",
                "flow": "input",
                "stage": "detected",
                "timeout_seconds": 10,
                "max_items": 10,
                "suffixes": [".dat"],
            }
        ],
    }
    completed, output, report = run_plan(tmp_path, plan)
    assert completed.returncode == 0, completed.stderr
    text = output.read_text()
    assert "# TYPE metrology_file_count gauge" in text
    assert "metrology_file_count" in text
    assert "metrology_probe_success" in text
    result = json.loads(report.read_text())
    assert result["raw_log_lines_included"] is False
    assert result["internal_targets_included"] is False


def test_network_disabled_returns_probe_failure(tmp_path):
    plan = {
        "schema_version": "2.0.0",
        "system_id": "example-system",
        "policy": base_policy(tmp_path, network_enabled=False),
        "probes": [
            {
                "id": "tcp-test",
                "type": "tcp",
                "enabled": True,
                "target_alias": "dependency",
                "host": "127.0.0.1",
                "port": 1,
                "timeout_seconds": 5,
            }
        ],
    }
    completed, output, report = run_plan(tmp_path, plan)
    assert completed.returncode == 1
    result = json.loads(report.read_text())
    assert result["probes"][0]["error_code"] == "NETWORK_DISABLED"
    assert "127.0.0.1" not in report.read_text()


def test_path_outside_approved_root_fails(tmp_path):
    approved = tmp_path / "approved"
    outside = tmp_path / "outside"
    approved.mkdir()
    outside.mkdir()
    plan = {
        "schema_version": "2.0.0",
        "system_id": "example-system",
        "policy": base_policy(approved),
        "probes": [
            {
                "id": "file-flow",
                "type": "file-flow",
                "enabled": True,
                "path": str(outside),
                "path_alias": "outside",
                "flow": "input",
                "stage": "detected",
                "timeout_seconds": 10,
            }
        ],
    }
    completed, _, report = run_plan(tmp_path, plan)
    assert completed.returncode == 1
    result = json.loads(report.read_text())
    assert result["probes"][0]["error_code"] == "PATH_NOT_APPROVED"
