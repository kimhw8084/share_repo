from pathlib import Path
import json

from obsfactory.handoff import prepare_handoff


ROOT = Path(__file__).resolve().parents[1]


def test_prepare_handoff(tmp_path):
    report = prepare_handoff(
        ROOT / "examples/server-discovery.json",
        tmp_path / "handoff",
        None,
        policy_acknowledged=True,
    )
    assert report["blocking_findings"] == []
    handoff = json.loads((tmp_path / "handoff/external-handoff.json").read_text())
    discovery = handoff["payload"]["server_discovery"]
    assert discovery["identity"]["host_name_included"] is False
    assert "host_name" not in discovery["identity"]
    assert discovery["identity"]["system_id"].startswith("sys_")
    assert discovery["identity"]["host_fingerprint"].startswith("host_")
    assert discovery["approved_path_inventory"][0].get("approved_root") is None
    assert (tmp_path / "handoff/local-only/alias-map.DO-NOT-TRANSFER.json").exists()
    assert handoff["human_approval"]["approved"] is False


def test_handoff_requires_policy(tmp_path):
    import pytest

    with pytest.raises(PermissionError):
        prepare_handoff(
            ROOT / "examples/server-discovery.json",
            tmp_path / "handoff",
        )
