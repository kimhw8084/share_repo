from obsfactory.security import sanitize_value, scan_text


def test_secret_assignment_is_blocking():
    findings = scan_text("api_key=not-a-real-value", "example")
    assert any(item.blocking for item in findings)


def test_sanitize_removes_identity_and_ip():
    findings = []
    value = {
        "host_name": "internal-host",
        "message": "connection failed to 10.1.2.3",
    }
    sanitized = sanitize_value(value, findings)
    assert sanitized["host_name"] == "<REDACTED>"
    assert "<IP>" in sanitized["message"]
