import importlib.util
from pathlib import Path
import hashlib
import json

import pytest


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "db_probe_v2", ROOT / "scripts/probes/dbapi_readonly_probe.py"
)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


def manifest_for(tmp_path: Path, query: str) -> Path:
    query_path = tmp_path / "query.sql"
    query_path.write_text(query, encoding="utf-8")
    value = {
        "schema_version": "1.0.0",
        "probe_id": "db-check",
        "system_id": "example-system",
        "target_alias": "database",
        "driver": "pyodbc",
        "query_file": "query.sql",
        "query_sha256": hashlib.sha256(query_path.read_bytes()).hexdigest(),
        "metric_name": "metrology_db_probe_value",
        "timeout_seconds": 10,
        "expected_min": 0,
        "expected_max": 100,
        "approval_reference": "TEST-ONLY",
        "read_only_account_required": True,
        "output_file_mode": "0640",
        "lock_stale_seconds": 60,
    }
    path = tmp_path / "manifest.json"
    path.write_text(json.dumps(value), encoding="utf-8")
    return path


def test_manifest_binds_query_hash(tmp_path):
    path = manifest_for(tmp_path, "SELECT 1")
    manifest, query_path, query = MODULE.load_manifest(path)
    assert query == "SELECT 1"
    query_path.write_text("SELECT 2", encoding="utf-8")
    with pytest.raises(ValueError, match="QUERY_HASH_MISMATCH"):
        MODULE.load_manifest(path)


def test_manifest_rejects_write_query_even_with_matching_hash(tmp_path):
    path = manifest_for(tmp_path, "DELETE FROM t")
    with pytest.raises(ValueError, match="SELECT_OR_WITH_REQUIRED"):
        MODULE.load_manifest(path)


def test_query_path_escape_is_rejected(tmp_path):
    outside = tmp_path.parent / "outside-query.sql"
    outside.write_text("SELECT 1", encoding="utf-8")
    path = manifest_for(tmp_path, "SELECT 1")
    value = json.loads(path.read_text(encoding="utf-8"))
    value["query_file"] = "../outside-query.sql"
    value["query_sha256"] = hashlib.sha256(outside.read_bytes()).hexdigest()
    path.write_text(json.dumps(value), encoding="utf-8")
    with pytest.raises(ValueError, match="QUERY_PATH_ESCAPE_PROHIBITED"):
        MODULE.load_manifest(path)


def test_query_symlink_is_rejected(tmp_path):
    real = tmp_path / "real.sql"
    real.write_text("SELECT 1", encoding="utf-8")
    link = tmp_path / "linked.sql"
    link.symlink_to(real)
    path = manifest_for(tmp_path, "SELECT 1")
    value = json.loads(path.read_text(encoding="utf-8"))
    value["query_file"] = "linked.sql"
    value["query_sha256"] = hashlib.sha256(real.read_bytes()).hexdigest()
    path.write_text(json.dumps(value), encoding="utf-8")
    with pytest.raises(ValueError, match="QUERY_SYMLINK_PROHIBITED"):
        MODULE.load_manifest(path)


def test_invalid_expected_range_is_rejected(tmp_path):
    path = manifest_for(tmp_path, "SELECT 1")
    value = json.loads(path.read_text(encoding="utf-8"))
    value["expected_min"] = 10
    value["expected_max"] = 1
    path.write_text(json.dumps(value), encoding="utf-8")
    with pytest.raises(ValueError, match="EXPECTED_RANGE_INVALID"):
        MODULE.load_manifest(path)


def test_unresolved_approval_reference_is_rejected(tmp_path):
    path = manifest_for(tmp_path, "SELECT 1")
    value = json.loads(path.read_text(encoding="utf-8"))
    value["approval_reference"] = "TBD"
    path.write_text(json.dumps(value), encoding="utf-8")
    with pytest.raises(ValueError, match="APPROVAL_REFERENCE_UNRESOLVED"):
        MODULE.load_manifest(path)
