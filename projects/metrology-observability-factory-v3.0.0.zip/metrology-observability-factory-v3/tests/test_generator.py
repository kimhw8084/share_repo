from pathlib import Path
import json

import yaml

from obsfactory.generate import generate_package


ROOT = Path(__file__).resolve().parents[1]


def test_generate_package(tmp_path):
    output = tmp_path / "generated"
    generate_package(
        ROOT / "profiles/example-windows-file-pipeline.yml",
        output,
    )
    assert (output / "prometheus/alert-rules.candidate.yml").exists()
    assert (output / "prometheus/alert-rules.production.yml").exists()
    assert (output / "splunk/searches.reference.spl").exists()
    assert (output / "otel/NOT_ENABLED.md").exists()
    assert (output / "runbooks/standard-alert-runbook.md").exists()
    yaml.safe_load((output / "prometheus/alert-rules.candidate.yml").read_text())
    yaml.safe_load((output / "prometheus/alert-rules.production.yml").read_text())
    json.loads((output / "dashboards/dashboard-spec.json").read_text())
    manifest = json.loads((output / "package-manifest.json").read_text())
    assert manifest["human_review_required"] is True


def test_generate_refuses_overwrite(tmp_path):
    output = tmp_path / "generated"
    output.mkdir()
    try:
        generate_package(ROOT / "profiles/example-linux-service.yml", output)
    except FileExistsError:
        pass
    else:
        raise AssertionError("Expected overwrite refusal")
