from pathlib import Path

import pytest

import obsfactory.generate as generator


ROOT = Path(__file__).resolve().parents[1]


def test_generation_failure_preserves_existing_output(tmp_path, monkeypatch):
    output = tmp_path / "package"
    output.mkdir()
    marker = output / "existing.txt"
    marker.write_text("preserve", encoding="utf-8")

    original_render = generator._render
    count = {"value": 0}

    def fail_after_first(template, destination, context):
        count["value"] += 1
        if count["value"] == 2:
            raise RuntimeError("synthetic render failure")
        return original_render(template, destination, context)

    monkeypatch.setattr(generator, "_render", fail_after_first)
    with pytest.raises(RuntimeError):
        generator.generate_package(
            ROOT / "profiles/example-linux-service.yml",
            output,
            platform_path=ROOT / "platforms/example-company-platform.yml",
            force=True,
        )
    assert marker.read_text(encoding="utf-8") == "preserve"
    assert not list(tmp_path.glob(".package.staging-*"))


def test_force_generation_atomically_replaces_output(tmp_path):
    output = tmp_path / "package"
    output.mkdir()
    (output / "old.txt").write_text("old", encoding="utf-8")
    generator.generate_package(
        ROOT / "profiles/example-linux-service.yml",
        output,
        platform_path=ROOT / "platforms/example-company-platform.yml",
        force=True,
    )
    assert not (output / "old.txt").exists()
    assert (output / "compiled-plan.json").exists()
