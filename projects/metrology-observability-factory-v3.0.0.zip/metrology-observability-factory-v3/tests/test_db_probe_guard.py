import importlib.util
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "db_probe", ROOT / "scripts/probes/dbapi_readonly_probe.py"
)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


def test_accepts_single_select():
    assert MODULE.validate_query("SELECT 1") == "SELECT 1"


@pytest.mark.parametrize(
    "query",
    [
        "UPDATE table_name SET value = 1",
        "SELECT * INTO new_table FROM old_table",
        "SELECT 1; SELECT 2",
        "EXEC dangerous_procedure",
    ],
)
def test_rejects_unsafe_queries(query):
    with pytest.raises(ValueError):
        MODULE.validate_query(query)
