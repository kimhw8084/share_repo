from obsfactory.metrics import validate_metric_catalog


def test_rejects_high_cardinality_labels():
    issues = validate_metric_catalog(
        [
            {
                "signal_type": "metric",
                "name": "metrology_bad_metric",
                "labels": ["metrology_system", "lot_id"],
                "metric_type": "gauge",
                "unit": "ratio",
            }
        ]
    )
    assert any("lot_id" in issue.message for issue in issues)


def test_accepts_bounded_labels():
    issues = validate_metric_catalog(
        [
            {
                "signal_type": "metric",
                "name": "metrology_transactions_total",
                "labels": ["metrology_system", "flow", "stage", "outcome"],
                "metric_type": "counter",
                "unit": "transactions",
            }
        ]
    )
    assert issues == []
