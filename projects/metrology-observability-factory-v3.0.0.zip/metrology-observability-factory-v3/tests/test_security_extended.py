from pathlib import Path

from obsfactory.security import sanitize_value, scan_tree


def test_symlink_is_blocking(tmp_path):
    target = tmp_path / "target.txt"
    target.write_text("safe", encoding="utf-8")
    link = tmp_path / "link.txt"
    link.symlink_to(target)
    findings = scan_tree(tmp_path)
    assert any(item.category == "symlink_prohibited" and item.blocking for item in findings)


def test_jwt_and_credential_url_are_blocking_in_structured_data():
    findings = []
    value = {
        "jwt": "eyJ" + "abcdefghijk.abcdefghijk.abcdefghijk",
        "url": "https://" + "user:pass" + "@example.invalid/path",
    }
    sanitize_value(value, findings)
    categories = {item.category for item in findings if item.blocking}
    assert "jwt" in categories
    assert "credential_url" in categories
