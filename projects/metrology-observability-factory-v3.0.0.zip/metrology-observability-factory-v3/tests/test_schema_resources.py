from obsfactory.schema import SCHEMA_FILES, load_schema


def test_all_registered_schemas_are_packaged():
    for kind, filename in SCHEMA_FILES.items():
        schema = load_schema(kind)
        assert schema["$schema"].endswith("2020-12/schema")
        assert schema["type"] == "object", (kind, filename)
