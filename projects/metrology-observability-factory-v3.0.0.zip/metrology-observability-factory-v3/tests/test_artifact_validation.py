from pathlib import Path
import json

import yaml

from obsfactory.artifact_validation import validate_generated_directory
from obsfactory.generate import generate_package


ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / "profiles/example-linux-service.yml"
PLATFORM = ROOT / "platforms/example-company-platform.yml"


def generated(tmp_path: Path) -> Path:
    output = tmp_path / "package"
    generate_package(PROFILE, output, platform_path=PLATFORM)
    return output


def test_manifest_tamper_is_detected(tmp_path):
    output = generated(tmp_path)
    path = output / "README.md"
    path.write_text(path.read_text(encoding="utf-8") + "\ntampered\n", encoding="utf-8")
    errors, _ = validate_generated_directory(output)
    assert any("Manifest hash mismatch: README.md" in error for error in errors)


def test_candidate_and_production_overlap_is_detected(tmp_path):
    output = generated(tmp_path)
    candidate = yaml.safe_load(
        (output / "prometheus/alert-rules.candidate.yml").read_text(encoding="utf-8")
    )
    production_path = output / "prometheus/alert-rules.production.yml"
    production = yaml.safe_load(production_path.read_text(encoding="utf-8"))
    production.setdefault("groups", []).append(candidate["groups"][0])
    production_path.write_text(yaml.safe_dump(production, sort_keys=False), encoding="utf-8")
    errors, _ = validate_generated_directory(output, require_manifest=False)
    assert any("duplicate alerts" in error for error in errors)


def test_generated_package_has_no_production_rules_by_default(tmp_path):
    output = generated(tmp_path)
    production = yaml.safe_load(
        (output / "prometheus/alert-rules.production.yml").read_text(encoding="utf-8")
    )
    assert production["groups"] == []
    compiled = json.loads((output / "compiled-plan.json").read_text(encoding="utf-8"))
    assert all(
        alert["lifecycle"] != "production"
        for alert in compiled["generated_alerts"]
    )
