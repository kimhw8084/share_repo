from obsfactory.diffing import semantic_diff


def test_id_addressable_lists_do_not_create_positional_noise():
    before = {"signals": [{"id": "a", "enabled": True}, {"id": "b", "enabled": True}]}
    after = {"signals": [{"id": "b", "enabled": True}, {"id": "a", "enabled": True}]}
    assert semantic_diff(before, after) == []


def test_alert_change_is_high_risk():
    changes = semantic_diff(
        {"alerts": [{"id": "A", "condition": "x > 0"}]},
        {"alerts": [{"id": "A", "condition": "x > 1"}]},
    )
    assert len(changes) == 1
    assert changes[0].risk == "high"
    assert "platform/security" in changes[0].approval
