from copy import deepcopy
from pathlib import Path

import pytest

from obsfactory.compiler import compile_profile
from obsfactory.diagnostics import CompilationError
from obsfactory.io import load_data
from obsfactory.schema import validate_data


ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def profile():
    return load_data(ROOT / "profiles/example-windows-file-pipeline.yml")


@pytest.fixture
def platform():
    return load_data(ROOT / "platforms/example-company-platform.yml")


def codes(plan):
    return {item["code"] for item in plan["diagnostics"]}


def test_compiled_plan_validates(profile, platform):
    plan = compile_profile(profile, platform, strict=False)
    assert validate_data("compiled-plan", plan) == []
    assert plan["capabilities"]["functional_availability"] is True
    assert plan["capabilities"]["host_health"] is False
    assert all(
        rule["record"] != "metrology_system:host_health:min"
        for rule in plan["recording_rules"]
    )


def test_duplicate_ids_fail_closed(profile, platform):
    profile["signals"].append(deepcopy(profile["signals"][0]))
    with pytest.raises(CompilationError) as exc:
        compile_profile(profile, platform)
    assert "PROFILE_DUPLICATE_ID" in {item.code for item in exc.value.diagnostics}


def test_forbidden_high_cardinality_label_fails(profile, platform):
    profile["signals"][0]["labels"].append("wafer_id")
    with pytest.raises(CompilationError) as exc:
        compile_profile(profile, platform)
    assert any("wafer_id" in item.message for item in exc.value.diagnostics)


def test_platform_can_disable_prometheus(profile, platform):
    platform["prometheus"]["enabled"] = False
    with pytest.raises(CompilationError) as exc:
        compile_profile(profile, platform)
    assert "PROMETHEUS_DISABLED_BY_PLATFORM" in {
        item.code for item in exc.value.diagnostics
    }


def test_otel_request_requires_declared_platform_components(profile, platform):
    profile["implementation"]["enable_otel"] = True
    profile["implementation"]["otel_mode"] = "agent"
    with pytest.raises(CompilationError) as exc:
        compile_profile(profile, platform)
    found = {item.code for item in exc.value.diagnostics}
    assert "OTEL_NOT_ALLOWED" in found
    assert "OTEL_MODE_NOT_ALLOWED_BY_PLATFORM" in found
    assert "OTEL_COMPONENT_UNAVAILABLE" in found


def test_generated_production_alerts_require_full_evidence(profile, platform):
    profile["implementation"]["production_alerts_allowed"] = True
    profile["implementation"]["generated_alert_lifecycle"] = "production"
    profile["implementation"]["generated_alert_validation_status"] = "production-validated"
    with pytest.raises(CompilationError) as exc:
        compile_profile(profile, platform)
    found = {item.code for item in exc.value.diagnostics}
    assert "GENERATED_PRODUCTION_ALERTS_EVIDENCE_MISSING" in found
    assert "PRODUCTION_APPROVAL_REFERENCE_MISSING" in found
    assert "OPERATOR_ACCEPTANCE_REFERENCE_MISSING" in found
    assert "ROLLBACK_VALIDATION_REFERENCE_MISSING" in found
    assert "SYSTEM_NOT_PRODUCTION" in found
    assert "PRODUCTION_OWNERSHIP_UNRESOLVED" in found


def test_custom_production_unknown_metric_is_error(profile, platform):
    alert = profile["alerts"][0]
    alert.update(
        {
            "enabled": True,
            "lifecycle": "production",
            "validation_status": "production-validated",
            "evidence_reference": "TEST-EVIDENCE",
            "production_approval_reference": "TEST-APPROVAL",
            "operator_acceptance_reference": "TEST-ACCEPTANCE",
            "condition": 'metrology_unknown_metric{metrology_system="x"} > 0',
        }
    )
    profile["system"]["lifecycle"] = "production"
    profile["ownership"]["primary_owner"] = "owner-alias"
    profile["ownership"]["backup_owner"] = "backup-alias"
    with pytest.raises(CompilationError) as exc:
        compile_profile(profile, platform)
    assert any(
        item.code == "ALERT_UNKNOWN_METRIC" and item.severity.value == "error"
        for item in exc.value.diagnostics
    )


def test_reference_alerts_remain_out_of_production(profile, platform):
    plan = compile_profile(profile, platform, strict=False)
    assert plan["generated_alerts"]
    assert all(item["lifecycle"] == "draft" for item in plan["generated_alerts"])


def test_combined_cardinality_budget_is_enforced(profile, platform):
    platform["prometheus"]["max_series_per_system"] = 1000
    for signal in profile["signals"]:
        signal["cardinality_limit"] = 250
    with pytest.raises(CompilationError) as exc:
        compile_profile(profile, platform)
    assert "SYSTEM_CARDINALITY_BUDGET_EXCEEDED" in {
        item.code for item in exc.value.diagnostics
    }


def test_required_uninstrumented_dependency_does_not_generate_alert(profile, platform):
    profile["dependencies"][0]["monitoring_status"] = "uninstrumented"
    profile["dependencies"][0]["signal_id"] = None
    plan = compile_profile(profile, platform, strict=False)
    assert "REQUIRED_DEPENDENCY_UNINSTRUMENTED" in codes(plan)
    assert not any(
        alert["id"].endswith("DOWNSTREAM_DATABASE")
        for alert in plan["generated_alerts"]
    )


def test_validated_dependency_requires_evidence(profile, platform):
    profile["dependencies"][0]["monitoring_status"] = "validated"
    profile["dependencies"][0]["evidence_reference"] = None
    with pytest.raises(CompilationError) as exc:
        compile_profile(profile, platform)
    assert "DEPENDENCY_VALIDATION_EVIDENCE_MISSING" in {
        item.code for item in exc.value.diagnostics
    }


def test_dependency_exception_requires_reference(profile, platform):
    profile["dependencies"][0]["monitoring_status"] = "exception"
    profile["dependencies"][0]["exception_reference"] = None
    with pytest.raises(CompilationError) as exc:
        compile_profile(profile, platform)
    assert "DEPENDENCY_EXCEPTION_REFERENCE_MISSING" in {
        item.code for item in exc.value.diagnostics
    }
