from copy import deepcopy
from pathlib import Path
import json

import pytest

from obsfactory.handoff import prepare_handoff
from obsfactory.io import load_data


ROOT = Path(__file__).resolve().parents[1]


def matching_features(tmp_path: Path) -> Path:
    value = load_data(ROOT / "examples/log-feature-summary.json")
    discovery = load_data(ROOT / "examples/server-discovery.json")
    value["system_id"] = discovery["identity"]["system_id"]
    path = tmp_path / "features.json"
    path.write_text(json.dumps(value), encoding="utf-8")
    return path


def test_platform_denial_blocks_external_handoff(tmp_path):
    with pytest.raises(PermissionError, match="does not permit"):
        prepare_handoff(
            ROOT / "examples/server-discovery.json",
            tmp_path / "handoff",
            platform_path=ROOT / "platforms/example-company-platform.yml",
        )


def test_system_id_mismatch_is_rejected(tmp_path):
    with pytest.raises(ValueError, match="system IDs do not match"):
        prepare_handoff(
            ROOT / "examples/server-discovery.json",
            tmp_path / "handoff",
            ROOT / "examples/log-feature-summary.json",
            policy_acknowledged=True,
        )


def test_persistent_salt_produces_stable_aliases(tmp_path):
    features = matching_features(tmp_path)
    salt = tmp_path / "local-only" / "salt.bin"
    first = tmp_path / "first"
    second = tmp_path / "second"
    prepare_handoff(
        ROOT / "examples/server-discovery.json",
        first,
        features,
        policy_acknowledged=True,
        salt_path=salt,
    )
    prepare_handoff(
        ROOT / "examples/server-discovery.json",
        second,
        features,
        policy_acknowledged=True,
        salt_path=salt,
    )
    a = json.loads((first / "external-handoff.json").read_text())
    b = json.loads((second / "external-handoff.json").read_text())
    assert (
        a["payload"]["server_discovery"]["identity"]["system_id"]
        == b["payload"]["server_discovery"]["identity"]["system_id"]
    )
    assert a["human_approval"]["approved"] is False
    assert b["human_approval"]["approved"] is False
