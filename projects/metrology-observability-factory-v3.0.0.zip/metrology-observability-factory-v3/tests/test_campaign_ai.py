import importlib.util
from pathlib import Path
import json
import os
import subprocess
import sys

from obsfactory.schema import validate_data


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts/campaign/run_ai_jobs.py"
SPEC = importlib.util.spec_from_file_location("campaign_ai_runner", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


def summary(system_id: str, count: int, template: str = "Operation failed for <ID>"):
    return {
        "schema_version": "1.0.0",
        "system_id": system_id,
        "analysis_window": {
            "start_utc": "2026-08-01T00:00:00Z",
            "end_utc": "2026-08-01T01:00:00Z",
            "timezone_assumption": "UTC",
        },
        "sources": [
            {
                "source_id": "source-alias",
                "source_type": "file",
                "records_analyzed": 10,
                "coverage_notes": "Synthetic test.",
            }
        ],
        "signatures": [
            {
                "signature_id": "LOCAL-1",
                "normalized_template": template,
                "count": count,
                "first_seen_utc": "2026-08-01T00:10:00Z",
                "last_seen_utc": "2026-08-01T00:20:00Z",
                "severity": "error",
                "affected_components": ["component-alias"],
                "probable_layer": "application",
                "supporting_features": ["Synthetic support."],
                "contradicting_features": [],
                "confidence": "medium",
                "root_cause_confirmed": False,
                "false_positive_risks": ["Synthetic risk."],
            }
        ],
        "sequences": [
            {
                "sequence_id": "LOCAL-SEQ",
                "ordered_signature_ids": ["LOCAL-1"],
                "maximum_gap_seconds": 60,
                "count": count,
                "confidence": "low",
                "interpretation": "Synthetic candidate sequence.",
            }
        ],
        "telemetry_candidates": [
            {
                "id": "TEL-1",
                "name": "metrology_example_errors_total",
                "signal_type": "log-derived-metric",
                "purpose": "Count normalized example errors.",
                "source": "normalized signatures",
                "unit": "events",
                "dimensions": ["component"],
                "expected_cardinality": "bounded",
                "collection_interval_seconds": 60,
                "failure_condition": "Validated rate is exceeded.",
                "recovery_condition": "Validated rate returns to normal.",
                "estimated_cost": "low",
                "privacy_risk": "low",
                "validation_needed": "Normal and incident replay.",
            }
        ],
        "alert_candidates": [
            {
                "id": "ALERT-1",
                "symptom": "Example error rate increases.",
                "candidate_condition": "Rate exceeds validated threshold.",
                "persistence_window": "5m",
                "operator_action": "Review normalized evidence.",
                "false_positive_risks": ["Planned test activity."],
            }
        ],
        "limitations": ["Synthetic test output."],
        "human_review": {
            "reviewed": False,
            "reviewer": "TBD",
            "review_notes": "Synthetic test.",
        },
    }


def test_merge_is_deterministic_and_conservative():
    merged = MODULE.merge_summaries(
        "pilot-system",
        [summary("pilot-system", 2), summary("pilot-system", 3)],
    )
    assert validate_data("log-features", merged) == []
    assert len(merged["signatures"]) == 1
    assert merged["signatures"][0]["count"] == 5
    assert merged["signatures"][0]["root_cause_confirmed"] is False
    assert merged["human_review"]["reviewed"] is False
    second = MODULE.merge_summaries(
        "pilot-system",
        [summary("pilot-system", 2), summary("pilot-system", 3)],
    )
    assert merged == second


def test_chunking_respects_bound_and_overlap(tmp_path):
    path = tmp_path / "large.log"
    path.write_text("line-1\nline-2\nline-3\nline-4\n", encoding="utf-8")
    chunks = MODULE.chunk_lines(path, max_bytes=14, overlap_lines=1)
    assert len(chunks) >= 2
    assert all(len(item["content"]) <= 21 for item in chunks)
    assert chunks[1]["start_line"] <= chunks[0]["end_line"]


def test_local_ai_adapter_end_to_end(tmp_path):
    source = tmp_path / "source.log"
    source.write_text("synthetic local evidence\n", encoding="utf-8")

    prompt = tmp_path / "prompt.md"
    prompt.write_text("Return schema-valid normalized JSON only.", encoding="utf-8")

    job_dir = tmp_path / "jobs"
    job_dir.mkdir()
    job = {
        "schema_version": "3.0.0",
        "job_id": "log-feature-extraction:pilot-system",
        "campaign_id": "unit-campaign",
        "system_id": "pilot-system",
        "purpose": "log-feature-extraction",
        "input_policy": {
            "raw_evidence_remains_intranet": True,
            "max_bytes_per_chunk": 1000,
            "chunk_overlap_lines": 1,
            "rare_event_pass": True,
        },
        "sources": [
            {
                "source_alias": "application-log",
                "path": str(source),
                "classification": "restricted",
                "approved": True,
            }
        ],
        "prompt_file": str(prompt),
        "output_schema": "schemas/log-feature-summary.schema.json",
        "output_file": "ai-results/pilot-system.log-feature-summary.json",
        "coverage": {
            "normal_window": "synthetic",
            "high_load_window": None,
            "incident_windows": [],
        },
        "root_cause_confirmation_allowed": False,
    }
    assert validate_data("ai-job", job) == []
    (job_dir / "pilot-system.json").write_text(
        json.dumps(job, indent=2), encoding="utf-8"
    )

    fake_model = tmp_path / "fake_model.py"
    fake_model.write_text(
        "import json, sys\n"
        f"value = {repr(summary('pilot-system', 1))}\n"
        "with open(sys.argv[2], 'w', encoding='utf-8') as handle:\n"
        "    json.dump(value, handle)\n",
        encoding="utf-8",
    )
    command = tmp_path / "command.json"
    command.write_text(
        json.dumps(
            [
                sys.executable,
                str(fake_model),
                "{prompt_file}",
                "{output_file}",
            ]
        ),
        encoding="utf-8",
    )
    output = tmp_path / "output"
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT / "src")
    completed = subprocess.run(
        [
            sys.executable,
            str(SCRIPT),
            "--jobs",
            str(job_dir),
            "--command-json",
            str(command),
            "--output",
            str(output),
            "--acknowledge-local-ai",
            "I_HAVE_APPROVAL",
        ],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
        check=False,
        timeout=60,
    )
    assert completed.returncode == 0, completed.stderr
    evidence_paths = list(output.rglob("*.evidence.json"))
    assert len(evidence_paths) == 1
    evidence = json.loads(evidence_paths[0].read_text())
    assert validate_data("evidence", evidence) == []
    assert evidence["evidence_type"] == "log-feature-summary"
    assert evidence["provenance"]["raw_logs_included"] is False
    assert evidence["payload"]["human_review"]["reviewed"] is False
