from pathlib import Path
import json
import os
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
APPROVAL = ROOT / "approvals/v3-defaults.approved.yml"


def environment():
    value = os.environ.copy()
    value["PYTHONPATH"] = str(ROOT / "src")
    return value


def inventory(path: Path) -> Path:
    path.write_text(
        "system_id,system_display_name,environment,criticality,support_tier,"
        "business_function,system_owner,system_backup,lifecycle,host_alias,"
        "os_hint,host_roles,approved_paths,collectors,host_owner,run_mode,"
        "prometheus_owner,splunk_owner,opentelemetry_owner\n"
        "cli-system,CLI System,test,high,24x7,Validate CLI workflow,"
        "owner-a,backup-a,pilot,cli-linux,linux,application,,environment,"
        "owner-a,local-manual,,,\n",
        encoding="utf-8",
    )
    return path


def test_campaign_cli_help():
    completed = subprocess.run(
        [sys.executable, "-m", "obsfactory", "campaign", "--help"],
        cwd=ROOT,
        env=environment(),
        text=True,
        capture_output=True,
        check=False,
        timeout=30,
    )
    assert completed.returncode == 0
    for command in [
        "init",
        "advance",
        "approve-runners",
        "ingest",
        "status",
        "finalize",
    ]:
        assert command in completed.stdout


def test_campaign_cli_init_advance_status(tmp_path):
    campaign = tmp_path / "campaign"
    init = subprocess.run(
        [
            sys.executable,
            "-m",
            "obsfactory",
            "campaign",
            "init",
            "--approval",
            str(APPROVAL),
            "--inventory",
            str(inventory(tmp_path / "inventory.csv")),
            "--campaign-id",
            "cli-smoke",
            "--inventory-snapshot-date",
            "2026-08-03",
            "--output",
            str(campaign),
        ],
        cwd=ROOT,
        env=environment(),
        text=True,
        capture_output=True,
        check=False,
        timeout=30,
    )
    assert init.returncode == 0, init.stderr
    assert (campaign / "campaign.yml").exists()

    advance = subprocess.run(
        [
            sys.executable,
            "-m",
            "obsfactory",
            "campaign",
            "advance",
            str(campaign),
        ],
        cwd=ROOT,
        env=environment(),
        text=True,
        capture_output=True,
        check=False,
        timeout=30,
    )
    assert advance.returncode == 0, advance.stderr
    assert (campaign / "execution/bundle-index.json").exists()
    assert (campaign / "state/last-advance.json").exists()

    status_file = tmp_path / "status.json"
    status = subprocess.run(
        [
            sys.executable,
            "-m",
            "obsfactory",
            "campaign",
            "status",
            str(campaign),
            "--output",
            str(status_file),
        ],
        cwd=ROOT,
        env=environment(),
        text=True,
        capture_output=True,
        check=False,
        timeout=30,
    )
    # Status returns one while required evidence gaps remain.
    assert status.returncode == 1
    value = json.loads(status_file.read_text(encoding="utf-8"))
    assert value["coverage"]["design"]["percentage"] == 100.0
    assert value["blocking_gap_count"] > 0
