from pathlib import Path
import hashlib

from obsfactory.package import create_zip


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_release_zip_is_reproducible(tmp_path, monkeypatch):
    source = tmp_path / "source"
    source.mkdir()
    (source / "README.md").write_text("stable\n", encoding="utf-8")
    (source / "config.yml").write_text("enabled: true\n", encoding="utf-8")
    monkeypatch.setenv("SOURCE_DATE_EPOCH", "1700000000")
    first = create_zip(source, tmp_path / "first.zip")
    second = create_zip(source, tmp_path / "second.zip")
    assert digest(first) == digest(second)


def test_destination_inside_source_is_rejected(tmp_path):
    source = tmp_path / "source"
    source.mkdir()
    try:
        create_zip(source, source / "bad.zip")
    except ValueError as exc:
        assert "inside the source tree" in str(exc)
    else:
        raise AssertionError("Expected destination rejection")
