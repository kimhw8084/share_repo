from pathlib import Path

from obsfactory.coverage import build_coverage
from obsfactory.io import load_data


ROOT = Path(__file__).resolve().parents[1]


def test_coverage_report_has_all_categories():
    profile = load_data(ROOT / "profiles/example-linux-service.yml")
    report = build_coverage(profile)
    assert "host_health" in report["coverage"]
    assert "telemetry_path" in report["coverage"]
    assert report["coverage"]["telemetry_path"] == "covered"
