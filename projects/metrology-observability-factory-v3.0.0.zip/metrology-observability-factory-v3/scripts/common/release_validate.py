#!/usr/bin/env python3
"""Run V3 release checks without contacting corporate systems."""
from __future__ import annotations

import argparse
import compileall
import csv
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import traceback
import xml.etree.ElementTree as ET
import zipfile


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from obsfactory.artifact_validation import validate_generated_directory  # noqa: E402
from obsfactory.assessment import assess  # noqa: E402
from obsfactory.campaign import (  # noqa: E402
    approve_runners,
    build_runners,
    finalize_campaign,
    init_campaign,
    status_campaign,
)
from obsfactory.compiler import compile_profile  # noqa: E402
from obsfactory.generate import generate_package  # noqa: E402
from obsfactory.io import load_data  # noqa: E402
from obsfactory.schema import validate_data  # noqa: E402
from obsfactory.security import findings_to_dicts, scan_tree  # noqa: E402


PLATFORM_PATH = ROOT / "platforms/example-company-platform.yml"
APPROVAL_PATH = ROOT / "approvals/v3-defaults.approved.yml"
QUESTIONNAIRE_PATH = (
    ROOT / "questionnaires/v3-principal-evidence-questionnaire.yml"
)
PROFILE_PATHS = [
    ROOT / "profiles/example-windows-file-pipeline.yml",
    ROOT / "profiles/example-linux-service.yml",
]
SOURCE_CONTRACTS = [
    ("evidence-questionnaire", QUESTIONNAIRE_PATH),
    ("campaign-approval", APPROVAL_PATH),
    ("questionnaire", ROOT / "questionnaires/principal-architecture-review.yml"),
    ("platform", PLATFORM_PATH),
    ("profile", PROFILE_PATHS[0]),
    ("profile", PROFILE_PATHS[1]),
    ("discovery", ROOT / "examples/server-discovery.json"),
    ("log-features", ROOT / "examples/log-feature-summary.json"),
    ("db-probe-manifest", ROOT / "examples/db-probe-manifest.example.json"),
]


def record(checks: list[dict], name: str, passed: bool, details=None) -> None:
    checks.append(
        {
            "name": name,
            "passed": bool(passed),
            "details": details if details is not None else {},
        }
    )


def write_smoke_inventory(path: Path) -> None:
    fields = [
        "system_id",
        "system_display_name",
        "environment",
        "criticality",
        "support_tier",
        "business_function",
        "system_owner",
        "system_backup",
        "lifecycle",
        "host_alias",
        "os_hint",
        "host_roles",
        "approved_paths",
        "collectors",
        "host_owner",
        "run_mode",
        "prometheus_owner",
        "splunk_owner",
        "opentelemetry_owner",
    ]
    rows = [
        {
            "system_id": "smoke-system",
            "system_display_name": "Smoke System",
            "environment": "test",
            "criticality": "high",
            "support_tier": "24x7",
            "business_function": "Validate campaign release workflow.",
            "system_owner": "owner-a",
            "system_backup": "backup-a",
            "lifecycle": "pilot",
            "host_alias": "smoke-linux",
            "os_hint": "linux",
            "host_roles": "application",
            "approved_paths": "",
            "collectors": "environment",
            "host_owner": "owner-a",
            "run_mode": "local-manual",
            "prometheus_owner": "",
            "splunk_owner": "",
            "opentelemetry_owner": "",
        }
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def run_campaign_smoke(temporary: Path) -> dict:
    campaign_dir = temporary / "campaign-smoke"
    inventory = temporary / "campaign-inventory.csv"
    write_smoke_inventory(inventory)

    init_campaign(
        APPROVAL_PATH,
        inventory,
        campaign_dir,
        campaign_id="release-smoke",
        inventory_snapshot_date="2026-08-03",
    )
    campaign_value = load_data(campaign_dir / "campaign.yml")
    campaign_errors = validate_data("campaign", campaign_value)

    bundle_index = build_runners(campaign_dir)
    approval_csv = campaign_dir / "execution/runner-approval-template.csv"
    approval_csv.write_text(
        "host_alias,approved,reviewer_role,review_reference\n"
        "smoke-linux,true,release-validator,RELEASE-SMOKE\n",
        encoding="utf-8",
    )
    approval_result = approve_runners(campaign_dir, approval_csv)
    approved_manifest = load_data(
        campaign_dir / "execution/smoke-linux/host-run-manifest.json"
    )
    approved_manifest_errors = validate_data("host-run", approved_manifest)
    runner_approval = load_data(
        campaign_dir / "execution/smoke-linux/runner-approval.json"
    )
    runner_approval_errors = validate_data("runner-approval", runner_approval)

    status_before = status_campaign(campaign_dir)
    external = temporary / "campaign-return.zip"
    final = finalize_campaign(campaign_dir, external)
    with zipfile.ZipFile(external) as archive:
        return_manifest = json.loads(
            archive.read("return-bundle-manifest.json").decode("utf-8")
        )
        names = set(archive.namelist())
        combined_text = "\n".join(
            archive.read(name).decode("utf-8", errors="replace")
            for name in sorted(names)
            if name.endswith((".json", ".yml", ".yaml", ".md"))
        )
    return_errors = validate_data("campaign-return", return_manifest)

    return {
        "campaign_schema_errors": campaign_errors,
        "bundle_count": bundle_index["bundle_count"],
        "approved_host_count": approval_result["approved_host_count"],
        "host_run_schema_errors": approved_manifest_errors,
        "runner_approval_schema_errors": runner_approval_errors,
        "design_coverage": status_before["coverage"]["design"]["percentage"],
        "return_schema_errors": return_errors,
        "return_status": final["status"],
        "production_validated": final["production_validated"],
        "return_files": len(names),
        "internal_ids_absent": all(
            item not in combined_text
            for item in [
                "release-smoke",
                "smoke-system",
                "smoke-linux",
                "owner-a",
                "backup-a",
            ]
        ),
        "raw_content_absent": not any(
            token in combined_text
            for token in [
                '"raw_logs_included": true',
                '"raw_configs_included": true',
            ]
        ),
        "alias_map_absent": not any("alias-map" in name for name in names),
        "passed": (
            not campaign_errors
            and bundle_index["bundle_count"] == 1
            and approval_result["approved_host_count"] == 1
            and not approved_manifest_errors
            and not runner_approval_errors
            and status_before["coverage"]["design"]["percentage"] == 100.0
            and not return_errors
            and final["production_validated"] is False
            and all(
                item not in combined_text
                for item in [
                    "release-smoke",
                    "smoke-system",
                    "smoke-linux",
                    "owner-a",
                    "backup-a",
                ]
            )
            and not any(
                token in combined_text
                for token in [
                    '"raw_logs_included": true',
                    '"raw_configs_included": true',
                ]
            )
            and not any("alias-map" in name for name in names)
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--test-evidence", type=Path)
    args = parser.parse_args()

    os.environ.setdefault("SOURCE_DATE_EPOCH", "1785715200")
    checks: list[dict] = []
    temporary = Path(tempfile.mkdtemp(prefix="obsfactory-v3-release-"))

    try:
        compiled_ok = compileall.compile_dir(
            str(ROOT / "src"), quiet=1
        ) and compileall.compile_dir(str(ROOT / "scripts"), quiet=1)
        record(checks, "python-compileall", compiled_ok)

        if args.test_evidence:
            test_evidence = json.loads(
                args.test_evidence.read_text(encoding="utf-8")
            )
            evidence_passed = (
                test_evidence.get("passed") is True
                and test_evidence.get("all_files_covered") is True
                and int(test_evidence.get("test_count", 0)) > 0
            )
            record(
                checks,
                "pytest-sharded-evidence",
                evidence_passed,
                test_evidence,
            )
        else:
            junit_path = temporary / "pytest-results.xml"
            pytest = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "pytest",
                    str(ROOT / "tests"),
                    "-q",
                    f"--junitxml={junit_path}",
                ],
                cwd=ROOT,
                text=True,
                capture_output=True,
                check=False,
                timeout=600,
            )
            test_count = None
            if junit_path.exists():
                junit_root = ET.parse(junit_path).getroot()
                if "tests" in junit_root.attrib:
                    test_count = int(junit_root.attrib["tests"])
                else:
                    test_count = sum(
                        int(item.attrib.get("tests", 0))
                        for item in junit_root.findall(".//testsuite")
                    )
            record(
                checks,
                "pytest",
                pytest.returncode == 0,
                {
                    "returncode": pytest.returncode,
                    "test_count": test_count,
                    "stdout": pytest.stdout[-20000:],
                    "stderr": pytest.stderr[-20000:] if pytest.returncode else "",
                },
            )

        for kind, path in SOURCE_CONTRACTS:
            errors = validate_data(kind, load_data(path))
            record(
                checks,
                f"schema:{kind}:{path.name}",
                not errors,
                {"errors": errors},
            )

        questionnaire = load_data(QUESTIONNAIRE_PATH)
        record(
            checks,
            "approved-questionnaire-completeness",
            (
                questionnaire["question_count"] == 205
                and len(questionnaire["questions"]) == 205
                and questionnaire["status"] == "approved-defaults"
            ),
            {
                "declared": questionnaire["question_count"],
                "actual": len(questionnaire["questions"]),
                "status": questionnaire["status"],
            },
        )

        approval = load_data(APPROVAL_PATH)
        record(
            checks,
            "approved-decision-matrix",
            (
                len(approval["decisions"]) == 24
                and approval["approval_status"] == "approved"
                and all(item["approved"] is True for item in approval["decisions"])
            ),
            {
                "decision_count": len(approval["decisions"]),
                "approval_status": approval["approval_status"],
            },
        )

        platform = load_data(PLATFORM_PATH)
        for profile_path in PROFILE_PATHS:
            profile = load_data(profile_path)
            assessment = assess(profile, platform)
            record(
                checks,
                f"assessment:{profile_path.name}",
                assessment["readiness"] != "blocked",
                {
                    "readiness": assessment["readiness"],
                    "diagnostics": assessment["diagnostics"],
                    "unresolved_decisions": assessment["unresolved_decisions"],
                },
            )

            plan = compile_profile(profile, platform, strict=True)
            plan_errors = validate_data("compiled-plan", plan)
            record(
                checks,
                f"compile:{profile_path.name}",
                not plan_errors
                and not any(
                    item["severity"] == "error"
                    for item in plan["diagnostics"]
                ),
                {
                    "schema_errors": plan_errors,
                    "diagnostics": plan["diagnostics"],
                    "cardinality_budget": plan["cardinality_budget"],
                },
            )

            output = temporary / profile_path.stem
            generate_package(
                profile_path,
                output,
                platform_path=PLATFORM_PATH,
            )
            artifact_errors, artifact_reviews = validate_generated_directory(
                output,
                require_manifest=True,
            )
            record(
                checks,
                f"generated-package:{profile_path.name}",
                not artifact_errors,
                {
                    "errors": artifact_errors,
                    "reviews": artifact_reviews,
                },
            )

        smoke = run_campaign_smoke(temporary)
        record(checks, "campaign-smoke", smoke["passed"], smoke)

        findings = scan_tree(ROOT)
        blocking = [item for item in findings if item.blocking]
        record(
            checks,
            "repository-security-scan",
            not blocking,
            {
                "blocking": findings_to_dicts(blocking),
                "review_count": sum(1 for item in findings if not item.blocking),
            },
        )
    except Exception as exc:
        record(
            checks,
            "release-harness-exception",
            False,
            {
                "type": type(exc).__name__,
                "message": str(exc),
                "traceback": traceback.format_exc()[-20000:],
            },
        )
    finally:
        shutil.rmtree(temporary, ignore_errors=True)

    passed = all(item["passed"] for item in checks)
    report = {
        "schema_version": "3.0.0",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_date_epoch": os.environ["SOURCE_DATE_EPOCH"],
        "checks": checks,
        "passed": passed,
        "not_validated_here": [
            "Corporate Windows PowerShell runtime; Windows CI parser job is supplied.",
            "Corporate-supported promtool syntax and rule-unit-test execution.",
            "Corporate OpenTelemetry distribution, version, and component validation.",
            "Splunk parsing, search cost, dashboards, indexes, sourcetypes, ingestion volume, retention, or RBAC.",
            "Corporate authentication, TLS, network, service accounts, repositories, orchestrators, and deployment mechanisms.",
            "MSSQL/Oracle connectivity, permissions, query plans, blocking behavior, or query cost.",
            "Corporate Llama/OpenCode command syntax, model quality, and approved log coverage.",
            "Any production server, application, database, message bus, equipment interface, failover, routing, deployment, or rollback.",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(args.output)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
