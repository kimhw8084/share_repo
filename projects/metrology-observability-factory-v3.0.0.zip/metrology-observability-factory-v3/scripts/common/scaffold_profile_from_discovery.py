#!/usr/bin/env python3
"""Create a conservative profile scaffold from discovery output.

Business criticality, functional health, data flows, dependencies, alert
thresholds, and ownership are never inferred from host inventory.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re

import yaml


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--discovery", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--service-pattern")
    parser.add_argument("--owner-team", default="TBD")
    args = parser.parse_args()

    discovery = json.loads(args.discovery.read_text(encoding="utf-8"))
    pattern = re.compile(args.service_pattern, re.IGNORECASE) if args.service_pattern else None
    service_rows = []
    for service in discovery.get("services", []):
        name = service.get("name", "")
        if pattern and not pattern.search(name):
            continue
        if not pattern:
            continue
        service_rows.append(
            {
                "id": re.sub(r"[^a-z0-9_]+", "-", name.lower()).strip("-")[:63] or "service",
                "display_name": name,
                "required": False,
                "runtime": "windows-service"
                if discovery.get("os", {}).get("family") == "windows"
                else "systemd-service",
                "service_name_ref": name,
                "process_name_ref": None,
                "host_group": None,
                "health_definition": "TBD: process/service state is not sufficient",
                "restart_policy": None,
                "safe_restart": "TBD",
                "notes": ["Imported from read-only discovery; required status needs owner review."],
            }
        )

    known = discovery.get("observability", {}).get("known_components", {})
    profile = {
        "schema_version": "1.0.0",
        "system": {
            "id": discovery["identity"]["system_id"],
            "display_name": "TBD",
            "environment": "production",
            "criticality": "TBD",
            "support_tier": "TBD",
            "business_function": "TBD",
            "related_systems": [],
            "tags": [],
        },
        "platform": {
            "os_families": [discovery.get("os", {}).get("family", "unknown")],
            "deployment_model": "unknown",
            "host_count": 1,
            "site_prometheus_available": "TBD",
            "site_splunk_available": "TBD",
            "otel_allowed": "TBD",
            "notes": [
                f"Discovery saw observability components: {known}",
                "Host count and deployment model require verification.",
            ],
        },
        "ownership": {
            "owner_team": args.owner_team,
            "primary_owner": "TBD",
            "backup_owner": "TBD",
            "technician_sop_coverage": "TBD",
            "escalation_path": "TBD",
        },
        "services": service_rows,
        "dependencies": [],
        "data_flows": [],
        "signals": [],
        "logs": [],
        "alerts": [],
        "data_handling": {
            "raw_logs_remain_intranet": True,
            "credentials_prohibited": True,
            "internal_identifiers_external_policy": "pseudonymize",
            "high_cardinality_policy": "logs-only",
            "approved_external_fields": [],
            "notes": [],
        },
        "implementation": {
            "enable_prometheus": True,
            "enable_splunk": True,
            "enable_otel": False,
            "scrape_interval": "60s",
            "evaluation_interval": "60s",
            "prometheus_job_name": discovery["identity"]["system_id"],
            "metrics_path": "/metrics",
            "otel_mode": "TBD",
            "deployment_owner": "TBD",
            "change_ticket": "TBD",
        },
        "assumptions": [],
        "open_questions": [
            "What production function must be demonstrated?",
            "Which services and dependencies are required?",
            "What are the critical input-to-output data flows?",
            "What are normal freshness, backlog, latency, and error ranges?",
            "Which failures recur and what evidence isolates them?",
            "What collection methods are approved by site Prometheus and Splunk owners?",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(yaml.safe_dump(profile, sort_keys=False), encoding="utf-8")
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
