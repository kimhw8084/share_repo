#!/usr/bin/env python3
"""Generate local execution commands from an approved inventory CSV.

This tool does not connect to or execute against remote hosts.
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path
import shlex


def ps_quote(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--inventory", required=True, type=Path)
    parser.add_argument("--output-directory", required=True, type=Path)
    args = parser.parse_args()

    rows = list(csv.DictReader(args.inventory.open(encoding="utf-8")))
    args.output_directory.mkdir(parents=True, exist_ok=True)
    linux_lines = ["#!/usr/bin/env sh", "set -eu", ""]
    windows_lines = [
        "[CmdletBinding()]",
        "param()",
        '$ErrorActionPreference = "Stop"',
        "",
    ]

    for row in rows:
        system_id = row["system_id"].strip()
        host_alias = row["host_alias"].strip()
        os_family = row["os_family"].strip().lower()
        approved_paths = [x for x in row.get("approved_paths", "").split("|") if x]
        include_events = row.get("include_event_summary", "").strip().lower() == "true"
        output = f"output/discovery/{system_id}/{host_alias}"

        if os_family == "linux":
            command = [
                "python3",
                "scripts/linux/collect_server_discovery.py",
                "--system-id",
                system_id,
                "--output-directory",
                output,
            ]
            for path in approved_paths:
                command.extend(["--approved-path", path])
            if include_events:
                command.append("--include-event-summary")
            linux_lines.append(f"# Review and execute locally on approved host alias: {host_alias}")
            linux_lines.append(" ".join(shlex.quote(item) for item in command))
            linux_lines.append("")
        elif os_family == "windows":
            parts = [
                r".\scripts\windows\Collect-ServerDiscovery.ps1",
                "-SystemId",
                ps_quote(system_id),
                "-OutputDirectory",
                ps_quote(output.replace("/", "\\")),
            ]
            if approved_paths:
                parts.extend(["-ApprovedPaths", ",".join(ps_quote(x) for x in approved_paths)])
            if include_events:
                parts.append("-IncludeEventSummary")
            windows_lines.append(f"# Review and execute locally on approved host alias: {host_alias}")
            windows_lines.append(" ".join(parts))
            windows_lines.append("")
        else:
            raise ValueError(f"Unsupported os_family for {host_alias}: {os_family}")

    linux_path = args.output_directory / "linux-discovery-plan.sh"
    windows_path = args.output_directory / "windows-discovery-plan.ps1"
    linux_path.write_text("\n".join(linux_lines) + "\n", encoding="utf-8")
    windows_path.write_text("\n".join(windows_lines) + "\n", encoding="utf-8")
    print(linux_path)
    print(windows_path)
    print("Commands were generated only; no remote execution occurred.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
