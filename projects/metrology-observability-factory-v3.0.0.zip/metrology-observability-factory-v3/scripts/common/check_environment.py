#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import platform
from pathlib import Path
import shutil
import sys

TOOLS = ["git", "promtool", "otelcol", "otelcol-contrib", "splunk", "node_exporter"]
MODULES = ["yaml", "jinja2", "jsonschema"]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    result = {
        "python": {
            "version": platform.python_version(),
            "supported": sys.version_info >= (3, 9),
            "executable": sys.executable,
        },
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "architecture": platform.machine(),
        },
        "modules": {name: bool(importlib.util.find_spec(name)) for name in MODULES},
        "tools": {name: shutil.which(name) for name in TOOLS},
        "notes": [
            "Missing promtool/otelcol only prevents local syntax checks; corporate-supported binaries should be used.",
            "No network connection or platform endpoint is tested.",
        ],
    }
    text = json.dumps(result, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if result["python"]["supported"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
