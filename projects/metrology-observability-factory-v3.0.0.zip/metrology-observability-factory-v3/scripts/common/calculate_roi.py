#!/usr/bin/env python3
"""Calculate low/base/high ROI from reviewed internal assumptions.

The calculator does not assign monetary values. Inputs must be supplied and
approved internally.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


REQUIRED = [
    "incident_frequency_per_year",
    "responders_per_incident",
    "hours_saved_per_incident",
    "loaded_labor_value_per_hour",
    "preventable_incidents_per_year",
    "impact_per_prevented_incident",
    "preventable_fraction",
    "adoption_rate",
    "build_cost",
    "annual_support_cost",
    "training_change_cost",
    "annual_platform_cost",
]


def calculate(case):
    missing = [key for key in REQUIRED if key not in case]
    if missing:
        raise ValueError(f"Missing inputs: {missing}")
    labor = (
        case["incident_frequency_per_year"]
        * case["responders_per_incident"]
        * case["hours_saved_per_incident"]
        * case["loaded_labor_value_per_hour"]
    )
    avoided = (
        case["preventable_incidents_per_year"]
        * case["impact_per_prevented_incident"]
        * case["preventable_fraction"]
    )
    adoption_adjusted = (labor + avoided) * case["adoption_rate"]
    total_cost = (
        case["build_cost"]
        + case["annual_support_cost"]
        + case["training_change_cost"]
        + case["annual_platform_cost"]
    )
    net = adoption_adjusted - total_cost
    recurring_benefit = max(
        0.0,
        adoption_adjusted - case["annual_support_cost"] - case["annual_platform_cost"],
    )
    payback_years = total_cost / recurring_benefit if recurring_benefit > 0 else None
    return {
        "labor_savings": labor,
        "avoided_loss": avoided,
        "adoption_adjusted_benefit": adoption_adjusted,
        "total_first_year_cost": total_cost,
        "net_first_year_value": net,
        "payback_years": payback_years,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding="utf-8"))
    result = {
        "schema_version": "1.0.0",
        "cases": {name: calculate(case) for name, case in data["cases"].items()},
        "warning": "Results are model outputs from supplied assumptions, not measured facts.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
