[CmdletBinding()]
param(
    [string]$Wheelhouse = $env:WHEELHOUSE
)
$ErrorActionPreference = "Stop"

python -m venv .venv
& .\.venv\Scripts\Activate.ps1

if ($Wheelhouse) {
    python -m pip install --no-index --find-links $Wheelhouse `
        --no-build-isolation -e ".[dev]"
}
else {
    python -m pip install --no-build-isolation -e ".[dev]"
}

python scripts\common\check_environment.py
Write-Output "Local development environment created. No monitoring deployment occurred."
