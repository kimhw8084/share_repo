#!/usr/bin/env sh
set -eu

python3 -m venv .venv
. .venv/bin/activate

if [ -n "${WHEELHOUSE:-}" ]; then
  python -m pip install --no-index --find-links "$WHEELHOUSE" \
    --no-build-isolation -e '.[dev]'
else
  python -m pip install --no-build-isolation -e '.[dev]'
fi

python scripts/common/check_environment.py
echo "Local development environment created. No corporate monitoring deployment occurred."
