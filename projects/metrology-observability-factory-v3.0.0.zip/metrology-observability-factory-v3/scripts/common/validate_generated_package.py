#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from obsfactory.artifact_validation import validate_generated_directory  # noqa: E402


def run(command, *, cwd: Path | None = None):
    completed = subprocess.run(
        command,
        cwd=cwd,
        text=True,
        capture_output=True,
        check=False,
    )
    return completed.returncode, completed.stdout, completed.stderr


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("package", type=Path)
    args = parser.parse_args()
    package = args.package.resolve()

    errors, reviews = validate_generated_directory(
        package,
        require_manifest=True,
    )

    prom_dir = package / "prometheus"
    promtool = shutil.which("promtool")
    if prom_dir.exists():
        if promtool:
            for name in [
                "recording-rules.yml",
                "alert-rules.candidate.yml",
                "alert-rules.production.yml",
            ]:
                path = prom_dir / name
                if path.exists():
                    code, out, err = run([promtool, "check", "rules", str(path)])
                    if code:
                        errors.append(f"promtool check rules failed: {path}: {out} {err}")
            test_file = prom_dir / "rule-tests.yml"
            if test_file.exists():
                code, out, err = run(
                    [promtool, "test", "rules", test_file.name],
                    cwd=prom_dir,
                )
                if code:
                    errors.append(f"promtool test rules failed: {out} {err}")
        else:
            reviews.append(
                "promtool unavailable; corporate-supported promtool must check and unit-test rules"
            )

    collector_path = package / "otel/collector.reference.yml"
    if collector_path.exists():
        otelcol = shutil.which("otelcol-contrib") or shutil.which("otelcol")
        if otelcol:
            code, out, err = run(
                [otelcol, "validate", "--config", str(collector_path)]
            )
            if code:
                errors.append(f"Collector validation failed: {out} {err}")
        else:
            reviews.append(
                "Collector binary unavailable; validate with the declared corporate distribution"
            )

    for review in reviews:
        print(f"REVIEW: {review}")
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print("Generated package structural checks passed.")
    print("Production platform compatibility and deployment approval are not established.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
