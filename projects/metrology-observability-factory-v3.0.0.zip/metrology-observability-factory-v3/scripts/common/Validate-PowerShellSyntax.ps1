[CmdletBinding()]
param(
    [string[]]$Paths = @(
        ".\scripts\windows\Collect-ServerDiscovery.ps1",
        ".\scripts\common\Bootstrap.ps1",
        ".\scripts\common\Validate-PowerShellSyntax.ps1"
    )
)
$ErrorActionPreference = "Stop"
$failed = $false
foreach ($path in $Paths) {
    $tokens = $null
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile(
        (Resolve-Path $path),
        [ref]$tokens,
        [ref]$errors
    )
    if ($errors.Count -gt 0) {
        $failed = $true
        foreach ($errorRecord in $errors) {
            Write-Error "$path: $($errorRecord.Message) at $($errorRecord.Extent.Text)"
        }
    }
    else {
        Write-Output "VALID: $path"
    }
}
if ($failed) { exit 1 }
