#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import sys

import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from obsfactory.coverage import build_coverage  # noqa: E402
from obsfactory.schema import validate_data  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profiles", required=True, type=Path)
    parser.add_argument("--output-directory", required=True, type=Path)
    args = parser.parse_args()

    rows = []
    errors = []
    for path in sorted(list(args.profiles.glob("*.yml")) + list(args.profiles.glob("*.yaml"))):
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        validation = validate_data("profile", data)
        if validation:
            errors.append({"profile": path.name, "errors": validation})
            continue
        coverage = build_coverage(data)
        row = {
            "profile": path.name,
            "system_id": data["system"]["id"],
            "display_name": data["system"]["display_name"],
            "environment": data["system"]["environment"],
            "criticality": data["system"]["criticality"],
            "support_tier": data["system"]["support_tier"],
            "owner_team": data["ownership"]["owner_team"],
            "primary_owner": data["ownership"]["primary_owner"],
            "backup_owner": data["ownership"]["backup_owner"],
        }
        row.update(coverage["coverage"])
        rows.append(row)

    args.output_directory.mkdir(parents=True, exist_ok=True)
    report = {
        "schema_version": "1.0.0",
        "systems": rows,
        "invalid_profiles": errors,
        "interpretation": "Coverage status is based on supplied profiles, not live platform inspection.",
    }
    (args.output_directory / "fleet-coverage.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    if rows:
        with (args.output_directory / "fleet-coverage.csv").open(
            "w", newline="", encoding="utf-8"
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)

    lines = [
        "# Fleet Coverage",
        "",
        "| System | Criticality | Owner | Functional | Freshness | Dependencies | Telemetry |",
        "|---|---|---|---|---|---|---|",
    ]
    for row in rows:
        lines.append(
            f"| `{row['system_id']}` | {row['criticality']} | {row['owner_team']} | "
            f"{row['functional_availability']} | {row['freshness']} | "
            f"{row['dependencies']} | {row['telemetry_path']} |"
        )
    if errors:
        lines.extend(["", "## Invalid profiles", ""])
        for item in errors:
            lines.append(f"- `{item['profile']}`: {'; '.join(item['errors'])}")
    (args.output_directory / "fleet-coverage.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )

    print(args.output_directory)
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
