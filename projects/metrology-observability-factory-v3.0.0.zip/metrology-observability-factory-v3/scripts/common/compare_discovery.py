#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


def keyed(rows, key):
    return {str(row.get(key)): row for row in rows if row.get(key) is not None}


def changes(before, after, collection, key):
    old = keyed(before.get(collection, []) or [], key)
    new = keyed(after.get(collection, []) or [], key)
    return {
        "added": sorted(set(new) - set(old)),
        "removed": sorted(set(old) - set(new)),
        "changed": sorted(
            item for item in set(old) & set(new) if old[item] != new[item]
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("before", type=Path)
    parser.add_argument("after", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    before = json.loads(args.before.read_text(encoding="utf-8"))
    after = json.loads(args.after.read_text(encoding="utf-8"))
    report = {
        "schema_version": "1.0.0",
        "before_collection_id": before.get("collection", {}).get("collection_id"),
        "after_collection_id": after.get("collection", {}).get("collection_id"),
        "os_changed": before.get("os") != after.get("os"),
        "resources_changed": before.get("resources") != after.get("resources"),
        "services": changes(before, after, "services", "name"),
        "processes": changes(before, after, "process_summary", "name"),
        "listening_ports": changes(before, after, "listening_ports", "port"),
        "observability_changed": before.get("observability") != after.get("observability"),
        "warnings_before": before.get("warnings", []),
        "warnings_after": after.get("warnings", []),
        "interpretation": (
            "Differences are observations, not proof of a production change or cause. "
            "Verify collection scope, permissions, and timing."
        ),
    }
    text = json.dumps(report, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
