#!/usr/bin/env python3
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", nargs="+", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    hosts = []
    for path in args.inputs:
        data = json.loads(path.read_text(encoding="utf-8"))
        hosts.append(
            {
                "source_file": path.name,
                "system_id": data.get("identity", {}).get("system_id"),
                "host_fingerprint": data.get("identity", {}).get("host_fingerprint"),
                "os_family": data.get("os", {}).get("family"),
                "os_name": data.get("os", {}).get("name"),
                "collection_id": data.get("collection", {}).get("collection_id"),
                "collected_at_utc": data.get("collection", {}).get("collected_at_utc"),
                "service_count": len(data.get("services", [])),
                "listening_port_count": len(data.get("listening_ports", [])),
                "known_observability_components": data.get("observability", {}).get(
                    "known_components", {}
                ),
                "warning_count": len(data.get("warnings", [])),
            }
        )
    report = {
        "schema_version": "1.0.0",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "host_count": len(hosts),
        "hosts": hosts,
        "raw_logs_included": False,
        "human_review_required": True,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
