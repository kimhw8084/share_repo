<#
.SYNOPSIS
Bounded, read-only Windows server discovery for observability design.

.DESCRIPTION
Collects OS/resource inventory, service/process summaries, listening port
numbers, observability-component presence, optional aggregate event counts,
optional scheduled-task metadata, and metadata from explicitly approved paths.

It does not collect raw logs, event messages, file/configuration contents,
environment values, registry values, process command lines, users, credentials,
internal network addresses, routes, DNS suffixes, or database content.

Review and company approval are required before execution and transfer.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[a-z][a-z0-9-]{1,62}$')]
    [string]$SystemId,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$OutputDirectory,

    [string[]]$ApprovedPaths = @(),

    [ValidateRange(1, 100000)]
    [int]$MaxPathItems = 5000,

    [ValidateRange(1, 10000)]
    [int]$MaxServices = 5000,

    [ValidateRange(1, 10000)]
    [int]$MaxProcesses = 1000,

    [ValidateRange(1, 10000)]
    [int]$MaxPorts = 2000,

    [ValidateRange(10, 3600)]
    [int]$MaxElapsedSeconds = 120,

    [switch]$IncludeEventSummary,

    [ValidateRange(1, 720)]
    [int]$EventLookbackHours = 24,

    [switch]$IncludeScheduledTaskSummary,

    [switch]$IncludeHostName
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$CollectorVersion = "2.0.0"
$StartTime = Get-Date
$Deadline = $StartTime.AddSeconds($MaxElapsedSeconds)
$Warnings = [System.Collections.Generic.List[string]]::new()
$Mutex = New-Object System.Threading.Mutex($false, "Local\MetrologyObservabilityDiscovery")

if (-not $Mutex.WaitOne(0)) {
    Write-Error "Another discovery process holds the mutex."
    exit 3
}

function Get-Sha256Text {
    param([Parameter(Mandatory = $true)][string]$Text)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $hash = [System.Security.Cryptography.SHA256]::Create().ComputeHash($bytes)
    return ([BitConverter]::ToString($hash)).Replace("-", "").ToLowerInvariant()
}

function Invoke-Safe {
    param(
        [Parameter(Mandatory = $true)][scriptblock]$Action,
        [Parameter(Mandatory = $true)][string]$Description,
        $Default = $null
    )
    try { return & $Action }
    catch {
        $Warnings.Add("$Description failed: $($_.Exception.Message)")
        return $Default
    }
}

function Write-AtomicUtf8File {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Content
    )
    $directory = Split-Path -Parent $Path
    New-Item -ItemType Directory -Path $directory -Force | Out-Null
    $temporary = Join-Path $directory (
        ".$([IO.Path]::GetFileName($Path)).$([Guid]::NewGuid().ToString('N')).tmp"
    )
    try {
        [IO.File]::WriteAllText(
            $temporary,
            $Content,
            [Text.UTF8Encoding]::new($false)
        )
        Move-Item -LiteralPath $temporary -Destination $Path -Force
    }
    finally {
        if (Test-Path -LiteralPath $temporary) {
            Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue
        }
    }
}

try {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    $computerName = [System.Net.Dns]::GetHostName()

    $os = Invoke-Safe {
        Get-CimInstance Win32_OperatingSystem |
            Select-Object Caption, Version, BuildNumber, OSArchitecture,
                LastBootUpTime, FreePhysicalMemory
    } "OS inventory"

    $computer = Invoke-Safe {
        Get-CimInstance Win32_ComputerSystem |
            Select-Object NumberOfLogicalProcessors, TotalPhysicalMemory
    } "Computer inventory"

    $disks = Invoke-Safe {
        @(Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
            [ordered]@{
                device_id = $_.DeviceID
                filesystem = $_.FileSystem
                total_bytes = [int64]$_.Size
                free_bytes = [int64]$_.FreeSpace
            }
        })
    } "Disk inventory" @()

    $services = Invoke-Safe {
        @(Get-CimInstance Win32_Service |
            Select-Object -First $MaxServices |
            ForEach-Object {
                [ordered]@{
                    name = $_.Name
                    display_name = $_.DisplayName
                    state = $_.State
                    start_mode = $_.StartMode
                }
            })
    } "Service inventory" @()

    $processSummary = Invoke-Safe {
        @(Get-Process |
            Group-Object ProcessName |
            Sort-Object Count -Descending |
            Select-Object -First $MaxProcesses |
            ForEach-Object {
                [ordered]@{
                    name = $_.Name
                    count = $_.Count
                }
            })
    } "Process summary" @()

    $listeners = Invoke-Safe {
        $processCache = @{}
        @(Get-NetTCPConnection -State Listen |
            Select-Object -First $MaxPorts |
            ForEach-Object {
                $processName = $null
                if ($_.OwningProcess -and $_.OwningProcess -gt 0) {
                    if (-not $processCache.ContainsKey($_.OwningProcess)) {
                        $pidValue = $_.OwningProcess
                        $processCache[$pidValue] = Invoke-Safe {
                            (Get-Process -Id $pidValue -ErrorAction Stop).ProcessName
                        } "Process lookup for PID $pidValue"
                    }
                    $processName = $processCache[$_.OwningProcess]
                }
                [ordered]@{
                    protocol = "tcp"
                    port = [int]$_.LocalPort
                    process_name = $processName
                    address_included = $false
                }
            } | Sort-Object port, process_name -Unique)
    } "Listening port inventory" @()

    $serviceNames = ($services | ForEach-Object { $_.name.ToLowerInvariant() }) -join " "
    $observability = [ordered]@{
        known_components = [ordered]@{
            windows_exporter = ($serviceNames -match "windows_exporter|wmi_exporter")
            opentelemetry_collector = ($serviceNames -match "otelcol|opentelemetry")
            splunk_forwarder_or_daemon = ($serviceNames -match "splunk")
            prometheus_server = ($serviceNames -match "prometheus")
        }
        telemetry_configuration_inspected = $false
    }

    $timeCandidates = @{}
    foreach ($service in $services) {
        if ($service.name -match "W32Time|VMTools|vmicheartbeat") {
            $timeCandidates[$service.name] = $service.state
        }
    }
    $timeService = [ordered]@{
        candidate_services = $timeCandidates
        time_source_included = $false
        offset_measured = $false
    }

    $containerRuntime = [ordered]@{
        docker_detected = ($serviceNames -match "docker")
        containerd_detected = ($serviceNames -match "containerd")
        container_inventory_collected = $false
    }

    $pathInventory = [System.Collections.Generic.List[object]]::new()
    foreach ($approvedPath in $ApprovedPaths) {
        if ((Get-Date) -ge $Deadline) {
            $Warnings.Add("Approved-path inventory stopped at the elapsed-time limit.")
            break
        }
        if (-not (Test-Path -LiteralPath $approvedPath)) {
            $Warnings.Add("Approved path unavailable: $approvedPath")
            continue
        }

        $rootItem = Get-Item -LiteralPath $approvedPath -Force
        $basePath = if ($rootItem.PSIsContainer) {
            $rootItem.FullName
        } else {
            $rootItem.Directory.FullName
        }
        $items = if ($rootItem.PSIsContainer) {
            Get-ChildItem -LiteralPath $rootItem.FullName -File -Recurse -Force `
                -ErrorAction SilentlyContinue |
                Where-Object {
                    -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint)
                } |
                Select-Object -First $MaxPathItems
        } else {
            @($rootItem)
        }

        foreach ($item in $items) {
            if ((Get-Date) -ge $Deadline) {
                $Warnings.Add("Elapsed-time limit reached while scanning $approvedPath")
                break
            }
            $relative = [IO.Path]::GetRelativePath($basePath, $item.FullName)
            $version = $null
            if ($item.Extension -ieq ".exe" -or $item.Extension -ieq ".dll") {
                $version = Invoke-Safe {
                    $item.VersionInfo.FileVersion
                } "Version lookup for $relative"
            }
            $pathInventory.Add([ordered]@{
                approved_root = $approvedPath
                relative_path = $relative
                suffix = $item.Extension.ToLowerInvariant()
                size_bytes = [int64]$item.Length
                modified_at_utc = $item.LastWriteTimeUtc.ToString("o")
                file_version = $version
                content_collected = $false
            })
        }
        if ($items.Count -ge $MaxPathItems) {
            $Warnings.Add("Inventory item limit may have been reached for $approvedPath")
        }
    }

    $eventSummary = $null
    if ($IncludeEventSummary) {
        $start = (Get-Date).AddHours(-1 * $EventLookbackHours)
        $eventSummary = Invoke-Safe {
            @(Get-WinEvent -FilterHashtable @{
                LogName = @("System", "Application")
                StartTime = $start
                Level = @(1, 2, 3)
            } -ErrorAction Stop |
            Group-Object ProviderName, Id, LevelDisplayName |
            Sort-Object Count -Descending |
            Select-Object -First 500 |
            ForEach-Object {
                $parts = $_.Name -split ", "
                [ordered]@{
                    provider = if ($parts.Count -gt 0) { $parts[0] } else { $null }
                    event_id = if ($parts.Count -gt 1) { $parts[1] } else { $null }
                    level = if ($parts.Count -gt 2) { $parts[2] } else { $null }
                    count = $_.Count
                    message_collected = $false
                }
            })
        } "Event summary" @()
    }

    $scheduledTaskSummary = $null
    if ($IncludeScheduledTaskSummary) {
        $scheduledTaskSummary = Invoke-Safe {
            @(Get-ScheduledTask |
                Select-Object -First 1000 |
                ForEach-Object {
                    [ordered]@{
                        task_name = $_.TaskName
                        task_path = $_.TaskPath
                        state = $_.State.ToString()
                        action_details_collected = $false
                    }
                })
        } "Scheduled task summary" @()
    }

    $Warnings.Add(
        "Elapsed-time limits are cooperative and cannot interrupt a blocked filesystem provider call."
    )
    $Warnings.Add(
        "Output ACLs inherit from the approved output directory and require corporate review."
    )

    $identity = [ordered]@{
        system_id = $SystemId
        host_fingerprint = Get-Sha256Text -Text $computerName
        host_name_included = [bool]$IncludeHostName
    }
    if ($IncludeHostName) { $identity.host_name = $computerName }

    $collectionId = (Get-Sha256Text -Text "$computerName-$((Get-Date).ToUniversalTime().ToString('o'))").Substring(0,16)
    $data = [ordered]@{
        schema_version = "1.0.0"
        collection = [ordered]@{
            collected_at_utc = (Get-Date).ToUniversalTime().ToString("o")
            collector_name = "Collect-ServerDiscovery.ps1"
            collector_version = $CollectorVersion
            privilege = if (
                ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).
                IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
            ) { "administrator" } else { "non-administrator" }
            raw_log_content_collected = $false
            configuration_content_collected = $false
            elapsed_seconds = [math]::Round(((Get-Date) - $StartTime).TotalSeconds, 3)
            collection_id = $collectionId
        }
        identity = $identity
        os = [ordered]@{
            family = "windows"
            name = $os.Caption
            version = $os.Version
            build = $os.BuildNumber
            architecture = $os.OSArchitecture
            boot_time_utc = if ($os.LastBootUpTime) {
                $os.LastBootUpTime.ToUniversalTime().ToString("o")
            } else { $null }
            timezone = (Get-TimeZone).Id
        }
        resources = [ordered]@{
            logical_cpu_count = $computer.NumberOfLogicalProcessors
            total_memory_bytes = [int64]$computer.TotalPhysicalMemory
            free_memory_bytes = if ($os.FreePhysicalMemory) {
                [int64]$os.FreePhysicalMemory * 1024
            } else { $null }
            filesystems = $disks
        }
        services = $services
        process_summary = $processSummary
        listening_ports = $listeners
        time_service = $timeService
        container_runtime = $containerRuntime
        observability = $observability
        approved_path_inventory = @($pathInventory)
        event_summary = $eventSummary
        scheduled_task_summary = $scheduledTaskSummary
        warnings = @($Warnings)
    }

    $discoveryPath = Join-Path $OutputDirectory "server-discovery.json"
    $discoveryJson = $data | ConvertTo-Json -Depth 14
    Write-AtomicUtf8File -Path $discoveryPath -Content ($discoveryJson + [Environment]::NewLine)

    $manifest = [ordered]@{
        schema_version = "1.0.0"
        system_id = $SystemId
        collection_id = $collectionId
        approved_paths = $ApprovedPaths
        files_discovered = $pathInventory.Count
        content_collected = $false
        human_review_required = $true
    }
    $manifestPath = Join-Path $OutputDirectory "evidence-manifest.json"
    $manifestJson = $manifest | ConvertTo-Json -Depth 6
    Write-AtomicUtf8File -Path $manifestPath -Content (
        $manifestJson + [Environment]::NewLine
    )

    Write-Output $discoveryPath
    Write-Warning "Human review is required before output transfer."
}
finally {
    if ($Mutex) {
        $Mutex.ReleaseMutex() | Out-Null
        $Mutex.Dispose()
    }
}
