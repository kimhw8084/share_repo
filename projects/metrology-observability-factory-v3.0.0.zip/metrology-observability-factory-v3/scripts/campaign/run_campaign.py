#!/usr/bin/env python3
"""Self-contained local evidence campaign runner.

The runner performs read-only collection on the local host. It does not deploy,
change configuration, restart services, write databases, execute failover, or
connect to other hosts.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any


VERSION = "3.0.0"


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def atomic_json(path: Path, value: Any, mode: int = 0o640) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        try:
            os.fchmod(fd, mode)
        except OSError:
            pass
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(value, handle, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        try:
            os.chmod(path, mode)
        except OSError:
            pass
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def run(command: list[str], timeout: int = 60) -> tuple[int, str, str]:
    try:
        completed = subprocess.run(
            command,
            text=True,
            capture_output=True,
            check=False,
            timeout=timeout,
            env={**os.environ, "LC_ALL": "C"},
        )
        return completed.returncode, completed.stdout, completed.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "TIMEOUT"
    except Exception as exc:
        return 127, "", type(exc).__name__


def privilege() -> str:
    if os.name == "nt":
        try:
            import ctypes
            return "administrator" if ctypes.windll.shell32.IsUserAnAdmin() else "normal"
        except Exception:
            return "unknown"
    try:
        return "root" if os.geteuid() == 0 else "normal"
    except AttributeError:
        return "unknown"


def detect_os() -> str:
    value = platform.system().lower()
    if value == "windows":
        return "windows"
    if value == "linux":
        return "linux"
    return "unsupported"


def envelope(
    manifest: dict[str, Any],
    *,
    evidence_type: str,
    evidence_id: str,
    subject_kind: str,
    subject_id: str,
    payload: Any,
    started: str,
    status: str,
    error_code: str | None = None,
    source_file: str = "runtime-generated",
    source_sha256: str | None = None,
) -> dict[str, Any]:
    subject = {"kind": subject_kind, "id": subject_id}
    if subject_kind == "host":
        subject["system_ids"] = manifest["host"]["system_ids"]
    return {
        "schema_version": "3.0.0",
        "campaign_id": manifest["campaign_id"],
        "run_id": manifest["run_id"],
        "evidence_id": evidence_id,
        "evidence_type": evidence_type,
        "subject": subject,
        "collector": {
            "name": f"campaign-local-{evidence_type}",
            "version": VERSION,
            "started_at_utc": started,
            "completed_at_utc": now(),
            "status": status,
            "privilege": privilege(),
            "error_code": error_code,
        },
        "classification": "confidential",
        "payload": payload,
        "provenance": {
            "source_file": source_file,
            "source_sha256": source_sha256 or canonical_hash(payload),
            "raw_logs_included": False,
            "raw_configs_included": False,
            "human_review_required": True,
        },
    }


def collect_environment(manifest: dict[str, Any]) -> dict[str, Any]:
    tools = {}
    for tool in [
        "python",
        "python3",
        "git",
        "prometheus",
        "promtool",
        "splunk",
        "otelcol",
        "otelcol-contrib",
        "node_exporter",
        "windows_exporter",
        "pwsh",
        "powershell",
    ]:
        tools[tool] = shutil.which(tool)
    return {
        "os": {
            "family": detect_os(),
            "name": platform.platform(),
            "release": platform.release(),
            "architecture": platform.machine(),
        },
        "python": {
            "version": platform.python_version(),
            "executable_present": True,
        },
        "tools_present": {key: bool(value) for key, value in tools.items()},
        "path_values_included": False,
        "environment_variables_included": False,
        "network_connections_tested": False,
        "host_alias": manifest["host"]["alias"],
    }


def version_output(candidates: list[tuple[str, list[str]]]) -> dict[str, Any]:
    attempts = []
    for executable, arguments in candidates:
        resolved = shutil.which(executable)
        if not resolved:
            attempts.append(
                {"executable": executable, "present": False, "returncode": None}
            )
            continue
        code, stdout, stderr = run([resolved, *arguments], timeout=20)
        text = (stdout or stderr).strip()
        attempts.append(
            {
                "executable": executable,
                "present": True,
                "returncode": code,
                "version_output": text[:1000],
                "path_included": False,
            }
        )
        if code == 0 and text:
            return {
                "detected": True,
                "version_output": text[:1000],
                "attempts": attempts,
            }
    return {"detected": False, "version_output": None, "attempts": attempts}


def config_metadata(paths: list[str]) -> list[dict[str, Any]]:
    result = []
    for raw in paths:
        path = Path(raw)
        item = {
            "path_alias": f"config-{len(result)+1}",
            "exists": path.exists(),
            "is_file": path.is_file() if path.exists() else False,
            "is_directory": path.is_dir() if path.exists() else False,
            "content_collected": False,
            "absolute_path_included": False,
        }
        if path.exists() and path.is_file() and not path.is_symlink():
            try:
                item.update(
                    {
                        "size_bytes": path.stat().st_size,
                        "modified_at_utc": datetime.fromtimestamp(
                            path.stat().st_mtime, timezone.utc
                        ).isoformat(),
                        "sha256": sha256_file(path),
                    }
                )
            except OSError:
                item["metadata_error"] = "OS_ERROR"
        result.append(item)
    return result


def collect_prometheus(manifest: dict[str, Any], target: dict[str, Any]) -> dict[str, Any]:
    version = version_output(
        [
            ("prometheus", ["--version"]),
            ("promtool", ["--version"]),
        ]
    )
    return {
        "target_id": target["id"],
        "kind": "prometheus",
        "detected": version["detected"],
        "version": version["version_output"],
        "distribution": "TBD: platform owner confirmation required",
        "binary_attempts": version["attempts"],
        "config_metadata": config_metadata(
            target.get("approved_config_paths", [])
        ),
        "service_discovery": "TBD",
        "rule_validation_available": bool(shutil.which("promtool")),
        "api_queried": False,
        "credentials_collected": False,
        "endpoints_included": False,
    }


def collect_splunk(manifest: dict[str, Any], target: dict[str, Any]) -> dict[str, Any]:
    version = version_output(
        [
            ("splunk", ["version"]),
            ("splunk", ["--version"]),
        ]
    )
    return {
        "target_id": target["id"],
        "kind": "splunk",
        "detected": version["detected"],
        "version": version["version_output"],
        "product": "TBD: platform owner confirmation required",
        "binary_attempts": version["attempts"],
        "config_metadata": config_metadata(
            target.get("approved_config_paths", [])
        ),
        "indexes_collected": False,
        "sourcetypes_collected": False,
        "tokens_collected": False,
        "api_queried": False,
        "credentials_collected": False,
        "endpoints_included": False,
    }


def collect_otel(manifest: dict[str, Any], target: dict[str, Any]) -> dict[str, Any]:
    version = version_output(
        [
            ("otelcol", ["--version"]),
            ("otelcol-contrib", ["--version"]),
        ]
    )
    components = None
    executable = shutil.which("otelcol") or shutil.which("otelcol-contrib")
    if executable and target.get("collect_components") is True:
        code, stdout, _ = run([executable, "components"], timeout=30)
        if code == 0:
            components = stdout[:50000]
    return {
        "target_id": target["id"],
        "kind": "opentelemetry",
        "detected": version["detected"],
        "version": version["version_output"],
        "distribution": "TBD: platform owner confirmation required",
        "binary_attempts": version["attempts"],
        "components_output": components,
        "components_command_attempted": components is not None,
        "config_metadata": config_metadata(
            target.get("approved_config_paths", [])
        ),
        "credentials_collected": False,
        "endpoints_included": False,
    }


def collect_host_discovery(
    manifest: dict[str, Any],
    bundle_dir: Path,
    output_dir: Path,
) -> tuple[str, Any, str | None, str, str]:
    raw_dir = output_dir / "local-raw/host-discovery"
    raw_dir.mkdir(parents=True, exist_ok=True)
    os_family = detect_os()
    if os_family == "linux":
        script = bundle_dir / "collect_server_discovery.py"
        command = [
            sys.executable,
            str(script),
            "--system-id",
            manifest["host"]["system_ids"][0],
            "--output-directory",
            str(raw_dir),
            "--max-elapsed-seconds",
            str(manifest["limits"]["host_discovery_seconds"]),
            "--max-services",
            str(manifest["limits"]["max_services"]),
            "--max-processes",
            str(manifest["limits"]["max_processes"]),
            "--max-ports",
            str(manifest["limits"]["max_ports"]),
            "--output-file-mode",
            manifest["policies"]["output_file_mode"],
        ]
        for approved in manifest["host"]["approved_paths"]:
            command.extend(["--approved-path", approved])
        code, _, stderr = run(
            command,
            timeout=manifest["limits"]["host_discovery_seconds"] + 30,
        )
    elif os_family == "windows":
        script = bundle_dir / "Collect-ServerDiscovery.ps1"
        powershell = shutil.which("pwsh") or shutil.which("powershell")
        if not powershell:
            return (
                "unsupported",
                {"reason": "PowerShell is unavailable"},
                "POWERSHELL_UNAVAILABLE",
                "runtime-generated",
                canonical_hash({"reason": "PowerShell is unavailable"}),
            )
        command = [
            powershell,
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(script),
            "-SystemId",
            manifest["host"]["system_ids"][0],
            "-OutputDirectory",
            str(raw_dir),
            "-MaxElapsedSeconds",
            str(manifest["limits"]["host_discovery_seconds"]),
            "-MaxServices",
            str(manifest["limits"]["max_services"]),
            "-MaxProcesses",
            str(manifest["limits"]["max_processes"]),
            "-MaxPorts",
            str(manifest["limits"]["max_ports"]),
        ]
        if manifest["host"]["approved_paths"]:
            command.extend(
                [
                    "-ApprovedPaths",
                    ",".join(manifest["host"]["approved_paths"]),
                ]
            )
        code, _, stderr = run(
            command,
            timeout=manifest["limits"]["host_discovery_seconds"] + 30,
        )
    else:
        return (
            "unsupported",
            {"reason": f"Unsupported OS: {platform.system()}"},
            "OS_UNSUPPORTED",
            "runtime-generated",
            canonical_hash({"reason": "unsupported OS"}),
        )

    discovery = raw_dir / "server-discovery.json"
    if code != 0 or not discovery.exists():
        status = "timeout" if code == 124 else "failed"
        return (
            status,
            {"reason": "Host discovery did not complete", "returncode": code},
            "HOST_DISCOVERY_TIMEOUT" if code == 124 else "HOST_DISCOVERY_FAILED",
            "runtime-generated",
            canonical_hash({"returncode": code, "stderr_code": stderr[:100]}),
        )
    payload = json.loads(discovery.read_text(encoding="utf-8-sig"))
    return "success", payload, None, discovery.name, sha256_file(discovery)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    manifest_path = args.manifest.resolve(strict=True)
    bundle_dir = manifest_path.parent
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    approval_path = manifest_path.parent / "runner-approval.json"
    if not approval_path.exists():
        print(
            "ERROR: hash-bound runner approval file is missing.",
            file=sys.stderr,
        )
        return 2
    approval = json.loads(approval_path.read_text(encoding="utf-8"))
    manifest_hash = sha256_file(manifest_path)
    valid_approval = (
        manifest.get("review", {}).get("approved_for_host") is True
        and approval.get("local_collection_approved") is True
        and approval.get("production_changes_approved") is False
        and approval.get("campaign_id") == manifest.get("campaign_id")
        and approval.get("host_alias") == manifest.get("host", {}).get("alias")
        and approval.get("manifest_sha256") == manifest_hash
        and bool(approval.get("reviewer_role"))
        and bool(approval.get("review_reference"))
    )
    if not valid_approval:
        print(
            "ERROR: runner approval is missing, invalid, or does not match "
            "the exact host-run manifest.",
            file=sys.stderr,
        )
        return 2
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    evidence_dir = output / "evidence"
    evidence_dir.mkdir(parents=True, exist_ok=True)

    results = []
    for collector in manifest["host"]["collectors"]:
        started = now()
        if collector == "host-discovery":
            status, payload, error, source_file, source_hash = collect_host_discovery(
                manifest, bundle_dir, output
            )
            value = envelope(
                manifest,
                evidence_type="host-discovery",
                evidence_id=f"host-discovery:{manifest['host']['alias']}:{manifest['run_id']}",
                subject_kind="host",
                subject_id=manifest["host"]["alias"],
                payload=payload,
                started=started,
                status=status,
                error_code=error,
                source_file=source_file,
                source_sha256=source_hash,
            )
        elif collector == "environment":
            payload = collect_environment(manifest)
            value = envelope(
                manifest,
                evidence_type="environment",
                evidence_id=f"environment:{manifest['host']['alias']}:{manifest['run_id']}",
                subject_kind="host",
                subject_id=manifest["host"]["alias"],
                payload=payload,
                started=started,
                status="success",
            )
        elif collector in {
            "prometheus-capabilities",
            "splunk-capabilities",
            "otel-capabilities",
        }:
            kind = {
                "prometheus-capabilities": "prometheus",
                "splunk-capabilities": "splunk",
                "otel-capabilities": "opentelemetry",
            }[collector]
            targets = [
                item for item in manifest.get("platform_targets", [])
                if item["kind"] == kind and item["enabled"]
            ]
            if not targets:
                value = envelope(
                    manifest,
                    evidence_type=collector,
                    evidence_id=f"{collector}:{manifest['host']['alias']}:{manifest['run_id']}",
                    subject_kind="platform",
                    subject_id=f"{kind}-{manifest['host']['alias']}",
                    payload={"reason": "No approved platform target is declared"},
                    started=started,
                    status="denied",
                    error_code="PLATFORM_TARGET_NOT_DECLARED",
                )
                atomic_json(
                    evidence_dir / f"{collector}.{manifest['run_id']}.json",
                    value,
                )
                results.append(
                    {
                        "collector": collector,
                        "status": "denied",
                        "evidence_id": value["evidence_id"],
                    }
                )
                continue
            for target in targets:
                if kind == "prometheus":
                    payload = collect_prometheus(manifest, target)
                elif kind == "splunk":
                    payload = collect_splunk(manifest, target)
                else:
                    payload = collect_otel(manifest, target)
                status = "success" if payload["detected"] else "partial"
                value = envelope(
                    manifest,
                    evidence_type=collector,
                    evidence_id=f"{collector}:{target['id']}:{manifest['run_id']}",
                    subject_kind="platform",
                    subject_id=target["id"],
                    payload=payload,
                    started=started,
                    status=status,
                    error_code=None if status == "success" else "BINARY_NOT_DETECTED",
                )
                atomic_json(
                    evidence_dir / f"{collector}.{target['id']}.{manifest['run_id']}.json",
                    value,
                )
                results.append(
                    {
                        "collector": collector,
                        "target_id": target["id"],
                        "status": status,
                        "evidence_id": value["evidence_id"],
                    }
                )
            continue
        else:
            value = envelope(
                manifest,
                evidence_type="environment",
                evidence_id=f"unsupported:{collector}:{manifest['run_id']}",
                subject_kind="host",
                subject_id=manifest["host"]["alias"],
                payload={"collector": collector},
                started=started,
                status="unsupported",
                error_code="COLLECTOR_UNSUPPORTED",
            )

        filename = f"{collector}.{manifest['run_id']}.json"
        atomic_json(evidence_dir / filename, value)
        results.append(
            {
                "collector": collector,
                "status": value["collector"]["status"],
                "evidence_id": value["evidence_id"],
            }
        )

    summary = {
        "schema_version": "3.0.0",
        "campaign_id": manifest["campaign_id"],
        "run_id": manifest["run_id"],
        "host_alias": manifest["host"]["alias"],
        "completed_at_utc": now(),
        "results": results,
        "raw_logs_included": False,
        "raw_configs_included": False,
        "production_changes_performed": False,
        "human_review_required": True,
    }
    atomic_json(output / "run-summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 1 if any(item["status"] in {"failed", "timeout"} for item in results) else 0


if __name__ == "__main__":
    raise SystemExit(main())
