#!/usr/bin/env python3
"""Guarded read-only DB-API scalar probe.

Engineer-only defense in depth. The database owner must provision a genuinely
read-only account and approve the exact query hash. Static SQL checks cannot
prove a query inexpensive, nonblocking, or semantically safe.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import re
import sys
import time
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from obsfactory.probes import OutputLock, atomic_write  # noqa: E402
from obsfactory.schema import validate_data  # noqa: E402


FORBIDDEN = re.compile(
    r"(?i)\b("
    r"insert|update|delete|merge|upsert|alter|drop|truncate|create|replace|"
    r"grant|revoke|commit|rollback|savepoint|call|exec|execute|begin|declare|"
    r"backup|restore|shutdown|kill|attach|detach|copy|load|unload|lock|"
    r"set|use|pragma"
    r")\b"
)
COMMENT_LINE = re.compile(r"--.*?$", re.MULTILINE)
COMMENT_BLOCK = re.compile(r"/\*.*?\*/", re.DOTALL)
METRIC_RE = re.compile(r"^[a-zA-Z_:][a-zA-Z0-9_:]*$")
LABEL_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")
UNRESOLVED = re.compile(r"(?i)^(?:TBD|TODO|UNKNOWN|REPLACE_WITH_|<REPLACE)")
ASSERTION = "I_HAVE_A_DATABASE_OWNER_APPROVED_READ_ONLY_ACCOUNT"


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_query(query: str) -> str:
    if len(query) > 20_000:
        raise ValueError("QUERY_TOO_LONG")
    cleaned = COMMENT_BLOCK.sub(" ", COMMENT_LINE.sub(" ", query)).strip()
    if cleaned.endswith(";"):
        cleaned = cleaned[:-1].rstrip()
    if ";" in cleaned:
        raise ValueError("MULTIPLE_STATEMENTS_PROHIBITED")
    if not re.match(r"(?is)^(select|with)\b", cleaned):
        raise ValueError("SELECT_OR_WITH_REQUIRED")
    match = FORBIDDEN.search(cleaned)
    if match:
        raise ValueError(f"FORBIDDEN_SQL_KEYWORD_{match.group(1).upper()}")
    if re.search(r"(?i)\binto\b", cleaned):
        raise ValueError("SELECT_INTO_PROHIBITED")
    return cleaned


def esc(value: str) -> str:
    return value.replace("\\", "\\\\").replace("\n", "\\n").replace('"', '\\"')


def metric(name: str, value: float, labels: dict[str, str]) -> str:
    if not METRIC_RE.fullmatch(name):
        raise ValueError("METRIC_NAME_INVALID")
    if not math.isfinite(float(value)):
        raise ValueError("METRIC_VALUE_NONFINITE")
    for key in labels:
        if not LABEL_RE.fullmatch(key):
            raise ValueError("LABEL_NAME_INVALID")
    rendered = ",".join(f'{key}="{esc(str(labels[key]))}"' for key in sorted(labels))
    return f"{name}{{{rendered}}} {float(value)!r}"


def connect_pyodbc(timeout: int):
    module = importlib.import_module("pyodbc")
    connection_string = os.environ.get("OBS_DB_CONNECTION_STRING")
    if not connection_string:
        raise RuntimeError("CONNECTION_CONFIGURATION_MISSING")
    # SQL_ATTR_ACCESS_MODE=101, SQL_MODE_READ_ONLY=1. Drivers can ignore this;
    # least-privilege database permissions remain mandatory.
    return module.connect(
        connection_string,
        timeout=timeout,
        autocommit=False,
        attrs_before={101: 1},
    )


def connect_oracle(timeout: int):
    module = importlib.import_module("oracledb")
    user = os.environ.get("OBS_DB_USER")
    password = os.environ.get("OBS_DB_PASSWORD")
    dsn = os.environ.get("OBS_DB_DSN")
    if not user or not password or not dsn:
        raise RuntimeError("CONNECTION_CONFIGURATION_MISSING")
    connection = module.connect(user=user, password=password, dsn=dsn)
    if hasattr(connection, "call_timeout"):
        connection.call_timeout = timeout * 1000
    cursor = connection.cursor()
    try:
        cursor.execute("SET TRANSACTION READ ONLY")
    finally:
        cursor.close()
    return connection


def _confined_regular_file(base: Path, relative: str) -> Path:
    if Path(relative).is_absolute():
        raise ValueError("QUERY_PATH_ABSOLUTE_PROHIBITED")
    candidate = base / relative
    if candidate.is_symlink():
        raise ValueError("QUERY_SYMLINK_PROHIBITED")
    resolved_base = base.resolve(strict=True)
    resolved = candidate.resolve(strict=True)
    try:
        resolved.relative_to(resolved_base)
    except ValueError as exc:
        raise ValueError("QUERY_PATH_ESCAPE_PROHIBITED") from exc
    if not resolved.is_file():
        raise ValueError("QUERY_FILE_REQUIRED")
    return resolved


def load_manifest(path: Path) -> tuple[dict[str, Any], Path, str]:
    if path.is_symlink():
        raise ValueError("MANIFEST_SYMLINK_PROHIBITED")
    resolved_manifest = path.resolve(strict=True)
    if not resolved_manifest.is_file():
        raise ValueError("MANIFEST_FILE_REQUIRED")
    value = json.loads(resolved_manifest.read_text(encoding="utf-8"))
    errors = validate_data("db-probe-manifest", value)
    if errors:
        raise ValueError("MANIFEST_INVALID: " + "; ".join(errors))
    if UNRESOLVED.match(str(value["approval_reference"]).strip()):
        raise ValueError("APPROVAL_REFERENCE_UNRESOLVED")
    minimum = value.get("expected_min")
    maximum = value.get("expected_max")
    if minimum is not None and maximum is not None and float(minimum) > float(maximum):
        raise ValueError("EXPECTED_RANGE_INVALID")
    query_path = _confined_regular_file(
        resolved_manifest.parent,
        str(value["query_file"]),
    )
    if sha256_file(query_path) != value["query_sha256"]:
        raise ValueError("QUERY_HASH_MISMATCH")
    query = validate_query(query_path.read_text(encoding="utf-8"))
    return value, query_path, query


def _error_code(exc: Exception) -> str:
    if isinstance(exc, ValueError):
        value = str(exc).strip()
        return re.sub(r"[^A-Z0-9_:-]", "_", value.upper())[:100] or "VALUE_ERROR"
    return re.sub(r"[^A-Z0-9_]", "_", type(exc).__name__.upper())[:100]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--report", type=Path)
    parser.add_argument(
        "--acknowledge-readonly-account",
        choices=[ASSERTION],
        required=True,
    )
    args = parser.parse_args()

    try:
        manifest, _, query = load_manifest(args.manifest)
    except Exception as exc:
        code = _error_code(exc)
        print(f"ERROR: database manifest rejected ({code}).", file=sys.stderr)
        return 2

    if os.environ.get("OBS_DB_READONLY_ACCOUNT_ASSERTION") != ASSERTION:
        print("ERROR: READ_ONLY_ACCOUNT_ASSERTION_MISSING", file=sys.stderr)
        return 2

    labels = {
        "metrology_system": manifest["system_id"],
        "probe": manifest["probe_id"],
        "dependency": manifest["target_alias"],
    }
    start = time.monotonic()
    success = 0.0
    dependency_up = 0.0
    probe_value: float | None = None
    error_code: str | None = None
    connection = None
    cursor = None

    try:
        connection = (
            connect_pyodbc(manifest["timeout_seconds"])
            if manifest["driver"] == "pyodbc"
            else connect_oracle(manifest["timeout_seconds"])
        )
        cursor = connection.cursor()
        if hasattr(cursor, "timeout"):
            cursor.timeout = manifest["timeout_seconds"]
        cursor.execute(query)
        row = cursor.fetchone()
        if row is None or len(row) != 1:
            raise ValueError("SCALAR_RESULT_REQUIRED")
        if cursor.fetchone() is not None:
            raise ValueError("SINGLE_ROW_REQUIRED")
        probe_value = float(row[0])
        if not math.isfinite(probe_value):
            raise ValueError("NONFINITE_RESULT_PROHIBITED")
        minimum = manifest.get("expected_min")
        maximum = manifest.get("expected_max")
        if minimum is not None and probe_value < float(minimum):
            raise ValueError("VALUE_BELOW_EXPECTED_MIN")
        if maximum is not None and probe_value > float(maximum):
            raise ValueError("VALUE_ABOVE_EXPECTED_MAX")
        dependency_up = 1.0
        success = 1.0
    except Exception as exc:
        error_code = _error_code(exc)
        print(f"ERROR: database probe failed ({error_code}).", file=sys.stderr)
    finally:
        if connection is not None:
            try:
                connection.rollback()
            except Exception:
                pass
        if cursor is not None:
            try:
                cursor.close()
            except Exception:
                pass
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass

    duration = time.monotonic() - start
    now = time.time()
    lines = [
        "# Generated by guarded read-only DB probe v2",
        "# TYPE metrology_probe_success gauge",
        metric("metrology_probe_success", success, labels),
        "# TYPE metrology_probe_duration_seconds gauge",
        metric("metrology_probe_duration_seconds", duration, labels),
        "# TYPE metrology_probe_last_run_unixtime_seconds gauge",
        metric("metrology_probe_last_run_unixtime_seconds", now, labels),
        "# TYPE metrology_dependency_up gauge",
        metric("metrology_dependency_up", dependency_up, labels),
    ]
    if probe_value is not None and success:
        lines.extend(
            [
                f"# TYPE {manifest['metric_name']} gauge",
                metric(manifest["metric_name"], probe_value, labels),
            ]
        )

    mode = int(str(manifest["output_file_mode"]), 8)
    report_value = {
        "schema_version": "1.0.0",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "system_id": manifest["system_id"],
        "probe_id": manifest["probe_id"],
        "target_alias": manifest["target_alias"],
        "success": bool(success),
        "duration_seconds": duration,
        "error_code": error_code,
        "approval_reference": manifest["approval_reference"],
        "query_sha256": manifest["query_sha256"],
        "raw_query_included": False,
        "connection_details_included": False,
        "credentials_included": False,
    }

    try:
        with OutputLock(args.output, int(manifest["lock_stale_seconds"])):
            atomic_write(args.output, "\n".join(lines) + "\n", mode)
            if args.report:
                atomic_write(
                    args.report,
                    json.dumps(report_value, indent=2) + "\n",
                    mode,
                )
    except Exception as exc:
        print(f"ERROR: output publication failed ({_error_code(exc)}).", file=sys.stderr)
        return 3
    return 0 if success else 1


if __name__ == "__main__":
    raise SystemExit(main())
