#!/usr/bin/env python3
"""Bounded, read-only Linux discovery for observability design.

Default exclusions:
- raw logs and journal messages
- file/configuration contents
- environment variables and command lines
- accounts, routes, addresses, DNS suffixes, and remote endpoints
- database content and credentials
- package inventories

Approved paths are metadata-only and symlinks are not followed.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timedelta, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from typing import Any

VERSION = "2.0.0"


def run(command: list[str], timeout: int = 15) -> tuple[int, str, str]:
    try:
        completed = subprocess.run(
            command,
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
            env={"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "LC_ALL": "C"},
        )
        return completed.returncode, completed.stdout, completed.stderr
    except Exception as exc:
        return 127, "", str(exc)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def atomic_write(path: Path, text: str, mode: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        os.chmod(path, mode)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def os_release() -> dict[str, str]:
    values: dict[str, str] = {}
    path = Path("/etc/os-release")
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            values[key] = value.strip().strip('"')
    return values


def memory_info() -> dict[str, int | None]:
    result: dict[str, int | None] = {"total_bytes": None, "available_bytes": None}
    path = Path("/proc/meminfo")
    if not path.exists():
        return result
    values: dict[str, int] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if ":" not in line:
            continue
        key, raw = line.split(":", 1)
        token = raw.strip().split()
        if token and token[0].isdigit():
            values[key] = int(token[0]) * 1024
    result["total_bytes"] = values.get("MemTotal")
    result["available_bytes"] = values.get("MemAvailable")
    return result


def boot_time_utc() -> str | None:
    try:
        uptime = float(Path("/proc/uptime").read_text().split()[0])
        return (datetime.now(timezone.utc) - timedelta(seconds=uptime)).isoformat()
    except Exception:
        return None


def filesystems() -> list[dict[str, Any]]:
    code, out, _ = run(["df", "-P", "-B1", "-T"], timeout=20)
    if code != 0:
        return []
    rows = []
    for line in out.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 7:
            continue
        filesystem, fs_type, total, used, available, percent = parts[:6]
        mountpoint = " ".join(parts[6:])
        rows.append(
            {
                "device_or_filesystem": filesystem,
                "filesystem_type": fs_type,
                "mountpoint": mountpoint,
                "total_bytes": int(total) if total.isdigit() else None,
                "used_bytes": int(used) if used.isdigit() else None,
                "available_bytes": int(available) if available.isdigit() else None,
                "used_percent": percent,
            }
        )
    return rows


def services(max_items: int) -> list[dict[str, str]]:
    if not shutil.which("systemctl"):
        return []
    code, out, _ = run(
        [
            "systemctl",
            "list-units",
            "--type=service",
            "--all",
            "--no-legend",
            "--plain",
            "--no-pager",
        ],
        timeout=30,
    )
    if code not in (0, 1):
        return []
    result = []
    for line in out.splitlines():
        parts = line.split(None, 4)
        if len(parts) >= 4:
            result.append(
                {
                    "name": parts[0],
                    "load": parts[1],
                    "active": parts[2],
                    "sub": parts[3],
                }
            )
    return result[:max_items]


def process_summary(max_items: int) -> list[dict[str, Any]]:
    code, out, _ = run(["ps", "-eo", "comm="], timeout=20)
    if code != 0:
        return []
    counts = Counter(line.strip() for line in out.splitlines() if line.strip())
    return [
        {"name": name, "count": count}
        for name, count in counts.most_common(max_items)
    ]


def listening_ports(max_items: int) -> list[dict[str, Any]]:
    if not shutil.which("ss"):
        return []
    code, out, _ = run(["ss", "-lntupH"], timeout=20)
    if code != 0:
        return []
    results = []
    for line in out.splitlines():
        parts = line.split()
        if len(parts) < 5:
            continue
        protocol = parts[0]
        local = parts[4]
        port = local.rsplit(":", 1)[-1].strip("[]")
        process = None
        if 'users:(("' in line:
            try:
                process = line.split('users:(("', 1)[1].split('"', 1)[0]
            except Exception:
                process = None
        results.append(
            {
                "protocol": protocol,
                "port": int(port) if port.isdigit() else port,
                "process_name": process,
                "address_included": False,
            }
        )
        if len(results) >= max_items:
            break
    return results


def agent_presence(service_rows: list[dict[str, str]]) -> dict[str, Any]:
    names = " ".join(row.get("name", "").lower() for row in service_rows)
    commands = {
        "node_exporter": shutil.which("node_exporter"),
        "otelcol": shutil.which("otelcol") or shutil.which("otelcol-contrib"),
        "splunk": shutil.which("splunk"),
        "prometheus": shutil.which("prometheus"),
    }
    return {
        "known_components": {
            "node_exporter": bool(commands["node_exporter"] or "node_exporter" in names),
            "opentelemetry_collector": bool(commands["otelcol"] or "otelcol" in names),
            "splunk_forwarder_or_daemon": bool(commands["splunk"] or "splunk" in names),
            "prometheus_server": bool(commands["prometheus"] or "prometheus" in names),
        },
        "telemetry_configuration_inspected": False,
    }


def time_service(service_rows: list[dict[str, str]]) -> dict[str, Any]:
    active = {
        row["name"]: row.get("active")
        for row in service_rows
        if any(token in row["name"].lower() for token in ("chrony", "chronyd", "ntp", "timesyncd"))
    }
    return {
        "candidate_services": active,
        "time_source_included": False,
        "offset_measured": False,
    }


def container_runtime(service_rows: list[dict[str, str]]) -> dict[str, Any]:
    names = " ".join(row.get("name", "").lower() for row in service_rows)
    return {
        "docker_detected": bool(shutil.which("docker") or "docker" in names),
        "containerd_detected": bool(shutil.which("containerd") or "containerd" in names),
        "podman_detected": bool(shutil.which("podman") or "podman" in names),
        "container_inventory_collected": False,
    }


def path_inventory(
    paths: list[Path],
    max_items_per_path: int,
    max_elapsed_seconds: int,
    allow_cross_filesystems: bool,
) -> tuple[list[dict[str, Any]], list[str]]:
    """Collect file metadata without following symlinks.

    The elapsed deadline is cooperative and cannot interrupt a blocked kernel
    filesystem call. Start with local bounded paths and use corporate timeout
    supervision for potentially unhealthy remote mounts.
    """
    rows: list[dict[str, Any]] = []
    warnings: list[str] = []
    deadline = time.monotonic() + max_elapsed_seconds

    for approved in paths:
        if time.monotonic() >= deadline:
            warnings.append("Approved-path inventory stopped at the elapsed-time limit")
            break
        try:
            if approved.is_symlink():
                warnings.append(f"Approved root is a symlink and was skipped: {approved}")
                continue
            resolved = approved.resolve(strict=True)
            root_stat = resolved.stat()
        except Exception as exc:
            warnings.append(f"Approved path unavailable: {approved}: {exc}")
            continue

        base = resolved if resolved.is_dir() else resolved.parent
        count = 0

        def add_file(item: Path) -> None:
            nonlocal count
            details = item.stat(follow_symlinks=False)
            rows.append(
                {
                    "approved_root": str(approved),
                    "relative_path": str(item.relative_to(base)),
                    "suffix": item.suffix.lower(),
                    "size_bytes": details.st_size,
                    "modified_at_utc": datetime.fromtimestamp(
                        details.st_mtime, timezone.utc
                    ).isoformat(),
                    "content_collected": False,
                    "filesystem_crossing_allowed": allow_cross_filesystems,
                }
            )
            count += 1

        if resolved.is_file():
            try:
                add_file(resolved)
            except Exception as exc:
                warnings.append(f"Could not inspect metadata for {resolved}: {exc}")
            continue

        stop = False
        for directory, dirnames, filenames in os.walk(
            resolved,
            topdown=True,
            followlinks=False,
        ):
            if time.monotonic() >= deadline:
                warnings.append(f"Elapsed-time limit reached while scanning {approved}")
                break
            directory_path = Path(directory)

            kept_dirs = []
            for name in dirnames:
                child = directory_path / name
                try:
                    if child.is_symlink():
                        continue
                    if not allow_cross_filesystems and child.stat(
                        follow_symlinks=False
                    ).st_dev != root_stat.st_dev:
                        warnings.append(
                            f"Skipped cross-filesystem directory under {approved}: "
                            f"{child.relative_to(base)}"
                        )
                        continue
                    kept_dirs.append(name)
                except Exception as exc:
                    warnings.append(f"Could not inspect directory metadata for {child}: {exc}")
            dirnames[:] = kept_dirs

            for name in filenames:
                if time.monotonic() >= deadline:
                    warnings.append(f"Elapsed-time limit reached while scanning {approved}")
                    stop = True
                    break
                if count >= max_items_per_path:
                    warnings.append(f"Inventory item limit reached for {approved}")
                    stop = True
                    break
                item = directory_path / name
                try:
                    if item.is_symlink():
                        continue
                    if not allow_cross_filesystems and item.stat(
                        follow_symlinks=False
                    ).st_dev != root_stat.st_dev:
                        continue
                    if item.is_file():
                        add_file(item)
                except Exception as exc:
                    warnings.append(f"Could not inspect metadata for {item}: {exc}")
            if stop:
                break
    return rows, warnings

def event_summary(hours: int, max_items: int) -> tuple[list[dict[str, Any]], list[str]]:
    if not shutil.which("journalctl"):
        return [], ["journalctl not available"]
    code, out, err = run(
        [
            "journalctl",
            "--since",
            f"{hours} hours ago",
            "-p",
            "0..3",
            "-o",
            "json",
            "--no-pager",
        ],
        timeout=45,
    )
    if code != 0:
        return [], [f"journalctl summary failed: {err.strip()}"]
    counts: Counter[tuple[str, str, str]] = Counter()
    for line in out.splitlines():
        try:
            event = json.loads(line)
            unit = event.get("_SYSTEMD_UNIT") or "<NO_UNIT>"
            identifier = event.get("SYSLOG_IDENTIFIER") or "<NO_IDENTIFIER>"
            priority = str(event.get("PRIORITY", "<NO_PRIORITY>"))
            counts[(unit, identifier, priority)] += 1
        except Exception:
            continue
    return [
        {
            "unit": key[0],
            "identifier": key[1],
            "priority": key[2],
            "count": count,
            "message_collected": False,
        }
        for key, count in counts.most_common(max_items)
    ], []


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--system-id", required=True)
    parser.add_argument("--output-directory", type=Path, required=True)
    parser.add_argument("--approved-path", action="append", default=[], type=Path)
    parser.add_argument("--max-path-items", type=int, default=5000)
    parser.add_argument("--max-services", type=int, default=5000)
    parser.add_argument("--max-processes", type=int, default=1000)
    parser.add_argument("--max-ports", type=int, default=2000)
    parser.add_argument("--max-elapsed-seconds", type=int, default=120)
    parser.add_argument("--include-event-summary", action="store_true")
    parser.add_argument("--event-lookback-hours", type=int, default=24)
    parser.add_argument("--include-host-name", action="store_true")
    parser.add_argument("--allow-cross-filesystems", action="store_true")
    parser.add_argument("--output-file-mode", choices=["0600", "0640", "0644"], default="0640")
    parser.add_argument("--lock-file", type=Path, default=Path("/tmp/metrology-observability-discovery.lock"))
    args = parser.parse_args()

    start = time.monotonic()
    args.lock_file.parent.mkdir(parents=True, exist_ok=True)
    lock_handle = args.lock_file.open("w")
    try:
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print("ERROR: another discovery process holds the lock", file=sys.stderr)
        return 3

    warnings: list[str] = []
    service_rows = services(args.max_services)
    inventory, inventory_warnings = path_inventory(
        args.approved_path,
        args.max_path_items,
        args.max_elapsed_seconds,
        args.allow_cross_filesystems,
    )
    warnings.extend(inventory_warnings)

    events = None
    if args.include_event_summary:
        events, event_warnings = event_summary(args.event_lookback_hours, 500)
        warnings.extend(event_warnings)

    release = os_release()
    host_name = socket.gethostname()
    collection_id = hashlib.sha256(
        f"{host_name}:{datetime.now(timezone.utc).isoformat()}".encode()
    ).hexdigest()[:16]
    data = {
        "schema_version": "1.0.0",
        "collection": {
            "collected_at_utc": datetime.now(timezone.utc).isoformat(),
            "collector_name": "collect_server_discovery.py",
            "collector_version": VERSION,
            "privilege": "root" if hasattr(os, "geteuid") and os.geteuid() == 0 else "non-root",
            "raw_log_content_collected": False,
            "configuration_content_collected": False,
            "elapsed_seconds": round(time.monotonic() - start, 3),
            "collection_id": collection_id,
        },
        "identity": {
            "system_id": args.system_id,
            "host_fingerprint": sha256_text(host_name),
            "host_name_included": args.include_host_name,
            **({"host_name": host_name} if args.include_host_name else {}),
        },
        "os": {
            "family": "linux",
            "name": release.get("PRETTY_NAME") or platform.platform(),
            "version": release.get("VERSION_ID"),
            "kernel": platform.release(),
            "architecture": platform.machine(),
            "boot_time_utc": boot_time_utc(),
            "timezone": datetime.now().astimezone().tzname(),
        },
        "resources": {
            "logical_cpu_count": os.cpu_count(),
            "memory": memory_info(),
            "filesystems": filesystems(),
        },
        "services": service_rows,
        "process_summary": process_summary(args.max_processes),
        "listening_ports": listening_ports(args.max_ports),
        "time_service": time_service(service_rows),
        "container_runtime": container_runtime(service_rows),
        "observability": agent_presence(service_rows),
        "approved_path_inventory": inventory,
        "event_summary": events,
        "scheduled_task_summary": None,
        "warnings": warnings,
    }

    args.output_directory.mkdir(parents=True, exist_ok=True)
    output_mode = int(args.output_file_mode, 8)
    output = args.output_directory / "server-discovery.json"
    atomic_write(output, json.dumps(data, indent=2) + "\n", output_mode)
    manifest = {
        "schema_version": "1.0.0",
        "system_id": args.system_id,
        "collection_id": collection_id,
        "approved_paths": [str(path) for path in args.approved_path],
        "files_discovered": len(inventory),
        "content_collected": False,
        "human_review_required": True,
        "allow_cross_filesystems": args.allow_cross_filesystems,
        "output_file_mode": args.output_file_mode,
    }
    atomic_write(
        args.output_directory / "evidence-manifest.json",
        json.dumps(manifest, indent=2) + "\n",
        output_mode,
    )
    print(output)
    print("Human review is required before output transfer.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
