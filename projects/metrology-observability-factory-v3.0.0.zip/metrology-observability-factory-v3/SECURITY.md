# Security and Execution Boundary

## Non-negotiable

- Raw logs and raw configurations remain in the corporate environment.
- Credentials, tokens, keys, connection strings, and private certificates are
  prohibited in repository, evidence envelopes, and return bundles.
- Default execution is local and read-only.
- No deployment, restart, failover, database write, account/network change, or
  autonomous remediation exists in the campaign workflow.
- Consequential actions require corporate approval outside this repository.

## Runner authorization

A local runner executes only when:

- `approved_for_host` is true;
- `runner-approval.json` exists;
- campaign and host identities match;
- reviewer role/reference exist;
- production changes remain false;
- manifest SHA-256 exactly matches the approved hash.

## Collection

- normal privilege first;
- explicit approved paths;
- no symlink/reparse traversal;
- bounded services/processes/ports/time;
- Linux same-filesystem default;
- no remote network probes in campaign discovery;
- config metadata/hash only unless a separate approved workflow applies.

## AI

- raw inputs/chunks/prompts/model output remain local;
- argv execution without shell;
- approved sources only;
- schema and security screening;
- root cause confirmation prohibited;
- human review remains required.

## External bundle

- stable pseudonyms;
- no reverse map or salt;
- identity replacement across profiles, evidence, conflicts, and rerun plans;
- denied file-type and secret-pattern screening;
- approval false by default;
- production validated false.

Automated screening reduces risk but does not guarantee confidentiality.
Corporate human review and policy approval remain mandatory.
