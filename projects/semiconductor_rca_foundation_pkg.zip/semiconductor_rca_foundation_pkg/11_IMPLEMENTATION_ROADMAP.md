# Implementation Roadmap for the Internal Coding Agent

## Milestone 0 — Workspace bootstrap
- Read all foundation documents.
- Identify database/query environment.
- Create a local project registry and query log.
- Confirm no sensitive data is copied outside the approved environment.

## Milestone 1 — Table discovery
For supplied table names, execute the discovery protocol and populate the table registry.

Deliverables:
- table map;
- entity/key graph;
- time-coverage matrix;
- join-coverage matrix;
- blockers/warnings.

## Milestone 2 — Canonical lineage
Build/test canonical process instance and wafer trajectory.

Acceptance tests:
- random wafer histories are chronologically valid;
- rework/repeat is preserved;
- chamber mapping coverage measured;
- duplicate row explosion absent;
- data-quality flags exist.

## Milestone 3 — Excursion population and good controls
Implement affected population + good-control tiers.

Acceptance:
- outcome opportunity is explicit;
- unmeasured controls are not labeled good;
- sensitivity to matching window is visible.

## Milestone 4 — Commonality engine
Candidate universe + bad/good enrichment + negative evidence + FDR.

## Milestone 5 — Alarm/equipment state
Alarm episodes, exposure denominators, sparse-rate models, time alignment, state/interlock/config changes.

## Milestone 6 — Maintenance/degradation
PM-cycle features and inferred intervention timeline.

## Milestone 7 — FDC
Recipe-step-aware baselines and interpretable anomaly features for top candidates.

## Milestone 8 — Spatial/metrology
Measurement system checks + canonical wafer coordinates + signature features.

## Milestone 9 — Physics layer
Map company equipment families/sensors to generic physical subsystems and mechanism expectations.

## Milestone 10 — Evidence report
Candidate ranking with support, contradictions, missing evidence, confidence class, next-best test.

## Milestone 11 — Blind replay
Run representative historical cohort with leakage controls.

## Milestone 12 — Advanced ML only if justified
Potential extensions:
- sequence/trajectory attribution;
- hierarchical Bayesian models;
- learned FDC embeddings;
- wafer-map representation learning;
- learned evidence calibration.

Every advanced model must beat or complement the interpretable baseline in held-out replay.
