# Tests and Guardrails

## Data tests
- process_instance unique-key test;
- start <= end;
- trajectory nondecreasing time except documented source corrections;
- valid tool/chamber hierarchy;
- route/operation mapping coverage;
- alarm episode duration nonnegative;
- FDC process-instance join coverage;
- metrology wafer join coverage;
- no uncontrolled many-to-many join multiplication;
- current-state metadata cannot masquerade as historical configuration.

## Control tests
- every good control has outcome opportunity;
- affected wafers never appear as controls for same excursion;
- matching does not condition on tested candidate exposure;
- time-window sensitivity is measured;
- sufficient overlap reported.

## Causality tests
- candidate cause precedes relevant output measurement;
- post-detection evidence clearly labeled;
- negative evidence included;
- competing hypotheses generated;
- no C4/C5 with one evidence channel.

## Statistics tests
- zero baseline counts handled with smoothing/Bayesian uncertainty;
- overdispersion tested before assuming Poisson adequacy;
- multiple-testing correction executed;
- sample size shown with every rate/ratio;
- peer baseline only uses comparable process conditions.

## FDC tests
- recipe-step alignment checked;
- unit/sensor alias consistency checked;
- missingness quantified;
- data leakage from bad-label-derived limits prohibited unless explicitly part of production control system and time-valid.

## Replay leakage tests
- closure fields blocked;
- future timestamps blocked;
- post-fix information blocked before candidate freeze;
- derived tables checked for hidden future leakage.

## LLM guardrails
- LLM may summarize free text and map vocabulary to ontology with evidence;
- LLM may not fabricate joins, units, failure mechanisms, or numeric thresholds;
- LLM cannot override statistical/temporal contradictions;
- every semantic inference should be traceable to observed schema/data/documentation.
