# Statistical Methods Specification

## 1. Commonality statistics
For candidate exposure C and binary outcome Bad/Good, form a 2x2 table.

Preferred outputs:
- affected exposure fraction;
- matched-good exposure fraction;
- risk ratio;
- odds ratio;
- smoothed log odds ratio;
- Fisher exact p-value for sparse cells;
- false-discovery-adjusted q-value across candidate universe.

Use Bayesian/continuity smoothing so zero cells do not create infinite evidence.

### Important
High affected exposure is not sufficient if nearly all comparable good wafers share the exposure.

## 2. Control matching
Use exact/coarsened matching first on high-value manufacturing semantics. Optional propensity/matching models can be used later but must not obscure overlap/positivity failures.

Report whether the candidate comparison has sufficient overlap.

## 3. Alarm episodes
Raw alarm toggles must be clustered/paired into episodes using set/clear semantics when available or configurable temporal debouncing when not.

Preserve:
- number of raw events;
- number of episodes;
- duration;
- toggle intensity.

## 4. Exposure-normalized event rates
Choose denominator from process physics/context:
- comparable wafer runs;
- recipe executions;
- process hours;
- plasma-on time;
- tool-active time;
- another justified exposure unit.

Do not use calendar days if the equipment was not comparably utilized.

## 5. Sparse count modeling
Baseline model options:
- Poisson with exposure offset when dispersion is reasonable;
- Gamma-Poisson / Bayesian rate model for stable uncertainty and zero baselines;
- Negative Binomial when overdispersion exists.

Useful output:
`P(rate_event / rate_baseline > K | data)` for operationally meaningful K values plus posterior interval.

Avoid arbitrary K as the only decision threshold; use historical calibration.

## 6. Time-series / SPC detectors
Use based on signal type:
- robust Z / median-MAD: isolated deviation;
- Shewhart-like thresholds: large shift;
- EWMA: gradual drift;
- CUSUM: persistent small mean shift;
- change-point detection: abrupt regime change;
- variance change tests: instability;
- Hotelling T2 / PCA score: multivariate movement;
- PCA Q/SPE residual: new correlation structure;
- robust Mahalanobis: multivariate outlier;
- correlation/covariance drift: subsystem interaction changes.

## 7. FDC baseline stratification
A sensor baseline should normally condition on enough context to make the distribution meaningful, e.g.:
`tool_family + chamber + recipe_family/version + recipe_step + product/context if materially necessary`.

Use hierarchical pooling when groups are sparse rather than creating fragile tiny baselines.

## 8. Three baselines
For equipment/FDC candidates calculate, where available:
1. self historical;
2. sister/peer chamber;
3. good-outcome run baseline.

Record whether each agrees or contradicts.

## 9. Multiple testing
Use staged/hierarchical screening and Benjamini-Hochberg FDR or an appropriate equivalent within a defined hypothesis family.

Do not combine unrelated p-values casually.

## 10. Spatial statistics/features
After canonical coordinate normalization:
- center/edge means;
- radial bins and gradient;
- azimuthal harmonics;
- edge-band score;
- top-bottom / left-right asymmetry;
- spatial autocorrelation;
- cluster/hotspot measures;
- line/scratch orientation where relevant;
- field/shot-level aggregation for lithography-related signals.

## 11. Sequential/trajectory extensions
After deterministic pipeline works, evaluate methods designed for variable-length trajectories and cross-process attribution. Candidate families include partial-trajectory or sequence-aware attribution models. Their value must be proven by blind replay versus the deterministic baseline.

## 12. Calibration
Do not call raw model output a probability of root cause unless calibrated against held-out historical incidents. Evaluate reliability diagrams/Brier score or equivalent calibration metrics.
