# RCA Pipeline Specification

## Input
`excursion_id`

## Output
Ranked candidate causal entities with evidence, contradictions, confidence class, and next-best test.

## Phase 1 — Reconstruct the event
1. Load excursion record.
2. Determine affected lots/wafers.
3. Resolve duplicate/ambiguous membership.
4. Identify detection mechanism and first bad observation where possible.
5. Establish per-wafer causal time limits.

## Phase 2 — Build affected trajectories
For every affected wafer:
1. reconstruct complete ordered process history;
2. preserve rework/repeat/skip behavior;
3. link actual tool/chamber/recipe where possible;
4. attach data-quality flags;
5. exclude future process events after defect observation from possible defect-generation candidates, while retaining them as contextual evidence.

## Phase 3 — Select eligible controls
Use `08_CONTROL_SELECTION.md`.
Build multiple control tiers, not one undifferentiated set.

## Phase 4 — Enumerate causal candidates
From affected trajectories and shared-resource context enumerate:
- operation;
- tool;
- chamber/module;
- recipe/version;
- route/version;
- maintenance condition;
- reticle;
- carrier;
- material/consumable if available;
- APC/R2R state;
- facility source;
- metrology system where an apparent excursion may be measurement-generated.

Do not enumerate alarms as root causes by default; alarms are usually evidence of an underlying equipment/subsystem condition. An alarm code can be a candidate signature, not necessarily the physical cause.

## Phase 5 — Commonality + counterfactual analysis
For each candidate:
- affected exposure rate;
- matched-control exposure rate;
- odds/risk ratio with smoothing;
- exact/statistical significance when appropriate;
- affected coverage;
- good-wafer contradiction count;
- temporal validity;
- concentration by operation/time/chamber/recipe.

Early prune candidates with poor temporal validity or no enrichment unless required as competing hypotheses.

## Phase 6 — Equipment temporal anomaly search
For leading equipment/chamber candidates:
1. create alarm episodes;
2. choose a physical exposure denominator;
3. estimate baseline from comparable historical operation;
4. estimate event-window rate;
5. evaluate rate uplift uncertainty;
6. screen state transitions, interlocks, counters, configuration changes;
7. run change/drift detectors on appropriate scalar signals;
8. compare self-history, sister chambers, and good-wafer runs;
9. correct for multiple testing.

## Phase 7 — Maintenance/degradation context
Compute at each affected process instance:
- wafers/runs/hours since PM;
- time since clean;
- relevant component age;
- counter state;
- location in normal maintenance cycle;
- recent unscheduled work;
- post-maintenance seasoning/qualification state.

Search for concentration of bad wafers in a degradation interval.

## Phase 8 — FDC investigation
Do not scan every raw sensor in the fab first.
For leading candidates:
1. identify comparable good runs by chamber+recipe/step+context;
2. align trace to recipe steps;
3. compute robust univariate features;
4. compute multivariate anomaly features;
5. compare affected vs controls and peer chambers;
6. identify sensor groups/subsystems that explain the anomaly;
7. retain raw trace plots or pointers for engineer review.

## Phase 9 — Metrology/spatial confirmation
1. verify measurement-system health;
2. normalize coordinates/orientation;
3. compute spatial features;
4. characterize defect signature;
5. compare predicted physical mechanism with actual signature;
6. check repeats/alternate metrology where available.

## Phase 10 — Physics consistency
Use process-family-specific mechanism knowledge. Statistical discovery comes first; physics validates/rejects the story.

Example rule form:
IF process_family=ETCH AND candidate_subsystem=BACKSIDE_HE/ESC
AND FDC indicates He/temperature abnormality
THEN expected signatures may include thermal/radial nonuniformity or etch-rate/CD/profile effects depending on recipe.
Do not claim a specific mechanism unless observed outputs are compatible.

## Phase 11 — Competing hypotheses
Explicitly search for:
- same reticle/material/carrier across bad wafers;
- recipe/version changes;
- APC/R2R changes;
- facility common mode;
- metrology-tool artifact;
- upstream/downstream alternative operation with stronger enrichment.

## Phase 12 — Intervention/recovery inference
If explicit corrective action exists, link it.
Otherwise infer candidate interventions from:
- equipment downtime;
- PM/maintenance events;
- chamber clean;
- component replacement;
- config/recipe changes;
- NPW/qualification sequence;
- equipment release;
- subsequent FDC normalization;
- subsequent good production.

Label inferred interventions with confidence; never present inference as documented fact.

## Phase 13 — Evidence fusion
Preserve full evidence vector. Apply confidence rules in `09_EVIDENCE_AND_CONFIDENCE.md`.

## Phase 14 — Result
For each candidate return:
- rank;
- entity hierarchy;
- confidence class;
- strongest support;
- strongest contradiction;
- missing evidence;
- causal time status;
- data-quality status;
- physical mechanism hypothesis;
- next-best confirmatory test.

If no candidate meets evidence requirements, abstain.
