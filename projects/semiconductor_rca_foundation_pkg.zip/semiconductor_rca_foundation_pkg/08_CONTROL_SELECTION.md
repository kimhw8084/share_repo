# Good-Control Definition and Selection

## Definition
For excursion symptom Y, a good control wafer is a wafer that:
1. had a meaningful opportunity to exhibit Y;
2. is sufficiently comparable to an affected wafer in relevant manufacturing context;
3. has evidence that Y was not present.

Therefore:
`Good = Comparable AND Observed_For_Target AND Normal_Outcome`

A wafer is not good merely because it is absent from the excursion membership table.

## Eligibility
Where available require/consider:
- same product/device family;
- compatible route/route revision;
- same relevant operation;
- same recipe family/version where not the variable being tested;
- comparable time neighborhood;
- same production/engineering class;
- compatible rework state;
- comparable measurement opportunity/sampling;
- measurement result demonstrably normal for the excursion signature.

## Avoid conditioning away the suspect
Do not force exact matching on the candidate exposure being tested. Example: when testing chamber C, do not require controls to have chamber C.

## Control tiers
### Tier A — within-lot good wafers
Powerful for controlling upstream/product/material context when affected and good wafers coexist in the lot.

### Tier B — same product/route/operation/time
Primary excursion counterfactual set.

### Tier C — same recipe/time on peer chambers
Useful for chamber/tool matching.

### Tier D — same chamber before/after event
Useful for temporal state-change analysis.

### Tier E — historical same chamber+recipe
Useful baseline for alarms/FDC.

### Tier F — NPW/monitor/qualification wafers
Independent equipment-condition evidence; not necessarily interchangeable with product controls.

## Sampling bias
If metrology/inspection samples only selected wafers, explicitly model eligibility. Unmeasured wafers should be UNKNOWN outcome unless another valid measurement proves normality.

## Match diagnostics
Always report:
- number affected;
- number eligible controls;
- time distance;
- product/route mismatch;
- measurement coverage;
- whether overlap is adequate;
- exclusions.

## Sensitivity
Run commonality across more than one defensible control definition. A candidate that only appears under one fragile control rule deserves lower confidence.
