# Scientific Doctrine

## 1. Problem statement
An excursion is an observed manufacturing-quality abnormality. The forensic problem is to identify which upstream causal entity or mechanism most plausibly generated the defect, while controlling for normal tool usage, product/route differences, sampling effects, temporal ordering, and alternative explanations.

## 2. What counts as evidence
### Anomaly
A tool, chamber, sensor, alarm, counter, measurement, or maintenance condition differs from its expected behavior.

### Association
The condition is disproportionately associated with affected wafers versus appropriate controls.

### Causal evidence
The condition:
- occurs at a causally valid time;
- predicts/associates with bad outcome relative to matched controls;
- is abnormal relative to suitable baselines;
- is physically compatible with the observed defect;
- survives competing-explanation checks;
- is corroborated by independent evidence channels;
- optionally disappears or normalizes after an intervention.

## 3. Core causal doctrine
For candidate C:
`CausalEvidence(C) = f(Commonality, Counterfactual, Time, Anomaly, Degradation, FDC, Physics, Spatial, Intervention, Contradictions, DataQuality)`

Do not implement this initially as a fixed weighted sum. Preserve the evidence vector. Historical replay should later calibrate a probability model.

## 4. Unit-of-analysis hierarchy
Preferred causal hierarchy:
`fab > area > process_family > operation > tool > module/chamber > subsystem > component > failure_mechanism`

Other cross-cutting entities:
`recipe/version, route/version, reticle, carrier/FOUP, material/chemical lot, consumable, operator/manual override, APC/R2R state, facility zone/source, metrology tool/recipe`.

## 5. Ordered trajectory doctrine
A wafer's manufacturing route is ordered and may contain rework, repeat, skip, hold, split, merge, and alternate-tool behavior. Preserve event ordering and process-instance identity.

## 6. Causal-window doctrine
Do not use event creation/closure as the causal window except for administrative reporting.

For each affected wafer, define relevant exposure times upstream of the first observation of the defect. Candidate evidence must be tagged as PRE_EXPOSURE, DURING_EXPOSURE, POST_EXPOSURE_PRE_DETECTION, or POST_DETECTION.

Evidence occurring after the causal process cannot have caused that wafer's defect, although it may corroborate a deteriorating condition.

## 7. Counterfactual doctrine
Every commonality claim must be compared against eligible good controls. “Not listed as bad” is not a good-control definition.

## 8. Measurement doctrine
Metrology/inspection is both evidence and a possible causal source of apparent excursion. Measurement tool, recipe, calibration, sampling, and repeatability must be modeled.

## 9. Multiple-testing doctrine
The search space may contain many thousands of tool/alarm/sensor/entity hypotheses. Apply hierarchical screening and false-discovery control. A rare-looking result among a huge search space is not automatically evidence.

## 10. Abstention doctrine
The system must explicitly return insufficient evidence when:
- coverage is poor;
- controls are inadequate;
- timestamp ordering is unreliable;
- multiple candidates remain equally plausible;
- physical evidence contradicts the statistical leader;
- measurement-system failure cannot be excluded.
