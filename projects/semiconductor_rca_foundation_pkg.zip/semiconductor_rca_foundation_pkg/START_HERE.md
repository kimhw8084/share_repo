# START HERE — Semiconductor Excursion Forensic Intelligence Foundation

## What this package is
This is a scientific and engineering specification for building a semiconductor wafer-excursion cause-finding platform inside a company environment. It intentionally does **not** contain a finished production system. It defines the logic tightly enough that an internal coding agent (for example Gemma 4) can inspect company tables and implement the system without inventing the causal methodology.

## Core achievement target
Given only information available when an excursion is detected, automatically reconstruct every affected wafer's process lineage, search candidate causal entities without keyword assumptions, statistically separate excursion-specific behavior from normal manufacturing behavior, identify the responsible process/chamber/time window, and independently corroborate the hypothesis using equipment state, alarms, FDC, PM/maintenance, metrology/spatial evidence, and—when recoverable—intervention/recovery evidence.

## The doctrine in one line
**Exposure + Counterfactual + Time + Anomaly + Equipment State + Physics + Spatial Evidence + Intervention − Contradictions = Causal Confidence.**

## How to use this package on the work PC
1. Give `00_GEMMA_MASTER_INSTRUCTION.md` to Gemma as the persistent project instruction.
2. Tell Gemma the database/query environment and the names of the tables that may be relevant. Do not manually explain every column unless the semantics cannot be recovered safely.
3. Gemma must execute `02_DATA_DISCOVERY_PROTOCOL.md` before using a new table in RCA logic.
4. Gemma writes/updates `config/table_registry.yaml` locally with discovered table grain, keys, time coverage, joins, quality warnings, and causal role.
5. Gemma builds the canonical entities defined in `03_CANONICAL_ONTOLOGY.yaml` rather than hard-coding logic directly to raw source tables.
6. Implement the deterministic pipeline in `05_RCA_PIPELINE_SPEC.md` before advanced ML.
7. Use the statistical rules in `06_STATISTICAL_METHODS.md`, the control logic in `08_CONTROL_SELECTION.md`, and the physics library in `07_PROCESS_PHYSICS_KB.md`.
8. Validate using historical blind replay in `10_HISTORICAL_REPLAY_VALIDATION.md`.
9. Do not promote a high-confidence root cause unless it satisfies `09_EVIDENCE_AND_CONFIDENCE.md`.

## What you need to tell Gemma initially
At minimum:
- SQL/query dialect or data platform.
- Table names for excursion/event registration and closure.
- affected lot/wafer table(s).
- lot/wafer transaction or movement history.
- process plan/operation definitions.
- tool/chamber metadata.
- alarm/event history.
- FDC summary/raw trace tables.
- metrology/inspection/test tables.
- PM/maintenance/work-order tables.
- NPW/monitor/qualification wafer history.
- any newly discovered APC/R2R, SPC, configuration, reticle, carrier, facility, calibration, or material tables.

Gemma should discover schemas, keys, and relationships itself using the controlled protocol.

## Non-negotiable rules
- Never equate correlation with cause.
- Never define a good control merely as “not listed as bad.”
- Never count raw alarm message volume without forming alarm episodes and an exposure denominator.
- Never use post-detection information as if it was available before detection during blind replay.
- Never force a root-cause answer when evidence is insufficient.
- Never allow an LLM narrative to override quantitative evidence.
- Never interpret a table or column semantically without evidence from schema, values, joins, or company documentation.
- Never let one evidence channel alone generate the highest confidence class.

## Recommended initial deliverable
A retrospective service/notebook that accepts one historical excursion ID and returns:
- affected population and causal window;
- matched good controls;
- ranked process/tool/chamber/other candidate entities;
- commonality and negative-control evidence;
- anomalous alarm/equipment-state evidence;
- FDC evidence for top candidates;
- PM/degradation evidence;
- spatial/metrology concordance;
- alternate explanations;
- confidence class and explicit contradictions;
- next-best engineering test;
- abstention when evidence is not sufficient.
