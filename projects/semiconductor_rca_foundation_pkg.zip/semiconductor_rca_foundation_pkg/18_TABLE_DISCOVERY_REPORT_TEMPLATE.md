# Table Discovery Report — Template

## Identity
- Source table:
- Data owner/source system if known:
- Discovery date:
- Query dialect:

## Inferred grain
- Proposed row grain:
- Evidence for grain:
- Confidence: High / Medium / Low

## Keys
- Confirmed unique key:
- Candidate keys tested:
- Duplicate behavior:

## Time semantics
- Event/effective timestamp(s):
- Meaning:
- Earliest/latest:
- Precision:
- Timezone/clock caveat:
- Historical vs current-state:

## Quality
- Row count:
- Null-heavy columns:
- Sentinel/invalid patterns:
- Suspected duplicate rate:
- Data gaps:

## Canonical mappings
- Canonical entity/entities supported:
- Field mapping:

## Join tests
For each target:
- condition:
- source coverage:
- target coverage:
- cardinality:
- multiplication factor:
- unmatched pattern:

## Forensic role
- What evidence/capability does this table add?
- Can it establish causal timing?
- Does it contain outcome labels or post-event leakage risk?

## Warnings
- ...

## Decision
- APPROVED_FOR_CAUSAL_USE
- APPROVED_WITH_LIMITATIONS
- REFERENCE_ONLY
- NOT_YET_UNDERSTOOD
