# Historical Blind Replay Validation

## Purpose
Prove the system finds causes rather than reconstructing known closure narratives.

## Replay clock
For each historical excursion choose an analysis cutoff corresponding to the moment of detection or a realistic early investigation point.

## Data permitted
Only data whose information timestamp would have been available by the replay cutoff, except historical baselines built strictly from earlier data.

## Hidden during scoring
- final root-cause field;
- closure narrative;
- later engineer comments revealing cause;
- corrective actions occurring after cutoff;
- later work orders revealing component replacement;
- post-event qualification/results;
- future metrology.

These may be used only after the ranked candidates are frozen.

## Evaluation unit
Evaluate at multiple hierarchy levels:
- responsible operation;
- tool;
- chamber/module;
- subsystem/component if reliable truth exists;
- mechanism category.

Historical RCA is not automatically perfect ground truth. Maintain label confidence: confirmed/probable/suspected/unknown.

## Metrics
Primary:
- Top-1 accuracy;
- Top-3 recall;
- Top-5 recall;
- mean reciprocal rank;
- operation attribution accuracy;
- chamber attribution accuracy;
- false-candidate burden;
- coverage / abstention rate;
- investigation compute/runtime.

Calibration:
- reliability/calibration by confidence class/model probability;
- Brier score or appropriate alternative after probability calibration.

Breakdowns:
- process family;
- single- vs multi-lot excursion;
- equipment vs process vs measurement vs material cause;
- easy/medium/hard cases;
- known vs uncertain historical RCA.

## Leakage tests
Create automated assertions that no field derived from closure/corrective-action/future data enters pre-cutoff scoring.

## Robustness tests
- vary matched-control window;
- remove one evidence channel at a time;
- perturb timestamp tolerance;
- compare self vs peer baselines;
- test candidate ranking with/without free-text information;
- test whether alarm-description keywords materially change results; the engine should remain useful without them.

## Promotion criterion
Do not claim production readiness from cherry-picked cases. Establish a representative event cohort and document exclusions.
