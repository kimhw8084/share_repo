# Foundation Build Acceptance Checklist

## Discovery
- [ ] Every source table used in RCA has a discovery report/registry entry.
- [ ] Row grain and time semantics are known.
- [ ] Join multiplication is tested.
- [ ] Historical-vs-current state is explicit.

## Canonical lineage
- [ ] Wafer trajectory reconstructs ordered operations.
- [ ] Rework/repeat is preserved.
- [ ] Tool and chamber coverage is quantified.
- [ ] Recipe/version coverage is quantified.
- [ ] Timestamp quality is quantified.

## Outcome and controls
- [ ] Affected membership has provenance.
- [ ] Good controls have measurement/outcome opportunity.
- [ ] Multiple control tiers are supported.
- [ ] Unmeasured wafers are not automatically good.

## Candidate generation
- [ ] Tool/chamber is not the only candidate type.
- [ ] Recipe/version, reticle/carrier/material/facility/metrology alternatives are supported when data exists.

## Statistical engine
- [ ] Bad-vs-good enrichment reported.
- [ ] Sparse cells handled safely.
- [ ] Alarm episodes, not raw toggles, are scored.
- [ ] Exposure denominator is explicit.
- [ ] Multiple testing is controlled.
- [ ] Self/peer/good-outcome baselines are separated.

## FDC
- [ ] Recipe/step context is respected.
- [ ] Missingness/units/aliases are validated.
- [ ] Interpretable features exist before deep models.

## PM/degradation
- [ ] Time/runs/wafers since maintenance can be computed where data permits.
- [ ] NPW/qualification state can be associated with equipment timeline.

## Metrology
- [ ] Measurement system itself can be tested as a candidate.
- [ ] Coordinate/orientation normalization exists for spatial data.

## Evidence
- [ ] Support and contradictions stored separately.
- [ ] C0-C5 evidence class implemented.
- [ ] High-confidence class cannot arise from one evidence channel.
- [ ] Abstention implemented.

## Validation
- [ ] Historical replay cutoff enforced.
- [ ] Closure/corrective-action leakage prevented.
- [ ] Top-k and abstention metrics generated.
- [ ] Error taxonomy generated.

## Deployment safety
- [ ] Initial system is decision support only.
- [ ] No automatic tool action, disposition, recipe change, or RCA closure.
