# Process Physics Knowledge Base — Foundation

## Purpose
Provide mechanism-consistency reasoning after statistical candidate discovery. Company-specific tool models and sensor names should be mapped into these generic physical domains.

This is a foundation, not a vendor service manual. Exact mechanisms depend on tool design and recipe.

---
## Plasma Etch
### Major equipment domains
- RF source power
- bias power
- matching network
- pressure/throttle control
- vacuum/pump
- gas delivery/MFCs
- ESC/chuck
- backside helium
- wafer/chamber temperature
- endpoint/optical systems
- chamber wall condition / seasoning
- showerhead/gas distribution where applicable

### Potential output signatures
- etch-rate shift
- CD shift
- profile/sidewall change
- selectivity shift
- residue
- center-edge/radial nonuniformity
- localized nonuniformity
- particles/contamination

### Mechanism reasoning examples
RF/bias abnormality -> ion-energy/plasma-density effects -> rate/profile/CD/selectivity signatures.
Pressure/gas abnormality -> chemistry/transport effects -> rate/CD/profile/uniformity.
ESC/backside-He/temperature abnormality -> wafer thermal nonuniformity -> radial/localized process signature.
Chamber condition/seasoning -> chemistry/particle/wall-state drift -> time-since-clean dependence and possible lot-position behavior.

---
## CVD / PECVD / ALD / Related Deposition
### Domains
- precursor/reactant delivery
- MFC/valves
- chamber pressure/vacuum
- substrate temperature
- RF/plasma for plasma-assisted processes
- showerhead/gas distribution
- chamber wall deposition/clean state
- timing/purge sequences for cyclic processes

### Signatures
- thickness mean/uniformity
- film composition/index/stress
- step coverage
- sheet resistance where relevant
- particles
- within-wafer radial pattern

---
## PVD / Sputter
### Domains
- target state/age
- power/plasma
- pressure/gas
- magnet/field behavior where relevant
- wafer temperature
- chamber contamination
- target-to-wafer geometry

### Signatures
- thickness/uniformity
- Rs
- composition
- particles
- edge/center pattern

---
## CMP
### Domains
- pad age/condition
- conditioner
- slurry delivery/concentration
- carrier/head zone pressures
- retaining ring
- platen speed
- wafer/head rotation
- endpoint/removal-time control
- temperature/friction proxies if measured

### Signatures
- radial removal-rate shift
- center/edge nonuniformity
- zonal pattern
- scratches
- dishing/erosion
- residual film

### Reasoning
Pressure-zone or retaining-ring problems often imply spatially structured removal signatures. Pad/conditioner/slurry problems may appear as drift with usage/maintenance cycle and broader wafer/lot effects.

---
## Lithography / Coat-Develop Track
### Scanner domains
- reticle/mask
- dose/source
- focus/leveling
- alignment/overlay
- wafer stage/chuck
- projection/optical condition

### Track domains
- resist dispense
- spin
- bake/chill
- developer
- temperature/time
- chemical lot/age

### Signatures
- CD
- focus/exposure signature
- overlay vectors
- field/shot systematic pattern
- edge effects
- resist/coating defects

### Causal alternatives
Always compare scanner/track/reticle/process and metrology contributions rather than treating one tool as the only possible source.

---
## Ion Implant
### Domains
- source condition
- beam current
- dose control
- energy
- mass analysis
- scan/uniformity
- wafer charging/temperature
- angle/orientation

### Signatures
- sheet resistance
- dose/uniformity
- electrical/junction effects
- spatial scan signatures

---
## Thermal / Furnace / RTP
### Domains
- temperature calibration
- zone matching
- ramp rate/time
- gas/ambient
- pressure where applicable
- wafer/boat position
- lamp/heater condition for RTP

### Signatures
- film/dopant/electrical properties
- Rs
- radial or axial position patterns
- activation/thermal-budget effects

---
## Wet Clean / Wet Etch
### Domains
- bath chemistry/concentration
- bath age
- temperature
- flow/agitation
- rinse
- dry
- filter/contamination

### Signatures
- particles
- residue
- contamination
- etch/removal rate
- water marks/dry-related signatures
- lot/batch commonality

---
## Metrology / Inspection
### Domains
- tool calibration
- measurement recipe
- focus/alignment
- optical/e-beam subsystem condition
- sampling plan/site map
- reference standards

### Apparent signatures
A measurement-system excursion may mimic a process excursion. Require repeatability, cross-tool, calibration, or upstream-physics corroboration when possible.

---
## Cross-process entity reasoning
Always allow these competing entities when data exists:
- reticle/mask;
- FOUP/carrier;
- material/chemical lot;
- shared consumable/bath/target/pad;
- facility utility/source zone;
- software/configuration/recipe revision;
- APC/R2R correction state;
- operator/manual override.

## Knowledge-base extension contract
For each company tool family, create a mapping:
`company_tool_model -> generic_process_family -> chambers/modules -> subsystem groups -> sensor groups -> likely output signatures -> PM lifecycle variables`.

Never encode alarm-description keywords as the only mapping. Sensor names/alarms can support a subsystem mapping after their semantics are validated.
