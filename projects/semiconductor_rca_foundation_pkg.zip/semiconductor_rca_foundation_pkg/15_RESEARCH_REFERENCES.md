# Research and Standards References

Use these as methodological anchors, not as substitutes for company process engineering knowledge.

## Semiconductor trajectory / RCA research
- IBM Research, “Wafer Defect Root Cause Analysis with Partial Trajectory Regression” (2025): variable-length wafer process trajectories, rework, waiting-time variability, upstream attribution.
  https://research.ibm.com/publications/wafer-defect-root-cause-analysis-with-partial-trajectory-regression
- IBM Research, “Sequence-Aware Inline Measurement Attribution for Good-Bad Wafer Diagnosis” (2025): sequence-aware attribution across manufacturing history.
  https://research.ibm.com/publications/sequence-aware-inline-measurement-attribution-for-good-bad-wafer-diagnosis-dm-big-data-management-and-machine-learning
- IBM Research, “Cross-Process Defect Attribution using Potential Loss Analysis” (2025): cross-process defect attribution framework.
  https://research.ibm.com/publications/cross-process-defect-attribution-using-potential-loss-analysis
- “Tool-to-Tool Matching Analysis Based Difference Score Computation Methods for Semiconductor Manufacturing” (2025): process-sensor time-series based tool/chamber matching.
  https://arxiv.org/html/2507.10564v1

## Statistical process monitoring
- NIST/SEMATECH e-Handbook, control charts: univariate/multivariate SPC, CUSUM, EWMA and related monitoring methods.
  https://www.itl.nist.gov/div898/handbook/pmc/section3/pmc3.htm
  https://www.itl.nist.gov/div898/handbook/pmc/section3/pmc323.htm
  https://www.itl.nist.gov/div898/handbook/pmc/section3/pmc324.htm

## SEMI semantic anchors
- SEMI Information & Control standards index. Relevant semantic areas include E116 Equipment Performance Tracking, E133 APC Systems Interface, E157 Module Process Tracking, E160 Communication of Data Quality, and related standards.
  https://www.semi.org/en/products-services/standards/information_and_control

## How to use references
- Preserve trajectory order rather than flattening prematurely.
- Use chamber/peer matching as an independent baseline.
- Use SPC/change detection for equipment/FDC evidence.
- Adopt module/process/data-quality semantics even when company source systems do not literally implement the SEMI standard.
