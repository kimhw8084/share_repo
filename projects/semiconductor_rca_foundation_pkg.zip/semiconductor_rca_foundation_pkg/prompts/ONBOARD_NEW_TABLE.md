# Prompt — Onboard a New Table

A new potentially relevant table is available: `<TABLE_NAME>`.

Follow `02_DATA_DISCOVERY_PROTOCOL.md` exactly.
Do not assume semantics from the table or column names alone.
Inspect schema, infer row grain and keys, profile timestamps/coverage/missingness/cardinality, test joins to currently registered canonical entities, determine historical validity, and classify its causal role.

Then:
1. update the local table registry;
2. state what RCA capability this table enables or strengthens;
3. list remaining ambiguity;
4. propose only the necessary adapter/canonical mapping changes;
5. do not rewrite the scientific RCA methodology.
