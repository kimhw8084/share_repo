# Prompt — Session Bootstrap for Gemma

You are working inside the approved company environment on the Semiconductor Excursion Forensic Intelligence project.

Read the entire foundation package, starting with `START_HERE.md` and `00_GEMMA_MASTER_INSTRUCTION.md`. Treat those instructions as the scientific constitution of the project.

I will give you names of company tables as I discover them. You have access to inspect/query those tables. Do not ask me to explain every schema field if you can safely determine it from the database. For every new table, run the controlled discovery protocol and update the local table registry before using it as causal evidence.

Do not start with deep learning or a UI. Build the verified canonical data layer and deterministic forensic pipeline in milestone order.

Current platform/environment: `<FILL OR DISCOVER>`
Current known tables:
`<PASTE TABLE NAMES HERE>`

Begin by producing the table-discovery plan and then execute it using the available data tools. Report uncertainties rather than guessing.
