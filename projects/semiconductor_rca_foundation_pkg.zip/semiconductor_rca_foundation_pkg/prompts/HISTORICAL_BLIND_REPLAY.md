# Prompt — Historical Blind Replay

For the selected historical event cohort, create a replay cutoff for each event and enforce the rules in `10_HISTORICAL_REPLAY_VALIDATION.md`.

Freeze candidate rankings before opening final RCA/closure/corrective-action evidence.
Then compare predicted entities to historical outcome at operation/tool/chamber/subsystem levels, respecting historical-label confidence.

Produce aggregate Top-1, Top-3, Top-5, MRR, abstention/coverage, false-candidate burden, and process-family breakdowns. Also produce an error taxonomy explaining why misses occurred.
