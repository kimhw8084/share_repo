# Prompt — Analyze One Excursion

Analyze excursion `<EXCURSION_ID>` using the forensic specification.

Do not read documented final RCA/closure explanation until the candidate ranking is frozen if this is a blind replay.

Return:
1. affected-wafer definition and coverage;
2. causal time window;
3. control populations and diagnostics;
4. candidate universe;
5. Top candidates with bad-vs-good commonality;
6. alarm/equipment-state evidence;
7. PM/degradation evidence;
8. FDC evidence;
9. metrology/spatial evidence and measurement-system checks;
10. physical mechanism compatibility;
11. competing explanations;
12. inferred/documented interventions if time-valid;
13. contradictions and missing evidence;
14. confidence class;
15. next-best engineering test;
16. abstain if evidence is insufficient.
