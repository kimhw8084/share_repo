# Prompt — Begin Foundation Build

Read the complete semiconductor RCA foundation package before coding.

Your first objective is not to build a UI or train a model. Establish:
1. verified table registry;
2. canonical wafer/process lineage;
3. excursion population reconstruction;
4. good-control eligibility and matching;
5. auditable candidate-evidence store.

Implement tests before extending to alarms/FDC/metrology.
Use raw source tables only through adapters/canonical views.
At each milestone, report:
- what is implemented;
- validation tests and results;
- coverage/data-quality limitations;
- next minimal milestone.

Do not claim root-cause accuracy before historical blind replay.
