# Canonical Data Contracts

The production implementation may use views, tables, DataFrames, or distributed datasets. The scientific modules should see consistent contracts.

## A. `canonical_process_instance`
Minimum:
- process_instance_id
- wafer_id
- lot_id if available
- operation_id
- process_family
- route_id/version if available
- tool_id
- chamber_id if applicable
- recipe_id/version if available
- start_time
- end_time
- rework_flag
- engineering_flag
- data_quality fields

## B. `canonical_excursion_population`
- excursion_id
- wafer_id
- affected_flag
- symptom/measurement target if known
- detection_time
- first_bad_measurement_time if known
- severity
- membership source/confidence

## C. `canonical_alarm_episode`
- tool/chamber
- alarm code/family
- episode start/end
- duration
- toggle count
- severity
- equipment state
- overlapping process instances
- data quality

Raw alarm toggles must be preserved separately.

## D. `canonical_equipment_health`
At relevant process time:
- time/wafers/runs since PM
- time/runs since clean
- component age where available
- counters/interlocks
- equipment state
- prior alarm burden
- qualification state

## E. `canonical_fdc_feature`
- process_instance
- sensor/feature
- recipe step
- feature value
- reference center/scale
- anomaly metrics
- sensor unit/quality

## F. `canonical_metrology`
- wafer
- measurement type
- measurement tool/recipe
- timestamp
- value
- x/y/orientation if spatial
- limits if valid historically
- repeat/calibration context when available

## G. `candidate_evidence`
One row per excursion x candidate x evidence item:
- excursion_id
- candidate_entity_type/id
- evidence_channel
- statistic/score
- support_or_contradiction
- causal_time_class
- p/q/posterior if applicable
- data_quality
- explanation
- source pointers/query IDs

This table is the audit backbone.
