# Implementation Pseudocode Contract

This is language-agnostic. Gemma may implement with SQL/Python/Spark/Polars/etc., but must preserve behavior.

```text
function analyze_excursion(excursion_id, replay_cutoff = null):
    event = load_excursion(excursion_id, replay_cutoff)
    population = resolve_affected_population(event, replay_cutoff)
    assert population.coverage_is_reported

    trajectories = reconstruct_trajectories(population.affected_wafers, replay_cutoff)
    quality = evaluate_trajectory_quality(trajectories)

    causal_limits = infer_causal_time_limits(event, population, trajectories)
    trajectories = tag_temporal_validity(trajectories, causal_limits)

    controls = build_control_sets(event, population, trajectories, replay_cutoff)
    validate_control_outcome_opportunity(controls)

    candidates = enumerate_candidate_entities(trajectories, event)

    commonality = []
    for candidate in candidates:
        stat = compare_bad_vs_good(candidate, population, controls)
        stat.temporal_validity = candidate_temporal_validity(candidate, trajectories)
        commonality.append(stat)

    commonality = apply_multiple_testing(commonality, family="candidate_commonality")
    leaders = screen_leading_candidates(commonality)

    evidence_store = persist_commonality_evidence(leaders)

    equipment_leaders = candidates_requiring_equipment_investigation(leaders)
    for candidate in equipment_leaders:
        alarm_episodes = construct_alarm_episodes(candidate, replay_cutoff)
        exposure = determine_physical_exposure(candidate, trajectories, controls)
        alarm_stats = compare_event_vs_baseline_rates(alarm_episodes, exposure)
        state_stats = analyze_equipment_state(candidate, replay_cutoff)
        drift_stats = run_appropriate_change_detectors(candidate)
        peer_stats = compare_peer_chambers(candidate)
        good_run_stats = compare_good_outcome_runs(candidate)
        persist_evidence(candidate, alarm_stats, state_stats, drift_stats,
                         peer_stats, good_run_stats)

        health = compute_maintenance_degradation_state(candidate, trajectories)
        persist_evidence(candidate, health)

    fdc_targets = choose_fdc_targets(evidence_store)
    for candidate in fdc_targets:
        baseline_runs = select_comparable_good_runs(candidate)
        aligned = align_fdc_by_recipe_step(candidate, baseline_runs)
        fdc_features = extract_interpretable_fdc_features(aligned)
        fdc_stats = compare_fdc(candidate, fdc_features, baseline_runs,
                                self_history=true,
                                peer_chambers=true,
                                good_outcomes=true)
        persist_evidence(candidate, fdc_stats)

    measurement_health = analyze_measurement_system(event, replay_cutoff)
    spatial_signature = characterize_excursion_signature(event, population)
    persist_evidence("measurement_system", measurement_health)

    for candidate in top_candidates(evidence_store):
        physics = check_physical_mechanism_compatibility(candidate,
                                                         evidence_store,
                                                         spatial_signature)
        persist_evidence(candidate, physics)

    alternatives = search_alternate_commonality(
        population,
        trajectories,
        controls,
        entity_types=[reticle, carrier, material, recipe_version,
                      apc_r2r_state, facility_source, metrology_system])
    persist_evidence(alternatives)

    interventions = find_documented_or_inferred_interventions(
        leaders, event, replay_cutoff)
    # During blind replay, post-cutoff intervention evidence cannot change the frozen ranking.
    persist_evidence(interventions)

    candidate_vectors = assemble_evidence_vectors(evidence_store)
    results = assign_evidence_classes(candidate_vectors)
    results = apply_contradiction_rules(results)
    results = apply_data_quality_gates(results, quality)

    if should_abstain(results):
        return abstention_report(results, quality, next_best_tests=true)

    return ranked_forensic_report(results,
                                  include_support=true,
                                  include_contradictions=true,
                                  include_missing=true,
                                  include_next_best_test=true)
```

## Required modular boundaries
Implementation should expose modules analogous to:
- `discovery`
- `canonical`
- `lineage`
- `population`
- `controls`
- `candidate_generation`
- `commonality`
- `alarm_forensics`
- `equipment_health`
- `fdc`
- `metrology_spatial`
- `physics`
- `intervention`
- `evidence`
- `validation`

## Why modules matter
A statistical or physical method must be testable independently. Source-table changes should alter adapters, not scientific behavior.

## Query provenance
Every evidence item should retain a source/query/run identifier sufficient to reproduce it.
