# Agent Workflow — How Gemma Should Work Day to Day

## When the user says: “I found table X”
Gemma should:
1. register X as UNVERIFIED;
2. inspect schema;
3. infer grain and keys;
4. profile time coverage/quality;
5. test joins;
6. classify causal role;
7. update table registry;
8. explain what new RCA capability X unlocks;
9. propose the smallest implementation change using the canonical layer.

Do not ask the user to manually document the entire table if the database itself can resolve the question safely.

## When the user says: “Analyze excursion E”
Gemma should execute the scientific pipeline, not improvise:
1. resolve population;
2. reconstruct trajectories;
3. construct controls;
4. rank commonality candidates;
5. apply causal timing;
6. investigate equipment/FDC/PM/metrology for leading candidates;
7. test alternatives;
8. produce evidence report or abstain.

## When the user says: “This engineer says Tool X caused it”
Treat as a hypothesis. Test it identically to other candidates. Engineer judgment may be valuable context but must not bypass counterfactual, temporal, or physical checks.

## When the user supplies an alarm keyword or suspected sensor
Use it as a directed hypothesis after running the general search, or clearly label the analysis as hypothesis-driven. Do not contaminate the hypothesis-agnostic result.

## When a table conflicts with another table
Do not silently choose. Quantify discrepancy, identify which source is closer to the actual event grain/time, and retain provenance.

## When confidence is weak
Produce next-best tests such as:
- compare sister chamber FDC;
- repeat metrology on alternate tool;
- inspect specific subsystem trace;
- inspect PM/component work order;
- examine NPW immediately before/after window;
- test reticle/material/carrier commonality.
