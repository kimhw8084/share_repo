# Evidence Fusion, Confidence, Contradictions, and Abstention

## Evidence channels
Maintain independent channels:
1. trajectory/commonality;
2. counterfactual controls;
3. temporal consistency;
4. alarms/equipment-state anomaly;
5. equipment health/PM/degradation;
6. FDC/sensor anomaly;
7. physical-mechanism compatibility;
8. metrology/spatial concordance;
9. intervention/recovery;
10. competing hypotheses / contradictions;
11. data-quality confidence.

## Evidence polarity
Each evidence item is SUPPORT, CONTRADICTION, NEUTRAL, or MISSING.

## Important contradictions
Examples:
- many good controls share same candidate exposure during same period;
- candidate abnormality occurs after affected wafer processing;
- candidate FDC is normal while a competing tool is abnormal;
- physical mechanism is incompatible with observed wafer signature;
- defect persists unchanged after the alleged corrective intervention;
- alternate reticle/material/facility commonality is stronger;
- metrology repeat on another tool does not reproduce the excursion;
- join/timestamp quality is too poor to establish sequence.

Contradictions must be surfaced, never hidden by an aggregate score.

## Initial confidence classes
### C0 — No meaningful evidence
No coherent candidate.

### C1 — Statistical candidate
Interesting rarity/commonality but weak counterfactual or physical evidence.

### C2 — Strong association
Clear bad-vs-good enrichment with causal timing, but limited independent equipment/physical confirmation.

### C3 — Association + process/equipment anomaly
Candidate commonality is strong and independent equipment-state/alarm/FDC evidence aligns.

### C4 — Independent physical confirmation
C3 plus wafer/metrology signature and mechanism compatibility or equivalent independent physical corroboration.

### C5 — Confirmed-like forensic chain
C4 plus strong intervention/recovery evidence or another exceptionally strong independent confirmation chain.

These are evidence classes, not probabilities.

## Probability calibration later
After sufficient historical blind replay, fit a calibrated model using the evidence vector. Candidate options include regularized logistic regression or gradient boosting with calibration. Preserve monotonic/scientific sanity checks where appropriate.

## High-confidence gating
Do not permit C4/C5 from a single evidence channel.

## Abstention triggers
Return INSUFFICIENT_EVIDENCE when:
- affected population is ambiguous;
- controls lack outcome opportunity;
- key trajectory coverage is poor;
- chamber/process identity is unresolved for a material fraction of affected wafers;
- causal timestamps are unreliable;
- leading candidates are statistically indistinguishable;
- physical evidence contradicts the leading candidate;
- measurement-system artifact remains equally plausible.

## Result template
Candidate: <entity hierarchy>
Confidence: C0-C5
Supporting evidence: ...
Contradictions: ...
Missing evidence: ...
Data-quality caveats: ...
Physical interpretation: ...
Competing candidate: ...
Next-best test: ...
