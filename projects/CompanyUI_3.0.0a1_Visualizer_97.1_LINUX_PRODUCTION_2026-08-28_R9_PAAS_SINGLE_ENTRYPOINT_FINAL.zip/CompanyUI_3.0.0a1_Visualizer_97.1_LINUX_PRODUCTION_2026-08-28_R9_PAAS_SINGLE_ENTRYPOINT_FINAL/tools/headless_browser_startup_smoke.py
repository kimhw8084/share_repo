#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return int(sock.getsockname()[1])


def find_browser() -> str | None:
    configured = os.getenv('COMPANY_UI_BROWSER')
    if configured and Path(configured).is_file():
        return configured
    for command in ('google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser', 'microsoft-edge', 'microsoft-edge-stable', 'msedge'):
        found = shutil.which(command)
        if found:
            return found
    for candidate in (
        '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
        '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
        '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser',
        '/usr/bin/microsoft-edge', '/usr/bin/microsoft-edge-stable',
    ):
        if Path(candidate).is_file():
            return candidate
    return None


def wait_http(url: str, process: subprocess.Popen, timeout: float = 25.0) -> None:
    deadline = time.monotonic() + timeout
    last = None
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise AssertionError(f'server exited early with code {process.returncode}')
        try:
            with urllib.request.urlopen(url, timeout=2) as response:
                if response.status == 200:
                    return
                last = response.status
        except Exception as exc:
            last = repr(exc)
        time.sleep(.15)
    raise AssertionError(f'server did not become healthy: {last!r}')


def main() -> int:
    parser = argparse.ArgumentParser(description='Browser-level retained editor boot smoke without Playwright.')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--require-browser', action='store_true')
    args = parser.parse_args()
    result = {'pass': False, 'skipped': False}
    browser = find_browser()
    if not browser:
        if args.require_browser:
            result['error'] = 'Chrome/Chromium/Edge browser not found'
            code = 1
        else:
            result.update({'pass': True, 'skipped': True, 'reason': 'browser not installed; HTTP installed-wheel smoke still runs separately'})
            code = 0
        text = json.dumps(result, indent=2, sort_keys=True)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(text+'\n', encoding='utf-8')
        print(text); return code

    package_root = Path(__file__).resolve().parents[1]
    entry = package_root / 'app.py'
    if not entry.is_file():
        raise SystemExit(f'canonical PaaS entrypoint missing: {entry}')

    port = free_port(); result.update({'browser': browser, 'port': port, 'entrypoint': 'app.py'})
    with tempfile.TemporaryDirectory(prefix='cui-viz-browser-') as td:
        work = Path(td); log_path = work/'server.log'; profile = work/'chrome-profile'; data = work/'reports'
        env = os.environ.copy(); env.update({'PYTHONUNBUFFERED':'1','COMPANY_UI_VISUALIZER_DATA_DIR':str(data)})
        with log_path.open('w', encoding='utf-8') as log:
            server = subprocess.Popen([sys.executable,str(entry),'--host','127.0.0.1','--port',str(port),'--data-dir',str(data)], stdout=log, stderr=subprocess.STDOUT, env=env)
        try:
            url=f'http://127.0.0.1:{port}/visualizer?qa=1'
            wait_http(url, server)
            command=[browser,'--headless=new','--disable-gpu','--disable-dev-shm-usage','--no-first-run','--no-default-browser-check',f'--user-data-dir={profile}','--virtual-time-budget=7000','--dump-dom',url]
            if hasattr(os, 'geteuid') and os.geteuid() == 0:
                command.insert(1, '--no-sandbox')
            proc=subprocess.run(command, capture_output=True, text=True, timeout=40)
            dom=proc.stdout
            if proc.returncode != 0:
                raise AssertionError(f'headless browser exited {proc.returncode}: {proc.stderr[-3000:]}')
            if 'id="visualizer-editor-root"' not in dom or 'cui-visualizer-root' not in dom:
                raise AssertionError('retained Visualizer editor root missing from rendered DOM')
            if '248 of 248 elements' not in dom:
                raise AssertionError('Visualizer runtime did not render the complete 248-element library')
            if 'data-qa="pass"' not in dom:
                raise AssertionError('Visualizer retained-editor self-test did not reach data-qa="pass"')
            if '"final":true' not in dom.replace('&quot;', '"') and '&quot;final&quot;:true' not in dom:
                raise AssertionError('Visualizer QA payload did not report final=true')
            time.sleep(.3)
            log_text=log_path.read_text(encoding='utf-8',errors='replace')
            forbidden=('Traceback (most recent call last)','500 Internal Server Error','AttributeError:','TypeError:','KeyError:','ExceptionGroup:')
            hits=[token for token in forbidden if token in log_text]
            if hits:
                raise AssertionError(f'Python runtime errors during browser boot: {hits}')
            result.update({'pass':True,'skipped':False,'checks':{'editor_root':True,'library_248_248':True,'retained_editor_qa':True,'server_log_clean':True},'browser_stderr_tail':proc.stderr[-1200:]})
        except Exception as exc:
            result['error']=f'{type(exc).__name__}: {exc}'
        finally:
            server.terminate()
            try: server.wait(timeout=8)
            except subprocess.TimeoutExpired: server.kill(); server.wait(timeout=5)
            result['server_log_tail']=log_path.read_text(encoding='utf-8',errors='replace')[-5000:] if log_path.exists() else ''
    text=json.dumps(result,indent=2,sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True); args.output.write_text(text+'\n',encoding='utf-8')
    print(text); return 0 if result.get('pass') else 1

if __name__=='__main__':
    raise SystemExit(main())
