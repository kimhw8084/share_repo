# Company UI 3.0.0a1 + Visualizer 97.1 — R9 PaaS single-entrypoint production final

R9 supersedes R1-R8. Do not reuse an older revision's `.venv` or extracted directory.

This package contains the Company UI v3 host plus the Visualizer 97.1 production editor at `/visualizer`, with the frozen 248-element / 17-engine Visualizer authority preserved.

## Production runtime

- Python `>=3.11,<3.14`
- NiceGUI **exactly `3.15.0`**
- `python-pptx==1.0.2`
- one process / one port
- local browser assets / no CDN
- no runtime Node dependency
- package-root `requirements.txt` is the authoritative production dependency file

## Clean work-PC install

Extract R9 into a new directory and run:

```bash
chmod +x *.sh
./setup_linux.sh
```

`setup_linux.sh` is fail-closed. Before it prints `Setup complete`, it verifies package SHA-256 integrity, installs the root requirements, installs the supplied wheel, runs `pip check`, validates NiceGUI 3.15 APIs, verifies frozen Visualizer authority, recursively verifies the complete Visualizer browser asset graph, starts the installed application and the root `app.py` publish entrypoint on temporary ports, requires `/visualizer` HTTP 200, validates the full static dependency graph over HTTP, rejects server tracebacks/500s, and—when Chrome/Chromium/Edge is present—requires the retained editor to reach its 248/248 QA-ready state.

Then run:

```bash
./run_visualizer.sh
```

Open:

```text
http://127.0.0.1:8080/visualizer
```

For the complete target certification estate:

```bash
./test_linux.sh
```

That additionally runs the full source regression/governance estate, strict browser behavior matrix, Company UI runtime certification, frozen Visualizer authority suite from a temporary copy, and live NiceGUI desktop/tablet/phone certification. Evidence is written to `evidence_local/`.

## Company NiceGUI publish

**Main Python file:**

```text
app.py
```

**Requirements file:**

```text
requirements.txt
```

Recommended production variables:

```bash
export COMPANY_UI_ENVIRONMENT=prod
export COMPANY_UI_STORAGE_SECRET='set-this-in-the-platform-secret-store'
export COMPANY_UI_VISUALIZER_DATA_DIR=/approved/persistent/company-ui/visualizer/reports
```

Production mode fails closed without `COMPANY_UI_STORAGE_SECRET`. Common hosting `HOST` and `PORT` environment variables are supported.

## Browser/network expectations

`304 Not Modified` for NiceGUI's own static files such as Socket.IO, framework JS, fonts, or CSS is normal cache validation. It is not an application error.

Visualizer `.mjs`/JSON runtime dependencies must never return 404. R9 retains the certified static-namespace fix and and certifies these paths, including:

```text
/_cui_visualizer/assets/integrated_editor.mjs
/_cui_visualizer/vendor/production_core/core/editor_store.mjs
/_cui_visualizer/vendor/production_core/core/runtime_registry.mjs
/_cui_visualizer/vendor/production_core/core/universal_renderer.mjs
/_cui_visualizer/vendor/production_core/contracts/component_contracts.json
```

## R9 certified behavior

- report title displays `Untitled report` for new/legacy untitled reports;
- technical 248/17 copy is removed from the page header;
- Company UI mobile navigation menu opens/closes browser-side;
- all nine quick-add controls mutate the report;
- Undo / Redo;
- Smart / Guided / Free modes;
- Group / Ungroup / Lock / layer ordering;
- Auto Layout;
- Command Palette;
- Preflight;
- Preview enter/exit;
- Inspector close/reopen with reclaimed workspace width;
- balanced canvas margins with inspector open and closed;
- Zoom / Fit / Mini-map;
- library search, all 17 engine filters, Show More;
- Save and PowerPoint semantic requests;
- retained editor rebind after host-root replacement;
- pointer movement remains browser-local;
- tablet and phone shell/work areas remain inside the Visualizer host;
- zero Chromium console/page errors in the final standalone behavior matrix.

## PowerPoint

Upload the user's existing `.pptx` through **Import / PowerPoint template**, then export from the Visualizer toolbar. The integration validates the PPTX archive, selects the governed target region, preserves surrounding template content, emits editable/native PowerPoint objects where practical, preserves numeric zero vs missing data, never invents sequence-only timeline dates, and never rasterizes the whole report as a shortcut.

## Persistence

Default local report storage:

```text
~/.company_ui/visualizer/reports
```

Override with `COMPANY_UI_VISUALIZER_DATA_DIR` or `--data-dir`. Writes are deterministic and atomic; server-bound report mutations are revision-aware; drag/resize/hover/pointer/virtual-scroll frame traffic remains browser-side.

## Final source/package certification

- **711/711 tests passing**
- governance **0 errors / 0 warnings**
- Company UI visual coverage **183/183**
- Visualizer **248/248 elements**
- Visualizer **17/17 engines**
- frozen vendor **123/123 files** verified
- Visualizer frozen authority evidence **27/27 gates** (authority bytes unchanged)
- Golden Connector v5 SHA-256 `d8ebd4378f01b7c52a7a4be57c578c22adf29b899cc08a370cf084881195343e`
- recursive Visualizer browser dependency graph complete
- final Chromium editor behavior matrix PASS
- audited source ↔ shipped wheel byte parity PASS

See `PRODUCTION_SIGNOFF.md`, `R8_VISUALIZER_UX_ASSET_CERTIFICATION.md`, `PUBLISH_NICEGUI.md`, and `evidence/CERTIFICATION_SUMMARY.json`.
