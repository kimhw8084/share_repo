# R9 production signoff

R9 supersedes R1-R8 for deployment.

## Release status

The previous work-PC failures were integration-runtime defects, not user-environment debugging tasks. R9 closes the full class of failures exposed by those runs: Python 3.11 generic compatibility, NiceGUI 3.15 static API compatibility, governed icons, generic Element misuse, retained DOM rebind, secure-context browser dependencies, scoped preview state, tablet min-content expansion, inspector/workspace reflow, host mobile navigation, and the Visualizer static module namespace mismatch that caused `.mjs` 404s.

## Final engineering gates

- 711/711 Company UI + Visualizer integration tests passing.
- Company UI governance: 0 errors / 0 warnings.
- Strict NiceGUI-3.15-shaped complete `/visualizer` page construction and post-render callback contract passes.
- Chromium editor behavior matrix passes all control/history/selection/layout/preview/inspector/zoom/library/semantic/rebind/responsive checks with zero console/page errors.
- Tablet and phone internal shell/work geometry is asserted inside the Visualizer host, not merely hidden by document overflow.
- Recursive retained-browser module/fetch graph has no missing or escaped targets.
- Live startup certification requires every graph URL to return HTTP 200 with correct module/JSON MIME types.
- Live Playwright integration certification rejects any same-origin 4xx/5xx response.
- Frozen Visualizer authority: 123/123 files match the authority manifest; prior 27/27 authority evidence remains applicable because those bytes are unchanged.
- 248/248 elements and 17/17 engines preserved.
- Golden Connector Engine v5 SHA-256 remains `d8ebd4378f01b7c52a7a4be57c578c22adf29b899cc08a370cf084881195343e`.
- Installable wheel is byte-compared to audited Company UI Python source and all Visualizer package data.
- Root `requirements.txt` remains the production dependency authority.
- Root `app.py` remains the single-file NiceGUI publisher entrypoint.
- Production storage secret fails closed; no predictable production fallback is shipped.
- No external runtime CDN/browser URL, runtime Node dependency, `crypto.randomUUID`, or `crypto.subtle` dependency remains in the integrated runtime path.

## Environment-specific live gate

This build sandbox cannot resolve the Python package index, so it cannot install NiceGUI 3.15.0 into a fresh local venv. That limitation is recorded rather than hidden. The delivery package compensates by making the target setup fail closed: `setup_linux.sh` cannot report success unless the exact installed NiceGUI runtime starts canonical `app.py` (and separately cross-checks the wheel console launcher), renders `/visualizer`, serves the complete dependency graph, and produces clean server logs. `test_linux.sh` adds the full browser interaction and live integration estate.

HTTP 304 responses from NiceGUI's own cacheable assets are expected successful cache validation. Visualizer runtime 404s are hard failures and are now explicitly certified against.


## Canonical PaaS execution contract

The package root contains exactly one Python file: `app.py`. Company NiceGUI PaaS publication must install root `requirements.txt` and execute:

```bash
python app.py
```

Local `run_visualizer.sh` and live/browser certification now execute the same `app.py` path. The wheel console entrypoint remains only as a packaging cross-check.
