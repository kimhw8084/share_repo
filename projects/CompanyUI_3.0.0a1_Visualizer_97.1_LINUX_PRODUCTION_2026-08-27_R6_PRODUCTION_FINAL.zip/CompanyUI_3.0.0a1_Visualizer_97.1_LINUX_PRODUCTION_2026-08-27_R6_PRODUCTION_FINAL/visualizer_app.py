#!/usr/bin/env python3
"""Company publisher entrypoint for Company UI + Visualizer 97.1.

The publishing service only needs this file as the Python entrypoint plus the
package-root requirements.txt. The complete audited application source remains in
source/ and is inserted ahead of any globally installed Company UI package.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
if not (SOURCE / 'company_ui' / '__init__.py').is_file():
    raise SystemExit(f'Bundled Company UI source is missing: {SOURCE}')
sys.path.insert(0, str(SOURCE))

from company_ui.products.visualizer.cli import main

if __name__ == '__main__':
    main()
