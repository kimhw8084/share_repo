# R4 navigation/runtime hotfix

## User-target failure reproduced

The NiceGUI 3.15.0 server and static assets started successfully, but the first `/visualizer` render failed because the Visualizer integration registered `icon='chart'`. Company UI intentionally renders only icons from its governed `ICON_REGISTRY`; `chart` is not a valid key. The existing governed key `chart-line` is the correct product-navigation asset.

The same run also showed the standalone product root `/` returning 404. That did not cause the Visualizer 500, but it is undesirable for a dedicated publish target.

## Corrections

- Visualizer navigation now uses governed canonical `chart-line`; no registry weakening and no new ungoverned asset.
- Product control icon `plus` was normalized to canonical governed key `add`; the package no longer depends on icon aliases.
- Dedicated `company-ui-visualizer` host redirects `/` to canonical `/visualizer` with HTTP 307. The inherited Company UI 22-route baseline is unchanged.
- Source regression resolves every Visualizer navigation icon through Company UI `get_icon`.
- `setup_linux.sh` validates installed-wheel navigation icons after installation.
- `verify_package.py` rejects wheels containing the invalid `chart` key and requires the root redirect.
- Live browser certification now checks the bare root resolves through the redirect as well as `/visualizer`.

## Preserved authorities

Visualizer 97.1 vendor bytes and Golden Connector Engine v5 are unchanged. Company UI global icon governance remains strict.
