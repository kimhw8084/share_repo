# Zero-Regression Gates

Integration is allowed to add capability. It is not allowed to lower either baseline's validated floor.

## Company UI gates

- Preserve source test pass state.
- Governance must remain 0 errors / 0 warnings unless a newly introduced warning is explicitly governed and resolved before release.
- Preserve inherited v2 renderer/anatomy unless a specific tested migration is intentionally approved.
- Preserve 183/183 visual component coverage.
- Preserve browser-native UI/UX constitution behavior.
- Preserve route/shell/navigation/theme/drawer/dialog/focus behavior.
- Target-runtime gates must be completed on supported environment: exact NiceGUI 3.15.0, 22-route live smoke, Chrome/Edge, human baseline.

## Visualizer gates

- 248/248 runtime entries and contracts.
- 17/17 canonical engines.
- Evidence-backed integrated Visualizer score must remain **>=95/100**; 97.1 is the current reference.
- 12,500+ deterministic property/fuzz cases.
- 200-component retained editor p95 <=16.7 ms; target <=10 ms when measured comparably.
- No high-frequency pointer/scroll/routing traffic through Python.
- Deterministic/revision-safe canonical state and exact undo/redo.
- Missing != zero.
- Sequence-only timeline may not invent dates.
- Golden Connector v5 frozen hash unchanged unless separately versioned.
- No unsafe SVG/script import.
- No whole-report PPT rasterization.
- Offline/local runtime.

## Integration-specific gates

- No competing canonical report states.
- No global CSS leakage.
- No route-level regressions outside `/visualizer`.
- Semantic bridge rejects stale/out-of-order commits safely.
- Reconnect does not lose or duplicate committed report changes.
- Save/open round-trip is deterministic.
- DataSession binding preserves identity/provenance/types.
- 248 library entries reachable from the real editor.
- Integrated mobile/tablet/desktop views remain contained and usable.
- PPT export preserves input template objects outside the target content region.
- One process / one port.
- Zero browser-console errors and zero unhandled Python exceptions in release runs.
