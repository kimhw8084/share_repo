# Integrated Application Acceptance Criteria

The integrated product is approval-ready only when the following are true together.

## Product readiness

- Company UI is visibly and behaviorally still Company UI.
- Visualizer feels like a native high-end workspace inside Company UI rather than an iframe/prototype bolted on top.
- All 248 Visualizer elements are reachable through the real product library/editor.
- Real save/load/data-binding/export workflows are present.

## Quality threshold

- Visualizer integrated score: **>=95 / 100**, using evidence comparable to the existing 97.1 audit.
- No Company UI inherited gate regression.
- No known P0/P1 defect under internal control.

## Performance

- Browser-side editor interaction retains a 16.7 ms p95 hard budget for comparable pointer-frame workloads; preferred <=10 ms.
- 100k data grid remains virtualized and bounded in DOM growth.
- Full diagram reroute may use a separate operation budget; it must remain deterministic and violation-free.
- Server/NiceGUI semantic commit latency may not stall browser interaction.

## Data correctness

- typed data semantics preserved end-to-end;
- missing != zero;
- stable identity/provenance retained;
- semantic eligibility prevents invalid visual/statistical claims;
- date/time and unit assumptions are validated rather than invented;
- persistence round trips are deterministic.

## PPT

- input work template remains intact outside selected/detected content region;
- editable objects preserved wherever practical;
- no full-report screenshot fallback;
- content reflows/splits rather than violating readability floors;
- output opens successfully after generation.

## Deployment

- supported target setup is repeatable;
- exact dependency/runtime checks are automated;
- one process / one port;
- local/offline assets;
- diagnostics identify runtime/bridge/export failures clearly;
- final package includes source, setup, tests, evidence, checksums and continuation context.
