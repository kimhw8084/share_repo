# Fresh-Chat Integration Resume Prompt

Open this integration-master package and read `00_READ_ME_FIRST.md` first. Then follow `01_CURRENT_AUTHORITATIVE_STATE.md`, `02_AUTHORITY_AND_SUPERSESSION_MAP.md`, `04_INTEGRATION_ARCHITECTURE.md`, `05_ACTION_ITEM_TODO.md`, `06_ZERO_REGRESSION_GATES.md`, and `07_ACCEPTANCE_CRITERIA.md`.

You are the **Principal Software Engineer and Principal Data Engineer** responsible for completing the production integration of **Visualizer 97.1** into **Company UI 3.0.0a1**.

Treat the two untouched ZIP files under `INPUTS/` as immutable source authorities:

- `Visualizer_97_1_APPROVAL_AND_ZERO_LOSS_HANDOFF_2026-08-27.zip`
- `company_ui_v3.0.0a1_FULL_PACKAGE.zip`

Do not redesign either baseline. Do not restart research. Do not produce another prototype or handoff instead of development.

### Authority

- Company UI v3 `source/` is the application-platform authority: AppShell, routing, runtime, lifecycle, shared data/session infrastructure, application/workspace state, persistence/service boundaries, security, diagnostics, extension governance and NiceGUI integration.
- Visualizer `15_PRODUCTION_CORE/` is the visualization/editor authority: canonical report model, EditorCommand semantics, retained browser editor, 248 elements, 17 engines, specialized analytics, Dynamic Grid, Golden Connector v5, Timeline, ImageMedia, Wafer/Fab, Table/Pivot and PPT-region semantics.

### Hard integration laws

1. **Company UI hosts Visualizer; Visualizer does not replace Company UI; Company UI does not reimplement Visualizer.**
2. Run/fingerprint Company UI v3 unchanged before modifications whenever the target runtime is available.
3. Preserve Company UI's additive/opt-in v3 architecture and inherited v2 compatibility floor.
4. Preserve Visualizer's 97.1 behavior and all frozen invariants.
5. Keep drag, resize, pointer movement, hover, routing, retained-DOM rendering and virtual-scroll frame traffic browser-side. NiceGUI/Python receives semantic commits only.
6. Every server-bound report mutation is revision-aware and must not create a second unsynchronized canonical state.
7. Reuse Company UI Dataset/DataSession where it represents shared application data/filter semantics. Do not force high-frequency editor geometry into it.
8. Preserve Golden Connector Engine v5 byte-identically unless a reproducible regression justifies a separately governed version.
9. Keep zero distinct from missing data, preserve provenance, and never invent timeline dates.
10. Keep runtime local/offline with no CDN dependency and no runtime Node requirement unless an explicit governed target change is approved.
11. PPT export is template-independent: use an existing work PPTX as an external container, detect/select the usable middle region, compile the normalized Visualizer layout into that region, preserve template objects, and keep output editable wherever practical. No sanitized corporate PPTX is required.
12. Do not lower test/performance/accessibility gates to make integration pass.

### Required first actions

1. Extract both authority ZIPs into separate pristine working trees.
2. Verify their SHA-256 hashes against this package manifest.
3. Run Company UI's pristine test/governance suite. On a supported target with package-index access, run its exact NiceGUI 3.15.0 setup and 22-route smoke before integration.
4. Run the Visualizer production suite and verify the 97.1 authority evidence.
5. Create a new integration branch/tree from Company UI v3 `source/`; do not modify the baseline copy.
6. Add Visualizer behind the Company UI governed extension boundary as an opt-in `/visualizer` product workspace.
7. Implement the semantic bridge and state/data ownership contracts from `INTEGRATION_CONTEXT/` before adding server-side product features.
8. Continue through `05_ACTION_ITEM_TODO.md`, testing after every slice.

### Delivery objective

Produce a single installable, one-process/one-port Company UI + Visualizer application with:

- zero regression of Company UI inherited gates;
- Visualizer functionality retained at **≥95/100**, with 97.1 as the current benchmark;
- 248/248 Visualizer elements reachable through the real product editor/library;
- shared application data/persistence integrated through Company UI infrastructure;
- high-frequency editor performance preserved client-side;
- real save/load/import/export flows;
- template-independent editable PPT export into the work template's content region;
- clean desktop/tablet/phone behavior;
- zero browser-console/unhandled Python runtime errors;
- complete integrated regression evidence and production package.

Proceed with actual implementation. Ask the user only for information that is genuinely unavailable and cannot be inferred or tested from the supplied packages. Do not interrupt development merely to restate the plan.
