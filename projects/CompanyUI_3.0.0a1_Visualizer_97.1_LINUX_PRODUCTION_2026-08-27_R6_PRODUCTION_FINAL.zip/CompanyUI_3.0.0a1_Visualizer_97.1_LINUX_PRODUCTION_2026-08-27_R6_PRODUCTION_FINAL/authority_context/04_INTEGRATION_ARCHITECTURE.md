# Integration Architecture

## Target structure

```text
Company UI v3 application
│
├── AppShell / routing / theme / security / services / persistence
│
└── /visualizer  (governed product extension)
    │
    ├── Python/NiceGUI host
    │   ├── route/page composition
    │   ├── semantic bridge
    │   ├── report repository/service
    │   ├── Dataset/DataSession adapters
    │   ├── file import/export service
    │   └── PPT generation/download service
    │
    └── browser Visualizer runtime
        ├── canonical report/editor model
        ├── retained DOM editor
        ├── EditorCommand/revision behavior
        ├── 248-element registry / 17 engines
        ├── chart/statistical engines
        ├── table/pivot/virtual grid
        ├── diagram + Golden Connector v5
        ├── timeline / image / wafer-fab engines
        └── Dynamic Grid / PPT normalized layout semantics
```

## Key rule: one canonical report domain

Do not create competing report models in Python and JavaScript.

The browser Visualizer model remains the authoritative high-frequency editing model. Semantic committed snapshots/patches are synchronized to Company UI services using revisioned messages. Server persistence stores deterministic canonical report state and validates schema/revision boundaries.

Company UI runtime state may own application concerns such as selected report ID, route state, permissions, active dataset/session IDs, save status, notifications and server task state. It must not become a per-pointer mirror of Visualizer geometry.

## Semantic bridge

Allowed browser → Python examples:

- `report.opened`
- `report.commit`
- `report.save_requested`
- `report.save_as_requested`
- `dataset.bind_requested`
- `asset.import_requested`
- `ppt.export_requested`
- `diagnostic.event`

A `report.commit` must include at least:

- report ID
- schema version
- `base_revision`
- new revision or deterministic commit ID
- semantic command/patch payload
- state fingerprint
- optional provenance metadata

Forbidden high-frequency bridge traffic:

- pointermove
- drag frame coordinates
- hover frames
- connector reroute frames
- brush-frame movement
- virtual-scroll row frames
- DOM geometry reads

## Data architecture

Use Company UI `Dataset` / `DataSession` for shared application datasets, semantic filters and cross-component application filtering when appropriate.

Use Visualizer engine adapters to transform DataSession results into the typed data contracts expected by the 248 elements.

Data adapter responsibilities:

- type preservation;
- stable row/entity identity;
- provenance/source identity;
- missing vs numeric zero;
- date/time validity;
- unit/domain metadata;
- semantic eligibility/preflight;
- deterministic ordering where order is meaningful;
- bounded materialization for large datasets.

## Workspace architecture

Company UI owns the outer application workspace and responsive shell.

Visualizer owns report-canvas geometry inside its workspace panel. Do not replace Visualizer's report Dynamic Grid with Company UI's application panel grid. They operate at different levels:

- Company UI workspace = application panel placement.
- Visualizer Dynamic Grid = report/slide content composition.

## Styling

- Company UI remains owner of global shell tokens/anatomy.
- Visualizer styles are scoped to the Visualizer root.
- Map compatible Company UI theme tokens into Visualizer semantic tokens.
- No global reset or selector leakage from Visualizer.
- Keep Visualizer's governed readability/target floors.

## Export architecture

At export time:

1. accept existing work PPTX;
2. choose source slide/layout;
3. resolve target region in order: named placeholder → explicit user rectangle → compatible content placeholder → largest safe middle region;
4. map normalized Visualizer Dynamic Grid geometry into PPT coordinates;
5. emit editable native objects where practical;
6. preserve template objects outside the target region;
7. create additional template-derived slides when content cannot fit without violating minimum readability;
8. fail preflight rather than silently rasterize an entire report.
