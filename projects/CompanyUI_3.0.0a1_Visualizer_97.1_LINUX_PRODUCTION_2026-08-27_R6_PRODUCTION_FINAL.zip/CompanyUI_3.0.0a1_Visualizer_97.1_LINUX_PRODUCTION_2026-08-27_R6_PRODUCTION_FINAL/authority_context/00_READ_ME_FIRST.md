# Visualizer + Company UI v3 — Integration Master Read Me First

This package is the authoritative zero-loss starting point for the **actual integration development phase** between:

- **Visualizer 97.1 production core** — internally certified at **97.1 / 100**, with 248/248 named elements, 17/17 engines, 27/27 release commands passing, and 12,500 deterministic property/fuzz cases.
- **Company UI 3.0.0a1 application platform** — assessed for this integration at **98 / 100 readiness/effectiveness**. Its package freezes 672/672 automated tests passing, governance 0 errors / 0 warnings, 183/183 visual component mapping, and 43/43 browser-native UI/UX constitution checks. Exact installed NiceGUI 3.15.0 target-runtime/browser certification remains a target-machine gate.

## Mission

Build the production Visualizer application **inside Company UI v3** without redesigning either authoritative baseline and without regressing either project's validated behavior.

The goal is not another prototype, audit, research phase, or handoff package. The goal is a working integrated application.

## Role

The implementing agent must operate as both:

1. **Principal Software Engineer** — architecture, runtime ownership, frontend/browser performance, NiceGUI integration, persistence, security, testing, packaging, zero-regression delivery.
2. **Principal Data Engineer** — canonical data models, DataSession integration, typed schemas, semantic eligibility, provenance, missing-vs-zero correctness, statistical/data transformations, scalable data access, deterministic serialization, export/data lineage.

These are not advisory titles. Use principal-level engineering judgment, validate assumptions in source/runtime evidence, and prefer durable architecture over expedient duplication.

## Read order

1. `00_READ_ME_FIRST.md`
2. `01_CURRENT_AUTHORITATIVE_STATE.md`
3. `02_AUTHORITY_AND_SUPERSESSION_MAP.md`
4. `03_INTEGRATION_RESUME_PROMPT.md`
5. `04_INTEGRATION_ARCHITECTURE.md`
6. `05_ACTION_ITEM_TODO.md`
7. `06_ZERO_REGRESSION_GATES.md`
8. `07_ACCEPTANCE_CRITERIA.md`
9. `INTEGRATION_CONTEXT/state_ownership_contract.json`
10. `INTEGRATION_CONTEXT/bridge_contract.json`
11. `INTEGRATION_CONTEXT/data_integration_contract.json`
12. `INTEGRATION_CONTEXT/ppt_middle_region_contract.json`
13. `INTEGRATION_CONTEXT/performance_budgets.json`
14. Open the two untouched authority ZIPs in `INPUTS/` and follow the source-specific read orders when implementation touches that side.

## Two immutable baseline inputs

`INPUTS/Visualizer_97_1_APPROVAL_AND_ZERO_LOSS_HANDOFF_2026-08-27.zip`

`INPUTS/company_ui_v3.0.0a1_FULL_PACKAGE.zip`

They are preserved byte-for-byte from the supplied authoritative files. Do not rewrite these ZIPs. Extract working copies for development.

## Non-negotiable integration law

**Company UI hosts Visualizer. Visualizer does not replace Company UI. Company UI does not reimplement Visualizer.**

- Company UI owns the application platform, shell, route lifecycle, services, security, persistence infrastructure, extension governance, application/workspace state and shared data services.
- Visualizer owns the report/editor domain, canonical report model, 248-element visualization runtime, browser-side retained editor, specialized engines, dynamic report grid and export semantics.
- High-frequency browser interaction stays browser-side. NiceGUI/Python receives semantic commits, never pointer-frame traffic.
- Reuse Company UI v3 runtime/data/workspace/extension capabilities instead of building parallel generic infrastructure.
- Preserve Golden Connector Engine v5 byte-identically unless a reproducible regression justifies a separately governed successor.

## Current external constraints

- The Company UI v3 package is a **source-complete alpha**. Exact installed NiceGUI 3.15.0, 22-route live server smoke, supported Chrome/Edge matrix and human visual-baseline approval must be run on the supported target environment before stable Company UI 3.0.0 promotion.
- A sanitized/confidential corporate PPTX is **not required**. The export architecture is template-independent and targets a selected/detected middle content region of an existing work PPTX at runtime.

## First development action

Before integrating Visualizer, extract Company UI v3 into a working directory and run its pristine setup/runtime/certification path unchanged wherever target dependencies are available. Fingerprint the pristine baseline. Then add Visualizer through the governed extension boundary.
