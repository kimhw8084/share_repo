# Authority and Supersession Map

## Highest authority for the integrated project

This integration-master package controls only **integration decisions and authority routing**. It does not replace the source authority inside either baseline ZIP.

## Company UI side

Authoritative implementation: `INPUTS/company_ui_v3.0.0a1_FULL_PACKAGE.zip -> source/`

Use Company UI v3 for:

- AppShell and global application anatomy
- routing/navigation
- NiceGUI runtime ownership
- typed application/workspace state
- atomic application transactions
- shared Dataset/DataSession infrastructure
- adaptive application workspace
- persistence/service/repository boundaries
- lifecycle/async task ownership
- security middleware
- application diagnostics/performance ownership
- extension registration
- application-level accessibility/theme/design constitution
- generic tables/forms/controls/overlays
- setup/runtime/certification machinery

Do **not** replace the v2-compatible renderer or migrate unrelated routes just to use v3 architecture.

## Visualizer side

Authoritative implementation: `INPUTS/Visualizer_97_1_APPROVAL_AND_ZERO_LOSS_HANDOFF_2026-08-27.zip -> 15_PRODUCTION_CORE/`

Use Visualizer for:

- canonical report/editor model
- EditorCommand semantics and revision-safe report mutations
- retained browser-side editor DOM
- pointer/drag/resize/selection geometry
- 248-element runtime registry and contracts
- 17 specialized engines
- CoreChart and EngineeringChart statistical behavior
- Table/Pivot and 100k virtualization behavior
- Diagram semantics and Golden Connector v5
- Timeline truth/date/dependency semantics
- ImageMedia geometry/security semantics
- Wafer/Fab registration and missing-vs-zero semantics
- Smart report layout / dynamic report grid
- normalized report-to-PPT content-region compilation
- Visualizer-specific preflight/export eligibility

## Superseded Visualizer instructions

The following remain historical only and must not become the active development plan:

- original ~77-point deep-audit continuation order;
- Waves 01–11 as a current production source;
- any requirement for a sanitized confidential corporate PPTX;
- any instruction that treats Wave 11 as the complete implementation base;
- any pre-97.1 score or intermediate gate report as current release authority.

## Superseded Company UI instructions

- Do not treat older v1/v2 phase docs as permission to replace the v3 source baseline.
- Do not globally migrate existing routes.
- Do not create a parallel chart/design framework beside Company UI and Visualizer.

## Conflict resolution

If an integration decision conflicts with source-specific rules:

1. preserve the source-specific invariant;
2. isolate the integration behind a documented adapter/extension;
3. add a regression test proving both sides remain valid;
4. never silently weaken either baseline's gate to make integration easier.
