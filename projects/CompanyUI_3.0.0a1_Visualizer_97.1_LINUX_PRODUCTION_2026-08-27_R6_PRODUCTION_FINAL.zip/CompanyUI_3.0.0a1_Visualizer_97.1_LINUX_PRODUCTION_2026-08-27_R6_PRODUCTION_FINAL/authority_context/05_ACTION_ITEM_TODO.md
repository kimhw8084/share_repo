# Integration Action Item TODO

## Phase 0 — Baseline and target-runtime certification

- [ ] Extract both immutable input packages to pristine baseline directories.
- [ ] Verify package hashes.
- [ ] Run Company UI source tests/governance unchanged.
- [ ] Run Visualizer 27-command release suite unchanged.
- [ ] On supported company macOS/Linux target, execute Company UI `setup.sh` with exact NiceGUI 3.15.0.
- [ ] Verify 22-route live smoke.
- [ ] Run supported Chrome/Edge matrix.
- [ ] Capture baseline screenshots/logs/runtime diagnostics.
- [ ] Fingerprint frozen baseline files before integration.

## Phase 1 — Governed Visualizer extension seam

- [ ] Create opt-in Visualizer extension/module under Company UI v3.
- [ ] Add `/visualizer` route without globally migrating existing pages.
- [ ] Register route/panel/commands through Company UI extension mechanisms.
- [ ] Scope Visualizer assets/CSS/JS under a Visualizer namespace/root.
- [ ] Ensure no CDN/runtime-Node dependency is introduced.
- [ ] Keep one process / one port.
- [ ] Add a baseline zero-regression test proving unrelated Company UI routes are unchanged.

## Phase 2 — Browser/Python semantic bridge

- [ ] Define versioned message schemas.
- [ ] Implement bootstrap of canonical Visualizer report state.
- [ ] Implement revisioned semantic `report.commit` path.
- [ ] Reject stale `base_revision` commits.
- [ ] Implement reconnect/recovery behavior.
- [ ] Preserve exact undo/redo across synchronization.
- [ ] Prevent server round trips from entering pointer/drag/hover/routing/virtual-scroll frame paths.
- [ ] Add out-of-order, duplicate and reconnect fuzz tests.

## Phase 3 — State ownership and persistence

- [ ] Resolve report IDs and application state through Company UI runtime.
- [ ] Add report repository/service abstraction.
- [ ] Implement create/open/save/save-as/duplicate/delete/archive as product needs require.
- [ ] Store deterministic canonical report JSON with schema version/revision/fingerprint.
- [ ] Add version migration hooks.
- [ ] Add corruption/fail-closed handling.
- [ ] Retain optional local recovery only as a subordinate recovery mechanism, not primary persistence.

## Phase 4 — Shared data and DataSession integration

- [ ] Define application dataset catalog/source adapters.
- [ ] Bind Visualizer components to Company UI Dataset/DataSession IDs.
- [ ] Preserve stable row/entity identity.
- [ ] Preserve provenance and units.
- [ ] Preserve missing vs zero.
- [ ] Enforce semantic eligibility before renderer invocation.
- [ ] Implement deterministic adapter transforms for charts/tables/engineering/wafer/timeline inputs.
- [ ] Add large-data materialization and paging policies.
- [ ] Verify shared filter/cross-filter behavior where semantically appropriate.

## Phase 5 — Product editor library: 248/248

- [ ] Use the Visualizer runtime registry as the source of truth for the real Add/Insert library.
- [ ] Organize 248 elements into usable categories/search rather than a flat wall.
- [ ] Add component search/filter/recent/favorites if helpful.
- [ ] Drive default insertion geometry and data eligibility from contracts.
- [ ] Drive inspector/property exposure from contracts.
- [ ] Preserve same renderer across gallery/library/canvas.
- [ ] Verify all 248 are reachable, configurable and serializable in the integrated editor.

## Phase 6 — Integrated responsive workspace/UI

- [ ] Mount Visualizer inside Company UI AppShell without changing shell anatomy.
- [ ] Map themes/tokens.
- [ ] Verify drawers/dialogs/toasts/focus restoration.
- [ ] Verify desktop expanded/compact nav.
- [ ] Verify tablet.
- [ ] Verify 390px phone/reduced-motion behavior.
- [ ] Verify 60/100/140% zoom behavior.
- [ ] Verify no shell/canvas overflow collisions.
- [ ] Preserve 32px desktop / 44px touch targets and readability floors.

## Phase 7 — Integrated data grid/table/pivot

- [ ] Expose the production typed 100k grid in the actual Visualizer workflow.
- [ ] Keep retained DOM virtualization.
- [ ] Add accessible keyboard row/cell navigation.
- [ ] Verify sort/filter semantics and missing-last behavior.
- [ ] Integrate pivot/subtotal/grand-total behaviors with bound DataSessions.
- [ ] Test 100k rows under integrated NiceGUI shell with memory/frame evidence.

## Phase 8 — Specialized engine integration

- [ ] CoreChart 29/29.
- [ ] EngineeringChart 13/13.
- [ ] Statistics reference suite.
- [ ] Diagram semantics + Golden Connector v5.
- [ ] Timeline no-invented-date behavior.
- [ ] ImageMedia sanitization/geometry.
- [ ] Wafer/Fab registration/provenance/missing-vs-zero.
- [ ] Smart Layout and Dynamic Grid.
- [ ] Preserve all engine-specific preflight rules.

## Phase 9 — PPT production exporter

- [ ] Connect canonical report model to Python PPT service.
- [ ] Accept existing template at runtime.
- [ ] Resolve target content region by governed precedence.
- [ ] Implement the governed strategies for all 225 exportable components.
- [ ] Preserve native charts/tables/text/shapes/connectors/images where practical.
- [ ] Preserve all original template objects outside target region.
- [ ] Reflow/split to additional template-derived slides when needed.
- [ ] Never whole-report rasterize.
- [ ] Round-trip generated PPTX and validate object types/containment.
- [ ] Add NiceGUI export/download workflow.

## Phase 10 — Security and operational productization

- [ ] Reuse Company UI auth/session/access-control mechanisms.
- [ ] Validate uploaded report/PPT/image/SVG inputs.
- [ ] Reuse/extend Visualizer SVG sanitizer.
- [ ] Bound temporary/export file handling.
- [ ] Prevent path traversal and arbitrary HTML/script injection.
- [ ] Add diagnostics for bridge, renderer and export failures.
- [ ] Confirm offline/local assets.

## Phase 11 — Combined zero-regression certification

- [ ] Company UI inherited source tests remain green.
- [ ] Company UI governance remains 0/0.
- [ ] Existing Company UI route/browser evidence remains green.
- [ ] Visualizer 248/248 runtime remains green.
- [ ] Visualizer release score remains >=95; do not inflate score if evidence regresses.
- [ ] 12,500+ property/fuzz cases green.
- [ ] 200-component editor frame budget green.
- [ ] 100k grid integrated performance green.
- [ ] Golden Connector stress green and frozen hash verified.
- [ ] All themes/device sizes/keyboard/reduced-motion gates green.
- [ ] Zero browser console errors.
- [ ] Zero unhandled Python errors.
- [ ] One-process/one-port/offline runtime verified.
- [ ] PPT export/download/open-roundtrip verified.

## Phase 12 — Final delivery

- [ ] Clean install/setup scripts for company target.
- [ ] Dependency pins and doctor checks.
- [ ] Integrated source manifest/SBOM/checksums.
- [ ] Final QA/certification report.
- [ ] Final phone/desktop preview.
- [ ] Full production package and fresh continuation prompt.
