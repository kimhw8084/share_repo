# R6 production signoff

R6 supersedes R1-R5 for deployment.

## Closed runtime defects

The acceptance failures found on Python 3.11 / NiceGUI 3.15 were corrected at their root causes: generic `StateKey[T]` construction, cross-version public API reflection, `add_static_files(..., follow_symlink=...)`, governed navigation icons, and generic NiceGUI `Element.set_text` misuse. The final page-builder contract executes the complete `/visualizer` construction path and post-render callbacks against a strict NiceGUI-3.15-shaped surface.

## Final engineering gates

- 709/709 Company UI + Visualizer integration tests collected and passing.
- Company UI governance: 0 errors / 0 warnings.
- Frozen Visualizer authority: 123/123 files match its manifest.
- Visualizer authority evidence: 27/27 production gates complete.
- 248/248 elements and 17/17 engines preserved.
- Golden Connector Engine v5 SHA-256 remains `d8ebd4378f01b7c52a7a4be57c578c22adf29b899cc08a370cf084881195343e`.
- Retained editor assets are byte-identical to the desktop/tablet/phone browser-certified asset set.
- Installable wheel is byte-compared to the audited source by `tools/verify_package.py`.
- Root `requirements.txt` is the production dependency authority.
- Root `visualizer_app.py` is the single-file NiceGUI publisher entrypoint.
- Package setup verifies SHA-256 integrity before installation, runs `pip check`, inspects the exact installed NiceGUI 3.15.0 API, starts the installed wheel, renders `/visualizer`, repeats the render through the source publish entrypoint, rejects server tracebacks/500s, and performs a headless Chromium/Chrome/Edge retained-editor boot when a supported browser is present.
- PPTX uploads are bounded and ZIP-structure checked before python-pptx parsing; export remains editable and template-preserving and never whole-report rasterizes.
- Production mode requires an explicit persistent `COMPANY_UI_STORAGE_SECRET`; no predictable fallback is shipped.

## Target-runtime rule

`setup_linux.sh` is intentionally fail-closed. It cannot print `Setup complete` unless the target machine's installed runtime actually renders the production application through both supported entry paths with a clean server log. This converts environment compatibility from a user debugging exercise into an automated deployment gate.
