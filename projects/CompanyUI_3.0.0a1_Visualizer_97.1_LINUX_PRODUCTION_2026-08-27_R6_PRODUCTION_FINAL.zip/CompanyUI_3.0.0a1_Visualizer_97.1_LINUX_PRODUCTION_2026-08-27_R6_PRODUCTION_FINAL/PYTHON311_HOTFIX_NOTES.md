# Python 3.11 acceptance hotfix

The first external acceptance run exposed two CPython-version compatibility issues before the Visualizer page could launch.

1. `StateKey[T]` used `@dataclass(frozen=True, slots=True)`. CPython 3.11 `typing` assigns `__orig_class__` for parameterized generic instances, and the generated frozen/slotted `__setattr__` can raise `TypeError`. `StateKey` remains frozen and generic but is intentionally non-slotted; its public constructor is unchanged.
2. Public API governance depended on interpreter-specific reflection for Enum constructors and private `pathlib` module layout. Governance now normalizes both to a cross-version contract.

Regression coverage: `source/tests/test_phase48_python311_runtime_compatibility.py`.

After installing this revision, `setup_linux.sh` performs an installed-wheel `StateKey[int](...)` smoke before certification.
