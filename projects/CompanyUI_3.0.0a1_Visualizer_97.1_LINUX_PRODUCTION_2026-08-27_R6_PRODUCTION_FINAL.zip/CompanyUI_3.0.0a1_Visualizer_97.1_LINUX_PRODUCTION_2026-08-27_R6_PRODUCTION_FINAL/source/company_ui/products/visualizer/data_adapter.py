from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Mapping, Sequence

from company_ui.data_engine import DataQuery, DataSession


class DataSemanticError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class VisualizerDataEnvelope:
    dataset_id: str
    session_revision: int
    row_identity: str | None
    rows: tuple[Mapping[str, Any], ...]
    fields: tuple[str, ...]
    provenance: Mapping[str, Any]
    truncated: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            'dataset_id': self.dataset_id,
            'session_revision': self.session_revision,
            'row_identity': self.row_identity,
            'rows': [deepcopy(dict(row)) for row in self.rows],
            'fields': list(self.fields),
            'provenance': deepcopy(dict(self.provenance)),
            'truncated': self.truncated,
        }


class VisualizerDataAdapter:
    """Typed boundary from Company UI DataSession to Visualizer engine payloads."""

    def __init__(self, *, max_materialized_rows: int = 50_000):
        if max_materialized_rows < 1:
            raise ValueError('max_materialized_rows must be positive')
        self.max_materialized_rows = max_materialized_rows

    def rows(self, session: DataSession, *, offset: int = 0, limit: int | None = None, provenance: Mapping[str, Any] | None = None) -> VisualizerDataEnvelope:
        requested = self.max_materialized_rows if limit is None else min(limit, self.max_materialized_rows)
        result = session.query(DataQuery(offset=offset, limit=requested))
        rows = tuple(self._typed_row(row) for row in result.rows)
        row_key = session.dataset.row_key
        if row_key is not None:
            identities = [row.get(row_key) for row in rows]
            if any(value is None for value in identities) or len(set(map(self._hashable, identities))) != len(identities):
                raise DataSemanticError('stable row identity was not preserved')
        return VisualizerDataEnvelope(
            dataset_id=session.dataset.key,
            session_revision=session.revision,
            row_identity=row_key,
            rows=rows,
            fields=tuple(sorted(session.dataset.fields)),
            provenance={'dataset_key': session.dataset.key, 'filters': [self._filter_to_dict(item) for item in session.filters], **dict(provenance or {})},
            truncated=(result.filtered_total or 0) > offset + len(rows),
        )

    def chart_xy(self, session: DataSession, *, x: str, y: str, provenance: Mapping[str, Any] | None = None) -> VisualizerDataEnvelope:
        self._require_fields(session, (x, y))
        envelope = self.rows(session, provenance=provenance)
        for row in envelope.rows:
            y_value = row.get(y)
            if y_value is None:
                continue
            if isinstance(y_value, bool) or not isinstance(y_value, (int, float, Decimal)):
                raise DataSemanticError(f'{y} must be numeric or missing')
        return envelope

    def timeline(self, session: DataSession, *, sequence_field: str, date_field: str | None = None, provenance: Mapping[str, Any] | None = None) -> VisualizerDataEnvelope:
        self._require_fields(session, (sequence_field, *((date_field,) if date_field else ())))
        envelope = self.rows(session, provenance=provenance)
        if date_field is None:
            # Sequence-only is intentionally kept sequence-only; no synthetic dates.
            return envelope
        for row in envelope.rows:
            value = row.get(date_field)
            if value is None:
                continue
            if not isinstance(value, (date, datetime, str)):
                raise DataSemanticError(f'{date_field} contains invalid date/time values')
        return envelope

    @staticmethod
    def _typed_row(row: Mapping[str, Any]) -> dict[str, Any]:
        # Deepcopy preserves None distinctly from zero and avoids coercive stringification.
        return deepcopy(dict(row))

    @staticmethod
    def _filter_to_dict(clause) -> dict[str, Any]:
        return {'field': clause.field, 'operation': clause.operation.value, 'value': deepcopy(clause.value), 'value2': deepcopy(clause.value2), 'filter_id': clause.filter_id}

    @staticmethod
    def _hashable(value: Any) -> Any:
        if isinstance(value, Mapping):
            return tuple(sorted((key, VisualizerDataAdapter._hashable(item)) for key, item in value.items()))
        if isinstance(value, (list, tuple)):
            return tuple(VisualizerDataAdapter._hashable(item) for item in value)
        return value

    @staticmethod
    def _require_fields(session: DataSession, fields: Sequence[str]) -> None:
        missing = [field for field in fields if field not in session.dataset.fields]
        if missing:
            raise DataSemanticError(f'unknown dataset field: {missing[0]}')
