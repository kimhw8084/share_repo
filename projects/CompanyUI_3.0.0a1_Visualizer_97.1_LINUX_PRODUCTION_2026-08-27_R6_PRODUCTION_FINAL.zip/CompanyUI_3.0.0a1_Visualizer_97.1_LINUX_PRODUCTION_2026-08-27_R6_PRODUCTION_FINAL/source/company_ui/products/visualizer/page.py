from __future__ import annotations

import inspect
import io
import json
import os
import uuid
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Mapping

from company_ui.integrations.nicegui_components import Button, FileUpload
from company_ui.integrations.nicegui_layout import AppShell, PageHeader
from company_ui.navigation import NavigationModel, NavItem, NavSection
from company_ui.runtime import ApplicationRuntime, StateKey, StateNamespace

from .domain import VisualizerContractError, canonical_model
from .extensions import VisualizerProduct
from .ppt_service import VisualizerPptService, _validate_pptx_payload

STATIC_ROUTE = '/_cui_visualizer'
ASSET_ROOT = Path(__file__).with_name('assets')
EDITOR_FRAGMENT = ASSET_ROOT / 'integrated_editor.html'
REPORT_STATE = StateKey[str]('visualizer.report_id', StateNamespace.WORKSPACE, validator=lambda value: isinstance(value, str) and bool(value.strip()))
PPT_MAX_BYTES = 100 * 1024 * 1024
REPORT_MAX_BYTES = 25 * 1024 * 1024

VISUALIZER_NAVIGATION = NavigationModel((
    NavSection('products', 'Products', (
        NavItem('visualizer', 'Visualizer', '/visualizer', icon='chart-line'),
    )),
))


def _ui():
    try:
        from nicegui import ui
    except ImportError as exc:  # pragma: no cover - target runtime only
        raise RuntimeError('NiceGUI 3.15.0 is required to render Visualizer.') from exc
    return ui


def _wire_value(value: Any) -> Any:
    """JSON-safe typed transport; null/zero and date/decimal identity remain explicit."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, datetime):
        return {'$type': 'datetime', 'value': value.isoformat()}
    if isinstance(value, date):
        return {'$type': 'date', 'value': value.isoformat()}
    if isinstance(value, Decimal):
        return {'$type': 'decimal', 'value': str(value)}
    if isinstance(value, Mapping):
        return {str(key): _wire_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_wire_value(item) for item in value]
    return {'$type': type(value).__name__, 'value': repr(value)}


def _js_literal(value: Any) -> str:
    # Escaping < prevents a report title/value from terminating an inline script tag.
    return json.dumps(_wire_value(value), ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')


async def _read_upload(event: Any, *, max_bytes: int) -> tuple[str, bytes]:
    """Support NiceGUI 3.15 upload event shapes without depending on legacy APIs."""
    name = str(getattr(event, 'name', '') or getattr(getattr(event, 'file', None), 'name', '') or 'upload')
    source = getattr(event, 'file', None) or getattr(event, 'content', None)
    if source is None:
        raise VisualizerContractError('upload payload is unavailable')
    read = getattr(source, 'read', None)
    if not callable(read):
        raise VisualizerContractError('upload payload is unreadable')
    value = read()
    if inspect.isawaitable(value):
        value = await value
    if not isinstance(value, (bytes, bytearray)):
        raise VisualizerContractError('upload payload did not produce bytes')
    content = bytes(value)
    if len(content) > max_bytes:
        raise VisualizerContractError(f'upload exceeds {max_bytes // (1024 * 1024)} MB limit')
    return name, content


def _response(type_: str, payload: Mapping[str, Any]) -> dict[str, Any]:
    return {'bridge_version': 1, 'type': type_, 'payload': dict(payload)}


def _record_payload(product: VisualizerProduct, report_id: str) -> dict[str, Any]:
    record = product.repository.get(report_id)
    return product.bridge._record_payload(record)  # governed serializer used by every bootstrap/recovery response


def _register_static_routes(app: Any) -> None:
    """Register only the static trees needed by the retained editor.

    NiceGUI 3.15.0 names the keyword ``follow_symlink`` (singular). Keeping
    this helper isolated makes the pinned runtime contract directly testable without
    importing NiceGUI in the source-only test environment.
    """
    app.add_static_files(f'{STATIC_ROUTE}/assets', str(ASSET_ROOT), follow_symlink=False)
    app.add_static_files(
        f'{STATIC_ROUTE}/vendor',
        str(Path(__file__).with_name('vendor') / 'production_core'),
        follow_symlink=False,
    )


def register_visualizer_page(runtime: ApplicationRuntime, product: VisualizerProduct) -> None:
    """Register the opt-in /visualizer product workspace inside Company UI's AppShell."""
    from nicegui import app, ui

    # Serve only the browser assets and frozen Visualizer authority required at runtime.
    # Never expose the Python product source/repository directory as a static tree.
    _register_static_routes(app)

    @ui.page('/visualizer')
    async def visualizer_page(report: str = 'default', new: str | None = None) -> None:
        requested = 'default' if new else (report or 'default')
        bootstrap = product.bridge.bootstrap(requested).to_dict()['payload']
        report_id = str(bootstrap['report_id'])

        workspace_id = f'visualizer-{uuid.uuid4().hex}'
        workspace = runtime.open_workspace(workspace_id)
        workspace.state.set(REPORT_STATE, report_id, source='visualizer.route')

        async def close_workspace() -> None:
            await runtime.close_workspace(workspace_id)

        client = getattr(getattr(ui, 'context', None), 'client', None)
        on_delete = getattr(client, 'on_delete', None)
        if callable(on_delete):
            on_delete(close_workspace)

        ppt_template: dict[str, Any] = {'name': None, 'content': None}
        ppt_service = VisualizerPptService()

        # Bootstrap must precede the integration module. The module waits for the
        # NiceGUI-rendered product root, so there is no race with retained DOM setup.
        ui.add_head_html(
            f'<link rel="stylesheet" href="{STATIC_ROUTE}/assets/integrated_editor.css">'
            f'<script>window.__CUI_VISUALIZER_BOOTSTRAP__={_js_literal(bootstrap)};</script>',
            shared=False,
        )
        ui.add_body_html(f'<script type="module" src="{STATIC_ROUTE}/assets/integrated_editor.mjs"></script>')

        async def send(response: Mapping[str, Any]) -> None:
            await ui.run_javascript(f'window.CompanyUIVisualizerBridge?.receive({_js_literal(response)});')

        async def handle_semantic(event: Any) -> None:
            try:
                detail = getattr(event, 'args', None)
                if isinstance(detail, Mapping):
                    detail = detail.get('detail', detail)
                if isinstance(detail, list) and detail:
                    detail = detail[0]
                if not isinstance(detail, str):
                    detail = getattr(event, 'detail', detail)
                message = json.loads(detail) if isinstance(detail, str) else detail
                if not isinstance(message, Mapping):
                    raise VisualizerContractError('semantic bridge event must contain an object')
                kind = message.get('type')
                payload = message.get('payload', {})
                current_report_id = workspace.state.get(REPORT_STATE)

                if kind in {'report.opened', 'report.commit', 'report.save_requested', 'report.save_as_requested', 'diagnostic.event'}:
                    response = product.bridge.handle(message)
                    if response is not None:
                        result = response.to_dict()
                        if response.type == 'report.bootstrap':
                            workspace.state.set(REPORT_STATE, str(result['payload']['report_id']), source='visualizer.bridge')
                        await send(result)
                    return

                if kind == 'dataset.bind_requested':
                    if not isinstance(payload, Mapping):
                        raise VisualizerContractError('dataset binding payload must be an object')
                    dataset_key = str(payload.get('dataset_key', ''))
                    if dataset_key not in runtime.data.datasets:
                        await send(_response('application.notification', {'level': 'warning', 'message': f'Dataset not registered: {dataset_key}'}))
                        return
                    session_id = f'dataset:{dataset_key}'
                    session = workspace.data_sessions.get(session_id)
                    if session is None:
                        session = workspace.open_data_session(dataset_key, session_id=session_id)
                    mode = str(payload.get('mode', 'rows'))
                    provenance = {'workspace_id': workspace.workspace_id, 'report_id': current_report_id, 'source': 'company_ui.data_engine'}
                    if mode == 'chart_xy':
                        envelope = product.data_adapter.chart_xy(session, x=str(payload['x']), y=str(payload['y']), provenance=provenance)
                    elif mode == 'timeline':
                        envelope = product.data_adapter.timeline(session, sequence_field=str(payload['sequence_field']), date_field=(str(payload['date_field']) if payload.get('date_field') else None), provenance=provenance)
                    else:
                        envelope = product.data_adapter.rows(session, offset=int(payload.get('offset', 0)), limit=(int(payload['limit']) if payload.get('limit') is not None else None), provenance=provenance)
                    await send(_response('dataset.binding_result', _wire_value(envelope.to_dict())))
                    return

                if kind == 'ppt.export_requested':
                    if not ppt_template['content']:
                        await send(_response('application.notification', {'level': 'warning', 'message': 'Upload the existing work PPTX first; the report will compile into its usable middle region.'}))
                        return
                    if not isinstance(payload, Mapping):
                        raise VisualizerContractError('PPT export payload must be an object')
                    record = product.repository.get(current_report_id)
                    result = ppt_service.export(
                        ppt_template['content'],
                        record,
                        payload.get('normalized_plan', {}),
                        slide_index=int(payload.get('slide_index', 0)),
                        explicit_region=payload.get('explicit_region'),
                    )
                    filename = f'{record.report_id}_visualizer_editable.pptx'
                    runtime.services.downloads.download(filename, result.content, media_type='application/vnd.openxmlformats-officedocument.presentationml.presentation')
                    await send(_response('application.notification', {'level': 'success', 'message': f'Editable PowerPoint compiled · {result.exported_items} objects'}))
                    return

                if kind == 'asset.import_requested':
                    await send(_response('application.notification', {'level': 'info', 'message': 'Use the governed report/PPT upload controls above the editor.'}))
                    return

                raise VisualizerContractError(f'unsupported semantic bridge message: {kind!r}')
            except Exception as exc:
                runtime.services.errors.capture(exc, context={'product': 'visualizer', 'workspace_id': workspace_id})
                await send(_response('application.notification', {'level': 'error', 'message': f'Visualizer integration error: {type(exc).__name__}: {exc}'}))

        async def upload_ppt(event: Any) -> None:
            try:
                name, content = await _read_upload(event, max_bytes=PPT_MAX_BYTES)
                # Reject malformed/pathological archives before python-pptx expands/parses XML.
                _validate_pptx_payload(content)
                from pptx import Presentation
                Presentation(io.BytesIO(content))
                ppt_template['name'] = name
                ppt_template['content'] = content
                ppt_status.set_text(f'Template ready · {name}')
                runtime.services.notifications.success('PowerPoint template loaded for editable export')
            except Exception as exc:
                runtime.services.notifications.error(f'PowerPoint rejected: {exc}')

        async def upload_report(event: Any) -> None:
            try:
                name, content = await _read_upload(event, max_bytes=REPORT_MAX_BYTES)
                payload = json.loads(content.decode('utf-8'))
                model_source = payload.get('model', payload) if isinstance(payload, Mapping) else payload
                model = canonical_model(model_source if isinstance(model_source, Mapping) else {})
                imported_id = f'import-{uuid.uuid4().hex[:12]}'
                record = product.repository.create(imported_id, title=Path(name).stem or 'Imported report', model=model, metadata={'imported_from': name})
                workspace.state.set(REPORT_STATE, record.report_id, source='visualizer.import')
                await send(_response('report.bootstrap', product.bridge._record_payload(record)))
                report_select.options = {item.report_id: item.title for item in product.repository.list()}
                report_select.value = record.report_id
                report_select.update()
                runtime.services.notifications.success('Visualizer report imported as a new revision-safe report')
            except Exception as exc:
                runtime.services.notifications.error(f'Report import rejected: {exc}')

        async def create_report() -> None:
            report_id_new = f'report-{uuid.uuid4().hex[:10]}'
            record = product.repository.create(report_id_new, title='Untitled Visualizer report')
            workspace.state.set(REPORT_STATE, record.report_id, source='visualizer.new')
            await send(_response('report.bootstrap', product.bridge._record_payload(record)))
            report_select.options = {item.report_id: item.title for item in product.repository.list()}
            report_select.value = record.report_id
            report_select.update()
            runtime.services.notifications.success('New Visualizer report created')

        async def select_report(event: Any) -> None:
            value = str(getattr(event, 'value', '') or '')
            if not value or value == workspace.state.get(REPORT_STATE):
                return
            record = product.repository.get(value)
            workspace.state.set(REPORT_STATE, record.report_id, source='visualizer.open')
            await send(_response('report.bootstrap', product.bridge._record_payload(record)))

        with AppShell(
            'Company UI',
            VISUALIZER_NAVIGATION,
            active_route='/visualizer',
            environment=os.getenv('COMPANY_UI_ENVIRONMENT', 'local'),
            subtitle='Visualizer 97.1',
            owner='Company UI Platform',
        ):
            PageHeader('Visualizer', '248-element production report editor hosted by Company UI v3.')
            with ui.element('section').classes('cui-visualizer-integration-bar').props('aria-label="Visualizer persistence and export controls"'):
                with ui.row().classes('items-end gap-2 w-full'):
                    reports = product.repository.list()
                    report_select = ui.select(
                        options={item.report_id: item.title for item in reports},
                        value=report_id,
                        label='Report',
                        on_change=select_report,
                    ).props('outlined dense options-dense').classes('cui-field-control min-w-64')
                    Button('New report', icon='add', on_click=create_report)
                    with ui.element('div').classes('cui-visualizer-template-status'):
                        ppt_status = ui.label('PowerPoint template · not loaded').classes('cui-field-description')
            with ui.element('details').classes('cui-visualizer-import-details'):
                ui.html('Import / PowerPoint template', tag='summary').classes('cui-visualizer-import-summary')
                with ui.row().classes('w-full items-start gap-3'):
                    FileUpload(label='Existing work PPTX', accept=('.pptx',), max_file_size_mb=100, on_upload=upload_ppt)
                    FileUpload(label='Visualizer report JSON', accept=('.json',), max_file_size_mb=25, on_upload=upload_report)

            fragment = EDITOR_FRAGMENT.read_text(encoding='utf-8')
            host = ui.element('div').classes('cui-visualizer-host')
            host.on('visualizer_bridge', handle_semantic, args=['detail'])
            with host:
                ui.html(fragment, sanitize=False).classes('w-full')

        # Product-only host CSS; Company UI's global constitution remains untouched.
        ui.add_css('''
.cui-visualizer-integration-bar{width:100%;padding:10px 12px;border:1px solid var(--cui-border-subtle);border-radius:var(--cui-radius-surface);background:var(--cui-surface-secondary);}
.cui-visualizer-import-details{width:100%;border:1px solid var(--cui-border-subtle);border-radius:var(--cui-radius-surface);background:var(--cui-surface);overflow:hidden;}
.cui-visualizer-import-summary{cursor:pointer;padding:10px 12px;font-size:var(--cui-type-label-size);font-weight:var(--cui-font-weight-650);color:var(--cui-text-secondary);}
.cui-visualizer-import-details[open]>.cui-visualizer-import-summary{border-bottom:1px solid var(--cui-border-subtle);}
.cui-visualizer-import-details>div{padding:12px;}
.cui-visualizer-import-details .cui-upload-shell{flex:1;min-width:min(320px,100%);}
.cui-visualizer-template-status{min-width:240px;padding-bottom:7px;}
@media(max-width:760px){.cui-visualizer-integration-bar .q-field{min-width:100%!important;}.cui-visualizer-template-status{min-width:100%;}.cui-visualizer-import-details>div{flex-direction:column;}}
''')


__all__ = ['ASSET_ROOT', 'REPORT_STATE', 'STATIC_ROUTE', 'VISUALIZER_NAVIGATION', 'register_visualizer_page']
