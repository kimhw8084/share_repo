from __future__ import annotations

import base64
import io
import json
import re
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from pptx import Presentation
from pptx.chart.data import ChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.util import Inches, Pt

from .domain import ReportRecord, VisualizerContractError

VENDOR_ROOT = Path(__file__).with_name('vendor') / 'production_core'
CONTRACTS_PATH = VENDOR_ROOT / 'contracts' / 'component_contracts.json'
_MAX_IMAGE_BYTES = 20 * 1024 * 1024
_MAX_PPTX_FILES = 20_000
_MAX_PPTX_UNCOMPRESSED_BYTES = 768 * 1024 * 1024
_MAX_PPTX_ENTRY_BYTES = 256 * 1024 * 1024
_DATA_IMAGE_RE = re.compile(r'^data:image/(?:png|jpe?g|gif);base64,([A-Za-z0-9+/=\r\n]+)$', re.IGNORECASE)


def _validate_pptx_payload(content: bytes) -> None:
    """Fail closed on malformed or pathological PPTX archives before XML parsing."""
    if not content:
        raise VisualizerContractError('PPT template is empty')
    try:
        with zipfile.ZipFile(io.BytesIO(content)) as archive:
            infos = archive.infolist()
            if not infos or len(infos) > _MAX_PPTX_FILES:
                raise VisualizerContractError('PPTX archive has an invalid file count')
            names = {item.filename for item in infos}
            if '[Content_Types].xml' not in names or 'ppt/presentation.xml' not in names:
                raise VisualizerContractError('PPTX archive is missing required presentation parts')
            total = 0
            for item in infos:
                path = item.filename.replace('\\', '/')
                parts = [part for part in path.split('/') if part not in {'', '.'}]
                if path.startswith('/') or any(part == '..' for part in parts):
                    raise VisualizerContractError('PPTX archive contains an unsafe path')
                if item.file_size > _MAX_PPTX_ENTRY_BYTES:
                    raise VisualizerContractError('PPTX archive contains an oversized entry')
                total += item.file_size
                if total > _MAX_PPTX_UNCOMPRESSED_BYTES:
                    raise VisualizerContractError('PPTX archive expands beyond the safety limit')
    except zipfile.BadZipFile as exc:
        raise VisualizerContractError('PPTX payload is not a valid ZIP package') from exc


def _load_contracts() -> dict[str, Mapping[str, Any]]:
    payload = json.loads(CONTRACTS_PATH.read_text(encoding='utf-8'))
    return {item['element']: item for item in payload['contracts']}


COMPONENT_CONTRACTS = _load_contracts()
EDITOR_ONLY_MAPPING = 'not_exported_editor_only'


@dataclass(frozen=True, slots=True)
class PptExportResult:
    content: bytes
    target_region: Mapping[str, float]
    exported_items: int
    skipped_editor_only: int
    strategies: Mapping[str, int]


class VisualizerPptService:
    """Compile a canonical Visualizer report into an existing editable PPTX.

    The input deck remains the template authority.  The browser remains the Dynamic
    Grid geometry authority and supplies normalized placements.  This service only
    maps that geometry into the selected PPT content region and emits native/editable
    PowerPoint objects from canonical report data.  It intentionally never invents
    business values and never rasterizes the complete report.
    """

    def export(
        self,
        template: bytes,
        record: ReportRecord,
        normalized_plan: Mapping[str, Any],
        *,
        slide_index: int = 0,
        explicit_region: Sequence[float] | None = None,
        placeholder: str = 'VISUALIZER_CONTENT',
    ) -> PptExportResult:
        if not template:
            raise VisualizerContractError('PPT template is required')
        _validate_pptx_payload(template)
        if slide_index < 0:
            raise VisualizerContractError('slide_index must be >= 0')
        prs = Presentation(io.BytesIO(template))
        if slide_index >= len(prs.slides):
            raise VisualizerContractError('slide_index is outside the input deck')
        slide = prs.slides[slide_index]
        target = self._target_region(prs, slide, explicit_region, placeholder)
        items = normalized_plan.get('items') if isinstance(normalized_plan, Mapping) else None
        if not isinstance(items, list):
            raise VisualizerContractError('normalized PPT plan requires items')

        model_by_id = {item['id']: item for item in record.model['items']}
        strategies: dict[str, int] = {}
        exported = 0
        skipped = 0
        for placement in items:
            if not isinstance(placement, Mapping):
                raise VisualizerContractError('PPT placement must be an object')
            item_id = str(placement.get('id', ''))
            source = model_by_id.get(item_id)
            if source is None:
                raise VisualizerContractError(f'PPT plan references unknown item {item_id}')
            element = str(source.get('element') or source.get('title') or source.get('type'))
            contract = COMPONENT_CONTRACTS.get(element)
            mapping = str(contract.get('ppt', {}).get('mapping')) if contract else self._fallback_mapping(source)
            if mapping == EDITOR_ONLY_MAPPING:
                skipped += 1
                continue
            strategies[mapping] = strategies.get(mapping, 0) + 1
            rect = self._map_norm(target, placement)
            self._emit(slide, rect, source, element, mapping)
            exported += 1

        output = io.BytesIO()
        prs.save(output)
        # Round-trip parse is a fail-closed integrity check.
        Presentation(io.BytesIO(output.getvalue()))
        return PptExportResult(output.getvalue(), target, exported, skipped, dict(sorted(strategies.items())))

    @staticmethod
    def _fallback_mapping(source: Mapping[str, Any]) -> str:
        kind = source.get('type')
        if kind == 'chart':
            return 'native_chart_when_supported_else_editable_shapes'
        if kind == 'table':
            return 'editable_table'
        if kind == 'text':
            return 'editable_text_box'
        if kind == 'timeline':
            return 'editable_timeline_shapes'
        if kind in {'image', 'media'}:
            return 'native_image_plus_editable_annotations'
        return 'editable_grouped_shapes'

    @staticmethod
    def _map_norm(target: Mapping[str, float], item: Mapping[str, Any]) -> dict[str, float]:
        nx, ny, nw, nh = (float(item[key]) for key in ('nx', 'ny', 'nw', 'nh'))
        if nx < 0 or ny < 0 or nw <= 0 or nh <= 0 or nx + nw > 1.000001 or ny + nh > 1.000001:
            raise VisualizerContractError('normalized PPT placement escaped content region')
        return {
            'x': target['x'] + nx * target['width'],
            'y': target['y'] + ny * target['height'],
            'width': nw * target['width'],
            'height': nh * target['height'],
        }

    @staticmethod
    def _target_region(prs, slide, region: Sequence[float] | None, placeholder: str) -> dict[str, float]:
        from pptx.enum.shapes import PP_PLACEHOLDER
        from .vendor_adapter import largest_empty_region, rect

        # Required contract precedence: named region, explicit rectangle,
        # compatible content placeholder, then safe middle-region detection.
        wanted = placeholder.strip().casefold()
        for shape in slide.shapes:
            if str(getattr(shape, 'name', '')).strip().casefold() == wanted:
                return rect(shape)
            if getattr(shape, 'has_text_frame', False) and shape.text.strip().casefold() == wanted:
                return rect(shape)

        if region is not None:
            if len(region) != 4:
                raise VisualizerContractError('explicit PPT region requires x,y,width,height')
            x, y, width, height = map(float, region)
            if min(x, y) < 0 or width <= 0 or height <= 0:
                raise VisualizerContractError('invalid explicit PPT region')
            return {'x': x, 'y': y, 'width': width, 'height': height}

        for shape in slide.shapes:
            try:
                placeholder_format = shape.placeholder_format
            except (ValueError, AttributeError):
                continue
            if placeholder_format.type in {PP_PLACEHOLDER.BODY, PP_PLACEHOLDER.OBJECT}:
                candidate = rect(shape)
                if candidate['width'] > 1 and candidate['height'] > 1:
                    return candidate

        page = {'width': prs.slide_width / 914400, 'height': prs.slide_height / 914400}
        obstacles = []
        for shape in slide.shapes:
            candidate = rect(shape)
            cy = candidate['y'] + candidate['height'] / 2
            edge = cy < page['height'] * .22 or cy > page['height'] * .78 or candidate['x'] < page['width'] * .08 or candidate['x'] + candidate['width'] > page['width'] * .92
            if edge and candidate['width'] * candidate['height'] > .02:
                obstacles.append(candidate)
        return largest_empty_region(page, obstacles, .06)

    @classmethod
    def _emit(cls, slide, rect_value: Mapping[str, float], source: Mapping[str, Any], element: str, mapping: str) -> None:
        from .vendor_adapter import add_card, add_kpi

        title = str(source.get('title') or element)
        if mapping == 'native_chart_when_supported_else_editable_shapes':
            if not cls._add_native_chart(slide, rect_value, source, title):
                add_card(slide, rect_value, title, 'Editable chart · no embedded numeric series')
        elif mapping in {'editable_table', 'editable_table_and_shapes'}:
            if not cls._add_native_table(slide, rect_value, source, title):
                cls._add_empty_native_table(slide, rect_value, title)
        elif mapping in {'editable_text_box', 'editable_text_and_shapes'}:
            if source.get('type') == 'metric':
                add_kpi(slide, rect_value, title, cls._display_value(source.get('value')))
            else:
                add_card(slide, rect_value, title, cls._text_payload(source))
        elif mapping == 'editable_shapes_and_connectors':
            cls._add_editable_connectors(slide, rect_value, source, title)
        elif mapping == 'editable_timeline_shapes':
            cls._add_editable_timeline(slide, rect_value, source, title)
        elif mapping in {'native_image_plus_editable_annotations', 'editable_shapes_plus_native_image_boundary'}:
            if not cls._add_embedded_image(slide, rect_value, source, title):
                add_card(slide, rect_value, title, 'Editable image boundary · no embedded image')
        elif mapping == 'flatten_selected_state_only':
            selected = source.get('selectedState', source.get('selected', source.get('value')))
            add_card(slide, rect_value, title, f'Selected state · {cls._display_value(selected)}')
        elif source.get('type') == 'metric':
            add_kpi(slide, rect_value, title, cls._display_value(source.get('value')))
        else:
            # Generic diagrams/composites/layouts remain native editable geometry.
            # The mapping label is metadata, not fabricated report data.
            add_card(slide, rect_value, title, f'Editable Visualizer object · {mapping}')

    @staticmethod
    def _display_value(value: Any) -> str:
        if value is None:
            return 'Missing'
        if isinstance(value, bool):
            return 'true' if value else 'false'
        if isinstance(value, (dict, list, tuple)):
            return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
        return str(value)

    @classmethod
    def _text_payload(cls, source: Mapping[str, Any]) -> str:
        for key in ('text', 'value', 'subtitle', 'description', 'detail'):
            if key in source:
                return cls._display_value(source.get(key))
        return 'Editable Visualizer text · no text payload'

    @staticmethod
    def _chart_type(source: Mapping[str, Any]):
        variant = str(source.get('variant', '')).casefold()
        element = str(source.get('element', '')).casefold()
        if 'bar' in variant or 'bar' in element:
            return XL_CHART_TYPE.BAR_CLUSTERED if 'horizontal' in element else XL_CHART_TYPE.COLUMN_CLUSTERED
        if 'area' in variant or 'area' in element:
            return XL_CHART_TYPE.AREA
        if 'scatter' in variant or 'scatter' in element:
            return XL_CHART_TYPE.XY_SCATTER
        return XL_CHART_TYPE.LINE_MARKERS

    @classmethod
    def _chart_series(cls, source: Mapping[str, Any]) -> tuple[list[str], list[tuple[str, list[float]]]] | None:
        data = source.get('data')
        # Common canonical compact form: [[category, numeric], ...].  Numeric zero is
        # preserved; missing/non-numeric values make the series ineligible for a native
        # chart rather than being coerced to zero.
        if isinstance(data, list) and data and all(isinstance(row, (list, tuple)) and len(row) >= 2 for row in data):
            categories: list[str] = []
            values: list[float] = []
            for row in data:
                value = row[1]
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    return None
                categories.append(cls._display_value(row[0]))
                values.append(float(value))
            return categories, [(str(source.get('seriesName') or source.get('title') or 'Value'), values)]

        # Explicit multi-series shape: {categories:[...], series:[{name, values:[...]}]}.
        if isinstance(data, Mapping):
            categories = data.get('categories')
            raw_series = data.get('series')
            if isinstance(categories, list) and categories and isinstance(raw_series, list) and raw_series:
                labels = [cls._display_value(value) for value in categories]
                series: list[tuple[str, list[float]]] = []
                for index, entry in enumerate(raw_series):
                    if not isinstance(entry, Mapping) or not isinstance(entry.get('values'), list) or len(entry['values']) != len(labels):
                        return None
                    values: list[float] = []
                    for value in entry['values']:
                        if isinstance(value, bool) or not isinstance(value, (int, float)):
                            return None
                        values.append(float(value))
                    series.append((str(entry.get('name') or f'Series {index + 1}'), values))
                return labels, series
        return None

    @classmethod
    def _add_native_chart(cls, slide, r: Mapping[str, float], source: Mapping[str, Any], title: str) -> bool:
        parsed = cls._chart_series(source)
        if parsed is None:
            return False
        categories, series = parsed
        data = ChartData()
        data.categories = categories
        for name, values in series:
            data.add_series(name, values)
        chart_shape = slide.shapes.add_chart(
            cls._chart_type(source),
            Inches(r['x']), Inches(r['y']), Inches(r['width']), Inches(r['height']), data,
        )
        chart_shape.name = f'VIZ::{title}'
        chart = chart_shape.chart
        chart.has_title = True
        chart.chart_title.text_frame.text = title
        chart.has_legend = len(series) > 1
        return True

    @classmethod
    def _table_matrix(cls, source: Mapping[str, Any]) -> list[list[str]] | None:
        rows = source.get('rows')
        if isinstance(rows, list) and rows:
            if all(isinstance(row, Mapping) for row in rows):
                columns = source.get('columns')
                if isinstance(columns, list) and columns and all(isinstance(value, str) and value for value in columns):
                    headers = list(columns)
                else:
                    headers = []
                    seen: set[str] = set()
                    for row in rows:
                        for key in row:
                            name = str(key)
                            if name not in seen:
                                headers.append(name)
                                seen.add(name)
                return [headers] + [[cls._display_value(row.get(column)) for column in headers] for row in rows]
            if all(isinstance(row, (list, tuple)) for row in rows):
                width = max((len(row) for row in rows), default=0)
                if width:
                    return [[cls._display_value(row[index]) if index < len(row) else 'Missing' for index in range(width)] for row in rows]

        data = source.get('data')
        if isinstance(data, list) and data and all(isinstance(row, (list, tuple)) for row in data):
            width = max((len(row) for row in data), default=0)
            if width:
                return [[cls._display_value(row[index]) if index < len(row) else 'Missing' for index in range(width)] for row in data]
        return None

    @classmethod
    def _add_native_table(cls, slide, r: Mapping[str, float], source: Mapping[str, Any], title: str) -> bool:
        matrix = cls._table_matrix(source)
        if not matrix or not matrix[0]:
            return False
        row_count = len(matrix)
        col_count = len(matrix[0])
        shape = slide.shapes.add_table(
            row_count, col_count,
            Inches(r['x']), Inches(r['y']), Inches(r['width']), Inches(r['height']),
        )
        shape.name = f'VIZ::{title}'
        table = shape.table
        for row_index, row in enumerate(matrix):
            for col_index in range(col_count):
                table.cell(row_index, col_index).text = row[col_index] if col_index < len(row) else 'Missing'
                for paragraph in table.cell(row_index, col_index).text_frame.paragraphs:
                    paragraph.font.name = 'Arial'
                    paragraph.font.size = Pt(9)
                    paragraph.font.bold = row_index == 0 and isinstance(source.get('rows'), list) and all(isinstance(v, Mapping) for v in source.get('rows', []))
        return True

    @staticmethod
    def _add_empty_native_table(slide, r: Mapping[str, float], title: str) -> None:
        shape = slide.shapes.add_table(1, 1, Inches(r['x']), Inches(r['y']), Inches(r['width']), Inches(r['height']))
        shape.name = f'VIZ::{title}'
        shape.table.cell(0, 0).text = 'No tabular data embedded'
        for paragraph in shape.table.cell(0, 0).text_frame.paragraphs:
            paragraph.font.name = 'Arial'
            paragraph.font.size = Pt(10)

    @classmethod
    def _node_labels(cls, source: Mapping[str, Any]) -> list[str]:
        nodes = source.get('nodes')
        labels: list[str] = []
        if isinstance(nodes, list):
            for node in nodes[:16]:
                if isinstance(node, Mapping):
                    raw = node.get('label', node.get('title', node.get('name')))
                else:
                    raw = node
                if raw is not None:
                    labels.append(cls._display_value(raw))
        return labels

    @classmethod
    def _add_editable_connectors(cls, slide, r: Mapping[str, float], source: Mapping[str, Any], title: str) -> None:
        labels = cls._node_labels(source)
        if not labels:
            from .vendor_adapter import add_card
            add_card(slide, r, title, 'Editable diagram · no embedded nodes')
            return
        count = min(len(labels), 6)
        gap = max(.08, r['width'] * .02)
        box_width = max(.35, (r['width'] - gap * (count - 1)) / count)
        box_height = min(max(.35, r['height'] * .4), max(.35, r['height'] - .15))
        y = r['y'] + (r['height'] - box_height) / 2
        previous = None
        for index, label in enumerate(labels[:count]):
            x = r['x'] + index * (box_width + gap)
            shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(box_width), Inches(box_height))
            shape.name = f'VIZ::{title} node {index + 1}'
            shape.text_frame.text = label
            for paragraph in shape.text_frame.paragraphs:
                paragraph.font.name = 'Arial'; paragraph.font.size = Pt(9)
            if previous is not None:
                x1 = previous[0] + box_width
                x2 = x
                cy = y + box_height / 2
                connector = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(cy), Inches(x2), Inches(cy))
                connector.name = f'VIZ::{title} connector {index}'
            previous = (x, y)

    @classmethod
    def _timeline_events(cls, source: Mapping[str, Any]) -> list[str]:
        events = source.get('events')
        labels: list[str] = []
        if isinstance(events, list):
            for event in events[:24]:
                if isinstance(event, Mapping):
                    # Preserve explicitly supplied chronology/sequence; never synthesize a date.
                    parts = []
                    for key in ('sequence', 'date', 'timestamp', 'label', 'title', 'name'):
                        if key in event and event.get(key) is not None:
                            parts.append(cls._display_value(event.get(key)))
                    if parts:
                        labels.append(' · '.join(parts))
                elif event is not None:
                    labels.append(cls._display_value(event))
        return labels

    @classmethod
    def _add_editable_timeline(cls, slide, r: Mapping[str, float], source: Mapping[str, Any], title: str) -> None:
        labels = cls._timeline_events(source)
        y = r['y'] + r['height'] * .56
        line = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(r['x'] + .12), Inches(y), Inches(r['x'] + r['width'] - .12), Inches(y))
        line.name = f'VIZ::{title} timeline'
        if not labels:
            from .vendor_adapter import add_card
            # A line plus canonical title is editable and does not invent milestones/dates.
            add_card(slide, {'x': r['x'], 'y': r['y'], 'width': r['width'], 'height': max(.35, r['height'] * .36)}, title, 'Editable timeline · no embedded events')
            return
        count = len(labels)
        for index, label in enumerate(labels):
            ratio = .5 if count == 1 else index / (count - 1)
            x = r['x'] + .15 + ratio * max(.1, r['width'] - .3)
            marker = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x - .055), Inches(y - .055), Inches(.11), Inches(.11))
            marker.name = f'VIZ::{title} event {index + 1}'
            textbox = slide.shapes.add_textbox(Inches(max(r['x'], x - .5)), Inches(r['y'] + .04), Inches(min(1.0, r['width'])), Inches(max(.28, y - r['y'] - .13)))
            textbox.name = f'VIZ::{title} label {index + 1}'
            textbox.text_frame.text = label
            for paragraph in textbox.text_frame.paragraphs:
                paragraph.font.name = 'Arial'; paragraph.font.size = Pt(8)

    @classmethod
    def _decode_image(cls, source: Mapping[str, Any]) -> bytes | None:
        value = source.get('image_data_uri', source.get('src'))
        if not isinstance(value, str):
            return None
        match = _DATA_IMAGE_RE.fullmatch(value.strip())
        if not match:
            return None
        try:
            content = base64.b64decode(match.group(1), validate=True)
        except (ValueError, base64.binascii.Error):
            return None
        if not content or len(content) > _MAX_IMAGE_BYTES:
            return None
        return content

    @classmethod
    def _add_embedded_image(cls, slide, r: Mapping[str, float], source: Mapping[str, Any], title: str) -> bool:
        content = cls._decode_image(source)
        if content is None:
            return False
        stream = io.BytesIO(content)
        try:
            picture = slide.shapes.add_picture(stream, Inches(r['x']), Inches(r['y']), Inches(r['width']), Inches(r['height']))
        except Exception as exc:  # corrupt or unsupported image bytes fail closed
            raise VisualizerContractError('embedded image payload is not a valid supported image') from exc
        picture.name = f'VIZ::{title} image'
        annotations = source.get('annotations')
        if isinstance(annotations, list):
            for index, annotation in enumerate(annotations[:50]):
                if not isinstance(annotation, Mapping):
                    continue
                try:
                    ax = float(annotation.get('nx', 0)); ay = float(annotation.get('ny', 0))
                    aw = float(annotation.get('nw', .12)); ah = float(annotation.get('nh', .08))
                except (TypeError, ValueError):
                    continue
                if ax < 0 or ay < 0 or aw <= 0 or ah <= 0 or ax + aw > 1 or ay + ah > 1:
                    continue
                box = slide.shapes.add_shape(
                    MSO_SHAPE.RECTANGLE,
                    Inches(r['x'] + ax * r['width']), Inches(r['y'] + ay * r['height']),
                    Inches(aw * r['width']), Inches(ah * r['height']),
                )
                box.name = f'VIZ::{title} annotation {index + 1}'
                box.fill.background()
                box.line.color.rgb = RGBColor(0, 0, 0)
        return True
