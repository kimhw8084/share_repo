from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Iterable

from .domain import INITIAL_MODEL, ReportRecord, VisualizerContractError, stable_json, utc_now, validate_report_id


class ReportNotFoundError(FileNotFoundError):
    pass


class ReportRepository:
    """Extension-owned repository behind Company UI's service boundary.

    Writes are deterministic, atomic and fail closed. The repository never mutates a
    report outside revision-aware semantic commits handled by the bridge service.
    """

    def __init__(self, root: str | Path):
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, report_id: str) -> Path:
        safe = validate_report_id(report_id)
        target = (self.root / f'{safe}.json').resolve()
        if target.parent != self.root:
            raise VisualizerContractError('report path escaped repository root')
        return target

    def list(self) -> tuple[ReportRecord, ...]:
        records = []
        for path in sorted(self.root.glob('*.json')):
            try:
                records.append(self._read(path))
            except Exception:
                continue
        return tuple(sorted(records, key=lambda item: (item.updated_at, item.report_id), reverse=True))

    def exists(self, report_id: str) -> bool:
        return self._path(report_id).is_file()

    def create(self, report_id: str, *, title: str = 'Untitled report', model=None, metadata=None) -> ReportRecord:
        path = self._path(report_id)
        if path.exists():
            raise FileExistsError(report_id)
        now = utc_now()
        record = ReportRecord(report_id=report_id, revision=1, title=title, model=model or INITIAL_MODEL, created_at=now, updated_at=now, metadata=metadata or {})
        self.save(record)
        return record

    def get(self, report_id: str) -> ReportRecord:
        path = self._path(report_id)
        if not path.is_file():
            raise ReportNotFoundError(report_id)
        return self._read(path)

    def get_or_create(self, report_id: str, *, title: str = 'Untitled report') -> ReportRecord:
        return self.get(report_id) if self.exists(report_id) else self.create(report_id, title=title)

    def save(self, record: ReportRecord) -> ReportRecord:
        path = self._path(record.report_id)
        payload = stable_json(record.to_dict(), indent=2) + '\n'
        fd, temp_name = tempfile.mkstemp(prefix=f'.{record.report_id}.', suffix='.tmp', dir=self.root)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, path)
        finally:
            try:
                os.unlink(temp_name)
            except FileNotFoundError:
                pass
        return record

    def delete(self, report_id: str) -> bool:
        path = self._path(report_id)
        if not path.exists():
            return False
        path.unlink()
        return True

    def duplicate(self, source_report_id: str, new_report_id: str, *, title: str | None = None) -> ReportRecord:
        source = self.get(source_report_id)
        return self.create(new_report_id, title=title or f'{source.title} copy', model=source.model, metadata={'duplicated_from': source.report_id})

    def _read(self, path: Path) -> ReportRecord:
        import json
        try:
            payload = json.loads(path.read_text(encoding='utf-8'))
        except Exception as exc:
            raise VisualizerContractError(f'corrupt report file: {path.name}') from exc
        if not isinstance(payload, dict):
            raise VisualizerContractError(f'corrupt report file: {path.name}')
        return ReportRecord.from_dict(payload)
