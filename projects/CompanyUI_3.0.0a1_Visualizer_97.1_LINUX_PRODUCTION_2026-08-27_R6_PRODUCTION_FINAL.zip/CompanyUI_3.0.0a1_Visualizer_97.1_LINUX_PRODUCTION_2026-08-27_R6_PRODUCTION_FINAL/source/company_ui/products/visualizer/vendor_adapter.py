"""Stable import facade over Visualizer 97.1's frozen PPT middle-region adapter."""
from __future__ import annotations

import importlib.util
from pathlib import Path

_ADAPTER = Path(__file__).with_name('vendor') / 'production_core' / 'tools' / 'ppt_template_adapter.py'
_spec = importlib.util.spec_from_file_location('company_ui_visualizer_vendor_ppt_adapter', _ADAPTER)
if _spec is None or _spec.loader is None:
    raise RuntimeError('Unable to load Visualizer PPT adapter')
_module = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_module)

add_card = _module.add_card
add_kpi = _module.add_kpi
add_native_chart = _module.add_native_chart
add_native_table = _module.add_native_table
largest_empty_region = _module.largest_empty_region
rect = _module.rect
