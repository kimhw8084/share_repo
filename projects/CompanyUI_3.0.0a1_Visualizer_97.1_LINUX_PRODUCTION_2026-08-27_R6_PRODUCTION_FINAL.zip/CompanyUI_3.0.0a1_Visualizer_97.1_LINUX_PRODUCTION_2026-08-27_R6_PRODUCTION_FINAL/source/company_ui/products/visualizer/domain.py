from __future__ import annotations

import hashlib
import json
import re
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping, Sequence

REPORT_SCHEMA_VERSION = 1
REPORT_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")
ALLOWED_MODES = frozenset({'smart', 'guided', 'free'})
MODEL_KEYS = ('schema_version', 'items', 'groups', 'mode', 'layoutPreset', 'crossFilter', 'nextId')


class VisualizerContractError(ValueError):
    pass


class RevisionConflictError(VisualizerContractError):
    def __init__(self, expected: int, received: int):
        super().__init__(f'Stale base_revision: expected {expected}, received {received}')
        self.expected = expected
        self.received = received


class DuplicateCommitError(VisualizerContractError):
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')


def _stable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _stable(value[key]) for key in sorted(value, key=lambda item: str(item))}
    if isinstance(value, (list, tuple)):
        return [_stable(item) for item in value]
    return value


def stable_json(value: Any, *, indent: int | None = None) -> str:
    separators = None if indent is not None else (',', ':')
    return json.dumps(_stable(value), indent=indent, ensure_ascii=False, separators=separators, allow_nan=False)


def fingerprint_model(model: Mapping[str, Any]) -> str:
    canonical = canonical_model(model)
    return hashlib.sha256(stable_json(canonical).encode('utf-8')).hexdigest()


def validate_report_id(report_id: str) -> str:
    value = str(report_id).strip()
    if not REPORT_ID_RE.fullmatch(value):
        raise VisualizerContractError('report_id must be 1..128 safe filename characters')
    return value


def _infer_next_id(items: Sequence[Mapping[str, Any]]) -> int:
    values: list[int] = []
    for item in items:
        match = re.fullmatch(r'c(\d+)', str(item.get('id', '')))
        if match:
            values.append(int(match.group(1)))
    return max(20, max(values, default=19) + 1)


def canonical_model(value: Mapping[str, Any] | None = None) -> dict[str, Any]:
    source = dict(value or {})
    items = deepcopy(source.get('items')) if isinstance(source.get('items'), list) else []
    groups = deepcopy(source.get('groups')) if isinstance(source.get('groups'), Mapping) else {}
    mode = source.get('mode') if source.get('mode') in ALLOWED_MODES else 'smart'
    next_id = source.get('nextId') if isinstance(source.get('nextId'), int) else _infer_next_id(items)
    model = {
        'schema_version': source.get('schema_version') if isinstance(source.get('schema_version'), int) else REPORT_SCHEMA_VERSION,
        'items': items,
        'groups': groups,
        'mode': mode,
        'layoutPreset': source.get('layoutPreset') if isinstance(source.get('layoutPreset'), str) else 'editorial',
        'crossFilter': deepcopy(source.get('crossFilter')) if 'crossFilter' in source else None,
        'nextId': next_id,
    }
    validate_model(model)
    return model


def validate_model(model: Mapping[str, Any]) -> None:
    for key in MODEL_KEYS:
        if key not in model:
            raise VisualizerContractError(f'Missing model field: {key}')
    if model['schema_version'] != REPORT_SCHEMA_VERSION:
        raise VisualizerContractError(f'unsupported report schema_version {model["schema_version"]!r}')
    if model['mode'] not in ALLOWED_MODES:
        raise VisualizerContractError(f'unsupported mode {model["mode"]!r}')
    if not isinstance(model['items'], list):
        raise VisualizerContractError('items must be a list')
    if not isinstance(model['groups'], Mapping):
        raise VisualizerContractError('groups must be an object')
    if not isinstance(model['nextId'], int) or model['nextId'] < 1:
        raise VisualizerContractError('nextId must be a positive integer')

    ids: set[str] = set()
    for entry in model['items']:
        if not isinstance(entry, Mapping):
            raise VisualizerContractError('Every item must be an object')
        item_id = entry.get('id')
        if not isinstance(item_id, str) or not item_id:
            raise VisualizerContractError('Every item requires a semantic id')
        if item_id in ids:
            raise VisualizerContractError(f'Duplicate item id: {item_id}')
        ids.add(item_id)
        if not isinstance(entry.get('type'), str) or not entry.get('type'):
            raise VisualizerContractError(f'Item {item_id} requires a type')
        order = entry.get('order')
        if isinstance(order, bool) or not isinstance(order, (int, float)):
            raise VisualizerContractError(f'Item {item_id} requires numeric order')
        for key in ('x', 'y', 'w', 'h', 'weight', 'z'):
            candidate = entry.get(key)
            if candidate is not None and (isinstance(candidate, bool) or not isinstance(candidate, (int, float))):
                raise VisualizerContractError(f'Item {item_id}.{key} must be numeric when present')

    item_by_id = {entry['id']: entry for entry in model['items']}
    for group_id, group in model['groups'].items():
        if not isinstance(group_id, str) or not group_id:
            raise VisualizerContractError('group id must be a non-empty string')
        if not isinstance(group, Mapping) or not isinstance(group.get('items'), list):
            raise VisualizerContractError(f'Group {group_id} is malformed')
        member_ids: set[str] = set()
        for item_id in group['items']:
            if item_id not in ids:
                raise VisualizerContractError(f'Group {group_id} references missing item {item_id}')
            if item_id in member_ids:
                raise VisualizerContractError(f'Group {group_id} contains duplicate member {item_id}')
            member_ids.add(item_id)
            if item_by_id[item_id].get('groupId') != group_id:
                raise VisualizerContractError(f'Group {group_id} membership disagrees with item {item_id}.groupId')
    for entry in model['items']:
        group_id = entry.get('groupId')
        if group_id is None:
            continue
        if not isinstance(group_id, str) or not group_id:
            raise VisualizerContractError(f'Item {entry["id"]}.groupId must be null or non-empty string')
        group = model['groups'].get(group_id)
        if not group or entry['id'] not in group.get('items', []):
            raise VisualizerContractError(f'Item {entry["id"]} references inconsistent group {group_id}')


def _require_item(model: dict[str, Any], item_id: str) -> tuple[dict[str, Any], int]:
    for index, entry in enumerate(model['items']):
        if entry['id'] == item_id:
            return entry, index
    raise VisualizerContractError(f'Unknown item id: {item_id}')


def _apply_op(model: dict[str, Any], op: Mapping[str, Any]) -> None:
    kind = op.get('op')
    if not isinstance(kind, str):
        raise VisualizerContractError('Every transaction operation requires op')
    if kind == 'item.add':
        entry = deepcopy(op.get('item'))
        if not isinstance(entry, Mapping):
            raise VisualizerContractError('item.add requires item')
        if any(item['id'] == entry.get('id') for item in model['items']):
            raise VisualizerContractError(f'Duplicate item id: {entry.get("id")}')
        index = op.get('index') if isinstance(op.get('index'), int) else len(model['items'])
        index = max(0, min(index, len(model['items'])))
        model['items'].insert(index, dict(entry))
        return
    if kind == 'item.remove':
        entry, index = _require_item(model, str(op.get('id')))
        del model['items'][index]
        for group in model['groups'].values():
            group['items'] = [item_id for item_id in group['items'] if item_id != entry['id']]
        return
    if kind == 'item.patch':
        entry, _ = _require_item(model, str(op.get('id')))
        patch = op.get('patch')
        if not isinstance(patch, Mapping):
            raise VisualizerContractError('item.patch requires patch object')
        for key, value in patch.items():
            entry[key] = deepcopy(value)
        return
    if kind == 'group.set':
        group_id = op.get('id')
        value = op.get('value')
        if not isinstance(group_id, str) or not group_id or not isinstance(value, Mapping):
            raise VisualizerContractError('group.set requires id/value')
        model['groups'][group_id] = deepcopy(dict(value))
        return
    if kind == 'group.delete':
        group_id = op.get('id')
        if not isinstance(group_id, str) or not group_id:
            raise VisualizerContractError('group.delete requires id')
        previous = model['groups'].pop(group_id, None)
        if previous:
            for item_id in previous.get('items', []):
                try:
                    entry, _ = _require_item(model, item_id)
                except VisualizerContractError:
                    continue
                if entry.get('groupId') == group_id:
                    entry['groupId'] = None
        return
    if kind == 'model.patch':
        patch = op.get('patch')
        if not isinstance(patch, Mapping):
            raise VisualizerContractError('model.patch requires patch object')
        allowed = {'mode', 'layoutPreset', 'crossFilter', 'nextId'}
        unexpected = set(patch) - allowed
        if unexpected:
            raise VisualizerContractError(f'model.patch cannot modify {sorted(unexpected)[0]}')
        for key, value in patch.items():
            model[key] = deepcopy(value)
        return
    if kind == 'model.replace':
        replacement = canonical_model(op.get('value') if isinstance(op.get('value'), Mapping) else {})
        model.clear()
        model.update(replacement)
        return
    raise VisualizerContractError(f'Unsupported transaction operation: {kind}')


def apply_editor_command(model: Mapping[str, Any], command: Mapping[str, Any], *, expected_revision: int) -> dict[str, Any]:
    if command.get('type') != 'editor.transaction':
        raise VisualizerContractError(f'Unsupported EditorCommand type: {command.get("type")!r}')
    base_revision = command.get('base_revision')
    if base_revision != expected_revision:
        raise RevisionConflictError(expected_revision, int(base_revision) if isinstance(base_revision, int) else -1)
    payload = command.get('payload')
    ops = payload.get('ops') if isinstance(payload, Mapping) else None
    if not isinstance(ops, list) or not ops:
        raise VisualizerContractError('EditorCommand payload.ops must be a non-empty array')
    if not isinstance(command.get('id'), str) or not command.get('id'):
        raise VisualizerContractError('EditorCommand requires an id')
    next_model = canonical_model(model)
    for op in ops:
        if not isinstance(op, Mapping):
            raise VisualizerContractError('EditorCommand operations must be objects')
        _apply_op(next_model, op)
    validate_model(next_model)
    return canonical_model(next_model)


INITIAL_MODEL = canonical_model({
    'schema_version': 1,
    'items': [
        {'id': 'c1', 'type': 'metric', 'title': 'Investigation Time', 'weight': 1.1, 'order': 0, 'value': 92, 'detail': False, 'locked': False, 'z': 1},
        {'id': 'c2', 'type': 'chart', 'title': 'Investigation Trend', 'weight': 1.85, 'order': 1, 'variant': 'line', 'data': [['Collect', 84], ['Normalize', 71], ['Reason', 48], ['Verify', 31], ['Close', 14]], 'brush': [0, 4], 'cross': None, 'drill': None, 'revealed': True, 'locked': False, 'z': 2},
        {'id': 'c3', 'type': 'text', 'title': 'Key Takeaway', 'weight': 1.05, 'order': 2, 'locked': False, 'z': 3},
        {'id': 'c4', 'type': 'table', 'title': 'Evidence Log', 'weight': 1.5, 'order': 3, 'locked': False, 'z': 4},
        {'id': 'c5', 'type': 'tabs', 'title': 'Investigation Summary', 'weight': 1.05, 'order': 4, 'tab': 'Summary', 'expanded': False, 'locked': False, 'z': 5},
        {'id': 'c6', 'type': 'timeline', 'title': 'Validation Path', 'weight': 1.35, 'order': 5, 'tm': 2, 'locked': False, 'z': 6},
    ],
    'groups': {},
    'mode': 'smart',
    'layoutPreset': 'editorial',
    'crossFilter': None,
    'nextId': 20,
})


@dataclass(frozen=True, slots=True)
class ReportRecord:
    report_id: str
    revision: int
    model: Mapping[str, Any]
    schema_version: int = REPORT_SCHEMA_VERSION
    state_fingerprint: str = ''
    title: str = 'Untitled report'
    created_at: str = field(default_factory=utc_now)
    updated_at: str = field(default_factory=utc_now)
    commit_ids: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        validate_report_id(self.report_id)
        if self.schema_version != REPORT_SCHEMA_VERSION:
            raise VisualizerContractError('unsupported report record schema')
        if self.revision < 1:
            raise VisualizerContractError('report revision must be >= 1')
        canonical = canonical_model(self.model)
        actual = fingerprint_model(canonical)
        if self.state_fingerprint and self.state_fingerprint != actual:
            raise VisualizerContractError('report fingerprint does not match canonical model')
        object.__setattr__(self, 'model', canonical)
        object.__setattr__(self, 'state_fingerprint', actual)
        object.__setattr__(self, 'metadata', deepcopy(dict(self.metadata)))

    def to_dict(self) -> dict[str, Any]:
        return {
            'report_id': self.report_id,
            'schema_version': self.schema_version,
            'revision': self.revision,
            'state_fingerprint': self.state_fingerprint,
            'title': self.title,
            'created_at': self.created_at,
            'updated_at': self.updated_at,
            'commit_ids': list(self.commit_ids),
            'metadata': deepcopy(dict(self.metadata)),
            'model': canonical_model(self.model),
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> 'ReportRecord':
        return cls(
            report_id=str(payload['report_id']),
            schema_version=int(payload.get('schema_version', REPORT_SCHEMA_VERSION)),
            revision=int(payload['revision']),
            state_fingerprint=str(payload.get('state_fingerprint', '')),
            title=str(payload.get('title', 'Untitled report')),
            created_at=str(payload.get('created_at', utc_now())),
            updated_at=str(payload.get('updated_at', utc_now())),
            commit_ids=tuple(str(item) for item in payload.get('commit_ids', ())),
            metadata=payload.get('metadata', {}) if isinstance(payload.get('metadata', {}), Mapping) else {},
            model=payload.get('model', {}) if isinstance(payload.get('model'), Mapping) else {},
        )
