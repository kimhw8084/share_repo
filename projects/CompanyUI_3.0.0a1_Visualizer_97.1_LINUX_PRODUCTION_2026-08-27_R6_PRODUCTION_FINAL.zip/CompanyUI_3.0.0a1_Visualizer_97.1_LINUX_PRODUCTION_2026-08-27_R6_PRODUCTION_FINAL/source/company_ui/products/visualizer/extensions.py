from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from company_ui.extensions import ExtensionDefinition, ExtensionKind
from company_ui.runtime import ApplicationRuntime
from company_ui.services import Command

from .bridge import VisualizerBridgeService
from .data_adapter import VisualizerDataAdapter
from .repository import ReportRepository


@dataclass(slots=True)
class VisualizerProduct:
    runtime: ApplicationRuntime
    repository: ReportRepository
    bridge: VisualizerBridgeService
    data_adapter: VisualizerDataAdapter


def register_visualizer(runtime: ApplicationRuntime, *, repository_root: str | Path) -> VisualizerProduct:
    """Register Visualizer through Company UI's explicit v3 extension boundary."""
    repository = ReportRepository(repository_root)
    bridge = VisualizerBridgeService(repository)
    data_adapter = VisualizerDataAdapter()
    product = VisualizerProduct(runtime, repository, bridge, data_adapter)

    definitions = (
        ExtensionDefinition('visualizer.workspace', ExtensionKind.WORKSPACE_PANEL, lambda: product, version='97.1+company-ui-v3', description='Visualizer governed product workspace', metadata={'route': '/visualizer', 'opt_in': True}),
        ExtensionDefinition('visualizer.runtime', ExtensionKind.VISUALIZATION, lambda: product, version='97.1', description='Certified Visualizer 248-element/17-engine runtime'),
        ExtensionDefinition('visualizer.dataset-adapter', ExtensionKind.DATA_SOURCE, lambda: data_adapter, version='1.0', description='Typed DataSession adapter preserving identity/provenance/missing values'),
        ExtensionDefinition('visualizer.report-bridge', ExtensionKind.COMPONENT, lambda: bridge, version='1.0', description='Revision-aware semantic browser/Python bridge'),
    )
    for definition in definitions:
        if runtime.extensions.get(definition.kind, definition.key) is None:
            runtime.extensions.register(definition)

    commands = (
        Command('visualizer.open', 'Open Visualizer', lambda: runtime.services.navigation.go('/visualizer'), keywords=('report', 'editor', 'visualization'), group='Visualizer'),
        Command('visualizer.new', 'New Visualizer report', lambda: runtime.services.navigation.go('/visualizer?new=1'), keywords=('report', 'create'), group='Visualizer'),
    )
    for command in commands:
        if runtime.services.commands.get(command.key) is None:
            runtime.services.commands.register(command)
    return product
