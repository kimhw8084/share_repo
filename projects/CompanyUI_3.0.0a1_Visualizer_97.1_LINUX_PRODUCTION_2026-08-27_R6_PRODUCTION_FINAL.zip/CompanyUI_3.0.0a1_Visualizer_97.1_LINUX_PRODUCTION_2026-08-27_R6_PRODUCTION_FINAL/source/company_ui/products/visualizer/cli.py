from __future__ import annotations

import argparse
import os
import secrets
from pathlib import Path

from company_ui.integrations.nicegui_runtime import NiceGUIRuntimeAdapter
from company_ui.integrations.nicegui_state import NiceGUIStateServices
from company_ui.runtime import ApplicationRuntime, RuntimeConfig, RuntimeEnvironment
from company_ui.services import ApplicationServices
from company_ui.version import FRAMEWORK_VERSION

from .extensions import register_visualizer
from .page import register_visualizer_page




def _runtime_environment() -> RuntimeEnvironment:
    raw = os.getenv('COMPANY_UI_ENVIRONMENT', 'dev').strip().lower()
    aliases = {'development': 'dev', 'testing': 'test', 'production': 'prod'}
    normalized = aliases.get(raw, raw)
    try:
        return RuntimeEnvironment(normalized)
    except ValueError as exc:
        allowed = ', '.join(item.value for item in RuntimeEnvironment)
        raise RuntimeError(f'Unsupported COMPANY_UI_ENVIRONMENT={raw!r}; expected one of: {allowed}') from exc


def _runtime_secret_environment(environment: RuntimeEnvironment) -> dict[str, str]:
    env = dict(os.environ)
    if env.get('COMPANY_UI_STORAGE_SECRET'):
        return env
    if environment is RuntimeEnvironment.PROD:
        raise RuntimeError(
            'COMPANY_UI_STORAGE_SECRET is required in production. '
            'Set it to a strong persistent secret in the deployment environment.'
        )
    # Local/test launches need a storage secret for NiceGUI session middleware, but
    # a predictable checked-in fallback is not acceptable. A per-process secret is
    # sufficient outside production; reports persist independently in the repository.
    env['COMPANY_UI_STORAGE_SECRET'] = secrets.token_urlsafe(48)
    return env


def _default_host() -> str:
    return os.getenv('COMPANY_UI_HOST') or os.getenv('HOST') or '0.0.0.0'


def _default_port() -> int:
    raw = os.getenv('COMPANY_UI_PORT') or os.getenv('PORT') or '8080'
    try:
        port = int(raw)
    except ValueError as exc:
        raise RuntimeError(f'Invalid application port: {raw!r}') from exc
    if not 1 <= port <= 65535:
        raise RuntimeError(f'Application port must be 1..65535; received {port}')
    return port


def default_repository_root() -> Path:
    configured = os.getenv('COMPANY_UI_VISUALIZER_DATA_DIR')
    return Path(configured).expanduser() if configured else Path.home() / '.company_ui' / 'visualizer' / 'reports'


def run(*, host: str = '127.0.0.1', port: int = 8080, show: bool = False, repository_root: str | Path | None = None) -> None:
    from nicegui import app, ui

    services = ApplicationServices(
        notifications=NiceGUIStateServices.notification_service(),
        navigation=NiceGUIStateServices.navigation_service(),
        clipboard=NiceGUIStateServices.clipboard_service(),
        downloads=NiceGUIStateServices.download_service(),
    )
    application = ApplicationRuntime(services=services)
    product = register_visualizer(application, repository_root=repository_root or default_repository_root())

    environment = _runtime_environment()
    config = RuntimeConfig(
        app_name='Company UI + Visualizer',
        app_version=f'{FRAMEWORK_VERSION}+visualizer97.1',
        environment=environment,
        host=host,
        port=port,
        title='Company UI · Visualizer',
        show_browser=show,
        reload=False,
    )
    runtime = NiceGUIRuntimeAdapter(config)
    runtime.install_middleware(app)
    runtime.install_operational_endpoints(app)
    register_visualizer_page(application, product)

    # This executable is the dedicated Company UI + Visualizer product host. Keep
    # /visualizer canonical while making the process root useful for publish
    # platforms and users that open the bare host/port. This is product-local and
    # does not change Company UI's inherited route estate.
    from starlette.responses import RedirectResponse

    @app.get('/', include_in_schema=False)
    async def visualizer_root_redirect() -> RedirectResponse:
        return RedirectResponse(url='/visualizer', status_code=307)

    app.on_shutdown(application.aclose)
    kwargs = config.nicegui_run_kwargs(_runtime_secret_environment(environment))
    ui.run(**kwargs)


def main() -> None:
    parser = argparse.ArgumentParser(description='Run Company UI v3 with the Visualizer 97.1 product workspace.')
    parser.add_argument('--host', default=_default_host())
    parser.add_argument('--port', type=int, default=_default_port())
    parser.add_argument('--show', action='store_true')
    parser.add_argument('--data-dir', default=os.getenv('COMPANY_UI_VISUALIZER_DATA_DIR'))
    args = parser.parse_args()
    run(host=args.host, port=args.port, show=args.show, repository_root=args.data_dir)


if __name__ == '__main__':
    main()
