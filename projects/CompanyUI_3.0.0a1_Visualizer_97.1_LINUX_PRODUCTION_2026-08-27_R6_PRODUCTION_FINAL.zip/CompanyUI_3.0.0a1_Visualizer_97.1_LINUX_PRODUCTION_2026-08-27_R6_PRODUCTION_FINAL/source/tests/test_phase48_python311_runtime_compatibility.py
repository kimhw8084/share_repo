from __future__ import annotations

import enum
import inspect
import json
from pathlib import Path

from company_ui import COMPATIBILITY_PATH, VISUAL_ROOT, StateKey, StateNamespace
from company_ui.governance.public_api import public_api_snapshot

ROOT = Path(__file__).resolve().parents[1]


def test_state_key_parameterized_generic_is_runtime_constructible_across_supported_python_range():
    key = StateKey[int]('count', StateNamespace.SESSION, default=0)
    assert key.name == 'count'
    assert key.namespace is StateNamespace.SESSION
    assert key.default == 0


def test_public_api_enum_contract_is_independent_of_interpreter_enum_signature(monkeypatch):
    baseline = public_api_snapshot()
    original = inspect.signature

    def simulated_python311_signature(value):
        if inspect.isclass(value) and issubclass(value, enum.Enum):
            return inspect.Signature([
                inspect.Parameter('value', inspect.Parameter.POSITIONAL_OR_KEYWORD),
                inspect.Parameter('names', inspect.Parameter.POSITIONAL_OR_KEYWORD, default=None),
            ])
        return original(value)

    monkeypatch.setattr(inspect, 'signature', simulated_python311_signature)
    assert public_api_snapshot() == baseline


def test_public_api_path_constants_use_public_pathlib_module_name():
    snapshot = public_api_snapshot()
    assert snapshot['COMPATIBILITY_PATH']['module'] == 'pathlib'
    assert snapshot['VISUAL_ROOT']['module'] == 'pathlib'
    assert isinstance(COMPATIBILITY_PATH, Path)
    assert isinstance(VISUAL_ROOT, Path)


def test_checked_in_public_api_contract_matches_cross_version_normalized_snapshot():
    contract = json.loads((ROOT / 'PUBLIC_API_CONTRACT.json').read_text(encoding='utf-8'))
    assert contract['symbols'] == public_api_snapshot()
