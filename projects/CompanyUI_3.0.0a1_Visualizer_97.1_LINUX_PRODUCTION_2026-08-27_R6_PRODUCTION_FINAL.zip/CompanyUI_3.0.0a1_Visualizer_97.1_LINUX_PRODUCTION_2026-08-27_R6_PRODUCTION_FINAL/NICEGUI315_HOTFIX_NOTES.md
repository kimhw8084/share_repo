# NiceGUI 3.15.0 static-route acceptance hotfix

The second external acceptance launch reached Visualizer page registration and exposed an integration-wrapper API mismatch:

```text
TypeError: App.add_static_files() got an unexpected keyword argument 'follow_symlinks'
```

NiceGUI 3.15.0 defines the keyword as `follow_symlink` (singular), with a default value of `False`. R3 changes only the Company UI Visualizer host wrapper to use that exact pinned API contract. The frozen Visualizer 97.1 authority tree and Golden Connector v5 are unchanged.

New regression/certification protection:

1. `source/tests/test_visualizer_integration.py` calls the static-route helper against a NiceGUI-3.15-compatible signature and rejects the invalid plural keyword.
2. `setup_linux.sh` validates the installed NiceGUI signature and actually registers both Visualizer static routes with the installed wheel before continuing.
3. `tools/verify_package.py` opens the final wheel and rejects the invalid plural keyword.

R3 post-fix estate was 699/699 tests with governance 0/0. R4 supersedes it with the navigation/runtime hardening documented in `NAVIGATION_RUNTIME_HOTFIX_NOTES.md`.
