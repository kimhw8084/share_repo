#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, socket, subprocess, sys, tempfile, time, urllib.error, urllib.request
from pathlib import Path

BROWSERS=(
 '/usr/bin/google-chrome','/usr/bin/google-chrome-stable','/usr/bin/chromium','/usr/bin/chromium-browser',
 '/usr/bin/microsoft-edge','/usr/bin/microsoft-edge-stable',
)

def free_port():
    with socket.socket() as s: s.bind(('127.0.0.1',0)); return s.getsockname()[1]

def http_get(url, timeout=2):
    with urllib.request.urlopen(url,timeout=timeout) as r: return r.status,r.read()

def wait_ready(base, process, seconds=30):
    deadline=time.monotonic()+seconds
    last='not started'
    while time.monotonic()<deadline:
        if process.poll() is not None: raise RuntimeError(f'server exited with {process.returncode}')
        try:
            status,body=http_get(base+'/healthz')
            if status==200: return
            last=f'HTTP {status}: {body[:200]!r}'
        except Exception as exc: last=str(exc)
        time.sleep(.25)
    raise RuntimeError(f'server did not become healthy: {last}')

def browser_path():
    configured=os.environ.get('COMPANY_UI_BROWSER')
    candidates=(([configured] if configured else []) + list(BROWSERS))
    for candidate in candidates:
        if candidate and Path(candidate).is_file() and os.access(candidate,os.X_OK): return candidate
    for name in ('google-chrome','google-chrome-stable','chromium','chromium-browser','microsoft-edge','microsoft-edge-stable'):
        found=shutil.which(name)
        if found: return found
    return None

def main():
    ap=argparse.ArgumentParser(description='Live one-process/one-port Company UI + Visualizer browser certification.')
    ap.add_argument('--output',type=Path,default=Path('evidence_local/live_visualizer_smoke.json'))
    ap.add_argument('--keep-log',action='store_true')
    args=ap.parse_args(); args.output.parent.mkdir(parents=True,exist_ok=True)
    browser=browser_path()
    if browser is None:
        print('FAIL: company-approved Chrome/Chromium/Edge executable not found. Set COMPANY_UI_BROWSER=/absolute/path.',file=sys.stderr); return 2
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print('FAIL: playwright==1.62.0 is required; install requirements-certification.txt',file=sys.stderr); return 2

    port=free_port(); base=f'http://127.0.0.1:{port}'
    with tempfile.TemporaryDirectory(prefix='cui-viz-live-') as td:
        td=Path(td); data=td/'reports'; data.mkdir(); log_path=td/'server.log'
        env=dict(os.environ); env['COMPANY_UI_ENVIRONMENT']='dev'; env['PYTHONUNBUFFERED']='1'
        cmd=[sys.executable,'-m','company_ui.products.visualizer.cli','--host','127.0.0.1','--port',str(port),'--data-dir',str(data)]
        with log_path.open('w',encoding='utf-8') as log:
            process=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
        result={'pass':False,'port':port,'browser':browser,'viewports':{},'server_command':cmd}
        try:
            wait_ready(base,process)
            # urllib follows the product-local 307 redirect; ending at /visualizer with
            # HTTP 200 proves the bare host/port is useful for deployment entry.
            status,_=http_get(base+'/')
            if status != 200: raise AssertionError('/ did not redirect to a healthy /visualizer workspace')
            status,_=http_get(base+'/visualizer')
            if status != 200: raise AssertionError('/visualizer did not return HTTP 200')
            try:
                http_get(base+'/_cui_visualizer/page.py')
                raise AssertionError('Python product source was exposed over static route')
            except urllib.error.HTTPError as exc:
                if exc.code != 404: raise
            for asset in ('/_cui_visualizer/assets/integrated_editor.mjs','/_cui_visualizer/vendor/contracts/component_contracts.json'):
                if http_get(base+asset)[0] != 200: raise AssertionError(f'asset failed: {asset}')

            with sync_playwright() as p:
                launched=p.chromium.launch(headless=True,executable_path=browser,args=['--disable-dev-shm-usage'])
                context=launched.new_context()
                page=context.new_page(); console_errors=[]; page_errors=[]
                page.on('console',lambda msg: console_errors.append(msg.text) if msg.type=='error' else None)
                page.on('pageerror',lambda exc: page_errors.append(str(exc)))
                for name,width,height in (('desktop',1440,1000),('tablet',900,1100),('phone',390,844)):
                    page.set_viewport_size({'width':width,'height':height})
                    page.goto(base+'/visualizer',wait_until='networkidle',timeout=30000)
                    page.wait_for_selector('.cui-visualizer-root',state='visible',timeout=15000)
                    page.wait_for_function("() => window.CompanyUIVisualizerBridge && document.querySelector('#libraryCount')?.textContent.includes('248')",timeout=15000)
                    metrics=page.evaluate("""() => { const root=document.querySelector('.cui-visualizer-root'); const rr=root.getBoundingClientRect(); return {library:document.querySelector('#libraryCount').textContent, revision:window.CompanyUIVisualizerBridge.state().revision, width:rr.width, viewport:innerWidth, document_overflow:document.documentElement.scrollWidth>document.documentElement.clientWidth}; }""")
                    if metrics['document_overflow']: raise AssertionError(f'{name}: document horizontal overflow')
                    result['viewports'][name]=metrics
                # Real semantic mutation: add one component. Browser-local editor changes first;
                # server must then persist an acknowledged revision through the semantic bridge.
                before=page.evaluate('() => window.CompanyUIVisualizerBridge.state().revision')
                page.locator('.pal[data-type="metric"]').first.click()
                page.wait_for_function(f"() => window.CompanyUIVisualizerBridge.state().acknowledged_revision >= {before+1}",timeout=15000)
                after=page.evaluate('() => window.CompanyUIVisualizerBridge.state()')
                report_id=after['report_id']; record_file=data/f'{report_id}.json'
                deadline=time.monotonic()+10
                persisted=None
                while time.monotonic()<deadline:
                    if record_file.is_file():
                        persisted=json.loads(record_file.read_text())
                        if persisted.get('revision',0)>=before+1: break
                    time.sleep(.1)
                if not persisted or persisted.get('revision',0)<before+1: raise AssertionError('semantic commit was not persisted')
                if after['acknowledged_revision'] != persisted['revision']: raise AssertionError('browser/server revision did not converge')
                # Pointer traffic must not advance persisted revision.
                rev=persisted['revision']; page.mouse.move(50,50); page.mouse.move(300,300); time.sleep(.35)
                persisted2=json.loads(record_file.read_text())
                if persisted2['revision'] != rev: raise AssertionError('pointer movement caused a server-bound report mutation')
                context.close(); launched.close()
            if console_errors or page_errors: raise AssertionError(f'browser errors: console={console_errors!r} page={page_errors!r}')
            result.update({'pass':True,'semantic_revision':persisted['revision'],'console_errors':console_errors,'page_errors':page_errors,'python_source_static_status':404})
        except Exception as exc:
            result['error']=f'{type(exc).__name__}: {exc}'
        finally:
            process.terminate()
            try: process.wait(timeout=8)
            except subprocess.TimeoutExpired: process.kill(); process.wait(timeout=5)
            log_text=log_path.read_text(encoding='utf-8',errors='replace') if log_path.exists() else ''
            result['unhandled_python_traceback']='Traceback (most recent call last)' in log_text
            if result.get('pass') and result['unhandled_python_traceback']:
                result['pass']=False; result['error']='Unhandled Python traceback found in server log'
            if args.keep_log:
                dest=args.output.with_suffix('.server.log'); dest.write_text(log_text,encoding='utf-8'); result['server_log']=str(dest)
            args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
        print(json.dumps(result,indent=2,sort_keys=True))
        return 0 if result.get('pass') else 1
if __name__=='__main__': raise SystemExit(main())
