#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil, subprocess, sys, tempfile
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(description='Run frozen Visualizer 97.1 production suite on a temporary copy.')
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]); ap.add_argument('--output',type=Path,default=Path('evidence_local/visualizer_authority_suite.json')); args=ap.parse_args()
    root=args.root.resolve(); vendor=root/'source/company_ui/products/visualizer/vendor/production_core'; args.output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='visualizer97-authority-') as td:
        copy=Path(td)/'15_PRODUCTION_CORE'; shutil.copytree(vendor,copy)
        proc=subprocess.run([sys.executable,'tools/run_production_core_suite.py'],cwd=copy,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        summary={'pass':proc.returncode==0,'returncode':proc.returncode,'source_authority':str(vendor),'executed_copy':str(copy),'output_tail':proc.stdout[-12000:]}
        suite=copy/'qa/full_suite.json'
        if suite.exists():
            try: summary['suite']=json.loads(suite.read_text())
            except Exception: pass
        args.output.write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
        print(proc.stdout,end='')
        print(f'Authority suite evidence: {args.output}')
        return proc.returncode
if __name__=='__main__': raise SystemExit(main())
