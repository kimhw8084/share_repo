#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re, sys, zipfile
from pathlib import Path

GOLDEN='d8ebd4378f01b7c52a7a4be57c578c22adf29b899cc08a370cf084881195343e'

def digest(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def main() -> int:
    ap=argparse.ArgumentParser(); ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]); args=ap.parse_args()
    root=args.root.resolve(); source=root/'source'; product=source/'company_ui/products/visualizer'; vendor=product/'vendor/production_core'
    failures=[]
    for tool in ('verify_nicegui315_runtime_surface.py','live_startup_smoke.py','headless_browser_startup_smoke.py'):
        if not (root/'tools'/tool).is_file(): failures.append(f'missing runtime certification tool: {tool}')
    publish_entry = root / 'visualizer_app.py'
    if not publish_entry.is_file():
        failures.append('root visualizer_app.py publish entrypoint missing')
    else:
        publish_source = publish_entry.read_text(encoding='utf-8')
        if "SOURCE = ROOT / 'source'" not in publish_source or 'sys.path.insert(0, str(SOURCE))' not in publish_source:
            failures.append('publish entrypoint does not prefer bundled audited source')
        if 'company_ui.products.visualizer.cli import main' not in publish_source:
            failures.append('publish entrypoint does not invoke governed Visualizer CLI')
    setup_source = (root/'setup_linux.sh').read_text(encoding='utf-8')
    if 'verify_checksums.sh' not in setup_source or 'pip check' not in setup_source or '--source-entrypoint' not in setup_source:
        failures.append('setup_linux.sh is missing fail-closed integrity/dependency/publish-entrypoint gates')
    runtime=[line.strip() for line in (root/'requirements.txt').read_text().splitlines() if line.strip() and not line.lstrip().startswith('#')]
    expected=['nicegui==3.15.0','python-pptx==1.0.2']
    if runtime != expected: failures.append(f'root requirements mismatch: {runtime!r}')
    source_runtime=[line.strip() for line in (source/'requirements.txt').read_text().splitlines() if line.strip() and not line.lstrip().startswith('#')]
    if source_runtime != ['nicegui==3.15.0']: failures.append('inherited source requirements contract changed')
    manifest=json.loads((product/'VENDOR_MANIFEST_SHA256.json').read_text())
    actual={p.relative_to(vendor).as_posix():digest(p) for p in sorted(vendor.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
    if actual != manifest['files']: failures.append('vendored Visualizer authority differs from frozen manifest')
    connector=vendor/'core/GOLDEN_CONNECTOR_ENGINE_V5_FROZEN.js'
    if digest(connector) != GOLDEN: failures.append('Golden Connector v5 hash mismatch')
    registry=json.loads((vendor/'contracts/runtime_registry.json').read_text())
    if registry.get('elements') != 248 or registry.get('engines') != 17: failures.append('Visualizer registry is not 248 elements / 17 engines')
    contracts=json.loads((vendor/'contracts/component_contracts.json').read_text()).get('contracts',[])
    if len(contracts) != 248: failures.append('Visualizer component contract count is not 248')
    wheel=next((root/'wheel').glob('company_ui-3.0.0a1-*.whl'),None)
    if wheel is None: failures.append('application wheel missing')
    else:
        with zipfile.ZipFile(wheel) as z:
            names=set(z.namelist())
            required_suffixes=('assets/integrated_editor.mjs','VENDOR_MANIFEST_SHA256.json','core/GOLDEN_CONNECTOR_ENGINE_V5_FROZEN.js','contracts/component_contracts.json')
            for suffix in required_suffixes:
                if not any(n.endswith(suffix) for n in names): failures.append(f'wheel missing {suffix}')
            page_name=next((n for n in names if n.endswith('company_ui/products/visualizer/page.py')),None)
            if page_name is None:
                failures.append('wheel missing Visualizer page module')
            else:
                page_source=z.read(page_name).decode('utf-8')
                if 'follow_symlinks=' in page_source:
                    failures.append('wheel contains invalid NiceGUI follow_symlinks keyword')
                if 'follow_symlink=False' not in page_source:
                    failures.append('wheel missing pinned NiceGUI 3.15 follow_symlink contract')
                if "icon='chart-line'" not in page_source or "icon='chart'" in page_source:
                    failures.append('wheel Visualizer navigation icon is not a governed chart-line icon')
                if "icon='add'" not in page_source or "icon='plus'" in page_source:
                    failures.append('wheel Visualizer control icon is not the canonical governed add icon')
                if ".element('summary').classes('cui-visualizer-import-summary').set_text" in page_source:
                    failures.append('wheel contains unsupported generic Element.set_text usage')
                if "ui.html('Import / PowerPoint template', tag='summary')" not in page_source:
                    failures.append('wheel missing NiceGUI 3.15-compatible semantic summary rendering')
            # The audited source and the installable wheel must be the same product, not merely similar.
            # Compare every Python module and every Visualizer package-data file byte-for-byte.
            for src_file in sorted((source/'company_ui').rglob('*.py')):
                if '__pycache__' in src_file.parts:
                    continue
                member=src_file.relative_to(source).as_posix()
                if member not in names:
                    failures.append(f'wheel missing source module {member}')
                elif z.read(member) != src_file.read_bytes():
                    failures.append(f'wheel/source byte mismatch: {member}')
            visualizer_root=source/'company_ui/products/visualizer'
            for src_file in sorted(visualizer_root.rglob('*')):
                if not src_file.is_file() or '__pycache__' in src_file.parts or src_file.suffix == '.pyc':
                    continue
                member=src_file.relative_to(source).as_posix()
                if member not in names:
                    failures.append(f'wheel missing Visualizer package data {member}')
                elif z.read(member) != src_file.read_bytes():
                    failures.append(f'wheel/source Visualizer byte mismatch: {member}')

            cli_name=next((n for n in names if n.endswith('company_ui/products/visualizer/cli.py')),None)
            if cli_name is None:
                failures.append('wheel missing Visualizer CLI module')
            else:
                cli_source=z.read(cli_name).decode('utf-8')
                if "@app.get('/', include_in_schema=False)" not in cli_source or "RedirectResponse(url='/visualizer', status_code=307)" not in cli_source:
                    failures.append('wheel missing product-root redirect to /visualizer')
    if failures:
        print(json.dumps({'pass':False,'failures':failures},indent=2)); return 1
    print(json.dumps({'pass':True,'runtime_requirements':runtime,'vendor_files':len(actual),'visualizer_elements':248,'visualizer_engines':17,'golden_connector_sha256':GOLDEN,'wheel':wheel.name if wheel else None},indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
