#!/usr/bin/env python3
from __future__ import annotations

import inspect
import json
from importlib.metadata import version

from nicegui import app, ui

EXPECTED = '3.15.0'

def require_params(name, callable_, required=(), forbidden=()):
    sig = inspect.signature(callable_)
    params = sig.parameters
    missing = [p for p in required if p not in params]
    bad = [p for p in forbidden if p in params]
    if missing or bad:
        raise SystemExit(f'{name} signature mismatch: {sig}; missing={missing}; forbidden_present={bad}')
    return str(sig)

def main() -> int:
    installed = version('nicegui')
    if installed != EXPECTED:
        raise SystemExit(f'NiceGUI {EXPECTED} required; installed={installed}')

    checks = {
        'app.add_static_files': require_params('app.add_static_files', app.add_static_files, ('url_path','local_directory','follow_symlink'), ('follow_symlinks',)),
        'ui.html': require_params('ui.html', ui.html, ('content','sanitize','tag')),
        'ui.select': require_params('ui.select', ui.select, ('options','value','label','on_change')),
        'ui.upload': require_params('ui.upload', ui.upload, ('on_upload','max_file_size','max_files')),
        'ui.add_head_html': require_params('ui.add_head_html', ui.add_head_html, ('html','shared')),
        'ui.add_body_html': require_params('ui.add_body_html', ui.add_body_html, ('html','shared')),
        'ui.add_css': require_params('ui.add_css', ui.add_css, ('css','shared')),
        'ui.run_javascript': require_params('ui.run_javascript', ui.run_javascript, ('code','timeout')),
        'ui.button': require_params('ui.button', ui.button, ('on_click',)),
        'ui.item': require_params('ui.item', ui.item, ('on_click',)),
        'ui.link': require_params('ui.link', ui.link, ('text','target')),
        'ui.query': require_params('ui.query', ui.query, ('selector',)),
        'ui.download': require_params('ui.download', ui.download, ('src','filename','media_type')),
        'ui.element.on': require_params('ui.element.on', ui.element.on, ('type','handler','args')),
    }
    if hasattr(ui.element, 'set_text'):
        raise SystemExit('Unexpected NiceGUI surface: generic ui.element exposes set_text')
    if not hasattr(ui.label, 'set_text'):
        raise SystemExit('NiceGUI label no longer exposes set_text')
    # APIs traversed by the Visualizer AppShell before the editor host is built.
    for name in ('element','label','button','row','column','item','item_section','item_label','badge','link','query','page','upload','select'):
        if not callable(getattr(ui, name, None)):
            raise SystemExit(f'NiceGUI ui.{name} is unavailable')
    for cls_name, cls in (('element', ui.element), ('button', ui.button), ('upload', ui.upload), ('select', ui.select)):
        for method in ('classes','props','on','update'):
            if not hasattr(cls, method):
                raise SystemExit(f'NiceGUI ui.{cls_name} missing element method {method}')
    for cls_name, cls in (('button', ui.button), ('upload', ui.upload)):
        if not hasattr(cls, 'disable'):
            raise SystemExit(f'NiceGUI ui.{cls_name} missing disable()')
    if not callable(getattr(getattr(ui, 'navigate', None), 'to', None)):
        raise SystemExit('NiceGUI ui.navigate.to is unavailable')
    if not callable(getattr(getattr(ui, 'clipboard', None), 'write', None)):
        raise SystemExit('NiceGUI ui.clipboard.write is unavailable')

    print(json.dumps({'pass': True, 'nicegui': installed, 'surface': checks, 'generic_element_set_text': False, 'label_set_text': True}, indent=2, sort_keys=True))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
