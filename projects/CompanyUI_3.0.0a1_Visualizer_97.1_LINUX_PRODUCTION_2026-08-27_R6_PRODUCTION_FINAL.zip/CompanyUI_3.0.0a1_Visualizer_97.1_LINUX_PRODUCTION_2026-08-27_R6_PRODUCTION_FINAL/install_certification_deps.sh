#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="${COMPANY_UI_VENV:-$ROOT/.venv}"
[ -x "$VENV/bin/python" ] || { echo 'Run ./setup_linux.sh first.' >&2; exit 1; }
"$VENV/bin/python" -m pip install -r "$ROOT/requirements-certification.txt"
"$VENV/bin/python" - <<'PY'
from importlib.metadata import version
for p,w in {'playwright':'1.62.0','Pillow':'12.3.0'}.items():
    got=version(p)
    if got!=w: raise SystemExit(f'{p}: expected {w}, installed {got}')
    print(f'[PASS] {p} {got}')
PY
