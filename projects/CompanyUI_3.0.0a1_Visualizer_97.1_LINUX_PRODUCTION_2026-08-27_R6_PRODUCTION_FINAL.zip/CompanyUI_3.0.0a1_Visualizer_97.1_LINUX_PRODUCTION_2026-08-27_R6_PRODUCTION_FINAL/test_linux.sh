#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="${COMPANY_UI_VENV:-$ROOT/.venv}"
[ -x "$VENV/bin/python" ] || { echo 'Run ./setup_linux.sh first.' >&2; exit 1; }
mkdir -p "$ROOT/evidence_local"
"$ROOT/install_certification_deps.sh"
"$VENV/bin/python" "$ROOT/tools/verify_package.py" --root "$ROOT" | tee "$ROOT/evidence_local/package_verification.json"
"$VENV/bin/python" "$ROOT/tools/verify_nicegui315_runtime_surface.py" | tee "$ROOT/evidence_local/nicegui315_runtime_surface.json"
"$VENV/bin/python" "$ROOT/tools/live_startup_smoke.py" --output "$ROOT/evidence_local/live_startup_smoke.json"
"$VENV/bin/python" "$ROOT/tools/live_startup_smoke.py" --source-entrypoint --output "$ROOT/evidence_local/publish_entrypoint_smoke.json"
"$VENV/bin/python" "$ROOT/tools/headless_browser_startup_smoke.py" --require-browser --output "$ROOT/evidence_local/headless_browser_startup_smoke.json"
(
  cd "$ROOT/source"
  "$VENV/bin/python" -m pytest -q
  "$VENV/bin/python" -m company_ui.governance.cli --root .
)
"$VENV/bin/company-ui" runtime-contract --format json | tee "$ROOT/evidence_local/runtime_contract.json"
"$VENV/bin/company-ui" doctor --ignore-port --port "${COMPANY_UI_PORT:-8080}" --format json | tee "$ROOT/evidence_local/runtime_doctor.json"
"$VENV/bin/company-ui" runtime-smoke --output "$ROOT/evidence_local/runtime_smoke" --port 0 --format json | tee "$ROOT/evidence_local/runtime_smoke.json"
"$VENV/bin/python" "$ROOT/tools/run_visualizer_authority_suite.py" --root "$ROOT" --output "$ROOT/evidence_local/visualizer_authority_suite.json"
"$VENV/bin/python" "$ROOT/tools/live_visualizer_smoke.py" --output "$ROOT/evidence_local/live_visualizer_smoke.json" --keep-log
printf '\nALL LINUX CERTIFICATION GATES PASSED. Evidence: %s/evidence_local\n' "$ROOT"
