#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
if command -v sha256sum >/dev/null 2>&1; then
  sha256sum -c SHA256SUMS.txt
elif command -v shasum >/dev/null 2>&1; then
  shasum -a 256 -c SHA256SUMS.txt
else
  echo 'No SHA-256 verifier found (need sha256sum or shasum).' >&2
  exit 1
fi
