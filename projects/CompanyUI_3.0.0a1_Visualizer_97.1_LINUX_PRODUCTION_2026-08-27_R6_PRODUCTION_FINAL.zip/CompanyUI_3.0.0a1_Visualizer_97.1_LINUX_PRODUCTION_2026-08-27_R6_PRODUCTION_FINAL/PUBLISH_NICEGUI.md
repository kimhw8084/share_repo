# NiceGUI company publish — production entry

Use the package root as the project/workspace.

**Python/main file to select:** `visualizer_app.py`

**Requirements file:** `requirements.txt`

The publisher should run the selected Python file after installing `requirements.txt`. `visualizer_app.py` intentionally prepends the bundled audited `source/` tree, so publishing does **not** depend on the local wheel being preinstalled.

## Environment

The app supports both Company UI names and common hosting variables:

- host: `COMPANY_UI_HOST`, then `HOST`, otherwise `0.0.0.0`
- port: `COMPANY_UI_PORT`, then `PORT`, otherwise `8080`
- report persistence: `COMPANY_UI_VISUALIZER_DATA_DIR`
- runtime environment: `COMPANY_UI_ENVIRONMENT` (`dev`, `test`, `qa`, `prod`; `production` is accepted as an alias)
- production storage secret: `COMPANY_UI_STORAGE_SECRET`

For `COMPANY_UI_ENVIRONMENT=prod`, `COMPANY_UI_STORAGE_SECRET` is mandatory and startup fails closed when it is absent. Store it as a protected deployment secret, not in source control.

For durable production reports, set `COMPANY_UI_VISUALIZER_DATA_DIR` to an approved persistent volume/path.

Canonical workspace: `/visualizer`. `/` redirects to `/visualizer`.
