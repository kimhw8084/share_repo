# Company UI 3.0.0a1 + Visualizer 97.1 — R6 production final

R6 is the deployment build. Discard R1-R5.

This package contains the Company UI v3 host plus the Visualizer 97.1 production editor at `/visualizer`, with the frozen 248-element / 17-engine Visualizer authority preserved.

## Production runtime

- Python `>=3.11,<3.14`
- NiceGUI **exactly `3.15.0`**
- `python-pptx==1.0.2`
- one process / one port
- local browser assets / no CDN
- no runtime Node dependency
- package-root `requirements.txt` is the authoritative production dependency file

## Clean work-PC install and acceptance

Extract R6 into a new directory. Do not reuse an older revision's `.venv`.

```bash
chmod +x *.sh
./setup_linux.sh
```

`setup_linux.sh` is fail-closed. Before it prints `Setup complete`, it:

1. verifies the package-wide SHA-256 manifest;
2. validates Python support;
3. creates/uses the package virtual environment;
4. installs the root `requirements.txt`;
5. force-installs the supplied application wheel;
6. runs `pip check`;
7. verifies exact NiceGUI / python-pptx / Company UI versions;
8. verifies Python 3.11-compatible `StateKey[T]` construction;
9. verifies the actual installed NiceGUI 3.15.0 runtime API;
10. verifies governed Visualizer icons and frozen authority/package integrity;
11. starts the **installed wheel** on a temporary port and requires `/visualizer` HTTP 200, correct root redirect, editor assets, 248/17 registry, no exposed Python source and no server traceback/500;
12. repeats that real HTTP render through the **root `visualizer_app.py` publish entrypoint**;
13. when Chrome/Chromium/Edge is present, boots the real retained editor headlessly and requires the 248/248 QA-ready state;
14. runs Company UI's runtime contract and doctor.

Only after setup passes, run:

```bash
./run_visualizer.sh
```

Open:

```text
http://127.0.0.1:8080/visualizer
```

For the complete regression/certification estate:

```bash
./test_linux.sh
```

This adds certification-only dependencies and runs the inherited Company UI estate, governance, 22-route runtime smoke, frozen Visualizer authority suite from a temporary copy, and live desktop/tablet/phone integration certification. Evidence is written to `evidence_local/`.

## Company NiceGUI publish

When the publishing UI asks for **one Python/main file**, select:

```text
visualizer_app.py
```

When it asks for the requirements file, select/use:

```text
requirements.txt
```

`visualizer_app.py` runs the bundled audited `source/` tree directly, so the company publisher does not need to install the supplied wheel first. Common hosting `HOST` and `PORT` environment variables are supported, with Company UI-specific variables taking precedence.

See `PUBLISH_NICEGUI.md` for production environment settings.

## Production environment

Recommended deployment variables:

```bash
export COMPANY_UI_ENVIRONMENT=prod
export COMPANY_UI_STORAGE_SECRET='set-this-in-the-platform-secret-store'
export COMPANY_UI_VISUALIZER_DATA_DIR=/approved/persistent/company-ui/visualizer/reports
```

Production mode fails closed without `COMPANY_UI_STORAGE_SECRET`; the package no longer contains a predictable runtime secret fallback. Report data should point to an approved durable volume/path.

For local acceptance, `run_visualizer.sh` intentionally binds to `127.0.0.1`. The company publish entrypoint defaults to `0.0.0.0` (or platform `HOST`) so it is reachable inside a deployment container.

## PowerPoint

Upload the user's existing `.pptx` through **Import / PowerPoint template**, then export from the Visualizer toolbar. The integration:

- validates PPTX ZIP structure and bounded expansion before parsing;
- selects the governed target region (`VISUALIZER_CONTENT`, explicit region, compatible placeholder, then safe middle region);
- preserves surrounding template content;
- emits native/editable PowerPoint objects where practical;
- preserves numeric zero vs missing data;
- never invents dates for sequence-only timelines;
- never rasterizes the whole report as a shortcut.

## Persistence and report state

Default local report storage:

```text
~/.company_ui/visualizer/reports
```

Override with `COMPANY_UI_VISUALIZER_DATA_DIR` or `--data-dir`.

Report writes are deterministic and atomic. Browser/server report mutations are revision-aware. High-frequency drag, resize, hover, pointer, connector routing and virtual-scroll frame traffic remains browser-side.

## Final certification state

- **709/709 tests passing**
- governance **0 errors / 0 warnings**
- Company UI visual coverage **183/183**
- Visualizer **248/248 elements**
- Visualizer **17/17 engines**
- Visualizer authority suite **27/27 gates**
- frozen vendor **123/123 files** verified
- Golden Connector v5 SHA-256 `d8ebd4378f01b7c52a7a4be57c578c22adf29b899cc08a370cf084881195343e`
- retained editor assets byte-identical to the desktop/tablet/phone browser-certified set
- audited source and shipped wheel byte-parity verified

See `PRODUCTION_SIGNOFF.md` and `evidence/CERTIFICATION_SUMMARY.json`.
