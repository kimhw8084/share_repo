# Do Not Regress

1. NiceGUI application startup/setup paths must keep working.
2. Existing atomic revision-aware report repository behavior must remain.
3. Existing report files must load; migration is automatic and idempotent.
4. Existing selection, multi-selection, drag, resize, nudge, layer, lock, group, zoom, preview, undo/redo must remain functional.
5. Never create a second independent undo stack for data operations.
6. Preserve distinction between missing value and numeric zero.
7. Do not expose EditorInfrastructure as report content.
8. Do not expose InteractionLayer behaviors as independent report content after compatible behavior attachment exists.
9. Do not add more catalog entries during this program.
10. Do not solve canonicalization by deleting legacy aliases needed to load old reports/templates.
11. Do not replace proven production_core calculations with simplified approximations.
12. Do not allow specialized renderer fixtures to ignore editable semantic data.
13. Do not make the Inspector the only way to edit visible properties.
14. Do not use a blocking modal for routine paste/mapping when inline/contextual UI is sufficient.
15. Do not copy full shared datasets into every visual item.
16. Do not store huge redundant undo snapshots when a transactional delta/reference suffices.
17. Do not silently discard invalid rows/columns.
18. Do not silently coerce IDs such as `0012` into number 12 when profile confidence is insufficient.
19. Do not make users manually reshape wide/long data for common visual contracts.
20. Do not declare completion solely from existing release/catalog tests; new authoring gates are required.
