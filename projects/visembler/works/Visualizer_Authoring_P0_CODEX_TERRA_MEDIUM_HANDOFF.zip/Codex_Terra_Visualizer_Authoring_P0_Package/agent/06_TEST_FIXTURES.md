# Minimal High-Value Test Fixtures

Use these shapes to cover most inference/paste regressions without huge test payloads.

## F1 — Headered categorical/value
```text
Tool\tYield
T01\t94.2
T02\t91.8
T03\t95.0
```
Expect header=true, Tool categorical/identifier, Yield number; bar/table candidates.

## F2 — Headerless numeric
```text
1\t10
2\t20
3\t30
```
Expect row 1 preserved as data; no unconditional header consumption.

## F3 — Wide time series
```text
Date\tTool A\tTool B
2026-08-01\t94.2\t91.7
2026-08-02\t95.0\t92.5
```
Expect Date -> time/x and two y/series fields; multi-line candidate; automatic wide-to-series mapping or non-destructive unpivot recipe.

## F4 — Scatter/bubble
```text
CD\tYield\tDefects\tTool
42.1\t94.2\t12\tT01
43.0\t91.8\t31\tT02
```
Expect numeric X/Y, Defects size candidate, Tool color/category candidate.

## F5 — Semiconductor wafer
```text
LOT_ID\tWAFER_ID\tTOOL_ID\tCHAMBER\tDIE_X\tDIE_Y\tCD\tTIMESTAMP
L100\tW01\tT01\tA\t-1\t2\t42.3\t2026-08-01 12:00:00
L100\tW01\tT01\tA\t0\t2\t42.9\t2026-08-01 12:00:01
```
Expect lot/wafer/tool/chamber/die_x/die_y/value/time semantics; wafer map recommendation.

## F6 — SPC
```text
Time\tSubgroup\tMeasurement\tLSL\tUSL
2026-08-01 08:00\t1\t10.2\t9.5\t10.5
2026-08-01 08:01\t1\t10.1\t9.5\t10.5
2026-08-01 09:00\t2\t10.4\t9.5\t10.5
```
Expect engineering/SPC mapping; correct subgroup/spec roles.

## F7 — Quoted CSV
```text
Name,Comment,Value
A,"contains, comma",1
B,"quoted ""value""",0
C,,
```
Expect comma inside quote preserved; numeric zero distinct from blank.

## F8 — Leading-zero identifiers
```text
Wafer\tValue
0012\t42.1
0013\t43.0
```
Expect Wafer identifier/string, not integer coercion.

## F9 — Mixed invalid time
```text
Timestamp\tValue
2026-08-01\t1
bad-date\t2
2026-08-03\t3
```
Expect warning referencing bad row, no silent deletion.

## F10 — Sankey/flow
```text
Source\tTarget\tWeight
Etch\tClean\t100
Clean\tMetrology\t95
```
Expect source/target/weight roles and flow recommendation.
