# Authoritative Execution Spec

## 1. Outcome
The application must beat Excel/PowerPoint/Spotfire for the **specific report-authoring loop**, not by copying their full feature sets.

Target common path:

1. User copies spreadsheet/query data.
2. User pastes on blank canvas or selected visual.
3. App profiles fields and infers semantic roles.
4. Clean data produces a valid visualization immediately or after one tiny contextual choice.
5. User edits data in an integrated Data Dock and edits visible labels/titles directly.
6. User switches compatible visual types without losing dataset, mapping, transforms, style, or placement.
7. Multiple visuals can share the same dataset.
8. Copy/paste, undo/redo, save/reload, and export preserve semantics.

## 2. Hard product laws
1. Paste first, configure second.
2. Infer reliable information; ask only for unresolved semantics.
3. Never require palette choice before data can be understood.
4. Data entered once is reusable by many visuals.
5. View conversion preserves data/mapping/style wherever compatible.
6. Data replacement does not destroy visual formatting.
7. Visible editable content is directly editable where practical.
8. Standard clipboard semantics stay standard.
9. Ambiguity uses a micro-choice, never a large modal by default.
10. Complexity is progressively disclosed.
11. No inspector/edit field may silently do nothing.
12. Named analytical methods must perform the named method.
13. Transforms are non-destructive and reversible.
14. Destructive operations are undoable.
15. Common workflows need no documentation.

## 3. Current verified defects to fix, not rediscover
- 248 catalog entries do not equal 248 usable authoring systems.
- 155/248 specialized outputs were found non-reactive to semantic/config edits in the prior audit.
- Current direct paste is engine-specific:
  - CoreChartEngine => first 2 columns become label/value.
  - EngineeringChartEngine => label/value observations.
  - WaferFabEngine => first 3 columns become x/y/value.
  - TableEngine => first pasted row is assumed headers.
  - MatrixEngine => raw matrix.
  - most families have no universal canvas paste path.
- `parseGridText` currently chooses only tab vs comma and does not perform robust profiling/header/type inference.
- Existing interaction handlers and current integrated renderer are split across runtime paths.
- EditorInfrastructure and InteractionLayer catalog entries are not legitimate report content.
- SmartLayout entries are visual mockups, not true containers.
- Matrix, Diagram, Wafer/Fab, many specialty Tables/Timelines/Composites do not have complete inspector→model→renderer binding.
- Existing QA emphasizes registry/markup/geometry and can pass while authoring semantics remain broken.

## 4. Architecture to build
### 4.1 DatasetStore
Report owns datasets independently of visual items.

Visual item stores:
- `dataset_id`
- `mapping`
- `transform_recipe_id` or inline immutable recipe reference
- `view_type` / subtype
- visual/style/layout configuration

Raw row data should not be duplicated into each linked visual after migration.

### 4.2 Typed DataFrame-like schema
Each dataset has:
- stable dataset id/name
- ordered fields with stable field ids
- display name
- inferred/declared type
- semantic tags
- nullable/missing statistics
- rows or storage reference
- source metadata
- revision

### 4.3 Data Contract Registry
Every canonical visual declares:
- required roles
- optional roles
- accepted field types
- min/max cardinality if relevant
- aliases/semantic hints
- default aggregations
- validation
- compatible views/conversions
- renderer adapter

### 4.4 Universal Intake
One parser/profiler handles clipboard and imported tabular text before any engine-specific logic.

Output is `IntakeResult`:
- normalized cells
- delimiter/source format
- header confidence
- field profiles
- warnings
- row/column counts
- candidate semantic mappings
- candidate visual recommendations

### 4.5 Field roles
Canonical role vocabulary should cover at least:
`category, x, y, value, series, color, size, label, facet, tooltip, weight, source, target, time, subgroup, lower_limit, upper_limit, specification_low, specification_high, wafer_id, lot_id, tool, chamber, recipe, product, die_x, die_y, bin, status`.

### 4.6 Data Dock
Lightweight spreadsheet editor, not full Excel replacement:
- virtualized rows
- cell/multi-cell selection
- keyboard navigation
- copy/paste
- row/column add/delete
- rename field
- type override
- sort/filter/find
- missing-value visibility
- live visual updates
- field-role chips and drag/drop mapping

### 4.7 Transform recipes
Non-destructive operations:
filter, sort, group, aggregate, pivot, unpivot, split, combine, derive, bin, rank, cumulative, normalize, date extraction.
Represent as serializable ordered recipes and apply deterministically.

### 4.8 Visual conversion
Changing compatible view preserves dataset + mapping + transforms + style/layout. If a target needs one unresolved role, show a tiny mapping prompt with suggestions.

### 4.9 Clipboard semantics
Normal copy/paste plus Paste Special:
- everything
- data only
- mapping only
- style only
- replace data
- append data
- linked duplicate
- independent duplicate

### 4.10 Semiconductor inference
Recognize aliases for lot/wafer/tool/equipment/chamber/recipe/step/operation/process/product/die x/y/bin/defect/yield/measurement/spec limits/timestamp. Recommend Wafer/Fab/Engineering views deterministically from recognized schema.

## 5. Implementation order
Execute `01_TASK_GRAPH.json`. High-level order:

A. Core data model + migration + persistence compatibility.
B. Universal parser/profiler/intake.
C. Data contracts + inference + recommendations.
D. Universal paste dispatcher.
E. Data Dock + mappings.
F. Visual conversion + direct editing + semantic clipboard.
G. Canonical family adapters/rebuilds.
H. Semiconductor workflows.
I. Export parity + comprehensive QA.

Do not rebuild 248 individual editors before A–F exist.

## 6. Compatibility strategy
- Keep current report schema loadable.
- Add migration on canonicalization/load; do not require manual conversion.
- Preserve legacy item data long enough to round-trip during migration.
- New writes should converge toward datasets + mappings.
- Catalog aliases may remain for old reports/templates even when no longer shown in the palette.
- Do not delete production_core engines until replacements pass equivalent gates.

## 7. Performance constraints
- Parsing/profiling must be bounded; large pastes must not freeze UI.
- Data Dock must virtualize large datasets.
- Renderer updates should depend on dataset revision/mapping, not repaint the full editor unnecessarily.
- Avoid copying large datasets into undo history; store transaction deltas/references where possible.
- Keep save payload within existing model size safeguards or intentionally extend storage design with tests.

## 8. Stop conditions
Do not declare P0 complete until all P0 acceptance gates in `04_ACCEPTANCE_GATES.md` pass. Existing legacy tests passing is necessary but not sufficient.
