# Code Map — Read These Hotspots, Do Not Re-discover

Paths below are inside the unzipped `CURRENT_CODEBASE.zip` under `source/`.

## Primary editor/runtime
### `company_ui/products/visualizer/assets/integrated_editor.mjs`
Current key regions/functions:
- `parseDelimitedLine`, `parseGridText`, `parsePairs`, `parseTable`, `parseObservations` around current data parsing/editor code.
- `semanticInspectorMarkup(entry)` creates engine-specific editor controls.
- `tableInspectorMarkup(entry)` is current small table editor.
- `parsePaste(txt)` / `pasteToSelection(txt)` around lines ~1202+ are the current engine-specific clipboard bottleneck.
- `pasteImage(file)` handles image clipboard path.
- window `paste` event near ~1407 currently only routes image or text to selected item.
- `commitOps(...)`/undo system is the correct transaction path to preserve; integrate dataset transactions with it rather than creating a second undo system.
- `renderInspector`, `reconcileCanvas`, `renderGeometryOnly` are update surfaces; avoid global rerenders for simple data edits.

Known current paste branches:
- CoreChartEngine: `row[0]` label + `row[1]` value.
- TableEngine: pasted row 0 headers.
- MatrixEngine: matrix cells.
- EngineeringChartEngine: label/value.
- WaferFabEngine: x/y/value.

Replace this branching with universal intake + contract-based dispatch.

### `company_ui/products/visualizer/assets/element_renderer.mjs`
Current integrated renderer. New canonical adapters must consume dataset views/mappings. Do not keep adding per-element sample fixtures disconnected from semantic data.

### `company_ui/products/visualizer/assets/integrated_editor.html/css`
Add Data Dock and compact mapping UI here. Keep canvas usable at common laptop/desktop sizes and preserve existing resize/selection behavior.

## Persistence/backend
### `company_ui/products/visualizer/domain.py`
- `canonical_model(...)`
- `validate_model(...)`
- `ReportRecord`

Add dataset/mapping migration and validation here while retaining old report compatibility. Watch existing model byte limit.

### `company_ui/products/visualizer/repository.py`
Atomic revision-aware persistence is good. Do not replace it. Dataset changes still commit through the report model/revision contract unless storage is intentionally split with compatibility tests.

### `company_ui/products/visualizer/ppt_service.py`
Current export collapses many specialized semantics into generic chart/table/KPI/text. Later task: export from canonical dataset+mapping representation and preserve specialty results where supported.

## Catalog/contracts
### `company_ui/products/visualizer/contracts/ELEMENT_CAPABILITY_MATRIX.json`
Large catalog. Do not read entire file at startup. Query only needed families/elements.

### `company_ui/products/visualizer/vendor/production_core/contracts/component_contracts.json`
Very large. Search targeted components only.

## Production-core engines worth reusing
- `vendor/production_core/core/editor_store.mjs`
- `data_grid_engine.mjs`
- `core_chart_engine.mjs`
- `advanced_chart_engine.mjs`
- `statistics_engine.mjs`
- `engineering_chart_engine.mjs`
- `wafer_fab_engine.mjs`
- `graph_semantics_engine.mjs`
- `timeline_semantics_engine.mjs`
- `table_pivot_engine.mjs`
- `grid_layout_engine.mjs`

Validate behavior before reuse, but prefer adapters over rewriting proven calculations.

## Existing tests/gates
Relevant current tests include:
- `tests/test_visualizer_r13_uiux.py`
- `tests/test_visualizer_r14_release.py`
- `tools/r13_catalog_render_audit.py`
- `tools/r13_element_capabilities.py`
- `tools/r14_content_torture.py`
- `tools/r14_performance_certification.py`
- production_core engine tests under `vendor/production_core/tests/`

Add new P0 authoring tests; do not treat catalog-render success as proof of semantic usability.
