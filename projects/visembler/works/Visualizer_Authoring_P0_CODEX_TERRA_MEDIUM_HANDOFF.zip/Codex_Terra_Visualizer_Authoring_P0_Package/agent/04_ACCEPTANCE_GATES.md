# Acceptance Gates

## Gate philosophy
An element/view is not implemented because it renders HTML. It is implemented only when its applicable **authoring loop** passes.

## P0 global gates
### G1 — Universal clean paste
Given ordinary Excel/TSV/CSV copied data on a blank canvas:
- parser detects rows/columns/types/likely header;
- a dataset is created;
- at least one valid recommended visualization is available;
- common unambiguous shapes render immediately or after <=1 contextual selection;
- operation is undoable.

### G2 — Selected visual paste
Pasting compatible data onto a selected canonical visual:
- replaces/creates its dataset safely;
- infers compatible mapping;
- preserves layout/style;
- never silently truncates columns to hard-coded first-two/first-three rules.

### G3 — Shared dataset
Two or more visuals can reference one dataset. Editing the dataset updates all dependent visuals while preserving independent visual configuration.

### G4 — Typed schema
Verify integer, float, scientific notation, percent, currency-like text, Boolean, datetime/date, categorical IDs, blank/null, numeric zero, mixed columns. Blank and 0 must remain distinct.

### G5 — Header inference
Headered and headerless input both work. Row 1 must not always be consumed as headers.

### G6 — Delimiter/source robustness
At minimum TSV, CSV, semicolon; quoted delimiters; CRLF/LF; trailing newline; clipboard `text/plain`. Prefer `text/html` enhancement only with robust fallback.

### G7 — Mapping
Required roles are visible and editable; type-incompatible drops are rejected or converted with an explicit explanation. Mapping changes update the visual immediately.

### G8 — Data Dock
Keyboard cell navigation, multi-cell copy/paste, add/delete row/column, rename, sort/filter, and live visual update work. Large tables use virtualization and do not make the whole page sluggish.

### G9 — Conversion
Switching between compatible views preserves dataset, compatible mappings, transforms, placement, and style. Missing required roles trigger a micro-choice, not recreation.

### G10 — Direct edit
Text, titles, KPI values/labels, table cells, and applicable diagram/timeline labels can be edited at the visual surface or via immediate context UI; inspector remains secondary.

### G11 — Semantic clipboard
Object duplicate, data-only copy, data-only paste/replace, mapping/style paste, linked vs independent duplicate behave deterministically. `Ctrl/Cmd+C/V`, undo/redo remain standard.

### G12 — Persistence
Save/reload preserves datasets, field metadata, mappings, transformations, shared references, and visual configuration. Legacy saved reports still load.

### G13 — Error/recovery
Malformed/mixed/partial data gives actionable warnings. No silent row loss. Undo restores exact prior state.

### G14 — Analytics truthfulness
I-MR/Xbar-R/CUSUM/EWMA/DOE/regression/residual/etc. must use correct production-core/statistical methods or be unavailable. No decorative approximation under an analytical name.

### G15 — Wafer/Fab semantics
Wafer/fab views must render from actual lot/wafer/tool/chamber/die/value/etc. fields, not sample fixtures. Domain alias inference is tested.

### G16 — Interaction binding
Cross-filter/brush/drill/etc. are behaviors bound to target visuals, not standalone palette content, and work on the integrated renderer path.

### G17 — Structure
Stack/grid/split/tabs/etc. are actual parent/child containers with persistence/reflow, not rendered illustrations.

### G18 — Export
Export reflects current edited data/mapping; no stale/sample renderer output.

### G19 — Regression
Existing setup/runtime, report CRUD, geometry, selection, resize, undo/redo, templates, and core release tests remain passing.

## Per-view minimum authoring matrix
For each canonical view/family, test applicability of:
- create from data
- paste
- edit
- map
- transform
- copy/duplicate
- replace source
- convert view
- undo/redo
- invalid/missing data
- save/reload
- export
- keyboard path
- large-data performance where relevant

## Performance targets
Set deterministic benchmarks in tests based on the baseline machine rather than magic UI claims. At minimum enforce:
- no O(rows × elements) editor-wide rerender for cell edits;
- bounded clipboard profiling;
- virtualized grid for large row counts;
- no duplicated full dataset snapshots per linked visual.
