# Terra Medium Efficiency Rules

These rules exist to minimize agent tokens and implementation latency.

1. Do not summarize the audit back to the user/console; implement it.
2. Do not read large JSON catalogs end-to-end. Use grep/jq/Python targeted queries by engine/element.
3. Do not open the XLSX unless a family task needs the exact per-element disposition.
4. Search symbols first, then open only surrounding line ranges.
5. Batch changes by file ownership: data core together, editor UI together, renderer adapters together, tests together.
6. After a task passes its focused tests, move forward; avoid repeated full-suite runs until milestone boundaries.
7. Reuse existing `commitOps`, repository, statistics, graph, table, and chart engines where correct.
8. Prefer one universal abstraction over N engine-specific patches.
9. Maintain a small local implementation log/file if needed; do not repeatedly regenerate plans.
10. When an ambiguous design detail arises, choose the option that best satisfies `00_EXECUTION_SPEC.md` product laws and existing backward compatibility; do not block on clarification unless truly impossible.
11. Any new abstraction must replace an existing repeated branch within the same milestone; avoid speculative framework code.
12. Keep modules cohesive. If `integrated_editor.mjs` would grow materially, extract focused ES modules supported by current asset loading rather than adding more giant switch statements.
13. Use fixtures in `06_TEST_FIXTURES.md` as first regression set before broad catalog fixtures.
14. Do not optimize decorative UI before the data loop is correct.
15. Do not add AI/LLM dependencies for mapping/recommendations; deterministic inference is the P0 requirement.
