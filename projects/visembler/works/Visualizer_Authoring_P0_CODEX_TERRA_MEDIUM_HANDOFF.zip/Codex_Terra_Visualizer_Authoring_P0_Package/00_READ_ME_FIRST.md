# Visualizer Authoring P0 — Codex Terra Medium Handoff

This package is intentionally optimized for **fast implementation with low context/token usage**.

## Give Codex only this ZIP + this prompt
Paste the contents of `01_CODEX_TERRA_PROMPT.txt` into Codex Terra Medium and attach this package.

## Reading order for the agent
1. `agent/00_EXECUTION_SPEC.md` — authoritative scope and sequencing.
2. `agent/01_TASK_GRAPH.json` — exact dependency-ordered work units.
3. `agent/02_CODE_MAP.md` — source hotspots; prevents rediscovery.
4. `agent/03_ARCHITECTURE_CONTRACTS.json` — canonical contracts to implement.
5. `agent/04_ACCEPTANCE_GATES.md` — done definition.
6. `agent/05_DO_NOT_REGRESS.md` — invariants.
7. `agent/07_AGENT_EFFICIENCY_RULES.md` — token/runtime discipline.

Load `agent/06_TEST_FIXTURES.md` when implementing the intake/test milestones.

Read `reference/248_ELEMENT_USABILITY_AUDIT.xlsx` only when a task specifically needs element-level detail. Do **not** load the workbook into context at startup.

## Source
`source/CURRENT_CODEBASE.zip` is the exact baseline supplied with this handoff. Unzip it into the working directory before editing.

## Primary objective
Turn the current catalog-driven editor into a world-class data-authoring system where the common workflow is:

**copy data → paste → correct visualization → direct edit → map/transform → switch view → compose/export**

The user must not need to understand element-specific schemas, recreate visuals to change type, or leave the app for routine data editing.
