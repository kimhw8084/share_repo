# Security and Data Handling Principles

This package assumes implementation inside an approved company environment.

## Rules
- Keep proprietary wafer, product, tool, recipe, sensor, and RCA information within approved systems.
- Do not send company manufacturing data to external services unless explicitly authorized.
- Use least-privilege read access during discovery and retrospective analysis.
- Log generated queries and model/version information for reproducibility.
- Separate raw sensitive identifiers from presentation layers when possible.
- Preserve source provenance for evidence.
- Do not permit the analytical system to automatically disposition wafers, shut down equipment, change recipes, or close RCA events in the initial phases.

## Agent behavior
The coding agent may query approved tables and create derived views/tables only where authorized. It should prefer read-only discovery until the user explicitly authorizes persistence/build operations.
