# Research and Standards References — V2

Use these as methodological anchors. They do not replace company process-engineering documentation or tool-model-specific maintenance manuals.

## Cross-process / trajectory RCA
- IBM Research / ASMC 2025 — **Wafer Defect Root Cause Analysis with Partial Trajectory Regression**. Addresses variable-length wafer process trajectories, rework/waiting-time variability, and counterfactual upstream attribution.
  https://research.ibm.com/publications/wafer-defect-root-cause-analysis-with-partial-trajectory-regression
  https://arxiv.org/abs/2507.20357

- IBM Research / ASMC 2025 — **Sequence-Aware Inline Measurement Attribution for Good-Bad Wafer Diagnosis**. Treats manufacturing order explicitly and proposes trajectory-aware attribution rather than unordered feature attribution.
  https://research.ibm.com/publications/sequence-aware-inline-measurement-attribution-for-good-bad-wafer-diagnosis-dm-big-data-management-and-machine-learning
  https://arxiv.org/abs/2507.20364

- IBM Research / WSC 2025 — **Cross-Process Defect Attribution using Potential Loss Analysis**. Motivated by the heterogeneous and combinatorial nature of processes along the wafer route and counterfactual cross-process attribution.
  https://research.ibm.com/publications/cross-process-defect-attribution-using-potential-loss-analysis
  https://arxiv.org/abs/2508.00895

## Tool / chamber matching
- **Tool-to-Tool Matching Analysis Based Difference Score Computation Methods for Semiconductor Manufacturing** (2025). Uses process-sensor time series for chamber/tool matching and discusses heterogeneous equipment and subsystem-level consistency.
  https://arxiv.org/html/2507.10564v1

## Statistical process monitoring
- NIST/SEMATECH Engineering Statistics Handbook — Process/Product Monitoring and Control; univariate and multivariate charts.
  https://www.itl.nist.gov/div898/handbook/pmc/section3/pmc3.htm

- NIST/SEMATECH — CUSUM control charts; useful for small persistent mean shifts.
  https://www.itl.nist.gov/div898/handbook/pmc/section3/pmc323.htm

- NIST/SEMATECH — EWMA control charts; exponentially weighted monitoring for drift/small shifts.
  https://www.itl.nist.gov/div898/handbook/pmc/section3/pmc324.htm

## Spatial wafer-pattern analysis
- Ezzat, Liu, Hochbaum, Ding — **A Graph-Theoretic Approach for Spatial Filtering and Its Impact on Mixed-type Spatial Pattern Recognition in Wafer Bin Maps**. Motivates separating systematic spatial patterns from random noise and explicitly addresses mixed defect patterns.
  https://arxiv.org/abs/2006.13824

- Ko, Koo — **A novel approach for wafer defect pattern classification based on topological data analysis**. Demonstrates use of wafer-pattern shape information for defect classification under limited/imbalanced data.
  https://arxiv.org/abs/2209.08945

## Process-physics anchors from equipment manufacturers
These references support generic process-domain physics only; exact tool behavior must come from local tool documentation/data.

- Lam Research — Etch process overview / reactive-ion etch.
  https://www.lamresearch.com/products/our-processes/etch/
  https://newsroom.lamresearch.com/etch-essentials-semiconductor-manufacturing

- Lam Research — Chamber cleaning and repeatable chamber-wall condition.
  https://newsroom.lamresearch.com/chamber-clean-cuts-co-32-percent

- ASML — Lithography principles: reticle/mask, optics, focus, wafer positioning.
  https://www.asml.com/technology/lithography-principles

- ASML — Wafer metrology examples including overlay and focus.
  https://www.asml.com/technology/lithography-principles/measuring-accuracy

- Applied Materials — Ion implant process portfolio emphasizing dose/energy/angle/uniformity control.
  https://www.appliedmaterials.com/us/en/semiconductor/products/processes/implant.html

## SEMI semantic anchors
- SEMI Information & Control standards family. Relevant semantic areas include substrate/module/process tracking, equipment performance/state, advanced process control, and data quality.
  https://www.semi.org/en/products-services/standards/information_and_control

## V2 interpretation rules derived from the literature
- Preserve complete process order and route variability.
- Treat cross-process attribution as a sequential/counterfactual problem, not merely feature correlation.
- Expect combinations/interactions and mixed spatial patterns; control the combinatorial search.
- Use process-sensor/peer-chamber comparisons as an independent equipment baseline.
- Use SPC/change detection for equipment/FDC evidence.
- Treat generic wafer patterns as hypotheses; normalize product-specific spatial background before architecture-sensitive inference.
- Do not turn research methods into mandatory production models until blind replay shows incremental value over the deterministic baseline.
