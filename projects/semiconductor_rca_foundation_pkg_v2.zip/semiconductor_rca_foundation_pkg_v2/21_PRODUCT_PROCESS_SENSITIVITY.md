# Product-Process Sensitivity and Criticality Model

## Problem
The same numeric process drift can have different consequence across product, layer, route, recipe, and device architecture. Therefore a global statement such as “1% drift is significant” is invalid.

## Canonical object
`product_process_sensitivity`

Suggested fields:
- product_family / device_family;
- route / layer / operation;
- recipe family/version if relevant;
- parameter / FDC feature / spatial feature;
- valid_from / valid_to;
- target/nominal;
- control limits where valid;
- specification limits where valid;
- robust historical center/scale;
- process capability metrics if available;
- empirical outcome sensitivity;
- evidence count / uncertainty;
- source: engineering / empirical / hybrid.

## Parameter abnormality versus product impact
Maintain two separate quantities:

1. `process_abnormality`: How unusual is the parameter for comparable processing?
2. `product_sensitivity`: How strongly does that deviation affect the target product/outcome?

A parameter may be statistically unusual but materially irrelevant to one product.
A parameter may remain within global limits yet materially affect a highly sensitive product.

## Recommended normalized features
For x under context c:
- robust_z = (x - median_c) / MAD_scale_c;
- spec_fraction = deviation / relevant specification-window width;
- distance_to_limit;
- historical percentile;
- within-context change-point score;
- empirical product interaction effect.

## Hierarchical estimation
When product-specific data is sparse, partially pool toward:
`technology_family -> product_family -> route/layer -> recipe`
rather than creating unstable tiny baselines.

## Evidence usage
Product sensitivity should modify the interpretation of a process/FDC deviation, not erase the raw evidence.

Store both:
- raw abnormality;
- product-conditioned expected impact.

## Spatial product baseline
Estimate normal product-specific spatial structure from eligible good wafers. Use residual maps before comparing architecture-sensitive patterns across products.

## Safeguard
Do not learn product sensitivity from post-event RCA labels alone. Use valid historical outcome data and prevent target leakage in replay.
