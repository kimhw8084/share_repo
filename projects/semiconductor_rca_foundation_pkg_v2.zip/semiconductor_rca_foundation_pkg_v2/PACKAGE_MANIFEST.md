# Package Manifest V2

## Core
- `START_HERE.md`
- `00_GEMMA_MASTER_INSTRUCTION.md`
- `01_SCIENTIFIC_DOCTRINE.md`
- `02_DATA_DISCOVERY_PROTOCOL.md`
- `03_CANONICAL_ONTOLOGY.yaml`
- `03_CAUSAL_HORIZON_AND_LATENT_DEFECTS.md`
- `04_CANONICAL_DATA_CONTRACTS.md`
- `05_RCA_PIPELINE_SPEC.md`
- `06_STATISTICAL_METHODS.md`
- `07_PROCESS_PHYSICS_KB.md`
- `08_CONTROL_SELECTION.md`
- `09_EVIDENCE_AND_CONFIDENCE.md`
- `10_HISTORICAL_REPLAY_VALIDATION.md`
- `11_IMPLEMENTATION_ROADMAP.md`
- `12_AGENT_WORKFLOW.md`
- `13_TESTS_AND_GUARDRAILS.md`
- `14_SECURITY_AND_DATA_HANDLING.md`
- `15_RESEARCH_REFERENCES.md`
- `16_IMPLEMENTATION_PSEUDOCODE.md`
- `17_RCA_RESULT_SCHEMA.json`
- `18_TABLE_DISCOVERY_REPORT_TEMPLATE.md`
- `19_BUILD_ACCEPTANCE_CHECKLIST.md`

## V2 design extensions
- `20_DESIGN_DECISIONS_V2.md` — direct resolution of critical architecture questions.
- `21_PRODUCT_PROCESS_SENSITIVITY.md` — product-specific interpretation of process drift.
- `22_DATA_RETENTION_AND_HISTORICAL_ACCESS.md` — hot/archive/history resolver contract.
- `23_INTERACTION_AND_MIXED_CAUSE_ANALYSIS.md` — combinations, sequence interactions, multiple causes.
- `24_CHALLENGE_TESTS.md` — adversarial scientific validation cases.
- `25_CAUSAL_TRAPS_AND_FAILURE_MODES.md` — confounding/leakage/selection traps.

## Configuration
- `config/table_registry.yaml`
- `config/source_retention_registry.yaml`
- `config/PROJECT_CONFIG_TEMPLATE.yaml`

## Reusable prompts
- `prompts/SESSION_BOOTSTRAP.md`
- `prompts/ONBOARD_NEW_TABLE.md`
- `prompts/BUILD_FOUNDATION.md`
- `prompts/ANALYZE_ONE_EXCURSION.md`
- `prompts/HISTORICAL_BLIND_REPLAY.md`
