# START HERE — Semiconductor Excursion Forensic Intelligence Foundation V2

## What this package is
A portable scientific/engineering specification for building a semiconductor excursion cause-finding platform inside the company environment. It does **not** contain a finished production system. It is designed so an internal coding agent such as Gemma can inspect company tables and implement the logic without inventing the RCA methodology.

## V2 core doctrine
**Exposure + Route-Adjusted Counterfactual + Time + Process Anomaly + Product Sensitivity + Physics + Spatial Evidence + Intervention − Reliable Contradictions = Causal Confidence.**

Important: evidence dependencies are tracked; three signals derived from one sensor are not three independent confirmations.

## Major V2 corrections
1. Set intersection is descriptive, not the commonality algorithm.
2. Primary commonality uses route-adjusted affected-vs-good exposure.
3. Defect magnitude is a separate dose-response channel, not primary population weighting.
4. Controls are candidate-specific and matched on pre-exposure context.
5. Causal lookback is route/physics-aware, not a fixed number of days/steps.
6. Both single and restricted combinatorial causes are supported.
7. Mixed-cause excursion registrations are allowed.
8. Product/process sensitivity modifies materiality of a drift.
9. Spatial evidence is product-normalized where possible.
10. Evidence channels are unequal and dependency-aware.
11. Contradictions are FATAL/STRONG/SOFT; only fatal logic hard-rejects.
12. Historical data is accessed through a source-retention/archival resolver.

## Work-PC boot sequence
1. Unzip this package.
2. Give Gemma `00_GEMMA_MASTER_INSTRUCTION.md` as persistent instruction.
3. Give Gemma `prompts/SESSION_BOOTSTRAP.md`.
4. Tell Gemma the query platform and relevant table names.
5. Gemma runs `02_DATA_DISCOVERY_PROTOCOL.md` and fills:
   - `config/table_registry.yaml`
   - `config/source_retention_registry.yaml`
6. Gemma maps data into `03_CANONICAL_ONTOLOGY.yaml` / `04_CANONICAL_DATA_CONTRACTS.md`.
7. Implement `05_RCA_PIPELINE_SPEC.md` and `16_IMPLEMENTATION_PSEUDOCODE.md` before advanced ML.
8. Validate with `10_HISTORICAL_REPLAY_VALIDATION.md` and `24_CHALLENGE_TESTS.md`.

## Recommended reading order
1. `00_GEMMA_MASTER_INSTRUCTION.md`
2. `20_DESIGN_DECISIONS_V2.md`
3. `01_SCIENTIFIC_DOCTRINE.md`
4. `03_CAUSAL_HORIZON_AND_LATENT_DEFECTS.md`
5. `08_CONTROL_SELECTION.md`
6. `05_RCA_PIPELINE_SPEC.md`
7. `06_STATISTICAL_METHODS.md`
8. `09_EVIDENCE_AND_CONFIDENCE.md`
9. `21_PRODUCT_PROCESS_SENSITIVITY.md`
10. `23_INTERACTION_AND_MIXED_CAUSE_ANALYSIS.md`
11. `22_DATA_RETENTION_AND_HISTORICAL_ACCESS.md`
12. `07_PROCESS_PHYSICS_KB.md`
13. validation/guardrail documents.

## Non-negotiable rules
- Never equate all-bad intersection with cause.
- Never call a routing-common tool causal without excess bad-vs-good enrichment.
- Never define unmeasured material as good.
- Never match controls on the candidate exposure under test.
- Never use a universal fixed causal lookback when upstream defects can propagate.
- Never double count derived evidence from one physical signal.
- Never let one noisy contradiction kill an otherwise strong case.
- Never let strong support override a true temporal impossibility.
- Never assume the same percentage drift has the same product impact.
- Never substitute current metadata for historical configuration.
- Never force one cause if the affected population is demonstrably mixed.
- Never force a winner when evidence is insufficient.

## The desired first implementation
A retrospective forensic notebook/service that takes one excursion ID and returns an auditable, dependency-aware ranked hypothesis set—not automated fab action.
