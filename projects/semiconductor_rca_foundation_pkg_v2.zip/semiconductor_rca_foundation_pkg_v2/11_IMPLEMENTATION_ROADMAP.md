# Implementation Roadmap V2 for the Internal Coding Agent

## Milestone 0 — Bootstrap
- Read the package and master instruction.
- Identify query platform.
- Create query/provenance log.
- Confirm data remains in approved environment.

## Milestone 1 — Source + retention discovery
- Onboard all named source tables.
- Infer grain, keys, time semantics, joins.
- Determine historical retention/archive paths.
- Populate table and source-retention registries.

## Milestone 2 — Canonical lineage
- Build wafer/process instances.
- Preserve route versions, rework/repeats, tool/chamber/recipe.
- Quantify coverage and historical validity.

## Milestone 3 — Target + causal horizon
- Define excursion outcome/measurement opportunity.
- Infer last-known-good/first-known-bad.
- Build process-state causal horizon; no fixed universal lookback.

## Milestone 4 — Good outcome pool + candidate-specific controls
- Build eligible good pool.
- Implement candidate-specific pre-exposure matching/stratification.
- Validate overlap/positivity and route balance.

## Milestone 5 — Commonality V2
- Strict intersection only as descriptive output.
- Route-adjusted bad-vs-good exposure contrasts.
- Wafer/lot/batch replication.
- Routing-commonality detection.
- Separate severity/dose-response analysis.

## Milestone 6 — Equipment evidence
- Alarm episodes + exposure-normalized rate models.
- Equipment-state/SPC/change detection.
- PM/degradation lifecycle.
- Self/peer/good-outcome baselines.

## Milestone 7 — FDC + product sensitivity
- Recipe-step alignment.
- Interpretable features before deep models.
- Product-process sensitivity layer.
- Evidence dependency groups.

## Milestone 8 — Measurement/spatial + physics
- Measurement-system candidate.
- Product-normal expected spatial map and residual pattern.
- Process-state/mechanism compatibility.

## Milestone 9 — Interventions, interactions, mixed causes
- Recover documented/inferred interventions.
- Restricted interaction/sequence search.
- Mixed-cause subgroup analysis only when justified.

## Milestone 10 — Evidence and confidence
- Fatal/strong/soft contradiction taxonomy.
- Dependency-aware evidence classes C0-C5.
- Abstention/mixed-cause statuses.

## Milestone 11 — Historical blind replay
- Compare against intersection/raw commonality baselines.
- Test calibration, route false positives, severity handling, product sensitivity, interaction burden, and archive consistency.

## Milestone 12 — Advanced models only after proof
Evaluate sequence-aware attribution, trajectory models, deep FDC models, and learned evidence fusion only if they improve held-out replay without destroying auditability.
