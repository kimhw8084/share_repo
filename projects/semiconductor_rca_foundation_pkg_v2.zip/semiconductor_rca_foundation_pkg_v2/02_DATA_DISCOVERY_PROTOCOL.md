# Data Discovery Protocol

## Purpose
Allow the coding agent to understand fragmented company tables safely with minimal manual explanation.

## Onboarding a new table
For every new table T, produce a Table Discovery Report.

### A. Structural inspection
- full table name / location;
- schema;
- column data types;
- row count estimate;
- partitioning/clustering if visible;
- earliest/latest timestamps;
- update latency / apparent refresh pattern.

### B. Grain inference
For each plausible entity key or composite key:
- count distinct;
- duplicate count;
- maximum rows/key;
- distribution rows/key;
- test whether repeated rows are revisions, events, samples, or duplicates.

Never assume `lot_id` means one row per lot or `tool_id` means one row per tool.

### C. Semantic profiling
For categorical columns:
- cardinality;
- top values;
- null/blank/unknown rates;
- patterns indicating codes vs human-readable text.

For numeric columns:
- min/max/quantiles;
- zero/infinite/sentinel patterns;
- likely units if documented, otherwise mark UNKNOWN_UNIT.

For timestamps:
- resolution;
- timezone evidence;
- duplicated timestamps;
- ordering consistency;
- future/impossible values.

### D. Join discovery
Against the canonical registry, test candidate joins and report:
- left coverage;
- right coverage;
- row multiplication factor;
- unmatched examples;
- one-to-one / one-to-many / many-to-many behavior;
- whether join is historically valid.

A join that produces a 50x row explosion must never be silently accepted.

### E. Historical-state test
Determine whether T is:
- immutable event history;
- effective-dated history;
- periodically snapshotted state;
- current-state-only metadata.

Current-state-only metadata must not be projected backwards in time without an explicit assumption flag.

### F. Causal role classification
Classify T as one or more:
- excursion outcome;
- population membership;
- genealogy/trajectory;
- process context;
- equipment identity;
- equipment event/alarm;
- equipment state/health;
- FDC/sensor;
- maintenance/intervention;
- metrology/inspection/test;
- control population;
- material/reticle/carrier;
- facilities;
- measurement-system context;
- reference metadata.

### G. Data-quality score
Record a structured score, not one opaque number:
- key integrity;
- timestamp integrity;
- join coverage;
- semantic certainty;
- historical validity;
- missingness;
- duplication risk.

## Required output per new table
Create/update `config/table_registry.yaml` with:
- source table;
- inferred grain;
- candidate/confirmed keys;
- time fields;
- canonical entities supported;
- joins;
- evidence role;
- warnings;
- validation SQL/query references.

## Minimum discovery queries
The exact SQL must match the platform, but the agent should always generate equivalents of:
1. DESCRIBE/INFORMATION_SCHEMA query.
2. row count and date range.
3. distinct-count profile for likely keys.
4. null-rate profile.
5. duplicate-key profile.
6. top categorical values.
7. join-coverage tests.
8. representative chronology for one known lot/wafer if possible.

## Stop conditions
Do not use a table in causal logic if:
- its row grain is unknown;
- the time field is ambiguous for the causal question;
- its join creates uncontrolled duplication;
- its identifiers cannot be tied to canonical entities;
- the table is current-state-only but historical values are required.

---
# V2 Addendum — Retention, Knowledge Time, and Evidence Dependency

For every source table also determine:
- earliest/latest event time actually queryable;
- whether older data moves to archive/history tables;
- partition/date columns;
- archive access path if discoverable;
- schema changes across history;
- ingestion/knowledge timestamp if available;
- whether a derived flag is generated from another source signal.

Update both:
- `config/table_registry.yaml`
- `config/source_retention_registry.yaml`

## Evidence dependency discovery
When a table contains alarms/SPC/FDC/derived flags, determine whether multiple fields originate from the same underlying sensor or measurement. Record a candidate `independence_group` so later evidence fusion does not double count them.

## Source-time classification
Each relevant timestamp should be classified as one of:
- manufacturing event time;
- effective configuration time;
- measurement time;
- ingestion/knowledge time;
- administrative update time.

Never treat administrative update time as physical event time without evidence.
