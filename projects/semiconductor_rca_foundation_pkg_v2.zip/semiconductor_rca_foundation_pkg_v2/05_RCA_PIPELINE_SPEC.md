# RCA Pipeline Specification V2

## Input
`excursion_id`

Optional:
- replay cutoff;
- requested symptom/measurement target;
- analysis mode: discovery / historical replay / engineer drill-down.

## Output
Ranked single or combinatorial causal hypotheses with evidence, contradictions, uncertainty, confidence class, mixed-cause status, and next-best discriminating test.

## Phase 0 — Resolve historical data coverage
1. Resolve source coverage for the event time through the Historical Data Resolver.
2. Load effective-dated metadata, not current-state substitutes.
3. Record uncovered intervals and source/schema versions.
4. If critical trajectory coverage is unavailable, downgrade/abstain.

## Phase 1 — Reconstruct the event and target
1. Load excursion record without closure leakage in replay.
2. Resolve affected lots/wafers.
3. Define symptom/target and measurement system.
4. Capture raw and product-normalized failure severity.
5. Identify first bad observation and any earlier trusted checkpoints.

## Phase 2 — Build affected trajectories
For every affected wafer:
1. reconstruct complete ordered process history;
2. preserve rework/repeats/skips/route branches;
3. link actual tool/chamber/recipe/version;
4. attach lot/batch/carrier/shared-resource context;
5. attach data-quality and provenance;
6. retain processing after defect creation as context but not candidate cause when temporally impossible.

## Phase 3 — Infer causal horizon
Use `03_CAUSAL_HORIZON_AND_LATENT_DEFECTS.md`.

For the symptom:
1. infer last-known-good / first-known-bad interval;
2. identify state domains capable of propagating into the symptom;
3. traverse upstream operations with plausible state paths;
4. preserve full-route fallback if knowledge is incomplete;
5. assign candidate-priority tiers, not universal time cutoffs.

## Phase 4 — Build eligible good-outcome pool
Use `08_CONTROL_SELECTION.md`.

Eligibility requires outcome opportunity and evidence of normal outcome. Build a broad pool before candidate-specific matching.

## Phase 5 — Enumerate candidate universe
Enumerate single candidate entities from the causal horizon:
- operation;
- tool;
- chamber/module;
- recipe/version;
- subsystem/state;
- PM/degradation state;
- reticle;
- carrier;
- material/consumable;
- APC/R2R state;
- configuration/software change;
- facility source;
- metrology system where measurement artifact is plausible.

Alarms/FDC features are usually evidence of a physical entity/state rather than root causes by themselves.

## Phase 6 — Route-adjusted commonality
For each candidate C:
1. build candidate-specific controls using pre-exposure context;
2. do not match on C or descendants of C;
3. calculate strict intersection/near-intersection only as descriptive diagnostics;
4. calculate bad exposure coverage;
5. calculate matched-good exposure;
6. estimate smoothed risk/odds effect;
7. estimate route-expected exposure / residual enrichment;
8. report wafer, lot, and batch support;
9. apply clustered/hierarchical uncertainty if required;
10. flag `ROUTING_COMMONALITY` when high bad exposure is explained by normal route exposure;
11. correct hypothesis family for false discovery.

## Phase 7 — Severity / dose-response analysis
Separately from binary commonality:
1. normalize outcome severity within product/target context;
2. test candidate exposure/intensity/state against severity;
3. use robust/hierarchical model appropriate to continuous/ordinal/count outcome;
4. report whether severity strengthens, weakens, or is neutral to the candidate.

Do not silently use severity as primary population weight.

## Phase 8 — Equipment temporal anomaly search
For leading equipment/chamber candidates:
1. construct alarm episodes;
2. identify independence groups linking alarms to underlying sensors;
3. choose physical exposure denominator;
4. estimate historical self baseline;
5. compare event-window state;
6. compare peer/sister chambers;
7. compare good-outcome runs;
8. evaluate counters/interlocks/configuration changes;
9. run appropriate SPC/change detectors;
10. control multiple testing.

## Phase 9 — PM/degradation
At affected process time compute:
- wafers/runs/hours since PM/clean;
- component/kit age;
- position within maintenance lifecycle;
- seasoning/qualification state;
- recent maintenance/config/software changes;
- degradation trend.

Test whether bad outcome concentrates in a degradation interval and whether equivalent good processing contradicts it.

## Phase 10 — FDC investigation
For leading candidates:
1. select comparable good runs;
2. align traces to recipe/process steps;
3. validate sensor units/aliases/missingness;
4. extract robust interpretable features;
5. compute univariate/multivariate deviations;
6. compare self/peer/good-outcome baselines;
7. map related signals into independence/subsystem groups;
8. apply product-process sensitivity to interpret material impact;
9. preserve raw trace pointers for engineer review.

## Phase 11 — Measurement-system and spatial analysis
1. test measurement-system health first;
2. normalize coordinates/orientation/shot/die information;
3. estimate product-specific expected spatial map from eligible good wafers;
4. calculate residual spatial signature;
5. characterize radial/azimuthal/field/cluster/line patterns;
6. compare to candidate physical mechanism;
7. use repeat/cross-tool measurement when available.

## Phase 12 — Physics consistency
Use process-family state/mechanism knowledge.

Statistical discovery occurs first. Physics can:
- support;
- limit confidence;
- reject a physically impossible candidate;
- identify a more specific subsystem;
- propose the next discriminating test.

## Phase 13 — Competing hypotheses
Explicitly compare candidates that can explain the same population:
- route commonality;
- reticle/material/carrier;
- recipe/version/APC;
- facility common mode;
- measurement artifact;
- alternate upstream operation;
- downstream amplification rather than initial creation.

## Phase 14 — Intervention/recovery
Link documented actions when available; otherwise infer interventions conservatively from downtime, maintenance, cleans, config/recipe changes, NPW/qualification, release, FDC normalization, and later outcome recovery.

During blind replay, post-cutoff evidence cannot change the frozen pre-detection ranking; it is used for retrospective validation/calibration only.

## Phase 15 — Restricted interaction search
If single causes do not explain the event sufficiently, use `23_INTERACTION_AND_MIXED_CAUSE_ANALYSIS.md`.

Search only justified combinations/sequences and compare their incremental explanatory value against simpler hypotheses.

## Phase 16 — Mixed-cause detection
If affected wafers separate into coherent groups by time, route, defect/spatial signature, or residual unexplained set:
1. test one-cause versus multi-subgroup explanation;
2. rerun candidate analysis per subgroup;
3. return `MIXED_CAUSE_SUSPECTED` if evidence favors multiple causes.

## Phase 17 — Evidence fusion
Use `09_EVIDENCE_AND_CONFIDENCE.md`.

Keep:
- hard causal gates;
- support evidence;
- contradiction severity;
- independence groups;
- product sensitivity;
- uncertainty/data quality.

Do not use equal channel weights or blindly sum correlated evidence.

## Phase 18 — Result
For every surviving candidate/hypothesis return:
- rank;
- entity hierarchy;
- single/interaction/mixed-cause type;
- confidence class;
- strict and near commonality diagnostics;
- route-adjusted enrichment;
- severity/dose response;
- strongest independent support;
- contradictions classified FATAL/STRONG/SOFT;
- temporal status;
- physics mechanism;
- product sensitivity context;
- historical coverage;
- next-best discriminating test.

If no hypothesis satisfies minimum causal evidence, abstain.
