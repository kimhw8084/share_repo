# Scientific Doctrine V2

## 1. Problem statement
An excursion is an observed manufacturing-quality abnormality. The forensic task is to identify which upstream causal entity, state, or interaction most plausibly generated the observed defect while controlling for normal routing, product sensitivity, sampling, temporal ordering, shared-resource effects, route variability, evidence dependence, and alternative explanations.

## 2. Three different claims
### Anomaly
Something differs from its expected behavior.

### Association
A condition is enriched among affected wafers relative to appropriate controls.

### Causal evidence
The candidate was actually exposed, is temporally capable of causing the outcome, shows excess association beyond normal routing, is physically compatible with the defect, survives competing hypotheses, and receives corroboration from sufficiently independent evidence.

## 3. Core causal vector
For candidate C preserve rather than prematurely collapse:

`Evidence(C) = {Exposure, RouteAdjustedCommonality, SeverityGradient, Time, EquipmentAnomaly, Degradation, FDC, ProductSensitivity, Physics, Spatial, MeasurementHealth, Intervention, Alternatives, Contradictions, DataQuality, HistoricalCoverage}`

Historical blind replay may later calibrate this vector into probabilities.

## 4. Commonality is conditional
`all bad wafers touched X` is not enough.

The relevant question is:
`Did affected wafers experience X more often than comparable wafers would be expected to experience X under normal routing?`

Therefore strict intersection is descriptive, and route-adjusted bad-versus-good enrichment is primary.

## 5. Severity is separate evidence
Do not let defect magnitude silently change population weights in the primary binary commonality test. Test whether candidate exposure/state has a dose-response relationship with normalized failure magnitude as an independent evidence channel.

## 6. Unit of independence
A wafer is the physical trajectory unit, but statistical independence may occur at wafer, lot, carrier, batch, chamber-run, or event level. Report and model clustering rather than treating all wafer rows as independent replicates.

## 7. Ordered trajectory doctrine
A wafer route is ordered and may contain rework, skip, hold, repeat, split, merge, alternate tools, and different waiting times. Preserve process-instance identity and sequence.

## 8. Latent/propagating-cause doctrine
Defect creation and defect observation can be separated by many process operations. Use a route/physics-aware causal horizon rather than a fixed time window.

## 9. Counterfactual doctrine
A good control must have a meaningful opportunity to exhibit the same target and evidence that it did not. Candidate-specific control construction must match pre-exposure context without matching away the candidate.

## 10. Multiple-cause doctrine
Do not assume every excursion is a single-point failure. Search simple causes first, then restricted interactions and mixed-cause subpopulations when warranted.

## 11. Product sensitivity doctrine
Process abnormality and product impact are different quantities. A shift can be unusual but harmless to one product, or subtle but critical to another.

## 12. Measurement doctrine
Metrology/inspection/test is both evidence and a possible source of apparent excursions. Normalize product-specific spatial baselines and verify measurement health.

## 13. Evidence dependence doctrine
Two channels produced by the same underlying sensor or algorithm are not independent corroboration. Track independence groups and avoid double counting.

## 14. Contradiction doctrine
Contradictions have different reliability and causal force.
- fatal contradiction: hard reject;
- strong contradiction: major downgrade;
- soft/noisy contradiction: modest downgrade.

## 15. Multiple-testing doctrine
Control false discovery across candidate, alarm, FDC, spatial, and interaction hypothesis families. The larger the search space, the less impressive an isolated rare result becomes.

## 16. Historical-validity doctrine
Use historical configuration and archived trajectory data appropriate to the event time. Missing historical coverage reduces confidence; it is not permission to guess.

## 17. Abstention doctrine
Return insufficient evidence when controls, temporal ordering, historical coverage, physical evidence, or differentiation among leading candidates is inadequate.

## 18. Scientific objective
The engine should maximize **correctly calibrated causal discrimination**, not the percentage of excursions for which it produces a winner.
