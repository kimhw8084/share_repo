# V2 Changelog

Rebuilt after scientific design review.

Major changes:
- replaced strict set-intersection commonality with route-adjusted bad-vs-good contrast;
- separated defect severity from primary commonality and added dose-response analysis;
- added routing-commonality detection;
- replaced fixed lookback with physics-aware causal horizon / state propagation;
- changed control selection to candidate-specific pre-exposure risk-set matching;
- added lot/batch clustering and pseudo-replication guardrails;
- added restricted combinatorial and mixed-cause analysis;
- added product-process sensitivity/criticality model;
- added product-normalized spatial residual logic;
- made evidence unequal and dependency-aware;
- replaced universal contradiction-to-C0 behavior with FATAL/STRONG/SOFT taxonomy;
- separated candidate status from C0-C5 confidence;
- added Historical Data Resolver / retention registry;
- added adversarial challenge tests and causal-trap catalog;
- restored/added missing ontology, configuration templates, prompts, and machine-readable result schema.
