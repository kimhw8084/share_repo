# Design Decisions V2 — Answers to Critical RCA Architecture Questions

This document resolves the design questions that materially change the forensic engine. These decisions supersede any earlier simplification that conflicts with them.

## 1. Commonality: set intersection or weighted overlap?

### Decision
Use **neither as the sole method**.

A strict set intersection is useful only as a descriptive diagnostic:
- Which entities were touched by every affected wafer?
- Which entities were touched by nearly every affected wafer?

It is not the commonality engine because it fails under:
- mixed-cause excursions;
- missing trajectory records;
- rework/alternate routing;
- chamber-level partial exposure;
- only a subset of wafers being affected by a localized failure.

The primary commonality analysis is a **route-adjusted bad-versus-good exposure contrast**.

For candidate C report at minimum:
- bad coverage P(C | Bad);
- matched-good exposure P(C | Good);
- risk ratio / odds ratio with shrinkage;
- route-adjusted enrichment;
- lot-level and wafer-level support;
- time concentration;
- uncertainty / FDR-adjusted significance.

Optional weighted-overlap scores may be used for candidate screening, especially inverse-background-prevalence weighting, but must not replace the explicit counterfactual comparison.

### Practical rule
- `intersection`: descriptive clue;
- `near_intersection`: candidate generation;
- `bad_vs_good_enrichment`: primary commonality evidence;
- `route_adjusted_residual`: causal-commonality discriminator.

---

## 2. Should commonality be weighted by failure magnitude?

### Decision
**Not in the primary discovery statistic.**

The foundational commonality analysis treats eligible affected wafers as affected observations without allowing a severe wafer to silently count as multiple wafers. Otherwise a small number of extreme measurements can dominate candidate discovery.

Failure magnitude is a **secondary dose-response evidence channel**.

For candidate C test whether exposure/state severity predicts defect severity among comparable wafers:
- binary outcome: bad/good enrichment;
- continuous outcome: robust regression / hierarchical regression;
- ordinal failure class: ordinal model;
- wafer reject fraction: binomial/beta-binomial or suitable count model;
- spatial severity: target-specific normalized score.

### Product normalization
Severity must be normalized within the target product/measurement context before comparing products. A one-unit raw change may have very different meaning for different devices or layers.

### Independence warning
If 25 wafers belong to one lot or batch, they are not automatically 25 independent causal observations. Report wafer-, lot-, and batch-level support and use clustered/hierarchical uncertainty where appropriate.

---

## 3. Routing commonality versus causal commonality

### Decision
Programmatically define **routing commonality** as high exposure that is expected under normal matched manufacturing context, and **causal commonality** as excess exposure beyond that expected routing probability.

For candidate C at operation s:

`RoutingExpected(C) = P(C | product, route_version, operation, time_context, eligible_good)`

`ObservedBad(C) = P(C | Bad, same contextual stratum)`

A candidate is routing-common when both are high and similar.
A candidate becomes causally interesting when ObservedBad is materially greater than RoutingExpected after conditioning on pre-exposure context.

### Required methods
Use one or more:
- matched 2x2 exposure comparison;
- conditional logistic regression;
- stratified Mantel-Haenszel-style effect estimates;
- within-route/time permutation null;
- hierarchical logistic model with product/route/operation effects;
- conditional mutual information as an exploratory metric.

### Route-commonality flag
Set `ROUTING_COMMONALITY` when:
- candidate exposure is high in bad wafers;
- exposure is also high in comparable good wafers;
- residual enrichment is small or uncertain.

Do not promote such a candidate solely because it appears in all affected trajectories.

---

## 4. Latent / propagating defects and causal lookback

### Decision
Do **not** use a fixed number of hours, days, or operations as the main causal lookback.

Semiconductor defects can be generated upstream and only become measurable many process steps later. The engine therefore uses a **route-aware causal horizon**.

### Preferred horizon
For target symptom Y:
1. identify the first trusted observation of Y;
2. identify the latest earlier checkpoint that can credibly rule out Y or its precursor state;
3. traverse upstream process history through operations physically capable of generating a state that can propagate into Y;
4. stop only at a trusted causal barrier/checkpoint or the start of the relevant manufacturing history.

If no trusted last-known-good checkpoint exists, retain the entire upstream route as eligible and prioritize candidates by physical relevance and evidence rather than hard-excluding older processes.

### Do not use simple time decay as causal exclusion
Older processes may remain fully causal when they permanently establish:
- geometry/pattern;
- dopant distribution;
- contamination/particles;
- film composition/thickness/stress;
- interface damage;
- overlay/alignment state;
- crystal/plasma damage;
- thermal budget effects.

Use operation-distance or elapsed-time decay only as a ranking prior when physics permits, never as a universal causal rule.

---

## 5. Good controls: same product or exact tool/recipe/chamber sequence?

### Decision
Same product alone is too weak. Exact full sequence matching is usually too strict and can condition away the cause.

Use **candidate-specific risk-set controls**.

A control should match the affected wafer on important **pre-candidate** context:
- product/device family;
- route and route revision;
- relevant upstream state/history;
- operation;
- recipe family/version when recipe is not the exposure under test;
- time neighborhood;
- production/engineering class;
- rework state;
- measurement opportunity and normal outcome.

But do **not** require the same suspect chamber when testing chamber, the same recipe version when testing recipe version, etc.

### Ideal chamber contrast
For testing chamber C at operation s:
- affected and good wafers arrive at the same/compatible operation with similar pre-operation history;
- controls may run on sister chambers;
- downstream outcome is observed comparably.

This estimates the exposure contrast rather than matching the exposure away.

### Post-treatment warning
Do not match on downstream variables that may have been caused by the suspect process. That creates post-treatment bias.

---

## 6. Single-point versus combinatorial failures

### Decision
Support **both**, with a hierarchical search strategy.

Start with single entities because they are interpretable and statistically efficient. Then search combinations among plausible leaders rather than all possible pairs/triples.

### Interaction types to support
- tool A + tool B;
- ordered sequence A -> B;
- chamber + recipe;
- chamber + PM-age state;
- process parameter + product;
- material lot + tool;
- reticle + scanner/track;
- facility disturbance + susceptible tool family;
- upstream process state + downstream process condition.

### Hierarchical search rule
Only test an interaction when at least one of these is true:
- one or both components have marginal evidence;
- process physics makes the interaction plausible;
- bad-only trajectory mining identifies strong co-occurrence;
- single-candidate models leave a systematic residual subgroup.

Use multiple-testing correction and penalize unnecessary complexity.

### Mixed-cause excursions
Also allow the affected population to contain more than one cause. If no candidate explains the whole population, cluster by defect signature, time, route, or spatial pattern and rerun the analysis within coherent subgroups.

---

## 7. Product criticality / sensitivity matrix

### Decision
Create a **Product-Process Sensitivity Model**, not a universal interpretation of percent drift.

A 1% drift can be highly consequential for one product/layer/parameter and irrelevant for another.

Represent:
`Sensitivity(product_family, route_layer, operation, parameter_or_feature)`

Evidence sources:
- historical specification/control limits valid at event time;
- target/nominal and process capability;
- product-specific historical response of downstream quality;
- engineering criticality metadata when available;
- empirical interaction between parameter deviation and product outcome.

### Recommended normalization
For a parameter x use context-aware measures such as:
- robust z-score relative to same product/recipe context;
- fraction of specification window consumed;
- distance to nearest valid specification limit;
- historical percentile;
- empirical outcome slope / likelihood ratio.

Do not treat percentage drift alone as comparable across parameters or products.

### Cold-start behavior
For a new/sparse product use process-family/recipe hierarchical pooling plus specification-based normalization; do not invent precise sensitivity.

---

## 8. Spatial signatures and device architecture

### Decision
Use two layers:
1. generic process/equipment spatial physics;
2. product/layout-specific residual patterns learned from good wafers.

Many wafer signatures arise from equipment/process geometry: radial, edge-ring, center, azimuthal, scan/field, zonal, scratch, cluster, etc. Product architecture/layout can modify how those process variations manifest.

Therefore never compare raw wafer maps across different products as if their normal spatial structure is identical.

### Product-normalized spatial evidence
For product P estimate a normal spatial field / map from good wafers. Analyze:
`ResidualMap = ObservedMap - ExpectedMap(product, measurement_recipe, relevant_context)`

Where available also align:
- reticle shot/field coordinates;
- die coordinates;
- layout density / device-region metadata;
- notch/orientation;
- measurement-site plan.

Only use architecture-specific weighting when validated for that product/family. Generic industry pattern labels are hypotheses, not proof of a specific physical cause.

---

## 9. Are evidence channels equal?

### Decision
No. They differ in specificity, reliability, independence, temporal relevance, and data quality.

Do not use equal weights. Also do not hard-code one universal channel ranking as truth.

### Evidence item quality dimensions
Every evidence item should record:
- polarity: support / contradiction / neutral;
- strength/effect size;
- reliability;
- temporal validity;
- mechanism specificity;
- data quality;
- sample size;
- independence group;
- uncertainty.

### Default diagnostic hierarchy
As a general prior, direct temporally aligned physical process evidence and successful intervention/recovery are more diagnostic than generic alarm rarity. But an interlock directly tied to a physical subsystem can be more specific than a weak FDC shift, and an OOS measurement can be measurement-system-generated.

Therefore channel strength is conditional, not absolute.

### Avoid double counting
If an alarm was generated from the same pressure sensor used in FDC, alarm rarity and that FDC excursion are not two independent confirmations. Assign both to the same `independence_group` or otherwise downweight correlated evidence.

---

## 10. Contradictions and the old C0 rule

### Decision
The old rule was too strict. Replace it with a **contradiction taxonomy**.

### Fatal contradictions / hard gates
These can reject a candidate regardless of other support unless the event is explicitly modeled as mixed-cause:
- candidate exposure did not occur;
- candidate condition occurred only after the affected processing and has no plausible earlier precursor evidence;
- operation is physically incapable of influencing the target state under the defined mechanism;
- identity/join evidence proves the candidate is the wrong chamber/entity.

### Strong contradictions
Materially reduce confidence but do not always force rejection:
- large matched-good population experiences same candidate/state with normal outcome;
- independent physical measurement is normal when the hypothesis predicts abnormality;
- product-normalized spatial signature is incompatible;
- controlled corrective intervention fails to remove the condition/defect;
- stronger alternate commonality explains the same population.

### Soft/noisy contradictions
Should reduce evidence modestly and can be overridden:
- one noisy sensor is normal;
- one alarm is absent;
- one isolated good wafer survives exposure;
- sparse/missing peer-chamber evidence.

### Confidence behavior
A candidate with three strong independent support channels may remain high confidence despite one low-reliability soft contradiction. A candidate cannot overcome a true temporal impossibility by accumulating unrelated support.

---

## 11. Historical trajectory retention / six-month-old events

### Decision
The scientific engine must be storage-tier agnostic. It must not assume the live lot-history table retains all history.

Create a `Historical Data Resolver` and source-retention registry.

For each source record:
- hot/live retention;
- earliest/latest available timestamp;
- archive/cold location if known;
- partition key;
- historical schema version;
- access method;
- effective-time versus ingestion/knowledge-time semantics;
- expected restore/query latency;
- coverage gaps.

For an event six months old:
1. request the required causal interval from the resolver;
2. query hot storage;
3. detect incomplete coverage;
4. query archive/cold/history source through a versioned adapter;
5. normalize to the canonical schema;
6. report provenance and gaps.

If the archive cannot be found, return `HISTORICAL_COVERAGE_INSUFFICIENT`; never reconstruct missing trajectory from current metadata guesses.

---

## 12. Additional V2 improvements derived from these questions

### A. Candidate-specific controls
Build an eligible good pool once, but perform matching/stratification per candidate so the candidate exposure is not accidentally matched away.

### B. Multi-level independence
Report evidence at wafer, lot, batch/carrier, and event level as applicable. Use clustered/hierarchical uncertainty.

### C. Interval-censored defect onset
Treat last-known-good and first-known-bad as an onset interval when exact defect creation time is unknown.

### D. Evidence dependency graph
Record which alarms, FDC features, SPC signals, and OOS flags derive from the same underlying sensor/measurement so they are not counted as independent channels.

### E. Mixture detection
If the affected population has multiple spatial/temporal/route modes, explicitly test whether one excursion registration contains multiple causes.

### F. Product-specific calibration
Calibrate evidence/confidence by process family and product class where data permits instead of assuming one global threshold behaves identically everywhere.
