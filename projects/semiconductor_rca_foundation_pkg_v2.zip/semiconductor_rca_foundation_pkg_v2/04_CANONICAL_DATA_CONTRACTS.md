# Canonical Data Contracts V2

Raw source systems may be tables, views, files, historians, archives, or APIs. Scientific modules operate on these source-independent contracts.

## A. `canonical_process_instance`
Minimum:
- process_instance_id;
- wafer_id;
- lot_id;
- batch/carrier id where applicable;
- operation_id / process_family;
- route_id / route_version;
- tool_id / chamber_id / module_id;
- recipe_id / recipe_version;
- start_time / end_time;
- rework/repeat/engineering flags;
- relevant shared entities (reticle/material/carrier/etc.) when available;
- source provenance;
- data-quality fields.

## B. `canonical_excursion_population`
- excursion_id;
- wafer_id;
- affected status;
- symptom/target;
- detection timestamp;
- last-known-good checkpoint if known;
- first-bad observation;
- raw severity;
- normalized severity by target/product context;
- membership provenance/confidence.

## C. `canonical_control_eligibility`
One row per excursion x potential control wafer:
- outcome opportunity;
- observed-normal status;
- product/route/time/rework context;
- pre-exposure trajectory summary;
- measurement comparability;
- exclusion reasons;
- control-pool tier.

Candidate-specific matching results are stored separately.

## D. `canonical_candidate_exposure`
One row per excursion x wafer x candidate:
- candidate entity/type;
- operation/process instance;
- exposed flag;
- exposure timing;
- duration/intensity/state if meaningful;
- pre/during/post exposure classification;
- route-expected probability if estimated.

## E. `canonical_alarm_episode`
- tool/chamber;
- alarm code/family;
- start/end/duration;
- toggle count;
- severity;
- equipment state;
- sensor/subsystem linkage if known;
- overlapping process instances;
- independence_group;
- data quality/provenance.

## F. `canonical_equipment_health`
At process time:
- time/runs/wafers since PM/clean;
- component/kit age;
- counters/interlocks;
- equipment state;
- previous alarm burden;
- seasoning/qualification state;
- maintenance/config/software changes;
- data quality/provenance.

## G. `canonical_fdc_feature`
- process_instance;
- sensor/feature;
- recipe step;
- feature value/unit;
- reference context;
- abnormality metrics;
- product-conditioned impact where available;
- independence_group;
- sensor/data quality.

## H. `canonical_metrology`
- wafer;
- measurement target/type;
- tool/recipe;
- event time;
- value;
- x/y/notch/field/die coordinates where available;
- valid historical limits;
- product-normalized residual;
- calibration/repeat context;
- outcome opportunity flag.

## I. `product_process_sensitivity`
- product family;
- route/layer/operation;
- parameter/FDC/spatial feature;
- valid dates;
- target/control/spec limits;
- robust context scale;
- empirical outcome sensitivity;
- uncertainty/source.

## J. `candidate_evidence`
One row per excursion x candidate x evidence item:
- candidate hierarchy;
- evidence channel;
- statistic/effect;
- polarity SUPPORT/CONTRADICTION/NEUTRAL/MISSING;
- contradiction severity NONE/SOFT/STRONG/FATAL;
- temporal validity;
- reliability;
- specificity;
- data quality;
- sample size;
- uncertainty;
- independence_group;
- product sensitivity context;
- source pointers/query IDs.

This is the audit backbone.

## K. `source_retention_registry`
- source role/table;
- earliest/latest event time;
- hot retention;
- archive/history source;
- partition/access method;
- schema-version semantics;
- event-time and knowledge-time fields;
- historical gaps;
- provenance.
