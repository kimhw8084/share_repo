# Scientific Challenge Tests — V2

These tests are intended to break the engine before production users do.

## 1. Ubiquitous routing trap
Construct an event where 100% of bad wafers and 97% of comparable good wafers use Tool A.
Expected: Tool A is flagged routing-commonality, not root cause.

## 2. Near-commonality true cause
One affected wafer is missing chamber history, while 19/20 known affected wafers share Chamber C and matched-good exposure is rare.
Expected: strict intersection fails descriptively but route-adjusted commonality still surfaces C with missing-data caveat.

## 3. Severe outlier dominance
One wafer has extreme defect severity while many moderately bad wafers point to another candidate.
Expected: primary commonality remains population-based; severity is separate evidence and cannot hijack discovery.

## 4. Correlated wafer pseudo-replication
25 affected wafers are from one batch/run.
Expected: report 25 wafer observations but ~1 relevant independent batch exposure where appropriate; uncertainty reflects clustering.

## 5. Exact-match control trap
When testing Chamber C, an intentionally bad matching configuration requires Chamber C in controls.
Expected: automated guardrail rejects the control specification for conditioning on tested exposure.

## 6. Latent upstream defect
A process several days/operations earlier creates a persistent state later detected downstream.
Expected: candidate remains inside causal horizon because state propagation is plausible despite long elapsed time.

## 7. False recent-cause bias
A downstream tool immediately before detection has a rare alarm but physically cannot create the target defect.
Expected: physics/temporal/state graph prevents promotion.

## 8. Product sensitivity interaction
Same FDC shift appears on products A and B; only A develops the defect.
Expected: raw abnormality is shared, product-impact evidence supports A-specific sensitivity rather than universal tool failure.

## 9. Product-normal spatial background
Product B has a normal radial pattern that resembles an excursion pattern on Product A.
Expected: product-specific expected map removes B's normal structure before RCA comparison.

## 10. Duplicate evidence trap
FDC pressure deviation triggers SPC flag and alarm.
Expected: all are tied to one independence group and do not count as three independent confirmations.

## 11. Soft contradiction
One noisy temperature sensor remains normal while route-adjusted commonality, pressure FDC, spatial signature, and intervention evidence strongly agree.
Expected: temperature is SOFT contradiction; candidate remains high confidence if justified.

## 12. Fatal temporal contradiction
Alarm and abnormal sensor state begin after all affected wafers have left the chamber.
Expected: proposed alarm state cannot be causal; candidate may retain separate historical/precursor evidence only if demonstrated.

## 13. Measurement-system false excursion
One metrology tool flags an excursion, cross-tool repeats are normal, upstream FDC is normal.
Expected: measurement system becomes leading candidate or engine abstains from process cause.

## 14. Combination cause
Neither Chamber C nor Recipe R alone is strongly enriched, but C+R combination is.
Expected: restricted interaction search surfaces C x R after single-candidate residual analysis.

## 15. Spurious combination explosion
Thousands of random pairs produce some low p-values.
Expected: staged candidate generation, complexity penalty, and interaction FDR prevent false promotion.

## 16. Mixed-cause registered event
Half the wafers show edge-ring pattern and Chamber C exposure; half show field-specific lithography pattern and Reticle R.
Expected: one-cause model leaves structured residuals and engine returns MIXED_CAUSE_SUSPECTED with subgroups.

## 17. APC feedback trap
A process parameter changes because upstream metrology already detected drift.
Expected: engine distinguishes controller response/mediator from initiating cause using temporal and process graph semantics.

## 18. Survivor / measurement-selection bias
Only suspicious wafers receive extra metrology.
Expected: unmeasured wafers are not labeled good; measurement opportunity is explicit.

## 19. Present-day metadata leakage
A tool configuration changed after a six-month-old event, but only current metadata is in live table.
Expected: historical resolver refuses to project current configuration backward without archive/effective-dated evidence.

## 20. Archive schema drift
Archived trajectory table uses old chamber identifiers/schema.
Expected: versioned adapter maps identifiers with provenance and reports unresolved history rather than silently joining incorrectly.

## 21. Good wafers on alleged cause during same bad state
Large matched-good group sees the same chamber and same abnormal state during the excursion window.
Expected: strong contradiction triggers search for interaction/product sensitivity/alternate cause.

## 22. Successful intervention
Candidate chamber is serviced, its FDC state normalizes, and subsequent comparable wafers recover.
Expected: intervention/recovery becomes strong independent evidence after replay ranking freeze.

## 23. Failed intervention
Candidate chamber is serviced but defect persists unchanged.
Expected: strong contradiction materially downgrades candidate unless intervention did not actually address the hypothesized mechanism.

## 24. Route branch confounding / Simpson's paradox
Raw fab-wide data implicates Tool A, but within each product/route stratum Tool A has no excess bad rate.
Expected: route-adjusted analysis removes the false association.

## 25. Nonstationary baseline
Tool process mix changes dramatically in the 30-day baseline.
Expected: exposure/context-conditioned baseline replaces naive calendar-rate comparison.
