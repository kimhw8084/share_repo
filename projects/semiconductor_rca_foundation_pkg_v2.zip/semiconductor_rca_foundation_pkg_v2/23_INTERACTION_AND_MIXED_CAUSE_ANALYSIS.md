# Interaction, Sequence, and Mixed-Cause Analysis

## Why this exists
Semiconductor manufacturing contains heterogeneous, sequential, and combinatorial process conditions. A cause can be:
- one entity;
- an interaction between entities;
- a specific ordered sequence;
- a susceptible product exposed to an otherwise tolerable drift;
- multiple independent causes grouped into one excursion event.

## Search stages
### Stage 1 — Single candidate screening
Find enriched operations/tools/chambers/recipes/materials/states with valid timing.

### Stage 2 — Residual diagnosis
After leading single candidates are modeled, inspect affected wafers that remain unexplained.

### Stage 3 — Restricted interactions
Generate interactions only from:
- top marginal candidates;
- physically linked subsystems/processes;
- frequent bad-only co-exposures;
- sequence motifs;
- candidate + product sensitivity;
- candidate + maintenance state.

### Stage 4 — Mixed-cause partition
If one coherent cause does not explain the population, cluster using pre-RCA observable features such as:
- defect/spatial signature;
- time;
- route branch;
- operation history;
- severity pattern.

Run the forensic pipeline per stable subgroup and compare against a one-cause model.

## Interaction representations
- unordered conjunction: A AND B;
- ordered motif: A -> B;
- state interaction: chamber C x PM_age_high;
- process-product: feature X x product P;
- cross-process: upstream state U x downstream process D.

## Statistical tests
Possible methods:
- logistic/ordinal/continuous model with interaction term;
- stratified 2x2/2xK contrasts;
- hierarchical shrinkage interaction model;
- control-enriched frequent itemset / sequence mining;
- sequence-aware attribution model after deterministic baseline.

## Strong hierarchy principle
Prefer interactions whose components have some marginal or physics-based justification. This limits false discoveries and improves interpretability.

## Synergy evidence
A combination is interesting when its joint effect materially exceeds what would be expected from the individual components and survives matched-good comparison.

Do not call two commonly co-routed tools a combination cause without excess joint enrichment.

## Complexity penalty
A two-factor explanation should outperform a one-factor explanation enough to justify additional complexity in held-out replay or likelihood/information criteria.

## Multiple testing
Interactions create a huge hypothesis space. Apply stricter staged screening/FDR than single-candidate analysis.
