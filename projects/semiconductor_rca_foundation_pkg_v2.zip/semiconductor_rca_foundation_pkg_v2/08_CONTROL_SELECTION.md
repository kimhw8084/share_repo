# Good-Control Definition and Candidate-Specific Selection V2

## Definition
For excursion symptom Y, a good control wafer is a wafer that:
1. had a meaningful opportunity to exhibit Y;
2. is comparable in relevant pre-exposure manufacturing context;
3. has evidence that Y was not present.

`GoodEligible = Comparable_PreExposure AND Observed_For_Target AND Normal_Outcome`

A wafer is not good merely because it is absent from the excursion list.

## Two-stage architecture
### Stage A — eligible good pool
Build a broad population with:
- product/device family;
- route/revision;
- operation history;
- time context;
- production/engineering class;
- rework state;
- measurement opportunity;
- observed normal target.

### Stage B — candidate-specific contrast
For candidate C, select/match/stratify controls using variables measured **before C** that influence exposure/outcome, while intentionally leaving C unconstrained.

## Why exact full-route matching is usually wrong
When testing chamber C, requiring controls to have exact chamber C removes the exposure contrast. When testing recipe revision R, exact-matching R does the same.

Exact sequence matching can be useful for every dimension *except* the tested exposure and its descendants, but often leaves too few controls.

## Preferred matching variables
Where relevant:
- same/compatible product/device family;
- route and route revision;
- same causal operation;
- pre-operation process history or route embedding;
- recipe family/version if recipe is not the candidate;
- time neighborhood;
- rework/hold/engineering status;
- incoming/previous measurement state where pre-treatment;
- comparable measurement opportunity.

## Forbidden/unsafe matching
Do not condition on:
- candidate exposure itself;
- downstream FDC or metrology influenced by the candidate;
- post-treatment holds/rework caused by the excursion;
- closure/corrective-action information.

## Control tiers
- within-lot observed-good wafers;
- same product/route/operation/time;
- same operation/recipe on peer chambers;
- same chamber before/after state for temporal comparison;
- historical same chamber+recipe for equipment baseline;
- NPW/monitor/qualification as independent equipment evidence, not automatically product controls.

## Candidate-specific positivity
If all comparable wafers receive the same candidate, observational data cannot distinguish its causal effect from the route. Mark `NO_EXPOSURE_CONTRAST` or `ROUTING_COMMONALITY` rather than manufacturing a conclusion.

## Sampling bias
Unmeasured wafers remain UNKNOWN unless another valid target measurement proves normality. Record the sampling/inspection policy when possible.

## Match diagnostics
For every candidate contrast report:
- affected count and independent cluster count;
- eligible control count;
- matched/weighted control count;
- time distance;
- product/route balance;
- measurement opportunity balance;
- exposure overlap/positivity;
- exclusions;
- sensitivity to alternative control definitions.

## Robustness
A strong candidate should persist across multiple defensible control constructions. Large ranking changes under minor control changes indicate fragility and reduce confidence.
