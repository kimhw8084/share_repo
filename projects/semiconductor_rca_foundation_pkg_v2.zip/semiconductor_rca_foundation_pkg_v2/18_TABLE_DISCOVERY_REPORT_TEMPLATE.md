# Table Discovery Report — V2 Template

## Identity
- Source table/system:
- Owner/source if known:
- Discovery date:
- Query dialect/access method:

## Inferred grain
- Proposed row grain:
- Evidence:
- Confidence: High / Medium / Low

## Keys
- Confirmed unique/composite key:
- Candidate keys tested:
- Duplicate/revision behavior:

## Time semantics
- Manufacturing event timestamp(s):
- Effective-date timestamp(s):
- Measurement timestamp(s):
- Ingestion/knowledge timestamp(s):
- Administrative timestamp(s):
- Earliest/latest queryable event time:
- Precision/timezone/clock caveat:
- Historical/effective-dated/current-state classification:

## Retention / archive
- Apparent hot retention:
- Older history location:
- Archive access method:
- Partition/date key:
- Historical schema-version issue:
- Uncovered time periods:

## Quality
- Row count/estimate:
- Null-heavy fields:
- Sentinel/invalid patterns:
- Duplicate rate:
- Data gaps:
- Units/documentation status:

## Canonical mappings
- Canonical entity/entities:
- Field mapping:
- Candidate product/process sensitivity fields:

## Join tests
For each target:
- condition;
- source coverage;
- target coverage;
- cardinality;
- multiplication factor;
- unmatched pattern;
- historical validity.

## Forensic role
- outcome / membership / trajectory / equipment / alarm / FDC / PM / metrology / material / facilities / reference / other;
- can establish causal timing?;
- contains outcome/post-event leakage risk?;
- likely evidence channel?;

## Evidence dependency
- Is this derived from another sensor/table?;
- proposed `independence_group`;
- double-counting risk.

## Warnings
- ...

## Decision
- APPROVED_FOR_CAUSAL_USE
- APPROVED_WITH_LIMITATIONS
- REFERENCE_ONLY
- ARCHIVE_REQUIRED
- NOT_YET_UNDERSTOOD
