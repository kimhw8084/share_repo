# Prompt — Build Foundation

Using the validated table registry, implement only the deterministic foundation first:
1. Historical Data Resolver.
2. Canonical process-instance lineage.
3. Excursion target/affected population.
4. Last-known-good/first-known-bad + physics-aware causal horizon.
5. Eligible good-outcome pool.
6. Candidate generation.
7. Candidate-specific control construction.
8. Route-adjusted bad-versus-good commonality.
9. Separate severity/dose-response analysis.
10. Equipment/alarm/PM/FDC/metrology evidence modules.
11. Product-process sensitivity layer.
12. Physics state propagation and mechanism checks.
13. Dependency-aware evidence store.
14. Fatal/strong/soft contradiction logic.
15. Restricted interaction/mixed-cause extension.
16. Historical replay harness.

Do not build a generic black-box root-cause classifier as the foundation.
