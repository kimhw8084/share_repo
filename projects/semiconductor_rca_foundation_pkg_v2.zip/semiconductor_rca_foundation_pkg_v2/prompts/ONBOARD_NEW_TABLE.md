# Prompt — Onboard New Table

New source table(s):
`<TABLE NAMES>`

Follow `02_DATA_DISCOVERY_PROTOCOL.md` and `18_TABLE_DISCOVERY_REPORT_TEMPLATE.md`.

Do not assume meaning from column names alone. Infer and validate:
- row grain;
- keys/duplicates;
- event/effective/knowledge timestamps;
- time coverage and archive/retention behavior;
- units/cardinality/nulls;
- joins and row multiplication;
- historical validity;
- canonical role;
- outcome-leakage risk;
- evidence dependency/independence groups.

Update:
- `config/table_registry.yaml`
- `config/source_retention_registry.yaml`

Then state which RCA capabilities this source enables or improves and which assumptions remain unresolved.
