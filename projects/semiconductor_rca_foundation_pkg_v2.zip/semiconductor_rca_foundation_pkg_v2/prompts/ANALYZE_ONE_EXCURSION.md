# Prompt — Analyze One Excursion

Excursion: `<EXCURSION_ID>`

Run the V2 forensic pipeline and return:
- target symptom and onset interval;
- historical/source coverage;
- affected wafer/lot population;
- causal horizon;
- eligible good pool;
- top candidates with strict intersection only as a diagnostic;
- route-adjusted bad-vs-good enrichment;
- route-commonality flags;
- severity/dose-response evidence;
- equipment/alarm/PM/FDC evidence;
- product sensitivity interpretation;
- product-normalized metrology/spatial evidence;
- physics mechanism consistency;
- competing hypotheses;
- restricted interactions if justified;
- mixed-cause assessment;
- evidence independence groups;
- FATAL/STRONG/SOFT contradictions;
- C0-C5 evidence class;
- next-best discriminating test;
- abstention if evidence is insufficient.
