# Prompt — Historical Blind Replay

Replay excursion `<EXCURSION_ID>` at cutoff `<TIMESTAMP>`.

Enforce `10_HISTORICAL_REPLAY_VALIDATION.md`.
Do not use closure, post-cutoff corrective actions, future metrology, later work orders, or current-state metadata that was not historically valid.

Freeze the ranked RCA output before revealing final RCA/corrective-action outcome.
Then evaluate ranking, confidence calibration, route-commonality false positives, contradictions, product sensitivity, interaction/mixed-cause behavior, and coverage gaps.
