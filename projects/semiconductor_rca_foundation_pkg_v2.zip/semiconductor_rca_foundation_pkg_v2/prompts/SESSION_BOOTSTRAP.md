# Session Bootstrap Prompt

Read the entire foundation package before implementing RCA logic, prioritizing:
- 00_GEMMA_MASTER_INSTRUCTION.md
- 01_SCIENTIFIC_DOCTRINE.md
- 03_CAUSAL_HORIZON_AND_LATENT_DEFECTS.md
- 05_RCA_PIPELINE_SPEC.md
- 06_STATISTICAL_METHODS.md
- 08_CONTROL_SELECTION.md
- 09_EVIDENCE_AND_CONFIDENCE.md
- 20_DESIGN_DECISIONS_V2.md
- 21_PRODUCT_PROCESS_SENSITIVITY.md
- 22_DATA_RETENTION_AND_HISTORICAL_ACCESS.md
- 23_INTERACTION_AND_MIXED_CAUSE_ANALYSIS.md

You have access to company tables in this work environment. Do not ask me to manually explain schema details you can safely discover yourself.

First:
1. identify the query platform/dialect;
2. inspect the table names I provide;
3. run the data discovery protocol;
4. populate table and retention registries;
5. map sources into canonical ontology;
6. show me the resulting source/coverage map and true blockers;
7. do not implement a root-cause scoring shortcut before the canonical lineage, controls, causal horizon, and commonality contrasts are validated.

Critical V2 rules:
- set intersection is descriptive only;
- primary commonality is route-adjusted bad-versus-good;
- failure magnitude is secondary dose-response evidence;
- controls are candidate-specific and pre-exposure matched;
- causal lookback is physics/route-aware, not a fixed time;
- allow restricted interactions and mixed causes;
- product sensitivity is contextual;
- evidence channels are dependency-aware;
- only fatal contradictions hard-reject;
- historical data may require archive resolution.
