# Tests and Guardrails V2

## Data / history tests
- process-instance key integrity;
- start <= end;
- trajectory ordering and rework semantics;
- valid tool/chamber hierarchy;
- route/recipe version coverage;
- hot/archive coverage reconciled;
- historical metadata effective-dated correctly;
- no uncontrolled many-to-many multiplication;
- current-state metadata cannot masquerade as historical configuration.

## Causal-horizon tests
- no universal fixed day/step cutoff used as causal truth;
- last-known-good checkpoint is sensitive to the target precursor before acting as a barrier;
- older persistent-state processes are retained when physics allows propagation;
- post-processing evidence is labeled correctly.

## Control tests
- every good control has outcome opportunity;
- affected wafers excluded from same-event controls;
- candidate-specific matching does not condition on candidate exposure;
- no downstream/post-treatment matching;
- overlap/positivity reported;
- route/time/product balance reported;
- sensitivity across alternate control definitions measured.

## Commonality tests
- strict intersection cannot directly create high confidence;
- route-common entity with equal good exposure receives `ROUTING_COMMONALITY`;
- residual enrichment is computed within comparable strata;
- wafer/lot/batch support is reported;
- correlated wafers do not create false precision.

## Severity tests
- primary commonality is unchanged by arbitrary defect-magnitude weights;
- severity analysis uses product/target normalization;
- dose-response model reports uncertainty;
- extreme single wafer cannot dominate without explicit evidence.

## Statistics tests
- zero baselines handled with shrinkage/uncertainty;
- overdispersion checked;
- alarm episodes replace raw toggles for rate analysis;
- exposure denominator explicit;
- autocorrelation/process-step context considered;
- multiple-testing/FDR executed per hypothesis family;
- interaction hypothesis space is staged/restricted.

## Evidence dependency tests
- alarm/FDC/SPC derived from same sensor share independence group;
- repeated transforms of same wafer map are not counted as independent physical channels;
- confidence logic counts independent groups, not rows.

## Contradiction tests
- FATAL contradiction rejects candidate;
- STRONG contradiction materially downgrades/caps confidence;
- SOFT contradiction does not automatically force C0;
- one noisy normal sensor can be overridden by multiple strong independent supports;
- true temporal impossibility cannot be overridden.

## Product sensitivity tests
- parameter percent drift is not interpreted globally;
- historical specs are effective-dated;
- sparse products use hierarchical pooling/uncertainty;
- product-specific spatial normal map is separated from excursion residual.

## Interaction / mixed-cause tests
- single-cause cases do not trigger unnecessary combinatorial explanations;
- interaction must add explanatory value beyond components;
- mixed-cause subgroup analysis uses pre-RCA observable features;
- complexity penalty / multiple-testing control exists.

## FDC tests
- recipe-step alignment;
- unit/sensor alias consistency;
- missingness quantified;
- data leakage prohibited;
- product sensitivity applied separately from raw abnormality.

## Metrology tests
- measurement system can be a candidate;
- orientation/coordinate normalization;
- product-normal spatial residual where possible;
- repeat/cross-tool evidence provenance maintained.

## Replay leakage tests
- closure fields blocked;
- future timestamps blocked;
- post-fix evidence blocked before ranking freeze;
- knowledge-time enforced where available;
- archive adapters do not expose current metadata as historical state.

## LLM guardrails
- LLM may inspect/propose schema semantics but must validate with data/joins/docs;
- LLM may summarize free text and map vocabulary to ontology with provenance;
- LLM may not fabricate units, joins, physical mechanisms, thresholds, PM steps, archive paths, or product sensitivities;
- LLM narrative cannot override fatal temporal/exposure logic;
- uncertainty must remain explicit.
