# Causal Horizon and Latent / Propagating Defects

## Purpose
Define how far upstream the engine should search when a defect is detected downstream.

## Core principle
Do not use a universal lookback such as 30 days, 100 process steps, or N hours.

The causal horizon is determined by:
- manufacturing sequence;
- last-known-good / first-known-bad evidence;
- physical state propagation;
- measurement sensitivity;
- process transformations that can create, preserve, amplify, mask, or remove a defect precursor.

## Defect onset as an interval
When the exact creation time is unknown, represent:
`onset_interval = (last_checkpoint_that_rules_out_precursor, first_observation_of_symptom]`

This is interval-censored causal timing, not a single guessed timestamp.

## Process-state propagation graph
Represent important persistent wafer states such as:
- geometry / pattern fidelity;
- film thickness / composition / stress;
- dopant concentration / profile;
- contamination / particles;
- interface condition;
- crystal/plasma/charging damage;
- overlay / alignment;
- surface condition / residue;
- thermal budget / activation state.

For each process family, define which state domains it can modify and which downstream measurements can observe them.

A process remains in the causal horizon if a physically plausible state path connects it to the observed symptom.

## Causal barriers
A lookback may stop or sharply reduce priority when a trusted operation/measurement establishes that the relevant state was normal after the candidate process.

Examples of potential barriers:
- reliable post-operation metrology that directly measures the target state;
- removal/replacement of the affected film/material when the hypothesized defect cannot survive;
- a validated process transformation that destroys the relevant precursor;
- independent electrical/physical checkpoint inconsistent with the hypothesized latent state.

Do not assume a measurement is a barrier unless it is actually sensitive to the precursor being excluded.

## Fallback behavior
If the process-state graph is incomplete:
1. include the entire upstream wafer trajectory to the earliest relevant route boundary;
2. rank operations by process-family compatibility and evidence;
3. do not hard-exclude older operations solely due to elapsed time.

## Search prioritization
Use priority tiers rather than a hard cutoff:
- Tier 1: operations between last-known-good and first-bad that directly create the measured state;
- Tier 2: upstream operations known to create persistent precursors affecting Tier-1 outputs;
- Tier 3: older operations with plausible propagation but weak direct connection;
- Tier 4: retained only as alternate hypotheses.

## Time-based evidence
Equipment alarm/FDC evidence should be tightly anchored to the wafer's processing exposure even when the resulting defect is detected much later.

Example:
An etch defect detected at downstream inspection may trace to an etch chamber three days earlier. Alarm/FDC evidence relevant to causation is the chamber state at that etch process instance, not the time of later inspection.

## Historical replay
The engine may use upstream history that existed before detection, but it may not use post-detection corrective-action knowledge to influence the frozen pre-detection ranking.
