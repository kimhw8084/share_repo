# Statistical Methods Specification V2

## 1. Commonality is a contrast, not an intersection

For candidate exposure C and outcome Bad/Good, begin with a 2x2 contrast inside comparable manufacturing strata.

Always report:
- bad exposure fraction;
- good exposure fraction;
- smoothed risk ratio;
- smoothed odds ratio / log odds ratio;
- uncertainty interval;
- sample counts at wafer and independent cluster level;
- adjusted q-value within candidate family.

Strict set intersection is a descriptive feature only.

## 2. Route-adjusted commonality

Estimate the expected exposure under normal routing using eligible good wafers matched/stratified by pre-exposure context.

Possible estimators:
- exact/coarsened matching + 2x2;
- conditional logistic regression;
- Mantel-Haenszel-type stratified effect;
- hierarchical logistic regression with product/route/time effects;
- within-stratum permutation null.

Flag high raw commonality with weak residual enrichment as `ROUTING_COMMONALITY`.

## 3. Inverse-prevalence screening
Optional candidate screening may use background rarity such as:
`rarity_weight(C) = log((N_good + k)/(N_good_exposed(C) + k))`

Do not treat this as final causal score; it is only search prioritization.

## 4. Candidate-specific controls
Matching/stratification must be rebuilt or revalidated per candidate so the tested exposure is not conditioned away.

Report positivity/overlap. If essentially every comparable wafer receives the candidate exposure, causal discrimination for that candidate may be impossible from observational commonality.

## 5. Statistical unit and clustering
Wafers from the same lot/batch/chamber-run can be correlated.

Use as appropriate:
- cluster-robust uncertainty;
- generalized estimating equations;
- mixed/hierarchical models;
- beta-binomial/binomial hierarchical models;
- report lot-level replication separately.

Do not manufacture confidence by treating correlated wafers as independent.

## 6. Failure magnitude / dose response
Primary commonality is not severity weighted.

Secondary model uses normalized target severity:
- continuous: robust regression / mixed model / GAM when justified;
- ordinal: ordinal logistic/probit;
- pass/fail + severity: two-part model if useful;
- defect/reject counts: binomial/beta-binomial/negative-binomial depending denominator and dispersion.

Test interaction with product/process sensitivity.

## 7. Alarm episodes
Collapse raw toggles into episodes using set/clear semantics or validated debounce logic.
Preserve raw count, episode count, duration, toggle intensity, severity, and subsystem/sensor mapping.

## 8. Exposure-normalized rates
Use the denominator justified by physics/context:
- comparable wafer runs;
- recipe executions;
- process hours;
- plasma-on time;
- RF hours;
- tool-active time;
- batch cycles;
- another justified exposure unit.

Calendar days alone are usually insufficient when utilization varies.

## 9. Sparse count models
Options:
- Poisson with exposure offset when dispersion is credible;
- Gamma-Poisson/Bayesian rate model for shrinkage and zero baselines;
- Negative Binomial for overdispersion;
- zero-inflated/hurdle variants only when data-generating behavior justifies them.

Useful outputs include posterior rate ratio intervals and probability of operationally meaningful uplift.

## 10. SPC / time-series change detection
Choose based on failure morphology:
- median/MAD robust z: isolated deviation;
- Shewhart-like large shift;
- EWMA: gradual drift;
- CUSUM: persistent small shift;
- change-point detection: regime transition;
- variance/scale change;
- Hotelling T2 / PCA score;
- PCA Q/SPE residual;
- robust Mahalanobis;
- covariance/correlation drift.

Respect autocorrelation and process-step structure.

## 11. Three baseline principle
Where available compare:
1. candidate self-history;
2. peer/sister chamber under comparable conditions;
3. good-outcome runs.

Record agreement and contradiction separately.

## 12. Product-process sensitivity
Maintain two separate scores:
- abnormality of x under comparable processing;
- expected materiality for the target product/outcome.

Use product/route/recipe hierarchical baselines and valid historical specifications.

## 13. Spatial statistics
First remove expected product/measurement spatial structure when possible.
Then evaluate residual:
- center/edge;
- radial bins/gradient;
- azimuthal harmonics;
- top-bottom / left-right asymmetry;
- spatial autocorrelation;
- local clusters/hotspots;
- line/scratch orientation;
- reticle field/shot-level aggregation;
- die/layout-region aggregation when available.

## 14. Interactions
Do not enumerate all pairs/triples.
Restricted methods:
- regression interaction terms;
- hierarchical shrinkage;
- enriched frequent itemsets;
- ordered sequence motifs;
- candidate x product;
- candidate x degradation state.

A combination must show incremental explanatory value beyond its components.

## 15. Mixed-cause population tests
If residual affected wafers remain unexplained, compare:
- one-cause model;
- subgroup/mixture model based on pre-RCA observable features.

Use stability across resampling and blind replay; avoid clustering purely to maximize apparent significance.

## 16. Evidence combination
Do not casually combine p-values across dependent channels.

Track an `independence_group` for evidence that shares underlying signals. Later probabilistic fusion should operate on calibrated, dependency-aware evidence features rather than assuming conditional independence.

## 17. Contradiction handling
Contradiction evidence has strength/reliability. Fatal logical contradictions are gates; soft contradictions are negative evidence, not automatic rejection.

## 18. Multiple testing
Define hypothesis families:
- single commonality;
- alarms/events;
- FDC features;
- spatial features;
- interactions/sequences.

Use staged/hierarchical screening and FDR or equivalent control. Interactions require stricter screening because the candidate space is much larger.

## 19. Sequential/trajectory models
After the deterministic baseline, evaluate process-sequence approaches such as PTR, Trajectory Shapley Attribution, or Potential Loss Analysis. They must prove incremental value in held-out historical replay.

## 20. Calibration
Do not call a model output `probability of root cause` until calibrated on held-out historical incidents. Evaluate calibration overall and by process/product family when data volume permits.
