# Data Retention, Archive, and Historical Access Contract

## Principle
RCA logic must be independent of whether source records reside in a live MES table, warehouse, historian, archive, lake, or cold tier.

## Source retention registry
For every source table/system record:
- source_name;
- logical_role;
- hot_retention_days if known;
- earliest_available_event_time;
- latest_available_event_time;
- archive_source/location;
- archive_access_method;
- partition/date key;
- schema_version behavior;
- event_time field;
- ingestion/knowledge_time field if available;
- snapshot/effective-dating semantics;
- expected gaps;
- historical query example;
- owner/documentation reference.

## Historical Data Resolver interface
The scientific modules request canonical data by entity + event-time range. They do not directly assume one physical table.

Conceptual interface:
`resolve(dataset_role, entity_filter, event_start, event_end, as_of_time=None)`

Resolver behavior:
1. inspect registered coverage;
2. query live/hot source;
3. measure returned time coverage;
4. if incomplete, query registered archive/history source;
5. apply schema-version adapter;
6. deduplicate by canonical event identity;
7. return provenance by row/partition;
8. return explicit uncovered intervals.

## Replay knowledge time
Where possible distinguish:
- event time: when manufacturing event occurred;
- knowledge/ingestion time: when the information became available to the analytical system.

Historical blind replay must enforce `knowledge_time <= replay_cutoff` when that timestamp exists.

## Historical metadata
Never apply present-day recipe/tool metadata to a six-month-old event unless the field is demonstrably time-invariant. Use effective-dated configuration or label the assumption.

## Failure mode
If required historical coverage is unavailable:
`HISTORICAL_COVERAGE_INSUFFICIENT`

The engine must reduce confidence or abstain rather than infer missing trajectory from current-state tables.

## Recommended internal improvement
If company policy permits, create a curated immutable forensic history layer containing the canonical lineage/equipment metadata needed for reproducible RCA. This is an implementation optimization, not a requirement of the scientific method.
