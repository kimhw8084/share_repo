# Historical Blind Replay Validation V2

## Purpose
Prove the engine discriminates causes rather than reconstructing closure narratives or overfitting one control definition.

## Replay clock
For each event define a realistic investigation cutoff. Enforce both event-time and, where available, knowledge/ingestion-time constraints.

## Historical resolver requirement
Before scoring, verify that trajectory/equipment/metadata coverage for the historical period is complete enough. Record archive sources and gaps.

## Hidden during pre-cutoff scoring
- final root cause;
- closure narrative;
- future engineering comments;
- corrective actions after cutoff;
- future work orders revealing cause;
- post-event qualification/results;
- future metrology.

These can be revealed only after the candidate ranking is frozen.

## Evaluation levels
- operation;
- tool;
- chamber/module;
- subsystem/component where truth is reliable;
- mechanism category;
- single vs interaction vs mixed-cause classification.

Historical RCA labels carry confidence: confirmed/probable/suspected/unknown.

## Primary ranking metrics
- Top-1 accuracy;
- Top-3 / Top-5 recall;
- mean reciprocal rank;
- operation/chamber accuracy;
- false-candidate burden;
- coverage/abstention rate;
- mixed-cause detection quality where labels permit.

## Commonality validation
Compare:
- strict intersection baseline;
- raw bad-only overlap;
- route-adjusted bad-vs-good engine.

The new method should demonstrate reduced routing false positives.

## Severity validation
Evaluate binary commonality and severity/dose-response separately. Verify that severity weighting does not distort primary candidate ranking on events with one or two extreme wafers.

## Product sensitivity validation
Where multiple products exist, test whether product-conditioned baselines improve attribution/calibration versus global thresholds.

## Contradiction ablation
Replay cases containing known noisy sensors/partial contradictions. Verify:
- fatal contradictions still reject;
- soft contradictions do not automatically force C0;
- correlated support is not double counted.

## Interaction validation
Create/identify cases with:
- single-point cause;
- candidate interaction;
- mixed-cause population.

Require interaction search to improve performance without materially increasing false candidate burden on single-cause events.

## Calibration
After enough cases:
- reliability curve;
- Brier score or appropriate probabilistic calibration metric;
- calibration by process family/product family where sample sizes permit;
- confidence-class precision.

## Robustness tests
- vary good-control window;
- candidate-specific versus fixed control set;
- remove one evidence group at a time;
- merge correlated evidence channels and confirm confidence does not inflate;
- perturb timestamp tolerance;
- vary causal-horizon fallback;
- compare self/peer/good baselines;
- test route-stratified permutation null;
- test alternative product spatial baselines;
- test with/without free-text fields;
- test archive versus hot-table extraction consistency.

## Leakage assertions
Automate checks that no closure-derived, corrective-action, post-cutoff, or present-day-only metadata enters the frozen replay features.

## Promotion principle
Do not claim readiness from cherry-picked incidents. Use a representative cohort and document exclusions, historical-coverage limitations, and label uncertainty.
