# Evidence Fusion, Reliability, Contradictions, Confidence, and Abstention V2

## 1. Evidence channels
Maintain at least:
1. actual exposure;
2. route-adjusted commonality/counterfactual;
3. severity/dose-response;
4. temporal consistency;
5. alarm/equipment-state anomaly;
6. PM/degradation;
7. FDC/process sensor;
8. product-process sensitivity;
9. physical-mechanism compatibility;
10. metrology/spatial concordance;
11. measurement-system health;
12. intervention/recovery;
13. competing hypotheses;
14. data quality/historical coverage.

## 2. Evidence channels are not equal
Every evidence item stores:
- polarity: SUPPORT / CONTRADICTION / NEUTRAL / MISSING;
- strength/effect size;
- uncertainty;
- reliability;
- temporal validity;
- specificity to hypothesized mechanism;
- data quality;
- sample/cluster count;
- independence_group;
- source provenance.

Do not apply equal weights.
Do not assume one universal ranking fits all process families.

## 3. Default diagnosticity prior
As a starting engineering prior—not calibrated truth—evidence tends to become more diagnostic when it moves from generic association toward specific physical and interventional evidence:
- generic alarm rarity: usually weak-to-moderate;
- strong route-adjusted commonality: necessary association evidence;
- direct equipment/FDC physical deviation at causal time: stronger when specific;
- product-normalized spatial/mechanism concordance: strong independent physical support;
- successful controlled intervention/recovery: very strong when unambiguous.

An alarm/interlock directly representing a physical failure may be stronger than a weak FDC deviation. An OOS result can be measurement-generated. Always evaluate specificity and reliability.

## 4. Evidence independence
Do not count the same physical fact multiple times.

Examples:
- pressure FDC trace + pressure-derived SPC flag + pressure alarm may share one independence group;
- a defect map classifier and features calculated from the same map are not independent physical confirmations;
- work-order text and maintenance event generated from the same intervention are one intervention source.

High confidence requires multiple **independent or conditionally distinct** evidence groups, not merely multiple rows.

## 5. Hard causal gates
A candidate is `REJECTED` when a high-certainty fatal contradiction proves:
- no exposure occurred for the population it claims to explain;
- causal condition occurs only after processing with no plausible earlier precursor;
- process/entity cannot physically influence the target state under the proposed mechanism;
- verified identity mapping shows the wrong tool/chamber/entity.

Do not override these gates with a weighted score.

For mixed-cause analysis, no-exposure on some affected wafers may mean the candidate explains a subgroup rather than the entire excursion.

## 6. Strong contradictions
Examples:
- large well-matched good population receives same exposure/state with normal outcome;
- independent direct measurement contradicts predicted mechanism;
- product-normalized spatial signature conflicts with physical prediction;
- intervention changes candidate state but the target defect persists in a well-powered comparable post-intervention cohort;
- stronger alternate commonality explains the same subset.

Strong contradictions materially cap/downgrade confidence but are not automatically fatal in the presence of uncertainty or effect modification.

## 7. Soft contradictions
Examples:
- one noisy sensor remains normal;
- one expected alarm is absent;
- one good wafer survives exposure;
- sparse peer comparison is neutral/weakly inconsistent.

Soft contradictions reduce evidence modestly and can be overcome by strong independent support.

## 8. Candidate status is separate from confidence
Status:
- ACTIVE;
- REJECTED_FATAL;
- ROUTING_COMMONALITY;
- NO_EXPOSURE_CONTRAST;
- MIXED_CAUSE_SUBGROUP;
- INSUFFICIENT_DATA.

Confidence class applies primarily to ACTIVE/MIXED_CAUSE_SUBGROUP candidates.

## 9. Confidence classes
### C0 — Unsupported
No coherent causal evidence or only weak noise.

### C1 — Candidate signal
Interesting anomaly/commonality but limited counterfactual/physical support.

### C2 — Strong route-adjusted association
Clear enrichment beyond normal routing with valid timing and adequate controls.

### C3 — Association + independent process/equipment evidence
C2 plus one or more credible physical/equipment/FDC/degradation evidence groups.

### C4 — Physical causal chain
C3 plus independent product-normalized metrology/spatial/mechanism concordance or equivalent strong physical corroboration, without unresolved major contradiction.

### C5 — Confirmed-like forensic chain
C4 plus strong intervention/recovery or another exceptionally strong independent confirmation chain.

These are evidence classes, not probabilities.

## 10. Correlated support rule
Three support signals from one sensor independence group do not satisfy a three-channel requirement. Count independent groups, not labels.

## 11. Probability calibration later
After blind replay, fit a calibrated model to the evidence vector. Candidate approaches include regularized hierarchical logistic models or gradient boosting with calibration, subject to monotonic/scientific sanity checks.

Consider calibration by process family/product family if sample sizes support it.

## 12. Abstention triggers
Return `INSUFFICIENT_EVIDENCE` when:
- affected population is ambiguous;
- good outcome opportunity is inadequate;
- historical trajectory coverage is materially incomplete;
- exposure contrast is absent for leaders;
- timestamp ordering is unreliable;
- leaders remain statistically/physically indistinguishable;
- measurement artifact remains equally plausible;
- evidence is dominated by one correlated source;
- no hypothesis reaches the required evidence class.

Return `MIXED_CAUSE_SUSPECTED` rather than forcing one root cause when coherent subgroups support different causes.
