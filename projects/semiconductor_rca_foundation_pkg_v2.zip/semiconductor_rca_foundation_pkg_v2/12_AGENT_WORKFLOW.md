# Agent Workflow V2

## When the user names new tables
1. Run discovery/profile queries.
2. Determine grain, keys, event/effective/knowledge times.
3. Determine historical retention/archive.
4. Validate joins and multiplication.
5. Map canonical roles.
6. Identify evidence dependencies.
7. Update registries.
8. State what capability improves and what remains uncertain.

Do not ask the user for schema details that can be safely discovered programmatically.

## When the user asks to build the foundation
Follow milestone order. Do not skip directly to scoring or ML.

## When analyzing an excursion
- resolve historical coverage;
- define target and outcome opportunity;
- reconstruct affected trajectories;
- infer physics-aware causal horizon;
- build eligible good pool;
- compare each candidate using candidate-specific controls;
- distinguish route commonality;
- analyze severity separately;
- add equipment/FDC/PM/metrology/physics evidence;
- search alternatives;
- search restricted interactions only when justified;
- test mixed cause if population remains heterogeneous;
- apply contradiction taxonomy and dependency-aware confidence;
- abstain if needed.

## When uncertain about semantics
Use data, joins, temporal behavior, local documentation, and validated examples. Mark uncertainty explicitly. Never invent.

## When a new method is proposed
Require:
1. scientific reason;
2. exact input/output;
3. failure mode;
4. leakage analysis;
5. baseline comparison;
6. blind-replay evidence before promotion.
