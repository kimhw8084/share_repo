# Implementation Pseudocode Contract V2

Language/platform independent. SQL/Python/Spark/Polars/etc. may vary, scientific behavior may not.

```text
function analyze_excursion(excursion_id, replay_cutoff=null):
    coverage = historical_resolver.check_required_coverage(excursion_id, replay_cutoff)
    if coverage.critical_gaps:
        record_quality_gate("HISTORICAL_COVERAGE_INSUFFICIENT", coverage)

    event = load_excursion(excursion_id, replay_cutoff)
    population = resolve_affected_population(event, replay_cutoff)
    target = define_excursion_target(event, population)
    normalize_failure_severity(population, target)

    trajectories = reconstruct_trajectories(
        population.affected_wafers,
        historical_resolver,
        replay_cutoff
    )
    trajectory_quality = evaluate_trajectory_quality(trajectories)

    onset_interval = infer_last_good_first_bad(event, population, trajectories, target)
    causal_horizon = build_physics_aware_causal_horizon(
        trajectories,
        target,
        onset_interval,
        process_state_graph
    )

    good_pool = build_eligible_good_outcome_pool(
        target=target,
        affected_population=population,
        historical_resolver=historical_resolver,
        replay_cutoff=replay_cutoff
    )
    validate_outcome_opportunity(good_pool)

    candidates = enumerate_single_candidates(causal_horizon)

    commonality_results = []
    for candidate in candidates:
        contrast = build_candidate_specific_controls(
            candidate,
            affected=population,
            eligible_good_pool=good_pool,
            match_pre_exposure_only=true,
            exclude_candidate_from_matching=true,
            exclude_descendants_from_matching=true
        )

        descriptive = compute_intersection_and_near_intersection(candidate, population)

        commonality = route_adjusted_bad_good_contrast(
            candidate,
            affected=population,
            controls=contrast,
            cluster_units=[lot, batch_or_carrier_when_relevant]
        )

        commonality.routing_flag = classify_routing_commonality(commonality, contrast)
        commonality.temporal_validity = candidate_temporal_validity(candidate, causal_horizon)
        commonality_results.append(commonality + descriptive)

    commonality_results = apply_multiple_testing(
        commonality_results,
        family="single_candidate_commonality"
    )

    leaders = screen_candidates(commonality_results)

    for candidate in leaders:
        severity = analyze_dose_response(
            candidate,
            normalized_target_severity=population.severity,
            candidate_controls=candidate.control_set,
            product_sensitivity_context=true,
            clustered=true
        )
        persist_evidence(candidate, severity)

        if candidate.is_equipment_related:
            alarm_episodes = construct_alarm_episodes(candidate, replay_cutoff)
            map_evidence_independence_groups(alarm_episodes)

            exposure = determine_physical_exposure_denominator(
                candidate, trajectories, candidate.control_set
            )

            alarm_stats = compare_event_vs_historical_rate(
                alarm_episodes,
                exposure,
                sparse_count_model="auto"
            )
            state_stats = analyze_equipment_state(candidate, replay_cutoff)
            drift_stats = run_signal_appropriate_change_detection(candidate)
            peer_stats = compare_peer_chambers(candidate)
            good_run_stats = compare_good_outcome_runs(candidate)
            health = compute_maintenance_degradation_state(candidate, trajectories)

            persist_evidence(candidate,
                             alarm_stats, state_stats, drift_stats,
                             peer_stats, good_run_stats, health)

    fdc_targets = choose_fdc_targets(leaders)
    for candidate in fdc_targets:
        baseline_runs = select_comparable_good_runs(candidate)
        aligned = align_fdc_by_recipe_step(candidate, baseline_runs)
        features = extract_interpretable_fdc_features(aligned)
        fdc_stats = compare_fdc_self_peer_good(candidate, features, baseline_runs)
        fdc_stats = attach_product_process_sensitivity(fdc_stats, target)
        fdc_stats = assign_independence_groups(fdc_stats)
        persist_evidence(candidate, fdc_stats)

    measurement_health = analyze_measurement_system(target, replay_cutoff)
    expected_map = estimate_product_normal_spatial_field(target, good_pool)
    spatial_signature = characterize_residual_spatial_signature(
        event, population, expected_map
    )
    persist_evidence("measurement_system", measurement_health)

    for candidate in top_candidates():
        physics = check_process_state_and_mechanism_compatibility(
            candidate,
            target,
            spatial_signature,
            process_state_graph,
            product_sensitivity_model
        )
        persist_evidence(candidate, physics)

    alternatives = search_competing_hypotheses(
        population,
        trajectories,
        good_pool,
        entity_types=[reticle, carrier, material, recipe_version,
                      apc_r2r_state, facility_source,
                      metrology_system, upstream_alternate_operation]
    )
    persist_evidence(alternatives)

    interventions = find_documented_or_inferred_interventions(
        leaders, event, replay_cutoff
    )
    persist_evidence(interventions)

    preliminary = assemble_dependency_aware_evidence_vectors()
    unexplained = identify_unexplained_affected_subsets(preliminary, population)

    if interaction_search_is_justified(preliminary, unexplained):
        interactions = generate_restricted_interactions(
            leaders,
            unexplained,
            physics_constraints=true,
            sequence_aware=true
        )
        for combo in interactions:
            combo_controls = build_candidate_specific_controls(combo, population, good_pool)
            combo_evidence = evaluate_interaction_incremental_value(combo, combo_controls)
            persist_evidence(combo, combo_evidence)
        apply_multiple_testing(family="restricted_interactions")

    if population_heterogeneity_is_material():
        subgroup_model = test_mixed_cause_hypothesis(
            features=[spatial_signature, time, route, severity, unexplained_pattern]
        )
        if subgroup_model.stable_and_supported:
            rerun_forensic_pipeline_per_subgroup(subgroup_model)

    evidence_vectors = assemble_dependency_aware_evidence_vectors()
    statuses = apply_fatal_causal_gates(evidence_vectors)
    results = assign_evidence_classes(evidence_vectors, statuses)
    results = apply_strong_and_soft_contradiction_logic(results)
    results = apply_data_quality_and_historical_coverage_gates(results)

    if no_adequate_candidate(results):
        return abstention_report(...)

    if mixed_cause_supported(results):
        return mixed_cause_forensic_report(...)

    return ranked_forensic_report(...)
```

## Required module boundaries
- `discovery`
- `historical_resolver`
- `canonical`
- `lineage`
- `target_definition`
- `causal_horizon`
- `control_eligibility`
- `candidate_specific_controls`
- `candidate_generation`
- `commonality`
- `severity_response`
- `alarm_forensics`
- `equipment_health`
- `fdc`
- `product_sensitivity`
- `metrology_spatial`
- `physics_state_graph`
- `intervention`
- `interaction_analysis`
- `mixed_cause`
- `evidence_dependency`
- `confidence`
- `validation`

## Query provenance
Every evidence object retains source/query/run identifiers sufficient for reproduction.
