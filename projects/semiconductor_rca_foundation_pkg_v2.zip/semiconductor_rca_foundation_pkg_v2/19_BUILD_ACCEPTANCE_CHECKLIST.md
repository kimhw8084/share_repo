# Foundation Build Acceptance Checklist V2

## Discovery / historical access
- [ ] Every source used causally has discovery report/registry entry.
- [ ] Row grain, event/effective/knowledge time semantics known.
- [ ] Join multiplication tested.
- [ ] Historical/current-state distinction explicit.
- [ ] Retention/archive path known or absence explicitly reported.
- [ ] Six-month-old representative event can resolve required trajectory or correctly abstain.

## Canonical lineage
- [ ] Ordered wafer trajectory reconstructs operations/rework/repeats.
- [ ] Tool/chamber/recipe coverage quantified.
- [ ] Lot/batch/carrier relationships preserved where relevant.
- [ ] Historical metadata effective-dated.

## Target / causal horizon
- [ ] Symptom and measurement opportunity defined.
- [ ] Last-known-good/first-known-bad interval represented.
- [ ] Fixed universal time lookback is not used as causal truth.
- [ ] Process-state propagation or full-route fallback implemented.

## Controls
- [ ] Eligible good pool requires observed normal outcome.
- [ ] Candidate-specific controls implemented.
- [ ] Candidate exposure excluded from matching features.
- [ ] Post-treatment variables excluded.
- [ ] Positivity/overlap reported.

## Commonality
- [ ] Set intersection is descriptive only.
- [ ] Bad-vs-good route-adjusted enrichment implemented.
- [ ] Routing-commonality flag implemented.
- [ ] Wafer/lot/batch support reported.
- [ ] Correlated observations handled.

## Severity
- [ ] Primary commonality is not defect-magnitude weighted.
- [ ] Separate normalized dose-response evidence implemented.
- [ ] Product/target severity scale explicit.

## Equipment / statistics
- [ ] Alarm episodes and exposure denominator explicit.
- [ ] Sparse count uncertainty handled.
- [ ] Self/peer/good-outcome baselines separate.
- [ ] SPC/change-detection methods appropriate to signal.
- [ ] Multiple-testing correction per hypothesis family.

## Product sensitivity
- [ ] Raw abnormality separated from product impact.
- [ ] Valid historical spec/control context used.
- [ ] Sparse products carry uncertainty/hierarchical pooling.

## FDC / evidence dependency
- [ ] Recipe-step context validated.
- [ ] Units/aliases/missingness checked.
- [ ] Alarm/SPC/FDC dependency groups tracked.
- [ ] Correlated evidence cannot create false multi-channel confidence.

## Metrology/spatial
- [ ] Measurement system itself can be candidate.
- [ ] Coordinates/orientation normalized.
- [ ] Product-specific expected spatial pattern/residual supported where data permits.

## Interactions / mixed causes
- [ ] Single candidates searched first.
- [ ] Interaction search is restricted/physics-informed.
- [ ] Interaction must add value beyond components.
- [ ] Mixed-cause subgroup analysis implemented or explicitly deferred.

## Evidence / contradictions
- [ ] FATAL/STRONG/SOFT taxonomy implemented.
- [ ] Fatal temporal/no-exposure contradictions cannot be overridden.
- [ ] Soft contradictions do not automatically force C0.
- [ ] Candidate status separate from C0-C5 confidence.
- [ ] Abstention and mixed-cause status supported.

## Validation
- [ ] Historical replay cutoff/knowledge-time enforced.
- [ ] Current metadata leakage prevented.
- [ ] Route-adjusted method compared to intersection baseline.
- [ ] Severity, interaction, product-sensitivity, contradiction, dependency ablations run.
- [ ] Challenge tests in `24_CHALLENGE_TESTS.md` executed.

## Deployment safety
- [ ] Decision-support only initially.
- [ ] No automatic tool action.
- [ ] No automatic recipe change.
- [ ] No automatic wafer disposition.
- [ ] No automatic RCA closure.
