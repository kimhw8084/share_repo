# Causal Traps and Failure Modes

## Confounding by route/product
Products are intentionally routed to different tools/recipes. Raw commonality can identify product mix instead of cause.

Mitigation: candidate-specific controls, route/product strata, within-stratum permutation, hierarchical adjustment.

## Conditioning on the cause
Matching controls on the suspect chamber/recipe removes the exposure difference.

Mitigation: pre-exposure matching only; leave tested exposure unconstrained.

## Conditioning on descendants
Matching on downstream FDC, rework, holds, or measurements influenced by the candidate can create bias.

Mitigation: process DAG/state graph; exclude post-treatment variables from control construction.

## APC / R2R feedback reversal
A controller correction can be a response to an earlier disturbance, so large correction magnitude may identify the controller's success rather than the initiating cause.

Mitigation: preserve causal order and distinguish disturbance, controller action, process result, downstream outcome.

## Measurement-selection bias
Extra inspection often targets suspicious material.

Mitigation: model outcome opportunity/sampling; unmeasured is UNKNOWN.

## Survivor bias
Wafers scrapped early never reach downstream measurement.

Mitigation: include scrap/disposition trajectory and avoid comparing only surviving measured wafers without eligibility modeling.

## Pseudo-replication
Many wafers share the same physical event/run/batch.

Mitigation: hierarchical/clustered statistical units.

## Multiple comparisons
Large candidate space guarantees accidental rare patterns.

Mitigation: staged search, FDR, shrinkage, replay calibration.

## Evidence double counting
Alarm, SPC, and FDC may encode one sensor excursion.

Mitigation: independence groups/dependency graph.

## Current-state backfill bias
Present tool/recipe metadata may differ from event-time configuration.

Mitigation: effective-dated history or explicit uncertainty.

## Mixed-cause masking
One event record may combine different defect signatures/causes.

Mitigation: residual/subgroup tests and multi-cause output.

## Severity-scale incompatibility
Raw deviation units differ by product/measurement.

Mitigation: target/product normalization; separate abnormality from materiality.

## Maintenance action confounding
Maintenance is triggered because engineers observed a problem, so maintenance-event proximity itself is not proof of cause.

Mitigation: distinguish pre-existing degradation from post-detection intervention; use recovery evidence carefully.

## Concept drift
Products, routes, recipes, chambers, control limits, and sensors evolve.

Mitigation: effective-dated context, rolling/hierarchical baselines, replay by era, monitoring of model calibration drift.
