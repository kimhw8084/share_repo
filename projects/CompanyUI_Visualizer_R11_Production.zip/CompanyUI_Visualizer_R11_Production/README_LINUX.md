# Company UI 3.0.0a1 + Visualizer 97.1 — R11 authoring production final

R11 supersedes R1-R10. Do not reuse an older revision's `.venv` or extracted directory.

This package contains the Company UI v3 host plus Visualizer 97.1 at `/visualizer`, preserving the frozen 248-element / 17-engine Visualizer authority. R10 specifically closes the blank-editor failure where report controls rendered but the retained editor collapsed to effectively zero height.

## Production runtime

- Python `>=3.11,<3.14`
- NiceGUI exactly `3.15.0`
- `python-pptx==1.0.2`
- one process / one port
- local browser assets / no CDN
- no runtime Node dependency
- package-root `requirements.txt` is the production dependency authority
- package-root `app.py` is the single PaaS entrypoint

## Clean work-PC install

Extract R11 into a new directory and run:

```bash
chmod +x *.sh
./setup_linux.sh
```

`setup_linux.sh` is fail-closed. Before it prints Setup complete, it verifies SHA-256 integrity, installs root requirements, installs/cross-checks the supplied wheel, runs `pip check`, validates NiceGUI 3.15 APIs, verifies frozen Visualizer authority, checks the recursive browser asset graph, starts canonical `app.py` and the installed wheel launcher on temporary ports, requires `/visualizer` HTTP 200, validates every static dependency over HTTP, rejects server tracebacks/500s, and—when Chrome/Chromium/Edge is present—requires the retained editor mount to be `mounted`, the editor geometry marker to be `pass`, the library to reach 248/248, and the retained-editor QA state to pass.

Then run:

```bash
./run_visualizer.sh
```

Open:

```text
http://127.0.0.1:8080/visualizer
```

For the complete target certification estate:

```bash
./test_linux.sh
```

That additionally runs the full source regression/governance estate, delayed-mount/rehydration Chromium gate, full browser behavior matrix, Company UI runtime certification, frozen Visualizer authority suite from a temporary copy, and live NiceGUI desktop/tablet/phone certification. Evidence is written to `evidence_local/`.

## Company NiceGUI PaaS publish

Select exactly:

```text
Main Python file: app.py
Requirements file: requirements.txt
```

The platform launch contract is:

```bash
python app.py
```

Recommended production variables:

```bash
export COMPANY_UI_ENVIRONMENT=prod
export COMPANY_UI_STORAGE_SECRET='set-this-in-the-platform-secret-store'
export COMPANY_UI_VISUALIZER_DATA_DIR=/approved/persistent/company-ui/visualizer/reports
```

Production mode fails closed without `COMPANY_UI_STORAGE_SECRET`. Common hosting `HOST` and `PORT` environment variables are supported.

## Blank-editor regression protection

R10 does not pass the retained editor fragment through `ui.html(fragment)`. NiceGUI owns a mount element, and a page-local installer projects the trusted retained fragment directly into it and rehydrates it if framework reconciliation replaces the mount. The editor publishes measured geometry readiness. A root under 600 px high, canvas under 240 px high, missing toolbar, unmounted host, or missing 248/248 readiness fails browser startup certification.

The R10 delayed-mount gate measures **1440x844 px** for the retained editor and **718 px** for the canvas both before and after simulated mount replacement.

## Browser/network expectations

`304 Not Modified` for NiceGUI's own Socket.IO/framework/font/CSS assets is normal successful cache validation.

Visualizer `.mjs`/JSON dependencies must never return 404. These paths are recursively certified:

```text
/_cui_visualizer/assets/integrated_editor.mjs
/_cui_visualizer/vendor/production_core/core/editor_store.mjs
/_cui_visualizer/vendor/production_core/core/runtime_registry.mjs
/_cui_visualizer/vendor/production_core/core/universal_renderer.mjs
/_cui_visualizer/vendor/production_core/contracts/component_contracts.json
```

## Certified behavior

- new/legacy untitled title displays `Untitled report`;
- all nine quick-add controls mutate the report;
- Undo / Redo;
- Smart / Guided / Free modes;
- Group / Ungroup / Lock / layer ordering;
- Auto Layout;
- Command Palette;
- Preflight;
- Preview enter/exit;
- Inspector close/reopen with reclaimed workspace width;
- balanced canvas margins with inspector open/closed/reopened;
- Zoom / Fit / Mini-map;
- library search, all 17 engine filters, Show More;
- Save and PowerPoint semantic requests;
- retained-editor rebind after host replacement;
- pointer movement remains browser-local;
- tablet and phone shell/work areas remain contained;
- zero Chromium console/page errors in the final behavior and mount matrices.

## PowerPoint

Upload the user's existing `.pptx` through **Import / PowerPoint template**, then export from the Visualizer toolbar. The integration validates the PPTX archive, selects the governed target region, preserves surrounding template content, emits editable/native PowerPoint objects where practical, preserves numeric zero vs missing data, never invents sequence-only timeline dates, and never rasterizes the whole report as a shortcut.

## Persistence

Default local report storage:

```text
~/.company_ui/visualizer/reports
```

Override with `COMPANY_UI_VISUALIZER_DATA_DIR` or `--data-dir`. Writes are deterministic and atomic; server-bound report mutations are revision-aware; drag/resize/hover/pointer/virtual-scroll frame traffic remains browser-side.

## Final source/package certification

- **712/712 tests passing**
- governance **0 errors / 0 warnings**
- Company UI visual coverage **183/183**
- Visualizer **248/248 elements**
- Visualizer **17/17 engines**
- frozen vendor **123/123 files** verified
- Visualizer frozen authority evidence **27/27 gates** (authority bytes unchanged)
- Golden Connector v5 SHA-256 `d8ebd4378f01b7c52a7a4be57c578c22adf29b899cc08a370cf084881195343e`
- recursive Visualizer browser dependency graph complete
- delayed mount/rehydration Chromium gate PASS
- final Chromium editor behavior matrix PASS
- audited source ↔ shipped wheel byte parity PASS

See `PRODUCTION_SIGNOFF.md`, `R11_AUTHORING_CERTIFICATION.md`, `R10_EDITOR_MOUNT_CERTIFICATION.md`, `PUBLISH_NICEGUI.md`, and `evidence/CERTIFICATION_SUMMARY.json`.

## R11 authoring scope

R11 adds report/template lifecycle management, revision-aware delete/cleanup, built-in and personal preset CRUD, Smart/Guided/Free geometry semantics, semantic inspectors for all 17 engines, spreadsheet/image clipboard workflows, and 248/248 differentiated element structures. `test_linux.sh` now runs both the legacy interaction matrix and `tools/r11_authoring_matrix.py`.
