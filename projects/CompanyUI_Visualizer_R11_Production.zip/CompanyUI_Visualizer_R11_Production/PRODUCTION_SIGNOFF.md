# R11 production signoff

R11 supersedes R1-R10 for deployment. It preserves the R10 retained-editor/runtime fixes and adds production report-authoring workflows, semantic component editors, real geometry modes, preset/report lifecycle management, image/data paste, and 248/248 differentiated element rendering.

## Signed-off evidence

- 712/712 inherited + integration tests PASS.
- Company UI governance: 0 errors / 0 warnings.
- Visualizer 97.1 frozen authority: 27/27 production gates PASS.
- 248/248 elements, 17/17 engines, 123 frozen vendor files unchanged.
- R11 authoring Chromium matrix: 54/54 PASS with zero console/page errors.
- Legacy interaction/responsive matrix: PASS with zero console/page errors.
- Delayed mount/rehydration: 1440x844 editor, 718 px canvas, 248/248 library before and after host replacement.
- Recursive browser asset graph: PASS, zero missing module/contract targets.
- Wheel/source byte parity: PASS.
- Golden Connector v5 unchanged: `d8ebd4378f01b7c52a7a4be57c578c22adf29b899cc08a370cf084881195343e`.

The canonical company PaaS entrypoint is `app.py`; dependencies are installed from the package-root `requirements.txt`. See `R11_AUTHORING_CERTIFICATION.md`, `PUBLISH_NICEGUI.md`, and `README_LINUX.md`.
