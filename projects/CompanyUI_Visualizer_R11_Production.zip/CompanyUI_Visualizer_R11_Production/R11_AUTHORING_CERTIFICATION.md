# R11 Authoring Production Certification

R11 is the production authoring upgrade on top of the R10 retained-editor/runtime integration. The frozen Visualizer 97.1 authority remains unchanged.

## Product changes certified

- Separate page identity, report title, and open-report selector.
- New-report chooser with blank canvas and governed starting templates.
- Revision-aware rename/delete plus user-confirmed cleanup of other empty Untitled reports.
- Smart geometry with 14 px outer safe frame and peer spacing.
- Guided geometry with 14 px grid, outer-margin, peer-edge/center/equal-gap snapping, resize snapping, and overlap prevention.
- Free geometry with unsnapped manual placement while retaining canvas safety/minimum sizes.
- Built-in presets plus personal preset save/load/rename/update/delete synchronized through the Company UI preference bridge.
- Canonical quick-add elements: no separate demo component system.
- Semantic inspectors for all 17 Visualizer engines.
- Spreadsheet-style paste for charts/tables/matrices/engineering/Wafer-Fab while preserving missing values distinct from numeric zero.
- Sequence-only timelines preserve null dates.
- Ctrl/Cmd+V image paste plus image file/alt/caption/focal editing.
- Element-specific integration rendering: 248/248 element identities have distinct structural signatures.
- Contextual selection toolbar is physically readable after scene zoom compensation.

## Release gates

- Company UI inherited pytest estate: 712/712 PASS.
- Company UI governance: 0 errors / 0 warnings.
- R11 authoring Chromium matrix: 54/54 PASS; zero console errors; zero page errors.
- Legacy interaction/responsive Chromium matrix: PASS; zero console/page errors.
- Delayed NiceGUI/Vue mount + rehydration smoke: 1440x844 editor, 718 px canvas before and after replacement, 248/248 library, zero browser errors.
- Recursive Visualizer browser module graph: PASS, no missing targets.
- Frozen Visualizer 97.1 production suite: 27/27 PASS on a temporary copy.
- Frozen vendor identity: 123/123 files unchanged.
- Golden Connector Engine v5 SHA-256: `d8ebd4378f01b7c52a7a4be57c578c22adf29b899cc08a370cf084881195343e`.
- Installable wheel/source byte parity: PASS.

## Target-runtime note

This build environment does not have NiceGUI installed and cannot reach the package index. Therefore the package retains fail-closed target checks in `setup_linux.sh`/`test_linux.sh`: exact NiceGUI 3.15.0 API verification, real `python app.py` HTTP startup, installed-wheel startup, browser startup, module graph, mount geometry, both browser behavior matrices, runtime smoke, full regression/governance, and frozen-authority suite.
