#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil
from pathlib import Path


def find_browser():
    configured=os.getenv('COMPANY_UI_BROWSER')
    candidates=([configured] if configured else [])+['/usr/bin/chromium','/usr/bin/google-chrome','/usr/bin/google-chrome-stable','/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge']
    for p in candidates:
        if p and Path(p).is_file() and os.access(p,os.X_OK): return p
    for name in ('chromium','chromium-browser','google-chrome','google-chrome-stable','microsoft-edge'):
        q=shutil.which(name)
        if q:return q
    return None


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',type=Path,default=Path('evidence/r11_authoring_matrix.json')); ap.add_argument('--browser'); args=ap.parse_args()
    root=Path(__file__).resolve().parents[1]; product=root/'source/company_ui/products/visualizer'; assets=product/'assets'; core=product/'vendor/production_core/core'
    html=(assets/'integrated_editor.html').read_text(); css=(assets/'integrated_editor.css').read_text(); store=(core/'editor_store.mjs').read_text(); registry=(core/'runtime_registry.mjs').read_text(); renderer=(assets/'element_renderer.mjs').read_text(); editor=(assets/'integrated_editor.mjs').read_text(); contracts=(product/'vendor/production_core/contracts/component_contracts.json').read_text()
    from playwright.sync_api import sync_playwright
    result={'pass':False,'checks':{},'console_errors':[],'page_errors':[]}; args.output.parent.mkdir(parents=True,exist_ok=True)
    def check(name,ok,detail=None):
        result['checks'][name]={'pass':bool(ok),'detail':detail}; print(f'[CHECK] {name}: {"PASS" if ok else "FAIL"}',flush=True)
        if not ok: raise AssertionError(f'{name}: {detail!r}')
    blank={'schema_version':1,'items':[],'groups':{},'mode':'guided','layoutPreset':'editorial','crossFilter':None,'nextId':1}
    with sync_playwright() as p:
        browser_path=args.browser or find_browser();
        if not browser_path: print('FAIL: browser not found'); return 2
        browser=p.chromium.launch(executable_path=browser_path,headless=True,args=['--disable-dev-shm-usage'])
        page=browser.new_page(viewport={'width':1440,'height':1000}); page.set_default_timeout(3000)
        page.on('console',lambda m: result['console_errors'].append(m.text) if m.type=='error' else None); page.on('pageerror',lambda e: result['page_errors'].append(str(e)))
        boot=json.dumps({'report_id':'r11-authoring','revision':1,'model':blank})
        bootstrap=f'''<script>window.__CUI_VISUALIZER_BOOTSTRAP__={boot};window.__CUI_VISUALIZER_ASSET_BUILD__='r11-authoring';window.__EVENTS=[];document.addEventListener('visualizer_bridge',e=>{{let m=e.detail;try{{m=typeof m==='string'?JSON.parse(m):m}}catch(_){{}}window.__EVENTS.push(m); if(m?.type==='preset.preferences_save_requested') setTimeout(()=>window.CompanyUIVisualizerBridge?.receive({{bridge_version:1,type:'preset.preferences_result',payload:{{presets:m.payload.presets}}}}),0);}});</script>'''
        page.set_content(f'<!doctype html><html><head><meta charset="utf-8"><style>{css}</style>{bootstrap}</head><body style="margin:0;height:100vh">{html}</body></html>',wait_until='domcontentloaded')
        page.evaluate("""async ({registry,store,renderer,editor,contracts})=>{const blob=s=>URL.createObjectURL(new Blob([s],{type:'text/javascript'}));const reg=blob(registry), st=blob(store), ren=blob(renderer), con=URL.createObjectURL(new Blob([contracts],{type:'application/json'}));window.__R11_RENDERER_URL__=ren;let patched=editor.replace("'../vendor/production_core/core/editor_store.mjs'",JSON.stringify(st)).replace("'../vendor/production_core/core/runtime_registry.mjs'",JSON.stringify(reg)).replace("'./element_renderer.mjs'",JSON.stringify(ren)).replace("new URL('../vendor/production_core/contracts/component_contracts.json', import.meta.url)",JSON.stringify(con));await import(blob(patched));}""",{'registry':registry,'store':store,'renderer':renderer,'editor':editor,'contracts':contracts})
        page.wait_for_function("()=>document.querySelector('.cui-visualizer-root')?.dataset.editorReady==='true'&&window.CompanyUIVisualizerBridge")
        page.evaluate("()=>window.CompanyUIVisualizerBridge.receive({bridge_version:1,type:'preset.preferences_result',payload:{presets:[]}})")
        state=lambda:page.evaluate('()=>window.CompanyUIVisualizerBridge.state()'); model=lambda:state()['model']
        check('ready.blank',state()['editor_ready'] and len(model()['items'])==0,state())
        # 248 identities + renderer structural uniqueness
        uniqueness=page.evaluate("""async()=>{const mod=await import(window.__R11_RENDERER_URL__);const buttons=[...document.querySelectorAll('#fullLibrary [data-element]')];return {visible:buttons.length};}""")
        page.locator('#componentSearch').fill(''); page.locator('#engineFilter').select_option('');
        # get catalog from options by repeatedly Show more
        for _ in range(32):
            more=page.locator('#libraryMore')
            if more.is_hidden(): break
            more.evaluate('(el)=>el.click()')
            page.wait_for_timeout(5)
        else:
            raise AssertionError('library Show more did not converge')
        catalog=page.locator('#fullLibrary [data-element]').evaluate_all("els=>els.map(e=>({element:e.dataset.element,engine:e.dataset.engine}))")
        sigs=page.evaluate("""async catalog=>{const mod=await import(window.__R11_RENDERER_URL__);return catalog.map(x=>mod.structuralSignature({element:x.element,engine:x.engine,title:x.element}));}""",catalog)
        check('catalog.248',len(catalog)==248,len(catalog)); check('renderer.248_unique_structures',len(set(sigs))==248,{'unique':len(set(sigs)),'total':len(sigs)})
        engines=sorted(set(x['engine'] for x in catalog)); check('catalog.17_engines',len(engines)==17,engines)
        page.locator('[data-mode="smart"]').click(); page.wait_for_timeout(15)
        reps=[('Smart Canvas','SmartLayoutEngine','#iLayoutConfig'),('Hero Title','TextEngine','#iText'),('Hero KPI','MetricEngine','#iValue'),('Before/After KPI','ComparisonEngine','#iBefore'),('Line Chart','CoreChartEngine','#iData'),('Clean Table','TableEngine','#iData'),('Decision Matrix','MatrixEngine','#iMatrix'),('Event Timeline','TimelineEngine','#iTimeline'),('Process Flow','DiagramEngine','#iNodes'),('Image','ImageMediaEngine','#iImageFile'),('Evidence Card','EvidenceCompositeEngine','#iStatement'),('Decision Needed','DecisionCompositeEngine','#iStatement'),('Project Card','ProjectCompositeEngine','#iStatement'),('SPC Control Chart','EngineeringChartEngine','#iObservations'),('Wafer Map','WaferFabEngine','#iTool'),('Cross-filter','InteractionLayer','#iBehavior'),('Right Inspector','EditorInfrastructure','#iConfiguration')]
        ids={}
        for element,engine,selector in reps:
            page.locator('#componentSearch').fill(element); page.wait_for_timeout(10); btn=page.locator(f'#fullLibrary [data-element="{element}"]'); check(f'library.rep.{engine}',btn.count()==1,element); btn.click(); page.wait_for_timeout(15)
            item=model()['items'][-1]; ids[engine]=item['id']; check(f'inspector.{engine}',item.get('engine')==engine and page.locator(selector).count()==1,{'item':item.get('engine'),'selector':selector})
        check('representatives.17',len(ids)==17,len(ids))
        # typed data: 0 != missing
        page.locator(f'.component[data-id="{ids["CoreChartEngine"]}"]').click(); page.locator('#iData').fill('A\t0\nB\t\nC\t12'); page.locator('#iData').dispatch_event('change'); page.wait_for_timeout(15)
        chart=next(x for x in model()['items'] if x['id']==ids['CoreChartEngine']); vals=[x['value'] for x in chart['rows']]; check('typed.zero_vs_missing',vals==[0,None,12],vals)
        # sequence timeline never invents dates
        page.locator(f'.component[data-id="{ids["TimelineEngine"]}"]').click(); page.locator('#iTimeline').fill('Collect|\nAnalyze|2026-08-28\nDecide|'); page.locator('#iTimeline').dispatch_event('change'); page.wait_for_timeout(10)
        timeline=next(x for x in model()['items'] if x['id']==ids['TimelineEngine']); check('timeline.blank_dates_preserved',[x['date'] for x in timeline['milestones']]==[None,'2026-08-28',None],timeline['milestones'])
        # image clipboard paste
        page.locator(f'.component[data-id="{ids["ImageMediaEngine"]}"]').click(); page.evaluate("""()=>{const dt=new DataTransfer();dt.items.add(new File([new Uint8Array([137,80,78,71,13,10,26,10])],'paste.png',{type:'image/png'}));window.dispatchEvent(new ClipboardEvent('paste',{bubbles:true,clipboardData:dt}));}"""); page.wait_for_timeout(80)
        image=next(x for x in model()['items'] if x['id']==ids['ImageMediaEngine']); check('image.clipboard_paste',str(image.get('src','')).startswith('data:image/png;base64,'),str(image.get('src',''))[:40])
        # presets: built in + server-synced CRUD
        check('presets.builtin',page.locator('#builtinPresetList [data-built-preset]').count()==3,page.locator('#builtinPresetList').inner_text())
        page.locator('#presetName').fill('My Production Preset'); page.locator('#presetSave').click(); page.wait_for_timeout(30); check('presets.save',page.locator('#presetList [data-loadpreset]').count()==1,page.locator('#presetList').inner_text())
        page.locator('#presetList [data-preset-rename="0"]').fill('Renamed Preset'); page.locator('#presetList [data-preset-rename="0"]').dispatch_event('change'); page.wait_for_timeout(20); check('presets.rename',page.locator('#presetList [data-preset-rename="0"]').input_value()=='Renamed Preset',page.locator('#presetList [data-preset-rename="0"]').input_value())
        page.locator('#presetList [data-updatepreset="0"]').click(); page.wait_for_timeout(20); check('presets.update',any(e.get('type')=='preset.preferences_save_requested' for e in page.evaluate('()=>window.__EVENTS')),None)
        page.locator('#presetList [data-deletepreset="0"]').click(); page.wait_for_timeout(20); check('presets.delete',page.locator('#presetList [data-loadpreset]').count()==0,page.locator('#presetList').inner_text())
        page.locator('#builtinPresetList [data-built-preset="executive"]').click(); page.wait_for_timeout(15); check('presets.builtin_apply',model()['layoutPreset']=='executive',model()['layoutPreset'])
        # Smart safe frame: every component inside 14px and at least one touches each safe boundary.
        page.locator('[data-mode="smart"]').click(); page.wait_for_timeout(20)
        rects=page.locator('.component').evaluate_all("els=>els.map(e=>({x:parseFloat(e.style.left),y:parseFloat(e.style.top),w:parseFloat(e.style.width),h:parseFloat(e.style.height)}))")
        check('smart.safe_frame',min(r['x'] for r in rects)>=13.9 and min(r['y'] for r in rects)>=13.9 and max(r['x']+r['w'] for r in rects)<=1186.1 and max(r['y']+r['h'] for r in rects)<=661.1,rects[:3])
        # Guided exact outer margin snap using real pointer events.
        page.locator('[data-mode="guided"]').click(); page.wait_for_timeout(20); first=page.locator('.component').nth(0); first.click(); item0=next(x for x in model()['items'] if x['id']==first.get_attribute('data-id')); head=first.locator('.c-head').bounding_box(); dx=(14-item0['x'])*state()['model'].get('_unused',1)
        zoom=page.evaluate('()=>window.__VIZ_PROD__.ui.zoom'); page.mouse.move(head['x']+head['width']/2,head['y']+head['height']/2); page.mouse.down(); page.mouse.move(head['x']+head['width']/2+(14-item0['x'])*zoom,head['y']+head['height']/2+(14-item0['y'])*zoom,steps=4); page.mouse.up(); page.wait_for_timeout(25)
        moved=next(x for x in model()['items'] if x['id']==item0['id']); check('guided.outer_margin_snap',abs(moved['x']-14)<.15 and abs(moved['y']-14)<.15,moved)
        # Free mode preserves unsnapped manual delta.
        page.locator('[data-mode="free"]').click(); page.wait_for_timeout(10); first=page.locator(f'.component[data-id="{item0["id"]}"]'); head=first.locator('.c-head').bounding_box(); before=next(x for x in model()['items'] if x['id']==item0['id']); page.mouse.move(head['x']+head['width']/2,head['y']+head['height']/2);page.mouse.down();page.mouse.move(head['x']+head['width']/2+5*zoom,head['y']+head['height']/2+3*zoom,steps=3);page.mouse.up();page.wait_for_timeout(15);after=next(x for x in model()['items'] if x['id']==item0['id']);check('free.no_snap',abs((after['x']-before['x'])-5)<1 and abs((after['y']-before['y'])-3)<1,{'before':before,'after':after})
        # toolbar legibility at current zoom
        first.click(); page.wait_for_timeout(10); toolbar=page.locator('#context'); metric=toolbar.evaluate("e=>{const buttons=[...e.querySelectorAll('button')];const cs=getComputedStyle(e);return {font:parseFloat(cs.fontSize),zoom:window.__VIZ_PROD__?.ui?.zoom,inlineTransform:document.querySelector('#scene').style.transform,interactionScene:getComputedStyle(document.querySelector('#scene')).getPropertyValue('--viz-interaction-scale'),sceneTransform:getComputedStyle(document.querySelector('#scene')).transform,buttons:buttons.map(b=>({t:b.innerText,rect:{w:b.getBoundingClientRect().width,h:b.getBoundingClientRect().height},css:{minW:getComputedStyle(b).minWidth,minH:getComputedStyle(b).minHeight,font:getComputedStyle(b).fontSize,pad:getComputedStyle(b).padding}})),minRenderedH:buttons.length?Math.min(...buttons.map(b=>b.getBoundingClientRect().height)):0,minRenderedW:buttons.length?Math.min(...buttons.map(b=>b.getBoundingClientRect().width)):0,text:e.innerText}}")
        check('selection_toolbar.readable',metric['font']>=12 and metric['minRenderedH']>=28 and metric['minRenderedW']>=40,metric)
        check('final.no_console_errors',not result['console_errors'],result['console_errors']); check('final.no_page_errors',not result['page_errors'],result['page_errors'])
        result['pass']=all(x['pass'] for x in result['checks'].values()); browser.close()
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)); print(json.dumps({'pass':result['pass'],'checks':len(result['checks']),'console_errors':result['console_errors'],'page_errors':result['page_errors']},indent=2)); return 0 if result['pass'] else 1

if __name__=='__main__': raise SystemExit(main())
