#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import shutil
from pathlib import Path


def find_browser() -> str | None:
    configured = os.getenv('COMPANY_UI_BROWSER')
    candidates = ([configured] if configured else []) + [
        '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
        '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
        '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser',
        '/usr/bin/microsoft-edge', '/usr/bin/microsoft-edge-stable',
    ]
    for candidate in candidates:
        if candidate and Path(candidate).is_file() and os.access(candidate, os.X_OK):
            return candidate
    for name in ('google-chrome','google-chrome-stable','chromium','chromium-browser','microsoft-edge','microsoft-edge-stable','msedge'):
        found = shutil.which(name)
        if found:
            return found
    return None


def main() -> int:
    ap = argparse.ArgumentParser(description='Browser-side retained Visualizer behavior matrix without a live server.')
    ap.add_argument('--output', type=Path, default=Path('evidence_local/editor_behavior_matrix.json'))
    ap.add_argument('--browser', default=None)
    args = ap.parse_args()

    root = Path(__file__).resolve().parents[1]
    product = root / 'source' / 'company_ui' / 'products' / 'visualizer'
    assets = product / 'assets'
    core = product / 'vendor' / 'production_core' / 'core'
    html = (assets / 'integrated_editor.html').read_text(encoding='utf-8')
    css = (assets / 'integrated_editor.css').read_text(encoding='utf-8')
    store_js = (core / 'editor_store.mjs').read_text(encoding='utf-8')
    registry_js = (core / 'runtime_registry.mjs').read_text(encoding='utf-8')
    renderer_js = (assets / 'element_renderer.mjs').read_text(encoding='utf-8')
    editor_js = (assets / 'integrated_editor.mjs').read_text(encoding='utf-8')
    contracts_json = (product / 'vendor' / 'production_core' / 'contracts' / 'component_contracts.json').read_text(encoding='utf-8')

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print('FAIL: playwright is required for editor_behavior_matrix.py')
        return 2

    result: dict = {'pass': False, 'checks': {}, 'console_errors': [], 'page_errors': []}
    args.output.parent.mkdir(parents=True, exist_ok=True)

    def check(name: str, condition: bool, detail=None):
        result['checks'][name] = {'pass': bool(condition), 'detail': detail}
        print(f'[CHECK] {name}: {"PASS" if condition else "FAIL"}', flush=True)
        if not condition:
            raise AssertionError(f'{name}: {detail!r}')

    with sync_playwright() as p:
        resolved_browser = args.browser or find_browser()
        if not resolved_browser:
            print('FAIL: Chrome/Chromium/Edge executable not found. Set COMPANY_UI_BROWSER=/absolute/path.')
            return 2
        launch_kwargs = {'headless': True, 'args': ['--disable-dev-shm-usage'], 'executable_path': resolved_browser}
        browser = p.chromium.launch(**launch_kwargs)
        page = browser.new_page(viewport={'width': 1440, 'height': 1000})
        page.set_default_timeout(2000)
        page.on('console', lambda msg: result['console_errors'].append(msg.text) if msg.type == 'error' else None)
        page.on('pageerror', lambda exc: result['page_errors'].append(str(exc)))
        page.add_init_script("""
          window.__CUI_VISUALIZER_BOOTSTRAP__={report_id:'behavior-matrix',revision:1};
          window.__CUI_VISUALIZER_ASSET_BUILD__='behavior-matrix';
          window.__EVENTS=[];
          document.addEventListener('visualizer_bridge',e=>{
            let payload=e.detail;
            try{ payload=typeof payload==='string'?JSON.parse(payload):payload; }catch(_e){}
            window.__EVENTS.push(payload);
          });
          window.prompt=()=> 'Behavior Preset';
        """)
        bootstrap_script = """<script>
          window.__CUI_VISUALIZER_BOOTSTRAP__={report_id:'behavior-matrix',revision:1};
          window.__CUI_VISUALIZER_ASSET_BUILD__='behavior-matrix';
          window.__EVENTS=[];
          document.addEventListener('visualizer_bridge',e=>{
            let payload=e.detail;
            try{ payload=typeof payload==='string'?JSON.parse(payload):payload; }catch(_e){}
            window.__EVENTS.push(payload);
          });
          window.prompt=()=> 'Behavior Preset';
        </script>"""
        page.set_content(f'<!doctype html><html><head><meta charset="utf-8"><style>{css}</style>{bootstrap_script}</head><body style="margin:0;height:100vh">{html}</body></html>', wait_until='domcontentloaded')

        # Load the real ES modules in-memory while preserving their module boundaries.
        page.evaluate("""async ({registry,store,renderer,editor,contracts}) => {
          const blob = (source) => URL.createObjectURL(new Blob([source], {type:'text/javascript'}));
          const registryUrl=blob(registry);
          const storeUrl=blob(store);
          const rendererUrl=blob(renderer);
          const contractsUrl=URL.createObjectURL(new Blob([contracts], {type:'application/json'}));
          let patched=editor
            .replace("'../vendor/production_core/core/editor_store.mjs'", JSON.stringify(storeUrl))
            .replace("'../vendor/production_core/core/runtime_registry.mjs'", JSON.stringify(registryUrl))
            .replace("'./element_renderer.mjs'", JSON.stringify(rendererUrl))
            .replace("new URL('../vendor/production_core/contracts/component_contracts.json', import.meta.url)", JSON.stringify(contractsUrl));
          await import(blob(patched));
        }""", {'registry': registry_js, 'store': store_js, 'renderer': renderer_js, 'editor': editor_js, 'contracts': contracts_json})
        page.wait_for_function("() => document.querySelector('.cui-visualizer-root')?.dataset.editorReady==='true' && window.CompanyUIVisualizerBridge")

        state = lambda: page.evaluate('() => window.CompanyUIVisualizerBridge.state()')
        model = lambda: state()['model']
        count = lambda: len(model()['items'])

        check('editor.ready', state()['editor_ready'] is True, state())
        check('library.248', '248' in page.locator('#libraryCount').inner_text(), page.locator('#libraryCount').inner_text())
        check('initial.no_errors', not result['console_errors'] and not result['page_errors'], {'console': result['console_errors'], 'page': result['page_errors']})

        # Every visible top-level editor control must have a browser-side behavior handler.
        handler_ids = ['undo','redo','auto','group','ungroup','lock','back','front','commandBtn','serverSaveBtn','pptBtn','preflightBtn','previewBtn','exportBtn','presetSave','inspectorToggle','inspectorClose','zoomOut','zoomIn','zoomFit','miniToggle','libraryMore']
        missing = page.evaluate("""ids => ids.filter(id => { const n=document.getElementById(id); return !n || (!n.onclick && ![...n._eventListeners||[]].length); })""", handler_ids)
        # addEventListener-managed controls don't expose _eventListeners; test them separately by behavior below.
        direct_expected = [i for i in handler_ids if i not in ('libraryMore',)]
        missing_direct = page.evaluate("ids => ids.filter(id => !document.getElementById(id)?.onclick)", direct_expected)
        check('controls.direct_handlers', not missing_direct, missing_direct)

        # Quick palette actions: each visible type must mutate the canonical model.
        initial_count = count()
        palette = page.locator('.pal')
        palette_types = palette.evaluate_all("els => els.map(e => e.dataset.type)")
        for idx, component_type in enumerate(palette_types):
            before = count(); palette.nth(idx).click(); page.wait_for_timeout(20)
            check(f'palette.{component_type}', count() == before + 1, {'before': before, 'after': count()})
        check('palette.all_types', count() == initial_count + len(palette_types), palette_types)

        # Undo/redo actually changes model history, including on non-secure origins where Web Crypto UUID APIs are unavailable.
        before_undo = count(); page.locator('#undo').click(timeout=1500); page.wait_for_timeout(20)
        check('history.undo', count() == before_undo - 1, {'before': before_undo, 'after': count()})
        redo_meta = page.evaluate("() => ({disabled:document.querySelector('#redo').disabled, canRedo:window.__VIZ_PROD__.store.canRedo})")
        check('history.redo_enabled', not redo_meta['disabled'] and redo_meta['canRedo'], redo_meta)
        page.locator('#redo').click(timeout=1500); page.wait_for_timeout(20)
        check('history.redo', count() == before_undo, {'after': count()})

        # Mode switches.
        for mode in ('guided','free','smart'):
            page.locator(f'[data-mode="{mode}"]').click(); page.wait_for_timeout(20)
            check(f'mode.{mode}', model()['mode'] == mode, model()['mode'])

        # Selection + group/ungroup/lock/layer actions.
        comps = page.locator('.component')
        check('canvas.components_rendered', comps.count() >= 2, comps.count())
        comps.nth(0).click(); comps.nth(1).click(modifiers=['Shift']); page.wait_for_timeout(20)
        page.locator('#group').click(); page.wait_for_timeout(20)
        check('selection.group', len(model()['groups']) >= 1, model()['groups'])
        page.locator('#ungroup').click(); page.wait_for_timeout(20)
        check('selection.ungroup', len(model()['groups']) == 0, model()['groups'])
        # reset to one selection and lock/unlock
        comps = page.locator('.component'); comps.nth(0).click(); selected_id = comps.nth(0).get_attribute('data-id')
        page.locator('#lock').click(); page.wait_for_timeout(20)
        entry = next(x for x in model()['items'] if x['id'] == selected_id)
        check('selection.lock', entry.get('locked') is True, entry)
        page.locator('#lock').click(); page.wait_for_timeout(20)
        entry = next(x for x in model()['items'] if x['id'] == selected_id)
        check('selection.unlock', entry.get('locked') is False, entry)
        z0 = entry.get('z', 0); page.locator('#front').click(); page.wait_for_timeout(20)
        z1 = next(x for x in model()['items'] if x['id'] == selected_id).get('z', 0)
        check('selection.bring_front', z1 >= z0, {'before': z0, 'after': z1})
        page.locator('#back').click(); page.wait_for_timeout(20)
        z2 = next(x for x in model()['items'] if x['id'] == selected_id).get('z', 0)
        check('selection.send_back', z2 <= z1, {'before': z1, 'after': z2})

        # Auto-layout produces a semantic revision and remains smart.
        rev0 = state()['revision']; page.locator('#auto').click(); page.wait_for_timeout(20)
        check('layout.auto_revision', state()['revision'] > rev0, {'before': rev0, 'after': state()['revision']})
        check('layout.auto_smart', model()['mode'] == 'smart', model()['mode'])

        # Command palette: opens, filters and executes a command.
        before = count(); page.locator('#commandBtn').click();
        check('commands.opens', page.locator('#cmdModal').evaluate("e=>e.classList.contains('show')"), None)
        page.locator('#cmdInput').fill('Add KPI'); page.locator('#cmdInput').press('Enter'); page.wait_for_timeout(20)
        check('commands.executes', count() == before + 1, {'before': before, 'after': count()})

        # Preflight modal.
        page.locator('#preflightBtn').click();
        check('preflight.opens', page.locator('#genericModal').evaluate("e=>e.classList.contains('show')"), None)
        check('preflight.content', bool(page.locator('#modalBody').inner_text().strip()), page.locator('#modalBody').inner_text()[:200])
        page.locator('#genericModal [data-close]').click()

        # Preview enter/exit.
        page.locator('#previewBtn').click(); page.wait_for_timeout(20)
        check('preview.enter', page.evaluate("() => document.querySelector('.cui-visualizer-root').classList.contains('preview-mode')"), None)
        page.locator('#previewExit').click(); page.wait_for_timeout(20)
        check('preview.exit', not page.evaluate("() => document.querySelector('.cui-visualizer-root').classList.contains('preview-mode')"), None)

        # Inspector collapse and expansion must change center geometry and keep balanced canvas gutters.
        def geometry():
            return page.evaluate("""() => {
              const root=document.querySelector('.cui-visualizer-root').getBoundingClientRect();
              const vp=document.querySelector('#viewport').getBoundingClientRect();
              const frame=document.querySelector('#sceneFrame').getBoundingClientRect();
              const pane=document.querySelector('#inspectorPane').getBoundingClientRect();
              const shell=document.querySelector('.shell').getBoundingClientRect();
              const work=document.querySelector('.work').getBoundingClientRect();
              const left=document.querySelector('.left').getBoundingClientRect();
              const cs=getComputedStyle(document.querySelector('#sceneFrame'));
              return {root:{x:root.x,y:root.y,w:root.width,h:root.height}, shell:{x:shell.x,w:shell.width,grid:getComputedStyle(document.querySelector('.shell')).gridTemplateColumns}, work:{x:work.x,w:work.width}, left:{x:left.x,w:left.width}, viewport:{x:vp.x,y:vp.y,w:vp.width,h:vp.height}, frame:{x:frame.x,y:frame.y,w:frame.width,h:frame.height}, inspector:{w:pane.width}, margins:{left:parseFloat(cs.marginLeft),right:parseFloat(cs.marginRight),top:parseFloat(cs.marginTop),bottom:parseFloat(cs.marginBottom)}, overflow:document.documentElement.scrollWidth>document.documentElement.clientWidth};
            }""")
        g_open = geometry(); page.locator('#inspectorClose').click(); page.wait_for_function("() => document.querySelector('#inspectorPane').getBoundingClientRect().width < 1", timeout=2000); g_closed = geometry()
        check('inspector.collapses', state()['inspector_open'] is False and g_closed['inspector']['w'] <= 1, {'state': state()['inspector_open'], 'open': g_open, 'closed': g_closed})
        check('inspector.reclaims_space', g_closed['viewport']['w'] > g_open['viewport']['w'], {'open': g_open['viewport']['w'], 'closed': g_closed['viewport']['w']})
        page.locator('#inspectorToggle').click(); page.wait_for_function("() => document.querySelector('#inspectorPane').getBoundingClientRect().width > 100", timeout=2000); g_reopen = geometry()
        check('inspector.reopens', state()['inspector_open'] is True and g_reopen['inspector']['w'] > 100, g_reopen)
        for name, g in [('open', g_open), ('closed', g_closed), ('reopen', g_reopen)]:
            check(f'geometry.{name}.no_document_overflow', not g['overflow'], g)
            # Frame margins are intentionally balanced on each axis and never below the workspace minimum.
            check(f'geometry.{name}.horizontal_gap', abs(g['margins']['left'] - g['margins']['right']) < 1.5 and g['margins']['left'] >= 20, g['margins'])
            check(f'geometry.{name}.vertical_gap', abs(g['margins']['top'] - g['margins']['bottom']) < 1.5 and g['margins']['top'] >= 20, g['margins'])

        # Zoom controls mutate visible zoom, fit remains bounded.
        z0=page.evaluate("() => ({text:document.querySelector('#zoomStatus').textContent,zoom:window.__VIZ_PROD__.ui.zoom,auto:window.__VIZ_PROD__.ui.autoFit})"); page.locator('#zoomIn').click(); page.wait_for_timeout(40); z1=page.evaluate("() => ({text:document.querySelector('#zoomStatus').textContent,zoom:window.__VIZ_PROD__.ui.zoom,auto:window.__VIZ_PROD__.ui.autoFit})"); print('[DEBUG zoom]',z0,z1,flush=True); check('zoom.in', z1['zoom'] > z0['zoom'] and z1['auto'] is False, {'before': z0, 'after': z1})
        page.locator('#zoomOut').click(); page.locator('#zoomFit').click(); page.wait_for_timeout(50)
        check('zoom.fit', '%' in page.locator('#zoomStatus').inner_text(), page.locator('#zoomStatus').inner_text())
        mini0 = page.locator('#miniToggle').get_attribute('aria-pressed'); page.locator('#miniToggle').click(); mini1 = page.locator('#miniToggle').get_attribute('aria-pressed')
        check('minimap.toggle', mini0 != mini1, {'before': mini0, 'after': mini1})

        # Library search/filter/show-more.
        page.locator('#componentSearch').fill('chart'); page.wait_for_timeout(20)
        visible_text = page.locator('#libraryCount').inner_text()
        check('library.search', '248 of 248' not in visible_text, visible_text)
        page.locator('#componentSearch').fill(''); page.wait_for_timeout(20)
        engines = page.locator('#engineFilter').locator('option').evaluate_all("els => els.map(e=>e.value).filter(Boolean)")
        check('library.engines_present', len(engines) == 17, engines)
        page.locator('#engineFilter').select_option(engines[0]); page.wait_for_timeout(20)
        check('library.engine_filter', page.locator('#libraryCount').inner_text().strip() != '248 of 248 elements', page.locator('#libraryCount').inner_text())
        page.locator('#engineFilter').select_option(''); page.locator('#componentSearch').fill('');
        # Show more works when list is limited.
        before_lib = page.locator('#fullLibrary .library-item').count()
        if page.locator('#libraryMore').is_visible():
            page.locator('#libraryMore').click(); page.wait_for_timeout(20)
            after_lib = page.locator('#fullLibrary .library-item').count()
            check('library.show_more', after_lib > before_lib, {'before': before_lib, 'after': after_lib})
        else:
            check('library.show_more', True, {'skipped': 'all entries visible at current filter'})

        # Save and PPT buttons dispatch semantic events; pointer movement must not.
        events0 = page.evaluate('() => window.__EVENTS.length'); page.locator('#serverSaveBtn').click(); page.locator('#pptBtn').click(); page.wait_for_timeout(20)
        events = page.evaluate('() => window.__EVENTS.slice()')
        types = [e.get('type') for e in events if isinstance(e, dict)]
        check('semantic.save', 'report.save_requested' in types, types)
        check('semantic.ppt', 'ppt.export_requested' in types, types)
        before_pointer = page.evaluate('() => window.__EVENTS.length'); page.mouse.move(40,40); page.mouse.move(300,300); page.wait_for_timeout(50); after_pointer = page.evaluate('() => window.__EVENTS.length')
        check('semantic.pointer_local', before_pointer == after_pointer, {'before': before_pointer, 'after': after_pointer})

        # Root replacement emulates NiceGUI/Vue hydration replacement; controls must rebind.
        instance0 = int(page.locator('.cui-visualizer-root').get_attribute('data-editor-instance'))
        before = count()
        page.evaluate("""() => { const old=document.querySelector('.cui-visualizer-root'); const clone=old.cloneNode(true); old.replaceWith(clone); }""")
        page.wait_for_function(f"() => Number(document.querySelector('.cui-visualizer-root')?.dataset.editorInstance) > {instance0} && document.querySelector('.cui-visualizer-root')?.dataset.editorReady==='true'")
        instance1 = int(page.locator('.cui-visualizer-root').get_attribute('data-editor-instance'))
        page.locator('.pal[data-type="chart"]').first.click(); page.wait_for_timeout(20)
        check('rehydration.rebinds', instance1 > instance0 and count() == before + 1, {'instances':[instance0,instance1], 'count':[before,count()]})

        # Responsive geometry: tablet + phone must not cut the workspace or page horizontally.
        responsive = {}
        for name, width, height in [('tablet', 900, 1100), ('phone', 390, 844)]:
            page.set_viewport_size({'width': width, 'height': height}); page.wait_for_timeout(100)
            responsive[name] = geometry()
            check(f'responsive.{name}.no_overflow', not responsive[name]['overflow'], responsive[name])
            check(f'responsive.{name}.shell_contained', responsive[name]['shell']['w'] <= responsive[name]['root']['w'] + 1.5, responsive[name])
            check(f'responsive.{name}.work_contained', responsive[name]['work']['x'] + responsive[name]['work']['w'] <= responsive[name]['root']['x'] + responsive[name]['root']['w'] + 1.5, responsive[name])
            check(f'responsive.{name}.inspector_hidden', responsive[name]['inspector']['w'] <= 1, responsive[name]['inspector'])
            check(f'responsive.{name}.workspace_width', responsive[name]['viewport']['w'] > width * 0.70, responsive[name]['viewport'])

        check('final.no_console_errors', not result['console_errors'], result['console_errors'])
        check('final.no_page_errors', not result['page_errors'], result['page_errors'])
        result['responsive'] = responsive
        result['final_state'] = state()
        result['events'] = page.evaluate('() => window.__EVENTS.slice(-20)')
        result['pass'] = all(v['pass'] for v in result['checks'].values())
        browser.close()

    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result['pass'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
