#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python3}"
"$ROOT/verify_checksums.sh"
echo "[PASS] package SHA-256 integrity"
VENV="${COMPANY_UI_VENV:-$ROOT/.venv}"
"$PYTHON_BIN" - <<'PY'
import sys
if not ((3,11) <= sys.version_info[:2] < (3,14)):
    raise SystemExit(f'Python {sys.version.split()[0]} unsupported; require >=3.11,<3.14')
print('Python',sys.version.split()[0],'OK')
PY
if [ ! -x "$VENV/bin/python" ]; then "$PYTHON_BIN" -m venv "$VENV"; fi
"$VENV/bin/python" -m pip install -r "$ROOT/requirements.txt"
WHEEL="$(find "$ROOT/wheel" -maxdepth 1 -name 'company_ui-3.0.0a1-*.whl' -print -quit)"
[ -n "$WHEEL" ] || { echo 'Application wheel missing' >&2; exit 1; }
"$VENV/bin/python" -m pip install --no-deps --force-reinstall "$WHEEL"
"$VENV/bin/python" -m pip check
"$VENV/bin/python" - <<'PY'
from importlib.metadata import version
expected={'nicegui':'3.15.0','python-pptx':'1.0.2','company-ui':'3.0.0a1'}
for package,want in expected.items():
    got=version(package)
    if got!=want: raise SystemExit(f'{package}: expected {want}, installed {got}')
    print(f'[PASS] {package} {got}')
PY
"$VENV/bin/python" - <<'PY'
import sys
from company_ui import StateKey, StateNamespace
key = StateKey[int]('python-runtime-smoke', StateNamespace.SESSION, default=0)
if key.default != 0:
    raise SystemExit('StateKey generic runtime smoke failed')
print(f'[PASS] StateKey[T] runtime compatibility on Python {sys.version.split()[0]}')
PY
"$VENV/bin/python" - <<'PY'
import inspect
from nicegui import app
from company_ui.products.visualizer.page import _register_static_routes
params = inspect.signature(app.add_static_files).parameters
if 'follow_symlink' not in params or 'follow_symlinks' in params:
    raise SystemExit(f'NiceGUI add_static_files API mismatch: {inspect.signature(app.add_static_files)}')
before = len(app.routes)
_register_static_routes(app)
after = len(app.routes)
if after < before + 2:
    raise SystemExit(f'Visualizer static route registration smoke failed: before={before} after={after}')
print(f'[PASS] NiceGUI add_static_files API {inspect.signature(app.add_static_files)}')
print('[PASS] Visualizer static route registration on installed NiceGUI 3.15.0')
PY
"$VENV/bin/python" "$ROOT/tools/verify_nicegui315_runtime_surface.py"
"$VENV/bin/python" - <<'PY'
from company_ui.products.visualizer.page import VISUALIZER_NAVIGATION
from company_ui.visual.registry import get_icon
items = list(VISUALIZER_NAVIGATION.iter_items())
if not items or items[0].route != '/visualizer':
    raise SystemExit('Visualizer navigation contract missing')
for item in items:
    if item.icon:
        resolved = get_icon(item.icon)
        if resolved.key != item.icon:
            raise SystemExit(f'Visualizer navigation icon mismatch: {item.icon} -> {resolved.key}')
print('[PASS] Visualizer product icons resolve canonically through Company UI registry')
PY
"$VENV/bin/python" "$ROOT/tools/verify_visualizer_asset_graph.py" --product-root "$ROOT/source/company_ui/products/visualizer" --output "$ROOT/evidence_local/setup_visualizer_asset_graph.json"
"$VENV/bin/python" "$ROOT/tools/verify_package.py" --root "$ROOT"
mkdir -p "$ROOT/evidence_local"
"$VENV/bin/python" "$ROOT/tools/live_startup_smoke.py" --output "$ROOT/evidence_local/setup_app_py_smoke.json"
"$VENV/bin/python" "$ROOT/tools/live_startup_smoke.py" --installed-wheel-entrypoint --output "$ROOT/evidence_local/setup_installed_wheel_smoke.json"
"$VENV/bin/python" "$ROOT/tools/headless_browser_startup_smoke.py" --output "$ROOT/evidence_local/setup_headless_browser_smoke.json"
"$VENV/bin/company-ui" runtime-contract
"$VENV/bin/company-ui" doctor --runtime-only --no-require-browser --ignore-port --port "${COMPANY_UI_PORT:-8080}"
printf '\nSetup complete: canonical root app.py rendered /visualizer successfully with clean server logs; installed-wheel cross-check also passed. Run: %s/run_visualizer.sh\n' "$ROOT"
