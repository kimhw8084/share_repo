from __future__ import annotations

import ast
import hashlib
import io
import json
from copy import deepcopy
from pathlib import Path

import pytest
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE
from pptx.util import Inches

from company_ui.certification.mac_lab import ROUTES
from company_ui.data_engine import Dataset
from company_ui.extensions import ExtensionKind
from company_ui.runtime import ApplicationRuntime
from company_ui.visual.registry import get_icon
from company_ui.products.visualizer.bridge import BROWSER_TO_SERVER, FORBIDDEN_HIGH_FREQUENCY, VisualizerBridgeService
from company_ui.products.visualizer.data_adapter import VisualizerDataAdapter
from company_ui.products.visualizer.domain import INITIAL_MODEL, ReportRecord, canonical_model, fingerprint_model
from company_ui.products.visualizer.extensions import register_visualizer
from company_ui.products.visualizer.ppt_service import COMPONENT_CONTRACTS, VisualizerPptService
from company_ui.products.visualizer.repository import ReportRepository

ROOT = Path(__file__).resolve().parents[1]
PRODUCT = ROOT / 'company_ui' / 'products' / 'visualizer'
VENDOR = PRODUCT / 'vendor' / 'production_core'
VENDOR_MANIFEST = PRODUCT / 'VENDOR_MANIFEST_SHA256.json'
GOLDEN_HASH = 'd8ebd4378f01b7c52a7a4be57c578c22adf29b899cc08a370cf084881195343e'


def _commit_payload(record, command, claimed):
    return {
        'report_id': record.report_id,
        'schema_version': 1,
        'base_revision': record.revision,
        'commit_id': command['id'],
        'command_or_patch': command,
        'canonical_state': claimed,
        'state_fingerprint': fingerprint_model(claimed),
    }


def _transaction(record, *ops, command_id='cmd-test'):
    command = {'id': command_id, 'type': 'editor.transaction', 'base_revision': record.revision, 'payload': {'ops': list(ops)}, 'meta': {'label': 'test'}}
    from company_ui.products.visualizer.domain import apply_editor_command
    claimed = apply_editor_command(record.model, command, expected_revision=record.revision)
    return command, claimed


def test_company_ui_inherited_22_routes_are_unchanged():
    assert len(ROUTES) == 22
    assert len({route.path for route in ROUTES}) == 22
    assert '/visualizer' not in {route.path for route in ROUTES}




def test_visualizer_navigation_uses_only_governed_company_ui_icons():
    from company_ui.products.visualizer.page import VISUALIZER_NAVIGATION

    items = list(VISUALIZER_NAVIGATION.iter_items())
    assert items
    assert items[0].route == '/visualizer'
    assert items[0].icon == 'chart-line'
    for item in items:
        if item.icon:
            assert get_icon(item.icon).key == item.icon


def test_visualizer_product_python_icon_literals_are_all_governed():
    icon_literals = set()
    for source_file in PRODUCT.glob('*.py'):
        tree = ast.parse(source_file.read_text(encoding='utf-8'), filename=str(source_file))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            for keyword in node.keywords:
                if keyword.arg == 'icon' and isinstance(keyword.value, ast.Constant) and isinstance(keyword.value.value, str):
                    icon_literals.add(keyword.value.value)
    assert icon_literals == {'chart-line'}
    for icon in sorted(icon_literals):
        assert get_icon(icon).key == icon


def test_visualizer_dedicated_launcher_redirects_root_to_canonical_workspace():
    cli_source = (PRODUCT / 'cli.py').read_text()
    assert "@app.get('/', include_in_schema=False)" in cli_source
    assert "RedirectResponse(url='/visualizer', status_code=307)" in cli_source


def test_visualizer_registers_only_through_governed_extension_boundary(tmp_path):
    runtime = ApplicationRuntime()
    product = register_visualizer(runtime, repository_root=tmp_path)
    assert runtime.extensions.get(ExtensionKind.WORKSPACE_PANEL, 'visualizer.workspace').metadata['route'] == '/visualizer'
    assert runtime.extensions.get(ExtensionKind.VISUALIZATION, 'visualizer.runtime').version == '97.1'
    assert runtime.extensions.get(ExtensionKind.DATA_SOURCE, 'visualizer.dataset-adapter').factory() is product.data_adapter
    assert runtime.extensions.get(ExtensionKind.COMPONENT, 'visualizer.report-bridge').factory() is product.bridge
    assert runtime.services.commands.get('visualizer.open') is not None
    assert runtime.services.commands.get('visualizer.new') is not None


def test_report_commit_is_revision_safe_atomic_and_deterministic(tmp_path):
    repo = ReportRepository(tmp_path)
    record = repo.create('r1')
    bridge = VisualizerBridgeService(repo)
    command, claimed = _transaction(record, {'op': 'item.patch', 'id': 'c1', 'patch': {'value': 0}}, command_id='cmd-zero')
    response = bridge.commit(_commit_payload(record, command, claimed))
    assert response.type == 'report.commit_ack'
    saved = repo.get('r1')
    assert saved.revision == 2
    assert saved.model['items'][0]['value'] == 0
    assert saved.state_fingerprint == fingerprint_model(saved.model)
    assert json.loads((tmp_path / 'r1.json').read_text())['revision'] == 2


def test_stale_commit_rejected_with_authoritative_state(tmp_path):
    repo = ReportRepository(tmp_path)
    original = repo.create('r1')
    bridge = VisualizerBridgeService(repo)
    command1, claimed1 = _transaction(original, {'op': 'model.patch', 'patch': {'layoutPreset': 'technical'}}, command_id='cmd-1')
    bridge.commit(_commit_payload(original, command1, claimed1))
    stale_command, stale_claimed = _transaction(original, {'op': 'model.patch', 'patch': {'layoutPreset': 'executive'}}, command_id='cmd-stale')
    response = bridge.commit(_commit_payload(original, stale_command, stale_claimed))
    assert response.type == 'report.commit_rejected'
    assert response.payload['reason'] == 'stale_base_revision'
    assert response.payload['authoritative']['revision'] == 2
    assert response.payload['authoritative']['model']['layoutPreset'] == 'technical'


def test_duplicate_commit_retry_is_idempotent(tmp_path):
    repo = ReportRepository(tmp_path)
    record = repo.create('r1')
    bridge = VisualizerBridgeService(repo)
    command, claimed = _transaction(record, {'op': 'model.patch', 'patch': {'layoutPreset': 'technical'}}, command_id='cmd-idempotent')
    payload = _commit_payload(record, command, claimed)
    first = bridge.commit(payload)
    assert first.payload['duplicate'] is False
    retry = dict(payload)
    retry['base_revision'] = 2
    second = bridge.commit(retry)
    assert second.type == 'report.commit_ack' and second.payload['duplicate'] is True
    assert repo.get('r1').revision == 2


def test_command_state_mismatch_is_rejected(tmp_path):
    repo = ReportRepository(tmp_path)
    record = repo.create('r1')
    bridge = VisualizerBridgeService(repo)
    command, claimed = _transaction(record, {'op': 'model.patch', 'patch': {'layoutPreset': 'technical'}}, command_id='cmd-mismatch')
    claimed['layoutPreset'] = 'executive'
    response = bridge.commit(_commit_payload(record, command, claimed))
    assert response.type == 'report.commit_rejected'
    assert response.payload['reason'] == 'command_state_mismatch'
    assert repo.get('r1').revision == 1


def test_repository_round_trip_and_bootstrap_are_exact(tmp_path):
    repo = ReportRepository(tmp_path)
    record = repo.create('exact', model=deepcopy(INITIAL_MODEL))
    round_trip = repo.get('exact')
    assert round_trip.to_dict() == record.to_dict()
    bootstrap = VisualizerBridgeService(repo).bootstrap('exact').payload
    assert bootstrap['revision'] == record.revision
    assert bootstrap['state_fingerprint'] == record.state_fingerprint
    assert bootstrap['model'] == record.model


def test_bridge_explicitly_excludes_high_frequency_frame_traffic(tmp_path):
    bridge = VisualizerBridgeService(ReportRepository(tmp_path))
    assert not (FORBIDDEN_HIGH_FREQUENCY & BROWSER_TO_SERVER)
    for kind in FORBIDDEN_HIGH_FREQUENCY:
        with pytest.raises(ValueError):
            bridge.handle({'bridge_version': 1, 'type': kind, 'payload': {}})


def test_dataset_adapter_preserves_zero_missing_identity_and_provenance():
    runtime = ApplicationRuntime()
    runtime.data.register(Dataset('typed', [
        {'id': 'a', 'sequence': 1, 'value': 0, 'optional': None},
        {'id': 'b', 'sequence': 2, 'value': 4.5, 'optional': 'x'},
    ], row_key='id'))
    workspace = runtime.open_workspace('w')
    session = workspace.open_data_session('typed')
    envelope = VisualizerDataAdapter().rows(session, provenance={'source': 'unit'})
    assert envelope.row_identity == 'id'
    assert envelope.rows[0]['value'] == 0
    assert envelope.rows[0]['optional'] is None
    assert envelope.provenance['dataset_key'] == 'typed'
    assert envelope.provenance['source'] == 'unit'


def test_sequence_only_timeline_never_invents_dates():
    runtime = ApplicationRuntime()
    runtime.data.register(Dataset('seq', [{'id': 1, 'step': 0}, {'id': 2, 'step': 1}], row_key='id'))
    session = runtime.open_workspace('w').open_data_session('seq')
    envelope = VisualizerDataAdapter().timeline(session, sequence_field='step')
    assert tuple(envelope.fields) == ('id', 'step')
    assert all('date' not in row and 'timestamp' not in row for row in envelope.rows)


def test_authoritative_registry_is_248_elements_17_engines_and_ppt_contracts_complete():
    registry = json.loads((VENDOR / 'contracts' / 'runtime_registry.json').read_text())
    assert registry['engines'] == 17
    assert registry['elements'] == 248
    assert len(registry['byEngine']) == 17
    assert sum(len(elements) for elements in registry['byEngine'].values()) == 248
    assert len(COMPONENT_CONTRACTS) == 248
    editor_only = sum(1 for item in COMPONENT_CONTRACTS.values() if item['ppt']['mapping'] == 'not_exported_editor_only')
    assert editor_only == 23
    assert 248 - editor_only == 225


def test_actual_integrated_library_exposes_registry_and_windowed_reachability():
    js = (PRODUCT / 'assets' / 'integrated_editor.mjs').read_text()
    html = (PRODUCT / 'assets' / 'integrated_editor.html').read_text()
    assert 'ELEMENTS_BY_ENGINE' in js
    assert 'allLibraryElements' in js
    assert 'All 248 elements' in html
    assert 'All 17 engines' in html
    assert 'libraryLimit = 36' in js  # avoids forcing all 248 cards into the live DOM
    assert 'addLibraryElement' in js and 'renderIntegratedElement(entry)' in js
    assert (PRODUCT / 'assets' / 'element_renderer.mjs').is_file()


def test_integrated_browser_bridge_has_semantic_queue_and_no_frame_dispatches():
    js = (PRODUCT / 'assets' / 'integrated_editor.mjs').read_text()
    assert 'semanticTail = semanticTail.then' in js
    assert "dispatchSemantic('report.commit'" in js
    assert 'base_revision: baseRevision' in js
    assert 'canonical_state: snapshot' in js
    assert 'state_fingerprint: fingerprint' in js
    for forbidden in ('pointermove', 'mousemove', 'dragover'):
        assert f"dispatchSemantic('{forbidden}'" not in js
    assert "addEventListener('pointermove'" in js  # retained browser interaction remains local




def test_visualizer_static_routes_do_not_expose_python_product_source():
    page_source = (PRODUCT / 'page.py').read_text()
    assert "add_static_files(STATIC_ROUTE, str(Path(__file__).parent)" not in page_source
    assert "f'{STATIC_ROUTE}/assets'" in page_source
    assert "f'{STATIC_ROUTE}/vendor/production_core'" in page_source

def test_visualizer_static_routes_match_pinned_nicegui_315_keyword_contract():
    from company_ui.products.visualizer.page import _register_static_routes

    calls = []

    class NiceGui315AppStub:
        def add_static_files(self, url_path, local_directory, *, follow_symlink=False, max_cache_age=3600):
            calls.append((url_path, local_directory, follow_symlink, max_cache_age))

    _register_static_routes(NiceGui315AppStub())
    assert [call[0] for call in calls] == [
        '/_cui_visualizer/assets',
        '/_cui_visualizer/vendor/production_core',
    ]
    assert all(call[2] is False for call in calls)


def test_visualizer_static_routes_never_use_invalid_plural_follow_symlinks_keyword():
    page_source = (PRODUCT / 'page.py').read_text()
    assert 'follow_symlinks=' not in page_source
    assert 'follow_symlink=False' in page_source

def test_integrated_css_is_scoped_and_does_not_modify_company_global_styles():
    css = (PRODUCT / 'assets' / 'integrated_editor.css').read_text()
    assert '@scope (.cui-visualizer-root)' in css
    assert '.cui-visualizer-root {' in css
    assert ':root {' not in css
    assert not (ROOT / 'company_ui' / 'design' / 'tokens.py').read_text().find('viz-') >= 0


def _vendor_hashes(root: Path):
    return {
        path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in root.rglob('*') if path.is_file() and '__pycache__' not in path.parts
    }


def test_vendored_visualizer_core_is_byte_identical_to_pristine_authority():
    manifest = json.loads(VENDOR_MANIFEST.read_text())
    assert manifest['authority'] == 'Visualizer 97.1 / 15_PRODUCTION_CORE'
    assert _vendor_hashes(VENDOR) == manifest['files']


def test_golden_connector_v5_remains_byte_identical():
    connector = VENDOR / 'core' / 'GOLDEN_CONNECTOR_ENGINE_V5_FROZEN.js'
    assert connector.exists()
    assert hashlib.sha256(connector.read_bytes()).hexdigest() == GOLDEN_HASH
    assert (PRODUCT / 'GOLDEN_CONNECTOR_SHA256.txt').read_text().strip() == GOLDEN_HASH


def _template_with_named_region() -> tuple[bytes, dict[str, float]]:
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    header = slide.shapes.add_textbox(Inches(.4), Inches(.15), Inches(12.3), Inches(.45))
    header.name = 'CORPORATE HEADER'
    header.text = 'Company template header'
    region = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(1.0), Inches(1.1), Inches(11.3), Inches(5.25))
    region.name = 'VISUALIZER_CONTENT'
    footer = slide.shapes.add_textbox(Inches(.4), Inches(7.0), Inches(12.3), Inches(.25))
    footer.name = 'CORPORATE FOOTER'
    footer.text = 'Confidential'
    stream = io.BytesIO(); prs.save(stream)
    return stream.getvalue(), {'x': 1.0, 'y': 1.1, 'width': 11.3, 'height': 5.25}


def test_ppt_named_region_precedes_explicit_region_and_preserves_template_outside():
    template, expected = _template_with_named_region()
    model = canonical_model({
        **INITIAL_MODEL,
        'items': [
            {'id': 'c1', 'type': 'metric', 'element': 'Hero KPI', 'engine': 'MetricEngine', 'title': 'KPI', 'weight': 1, 'order': 0, 'value': 98.7, 'locked': False, 'z': 1},
            {'id': 'c2', 'type': 'chart', 'element': 'Line Chart', 'engine': 'CoreChartEngine', 'title': 'Trend', 'weight': 1, 'order': 1, 'data': [['A', 0], ['B', 4.5]], 'locked': False, 'z': 2},
            {'id': 'c3', 'type': 'table', 'element': 'Clean Table', 'engine': 'TableEngine', 'title': 'Table', 'weight': 1, 'order': 2, 'rows': [{'id': 'a', 'value': 0, 'optional': None}, {'id': 'b', 'value': 4.5, 'optional': 'x'}], 'locked': False, 'z': 3},
        ],
        'nextId': 4,
    })
    record = ReportRecord('ppt-test', 1, model)
    plan = {'items': [
        {'id': 'c1', 'nx': 0, 'ny': 0, 'nw': .3, 'nh': .3},
        {'id': 'c2', 'nx': .32, 'ny': 0, 'nw': .68, 'nh': .55},
        {'id': 'c3', 'nx': 0, 'ny': .58, 'nw': 1, 'nh': .42},
    ]}
    result = VisualizerPptService().export(template, record, plan, explicit_region=(3, 3, 2, 2))
    assert result.target_region == expected
    assert result.exported_items == 3
    output = Presentation(io.BytesIO(result.content))
    names = [shape.name for shape in output.slides[0].shapes]
    assert 'CORPORATE HEADER' in names and 'CORPORATE FOOTER' in names and 'VISUALIZER_CONTENT' in names
    assert any(name.startswith('VIZ::') for name in names)
    assert any(getattr(shape, 'has_chart', False) for shape in output.slides[0].shapes)
    assert any(getattr(shape, 'has_table', False) for shape in output.slides[0].shapes)
    chart = next(shape.chart for shape in output.slides[0].shapes if getattr(shape, 'has_chart', False))
    assert tuple(chart.series[0].values) == (0.0, 4.5)
    table = next(shape.table for shape in output.slides[0].shapes if getattr(shape, 'has_table', False))
    values = [[cell.text for cell in row.cells] for row in table.rows]
    assert values[0] == ['id', 'value', 'optional']
    assert values[1] == ['a', '0', 'Missing']
    all_text = '\n'.join(shape.text for shape in output.slides[0].shapes if getattr(shape, 'has_text_frame', False))
    assert 'W1' not in all_text and 'Validate chamber' not in all_text


def test_ppt_missing_chart_and_table_data_never_invent_business_values():
    template, _ = _template_with_named_region()
    model = canonical_model({
        **INITIAL_MODEL,
        'items': [
            {'id': 'c1', 'type': 'chart', 'element': 'Line Chart', 'engine': 'CoreChartEngine', 'title': 'No Data Chart', 'weight': 1, 'order': 0, 'locked': False, 'z': 1},
            {'id': 'c2', 'type': 'table', 'element': 'Clean Table', 'engine': 'TableEngine', 'title': 'No Data Table', 'weight': 1, 'order': 1, 'locked': False, 'z': 2},
        ],
        'nextId': 3,
    })
    record = ReportRecord('ppt-no-data', 1, model)
    plan = {'items': [
        {'id': 'c1', 'nx': 0, 'ny': 0, 'nw': .5, 'nh': 1},
        {'id': 'c2', 'nx': .5, 'ny': 0, 'nw': .5, 'nh': 1},
    ]}
    result = VisualizerPptService().export(template, record, plan)
    output = Presentation(io.BytesIO(result.content))
    slide = output.slides[0]
    assert not any(getattr(shape, 'has_chart', False) for shape in slide.shapes)
    table = next(shape.table for shape in slide.shapes if getattr(shape, 'has_table', False))
    assert table.cell(0, 0).text == 'No tabular data embedded'
    all_text = '\n'.join(shape.text for shape in slide.shapes if getattr(shape, 'has_text_frame', False))
    for fabricated in ('W1', 'W2', 'Yield', 'Validate chamber', 'Kim', 'Run split'):
        assert fabricated not in all_text


def test_ppt_sequence_only_timeline_does_not_invent_dates():
    template, _ = _template_with_named_region()
    model = canonical_model({
        **INITIAL_MODEL,
        'items': [
            {'id': 'c1', 'type': 'timeline', 'element': 'Sequence Strip', 'engine': 'TimelineEngine', 'title': 'Sequence', 'weight': 1, 'order': 0,
             'events': [{'sequence': 1, 'label': 'Collect'}, {'sequence': 2, 'label': 'Verify'}], 'locked': False, 'z': 1},
        ],
        'nextId': 2,
    })
    result = VisualizerPptService().export(template, ReportRecord('ppt-sequence', 1, model), {'items': [{'id': 'c1', 'nx': 0, 'ny': 0, 'nw': 1, 'nh': 1}]})
    output = Presentation(io.BytesIO(result.content))
    texts = [shape.text for shape in output.slides[0].shapes if getattr(shape, 'has_text_frame', False)]
    joined = '\n'.join(texts)
    assert '1 · Collect' in joined and '2 · Verify' in joined
    assert not any(token in joined for token in ('2025-', '2026-', 'Jan ', 'Feb ', 'Mar '))


def test_ppt_plan_rejects_geometry_that_escapes_target_region():
    template, _ = _template_with_named_region()
    record = ReportRecord('ppt-test', 1, INITIAL_MODEL)
    with pytest.raises(ValueError):
        VisualizerPptService().export(template, record, {'items': [{'id': 'c1', 'nx': .9, 'ny': 0, 'nw': .2, 'nh': .2}]})


def test_visualizer_cli_uses_platform_host_and_port_fallbacks(monkeypatch):
    from company_ui.products.visualizer import cli
    monkeypatch.delenv('COMPANY_UI_HOST', raising=False)
    monkeypatch.delenv('COMPANY_UI_PORT', raising=False)
    monkeypatch.setenv('HOST', '0.0.0.0')
    monkeypatch.setenv('PORT', '9123')
    assert cli._default_host() == '0.0.0.0'
    assert cli._default_port() == 9123


def test_visualizer_cli_production_requires_explicit_storage_secret(monkeypatch):
    from company_ui.products.visualizer import cli
    from company_ui.runtime import RuntimeEnvironment
    monkeypatch.delenv('COMPANY_UI_STORAGE_SECRET', raising=False)
    try:
        cli._runtime_secret_environment(RuntimeEnvironment.PROD)
    except RuntimeError as exc:
        assert 'COMPANY_UI_STORAGE_SECRET is required in production' in str(exc)
    else:
        raise AssertionError('production launch must not use an implicit predictable storage secret')


def test_visualizer_cli_nonprod_generates_nonempty_process_secret(monkeypatch):
    from company_ui.products.visualizer import cli
    from company_ui.runtime import RuntimeEnvironment
    monkeypatch.delenv('COMPANY_UI_STORAGE_SECRET', raising=False)
    env = cli._runtime_secret_environment(RuntimeEnvironment.DEV)
    assert len(env['COMPANY_UI_STORAGE_SECRET']) >= 32
    assert env['COMPANY_UI_STORAGE_SECRET'] != f'company-ui-visualizer-v3.0.0a1'


def test_root_publish_entrypoint_prefers_bundled_source():
    from pathlib import Path
    entry = Path(__file__).resolve().parents[1] / 'app.py'
    # The source-tree test lives one level below the package root in delivery, so
    # use the staged package relationship when present and otherwise audit source text.
    if not entry.is_file():
        entry = Path(__file__).resolve().parents[2] / 'app.py'
    if entry.is_file():
        text = entry.read_text(encoding='utf-8')
        assert "SOURCE = ROOT / 'source'" in text
        assert 'sys.path.insert(0, str(SOURCE))' in text
        assert 'company_ui.products.visualizer.cli import main' in text
        root = entry.parent
        assert sorted(p.name for p in root.glob('*.py')) == ['app.py']


def test_pptx_preflight_rejects_non_pptx_zip_payload():
    import io, zipfile
    from company_ui.products.visualizer.domain import VisualizerContractError
    from company_ui.products.visualizer.ppt_service import _validate_pptx_payload
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w') as z:
        z.writestr('not-a-presentation.txt', 'x')
    try:
        _validate_pptx_payload(stream.getvalue())
    except VisualizerContractError as exc:
        assert 'missing required presentation parts' in str(exc)
    else:
        raise AssertionError('malformed PPTX ZIP must be rejected before python-pptx parsing')


def test_pptx_preflight_accepts_real_pptx():
    import io
    from pptx import Presentation
    from company_ui.products.visualizer.ppt_service import _validate_pptx_payload
    prs = Presentation(); prs.slides.add_slide(prs.slide_layouts[6])
    stream = io.BytesIO(); prs.save(stream)
    _validate_pptx_payload(stream.getvalue())
