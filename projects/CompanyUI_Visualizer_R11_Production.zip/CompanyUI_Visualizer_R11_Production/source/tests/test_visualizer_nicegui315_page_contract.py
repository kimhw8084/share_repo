from __future__ import annotations

import asyncio
import sys
import types
from pathlib import Path

from company_ui.runtime import ApplicationRuntime
from company_ui.products.visualizer.extensions import register_visualizer


class _Awaitable:
    def __await__(self):
        if False:
            yield None
        return None


class _Element:
    _next_id = 1

    def __init__(self, *args, **kwargs):
        self.id = _Element._next_id
        _Element._next_id += 1
        self.args = args
        self.kwargs = kwargs
        self.handlers = {}
        self.disabled = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def classes(self, *args, **kwargs):
        return self

    def props(self, *args, **kwargs):
        return self

    def style(self, *args, **kwargs):
        return self

    def on(self, event, handler=None, *args, js_handler=None, **kwargs):
        self.handlers[event] = handler if handler is not None else js_handler
        return self

    def update(self):
        return self

    def tooltip(self, *args, **kwargs):
        return self

    def disable(self):
        self.disabled = True
        return self

    def enable(self):
        self.disabled = False
        return self

    # Deliberately NO set_text: generic NiceGUI Element does not expose it in 3.15.0.


class _Label(_Element):
    def __init__(self, text='', *args, **kwargs):
        super().__init__(text, *args, **kwargs)
        self.text = text

    def set_text(self, text):
        self.text = text
        return self


class _Select(_Element):
    def __init__(self, *, options, value=None, label=None, on_change=None, **kwargs):
        super().__init__(options=options, value=value, label=label, on_change=on_change, **kwargs)
        self.options = options
        self.value = value
        self.on_change = on_change



class _Input(_Element):
    def __init__(self, *, label=None, value=None, on_change=None, **kwargs):
        super().__init__(label=label, value=value, on_change=on_change, **kwargs)
        self.label = label
        self.value = value
        self.on_change = on_change

class _Dialog(_Element):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.opened = False
    def open(self):
        self.opened = True
        return self
    def close(self):
        self.opened = False
        return self

class _Upload(_Element):
    def __init__(self, *, on_upload=None, max_file_size=None, max_files=None, **kwargs):
        super().__init__(on_upload=on_upload, max_file_size=max_file_size, max_files=max_files, **kwargs)
        self.on_upload = on_upload


class _Client:
    def __init__(self):
        self.delete_callbacks = []

    def on_delete(self, callback):
        self.delete_callbacks.append(callback)


class _Navigate:
    def to(self, route):
        return None


class _FakeUI:
    def __init__(self):
        self.pages = {}
        self.context = types.SimpleNamespace(client=_Client())
        self.navigate = _Navigate()
        self.css = []
        self.head = []
        self.body = []
        self.javascript = []
        self.uploads = []
        self.selects = []
        self.inputs = []
        self.dialogs = []
        self.buttons = []
        self.elements = []
        self.downloads = []
        self.html_calls = []

    def page(self, route):
        def decorate(func):
            self.pages[route] = func
            return func
        return decorate

    def element(self, *args, **kwargs):
        item = _Element(*args, **kwargs)
        self.elements.append(item)
        return item

    def html(self, content='', *, sanitize=True, tag='div'):
        self.html_calls.append((content, sanitize, tag))
        return _Element(content, sanitize=sanitize, tag=tag)

    def label(self, text=''):
        return _Label(text)

    def select(self, *args, **kwargs):
        if args:
            kwargs['options'] = args[0]
        item = _Select(**kwargs)
        self.selects.append(item)
        return item

    def input(self, *args, **kwargs):
        if args and 'label' not in kwargs: kwargs['label'] = args[0]
        item = _Input(**kwargs); self.inputs.append(item); return item

    def dialog(self, *args, **kwargs):
        item = _Dialog(*args, **kwargs); self.dialogs.append(item); return item

    def card(self, *args, **kwargs): return _Element(*args, **kwargs)

    def upload(self, **kwargs):
        item = _Upload(**kwargs)
        self.uploads.append(item)
        return item

    def button(self, *args, **kwargs):
        item = _Element(*args, **kwargs)
        item.on_click = kwargs.get('on_click')
        self.buttons.append(item)
        return item
    def row(self, *args, **kwargs): return _Element(*args, **kwargs)
    def column(self, *args, **kwargs): return _Element(*args, **kwargs)
    def item(self, *args, **kwargs): return _Element(*args, **kwargs)
    def item_section(self, *args, **kwargs): return _Element(*args, **kwargs)
    def item_label(self, text='', *args, **kwargs): return _Label(text, *args, **kwargs)
    def badge(self, text='', *args, **kwargs): return _Label(text, *args, **kwargs)
    def link(self, *args, **kwargs): return _Element(*args, **kwargs)
    def query(self, *args, **kwargs): return _Element(*args, **kwargs)

    def add_css(self, css, *, shared=False):
        self.css.append((css, shared))

    def add_head_html(self, html, *, shared=False):
        self.head.append((html, shared))

    def add_body_html(self, html, *, shared=False):
        self.body.append((html, shared))

    def run_javascript(self, code, *, timeout=1.0):
        self.javascript.append((code, timeout))
        return _Awaitable()

    def timer(self, *args, **kwargs):
        return _Element(*args, **kwargs)

    def download(self, content, filename=None, media_type=''):
        self.downloads.append((content, filename, media_type))

    clipboard = types.SimpleNamespace(write=lambda text: None)


class _FakeApp:
    def __init__(self):
        self.static = []

    def add_static_files(self, url_path, local_directory, *, follow_symlink=False, max_cache_age=3600):
        self.static.append((url_path, local_directory, follow_symlink, max_cache_age))


def test_visualizer_page_constructs_against_strict_nicegui315_surface(monkeypatch, tmp_path: Path):
    """Execute the complete Visualizer page builder using only APIs NiceGUI 3.15 exposes.

    This is intentionally strict: generic elements do not grow convenience methods via
    __getattr__. The R4 ``ui.element(...).set_text(...)`` defect therefore fails here.
    """
    fake_ui = _FakeUI()
    fake_app = _FakeApp()
    module = types.ModuleType('nicegui')
    module.ui = fake_ui
    module.app = fake_app
    monkeypatch.setitem(sys.modules, 'nicegui', module)

    # Force the shell/theme integration to exercise its NiceGUI calls in this test.
    import company_ui.integrations.nicegui_theme as theme
    monkeypatch.setattr(theme, '_INSTALLED', False)
    monkeypatch.setattr(theme, 'build_framework_css', lambda: '/* strict-page-contract */')

    from company_ui.integrations.nicegui_state import NiceGUIStateServices
    from company_ui.services import ApplicationServices
    services = ApplicationServices(
        notifications=NiceGUIStateServices.notification_service(),
        navigation=NiceGUIStateServices.navigation_service(),
        clipboard=NiceGUIStateServices.clipboard_service(),
        downloads=NiceGUIStateServices.download_service(),
    )
    runtime = ApplicationRuntime(services=services)
    product = register_visualizer(runtime, repository_root=tmp_path / 'reports')

    from company_ui.products.visualizer.page import register_visualizer_page
    register_visualizer_page(runtime, product)
    assert '/visualizer' in fake_ui.pages
    assert len(fake_app.static) == 2
    assert all(item[2] is False for item in fake_app.static)
    routes = {item[0]: Path(item[1]).resolve() for item in fake_app.static}
    assert '/_cui_visualizer/assets' in routes
    assert '/_cui_visualizer/vendor/production_core' in routes
    assert routes['/_cui_visualizer/vendor/production_core'].name == 'production_core'

    asyncio.run(fake_ui.pages['/visualizer']())

    assert len(fake_ui.uploads) == 2
    assert all(item.on_upload is not None for item in fake_ui.uploads)
    assert fake_ui.selects and fake_ui.selects[0].value == 'default'
    assert fake_ui.inputs and fake_ui.inputs[0].label == 'Report title'
    assert len(fake_ui.dialogs) == 3
    assert any('visualizer-editor-root' in html and 'replaceChildren' in html for html, _ in fake_ui.body)
    assert any('integrated_editor.mjs' in html for html, _ in fake_ui.body)
    assert not any('visualizer-editor-root' in content for content, _sanitize, _tag in fake_ui.html_calls), 'retained editor must not depend on a Vue-managed ui.html wrapper'
    assert any('cui-visualizer-import-summary' in css for css, _ in fake_ui.css)
    mobile_handlers = [handler for item in fake_ui.buttons for handler in item.handlers.values() if isinstance(handler, str) and 'mobileNav' in handler]
    assert mobile_handlers and any("dataset.mobileNav=opening?'open':'closed'" in handler for handler in mobile_handlers)

    async def exercise_callbacks():
        # New-report chooser creates a truly blank canonical report.
        blank_button = next(item for item in fake_ui.buttons if item.args and item.args[0] == 'Blank canvas')
        await blank_button.on_click()
        assert len(product.repository.list()) >= 2
        assert product.repository.list()[0].model['items'] == []

        class AsyncFile:
            def __init__(self, name, payload):
                self.name = name
                self.payload = payload
            async def read(self):
                return self.payload

        # JSON import callback executes canonicalization, repository persistence, selector update and JS bootstrap send.
        report_event = types.SimpleNamespace(file=AsyncFile('imported.json', b'{"model":{"schema_version":1,"components":[]}}'))
        await fake_ui.uploads[1].on_upload(report_event)
        assert any(item.report_id.startswith('import-') for item in product.repository.list())

        # PPT callback parses a real editable PPTX and updates a real text-capable label.
        import io
        from pptx import Presentation
        ppt = Presentation(); ppt.slides.add_slide(ppt.slide_layouts[6]); buffer = io.BytesIO(); ppt.save(buffer)
        ppt_event = types.SimpleNamespace(file=AsyncFile('work-template.pptx', buffer.getvalue()))
        await fake_ui.uploads[0].on_upload(ppt_event)

        # Report selection callback must resolve and emit a bootstrap without relying on browser-only state.
        target = 'default'
        fake_ui.selects[0].value = target
        await fake_ui.selects[0].on_change(types.SimpleNamespace(value=target))

        # Semantic bridge callbacks after first render: dataset miss, export and asset-import paths.
        bridge_host = next(item for item in fake_ui.elements if 'visualizer_bridge' in item.handlers)
        import json
        await bridge_host.handlers['visualizer_bridge'](types.SimpleNamespace(args={'detail': json.dumps({'type':'dataset.bind_requested','payload':{'dataset_key':'missing'}})}))
        await bridge_host.handlers['visualizer_bridge'](types.SimpleNamespace(args={'detail': json.dumps({'type':'asset.import_requested','payload':{}})}))
        plan = {'items':[{'id':'c1','nx':0.08,'ny':0.1,'nw':0.4,'nh':0.3}]}
        await bridge_host.handlers['visualizer_bridge'](types.SimpleNamespace(args={'detail': json.dumps({'type':'ppt.export_requested','payload':{'normalized_plan':plan}})}))
        assert fake_ui.downloads, 'PPT export should reach the governed NiceGUI download service after a template is loaded'

    asyncio.run(exercise_callbacks())
    assert fake_ui.javascript, 'callbacks should emit semantic/bootstrap JavaScript responses'


def test_visualizer_retained_mount_bootstrap_is_fail_visible_and_rehydratable():
    from company_ui.products.visualizer.page import _editor_mount_script
    fragment = '<div id="visualizer-editor-root" class="cui-visualizer-root"><button id="probe">Probe</button></div>'
    script = _editor_mount_script('viz-mount-probe', fragment)
    assert 'document.getElementById(mountId)' in script
    assert "querySelector(':scope > #visualizer-editor-root')" in script
    assert 'host.replaceChildren()' in script
    assert 'template.innerHTML=markup.trim()' in script
    assert "host.dataset.visualizerMount='mounted'" in script
    assert 'MutationObserver' in script
    assert 'ui.html' not in script
