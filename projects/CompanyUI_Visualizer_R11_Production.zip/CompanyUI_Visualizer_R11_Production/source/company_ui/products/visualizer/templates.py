from __future__ import annotations

from copy import deepcopy

from .domain import canonical_model


def _item(id_: str, type_: str, engine: str, order: int, title: str, **extra):
    return {'id': id_, 'type': type_, 'engine': engine, 'order': order, 'title': title, 'locked': False, 'groupId': None, 'z': order, **extra}


BLANK_REPORT = canonical_model({
    'items': [], 'groups': {}, 'mode': 'guided', 'layoutPreset': 'editorial', 'crossFilter': None, 'nextId': 1,
})

REPORT_TEMPLATES = {
    'executive-brief': {
        'name': 'Executive Brief',
        'description': 'Headline KPI, trend, key takeaway and decision summary.',
        'model': canonical_model({'mode': 'guided', 'layoutPreset': 'executive', 'nextId': 5, 'items': [
            _item('c1','Hero KPI','MetricEngine',1,'Primary KPI',value=None,unit='',delta=None,target=None),
            _item('c2','Line Chart','CoreChartEngine',2,'Trend',rows=[{'label':'Period 1','value':None},{'label':'Period 2','value':None}]),
            _item('c3','Key Takeaway','TextEngine',3,'Key takeaway',text='Summarize the most important result.'),
            _item('c4','Decision Card','DecisionCompositeEngine',4,'Decision',statement='Decision required',detail='Describe the recommendation and trade-offs.',status='Open'),
        ]}),
    },
    'investigation-rca': {
        'name': 'Investigation / RCA',
        'description': 'Problem statement, evidence, causal diagram and actions.',
        'model': canonical_model({'mode': 'guided', 'layoutPreset': 'technical', 'nextId': 5, 'items': [
            _item('c1','Problem Statement','TextEngine',1,'Problem statement',text='Define the observed problem and impact.'),
            _item('c2','Evidence Log','EvidenceCompositeEngine',2,'Evidence',statement='Evidence item',detail='Add source, observation and confidence.',status='Observed'),
            _item('c3','Fishbone Diagram','DiagramEngine',3,'Cause analysis',nodes=['Problem','Method','Machine','Material'],edges=[['Method','Problem'],['Machine','Problem'],['Material','Problem']]),
            _item('c4','Action Register','ProjectCompositeEngine',4,'Actions',statement='Corrective action',detail='Owner · due date · verification',status='Planned'),
        ]}),
    },
    'operations-review': {
        'name': 'Operations Review',
        'description': 'Operational scorecard with KPIs, table, trend and risks.',
        'model': canonical_model({'mode': 'guided', 'layoutPreset': 'editorial', 'nextId': 5, 'items': [
            _item('c1','KPI Strip','MetricEngine',1,'Operations KPIs',value=None,unit='',delta=None,target=None),
            _item('c2','Clean Table','TableEngine',2,'Operating detail',columns=['Metric','Actual','Target'],rows=[['Example',None,None]]),
            _item('c3','Combo Chart','CoreChartEngine',3,'Performance trend',rows=[{'label':'Period 1','value':None},{'label':'Period 2','value':None}]),
            _item('c4','Risk Callout','DecisionCompositeEngine',4,'Top risk',statement='Risk',detail='Describe exposure and mitigation.',status='Monitor'),
        ]}),
    },
    'wafer-fab-analysis': {
        'name': 'Wafer / Fab Analysis',
        'description': 'Semiconductor spatial/process analysis with editable observations.',
        'model': canonical_model({'mode': 'guided', 'layoutPreset': 'technical', 'nextId': 5, 'items': [
            _item('c1','Wafer Map','WaferFabEngine',1,'Wafer map',observations=[],tool='',chamber='',lot='',route=''),
            _item('c2','Tool Comparison','WaferFabEngine',2,'Tool comparison',observations=[],tool='',chamber='',lot='',route=''),
            _item('c3','Control Chart','EngineeringChartEngine',3,'Process control',observations=[],role='Measurement',lcl=None,ucl=None),
            _item('c4','Evidence Log','EvidenceCompositeEngine',4,'Engineering evidence',statement='Observation',detail='Record provenance and interpretation.',status='Observed'),
        ]}),
    },
}


def template_model(template_id: str):
    if template_id == 'blank':
        return deepcopy(BLANK_REPORT)
    try:
        return deepcopy(REPORT_TEMPLATES[template_id]['model'])
    except KeyError as exc:
        raise KeyError(f'Unknown Visualizer template: {template_id}') from exc
