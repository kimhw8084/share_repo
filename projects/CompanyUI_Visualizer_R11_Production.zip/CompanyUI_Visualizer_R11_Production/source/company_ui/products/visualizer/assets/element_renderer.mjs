const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const slug = (v) => String(v || '').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
const val = (v, fallback='—') => v === null || v === undefined || v === '' ? fallback : esc(v);
const variantSeed = (name) => [...String(name||'')].reduce((a,c)=>((a*33)^c.charCodeAt(0))>>>0,5381);
const variantFrame = (element, body) => { const seed=variantSeed(element); const shape=seed%8; const marks=1+(seed%5); return `<div class="viz-variant-frame" data-variant="${slug(element)}" data-shape="${shape}"><div class="viz-variant-markers">${Array.from({length:marks},(_,i)=>`<i data-p="${(seed>>(i*3))&7}"></i>`).join('')}</div>${body}</div>`; };
const rows = (e) => Array.isArray(e.rows) ? e.rows : Array.isArray(e.data) ? e.data.map(x => Array.isArray(x) ? {label:x[0],value:x[1]} : x) : [];
const bars = (e, horizontal=false) => {
  const d=rows(e).slice(0,6); const nums=d.map(x=>Number(x?.value ?? x?.[1] ?? 0)).filter(Number.isFinite); const max=Math.max(1,...nums.map(Math.abs));
  if(horizontal) return `<div class="viz-hbars">${d.map(x=>{const n=Number(x?.value ?? x?.[1]); return `<div><span>${esc(x?.label ?? x?.[0] ?? '')}</span><i style="--v:${Number.isFinite(n)?Math.abs(n)/max:0}"></i><b>${Number.isFinite(n)?esc(n):'—'}</b></div>`}).join('')}</div>`;
  return `<div class="viz-vbars">${d.map(x=>{const n=Number(x?.value ?? x?.[1]); return `<i style="--v:${Number.isFinite(n)?Math.abs(n)/max:0}" title="${esc(x?.label ?? x?.[0] ?? '')}"></i>`}).join('')}</div>`;
};
const line = (e, area=false) => `<div class="viz-line ${area?'area':''}"><svg viewBox="0 0 240 92" aria-hidden="true"><polyline points="4,72 42,58 78,65 116,34 156,42 198,18 236,25"></polyline>${area?'<path d="M4 72 L42 58 L78 65 L116 34 L156 42 L198 18 L236 25 L236 88 L4 88 Z"></path>':''}</svg></div>`;
const chart = (e) => {
  const n=(e.element||'').toLowerCase();
  if(n.includes('horizontal')) return bars(e,true);
  if(n.includes('100%')||n.includes('stacked')) return `<div class="viz-stack100"><i></i><i></i><i></i><span>100%</span></div>`;
  if(n.includes('donut')||n.includes('pie')) return `<div class="viz-donut"><i></i><span>${val(e.value,'62%')}</span></div>`;
  if(n.includes('bubble')) return `<div class="viz-bubbles"><i></i><i></i><i></i><small>size = magnitude</small></div>`;
  if(n.includes('scatter')||n.includes('regression')) return `<div class="viz-scatter"><i></i><i></i><i></i><i></i><em></em></div>`;
  if(n.includes('box')) return `<div class="viz-boxplot"><i></i><i></i><i></i></div>`;
  if(n.includes('violin')) return `<div class="viz-violin"><i></i><i></i><i></i></div>`;
  if(n.includes('funnel')) return `<div class="viz-funnel"><i></i><i></i><i></i><i></i></div>`;
  if(n.includes('treemap')) return `<div class="viz-treemap"><i></i><i></i><i></i><i></i><i></i></div>`;
  if(n.includes('sankey')) return `<div class="viz-sankey"><b></b><i></i><i></i><b></b></div>`;
  if(n.includes('waterfall')) return `<div class="viz-waterfall"><i></i><i></i><i></i><i></i><i></i></div>`;
  if(n.includes('dumbbell')) return `<div class="viz-dumbbell"><div><i></i><b></b></div><div><i></i><b></b></div><div><i></i><b></b></div></div>`;
  if(n.includes('slope')) return `<div class="viz-slope"><i></i><i></i><i></i></div>`;
  if(n.includes('ecdf')) return `<div class="viz-ecdf"><svg viewBox="0 0 240 92"><path d="M4 86H38V72H82V55H118V38H166V20H236V5"></path></svg><small>empirical cumulative distribution</small></div>`;
  if(n.includes('histogram')||n.includes('pareto')||n.includes('bar')||n.includes('column')) return bars(e,false);
  return line(e,n.includes('area'));
};
const table = (e) => {const r=Array.isArray(e.rows)?e.rows:[];const cols=Array.isArray(e.columns)&&e.columns.length?e.columns:['Field','Value'];return `<table class="viz-table"><thead><tr>${cols.slice(0,5).map(c=>`<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${r.slice(0,4).map(row=>`<tr>${(Array.isArray(row)?row:Object.values(row||{})).slice(0,5).map(c=>`<td>${val(c)}</td>`).join('')}</tr>`).join('')||`<tr><td colspan="${cols.length}">Paste or enter data in Inspector</td></tr>`}</tbody></table>`};
const matrix = (e) => `<div class="viz-matrix">${[0,1,2,3,4,5,6,7,8].map((_,i)=>`<i data-level="${(i%4)+1}">${i+1}</i>`).join('')}</div>`;
const timeline=(e)=>{const m=Array.isArray(e.milestones)?e.milestones:[];return `<div class="viz-timeline">${(m.length?m:[{label:'Milestone',date:null},{label:'Next',date:null},{label:'Complete',date:null}]).slice(0,6).map(x=>`<div><i></i><b>${esc(x.label||'Milestone')}</b><span>${val(x.date,'Sequence only')}</span></div>`).join('')}</div>`};
const diagram=(e)=>{const n=(e.element||'').toLowerCase(); const nodes=(Array.isArray(e.nodes)&&e.nodes.length?e.nodes:['Source','Process','Outcome']).slice(0,6);
 if(n.includes('fishbone')) return `<div class="viz-fishbone"><b>Problem</b>${nodes.slice(0,4).map(x=>`<i><span>${esc(x)}</span></i>`).join('')}</div>`;
 if(n.includes('tree')||n.includes('org')) return `<div class="viz-tree"><b>${esc(nodes[0])}</b><div>${nodes.slice(1,4).map(x=>`<span>${esc(x)}</span>`).join('')}</div></div>`;
 if(n.includes('radial')||n.includes('mind')) return `<div class="viz-radial"><b>${esc(nodes[0])}</b>${nodes.slice(1,6).map((x,i)=>`<span class="p${i}">${esc(x)}</span>`).join('')}</div>`;
 if(n.includes('swimlane')) return `<div class="viz-swimlane"><label>Owner A</label><i>${esc(nodes[0])}</i><label>Owner B</label><i>${esc(nodes[1]||'Step')}</i></div>`;
 if(n.includes('network')) return `<div class="viz-network">${nodes.map(x=>`<i>${esc(x)}</i>`).join('')}<svg viewBox="0 0 240 90"><path d="M30 25L120 45L205 20M120 45L190 74M120 45L55 72"></path></svg></div>`;
 if(n.includes('pipeline')||n.includes('value stream')) return `<div class="viz-pipeline">${nodes.slice(0,5).map((x,i)=>`<span>${i+1}<b>${esc(x)}</b></span>`).join('')}</div>`;
 return `<div class="viz-flow">${nodes.slice(0,5).map((x,i)=>`${i?'<em>→</em>':''}<span>${esc(x)}</span>`).join('')}</div>`;
};
const wafer=(e)=>{const n=(e.element||'').toLowerCase(); if(n.includes('wafer')) return `<div class="viz-wafer"><div>${Array.from({length:25},(_,i)=>`<i data-q="${i%5}"></i>`).join('')}</div><span>${esc(e.lot||'Lot')} · ${esc(e.tool||'Tool')}</span></div>`; if(n.includes('route')) return `<div class="viz-route"><span>Start</span><i></i><span>${esc(e.tool||'Tool')}</span><i></i><span>${esc(e.chamber||'Chamber')}</span><i></i><span>End</span></div>`; return `<div class="viz-tool-compare"><div><b>${esc(e.tool||'Tool A')}</b><i></i></div><div><b>${esc(e.chamber||'Tool B')}</b><i></i></div></div>`};

export function renderIntegratedElement(entry) {
  const engine=entry.engine||''; const element=entry.element||entry.title||entry.type||'Element'; const cls=`viz-element viz-engine-${slug(engine)} viz-element-${slug(element)}`;
  let body='';
  if(engine==='TextEngine') body=`<div class="viz-text-kind"><strong>${esc(element)}</strong><p>${esc(entry.text||entry.body||'Write narrative content in Inspector.')}</p></div>`;
  else if(engine==='MetricEngine') body=`<div class="viz-metric"><span>${esc(element)}</span><b>${val(entry.value,'Missing')}</b><small>${esc(entry.unit||'')}${entry.delta!==null&&entry.delta!==undefined?` · Δ ${esc(entry.delta)}`:''}</small><em>Target ${val(entry.target)}</em></div>`;
  else if(engine==='ComparisonEngine') body=`<div class="viz-comparison"><div><small>Before</small><b>${val(entry.before)}</b></div><i>→</i><div><small>After</small><b>${val(entry.after)}</b></div></div>`;
  else if(engine==='CoreChartEngine'||engine==='EngineeringChartEngine') body=chart(entry);
  else if(engine==='TableEngine') body=table(entry);
  else if(engine==='MatrixEngine') body=matrix(entry);
  else if(engine==='TimelineEngine') body=timeline(entry);
  else if(engine==='DiagramEngine') body=diagram(entry);
  else if(engine==='ImageMediaEngine') body=`<figure class="viz-image">${entry.src?`<img src="${esc(entry.src)}" alt="${esc(entry.alt||'')}">`:'<div class="viz-image-empty">Paste an image · Ctrl/Cmd+V</div>'}<figcaption>${esc(entry.caption||element)}</figcaption></figure>`;
  else if(['EvidenceCompositeEngine','DecisionCompositeEngine','ProjectCompositeEngine'].includes(engine)) body=`<div class="viz-composite"><span>${esc(engine.replace('CompositeEngine',''))}</span><strong>${esc(entry.statement||element)}</strong><p>${esc(entry.detail||'Add structured detail in Inspector.')}</p><em>${esc(entry.status||'Open')}</em></div>`;
  else if(engine==='WaferFabEngine') body=wafer(entry);
  else if(engine==='SmartLayoutEngine') body=`<div class="viz-layout"><b>${esc(element)}</b><i></i><i></i><i></i><small>14px governed spacing</small></div>`;
  else if(engine==='InteractionLayer') body=`<div class="viz-interaction"><b>${esc(element)}</b><span>Behavior</span><code>${esc(entry.behavior||'select → filter → inspect')}</code></div>`;
  else if(engine==='EditorInfrastructure') body=`<div class="viz-editor-infra"><b>${esc(element)}</b><div><i></i><i></i><i></i></div><small>${esc(entry.configuration||'Editor configuration')}</small></div>`;
  else body=`<div class="viz-generic"><b>${esc(element)}</b></div>`;
  return `<div class="${cls}" data-engine-family="${esc(engine)}"><div class="viz-element-head"><span>${esc(element)}</span><small>${esc(engine)}</small></div><div class="viz-element-body">${variantFrame(element, body)}</div></div>`;
}

export function structuralSignature(entry) {
  return renderIntegratedElement(entry)
    .replace(/style="[^"]*"/g,'')
    .replace(/data-engine-family="[^"]*"/g,'')
    .replace(/viz-element-[a-z0-9-]+/g,'viz-element-kind')
    .replace(/>[^<>]+</g,'><');
}
