from __future__ import annotations

import inspect
import io
import json
import hashlib
import os
import uuid
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Mapping

from company_ui.integrations.nicegui_components import Button, FileUpload
from company_ui.integrations.nicegui_layout import AppShell, PageHeader
from company_ui.navigation import NavigationModel, NavItem, NavSection
from company_ui.runtime import ApplicationRuntime, StateKey, StateNamespace

from .domain import VisualizerContractError, canonical_model
from .extensions import VisualizerProduct
from .ppt_service import VisualizerPptService, _validate_pptx_payload
from .templates import REPORT_TEMPLATES, template_model

STATIC_ROUTE = '/_cui_visualizer'
ASSET_ROOT = Path(__file__).with_name('assets')
EDITOR_FRAGMENT = ASSET_ROOT / 'integrated_editor.html'

def _asset_build_id() -> str:
    digest = hashlib.sha256()
    for name in ('integrated_editor.css', 'integrated_editor.html', 'integrated_editor.mjs', 'element_renderer.mjs'):
        digest.update((ASSET_ROOT / name).read_bytes())
    return digest.hexdigest()[:16]

ASSET_BUILD = _asset_build_id()
REPORT_STATE = StateKey[str]('visualizer.report_id', StateNamespace.WORKSPACE, validator=lambda value: isinstance(value, str) and bool(value.strip()))
PPT_MAX_BYTES = 100 * 1024 * 1024
REPORT_MAX_BYTES = 25 * 1024 * 1024

VISUALIZER_NAVIGATION = NavigationModel((
    NavSection('products', 'Products', (
        NavItem('visualizer', 'Visualizer', '/visualizer', icon='chart-line'),
    )),
))


def _ui():
    try:
        from nicegui import ui
    except ImportError as exc:  # pragma: no cover - target runtime only
        raise RuntimeError('NiceGUI 3.15.0 is required to render Visualizer.') from exc
    return ui


def _wire_value(value: Any) -> Any:
    """JSON-safe typed transport; null/zero and date/decimal identity remain explicit."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, datetime):
        return {'$type': 'datetime', 'value': value.isoformat()}
    if isinstance(value, date):
        return {'$type': 'date', 'value': value.isoformat()}
    if isinstance(value, Decimal):
        return {'$type': 'decimal', 'value': str(value)}
    if isinstance(value, Mapping):
        return {str(key): _wire_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_wire_value(item) for item in value]
    return {'$type': type(value).__name__, 'value': repr(value)}


def _js_literal(value: Any) -> str:
    # Escaping < prevents a report title/value from terminating an inline script tag.
    return json.dumps(_wire_value(value), ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')


async def _read_upload(event: Any, *, max_bytes: int) -> tuple[str, bytes]:
    """Support NiceGUI 3.15 upload event shapes without depending on legacy APIs."""
    name = str(getattr(event, 'name', '') or getattr(getattr(event, 'file', None), 'name', '') or 'upload')
    source = getattr(event, 'file', None) or getattr(event, 'content', None)
    if source is None:
        raise VisualizerContractError('upload payload is unavailable')
    read = getattr(source, 'read', None)
    if not callable(read):
        raise VisualizerContractError('upload payload is unreadable')
    value = read()
    if inspect.isawaitable(value):
        value = await value
    if not isinstance(value, (bytes, bytearray)):
        raise VisualizerContractError('upload payload did not produce bytes')
    content = bytes(value)
    if len(content) > max_bytes:
        raise VisualizerContractError(f'upload exceeds {max_bytes // (1024 * 1024)} MB limit')
    return name, content


def _response(type_: str, payload: Mapping[str, Any]) -> dict[str, Any]:
    return {'bridge_version': 1, 'type': type_, 'payload': dict(payload)}


def _record_payload(product: VisualizerProduct, report_id: str) -> dict[str, Any]:
    record = product.repository.get(report_id)
    return product.bridge._record_payload(record)  # governed serializer used by every bootstrap/recovery response


def _register_static_routes(app: Any) -> None:
    """Register only the static trees needed by the retained editor.

    NiceGUI 3.15.0 names the keyword ``follow_symlink`` (singular). Keeping
    this helper isolated makes the pinned runtime contract directly testable without
    importing NiceGUI in the source-only test environment.
    """
    app.add_static_files(f'{STATIC_ROUTE}/assets', str(ASSET_ROOT), follow_symlink=False, max_cache_age=0)
    app.add_static_files(
        f'{STATIC_ROUTE}/vendor/production_core',
        str(Path(__file__).with_name('vendor') / 'production_core'),
        follow_symlink=False,
        max_cache_age=3600,
    )




def _editor_mount_script(mount_id: str, fragment: str) -> str:
    """Install the trusted retained editor into a NiceGUI-owned mount node.

    The retained editor is intentionally browser-owned after initial insertion.  We
    avoid relying on ``ui.html`` as the editor's lifecycle boundary because Vue can
    legitimately reconcile that component independently of the retained DOM.  The
    mount node itself remains NiceGUI-owned; this tiny bootstrap installs the frozen
    fragment once the node exists and restores it if that direct child is removed.
    """
    mount_literal = _js_literal(mount_id)
    fragment_literal = _js_literal(fragment)
    return f"""<script>(()=>{{
const mountId={mount_literal};
const markup={fragment_literal};
let host=null;
let hostObserver=null;
let parentObserver=null;
let frame=0;
const installRoot=()=>{{
  if(!host||!host.isConnected)return false;
  let root=host.querySelector(':scope > #visualizer-editor-root');
  if(!root){{
    host.replaceChildren();
    const template=document.createElement('template');
    template.innerHTML=markup.trim();
    host.append(template.content.cloneNode(true));
    root=host.querySelector(':scope > #visualizer-editor-root');
  }}
  if(root){{
    host.dataset.visualizerMount='mounted';
    host.setAttribute('aria-busy','false');
    return true;
  }}
  host.dataset.visualizerMount='failed';
  host.setAttribute('aria-busy','false');
  return false;
}};
const bindHost=()=>{{
  const next=document.getElementById(mountId);
  if(!next){{
    if(frame<600){{frame+=1;requestAnimationFrame(bindHost);}}
    return;
  }}
  if(next===host){{installRoot();return;}}
  hostObserver?.disconnect();
  parentObserver?.disconnect();
  host=next;
  installRoot();
  hostObserver=new MutationObserver(()=>{{
    if(!host.querySelector(':scope > #visualizer-editor-root'))installRoot();
  }});
  hostObserver.observe(host,{{childList:true}});
  if(host.parentElement){{
    parentObserver=new MutationObserver(()=>{{
      const current=document.getElementById(mountId);
      if(current!==host)bindHost();
    }});
    parentObserver.observe(host.parentElement,{{childList:true}});
  }}
}};
bindHost();
}})();</script>"""

def register_visualizer_page(runtime: ApplicationRuntime, product: VisualizerProduct) -> None:
    """Register the opt-in /visualizer product workspace inside Company UI's AppShell."""
    from nicegui import app, ui

    # Serve only the browser assets and frozen Visualizer authority required at runtime.
    # Never expose the Python product source/repository directory as a static tree.
    _register_static_routes(app)

    @ui.page('/visualizer')
    async def visualizer_page(report: str = 'default', new: str | None = None) -> None:
        requested = 'default' if new else (report or 'default')
        bootstrap = product.bridge.bootstrap(requested).to_dict()['payload']
        report_id = str(bootstrap['report_id'])

        workspace_id = f'visualizer-{uuid.uuid4().hex}'
        workspace = runtime.open_workspace(workspace_id)
        workspace.state.set(REPORT_STATE, report_id, source='visualizer.route')

        async def close_workspace() -> None:
            await runtime.close_workspace(workspace_id)

        client = getattr(getattr(ui, 'context', None), 'client', None)
        on_delete = getattr(client, 'on_delete', None)
        if callable(on_delete):
            on_delete(close_workspace)

        ppt_template: dict[str, Any] = {'name': None, 'content': None}
        ppt_service = VisualizerPptService()

        # Bootstrap must precede the integration module. The module waits for the
        # NiceGUI-rendered product root, so there is no race with retained DOM setup.
        ui.add_head_html(
            f'<link rel="stylesheet" href="{STATIC_ROUTE}/assets/integrated_editor.css?v={ASSET_BUILD}">'
            f'<script>window.__CUI_VISUALIZER_BOOTSTRAP__={_js_literal(bootstrap)};window.__CUI_VISUALIZER_ASSET_BUILD__={_js_literal(ASSET_BUILD)};</script>',
            shared=False,
        )

        async def send(response: Mapping[str, Any]) -> None:
            await ui.run_javascript(f'window.CompanyUIVisualizerBridge?.receive({_js_literal(response)});')

        async def handle_semantic(event: Any) -> None:
            try:
                detail = getattr(event, 'args', None)
                if isinstance(detail, Mapping):
                    detail = detail.get('detail', detail)
                if isinstance(detail, list) and detail:
                    detail = detail[0]
                if not isinstance(detail, str):
                    detail = getattr(event, 'detail', detail)
                message = json.loads(detail) if isinstance(detail, str) else detail
                if not isinstance(message, Mapping):
                    raise VisualizerContractError('semantic bridge event must contain an object')
                kind = message.get('type')
                payload = message.get('payload', {})
                current_report_id = workspace.state.get(REPORT_STATE)

                if kind in {'report.opened', 'report.commit', 'report.save_requested', 'report.save_as_requested', 'diagnostic.event'}:
                    response = product.bridge.handle(message)
                    if response is not None:
                        result = response.to_dict()
                        if response.type == 'report.bootstrap':
                            workspace.state.set(REPORT_STATE, str(result['payload']['report_id']), source='visualizer.bridge')
                        await send(result)
                    return

                if kind == 'dataset.bind_requested':
                    if not isinstance(payload, Mapping):
                        raise VisualizerContractError('dataset binding payload must be an object')
                    dataset_key = str(payload.get('dataset_key', ''))
                    if dataset_key not in runtime.data.datasets:
                        await send(_response('application.notification', {'level': 'warning', 'message': f'Dataset not registered: {dataset_key}'}))
                        return
                    session_id = f'dataset:{dataset_key}'
                    session = workspace.data_sessions.get(session_id)
                    if session is None:
                        session = workspace.open_data_session(dataset_key, session_id=session_id)
                    mode = str(payload.get('mode', 'rows'))
                    provenance = {'workspace_id': workspace.workspace_id, 'report_id': current_report_id, 'source': 'company_ui.data_engine'}
                    if mode == 'chart_xy':
                        envelope = product.data_adapter.chart_xy(session, x=str(payload['x']), y=str(payload['y']), provenance=provenance)
                    elif mode == 'timeline':
                        envelope = product.data_adapter.timeline(session, sequence_field=str(payload['sequence_field']), date_field=(str(payload['date_field']) if payload.get('date_field') else None), provenance=provenance)
                    else:
                        envelope = product.data_adapter.rows(session, offset=int(payload.get('offset', 0)), limit=(int(payload['limit']) if payload.get('limit') is not None else None), provenance=provenance)
                    await send(_response('dataset.binding_result', _wire_value(envelope.to_dict())))
                    return

                if kind == 'preset.preferences_requested':
                    preferences = runtime.services.preferences
                    presets = []
                    if preferences is not None:
                        snapshot = preferences.load()
                        raw = snapshot.filter_views.get('visualizer.personal_presets', {})
                        if isinstance(raw, Mapping) and isinstance(raw.get('presets'), list):
                            presets = raw['presets']
                    await send(_response('preset.preferences_result', {'presets': presets}))
                    return

                if kind == 'preset.preferences_save_requested':
                    preferences = runtime.services.preferences
                    if preferences is None:
                        await send(_response('application.notification', {'level': 'warning', 'message': 'Personal presets are unavailable in this runtime.'}))
                        return
                    raw = payload.get('presets') if isinstance(payload, Mapping) else None
                    if not isinstance(raw, list):
                        raise VisualizerContractError('preset preferences require presets array')
                    presets = []
                    for entry in raw[:50]:
                        if not isinstance(entry, Mapping):
                            continue
                        name = str(entry.get('name', '')).strip()[:80]
                        model_value = entry.get('model')
                        if not name or not isinstance(model_value, Mapping):
                            continue
                        presets.append({'id': str(entry.get('id') or uuid.uuid4().hex), 'name': name, 'model': canonical_model(model_value)})
                    preferences.save_filter_view('visualizer.personal_presets', {'presets': presets})
                    await send(_response('preset.preferences_result', {'presets': presets}))
                    return

                if kind == 'ppt.export_requested':
                    if not ppt_template['content']:
                        await send(_response('application.notification', {'level': 'warning', 'message': 'Upload the existing work PPTX first; the report will compile into its usable middle region.'}))
                        return
                    if not isinstance(payload, Mapping):
                        raise VisualizerContractError('PPT export payload must be an object')
                    record = product.repository.get(current_report_id)
                    result = ppt_service.export(
                        ppt_template['content'],
                        record,
                        payload.get('normalized_plan', {}),
                        slide_index=int(payload.get('slide_index', 0)),
                        explicit_region=payload.get('explicit_region'),
                    )
                    filename = f'{record.report_id}_visualizer_editable.pptx'
                    runtime.services.downloads.download(filename, result.content, media_type='application/vnd.openxmlformats-officedocument.presentationml.presentation')
                    await send(_response('application.notification', {'level': 'success', 'message': f'Editable PowerPoint compiled · {result.exported_items} objects'}))
                    return

                if kind == 'asset.import_requested':
                    await send(_response('application.notification', {'level': 'info', 'message': 'Use the governed report/PPT upload controls above the editor.'}))
                    return

                raise VisualizerContractError(f'unsupported semantic bridge message: {kind!r}')
            except Exception as exc:
                runtime.services.errors.capture(exc, context={'product': 'visualizer', 'workspace_id': workspace_id})
                await send(_response('application.notification', {'level': 'error', 'message': f'Visualizer integration error: {type(exc).__name__}: {exc}'}))

        def display_title(value: str) -> str:
            cleaned = (value or '').strip()
            if cleaned in {'Visualizer report', 'Untitled Visualizer report'}:
                return 'Untitled report'
            return cleaned or 'Untitled report'

        def report_options() -> dict[str, str]:
            records = product.repository.list()
            counts: dict[str, int] = {}
            for item in records:
                key = display_title(item.title)
                counts[key] = counts.get(key, 0) + 1
            options: dict[str, str] = {}
            for item in records:
                title = display_title(item.title)
                if counts.get(title, 0) > 1:
                    blank = ' · blank' if not item.model.get('items') else ''
                    title = f'{title}{blank} · {item.report_id[-6:]}'
                options[item.report_id] = title
            return options

        def update_report_controls(record) -> None:
            report_select.options = report_options()
            report_select.value = record.report_id
            report_select.update()
            report_title.value = display_title(record.title)
            report_title.update()

        async def activate_record(record, *, source: str, notice: str | None = None) -> None:
            workspace.state.set(REPORT_STATE, record.report_id, source=source)
            await send(_response('report.bootstrap', product.bridge._record_payload(record)))
            update_report_controls(record)
            if notice:
                runtime.services.notifications.success(notice)

        async def upload_ppt(event: Any) -> None:
            try:
                name, content = await _read_upload(event, max_bytes=PPT_MAX_BYTES)
                _validate_pptx_payload(content)
                from pptx import Presentation
                Presentation(io.BytesIO(content))
                ppt_template['name'] = name
                ppt_template['content'] = content
                ppt_status.set_text(f'Template ready · {name}')
                runtime.services.notifications.success('PowerPoint template loaded for editable export')
            except Exception as exc:
                runtime.services.notifications.error(f'PowerPoint rejected: {exc}')

        async def upload_report(event: Any) -> None:
            try:
                name, content = await _read_upload(event, max_bytes=REPORT_MAX_BYTES)
                payload = json.loads(content.decode('utf-8'))
                model_source = payload.get('model', payload) if isinstance(payload, Mapping) else payload
                model_value = canonical_model(model_source if isinstance(model_source, Mapping) else {})
                imported_id = f'import-{uuid.uuid4().hex[:12]}'
                record = product.repository.create(imported_id, title=Path(name).stem or 'Imported report', model=model_value, metadata={'imported_from': name})
                await activate_record(record, source='visualizer.import', notice='Visualizer report imported as a new revision-safe report')
            except Exception as exc:
                runtime.services.notifications.error(f'Report import rejected: {exc}')

        async def create_report_from(template_id: str) -> None:
            try:
                model_value = template_model(template_id)
                template = REPORT_TEMPLATES.get(template_id)
                title = template['name'] if template else 'Untitled report'
                report_id_new = f'report-{uuid.uuid4().hex[:10]}'
                record = product.repository.create(report_id_new, title=title, model=model_value, metadata={'template_id': template_id})
                new_report_dialog.close()
                await activate_record(record, source='visualizer.new', notice=f'{title} created')
            except Exception as exc:
                runtime.services.notifications.error(f'Unable to create report: {exc}')

        async def rename_report(event: Any) -> None:
            try:
                current = product.repository.get(workspace.state.get(REPORT_STATE))
                cleaned = str(getattr(event, 'value', '') or '').strip() or 'Untitled report'
                if cleaned == current.title:
                    return
                updated = product.repository.rename(current.report_id, cleaned, expected_revision=current.revision)
                await activate_record(updated, source='visualizer.rename')
            except Exception as exc:
                runtime.services.notifications.error(f'Rename failed: {exc}')
                current = product.repository.get(workspace.state.get(REPORT_STATE))
                report_title.value = display_title(current.title)
                report_title.update()

        async def delete_current_report() -> None:
            try:
                current = product.repository.get(workspace.state.get(REPORT_STATE))
                product.repository.delete_if_revision(current.report_id, current.revision)
                remaining = product.repository.list()
                if remaining:
                    next_record = remaining[0]
                else:
                    next_record = product.repository.create(f'report-{uuid.uuid4().hex[:10]}', title='Untitled report', model=template_model('blank'), metadata={'template_id':'blank'})
                delete_report_dialog.close()
                await activate_record(next_record, source='visualizer.delete', notice='Report deleted')
            except Exception as exc:
                runtime.services.notifications.error(f'Delete failed: {exc}')

        async def clean_empty_reports() -> None:
            try:
                current_id = workspace.state.get(REPORT_STATE)
                removed = 0
                for record in list(product.repository.list()):
                    if record.report_id == current_id:
                        continue
                    if display_title(record.title) == 'Untitled report' and product.repository.is_blank(record.report_id):
                        product.repository.delete_if_revision(record.report_id, record.revision)
                        removed += 1
                clean_empty_dialog.close()
                current = product.repository.get(current_id)
                update_report_controls(current)
                runtime.services.notifications.success(f'Removed {removed} empty Untitled report{"s" if removed != 1 else ""}')
            except Exception as exc:
                runtime.services.notifications.error(f'Cleanup failed: {exc}')

        async def select_report(event: Any) -> None:
            value = str(getattr(event, 'value', '') or '')
            if not value or value == workspace.state.get(REPORT_STATE):
                return
            await activate_record(product.repository.get(value), source='visualizer.open')

        with AppShell(
            'Company UI',
            VISUALIZER_NAVIGATION,
            active_route='/visualizer',
            environment=os.getenv('COMPANY_UI_ENVIRONMENT', 'local'),
            subtitle='Visualizer 97.1',
            owner='Company UI Platform',
        ):
            current_record = product.repository.get(report_id)

            with ui.dialog() as new_report_dialog, ui.card().classes('cui-visualizer-dialog-card'):
                ui.label('New report').classes('cui-visualizer-dialog-title')
                ui.label('Start blank or use a governed starting template. Everything remains editable.').classes('cui-field-description')
                with ui.column().classes('cui-visualizer-template-list'):
                    ui.button('Blank canvas', on_click=lambda: create_report_from('blank')).props('flat no-caps').classes('cui-visualizer-template-option')
                    for template_id, template in REPORT_TEMPLATES.items():
                        async def choose_template(_event=None, template_id=template_id):
                            await create_report_from(template_id)
                        with ui.button(on_click=choose_template).props('flat no-caps').classes('cui-visualizer-template-option'):
                            ui.label(template['name']).classes('cui-visualizer-template-name')
                            ui.label(template['description']).classes('cui-field-description')
                ui.button('Cancel', on_click=new_report_dialog.close).props('flat no-caps')

            with ui.dialog() as delete_report_dialog, ui.card().classes('cui-visualizer-dialog-card'):
                ui.label('Delete this report?').classes('cui-visualizer-dialog-title')
                ui.label('This permanently removes the selected report from Visualizer persistence.').classes('cui-field-description')
                with ui.row().classes('justify-end gap-2'):
                    ui.button('Cancel', on_click=delete_report_dialog.close).props('flat no-caps')
                    ui.button('Delete report', on_click=delete_current_report).props('unelevated no-caps color=negative')

            with ui.dialog() as clean_empty_dialog, ui.card().classes('cui-visualizer-dialog-card'):
                ui.label('Remove other empty Untitled reports?').classes('cui-visualizer-dialog-title')
                ui.label('The report currently open is always preserved.').classes('cui-field-description')
                with ui.row().classes('justify-end gap-2'):
                    ui.button('Cancel', on_click=clean_empty_dialog.close).props('flat no-caps')
                    ui.button('Remove empty reports', on_click=clean_empty_reports).props('unelevated no-caps')

            with ui.column().classes('cui-page cui-page--full cui-visualizer-page'):
                with ui.element('header').classes('cui-page-header cui-visualizer-page-header'):
                    with ui.element('div').classes('cui-page-header__copy'):
                        ui.label('Visualizer').classes('cui-page-title')
                        ui.label('Build, arrange, validate, and export the current report.').classes('cui-page-description')
                with ui.element('section').classes('cui-visualizer-report-bar').props('aria-label="Report controls"'):
                    with ui.row().classes('items-end gap-2 w-full'):
                        report_title = ui.input(
                            label='Report title', value=display_title(current_record.title), on_change=rename_report,
                        ).props('outlined dense').classes('cui-field-control cui-visualizer-report-title')
                        report_select = ui.select(
                            options=report_options(), value=report_id, label='Open report', on_change=select_report,
                        ).props('outlined dense options-dense').classes('cui-field-control cui-visualizer-report-select')
                        ui.button('New report', on_click=new_report_dialog.open).props('unelevated no-caps')
                        ui.button('Delete', on_click=delete_report_dialog.open).props('flat no-caps')
                        ui.button('Clean empty', on_click=clean_empty_dialog.open).props('flat no-caps').tooltip('Remove other empty Untitled reports')

                fragment = EDITOR_FRAGMENT.read_text(encoding='utf-8')
                mount_id = f'visualizer-editor-mount-{workspace_id}'
                host = (ui.element('div').classes('cui-visualizer-host').props(f'id="{mount_id}" data-visualizer-mount="pending" aria-busy="true" aria-label="Visualizer report editor"'))
                host.on('visualizer_bridge', handle_semantic, args=['detail'])

                with ui.element('details').classes('cui-visualizer-import-details'):
                    ui.html('Import / PowerPoint template', tag='summary').classes('cui-visualizer-import-summary')
                    with ui.row().classes('w-full items-start gap-3'):
                        FileUpload(label='Existing work PPTX', accept=('.pptx',), max_file_size_mb=100, on_upload=upload_ppt)
                        FileUpload(label='Visualizer report JSON', accept=('.json',), max_file_size_mb=25, on_upload=upload_report)
                        with ui.element('div').classes('cui-visualizer-template-status'):
                            ppt_status = ui.label('PowerPoint template · not loaded').classes('cui-field-description')

        # Install the retained DOM directly into the NiceGUI-owned mount and only then
        # load the editor module.  This keeps the editor lifecycle browser-side while
        # avoiding a Vue-managed ui.html wrapper as the retained-DOM authority.
        ui.add_body_html(_editor_mount_script(mount_id, fragment), shared=False)
        ui.add_body_html(
            f'<script type="module" src="{STATIC_ROUTE}/assets/integrated_editor.mjs?v={ASSET_BUILD}"></script>',
            shared=False,
        )

        # Product-only host CSS; Company UI's global constitution remains untouched.
        ui.add_css('''
.cui-visualizer-page{width:100%;max-width:none!important;gap:var(--cui-space-3)!important;padding:clamp(var(--cui-space-3),1.3vw,var(--cui-space-5))!important;}
.cui-visualizer-page-header{padding-bottom:var(--cui-space-3)!important;}
.cui-visualizer-report-bar{width:100%;padding:var(--cui-space-3);border:1px solid var(--cui-border-subtle);border-radius:var(--cui-radius-surface);background:var(--cui-surface-secondary);}
.cui-visualizer-report-title{min-width:min(280px,100%);flex:1 1 280px;}
.cui-visualizer-report-select{min-width:min(320px,100%);flex:1 1 320px;}
.cui-visualizer-dialog-card{width:min(620px,calc(100vw - var(--cui-space-6)));max-width:100%;padding:var(--cui-space-5);gap:var(--cui-space-3);}
.cui-visualizer-dialog-title{font-size:var(--cui-type-title-size);line-height:var(--cui-type-title-line);font-weight:var(--cui-font-weight-700);color:var(--cui-text-primary);}
.cui-visualizer-template-list{width:100%;gap:var(--cui-space-2);}
.cui-visualizer-template-option{width:100%;justify-content:flex-start!important;text-align:left!important;border:1px solid var(--cui-border-subtle)!important;border-radius:var(--cui-radius-control)!important;padding:var(--cui-space-3)!important;}
.cui-visualizer-template-option .q-btn__content{width:100%;align-items:flex-start!important;}
.cui-visualizer-template-name{font-size:var(--cui-type-label-size);font-weight:var(--cui-font-weight-650);color:var(--cui-text-primary);}
.cui-visualizer-import-details{width:100%;border:1px solid var(--cui-border-subtle);border-radius:var(--cui-radius-surface);background:var(--cui-surface);overflow:hidden;}
.cui-visualizer-import-summary{cursor:pointer;padding:var(--cui-space-3);font-size:var(--cui-type-label-size);font-weight:var(--cui-font-weight-650);color:var(--cui-text-secondary);}
.cui-visualizer-import-details[open]>.cui-visualizer-import-summary{border-bottom:1px solid var(--cui-border-subtle);}
.cui-visualizer-import-details>div{padding:var(--cui-space-3);}
.cui-visualizer-import-details .cui-upload-shell{flex:1;min-width:min(320px,100%);}
.cui-visualizer-template-status{min-width:240px;padding-block:var(--cui-space-2);}
.cui-visualizer-host{position:relative;width:100%;min-width:0;min-height:660px;}
.cui-visualizer-host[data-visualizer-mount="pending"]::before,.cui-visualizer-host[data-visualizer-mount="failed"]::before{content:"Loading Visualizer editor…";position:absolute;inset:0;display:grid;place-items:center;min-height:660px;border:1px solid var(--cui-border-subtle);border-radius:var(--cui-radius-surface);background:var(--cui-surface-secondary);color:var(--cui-text-secondary);font-size:var(--cui-type-label-size);z-index:1;}
.cui-visualizer-host[data-visualizer-mount="failed"]::before{content:"Visualizer editor failed to mount. Reload the page or contact the application owner.";color:var(--cui-danger);}
.cui-visualizer-host[data-visualizer-mount="mounted"]::before{display:none;}
@media(max-width:760px){.cui-visualizer-page{padding:var(--cui-space-2)!important}.cui-visualizer-report-bar .q-field{min-width:100%!important;}.cui-visualizer-template-status{min-width:100%;}.cui-visualizer-import-details>div{flex-direction:column;}}
''')


__all__ = ['ASSET_ROOT', 'REPORT_STATE', 'STATIC_ROUTE', 'VISUALIZER_NAVIGATION', 'register_visualizer_page']
