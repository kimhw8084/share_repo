# EPHI v0.7.0 — Engineer Advisory Read Model & Episode API

## Objective

Expose the qualified EPHI analytical state to engineers without creating a second decision engine in the UI/API layer.

The product-layer invariant is:

> Advisory code may select, rank, format, cache, and audit structured domain evidence. It may not recompute detector, reference, peer, metrology-engine, or quality-model truth.

An automated dependency-boundary test enforces this invariant.

## Implemented contracts

### EpisodeView

`EpisodeView` is the primary engineer read model and contains:

- header: episode/asset/context/state;
- semantic technical severity and independent operational priority;
- technical confidence and assessment maturity;
- estimated onset and trend;
- `why_now` explanation;
- dependency-aware top support;
- top contradictions plus explicit contradiction summary;
- confidence limitations;
- ranked competing hypotheses;
- self-reference and peer-comparison summary;
- metrology/measurement-system summary when applicable;
- quality-stage/maturity summaries;
- compact exposure summary;
- recommended verification;
- timeline;
- analytical revision history;
- human workflow state.

The read model is versioned by both `episode_version` and `presentation_policy_version`.

### Evidence drill-down

The episode card shows only the strongest independent dependency groups. The `/evidence` drill-down returns all structured evidence for the current leading hypothesis, preserving dependency groups and evidence polarity so engineers/analysts can inspect correlated evidence explicitly.

### Analytical history

Each authoritative source update appends an `AnalyticalRevision` with severity, confidence, maturity, novelty, and leading hypothesis. A new conclusion therefore does not erase the earlier conclusion.

Human workflow mutations are tracked separately in the workflow audit log.

### Workflow

Supported workflow states:

`NEW -> ACKNOWLEDGED -> INVESTIGATING -> ACTION_TAKEN -> MONITORING_RECOVERY -> RESOLVED`

with terminal alternatives `BENIGN`, `DATA_ISSUE`, `DUPLICATE`, and `UNRESOLVED`.

Structured closure feedback preserves:

- behavior confirmed: yes/no/uncertain;
- quality affected: yes/no/unknown;
- likely category;
- action taken;
- whether action resolved the state;
- confidence;
- optional note.

Every mutation is audit-recorded with actor, timestamp, previous/current state, and reason.

### Missed-event capture

`MissedEventReport` provides a direct path for engineers to record a real manufacturing event that EPHI did not surface. This supports honest future recall/failure-layer analysis.

### Material exposure

The v0.7 contract supports exact material records separately from the compact episode payload. It distinguishes definite past, possible past, committed, and future-preventable exposure classes and includes preventability state.

The portable build does **not** invent WIP/material exposure. Real items must come from the future/internal exposure subsystem.

## FastAPI v1 surface

The frozen v0.7 OpenAPI surface has 13 paths:

- `/healthz`
- `/version`
- `/v1/attention`
- `/v1/episodes`
- `/v1/episodes/{episode_id}`
- `/v1/episodes/{episode_id}/evidence`
- `/v1/episodes/{episode_id}/material-exposure`
- `/v1/episodes/{episode_id}/notification`
- `/v1/episodes/{episode_id}/workflow`
- `/v1/episodes/{episode_id}/close`
- `/v1/episodes/{episode_id}/closure-feedback`
- `/v1/episodes/{episode_id}/audit`
- `/v1/missed-events`

Unknown episodes return 404; invalid workflow transitions return 409; malformed request contracts return FastAPI/Pydantic validation errors.

## Runtime shape

`AdvisorySourceRepository` isolates the API/read model from storage. The portable reference includes `InMemoryAdvisorySourceRepository`; internal production should implement the protocol over approved materialized episode state.

Read models are cached by:

`(episode_id, episode_version, presentation_policy_version)`

and invalidated on analytical or workflow version changes.

Workflow, audit, closure feedback, missed-event reports, and version metadata can be checkpointed through the existing `StateStore` contract. Authoritative analytical source objects remain owned by the analytical/materialization layer and are reloaded through `AdvisorySourceRepository`.

## Presentation policy

Display-only thresholds are external and versioned at `configs/advisory/presentation.yaml`. They control only:

- top-K support/contradictions;
- semantic evidence-band display thresholds;
- preferred confidence display floor.

They cannot change analytical severity, hypothesis scores, evidence polarity, or quality conclusions.

## Performance reference

The advisory benchmark measures local Python/Pydantic read-model work only. It excludes network, auth, company storage, and browser rendering.

See `ADVISORY_BENCHMARK_V070.json` for exact results.

## Explicit non-goals in v0.7

- no frontend-framework commitment;
- no internal RBAC/identity assumptions;
- no direct company-message API integration;
- no automatic tool hold/routing/disposition;
- no new detector/ML logic in the advisory layer;
- no invented WIP exposure;
- no synchronous deep RCA queries.

These boundaries are deliberate.
