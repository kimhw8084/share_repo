# Internal AutoPort Runbook

## 1. Configure OpenCode
Keep the work-environment Gemma model/provider configuration local. Do not hard-code the proprietary model endpoint in the repository. The committed `AGENTS.md`, `opencode.json`, `.opencode/agents/port.md`, and `.opencode/agents/review.md` provide repository behavior/permissions.

Use the `port` agent for normal database binding. Use the `core` agent only for an exceptional, justified generic-core change.

## 2. Start with a table hint
Example engineer input: `TB_FAB_METRO_HIST probably contains metrology results.`

Gemma should inspect metadata/partitions first, then bounded samples and aggregate statistics. Full-history scans are not acceptable for schema discovery.

## 3. Read the matching semantic requirement
Use `docs/data_requirements/` or:

```bash
ephi autopilot catalog
```

Do not equate similar column names with equivalent semantics.

## 4. Discover/rank candidates
With the internal inspector wired:

```bash
ephi autopilot discover \
  --dataset metrology \
  --hint TB_FAB_METRO_HIST \
  --inspector-module ephi_company.autopilot \
  --config <config>
```

Inspect the strongest candidate's required fields, confidence and review items.

## 5. Generate a binding

```bash
ephi autopilot candidate \
  --dataset metrology \
  --table <accepted-candidate> \
  --inspector-module ephi_company.autopilot \
  --config <config> \
  --partition-column <physical-partition-column> \
  --watermark-column <physical-watermark-column> \
  --output-binding company_bindings/metrology.yaml
```

For composite identities or coded semantics, Gemma may edit the generated SQL expression in `company_bindings/`; do not modify generic EPHI domain types.

## 6. Validate SQL contract

```bash
ephi autopilot validate-binding --binding company_bindings/metrology.yaml
```

Resolve all errors. Warnings are explicit qualification limitations; do not silently suppress them.

## 7. Repeat for available datasets
Prioritize executions + metrology, then FDC/signals, maintenance, quality, then WIP/genealogy/history as available. Missing optional datasets must become explicit unavailable capabilities, not fake normal data.

## 8. Synthesize configuration / bootstrap handoff

```bash
ephi autopilot bootstrap \
  --binding company_bindings/executions.yaml \
  --binding company_bindings/metrology.yaml \
  --output-config configs/company/generated.yaml
```

The report lists inferred capabilities, unavailable datasets, manual decisions, config hash and exact next port-bootstrap command.

## 9. Audit port changes

```bash
ephi autopilot change-audit \
  --changed-path company_bindings/executions.yaml \
  --changed-path company_bindings/metrology.yaml
```

Any generic-core change fails the normal portability gate and requires explicit architecture review.

## 10. Qualify
Run AutoPort qualification, port qualification, Data Reality, historical replay, then normal family/campaign qualification. AutoPort makes the system executable; production qualification still requires real internal evidence.
