# Internal Shadow Operations Port Checklist — v0.11.0

Use this checklist after the v0.10 scientific/business subsystems are mapped and before any engineer-facing advisory launch.

## 1. Runtime backend

- Implement an approved shared `StateStore` / durable queue backend for Kubernetes workers.
- Do not use the local SQLite reference store across multiple pods.
- Implement `ephi_company.app.create_app(config)` to wire company-backed API services and authorization.
- Implement `ephi_company.runtime.build_queue(role)`.
- Implement `ephi_company.runtime.build_handlers(role)`.
- Verify all job handlers are idempotent under at-least-once execution.
- Validate lease expiry/reclaim after forced pod termination.
- Validate retry classification for transient vs deterministic failure.

## 2. Runtime roles

- Map `API`, `INCREMENTAL_WORKER`, `BATCH_WORKER`, `REPLAY_WORKER`, and optional `GPU_WORKER` to approved PaaS/Kubernetes constructs.
- Replace all provisional CPU/memory values using measured workload geometry.
- Keep GPU replicas at zero unless a qualified challenger requires them.
- Ensure batch/replay pools cannot starve incremental scoring/API resources.

## 3. Bootstrap/backfill

- Build canonical history first.
- Materialize exposure before quality/RCA joins.
- Build references before behavioral replay.
- Build peers after reference/context qualification.
- Chunk history by restartable family/time ranges.
- Confirm live and recent-correction processing outrank historical backfill.
- Kill workers mid-chunk and verify checkpoint restart without duplication/loss.

## 4. Freshness/SLO policy

For the first family, replace the reference SLO values using actual manufacturing time-to-action requirements for:

- source freshness;
- canonical freshness;
- feature freshness;
- reference freshness;
- peer freshness;
- assessment freshness;
- WIP freshness;
- quality-model freshness;
- historical-index freshness;
- value-reconciliation freshness.

Confirm stale/unknown states are visible and do not masquerade as healthy equipment.

## 5. Operational controls

Wire control mutation only behind approved authorization.

Validate scoped controls for:

- notification delivery;
- family capability;
- specific detector;
- specific model;
- source quarantine.

Run an alert-storm drill: suppress notification delivery while preserving ingestion, scoring, evidence, episode state, and audit history.

## 6. Certification evidence

Create a real `FamilyQualificationManifest` for the target family. Do not use the shipped reference template as evidence.

Required before `OFFLINE_QUALIFIED`/`SHADOW` includes at minimum:

- Data Reality qualification;
- behavioral/metrology Golden Corpus qualification;
- runtime/scale qualification.

Capability-specific planes must be added for quality, exposure, RCA, and value functionality.

Store all manifests in the authoritative family registry; never overwrite earlier qualification history.

## 7. Champion/challenger shadow

- Pin one qualified champion release.
- Run challengers on identical live inputs.
- Confirm challenger output cannot affect engineer-visible production output.
- Persist comparison results.
- Review actionable disagreements, errors, latency, and case-level differences.
- Never auto-promote from aggregate metrics.

## 8. Engineer shadow review

Collect structured review from selected domain engineers:

- Would I want this event?
- Is the comparison population valid?
- Is the leading hypothesis reasonable?
- Is the recommended verification useful?
- If not useful, why?

Define family-specific shadow thresholds only after pilot review volume is sufficient. `SHADOW_QUALIFIED` requires this evidence.

## 9. Notification delivery

- Connect the internal messaging adapter downstream of `NotificationDeliveryGate`.
- Notification preview API may remain readable while delivery is suppressed.
- Verify duplicate notification prevention by episode version.
- Verify common-mode parent episodes do not produce child alert storms.

## 10. Rollback / release operations

- Generate immutable `ReleaseManifest` for every shadow/advisory release.
- Hash qualification and deployment artifacts.
- Record state-schema version.
- Test rollback before advisory launch.
- Reject destructive migrations without a separately qualified migration/rebuild plan.
- Preserve prior analytical/event history after rollback.

## 11. Security

- Inject credentials through approved secret management.
- Map roles/permissions to company identity.
- Keep control/certification/value mutation endpoints disabled until authorization is wired.
- Verify audit actor identity for operational changes.

## 12. Shadow exit criteria

Do not move to advisory merely because the deployment is stable. Require all of:

- required certification planes pass;
- operational freshness SLOs are met;
- false actionable burden is acceptable;
- missed-event review is active;
- engineer shadow gate passes;
- rollback tested;
- kill-switch drill passes;
- runtime resource cost is acceptable;
- no unresolved source/reference/peer/model-health blocker exists.
