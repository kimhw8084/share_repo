# Milestone 15 — v0.8.0 Exposure, WIP & Operational Priority

## Purpose

v0.8.0 replaces the advisory layer's exposure placeholders with an authoritative operational subsystem while preserving the permanent EPHI boundary:

`technical health -> harmfulness -> exposure/preventability -> operational priority`

Operational priority cannot modify technical severity, hypothesis support, detector state, reference state, or quality-model output.

## Implemented domain semantics

### Onset-aware historical exposure

`EpisodeOnsetWindow(low, best, high)` is the exposure boundary. Material processed before `low` is not included. Material processed within `[low, high)` is `POSSIBLE_PAST_EXPOSURE`; material with at least one exact suspect execution at/after `high` is `DEFINITE_PAST_EXPOSURE`.

Repeated/rework passes do not inflate material counts. All suspect execution IDs are preserved in `suspect_execution_ids`, while the material appears once in the historical exposure population.

### WIP route semantics

Future routing is deliberately not treated as a probability unless the source actually provides a reliable assignment:

- `CURRENTLY_COMMITTED_EXPOSURE`: committed to the suspect asset;
- `FUTURE_LIKELY_EXPOSURE`: current routing/dispatch state identifies the suspect asset;
- `FUTURE_POSSIBLE_EXPOSURE`: suspect asset is eligible but no reliable assignment exists;
- `FUTURE_PREVENTABLE_EXPOSURE`: likely suspect exposure plus at least one qualified, sufficiently compatible, sufficiently confident healthy alternative.

Qualification, availability, compatibility, and EPHI health are distinct dimensions. A statically qualified asset with an active EPHI health problem is not a preferred alternative.

### Preventability

Current states include `HIGH`, `MODERATE`, `UNKNOWN`, `ALREADY_COMMITTED`, and `NO_QUALIFIED_ALTERNATIVE`. The portable engine does not claim routing feasibility when capacity/availability data is absent.

### Quality maturity

Operational material summaries use explicit maturity semantics. `NOT_YET_MATURE` is pending and cannot be accidentally counted as mature.

## Operational priority

Priority is not a weighted health score. v0.8 computes three transparent operational decisions:

1. **Containment priority** — future/committed WIP and time-to-exposure;
2. **Disposition priority** — already-exposed material and quality/harmfulness maturity;
3. **RCA priority** — technical severity/confidence plus harmfulness evidence.

`overall_priority` is the most urgent of these three. The reference policy is versioned at `configs/priority/reference.yaml` and is explicitly not a fab constant.

A WIP refresh may change operational priority without creating an `AnalyticalRevision`. This is tested directly.

## Runtime / internal-port boundary

`ExposureSourceRepository` is the only source-facing semantic contract required by the operational engine. A company implementation provides:

- exact historical execution/material exposure for the suspect asset and onset window;
- current WIP route state for the affected operation;
- context-qualified alternative assets with availability and current EPHI health metadata.

`ExposureRefreshCoordinator` performs the point-in-time refresh using those semantics. No company table names appear in exposure/priority code.

The Data Reality Audit now distinguishes:

- `WIP` — basic current material visibility;
- `WIP_ROUTING` — usable future route/assignment state;
- `ALTERNATIVE_RESOURCE` — WIP plus asset-qualification semantics.

The new optional logical dataset `asset_qualification` keeps qualification mappings outside the analytical engine.

## API integration

Two typed read-only endpoints are added:

- `GET /v1/episodes/{episode_id}/exposure`
- `GET /v1/episodes/{episode_id}/priority`

`EpisodeView` consumes authoritative `ExposureSnapshot` and `OperationalPriorityAssessment` when present. The older advisory context remains only as a compatibility fallback for pre-v0.8 local fixtures.

## Qualification fixes discovered during implementation

1. Repeated suspect executions for one wafer initially inflated material exposure counts. Fixed by material-level grouping with complete execution-ID provenance.
2. A naïve maturity string check could classify `NOT_YET_MATURE` as mature. Replaced with explicit maturity-state semantics.
3. A qualified alternative was initially at risk of being considered usable without checking its current EPHI health. The preferred-alternative rule now requires qualified + available/known + healthy + confidence + compatibility.
4. WIP refresh and analytical revision had to be separated explicitly. Operational refresh increments presentation/source version but not analytical history.

## Reference qualification result

`EXPOSURE_PRIORITY_BENCHMARK_V080.json` verifies:

- repeated execution deduplication;
- pending quality maturity handling;
- healthy alternative enables preventability;
- unhealthy alternative is rejected;
- time-critical preventable WIP produces P1 containment under the reference policy;
- rerouting/removing WIP drops containment priority to P4;
- technical severity is unchanged;
- 10,000-material operational classification completes with count preservation.

The measured in-memory Python operational-layer throughput is recorded in the artifact. It excludes Big Data query time and must not be interpreted as end-to-end fab throughput.

## Deliberately not implemented

- automatic rerouting;
- automatic hold/disposition;
- dispatch optimization;
- learned routing probability;
- dollar/value conversion;
- Value Ledger;
- capacity optimization.

Those require separate data/governance qualification and must not contaminate technical health truth.
