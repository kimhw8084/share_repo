# Milestone 16 — v0.9.0 Historical Intelligence & RCA Substrate

## Purpose

v0.9.0 implements the Phase 8 historical-intelligence/RCA architecture without introducing an autonomous root-cause engine. Historical analogy and RCA are intentionally separate:

- **Historical similarity** asks whether EPHI has seen a comparable state before and what happened afterward.
- **RCA commonality** asks which upstream/manufacturing factors distinguish affected material from matched controls under temporal and health-state constraints.

A similar historical case can support an RCA candidate, but similarity never substitutes for causal evidence.

## Implemented historical intelligence

### Episode fingerprint

`EpisodeFingerprint` is versioned and decomposed into domains rather than one opaque vector:

- behavior;
- temporal phenotype/state;
- measurement-system evidence;
- quality association;
- optional spatial signature;
- optional maintenance age;
- optional route signature.

Exact asset identity is metadata and is not embedded as a dominant similarity feature.

### Versioned normalization and weights

`configs/history/reference.yaml` defines:

- domain weights;
- per-label numerical scales;
- strict context behavior;
- context bonus;
- distance scale.

This prevents heterogeneous quantities such as hours, technical severity, novelty, and quality effects from being compared in arbitrary raw units.

### Exact similarity baseline

`ExactSimilarityEngine` performs transparent exact retrieval before any ANN implementation is admitted.

Important invariants:

- unavailable fingerprint domains are omitted from the denominator, not treated as zero similarity;
- equipment-family/operation compatibility can be a hard search boundary;
- recipe/product matches can refine similarity without dominating it;
- results contain per-domain similarity/confidence;
- historical case confidence remains separate from similarity confidence;
- historical cases are filtered by `available_at <= as_of`;
- the current/source episode is excluded from its own historical search.

### Historical case epistemic state

`HistoricalCase` supports:

- `UNREVIEWED`;
- `PARTIALLY_STRUCTURED`;
- `ENGINEER_REVIEWED`;
- `ROOT_CAUSE_CONFIRMED`;
- `ROOT_CAUSE_DISPUTED`;
- `INSUFFICIENT_EVIDENCE`.

Root-cause confidence, data completeness, prior actions, action result, benign cases, and resolution summary are retained separately.

### Engineer analogue object

The API returns `HistoricalAnalogue`, not merely a nearest-neighbor score. It includes:

- similarity;
- similarity confidence;
- case confidence;
- domain decomposition;
- shared context;
- important differences;
- curation state;
- root-cause category/confidence;
- prior action/result;
- resolution summary;
- benign-case flag.

### Recurrence

`RecurrenceSummary` summarizes repeated high-similarity historical cases without promoting recurrence into causal truth. It can report dominant validated root-cause/action patterns, benign recurrence, and aggregate confidence.

## Implemented RCA substrate

### InvestigationSeed

`build_investigation_seed()` carries:

- episode and asset;
- manufacturing context;
- onset uncertainty;
- already/potentially affected material IDs;
- available control-set IDs;
- leading EPHI hypotheses;
- top historical case IDs;
- bounded route lookback.

Future WIP is not silently treated as already affected material.

### RouteToken

`RouteToken` is the compact investigation substrate:

- material;
- route sequence;
- operation;
- asset;
- event time;
- optional recipe;
- optional asset epoch;
- optional process regime;
- optional active EPHI health episode;
- health strength.

It emits reusable factor keys such as `ASSET`, `RECIPE`, `ASSET_RECIPE`, `ASSET_EPOCH`, `PROCESS_REGIME`, and `HEALTH_EPISODE`.

### Affected versus controls

RCA uses explicit `AffectedMaterial` and one or more `ControlPopulation` objects. It does not use simple set intersection as the root-cause algorithm.

For every candidate factor, `CommonalityEvidence` retains:

- affected prevalence;
- control prevalence;
- prevalence difference;
- relative risk;
- odds ratio;
- severity association;
- material-level temporal plausibility;
- EPHI health support;
- robustness across control definitions;
- evidence confidence.

### Temporal plausibility

A critical v0.9 correction: candidate exposure is compared against material outcome/failure time when available. Equipment episode onset is **not** used as a generic substitute for downstream material outcome time.

Therefore:

- exposures consistently preceding material outcomes can support a candidate;
- exposures consistently occurring after outcomes contradict a candidate;
- missing material-level ordering information produces `UNCERTAIN`, not fabricated contradiction.

### Health-aware factors

Exposure to an asset while it is in an active EPHI health episode is a first-class factor (`HEALTH_EPISODE:*`). This lets RCA distinguish static routing commonality from exposure to the resource specifically while it was abnormal.

### Multiple controls

`control_robustness` records whether enrichment remains positive across available control definitions. A factor that appears important under one control set but disappears under another is explicitly weakened.

### RCA candidate ranking

`RCACandidate` remains a ranked evidence object, not an automatic root-cause declaration. The ranking policy is externalized in `configs/rca/reference.yaml` and combines:

- prevalence separation;
- relative risk;
- temporal support;
- EPHI health support;
- control robustness;
- optional historical support;
- overall confidence.

Temporal contradiction applies a strong penalty and forces the `CONTRADICTED` band.

### Bounded interactions only

`rank_top_pairwise()` is candidate-triggered and bounded to top-K semantically eligible single factors. It reports a pair only if joint affected-vs-control separation exceeds the better individual factor. Existing composite factors such as `ASSET_RECIPE` are not paired again to manufacture tautological interactions.

There is no unrestricted higher-order combinatorial search.

## API additions

v0.9 adds typed read/investigation endpoints:

- `GET /v1/episodes/{episode_id}/historical-analogues`
- `GET /v1/episodes/{episode_id}/historical-recurrence`
- `GET /v1/episodes/{episode_id}/investigation-seed`
- `GET /v1/episodes/{episode_id}/rca-candidates`

These endpoints return bounded/materialized intelligence. They do not expose an unbounded genealogy traversal endpoint.

## Data Reality additions

The logical `historical_cases` dataset is now part of the portable contract. New capabilities are:

- `HISTORICAL_CASES`;
- `RCA_ROUTE_INDEX`.

Historical-case knowledge replay requires `available_at`. `RCA_ROUTE_INDEX` is treated as a derived/materialized capability based primarily on execution history, with genealogy as optional enrichment.

## Qualification result

Reference v0.9 benchmark:

- 2,001 historical cases searched;
- deliberately future/unavailable perfect analogue excluded;
- correct historical analogue ranked first;
- 100 affected materials;
- 200 controls across two policies;
- 505 route tokens;
- routine route factor prevalence difference = `0.0`;
- suspect asset prevalence difference ≈ `0.8017`;
- post-outcome highly enriched factor = `CONTRADICTS`;
- misleading historical support could not override temporal contradiction;
- top RCA candidate = active suspect EPHI health episode factor.

Sandbox reference runtime:

- exact analogue retrieval ≈ 39.6k cases/sec for 2,000 eligible cases;
- commonality ≈ 296k route tokens/sec for this compact in-memory benchmark.

These are Python in-memory reference measurements only. They exclude Big Data reads, materialization/index build time, network/storage latency, and full historical corpus geometry.

## Deliberately not implemented

v0.9 does **not** include:

- ANN/FAISS production dependency;
- learned similarity metric;
- graph database;
- graph neural network;
- route transformer;
- causal discovery over the fab;
- unrestricted pair/high-order interaction mining;
- autonomous root-cause declaration;
- LLM-only case extraction or technical reasoning.

ANN becomes a challenger only after exact retrieval semantics are validated on the internal historical corpus and exact-search cost is measured.

## Exit condition

v0.9 establishes the production contracts needed to bring internal historical cases and route/exposure indexes into EPHI while preserving scientific restraint. The next major build should focus on the Value Ledger/economic reconciliation or on internal port/shadow qualification, depending on where the repository is being executed.
