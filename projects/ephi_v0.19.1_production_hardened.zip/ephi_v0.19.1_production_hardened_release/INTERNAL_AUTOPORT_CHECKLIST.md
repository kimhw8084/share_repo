# Internal AutoPort Checklist

- [ ] OpenCode uses repository `AGENTS.md` and port agent.
- [ ] Company Gemma/provider endpoint is configured outside committed source.
- [ ] `ephi_company.autopilot.build_schema_inspector` uses approved bounded metadata/statistics APIs.
- [ ] Candidate table decisions use schema + values + cardinality + temporal behavior, not names alone.
- [ ] `event_time` and `available_at` are independently validated.
- [ ] Material identity is globally stable or uses an explicit composite expression.
- [ ] Applicable cross-dataset join coverage is checked before production qualification.
- [ ] SQL uses explicit projections and bounded partition predicates.
- [ ] Incremental watermark handles late/corrected data where applicable.
- [ ] Every binding passes `ephi autopilot validate-binding`.
- [ ] Generated config passes strict EPHI config validation.
- [ ] Missing datasets are represented as unavailable capabilities.
- [ ] Manual review items are genuine semantic/physics decisions only.
- [ ] `ephi autopilot change-audit` reports zero generic-core edits for normal porting.
- [ ] AutoPort qualification passes.
- [ ] Port/Data Reality qualification passes before historical replay/shadow.
