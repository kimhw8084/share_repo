# Milestone 13 — v0.6.0 Quality / Harmfulness Foundation

## Purpose

v0.6.0 implements the Phase 6 architectural boundary in executable form: behavioral abnormality remains separate from downstream manufacturing harmfulness. The quality layer answers whether equipment/process state adds predictive or observational information about a defined quality target beyond manufacturing context alone.

The release intentionally does **not** promote a universal quality score or production model. It establishes the contracts, leakage barriers, baselines, calibration, applicability, cohort evidence, and qualification framework required before internal historical data is used.

## Permanent separation

```text
Behavioral Health (unsupervised/semi-supervised)
        ↓
EquipmentStateVector
        ↓
Quality target-specific analysis
        ↓
M0: context only
M1: context + equipment state
        ↓
Predictive increment + exposed/control evidence
        ↓
QualityAssociationEvidence
```

A behavioral episode may be severe while quality evidence is unavailable or neutral. Conversely, an equipment-state feature can only be called quality-useful when M1 beats M0 on a chronological holdout.

## Implemented contracts

### Quality target

`QualityTargetDefinition` includes:

- immutable target ID/version;
- continuous or binary target type;
- outcome stage;
- prediction time;
- physical unit;
- harmful direction (`UPPER`, `LOWER`, `TWO_SIDED`);
- minimum practical effect;
- measurement-system sensitivity.

Targets load from versioned YAML and can be registered without embedding product/spec rules inside modeling code.

### Outcome maturity and censoring

Production semantics distinguish:

- `MATURE_AVAILABLE`;
- `NOT_YET_MATURE`;
- `HELD`;
- `SCRAPPED_BEFORE_OUTCOME`;
- `REROUTED`;
- `REWORKED`;
- `LOST_TO_FOLLOWUP`.

Only mature outcomes known by the historical knowledge cutoff become training labels. Intervention-censored outcomes are excluded, not converted into successful/healthy labels.

### No-lookahead construction

Every `QualityTrainingRow` carries:

```text
prediction_cutoff
equipment_known_at
outcome_available_at
outcome_maturity
```

The constructor requires:

```text
equipment_known_at <= prediction_cutoff
outcome_available_at > prediction_cutoff
```

A leakage attempt raises an error by default.

### Equipment state

The first quality feature vector is deliberately compact and evidence-level:

- behavioral novelty;
- health confidence;
- local-asset support;
- common-mode support;
- measurement-system support.

The quality model does not query raw Big Data or build its own detector features.

## M0 versus M1

For every target:

```text
M0 = f(manufacturing context)
M1 = f(manufacturing context, EPHI equipment state)
```

The current reference baselines are intentionally simple:

- continuous: one-hot context + Ridge regression;
- binary: one-hot context + Logistic Regression.

Context includes operation, recipe, product, and technology. These are baseline implementations, not a claim that Ridge/logistic will be the final internal champion.

## Chronological calibration

Data is split in time order into:

```text
TRAIN → CALIBRATION → TEST
```

There is no random final holdout.

Binary models use a Platt calibrator fitted only on the calibration block. Continuous M1 models use the calibration block to estimate an absolute-residual prediction interval. Final reported metrics come from the later untouched test block.

## Applicability / OOD contract

Every prediction records whether:

- exact context was represented in training;
- product was represented;
- recipe was represented.

Unseen product/recipe lowers applicability and model confidence rather than allowing confident silent extrapolation.

## Exposed-vs-control evidence

The first cohort implementation performs exact-context, nearest-time control matching. It reports:

- exposed and control counts;
- exposed/control means;
- adjusted effect;
- standard error;
- control robustness;
- sampling confidence;
- measurement integrity;
- association confidence;
- contradictions.

The output metadata explicitly records `causal_claim: false`. Route/genealogy/same-lot matching will be added when internal canonical material history is available.

## Harmful direction

The same numerical shift can mean different things for different targets.

For an `UPPER`-harm target, an exposed cohort moving materially lower is classified as `CONTRADICTED`, not as harmful merely because the absolute difference is large.

## Measurement-system confidence

For process-quality outcomes that depend on metrology, low measurement-system integrity caps quality-attribution confidence and can downgrade strong support.

For a target whose stage is explicitly `MEASUREMENT_SYSTEM`, the integrity field remains visible but is not used circularly to invalidate the target; qualifying measurement-system quality evidence supports the `METROLOGY_SYSTEM_SHIFT` hypothesis.

## Sampling selection diagnostic

`diagnose_sampling_bias()` estimates whether measurement selection is strongly predictable from manufacturing context or current health state. A high diagnostic AUC is an explicit warning that sampled outcomes may not represent the population.

The implementation deliberately **does not** perform inverse-probability weighting automatically. IPW is only scientifically acceptable later when overlap and ignorability assumptions are supportable.

## Model artifact safety

Quality model artifacts include:

- target ID/version;
- target type;
- calibration method;
- uncertainty method;
- equipment-state usefulness decision;
- fixed feature compatibility contract;
- model SHA-256.

The binary model file is never considered sufficient identity by itself. Loading verifies the content hash and target compatibility. Joblib/sklearn artifacts are trusted-internal only because serialization is pickle-based.

## Synthetic qualification

The external synthetic gate is a regression test, not a fab validation claim.

Current v0.6.0 results:

### Harmful continuous local drift

```text
Rows:                    1,536
M0 context RMSE:         1.3039
M1 context+state RMSE:   0.4365
M1 RMSE gain:            0.8674
Association effect:      +1.6050
Association state:       STRONG_ASSOCIATION
M1 90% residual interval half-width: 0.7765
```

### Benign local behavioral drift

```text
Rows:                    1,536
M0 RMSE:                 0.2732
M1 RMSE:                 0.3265
M1 gain:                -0.0533
Equipment state useful:  false
Association effect:      +0.0117
Association state:       NO_OBSERVED_ASSOCIATION
```

### Harmful binary target

```text
Rows:                    2,336
M0 Brier:                0.2021
M1 Brier:                0.1698
M1 Brier gain:           0.0323
M1 calibration error:    0.0934
Association state:       STRONG_ASSOCIATION
```

The external synthetic-quality gate passes all five required checks.

## Existing-platform regression

The pre-existing nine-case behavioral/metrology Golden Corpus remains unchanged by this release:

```text
Case pass rate:          100%
Episode recall:          100%
False actionable events: 0
False events / 1000 asset-hours: 0
```

Thus the quality layer has not altered the technical health decision path.

## What is intentionally not promoted

v0.6.0 does not claim:

- production quality probability calibration;
- a universal target across products;
- causal equipment effects;
- production metrology sampling correction;
- production tool/product generalization;
- financial loss prediction;
- automatic model promotion.

Those require internal historical qualification.

## Next internal qualification gate

The company port should next validate real target semantics and labels before any model is promoted:

1. define target/stage/spec and prediction cutoff;
2. audit `observed_at` and `available_at`;
3. identify censoring/intervention states;
4. quantify sampling selection;
5. build M0/M1 snapshot;
6. chronological holdout;
7. lot-group leakage study;
8. tool-held-out and product-held-out studies where feasible;
9. probability calibration / continuous interval coverage;
10. measurement-system confounding;
11. exposed/control robustness with route/genealogy controls;
12. shadow only after all target-specific gates pass.
