# EPHI v0.12 Internal Port Kit Checklist

Use this checklist when moving the validated portable release into the internal environment.

## Package / provenance

- [ ] Install exact EPHI release and matching `ephi-company-port` version.
- [ ] Verify `RELEASE_MANIFEST.json` and package checksum.
- [ ] Keep proprietary implementation under `ephi_company`; do not fork `src/ephi` analytical modules.
- [ ] Rebuild the release manifest after any internal adapter/auth/runtime change.

## Port target

- [ ] Set `operations.family_id` to the pilot family.
- [ ] Declare `port.required_capabilities` explicitly.
- [ ] Decide whether `allow_partial_capabilities` is permitted and document why.
- [ ] Replace every required `__MAP_*` physical dataset/column placeholder.

## Physical data plane

- [ ] Implement approved Arrow Big Data executor.
- [ ] Preserve logical names through `MappedBigDataClient`.
- [ ] Preserve `event_time` and `available_at` semantics.
- [ ] Implement source-side aggregate Data Reality profiling.
- [ ] Confirm late/corrected data and revision semantics.

## Durable infrastructure

- [ ] Shared CAS-capable `StateStore` implemented.
- [ ] Durable materialization store implemented.
- [ ] Immutable artifact store implemented.
- [ ] Shared work queue semantics preserve idempotent enqueue, leases, retry and reclaim.
- [ ] No pod-local SQLite is used across multiple Kubernetes replicas.

## Identity / security

- [ ] Company identity resolver implemented.
- [ ] `/v1` read roles mapped.
- [ ] mutation roles mapped.
- [ ] authenticated subject overrides body-supplied audit actor/reporter.
- [ ] proprietary secrets are runtime-injected, not stored in mapping YAML or image layers.

## Notifications

- [ ] Approved internal publisher implemented.
- [ ] All delivery routes use `ControlledNotificationDispatcher` / `NotificationDeliveryGate`.
- [ ] Global/family/component notification kill-switch tested.
- [ ] Suppressing delivery does not suppress analytical episode generation.

## Bootstrap / qualification

- [ ] `ephi port module-validate` passes.
- [ ] `MAPPING_VALIDATION` passes.
- [ ] capability-scoped `DATA_REALITY` passes.
- [ ] `STATE_BOOTSTRAP` completes with exact release/config identity.
- [ ] internal strict `GOLDEN_REPLAY` passes.
- [ ] measured `OPERATIONS_QUALIFICATION` passes.
- [ ] real engineer `SHADOW_READINESS` passes.
- [ ] resulting port report is archived.

## Deployment

- [ ] Internal image installs both packages.
- [ ] `EPHI_CONFIG_PATHS` supplied to API and all workers.
- [ ] API uses `ephi_company.app`.
- [ ] workers use `ephi_company.runtime`.
- [ ] bootstrap Job runs before shadow eligibility is declared.
- [ ] resource requests/limits replaced using internal scale evidence.
- [ ] network/ingress/service-account policies reviewed.

## Certification

- [ ] Reference family template remains `RESEARCH` until internal evidence is attached.
- [ ] capability-specific gates are recorded in immutable family history.
- [ ] promotion occurs through legal certification transitions only.
- [ ] rollback compatibility is evaluated before deployment rollback.

## Non-goals

- [ ] No automatic tool hold/reroute/recipe change.
- [ ] No automatic root-cause declaration.
- [ ] No automatic model promotion.
- [ ] No financial approval from the Value Ledger.
