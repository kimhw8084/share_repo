# Milestone 27 — Production Hardening & Fail-Fast Database Integration

## Objective
Reduce internal porting failures to either immediate success or precise preflight failure before manufacturing workers start.

## Hardened guarantees
- Accepted binding manifests are strict and tamper-evident; edited SQL must be reviewed and resealed.
- Every accepted binding exposes the full canonical dataset schema. Unresolved optional semantics are explicit `NULL`; required semantics cannot be faked by `NULL`.
- Y/N and equivalent boolean token sources are normalized to canonical boolean values in SQL.
- Process-history `material_id` is optional for behavioral health, matching the formal dataset contract.
- Runtime SQL no longer assumes every repository query has an event-time window. Incremental `available_at` and ID lookups execute directly.
- Physical partition pruning is conservative and additive to exact canonical filtering.
- Temporal predicates must be valid ISO/datetime values and bounded interactive windows are enforced.
- SQL capability probes qualify parameter binding, subqueries, CASE, casts, timestamps and LIMIT behavior before company tables are used.
- Startup schema fingerprints detect source schema drift.
- Bootstrap executes zero-row queries through the real company SQL executor before Data Reality/workers start.
- Missing AutoPort binding mounts fail explicitly rather than silently falling back to legacy mappings.
- Production preflight aggregates all company infrastructure gaps in one report.
- The 15th qualification plane launches real CLI/API subprocesses and verifies reference PASS plus company-scaffold fail-closed behavior.

## Portable production evidence
The reference qualification executes generated SQL against SQLite through the actual `SqlTemplateBigDataClient` and `ProcessExecutionRepository`, checks boolean normalization, binding integrity, SQL dialect probes, HTTP process startup, join guards, and production-preflight CLI behavior.

This is portable mechanism evidence only. Company-internal production qualification still requires exact SQL dialect/API, real table semantics, Data Reality, query-plan/scale measurements, DR drills, historical replay and engineer shadow evidence.
