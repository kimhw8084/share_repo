# Internal Campaign Observability Runbook

## 1. Preconditions

Use the exact approved `RELEASE_MANIFEST.json`, company/family config stack, shared state backend, and immutable artifact backend. Do not run readiness against a copied workspace or a different config hash.

## 2. Execute/resume the campaign

Use the versioned command sequence in `scripts/metrology_campaign_command_sequence.sh`. Retry a transient failure with the same `campaign-id`; do not create a new campaign identity merely to hide a failed attempt.

## 3. Review readiness

Run:

```bash
ephi launch campaign-readiness \
  --state-module ephi_company.state \
  --config configs/base.yaml \
  --config company_port/configs/company.yaml \
  --config configs/families/metrology.yaml \
  --family-id METROLOGY_REFERENCE \
  --campaign-id <campaign-id> \
  --current-state <current-certification-state>
```

Do not hand off when readiness is `FAILED` or `BLOCKED`.

## 4. Inspect blockers in order

1. `reconciliation.blockers`
2. `slo.blockers`
3. retention blockers
4. dossier/promotion blockers
5. failed stage event taxonomy and preserved raw error

Artifact-integrity, source-identity, and replay/source mismatches are fail-closed conditions.

## 5. Publish the qualification export

```bash
ephi launch campaign-export \
  --state-module ephi_company.state \
  --config configs/base.yaml \
  --config company_port/configs/company.yaml \
  --config configs/families/metrology.yaml \
  --family-id METROLOGY_REFERENCE \
  --campaign-id <campaign-id> \
  --current-state <current-certification-state> \
  --publish \
  --output <campaign-root>/qualification-export.json
```

Preserve both the semantic `export_sha256` and the immutable artifact reference.

## 6. Compare reruns when needed

Use `campaign-compare` when a replay/re-execution is performed. An `EXECUTION_CHANGED` result may be acceptable when evidence/source fingerprints remain unchanged; `SOURCE_CHANGED` or `EVIDENCE_CHANGED` requires explicit qualification review.

## 7. Handoff

Only a READY dossier is handed into the qualification control plane. Handoff creates/records promotion evidence; it does not approve the promotion.

## 8. Incident handling

- `ARTIFACT_INTEGRITY`: freeze promotion, preserve store/object metadata, investigate mutation/corruption.
- `SOURCE_IDENTITY`: freeze promotion, reconcile release/config/family/snapshot lineage.
- `SOURCE_UNAVAILABLE`: retry only after source health is restored; do not fabricate evidence.
- `ADAPTER_CONTRACT`: fix/requalify company adapter before rerun.
- `EVIDENCE_REJECTED`: treat the scientific/operational gate as failed, not as a transient infrastructure error.
- `UNKNOWN`: preserve full error and classify during postmortem before promotion.

## 9. Retention

Do not delete evidence, replay manifests, or source-lineage records merely because the minimum retention date has elapsed. The v0.18 policy is a minimum-retention assessment; formal archival/deletion remains a separate controlled process.
