# Phase 14 — Initial Implementation Specification

## Objective

Convert the frozen EPHI architecture into the smallest production-shaped codebase that can support the first end-to-end health vertical slice without later rewrites.

## Scope of this initial repository

### Implement now

- package/build/version foundation;
- strict config contracts and deterministic config hash;
- domain primitives for knowledge time, provenance, IDs, and capability semantics;
- `BigDataClient`, `StateStore`, `MaterializationStore`, and `ArtifactStore` protocols;
- durable local SQLite `StateStore` with optimistic compare-and-set;
- local DuckDB Big Data adapter and Parquet materialization store;
- canonical execution validator/canonicalizer;
- semantic process-execution repository;
- watermark and job-run primitives;
- synthetic manufacturing generator with fault injection;
- data-reality audit utility;
- CLI and FastAPI process entrypoints;
- invariant, unit, and optional local-integration tests.

### Explicitly defer

- reference/peer computation;
- detector implementations;
- evidence fusion;
- episode state machine;
- supervised quality models;
- ANN/FAISS;
- GPU/PyTorch;
- graph database;
- Redis/message bus;
- distributed Python framework;
- UI framework selection.

No placeholder implementation may pretend these deferred capabilities exist.

## Core interface decisions

### Columnar hot path

Repositories and canonicalizers operate on Arrow-compatible batches. Domain objects are reserved for low-cardinality semantic entities and API/config boundaries.

### Knowledge-time invariant

Any historical/replay read must obey:

`record.available_at <= as_of`

### State update invariant

Sequential analytical state will use compare-and-set versioning. Duplicate processing must not silently advance state twice.

### Configuration invariant

A merged validated configuration has a deterministic SHA-256 hash. The hash is suitable for inclusion in future release manifests.

### Adapter invariant

Company-specific dataset/table names may exist only inside adapter/repository configuration. Scientific modules never receive proprietary table names.

## First executable vertical slice after this foundation

`synthetic/company execution -> canonical execution -> scalar feature -> reference state -> robust self detector -> evidence -> episode -> EpisodeView API`

The population/reference layer is deliberately implemented before detectors.

## Milestone acceptance criteria

### M0 — Foundation

- `python -m ephi.cli.main version` succeeds;
- configuration validation succeeds;
- FastAPI `/healthz` and `/version` return deterministic metadata;
- unit tests pass without optional local libraries.

### M1 — Synthetic + local analytical stack

With `.[local,dev]` installed:

- synthetic generator writes Parquet datasets;
- data audit reports row counts/schema/time coverage;
- DuckDB adapter can query generated execution data with projection and knowledge-time predicates;
- Parquet materialization append/read/upsert tests pass.

### M2 — Canonical + incremental runtime

- execution canonicalization rejects missing required semantics;
- repository reads are bounded by `available_at`;
- SQLite state CAS detects conflicting writers;
- watermark commit is idempotent and monotonic under the same state version;
- worker retry tests show no silent state duplication.

## Performance design constraints

- no Python object per raw manufacturing row;
- no row-at-a-time source queries;
- no mandatory Pandas dependency;
- no raw-history scan inside API requests;
- optional local imports are lazy;
- future detector/model interfaces must be batch-in/batch-out;
- future trace feature extraction must share one source pass across consumers.
