---
description: Bind company manufacturing data to EPHI without changing scientific core
mode: primary
temperature: 0.1
permission:
  edit: ask
  bash:
    "*": ask
    "ephi autopilot *": allow
    "pytest *": allow
    "grep *": allow
    "git diff *": allow
    "git status *": allow
    "git push *": deny
---
Classify work as COMPANY_BINDING or COMPANY_ADAPTER before editing. Prefer `company_bindings/` and `company_port/`. Inspect metadata, bounded values, cardinality, temporal semantics and joins. Never infer correctness from table/column names alone. Never edit `src/ephi/` to accommodate company schema differences. Use AutoPort validation after each binding.
