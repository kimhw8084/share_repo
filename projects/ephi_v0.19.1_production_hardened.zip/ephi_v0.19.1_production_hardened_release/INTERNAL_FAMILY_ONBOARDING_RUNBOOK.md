# Internal Family Onboarding Runbook

## 1. Freeze the target before collecting evidence

Create or copy a versioned `FamilyOnboardingPolicy` for the family. Decide which capabilities are required for the first pilot and which are optional. Do not make a capability optional merely because its data is difficult to obtain.

For the metrology reference:

```yaml
required_capabilities:
  - PROCESS_HISTORY
  - METROLOGY
  - REFERENCE_WAFER
```

Optional capabilities remain visible as limitations.

## 2. Run mapping validation and Data Reality

Use the v0.12 port flow to generate the internal Data Reality artifact. Preserve the exact release ID and config hash.

Then generate the onboarding plan:

```bash
ephi onboarding plan \
  --data-reality DATA_REALITY_INTERNAL.json \
  --policy configs/onboarding/metrology_reference.yaml \
  --release-manifest RELEASE_MANIFEST.json \
  --output FAMILY_ONBOARDING_PLAN.json
```

Exit code `2` means required capability blockers remain.

## 3. Resolve blockers before Golden replay

For each blocker, close the generated actions using measured evidence. Typical blockers are missing logical/physical mapping, ambiguous IDs, insufficient `available_at`, poor execution-to-metrology linkage, or incomplete reference-wafer coverage.

Do not start family promotion by overriding a blocker in JSON.

## 4. Curate Golden Historical cases

Create case-intake JSON from approved internal materializations/case IDs. Intake should include scope, expected hypothesis/actionability, onset uncertainty, label confidence, evidence references, and known actions/resolution.

Reference/offline tooling:

```bash
ephi onboarding golden-submit --state-db ./golden.sqlite3 --intake CASE.json

ephi onboarding golden-review \
  --state-db ./golden.sqlite3 \
  --intake-id CASE-ID \
  --state ACCEPTED \
  --reviewer independent-reviewer

ephi onboarding golden-export \
  --state-db ./golden.sqlite3 \
  --corpus-id METROLOGY-GOLDEN \
  --version 1.0.0 \
  --description "Metrology family internal Golden corpus" \
  --output GOLDEN_CORPUS_INTERNAL.json
```

For the internal multi-user workflow, use the same registry on approved shared state rather than local SQLite.

## 5. Check Golden coverage before replay

The family policy must define minimum total/high-confidence case counts and required case types. The reference metrology policy includes:

- HEALTHY
- METROLOGY_SYSTEM_SHIFT
- COMMON_MODE_PROCESS_CHANGE
- MAINTENANCE_TRANSITION
- DATA_PIPELINE_CHANGE
- AMBIGUOUS

Add product/recipe/route/PM and false-alarm strata as required by the actual pilot.

## 6. Run strict historical replay and scale qualification

Use the existing Golden replay, runtime-scale, correction/restart, peer/reference, quality, exposure, history/RCA, and value gates applicable to the capability being promoted.

Persist each gate as a `GateResult` with artifact path and summary. Do not copy a PASS result from another release/config/family.

## 7. Build the OFFLINE_QUALIFIED promotion package

```bash
ephi onboarding promotion-package \
  --policy configs/onboarding/metrology_reference.yaml \
  --plan FAMILY_ONBOARDING_PLAN.json \
  --corpus GOLDEN_CORPUS_INTERNAL.json \
  --gates CAPABILITY_GATES.json \
  --from-state RESEARCH \
  --target-state OFFLINE_QUALIFIED \
  --output BEHAVIORAL_HEALTH_PROMOTION.json
```

A BLOCKED package is an evidence result, not an error to suppress.

## 8. Generate/register the family manifest

After every capability package required for the family target state is READY:

```bash
ephi onboarding family-manifest \
  --package BEHAVIORAL_HEALTH_PROMOTION.json \
  --package METROLOGY_PROMOTION.json \
  --approved-by approver-id \
  --output FAMILY_QUALIFICATION_MANIFEST.json
```

Register through the authoritative `FamilyQualificationRegistry`. Never overwrite an older manifest.

## 9. Enter SHADOW

Entering shadow requires offline scientific/runtime evidence but **does not mean shadow-qualified**. Keep engineer notifications suppressed initially if the rollout policy requires it; analytics and episode formation must continue.

## 10. Build the engineer review queue

Materialize eligible episode review candidates from the advisory read model. Apply the versioned family sampling policy. Preserve hypothesis coverage and deliberately inspect lower-confidence/contradictory cases rather than reviewing only spectacular P1 events.

Use lease-based claims so abandoned reviews re-enter the queue.

## 11. Capture engineer and missed-event evidence

For reviewed episodes record:

- want/partially useful/not useful/misleading,
- comparison validity,
- hypothesis reasonableness,
- verification usefulness,
- false-event reason when applicable.

Capture known external issues absent from EPHI as `MissedEventReport` rather than forcing them into existing episode labels.

## 12. Build SHADOW_QUALIFIED evidence

The promotion package must include `ENGINEER_SHADOW` plus the actual `ShadowQualificationMetrics`. Missing hypothesis review coverage, poor usefulness, excess misleading rate, or insufficient review count blocks the package.

The v0.13 certification policy explicitly prevents `SHADOW -> SHADOW_QUALIFIED` without this plane.

## 13. Preserve limitations

If optional capabilities remain partial/unavailable, propagate them into the qualification manifest. Example: "WIP routing unavailable; containment priority not production-qualified." Do not hide limitations because the primary detector is strong.

## 14. Promotion is release-specific

Any material change to release ID, family config, data mapping, detector/reference semantics, or qualification policy requires the appropriate requalification depth. Do not reuse a v0.13 READY package for a later release unless the release/change-impact policy explicitly permits it.
