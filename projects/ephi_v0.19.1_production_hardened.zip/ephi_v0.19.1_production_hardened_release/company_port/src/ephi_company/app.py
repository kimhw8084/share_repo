from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from ephi.api.app import create_app as create_core_app
from ephi.config import EphiConfig

from ephi_company.auth import authorized, build_identity_resolver
from ephi_company.services import build_services


def create_app(config: EphiConfig) -> FastAPI:
    # Resolve dependencies at startup so an unwired company integration fails before
    # serving traffic rather than falling back to local/in-memory behavior.
    identity_resolver = build_identity_resolver()
    services = build_services(config)
    app = create_core_app(
        config,
        advisory_service=services.advisory,
        history_rca_service=services.history_rca,
        value_service=services.value,
        operations_status_service=services.operations,
        qualification_service=services.qualification,
        campaign_observability_service=services.campaign_observability,
        actor_resolver=lambda request: request.state.company_identity.subject,
    )
    app.state.company_identity_resolver = identity_resolver

    @app.middleware("http")
    async def company_authorization(request: Request, call_next):
        if request.url.path in {"/healthz", "/version"}:
            return await call_next(request)
        try:
            identity = identity_resolver.resolve(request)
        except Exception:
            return JSONResponse(status_code=401, content={"detail": "company identity required"})
        write = request.method.upper() not in {"GET", "HEAD", "OPTIONS"}
        admin = write and (
            request.url.path.endswith("/promotion/approve")
            or request.url.path.endswith("/gates")
            or request.url.path.endswith("/plan")
        )
        if not authorized(identity, write=write, admin=admin):
            return JSONResponse(status_code=403, content={"detail": "insufficient EPHI role"})
        request.state.company_identity = identity
        return await call_next(request)

    return app
