from __future__ import annotations

from typing import Protocol

from ephi.config import EphiConfig
from ephi.domain.launch import (
    LaunchEvidenceAdapterDescriptor,
    LaunchEvidenceReceipt,
    ProductionReplayManifest,
    SourceSnapshotLineage,
)
from ephi.registry.releases import ReleaseManifest

from ephi_company.errors import CompanyPortNotConfiguredError


class InternalLaunchEvidenceExecutor(Protocol):
    """Company-side evidence collector for the real metrology qualification campaign.

    v0.17 requires the adapter to declare all launch stages idempotent, publish immutable
    evidence (directly or through the campaign controller), and resolve every referenced
    source snapshot into explicit lineage. Generic EPHI validates identity, content hashes,
    lineage, retries/resume, and certification sufficiency; this adapter owns only the
    company-specific execution needed to produce evidence. Real launch receipts must use INTERNAL_MEASURED provenance.
    """

    def describe_adapter(self) -> LaunchEvidenceAdapterDescriptor: ...
    def resolve_source_snapshot(self, snapshot_id: str) -> SourceSnapshotLineage: ...
    def collect_data_reality(self) -> LaunchEvidenceReceipt: ...
    def collect_internal_golden_replay(self) -> LaunchEvidenceReceipt: ...
    def collect_production_replay_scale(self) -> tuple[LaunchEvidenceReceipt, ProductionReplayManifest]: ...
    def collect_reliability_dr_drill(self) -> LaunchEvidenceReceipt: ...
    def collect_shadow_runtime(self) -> LaunchEvidenceReceipt: ...
    def collect_engineer_shadow(self) -> LaunchEvidenceReceipt: ...


def build_launch_evidence_executor(
    config: EphiConfig,
    release_manifest: ReleaseManifest,
) -> InternalLaunchEvidenceExecutor:
    raise CompanyPortNotConfiguredError(
        "wire the v0.17 internal metrology evidence executor; it must declare idempotent stages, "
        "resolve source-snapshot lineage, and produce release/config-bound immutable evidence"
    )
