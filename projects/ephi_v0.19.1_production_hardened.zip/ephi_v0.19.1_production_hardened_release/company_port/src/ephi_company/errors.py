class CompanyPortNotConfiguredError(RuntimeError):
    """Raised when a required company-specific infrastructure hook is still unwired."""
