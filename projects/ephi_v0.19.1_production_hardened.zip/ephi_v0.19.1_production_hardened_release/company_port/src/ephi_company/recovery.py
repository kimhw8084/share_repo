from __future__ import annotations

from pathlib import Path

from ephi.adapters.base.artifact_store import ArtifactRef
from ephi.config import EphiConfig
from ephi.registry.releases import ReleaseManifest
from ephi.reliability.policy import load_reliability_policy
from ephi.reliability.snapshot import (
    build_backup_bundle,
    load_backup_artifact,
    publish_backup_bundle,
    restore_backup_bundle,
)

from ephi_company.state import build_artifact_store, build_recovery_state_store


def create_state_backup(
    config: EphiConfig,
    release_manifest: ReleaseManifest,
    *,
    policy_path: str | Path,
    staging_dir: str | Path,
) -> ArtifactRef:
    """Create an immutable state backup using the approved company recovery backends."""
    policy = load_reliability_policy(policy_path)
    state_store = build_recovery_state_store(config)
    artifact_store = build_artifact_store(config)
    bundle = build_backup_bundle(
        state_store,
        policies=policy.policies,
        source_release_id=release_manifest.release_id,
        state_schema_version=policy.state_schema_version,
        fail_on_unclassified=policy.fail_on_unclassified_state,
    )
    return publish_backup_bundle(bundle, artifact_store, staging_dir=staging_dir)


def restore_state_backup(
    config: EphiConfig,
    artifact_ref: ArtifactRef,
    *,
    confirm_clean_target: bool = False,
) -> None:
    """Restore only into a clean recovery namespace.

    This function is intentionally not exposed as an HTTP route. Company operational
    authorization/change-control must wrap it. ``confirm_clean_target`` is an explicit
    human/operator acknowledgement in addition to the store-level empty-target check.
    """
    if not confirm_clean_target:
        raise ValueError("restore requires explicit confirm_clean_target=True")
    artifact_store = build_artifact_store(config)
    bundle = load_backup_artifact(artifact_store, artifact_ref)
    restore_backup_bundle(build_recovery_state_store(config), bundle, require_empty=True)
