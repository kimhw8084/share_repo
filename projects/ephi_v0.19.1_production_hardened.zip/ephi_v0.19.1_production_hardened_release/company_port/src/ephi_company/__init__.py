"""Company-specific EPHI composition scaffold.

Replace only the marked physical-infrastructure hooks. Keep manufacturing mappings,
identity/auth integration, and deployment-specific composition outside the generic
`ephi` package.
"""
