from __future__ import annotations

from collections.abc import Callable, Mapping

from ephi.config import EphiConfig
from ephi.domain.operations import RuntimeRole
from ephi.runtime.idempotency import AppliedWorkLedger
from ephi.runtime.queue import DurableWorkQueue

from ephi_company.errors import CompanyPortNotConfiguredError
from ephi_company.state import build_state_store
from ephi_company.configuration import load_company_config


def _runtime_config() -> EphiConfig:
    return load_company_config()


def build_queue(role: RuntimeRole):
    config = _runtime_config()
    # DurableWorkQueue is storage-agnostic; the company StateStore MUST be shared,
    # durable, and CAS-capable for multi-pod use.
    return DurableWorkQueue(build_state_store(config))


def build_applied_work_ledger(role: RuntimeRole):
    config = _runtime_config()
    return AppliedWorkLedger(build_state_store(config))


def build_handlers(role: RuntimeRole) -> Mapping[str, Callable]:
    raise CompanyPortNotConfiguredError(
        f"wire idempotent handlers for runtime role {role.value}; never substitute no-op handlers"
    )
