from __future__ import annotations

from typing import Protocol

from ephi.config import EphiConfig
from ephi.domain.port import PortGateEvidence
from ephi.registry.releases import ReleaseManifest

from ephi_company.errors import CompanyPortNotConfiguredError


class BootstrapExecutor(Protocol):
    def run(self, config: EphiConfig, release_manifest: ReleaseManifest) -> PortGateEvidence: ...


def build_bootstrap_executor(config: EphiConfig) -> BootstrapExecutor:
    """Build the internal state bootstrap executor.

    It should orchestrate the existing EPHI BootstrapPhase order using shared state and
    idempotent jobs. It must not report success until required chunks/materializations
    are complete and their source/release/config identities match the current run.
    """
    raise CompanyPortNotConfiguredError(
        "wire canonical/features/reference/peer/history bootstrap executor"
    )
