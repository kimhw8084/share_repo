from __future__ import annotations

from ephi.audit import DataRealityBackend
from ephi.config import EphiConfig

from ephi_company.errors import CompanyPortNotConfiguredError


def build_audit_backend(config: EphiConfig) -> DataRealityBackend:
    """Return a backend that pushes aggregate profiling into the company Big Data platform."""
    raise CompanyPortNotConfiguredError(
        "wire Data Reality profiling to company Big Data; do not download full tables to Python"
    )
