from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from fastapi import Request

from ephi_company.errors import CompanyPortNotConfiguredError

READ_ROLES = frozenset({"EPHI_VIEWER", "EPHI_ENGINEER", "EPHI_ADMIN"})
WRITE_ROLES = frozenset({"EPHI_ENGINEER", "EPHI_ADMIN"})
ADMIN_ROLES = frozenset({"EPHI_ADMIN"})


@dataclass(frozen=True, slots=True)
class CompanyIdentity:
    subject: str
    roles: frozenset[str]


class IdentityResolver(Protocol):
    def resolve(self, request: Request) -> CompanyIdentity: ...


def authorized(identity: CompanyIdentity, *, write: bool, admin: bool = False) -> bool:
    if admin:
        required = ADMIN_ROLES
    else:
        required = WRITE_ROLES if write else READ_ROLES
    return bool(identity.roles & required)


def build_identity_resolver() -> IdentityResolver:
    # Integrate with the company-approved ingress/service identity mechanism.
    # Fail closed until this hook is implemented.
    raise CompanyPortNotConfiguredError("wire company identity / role resolution")
