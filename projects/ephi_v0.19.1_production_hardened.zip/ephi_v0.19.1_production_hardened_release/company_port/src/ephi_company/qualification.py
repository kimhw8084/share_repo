from __future__ import annotations

from ephi.config import EphiConfig
from ephi.domain.port import PortGateEvidence
from ephi.registry.releases import ReleaseManifest

from ephi_company.errors import CompanyPortNotConfiguredError


def run_internal_golden_replay(config: EphiConfig, release_manifest: ReleaseManifest) -> PortGateEvidence:
    raise CompanyPortNotConfiguredError(
        "wire internal Golden Historical Corpus loader and strict available_at replay gate"
    )


def run_internal_operations_gate(config: EphiConfig, release_manifest: ReleaseManifest) -> PortGateEvidence:
    raise CompanyPortNotConfiguredError(
        "wire measured internal scale/freshness/queue/restart/deployment qualification gate"
    )


def assess_internal_shadow_readiness(config: EphiConfig, release_manifest: ReleaseManifest) -> PortGateEvidence:
    raise CompanyPortNotConfiguredError(
        "wire family qualification plus real engineer shadow-review readiness gate"
    )
