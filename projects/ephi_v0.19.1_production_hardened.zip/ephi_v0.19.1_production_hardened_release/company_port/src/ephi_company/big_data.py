from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable, Mapping, Protocol

from ephi.adapters.base.big_data import BigDataClient, QuerySpec
from ephi.adapters.company.configured import mapping_registry_from_config
from ephi.adapters.company.mapped_client import MappedBigDataClient
from ephi.adapters.company.sql_bound_client import SqlBindingRegistry, SqlTemplateBigDataClient
from ephi.config import EphiConfig

from ephi_company.errors import CompanyPortNotConfiguredError


class ApprovedCompanyQueryExecutor(Protocol):
    """Minimal contract to wrap the approved internal Big Data library."""

    def query_arrow(self, query: QuerySpec): ...

    def stream_arrow(self, query: QuerySpec, *, batch_rows: int = 65_536) -> Iterable: ...


def build_approved_executor(config: EphiConfig) -> ApprovedCompanyQueryExecutor:
    # Replace this function only. Credentials/tokens must come from approved runtime
    # identity/secret injection and must never be stored in EPHI mapping YAML.
    raise CompanyPortNotConfiguredError(
        "wire build_approved_executor() to the approved internal Big Data library"
    )



class ApprovedCompanySqlExecutor(Protocol):
    """Execute parameterized read-only SQL produced from validated AutoPort bindings."""

    def query_sql_arrow(self, sql: str, parameters: Mapping[str, Any]): ...
    def stream_sql_arrow(self, sql: str, parameters: Mapping[str, Any], *, batch_rows: int = 65_536) -> Iterable: ...


def build_approved_sql_executor(config: EphiConfig) -> ApprovedCompanySqlExecutor:
    raise CompanyPortNotConfiguredError(
        "wire build_approved_sql_executor() to the approved internal parameterized SQL/Arrow API"
    )

def build_big_data_client(config: EphiConfig) -> BigDataClient:
    binding_root = Path(config.autopilot.binding_dir)
    registry = SqlBindingRegistry.from_directory(binding_root)
    if registry.bindings:
        return SqlTemplateBigDataClient(build_approved_sql_executor(config), registry)
    if config.autopilot.accepted_datasets:
        raise CompanyPortNotConfiguredError(
            f"AutoPort is active for {list(config.autopilot.accepted_datasets)} but no validated binding manifests "
            f"were found at {binding_root}. Mount the approved company bindings before startup."
        )
    executor = build_approved_executor(config)
    return MappedBigDataClient(executor, mapping_registry_from_config(config.data))
