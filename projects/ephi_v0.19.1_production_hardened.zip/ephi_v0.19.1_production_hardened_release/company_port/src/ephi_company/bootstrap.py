from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ephi.adapters.base.big_data import QuerySpec
from ephi.adapters.company.validation import validate_mapping_config
from ephi.adapters.company.sql_bound_client import SqlBindingRegistry
from ephi.audit import DEFAULT_CAPABILITY_RULES, DataRealityAuditor
from ephi.audit_contracts import DEFAULT_DATASET_CONTRACTS, DEFAULT_JOIN_CONTRACTS
from ephi.autopilot.validation import validate_sql_binding
from ephi.config import EphiConfig
from ephi.domain.data_reality import QualificationState
from ephi.domain.port import PortGateEvidence
from ephi.registry.releases import ReleaseManifest

from ephi_company.audit import build_audit_backend
from ephi_company.autopilot import build_schema_inspector
from ephi_company.big_data import build_big_data_client
from ephi_company.bootstrap_tasks import build_bootstrap_executor
from ephi_company.qualification import (
    assess_internal_shadow_readiness,
    run_internal_golden_replay,
    run_internal_operations_gate,
)
from ephi_company.state import build_recovery_state_store, build_state_store


def _required_dataset_names(config: EphiConfig) -> frozenset[str]:
    required = set()
    requested = set(config.port.required_capabilities)
    for rule in DEFAULT_CAPABILITY_RULES:
        if rule.capability in requested:
            required.update(rule.required_datasets)
    return frozenset(required)


@dataclass
class CompanyBootstrapRuntime:
    config: EphiConfig
    release_manifest: ReleaseManifest

    def _validate_autopilot_bindings(self, required_datasets: frozenset[str]) -> PortGateEvidence:
        root = Path(self.config.autopilot.binding_dir)
        try:
            registry = SqlBindingRegistry.from_directory(root)
        except Exception as exc:
            return PortGateEvidence(passed=False, summary="AutoPort binding load failed", blockers=(str(exc),))
        blockers: list[str] = []
        warnings = 0
        for logical_name in sorted(required_datasets):
            binding = registry.bindings.get(logical_name)
            if binding is None:
                blockers.append(f"required AutoPort binding missing: {logical_name}")
                continue
            result = validate_sql_binding(binding)
            warnings += len(result.warnings)
            if not result.passed:
                blockers.append(f"invalid AutoPort binding {logical_name}: {'; '.join(result.errors)}")
        if blockers:
            return PortGateEvidence(
                passed=False,
                summary="required AutoPort bindings are incomplete",
                blockers=tuple(blockers),
                metrics={"required_datasets": len(required_datasets), "binding_warnings": warnings},
            )

        # Compare accepted source schema fingerprints before constructing workers.
        try:
            inspector = build_schema_inspector(self.config)
            for logical_name in sorted(required_datasets):
                binding = registry.binding(logical_name)
                if not binding.source_schema_fingerprint:
                    continue
                if hasattr(inspector, "profile_table"):
                    profile = inspector.profile_table(binding.physical_table, sample_rows=0)
                else:
                    profile = inspector.profile(binding.physical_table, sample_rows=0)
                current = profile.schema_fingerprint()
                if current != binding.source_schema_fingerprint:
                    blockers.append(f"source schema drift detected for {logical_name}: {binding.physical_table}")
        except Exception as exc:
            blockers.append(f"schema fingerprint preflight failed: {exc}")

        # Zero-row query through the real company SQL executor catches table/column/
        # syntax/parameterization failures before Data Reality or workers scan history.
        if not blockers:
            try:
                client = build_big_data_client(self.config)
                contracts = {c.logical_name: c for c in DEFAULT_DATASET_CONTRACTS}
                for logical_name in sorted(required_datasets):
                    contract = contracts[logical_name]
                    client.query_arrow(QuerySpec(
                        dataset=logical_name,
                        columns=tuple((*contract.required_columns, *contract.optional_columns)),
                        limit=0,
                    ))
            except Exception as exc:
                blockers.append(f"runtime SQL preflight failed: {exc}")

        return PortGateEvidence(
            passed=not blockers,
            summary="required AutoPort bindings and runtime SQL preflight passed" if not blockers else "AutoPort runtime preflight failed",
            blockers=tuple(blockers),
            metrics={"required_datasets": len(required_datasets), "binding_warnings": warnings},
        )

    def validate_mapping(self) -> PortGateEvidence:
        if not self.config.port.required_capabilities:
            return PortGateEvidence(
                passed=False,
                summary="port target capability set is empty",
                blockers=("configure port.required_capabilities before internal bootstrap",),
            )
        required_datasets = _required_dataset_names(self.config)
        if self.config.autopilot.accepted_datasets:
            return self._validate_autopilot_bindings(required_datasets)

        results = validate_mapping_config(self.config.data, DEFAULT_DATASET_CONTRACTS)
        by_name = {item.logical_name: item for item in results}
        blockers: list[str] = []
        placeholder_count = 0
        for logical_name in sorted(required_datasets):
            item = by_name[logical_name]
            if item.state in {QualificationState.UNAVAILABLE, QualificationState.FAILED}:
                blockers.append(f"required dataset mapping invalid: {logical_name}")
                continue
            binding = self.config.data.datasets[logical_name]
            physical_values = (binding.physical_name, *binding.columns.values())
            placeholders = [value for value in physical_values if value.startswith("__MAP_")]
            placeholder_count += len(placeholders)
            if placeholders:
                blockers.append(f"placeholder mapping remains for required dataset: {logical_name}")
        return PortGateEvidence(
            passed=not blockers,
            summary="required logical-to-physical mappings validated" if not blockers else "required mapping is incomplete",
            blockers=tuple(blockers),
            metrics={
                "required_capabilities": len(self.config.port.required_capabilities),
                "required_datasets": len(required_datasets),
                "placeholder_values": placeholder_count,
            },
        )

    def run_data_reality(self) -> PortGateEvidence:
        report = DataRealityAuditor(build_audit_backend(self.config)).run(
            DEFAULT_DATASET_CONTRACTS,
            DEFAULT_JOIN_CONTRACTS,
            config_hash=self.config.stable_hash(),
        )
        acceptable = {QualificationState.QUALIFIED}
        if self.config.port.allow_partial_capabilities:
            acceptable |= {QualificationState.PARTIAL, QualificationState.PROVISIONAL}
        blockers = []
        states = {}
        for capability in self.config.port.required_capabilities:
            assessment = report.capability(capability)
            state = assessment.state if assessment else QualificationState.UNAVAILABLE
            states[capability.value] = state.value
            if state not in acceptable:
                blockers.append(f"required capability {capability.value} is {state.value}")
        return PortGateEvidence(
            passed=not blockers,
            summary="required Data Reality capabilities passed" if not blockers else "required Data Reality capability gate failed",
            artifact="DATA_REALITY_INTERNAL.json",
            blockers=tuple(blockers),
            metrics={"required_capabilities": len(states), "blocked_capabilities": len(blockers)},
        )

    def bootstrap_state(self) -> PortGateEvidence:
        return build_bootstrap_executor(self.config).run(self.config, self.release_manifest)

    def run_golden_replay(self) -> PortGateEvidence:
        return run_internal_golden_replay(self.config, self.release_manifest)

    def run_operations_qualification(self) -> PortGateEvidence:
        return run_internal_operations_gate(self.config, self.release_manifest)

    def assess_shadow_readiness(self) -> PortGateEvidence:
        return assess_internal_shadow_readiness(self.config, self.release_manifest)


def build_port_runtime(config: EphiConfig, release_manifest: ReleaseManifest) -> CompanyBootstrapRuntime:
    return CompanyBootstrapRuntime(config=config, release_manifest=release_manifest)


def build_port_state_store(config: EphiConfig):
    return build_state_store(config)


def build_recovery_store(config: EphiConfig):
    return build_recovery_state_store(config)
