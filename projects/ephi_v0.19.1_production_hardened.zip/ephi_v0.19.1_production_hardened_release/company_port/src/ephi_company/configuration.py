from ephi.config import EphiConfig
from ephi.port.configuration import load_runtime_config


def load_company_config() -> EphiConfig:
    return load_runtime_config()
