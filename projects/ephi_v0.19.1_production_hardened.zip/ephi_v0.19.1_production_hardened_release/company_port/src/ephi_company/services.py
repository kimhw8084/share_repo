from __future__ import annotations

from dataclasses import dataclass

from ephi.advisory.service import AdvisoryService
from ephi.config import EphiConfig
from ephi.history.application import HistoryRCAApplicationService
from ephi.operations.status import OperationsStatusService
from ephi.onboarding.control_plane import QualificationControlPlaneService
from ephi.value.service import ValueLedgerService
from ephi.launch.observability import CampaignObservabilityService

from ephi_company.errors import CompanyPortNotConfiguredError


@dataclass(frozen=True, slots=True)
class CompanyServices:
    advisory: AdvisoryService
    history_rca: HistoryRCAApplicationService | None
    value: ValueLedgerService | None
    operations: OperationsStatusService
    qualification: QualificationControlPlaneService
    campaign_observability: CampaignObservabilityService


def build_services(config: EphiConfig) -> CompanyServices:
    """Compose company-backed materialized read services.

    The generic API must not query raw manufacturing history per request. Build these
    services from approved shared state/materializations and immutable artifacts.
    """
    raise CompanyPortNotConfiguredError(
        "wire company-backed Advisory/History/Value/Operations services"
    )
