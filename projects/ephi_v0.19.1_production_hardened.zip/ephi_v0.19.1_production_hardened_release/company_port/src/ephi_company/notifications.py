from __future__ import annotations

from typing import Protocol

from ephi.advisory.models import NotificationPayload
from ephi.config import EphiConfig
from ephi.operations.controls import OperationalControlService
from ephi.operations.notifications import NotificationDeliveryGate

from ephi_company.errors import CompanyPortNotConfiguredError


class NotificationPublisher(Protocol):
    def publish(self, payload: NotificationPayload) -> None: ...


def build_notification_publisher(config: EphiConfig) -> NotificationPublisher:
    raise CompanyPortNotConfiguredError(
        "wire the approved internal message/notification API"
    )


class ControlledNotificationDispatcher:
    """Only publishing path exposed by the scaffold; honors EPHI delivery controls."""

    def __init__(self, publisher: NotificationPublisher, controls: OperationalControlService) -> None:
        self.publisher = publisher
        self.gate = NotificationDeliveryGate(controls)

    def publish(
        self,
        payload: NotificationPayload,
        *,
        family: str | None = None,
        component: str | None = None,
    ) -> bool:
        if not self.gate.allowed(family=family, component=component):
            return False
        self.publisher.publish(payload)
        return True
