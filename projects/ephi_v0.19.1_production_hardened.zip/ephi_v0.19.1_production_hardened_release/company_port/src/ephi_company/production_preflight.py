from __future__ import annotations

from collections.abc import Callable

from ephi.autopilot.dialect import qualify_sql_executor
from ephi.config import EphiConfig
from ephi.domain.operations import DeploymentPlan, RuntimeRole
from ephi.port.production_preflight import ProductionPreflightCheck, ProductionPreflightReport
from ephi.registry.releases import ReleaseManifest


def run_production_preflight(
    config: EphiConfig,
    deployment_plan: DeploymentPlan,
    release_manifest: ReleaseManifest,
) -> ProductionPreflightReport:
    checks: list[ProductionPreflightCheck] = []

    def check(name: str, callback: Callable[[], object]) -> object | None:
        try:
            value = callback()
            checks.append(ProductionPreflightCheck(name, True, type(value).__name__ if value is not None else "constructed"))
            return value
        except Exception as exc:
            checks.append(ProductionPreflightCheck(name, False, f"{type(exc).__name__}: {exc}"))
            return None

    from ephi_company.autopilot import build_schema_inspector
    from ephi_company.big_data import build_approved_sql_executor, build_big_data_client
    from ephi_company.state import (
        build_state_store, build_recovery_state_store, build_materialization_store, build_artifact_store,
    )
    from ephi_company.audit import build_audit_backend
    from ephi_company.auth import build_identity_resolver
    from ephi_company.services import build_services
    from ephi_company.notifications import build_notification_publisher
    from ephi_company.bootstrap_tasks import build_bootstrap_executor
    from ephi_company.launch import build_launch_evidence_executor
    from ephi_company.bootstrap import build_port_runtime, build_port_state_store, build_recovery_store
    from ephi_company.runtime import build_handlers

    check("schema_inspector", lambda: build_schema_inspector(config))
    sql_executor = check("sql_executor", lambda: build_approved_sql_executor(config))
    if sql_executor is not None:
        report = qualify_sql_executor(sql_executor)
        checks.append(ProductionPreflightCheck(
            "sql_dialect_capabilities", report.passed,
            "all portable SQL probes passed" if report.passed else "; ".join(f"{c.name}: {c.error}" for c in report.checks if not c.passed),
        ))
    else:
        checks.append(ProductionPreflightCheck("sql_dialect_capabilities", False, "SQL executor unavailable"))
    check("big_data_client", lambda: build_big_data_client(config))
    check("state_store", lambda: build_state_store(config))
    check("recovery_state_store", lambda: build_recovery_state_store(config))
    check("materialization_store", lambda: build_materialization_store(config))
    check("artifact_store", lambda: build_artifact_store(config))
    check("audit_backend", lambda: build_audit_backend(config))
    check("identity_resolver", build_identity_resolver)
    check("services", lambda: build_services(config))
    check("notification_publisher", lambda: build_notification_publisher(config))
    check("bootstrap_executor", lambda: build_bootstrap_executor(config))
    check("launch_evidence_executor", lambda: build_launch_evidence_executor(config, release_manifest))
    port_runtime = check("port_runtime", lambda: build_port_runtime(config, release_manifest))
    if port_runtime is not None:
        try:
            evidence = port_runtime.validate_mapping()
            checks.append(ProductionPreflightCheck(
                "port_mapping_runtime_preflight", evidence.passed,
                evidence.summary if evidence.passed else "; ".join(evidence.blockers),
            ))
        except Exception as exc:
            checks.append(ProductionPreflightCheck("port_mapping_runtime_preflight", False, f"{type(exc).__name__}: {exc}"))
    else:
        checks.append(ProductionPreflightCheck("port_mapping_runtime_preflight", False, "port runtime unavailable"))
    check("port_state_store", lambda: build_port_state_store(config))
    check("port_recovery_store", lambda: build_recovery_store(config))

    active_worker_roles = [
        profile.role for profile in deployment_plan.roles
        if profile.replicas > 0 and profile.role != RuntimeRole.API
    ]
    for role in active_worker_roles:
        # Queue/ledger construction ultimately depends on the shared state store; the
        # explicit handler check is what proves role-specific work is implemented.
        state = check(f"worker_state:{role.value}", lambda: build_state_store(config))
        if state is not None:
            from ephi.runtime.queue import DurableWorkQueue
            from ephi.runtime.idempotency import AppliedWorkLedger
            check(f"worker_queue:{role.value}", lambda state=state: DurableWorkQueue(state))
            check(f"worker_ledger:{role.value}", lambda state=state: AppliedWorkLedger(state))
        else:
            checks.append(ProductionPreflightCheck(f"worker_queue:{role.value}", False, "shared state unavailable"))
            checks.append(ProductionPreflightCheck(f"worker_ledger:{role.value}", False, "shared state unavailable"))
        check(f"worker_handlers:{role.value}", lambda role=role: build_handlers(role))

    return ProductionPreflightReport(all(c.passed for c in checks), tuple(checks), __name__)
