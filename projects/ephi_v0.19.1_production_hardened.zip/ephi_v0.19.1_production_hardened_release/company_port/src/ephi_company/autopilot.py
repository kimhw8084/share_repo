from __future__ import annotations

from typing import Protocol

from ephi.autopilot.models import PhysicalTableProfile

from ephi_company.errors import CompanyPortNotConfiguredError


class CompanySchemaInspector(Protocol):
    """Approved bounded metadata/statistics interface used by AutoPort.

    Implementations should use the internal Big Data metadata/query APIs and must
    avoid unbounded full-history scans for schema discovery.
    """

    def find_tables(self, hint: str | None = None, *, limit: int = 20) -> tuple[str, ...]:
        ...

    def profile_table(self, table_name: str, *, sample_rows: int = 50) -> PhysicalTableProfile:
        ...


def build_schema_inspector(config) -> CompanySchemaInspector:
    raise CompanyPortNotConfiguredError(
        "Implement ephi_company.autopilot.build_schema_inspector(config) using the approved "
        "internal Big Data metadata/statistics APIs. Return PhysicalTableProfile and keep "
        "profiling bounded. Do not modify generic EPHI core for proprietary schemas."
    )
