from __future__ import annotations

from ephi.adapters.base.artifact_store import ArtifactStore
from ephi.adapters.base.materialization_store import MaterializationStore
from ephi.adapters.base.state_store import SnapshotStateStore, StateStore
from ephi.config import EphiConfig

from ephi_company.errors import CompanyPortNotConfiguredError


def build_state_store(config: EphiConfig) -> StateStore:
    raise CompanyPortNotConfiguredError(
        "wire build_state_store() to an approved shared durable CAS-capable backend; "
        "do not use pod-local SQLite for multi-pod shadow deployment"
    )


def build_recovery_state_store(config: EphiConfig) -> SnapshotStateStore:
    raise CompanyPortNotConfiguredError(
        "wire build_recovery_state_store() to the approved shared backend with "
        "point-in-time-consistent snapshot and clean-target restore semantics; ordinary CAS alone is insufficient"
    )


def build_materialization_store(config: EphiConfig) -> MaterializationStore:
    raise CompanyPortNotConfiguredError(
        "wire build_materialization_store() to approved durable materialized storage"
    )


def build_artifact_store(config: EphiConfig) -> ArtifactStore:
    raise CompanyPortNotConfiguredError(
        "wire build_artifact_store() to approved immutable internal artifact storage"
    )
