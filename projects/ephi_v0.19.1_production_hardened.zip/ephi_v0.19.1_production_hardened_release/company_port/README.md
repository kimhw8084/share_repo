# EPHI Company Port — v0.19.1

This package contains company-specific composition scaffolds only. v0.17 strengthens `ephi_company.launch.build_launch_evidence_executor`: the adapter must declare all campaign stages idempotent, resolve source-snapshot lineage, and produce artifacts that the generic campaign controller can publish/verify through the approved immutable ArtifactStore. Portable EPHI owns retries/resume, evidence identity, lineage, dossier construction, and control-plane handoff; the company adapter owns physical execution.

Do not replace `INTERNAL_MEASURED` requirements with portable or simulated evidence to make a launch dossier green.

# EPHI company port scaffold

This package is intentionally separate from `src/ephi`. Replace the physical/company hooks here; do not fork analytical modules.

Required wiring order:
1. logical-to-physical dataset/column mapping;
2. approved Big Data Arrow executor;
3. shared CAS-capable StateStore plus durable materialization/artifact stores;
4. identity/role resolver;
5. materialized advisory/history/value/operations/qualification service composition;
6. idempotent worker handlers and shared queue backend;
7. Data Reality profiling backend (`audit.py`);
8. bootstrap executor (`bootstrap_tasks.py`);
9. internal Golden replay, measured operations gate, and engineer shadow readiness (`qualification.py`);
10. shared qualification control plane with company auth/admin role enforcement (`services.py` + core qualification APIs).

All unimplemented infrastructure hooks fail closed with `CompanyPortNotConfiguredError`.


## Campaign observability

The company composition must provide `CompanyServices.campaign_observability` backed by the shared launch workspace and approved immutable artifact store. The core FastAPI surface exposes campaign readiness/reconciliation/SLO/retention/export as read-only views. The internal operator sequence performs readiness and immutable export publication before qualification-control-plane handoff.
