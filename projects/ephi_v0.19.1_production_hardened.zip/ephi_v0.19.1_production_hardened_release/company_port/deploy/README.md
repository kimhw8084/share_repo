# Deployment overlays

`base/` consumes the EPHI reference Kubernetes bundle. `overlays/shadow/` injects the common configuration path into every Deployment and adds a one-shot bootstrap Job.

The bootstrap Job is intentionally fail-closed: it exits non-zero until mapping, Data Reality, bootstrap state, Golden replay, operations qualification, and shadow-readiness gates all pass.

Before internal use, supply company-approved configuration mounts, identity/secrets injection, registry/image policy, shared StateStore/queue infrastructure, and measured resource requests/limits.
