# AutoPort binding ConfigMap

The internal deployment pipeline must provision a ConfigMap named `ephi-company-bindings` from the **validated YAML binding manifests only** (not the `.sql` templates). It is mounted read-only at `/etc/ephi/bindings` in API, workers, and bootstrap.

Example internal pipeline action (adapt to approved tooling): create/update the ConfigMap from `company_bindings/*.yaml`, then render/apply the shadow overlay. Do not commit proprietary bindings to the portable repository.
