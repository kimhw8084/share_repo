# EPHI v0.4.0 — Data Reality & Production Columnar Path

## Purpose

v0.4.0 converts the v0.3 scientific reference implementation into a substantially more portable company-integration and production-scoring substrate. It deliberately does **not** assume proprietary dataset names, universal join thresholds, or synthetic metrology resolution constants.

## New production contracts

### Semantic Data Reality Audit

The audit now has first-class contracts for:

- assets
- process executions
- scalar signals
- traces
- metrology
- quality outcomes
- maintenance
- genealogy
- WIP

Each dataset declares required/optional columns, identity, event time, knowledge-availability time, and revision semantics. The audit reports `QUALIFIED`, `PROVISIONAL`, `PARTIAL`, `UNAVAILABLE`, or `FAILED`; it does not convert missing data into healthy manufacturing state.

Join profiling reports measured match and ambiguity fractions. There is intentionally **no universal hard-coded coverage threshold**: family certification decides what level of join coverage is acceptable for the claimed capability.

### Capability assessment

The audit maps observed data reality into explicit capability states such as process history, scalar FDC, raw trace, metrology, spatial metrology, reference material, maintenance, genealogy, quality outcome, and WIP. Unsupported channels stay unavailable rather than reducing a tool's health score.

### Company mapping layer

Analytical repositories continue to issue logical queries such as `executions.execution_id`. The company port supplies:

1. logical dataset -> physical dataset mapping;
2. logical column -> physical column mapping;
3. one approved physical `BigDataClient` implementation using the internal Big Data library.

`MappedBigDataClient` translates the logical `QuerySpec`, delegates to the physical client, then restores logical Arrow column names. Proprietary table/column names therefore do not leak into analytical modules.

## Measurement-scale qualification

v0.3 required practical scale floors to prevent tiny physically meaningless differences from generating huge z-scores when MAD approaches zero. v0.4 makes those floors characteristic-specific and qualification-aware.

`derive_measurement_scale_policy()` can use:

- configured instrument resolution;
- configured measurement uncertainty;
- observed quantization candidate;
- healthy robust dispersion.

Configured instrument metadata yields a `QUALIFIED` scale policy. Data-only inferred quantization remains `PROVISIONAL` by design.

`MeasurementSystemConfig.from_scale_policies()` propagates characteristic-specific robust floors independently into:

- reference-material bias;
- production-wafer state;
- cross-tool/head matching;
- compact spatial center-edge behavior;
- remeasure repeatability.

Synthetic `0.03–0.04` floors remain fallback test values only.

## Materialized integer reference state

The hot scorer can now consume precomputed `uint64 state_key_id` values rather than creating Python domain objects or composite string dictionary keys per source row.

`ReferenceStateMatrixIndex`:

- uses a deterministic BLAKE2b 64-bit analytical key;
- collision/duplicate checks the materialized state set;
- stores reference statistics as sorted NumPy arrays;
- performs batch lookup using `numpy.searchsorted`;
- carries reference confidence, physical scale floor, and practical-effect floor.

The state key should be materialized once on the execution/feature spine rather than hashed repeatedly in the detector hot path.

## Exact vectorized peer/fleet decomposition

The grouped NumPy peer kernel now matches the qualified semantic peer implementation exactly across tested cohort sizes 2–7.

For cohorts of three, EPHI preserves the all-member robust consensus needed to resist a single poisoned head. For larger cohorts, target observations are exactly excluded from the peer median, peer scale, and peer MAD.

Groups of equal size are processed as dense NumPy matrices. This removes the previous Python loop per manufacturing cohort. Complexity is bounded by `O(rows × peer_count)` with peer count constrained by manufacturing eligibility, never by historical volume.

## Production columnar scorer

`ColumnarBehavioralScorer` performs:

1. integer-key reference lookup;
2. self/adaptive and frozen-anchor robust scoring;
3. physical-change calculation;
4. unit/data-pipeline jump screening;
5. exact grouped peer/fleet decomposition;
6. practical-effect gating.

It intentionally does not query history. Sequential EWMA/CUSUM, controlled known-good admission, evidence fusion, and episodes remain separate incremental stages.

## Qualification results in this environment

### Core tests

43 tests pass. The optional PyArrow/DuckDB integration module is skipped in this sandbox because those optional packages are not installed.

### Behavioral regression

20 seeds × four scenarios, 256,000 synthetic observations:

- healthy: zero actionable events in every seed;
- local drift: all actionable observations confined to `A000`;
- common mode: zero local actionable events, final 100 assessments common-mode in every seed;
- unit-scale change: zero equipment-actionable events; post-change target assessments route to data-pipeline/schema hypothesis.

### Metrology bounded regression

3 seeds per scenario at 900 measurements/head:

- healthy: 0 local actionable;
- measurement-head drift: 216 total actionable, all on `HEAD_A`;
- process shift: 0 local actionable, fleet episode active;
- remeasure instability: 5 total actionable, all on `HEAD_A`;
- spatial-head drift: 36 total actionable, all on `HEAD_A`.

### Production-columnar benchmark

1,000,000 observations; four assets per peer group; 256 contexts:

- full materialized reference lookup + scalar scoring + exact grouped peer decomposition: approximately **0.90M rows/sec** in this sandbox;
- reference lookup success: 100%;
- peer adequacy: 100%.

This is a CPU/NumPy analytical benchmark only. It is **not** an end-to-end company Big Data throughput claim and excludes source query time, canonicalization, sequential state updates, evidence/episode writes, and persistence.

## Internal port boundary

The company environment now needs to supply only the environment-specific pieces:

- internal physical Big Data client implementation;
- logical dataset mappings;
- logical column mappings;
- durable StateStore/MaterializationStore/ArtifactStore implementations if local stores are not appropriate;
- actual measurement resolution/uncertainty evidence;
- actual data/join audit results;
- family qualification thresholds derived from the audit and Golden Historical Benchmark Corpus.

The detector, reference, peer, metrology, evidence, episode and synthetic qualification logic should not be rewritten for the port.

## What remains before live shadow qualification

1. Run `ephi data mapping-validate` against internal mappings.
2. Run semantic Data Reality Audit on internal Big Data.
3. Validate execution/material/FDC/metrology/maintenance joins against manual golden samples.
4. Derive characteristic-specific metrology scale policies from actual resolution/uncertainty and healthy distributions.
5. Materialize integer state/peer keys in the internal execution/feature spine.
6. Benchmark Big Data pushdown + Arrow batch transfer + scorer in the actual environment.
7. Build the fixed Golden Historical Benchmark Corpus.
8. Replay metrology cases with true `available_at` semantics.
9. Only then tune production reference/peer/event thresholds.
