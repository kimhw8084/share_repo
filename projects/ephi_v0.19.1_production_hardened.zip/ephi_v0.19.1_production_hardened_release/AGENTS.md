# EPHI OpenCode / Gemma 4 Porting Rules

## Mission
Port EPHI by binding company manufacturing data to stable EPHI semantic contracts. Do not redesign the qualified scientific core during environment integration.

## First action on every change
Classify the task as exactly one of: `COMPANY_BINDING`, `COMPANY_ADAPTER`, `CONFIG`, `FAMILY_PLUGIN`, `POLICY`, `CORE_CHANGE`.

Use this edit order:
1. `company_bindings/`
2. `company_port/src/ephi_company/`
3. `configs/`
4. `families/` or `extensions/`
5. `src/ephi/` only with explicit core-change justification and qualification evidence.

## Default port workflow
When the user gives a plausible company table name:
1. Read `docs/data_requirements/00_OVERVIEW.md` and the matching dataset file.
2. Inspect table metadata first; do not scan full history.
3. Inspect bounded sample values and bounded aggregate statistics.
4. Test cardinality, nulls, time semantics and joins required by the contract.
5. Distinguish physical `event_time` from knowledge `available_at`.
6. Produce a canonical profile JSON compatible with `ephi autopilot propose`.
7. Generate the most efficient SQL binding under `company_bindings/`.
8. Run `ephi autopilot validate-binding`.
9. Resolve blocking validation issues.
10. Run `ephi autopilot synthesize` and then qualification/bootstrap.

## SQL performance rules
- Never use `SELECT *` in production bindings.
- Never validate semantics by scanning an entire billion-row table when metadata/bounded samples/aggregates suffice.
- Preserve partition predicate pushdown.
- Preserve an incremental watermark when the source supports corrections/late data.
- Project only required columns.
- Avoid Python row loops in manufacturing hot paths.
- Prefer backend aggregation/join pushdown when it materially reduces transferred rows.

## Scientific invariants
Never violate:
- `event_time != available_at` when the source has both physical and knowledge times.
- future data must not enter historical replay.
- missing data != healthy.
- anomaly != harmfulness.
- correlation != causality.
- routing commonality != causal commonality.
- historical similarity != root cause.
- technical severity != operational priority.
- estimated value != validated realized benefit.
- portable/synthetic evidence != internal measured evidence.

## Core protection
Do not edit `src/ephi/` to solve table names, column names, SQL dialect, authentication, deployment, notifications, family naming, or ordinary threshold configuration.
If core change appears necessary: explain why binding/adapter/config/plugin cannot solve it, add a failing test first, make the minimum change, and run the affected qualification gates.

## Uncertainty behavior
Do not guess proprietary schemas or APIs. Inspect them. If a semantic mapping remains ambiguous, mark it `REVIEW_REQUIRED` and explain the exact evidence needed to decide.

## Completion report
Always report: classification, files changed, semantic mappings established, unresolved review items, SQL/performance checks, tests run, qualification impact, and whether generic core changed.

## v0.19.1 production hardening sequence
Before inspecting manufacturing tables, run `ephi autopilot db-qualify` against the approved company SQL executor.
After any intentional binding edit, use `ephi autopilot seal-binding`; never hand-edit `binding_hash`.
For partitioned sources, explicitly confirm `partition_source_field` (`event_time` or `available_at`) and `partition_granularity` (`date` or `timestamp`).
A binding must expose the full canonical schema; unresolved optional fields remain `NULL AS <canonical>` and must not be invented.
Before Data Reality, replay, API deployment, or workers, run `ephi port production-preflight` and resolve every blocking check.
A missing AutoPort binding mount, schema fingerprint drift, SQL capability failure, canonical type failure, or zero-row runtime SQL failure is a blocker, not a reason to modify generic EPHI core.
