# EPHI Internal Port Bootstrap Runbook

## 1. Create the internal composition package

Copy `company_port/` into the internal repository/build context. Do not copy proprietary table names, auth code, or credentials into `src/ephi`.

Install the two packages together:

```bash
python -m pip install /path/to/ephi-release /path/to/ephi-release/company_port
```

## 2. Map the target capability set

Start with `company_port/configs/company.yaml.example` and replace only physical dataset/column placeholders. Keep credentials out of this file.

For the reference metrology pilot the required capability set is:

```yaml
port:
  required_capabilities:
    - PROCESS_HISTORY
    - METROLOGY
    - REFERENCE_WAFER
  allow_partial_capabilities: false
```

Validate the generic module contract:

```bash
EPHI_CONFIG_PATHS=/etc/ephi/base.yaml,/etc/ephi/company.yaml,/etc/ephi/family.yaml \
  ephi port module-validate \
  --runtime-module ephi_company.bootstrap \
  --release-manifest /opt/ephi/RELEASE_MANIFEST.json
```

## 3. Implement physical infrastructure hooks

Implement the narrow functions in:

- `ephi_company/big_data.py`
- `ephi_company/state.py`
- `ephi_company/audit.py`
- `ephi_company/bootstrap_tasks.py`
- `ephi_company/qualification.py`
- `ephi_company/runtime.py`
- `ephi_company/services.py`
- `ephi_company/auth.py`
- `ephi_company/notifications.py`

Leave `ephi_company/bootstrap.py` stage ordering unchanged unless the generic port contract itself is deliberately versioned.

## 4. Run the fail-closed bootstrap

```bash
EPHI_CONFIG_PATHS=/etc/ephi/base.yaml,/etc/ephi/company.yaml,/etc/ephi/family.yaml \
  ephi port bootstrap \
  --runtime-module ephi_company.bootstrap \
  --release-manifest /opt/ephi/RELEASE_MANIFEST.json \
  --output /approved/artifacts/PORT_BOOTSTRAP_REPORT.json
```

Expected order:

```text
MAPPING_VALIDATION
DATA_REALITY
STATE_BOOTSTRAP
GOLDEN_REPLAY
OPERATIONS_QUALIFICATION
SHADOW_READINESS
```

A non-zero exit is a qualification failure, not a reason to skip the stage.

## 5. Resume after correcting a failure

Re-run the same command. Previously passed stages are reused only if the release/config/family/environment identity is unchanged. A changed identity is rejected so evidence from one candidate cannot qualify another.

Use `--restart` only when deliberately restarting the port sequence under the same identity. The authoritative store remains responsible for its own audit history.

## 6. Deploy shadow runtime

Use `company_port/deploy/overlays/shadow` as the starting Kustomize overlay. Replace:

- image registry/name;
- configuration mounts;
- approved identity/secret injection;
- shared state/queue connection details;
- ingress/network policy;
- node placement;
- CPU/memory/GPU sizing after scale qualification.

The bootstrap Job should finish successfully before the shadow runtime is considered eligible to serve engineer-facing evidence.

## 7. Preserve qualification evidence

Store at minimum:

- release manifest;
- effective config hash;
- Data Reality report;
- internal Golden corpus/version and replay report;
- runtime/scale/SLO report;
- family qualification manifest/history;
- engineer shadow summary;
- port bootstrap report;
- deployment bundle hash.

## 8. Promotion rule

`shadow_ready=true` in the port report means the configured internal hooks returned passing evidence for the exact run identity. It does **not** bypass EPHI certification transitions. Promotion still occurs through the family certification registry and approved internal process.
