# Internal Reliability / Disaster-Recovery Qualification Checklist

Do not promote a family beyond shadow readiness until the applicable items are evidenced.

## State inventory

- [ ] Enumerate every key/namespace in the shared EPHI state backend.
- [ ] Map every namespace to `AUTHORITATIVE` or `REBUILDABLE` in the versioned reliability policy.
- [ ] Confirm backup fails on an intentionally unclassified test namespace.
- [ ] Confirm authoritative namespaces include qualification/audit, workflow feedback, validated value evidence, controls/certification, bootstrap identity, watermarks, and applied-work ledger where deployed.
- [ ] Document why each rebuildable namespace can be reconstructed without changing historical truth.

## Snapshot / backup

- [ ] Approved backend implements point-in-time-consistent snapshot semantics.
- [ ] Immutable artifact storage is approved for EPHI backup classification.
- [ ] Encryption at rest/in transit is verified by internal infrastructure owners.
- [ ] Backup retention and access control are approved.
- [ ] Backup record and bundle hashes validate after artifact materialization.
- [ ] Required authoritative namespace removal makes the backup unusable.
- [ ] Dirty-target restore is rejected.
- [ ] Backup generation and artifact IDs are linked to the EPHI release manifest.

## Restore / DR drill

- [ ] Restore into an isolated clean namespace.
- [ ] Restore authoritative state exactly and validate service deserialization.
- [ ] Rebuild rebuildable state from source history where intentionally omitted.
- [ ] Re-run freshness gates before advisory traffic.
- [ ] Re-run required family qualification checks after rebuild/migration.
- [ ] Compare pre-failure and post-recovery episode/assessment signatures on a frozen replay interval.
- [ ] Compare qualification workspace/audit history hashes.
- [ ] Compare validated value-ledger active/history state.
- [ ] Measure RPO and RTO; record observed values rather than targets only.

## State migration / rollback

- [ ] Every state schema change has an explicit migration/rebuild decision.
- [ ] Deterministic migration output is byte-stable for identical input.
- [ ] Semantic projection is unchanged for representation-only migrations.
- [ ] Non-reversible migration blocks rollback in release compatibility.
- [ ] Destructive migration requires a fresh pre-migration backup and explicit change control.
- [ ] Rollback drill uses the same state schema/config/release identity that production would use.

## Queue / crash recovery

- [ ] Shared queue implementation preserves work-ID idempotency.
- [ ] Conflicting reuse of an idempotency key is rejected.
- [ ] Lease expiry/reclaim is tested with real worker termination.
- [ ] Dependency ordering is preserved for ordered jobs.
- [ ] Applied-work ledger survives worker restart.
- [ ] External side effects use approved idempotency/transaction semantics; do not rely solely on the EPHI applied-work ledger.
- [ ] Duplicate and reordered source deliveries are replay-tested.

## Partial outage / fail-soft behavior

- [ ] WIP outage disables/prevents stale exposure priority without disabling valid behavioral health scoring.
- [ ] Quality-model outage removes/marks quality harmfulness unavailable rather than normal.
- [ ] Historical-index outage degrades RCA/history only.
- [ ] Source/canonical/reference/peer hard staleness blocks new scoring.
- [ ] Existing read models visibly carry stale/degraded state where reads remain allowed.
- [ ] Notification behavior during stale assessment state is verified.

## Company deployment

- [ ] `build_recovery_state_store(config)` uses approved shared snapshot-capable storage.
- [ ] `build_artifact_store(config)` points to approved immutable internal artifact storage.
- [ ] No multi-pod path uses SQLite.
- [ ] Recovery restore is operator/admin controlled and not anonymously exposed over HTTP.
- [ ] Backup/restore credentials are separated according to internal least-privilege policy.
- [ ] Operational runbook identifies owners and escalation path.

## Promotion evidence

- [ ] `RELIABILITY_DR` gate is attached before any `OFFLINE_QUALIFIED → SHADOW` promotion.

- [ ] DR drill artifact attached to family/release qualification evidence.
- [ ] Observed RPO/RTO attached.
- [ ] Latest successful backup freshness attached.
- [ ] Migration/rollback compatibility result attached.
- [ ] Unresolved recovery limitations appear in family manifest limitations.
