from __future__ import annotations

import argparse
import json
from time import perf_counter

import numpy as np

from ephi.domain.populations import MaterializedReferenceState
from ephi.populations.columnar_state import ReferenceStateMatrixIndex, stable_state_key_id
from ephi.runtime.columnar import ColumnarBehavioralBatch, ColumnarBehavioralScorer


def run(rows: int = 1_000_000, assets: int = 4, contexts: int = 256, seed: int = 41) -> dict[str, float | int]:
    if rows % assets:
        rows -= rows % assets
    rng = np.random.default_rng(seed)
    states: list[MaterializedReferenceState] = []
    state_keys: list[np.uint64] = []
    state_medians: list[float] = []
    for context in range(contexts):
        context_key = f"CTX-{context:04d}"
        for asset in range(assets):
            asset_id = f"A{asset:03d}"
            median = 100.0 + asset * 0.3 + context * 0.001
            states.append(
                MaterializedReferenceState(
                    asset_id=asset_id,
                    context_key=context_key,
                    feature_id="PRESSURE_MAIN",
                    median=median,
                    mad=0.6,
                    n=120,
                    anchor_median=median,
                    anchor_mad=0.6,
                    anchor_n=60,
                    adequate=True,
                    confidence=1.0,
                    scale_floor=0.05,
                    practical_effect_floor=0.05,
                )
            )
            state_keys.append(stable_state_key_id(asset_id, context_key, "PRESSURE_MAIN"))
            state_medians.append(median)

    index = ReferenceStateMatrixIndex(states)
    groups = rows // assets
    context_idx = rng.integers(0, contexts, size=groups)
    asset_idx = np.arange(assets, dtype=np.int64)
    flattened_state = (context_idx[:, None] * assets + asset_idx[None, :]).reshape(-1)
    key_array = np.asarray(state_keys, dtype=np.uint64)[flattened_state]
    baseline = np.asarray(state_medians, dtype=np.float64)[flattened_state]
    values = baseline + rng.normal(0.0, 0.6, size=rows)
    peer_group = np.repeat(np.arange(groups, dtype=np.int64), assets)

    scorer = ColumnarBehavioralScorer(index)
    batch = ColumnarBehavioralBatch(key_array, peer_group, values)
    scorer.score(ColumnarBehavioralBatch(key_array[: min(rows, 10_000)], peer_group[: min(rows, 10_000)], values[: min(rows, 10_000)]))
    start = perf_counter()
    result = scorer.score(batch)
    elapsed = perf_counter() - start
    return {
        "rows": rows,
        "assets_per_peer_group": assets,
        "contexts": contexts,
        "elapsed_seconds": elapsed,
        "rows_per_second": rows / elapsed,
        "reference_found_fraction": float(result.reference_found.mean()),
        "peer_adequate_fraction": float(result.peer.adequate.mean()),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rows", type=int, default=1_000_000)
    parser.add_argument("--assets", type=int, default=4)
    parser.add_argument("--contexts", type=int, default=256)
    parser.add_argument("--seed", type=int, default=41)
    args = parser.parse_args()
    print(json.dumps(run(args.rows, args.assets, args.contexts, args.seed), indent=2))


if __name__ == "__main__":
    main()
