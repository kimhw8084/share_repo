from __future__ import annotations

import argparse
import json
import time
from collections import defaultdict

from ephi.domain.evidence import Hypothesis
from ephi.domain.health import HealthSeverity
from ephi.health.engine import BehavioralHealthPipeline
from ephi.synthetic.scalar import ScalarScenarioConfig, generate_scalar_observations


def run(seeds: int, executions_per_asset: int) -> dict[str, object]:
    scenarios = ("healthy", "local-drift", "common-mode", "unit-scale-change")
    metrics: dict[tuple[str, str], list[int]] = defaultdict(list)
    t0 = time.perf_counter()
    total_observations = 0

    for scenario in scenarios:
        for seed in range(seeds):
            observations = generate_scalar_observations(
                ScalarScenarioConfig(
                    scenario=scenario,
                    seed=seed,
                    executions_per_asset=executions_per_asset,
                )
            )
            total_observations += len(observations)
            pipeline = BehavioralHealthPipeline()
            result = pipeline.process(observations)
            actionable = [
                a for a in result.assessments if a.severity >= HealthSeverity.INVESTIGATE
            ]
            metrics[(scenario, "actionable")].append(len(actionable))
            metrics[(scenario, "target_actionable")].append(
                sum(a.asset_id == "A000" for a in actionable)
            )
            metrics[(scenario, "common_tail")].append(
                sum(
                    a.leading_hypothesis == Hypothesis.COMMON_MODE_PROCESS_CHANGE
                    for a in result.assessments[-100:]
                )
            )
            metrics[(scenario, "pipeline_lead")].append(
                sum(
                    a.leading_hypothesis == Hypothesis.DATA_PIPELINE_OR_SCHEMA_CHANGE
                    for a in result.assessments
                )
            )

    elapsed = time.perf_counter() - t0
    output: dict[str, object] = {
        "seeds": seeds,
        "executions_per_asset": executions_per_asset,
        "total_observations": total_observations,
        "elapsed_seconds": round(elapsed, 3),
        "observations_per_second": round(total_observations / elapsed),
        "scenarios": {},
    }
    scenario_output: dict[str, object] = {}
    for scenario in scenarios:
        values: dict[str, object] = {}
        for metric in ("actionable", "target_actionable", "common_tail", "pipeline_lead"):
            series = metrics[(scenario, metric)]
            values[metric] = {
                "min": min(series),
                "max": max(series),
                "mean": round(sum(series) / len(series), 3),
            }
        scenario_output[scenario] = values
    output["scenarios"] = scenario_output
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", type=int, default=20)
    parser.add_argument("--executions-per-asset", type=int, default=800)
    args = parser.parse_args()
    print(json.dumps(run(args.seeds, args.executions_per_asset), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
