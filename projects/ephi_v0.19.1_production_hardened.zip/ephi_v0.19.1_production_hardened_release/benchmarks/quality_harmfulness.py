from __future__ import annotations

import json

from ephi.quality.qualification import run_quality_qualification


def main() -> None:
    print(json.dumps(run_quality_qualification().to_dict(), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
