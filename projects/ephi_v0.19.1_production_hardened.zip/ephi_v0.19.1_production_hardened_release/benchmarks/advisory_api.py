from __future__ import annotations

import json
import time
from pathlib import Path

from ephi.advisory.demo import build_demo_advisory_service
from ephi.advisory.read_models import build_episode_view


def run() -> dict[str, float | int]:
    service = build_demo_advisory_service()
    episode_id = service.list_attention()[0].episode_id
    source = service.sources.get(episode_id)
    assert source is not None

    build_iterations = 5000
    start = time.perf_counter()
    for _ in range(build_iterations):
        build_episode_view(
            source.episode,
            source.assessment,
            advisory_context=source.advisory_context,
            quality_associations=source.quality_associations,
        )
    build_seconds = time.perf_counter() - start

    view = service.get_view(episode_id)  # warm cache
    serialization_iterations = 20000
    start = time.perf_counter()
    for _ in range(serialization_iterations):
        view.model_dump_json()
    serialization_seconds = time.perf_counter() - start

    cached_iterations = 200000
    start = time.perf_counter()
    for _ in range(cached_iterations):
        service.get_view(episode_id)
    cached_seconds = time.perf_counter() - start

    return {
        "build_iterations": build_iterations,
        "read_model_build_seconds": build_seconds,
        "read_model_builds_per_second": build_iterations / build_seconds,
        "serialization_iterations": serialization_iterations,
        "json_serialization_seconds": serialization_seconds,
        "json_serializations_per_second": serialization_iterations / serialization_seconds,
        "cached_iterations": cached_iterations,
        "cached_get_seconds": cached_seconds,
        "cached_gets_per_second": cached_iterations / cached_seconds,
    }


if __name__ == "__main__":
    payload = run()
    output = Path("ADVISORY_BENCHMARK_V070.json")
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
