from __future__ import annotations

import argparse
import json
import time

import numpy as np

from ephi.detectors.columnar import score_scalar_arrays
from ephi.populations.materialized import ReferenceStateBatch


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rows", type=int, default=1_000_000)
    args = parser.parse_args()
    n = args.rows
    rng = np.random.default_rng(42)
    values = rng.normal(100.0, 1.0, n)
    reference = ReferenceStateBatch(
        median=np.full(n, 100.0),
        mad=np.full(n, 1.0),
        anchor_median=np.full(n, 100.0),
        anchor_mad=np.full(n, 1.0),
        confidence=np.ones(n),
        adequate=np.ones(n, dtype=bool),
    )
    start = time.perf_counter()
    result = score_scalar_arrays(values, reference)
    elapsed = time.perf_counter() - start
    payload = {
        "rows": n,
        "elapsed_seconds": elapsed,
        "rows_per_second": n / elapsed,
        "finite_scores": int(np.isfinite(result.self_z).sum()),
    }
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
