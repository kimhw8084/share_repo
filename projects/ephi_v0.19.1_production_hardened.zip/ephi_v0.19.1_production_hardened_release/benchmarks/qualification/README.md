# Qualification Benchmarks

This directory contains fixed benchmark truth, not tunable detector configuration.

## Build the synthetic fixed corpus

```bash
PYTHONPATH=src python -m ephi.cli.main benchmark corpus-build \
  --output benchmarks/qualification/SYNTHETIC_GOLDEN_CORPUS.json
```

## Run baseline strict replay

```bash
PYTHONPATH=src python -m ephi.cli.main benchmark run \
  --corpus benchmarks/qualification/SYNTHETIC_GOLDEN_CORPUS.json \
  --method baseline-v0.5 \
  --gate-policy configs/qualification/synthetic_regression.yaml \
  --output SYNTHETIC_QUALIFICATION_V050.json
```

## Run method bake-off

```bash
PYTHONPATH=src python -m ephi.cli.main benchmark bakeoff \
  --corpus benchmarks/qualification/SYNTHETIC_GOLDEN_CORPUS.json \
  --output METHOD_BAKEOFF_V050.json
```

## Run population stress checks

```bash
PYTHONPATH=src python -m ephi.cli.main benchmark stress
```

Internal Golden Corpus cases use the same `BenchmarkCase` schema but set `source_kind: INTERNAL_HISTORY` and are resolved by the company-side `HistoricalBenchmarkLoader`.
