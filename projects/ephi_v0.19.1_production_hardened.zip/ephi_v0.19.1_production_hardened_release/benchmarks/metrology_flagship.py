from __future__ import annotations

import argparse
import json
import time
from collections import Counter

from ephi.domain.evidence import Hypothesis
from ephi.domain.health import HealthSeverity
from ephi.metrology.engine import MetrologyHealthPipeline
from ephi.synthetic.metrology import MetrologyScenarioConfig, generate_metrology_observations


def run_one(scenario: str, seed: int, measurements_per_head: int) -> dict[str, object]:
    observations = generate_metrology_observations(
        MetrologyScenarioConfig(
            n_heads=3,
            measurements_per_head=measurements_per_head,
            scenario=scenario,
            seed=seed,
        )
    )
    pipeline = MetrologyHealthPipeline()
    start = time.perf_counter()
    result = pipeline.process(observations)
    elapsed = time.perf_counter() - start

    actionable = [a for a in result.assessments if a.severity >= HealthSeverity.INVESTIGATE]
    actionable_by_asset = Counter(a.asset_id for a in actionable)
    tail = result.assessments[-150:]
    tail_common_mode = sum(
        a.leading_hypothesis == Hypothesis.COMMON_MODE_PROCESS_CHANGE for a in tail
    )
    return {
        "scenario": scenario,
        "seed": seed,
        "measurements_per_head": measurements_per_head,
        "site_observations": len(observations),
        "measurement_results": len(result.measurements),
        "assessments": len(result.assessments),
        "actionable_assessments": len(actionable),
        "actionable_by_asset": dict(sorted(actionable_by_asset.items())),
        "tail_common_mode_assessments": tail_common_mode,
        "active_local_episodes": len(pipeline.episodes.active()),
        "active_fleet_episodes": len(pipeline.fleet_episodes.active()),
        "elapsed_seconds": elapsed,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Run bounded EPHI metrology qualification batches")
    parser.add_argument(
        "--scenario",
        choices=[
            "healthy",
            "measurement-head-drift",
            "process-shift",
            "remeasure-instability",
            "spatial-head-drift",
        ],
        required=True,
    )
    parser.add_argument("--seed-start", type=int, default=100)
    parser.add_argument("--seeds", type=int, default=5)
    parser.add_argument("--measurements-per-head", type=int, default=900)
    args = parser.parse_args()

    runs = [
        run_one(args.scenario, seed, args.measurements_per_head)
        for seed in range(args.seed_start, args.seed_start + args.seeds)
    ]
    total_actionable = sum(int(r["actionable_assessments"]) for r in runs)
    non_target_actionable = sum(
        sum(int(v) for k, v in r["actionable_by_asset"].items() if k != "METRO001/HEAD_A")
        for r in runs
    )
    payload = {
        "scenario": args.scenario,
        "seed_start": args.seed_start,
        "seeds": args.seeds,
        "measurements_per_head": args.measurements_per_head,
        "total_actionable_assessments": total_actionable,
        "non_target_actionable_assessments": non_target_actionable,
        "runs": runs,
    }
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
