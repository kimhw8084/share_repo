from __future__ import annotations
import json
from ephi.history.qualification import run_history_rca_qualification
if __name__=='__main__':
    print(json.dumps(run_history_rca_qualification().model_dump(mode='json'),indent=2,sort_keys=True))
