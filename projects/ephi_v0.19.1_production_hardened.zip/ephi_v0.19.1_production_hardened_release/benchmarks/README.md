# Performance benchmarks

Machine-readable benchmark harnesses are added as each production analytical capability is implemented. Performance regression is a production qualification gate, not an afterthought.
