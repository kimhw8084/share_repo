# EPHI v0.19.1 Production Hardening Build Validation

## Release identity
- Release: `ephi-0.19.1-4fdffb4b0b25-d27883cf588c`
- Code/config/company-port/OpenCode instruction SHA-256: `4fdffb4b0b259d9ec0d5ffcbab66633316b40942b7983b53688e2595460ac04f`
- Config SHA-256: `d27883cf588cf3697e67ae1d9475cfdc7538c062c99e61c1ef70119b3af66881`
- State schema: `2`

## Clean release-copy regression
- **275 tests accounted for**.
- **274 passed**.
- **1 skipped**: optional PyArrow/DuckDB local integration because `pyarrow` is unavailable in this sandbox.
- Every test domain passes with `DeprecationWarning` promoted to error.
- `compileall` passes for `src`, `company_port/src`, `tests`, and `benchmarks`.

## Concurrency/restart stress
The critical concurrent/restart set was exercised across 12 consecutive iterations: qualification submissions, shadow claims, promotion approval, durable queue claim/reclaim, launch evidence updates, campaign retry/resume, port resume, and expired lease reclamation. All iterations passed with no lost-update/exactly-one-winner regressions.

## Installed-package validation
Both packages were built and installed from the clean release copy using offline-safe `pip --target --no-build-isolation --no-deps`.
- `ephi` = `0.19.1`
- `ephi-company-port` = `0.19.1`
- installed AutoPort qualification = PASS
- installed production-smoke qualification = PASS
- installed port qualification = PASS
- installed family manifest validation = valid `RESEARCH`
- manifest recomputation after build/install artifacts = `MANIFEST_MATCH_AFTER_INSTALL = True`

## Production-smoke qualification
- fully wired reference preflight: **26/26 PASS**
- untouched company scaffold: **25 aggregated blocking gaps**, fail-closed, no traceback
- real generic HTTP process startup/health/version/shutdown: PASS
- AutoPort runtime repository execution: PASS
- SQL capability probes: PASS
- binding integrity tamper rejection: PASS
- boolean-token normalization: PASS
- join-multiplication guard: PASS

## AutoPort hardened behavior
- hostile autoconfiguration coverage: **90.9%** over resolved canonical semantics
- manual semantic decisions: **2**
- generic-core edits required: **0**
- binding manifests are strict/tamper-evident and require resealing after reviewed edits
- full canonical schemas are exposed; unresolved optional fields are explicit NULLs
- missing AutoPort binding mounts fail explicitly
- source-schema fingerprint drift blocks bootstrap
- startup executes zero-row SQL through the real company executor before Data Reality/workers
- incremental `available_at` and ID lookups no longer require fake event windows
- physical partition pruning is conservative and exact canonical predicates remain authoritative
- temporal query windows, IN lists and limits are bounded by runtime policy

## SQL performance simulation
A 250,000-row indexed SQLite reference workload confirmed optimizer pushdown through the hardened canonical subquery:
- incremental `available_at` window: 8,640 rows in ~0.040 s, plan used `IX_RUNS_LOAD`
- event-time window: 8,640 rows in ~0.013 s, plan used `IX_RUNS_DATE`
- no Python-side full-history materialization was required

These numbers are portability/reference measurements, not company warehouse performance claims.

## Qualification planes
All **15** portable v0.19.1 planes are PASS:
1. Behavioral / metrology
2. Quality / harmfulness
3. Exposure / priority
4. Historical intelligence / RCA
5. Value / ROI
6. Shadow / release operations
7. Internal port mechanism
8. Family onboarding
9. Qualification control plane
10. Reliability / DR
11. Metrology shadow launch
12. Campaign execution
13. Campaign observability
14. AutoPort / zero-code onboarding
15. Production smoke / fail-fast runtime integration

## Scope
This release qualifies portable runtime and integration mechanisms. It does not claim internal manufacturing qualification. Exact company table semantics, SQL dialect/API behavior, Data Reality, historical Golden cases, production-scale query plans/runtime, DR drills, and engineer shadow evidence remain required for promotion.
