# EPHI Internal Reliability / DR Runbook

## 1. Pre-deployment classification

1. Run the state inventory against the approved shared backend.
2. Update the family/company reliability policy so every discovered namespace is classified.
3. Treat an unclassified namespace as a release blocker.
4. Review `AUTHORITATIVE` vs `REBUILDABLE` with the subsystem owner.

Portable policy reference: `configs/reliability/reference.yaml`.

## 2. Backup creation

Portable/local drill:

```bash
ephi reliability backup \
  --state-db ./.ephi-state.sqlite3 \
  --release-id <RELEASE_ID> \
  --policy configs/reliability/reference.yaml \
  --output ./state-backup.json

ephi reliability backup-inspect --bundle ./state-backup.json
```

Company deployment should call `ephi_company.recovery.create_state_backup(...)`, which composes the approved snapshot-capable shared state backend and immutable artifact store.

A backup is acceptable only if:

- all hashes validate;
- all required authoritative namespaces exist;
- release/state-schema identity is correct;
- artifact storage confirms the immutable content hash.

## 3. Restore drill

Always restore into an isolated clean target first.

Portable/local drill:

```bash
ephi reliability restore \
  --bundle ./state-backup.json \
  --state-db ./restored-state.sqlite3 \
  --confirm-empty-target
```

Company recovery calls `ephi_company.recovery.restore_state_backup(...)` behind internal change-control/authorization. No HTTP restore endpoint is supplied by EPHI.

## 4. Post-restore validation

1. Restore/deserialize authoritative services.
2. Validate qualification workspace and audit history.
3. Validate Value Ledger claim groups, revisions, and active entries.
4. Validate operational controls/certification history.
5. Validate watermarks/knowledge boundaries.
6. Rebuild any intentionally omitted rebuildable state.
7. Re-run freshness/readiness gates.
8. Replay a frozen recent interval and compare episode/assessment signatures with pre-failure evidence.
9. Keep notifications suppressed until readiness is qualified.

## 5. State migration

For every release-level state schema change:

```bash
ephi operations release-compatibility \
  --source RELEASE_OLD.json \
  --target RELEASE_NEW.json \
  --source-state-schema <OLD> \
  --target-state-schema <NEW> \
  --migration-available
```

Add `--migration-reversible` only when reverse compatibility is actually proven. If a migration is not reversible, rollback must remain blocked after the migration is applied.

## 6. Worker crash / duplicate drill

Verify:

- lease expiry and reclaim;
- exact-one live lease winner under concurrent claim;
- same `work_id` + same content is idempotent;
- same `work_id` + different content is rejected;
- dependency ordering is enforced;
- process crash after applied-work recording but before queue completion does not re-run the handler.

External effects must still use approved system-level idempotency because the EPHI local applied-work ledger cannot atomically cover arbitrary external systems.

## 7. Partial-source outage drill

Exercise at least:

- WIP missing/stale;
- quality-model stale;
- historical-index stale;
- source/canonical hard stale;
- assessment stale.

Confirm each subsystem becomes `DEGRADED`/`UNAVAILABLE` according to capability dependencies rather than propagating a false `NORMAL` state.

## 8. Evidence retention

Attach to the release/family qualification package:

- backup bundle/artifact ID and hashes;
- restore drill output;
- RPO/RTO measurement;
- release compatibility/migration decision;
- replay equivalence report;
- partial-outage readiness report;
- unresolved limitations and owner.
