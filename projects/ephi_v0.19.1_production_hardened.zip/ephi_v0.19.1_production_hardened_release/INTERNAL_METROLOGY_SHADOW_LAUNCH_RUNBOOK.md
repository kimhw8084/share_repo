# Internal Metrology Shadow Launch Runbook

This runbook is the execution sequence for the first metrology-family campaign. Do not skip stages by manually editing receipts or family manifests.

## 1. Freeze identity

Install the exact `ephi` and `ephi-company-port` release. Record `RELEASE_MANIFEST.json`, resolved `EPHI_CONFIG_PATHS`, family ID, config hash, deployment image digest, and target environment.

## 2. Run internal Data Reality

Run the company Data Reality audit on the target family. Required capabilities for the reference metrology launch are `PROCESS_HISTORY`, `METROLOGY`, and `REFERENCE_WAFER`. Resolve required blockers. Persist the audit as an immutable internal artifact. Create an `INTERNAL_MEASURED / DATA_REALITY` evidence receipt bound to the exact release/config.

## 3. Curate internal Golden history

Use the qualification control plane to intake and independently review real historical cases. Export only accepted `INTERNAL_HISTORY` cases. Build `InternalGoldenReplayManifest` from that corpus and a stable source snapshot ID. Synthetic cases are regression-only and cannot substitute.

## 4. Execute strict Golden replay

Replay the accepted corpus with `available_at <= replay_as_of`, the exact release/config, and the saved source snapshot. Persist the qualification output immutably. Attach an `INTERNAL_GOLDEN_REPLAY` receipt only when the internal gate passes.

## 5. Execute production-scale replay

Partition a representative internal history window into a `ProductionReplayManifest`. Preserve source snapshot identity, partition time ranges, and expected row/material counts. Measure source bytes read, rows processed, elapsed time, peak memory, correction replay, restart recovery, queue behavior, and service freshness using the target infrastructure. Internal SLO policy—not portable synthetic throughput—determines PASS/FAIL.

## 6. Build OFFLINE_QUALIFIED dossier

Run `ephi launch dossier` from `RESEARCH → OFFLINE_QUALIFIED`. It must have internal Data Reality, internal Golden replay, measured runtime-scale evidence, and at least one production replay manifest. Any identity/checksum mismatch blocks the dossier.

## 7. Perform DR drill before shadow

On the approved shared state/artifact backends, execute backup/restore and migration/rollback drills. Measure RPO and RTO. Verify authoritative state exactness and rebuildable-state recovery. Attach `RELIABILITY_DR_DRILL` evidence only if the internal DR policy passes.

## 8. Build SHADOW dossier

From the approved offline state, build `OFFLINE_QUALIFIED → SHADOW`. `RELIABILITY_DR` is mandatory. Start with notifications suppressed. Do not enable advisory delivery merely because workers are healthy.

## 9. Collect live shadow evidence

Persist freshness/SLO/source coverage, scoring counts, episode counts, degraded-mode intervals, and release/config identity. Use structured shadow-review assignment and missed-event capture. Attach `SHADOW_RUNTIME` and `ENGINEER_SHADOW` evidence only from real live shadow observations.

## 10. Build SHADOW_QUALIFIED dossier

Generate `SHADOW → SHADOW_QUALIFIED` only after the live runtime and engineer-shadow requirements are satisfied. Feed the resulting gate results into the existing onboarding/promotion control plane. Approval remains admin-governed and immutable.

## Failure handling

- Missing/mutated artifact: recollect or republish; never edit the checksum.
- Config/release mismatch: start a new campaign workspace for the new identity.
- Expired evidence: rerun the relevant measurement.
- Data capability becomes unavailable: block dependent readiness; do not infer normal operation.
- DR failure: stay at or roll back to `OFFLINE_QUALIFIED` until the internal recovery gate is passed.
