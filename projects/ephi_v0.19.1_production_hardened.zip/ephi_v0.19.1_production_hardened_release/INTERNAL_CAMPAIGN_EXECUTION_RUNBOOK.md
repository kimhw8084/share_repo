# EPHI v0.17 Internal Campaign Execution Runbook

## Purpose
v0.17 controls the execution of the first real metrology qualification campaign. It does not add new detector logic. It validates the company evidence adapter, publishes collected evidence immutably, records source-snapshot lineage, resumes failed stages without replaying completed work, and hands a READY dossier into the existing qualification control plane without auto-approval.

## Non-negotiable boundaries
- Real promotion evidence must be `INTERNAL_MEASURED`.
- Every source-bound receipt must identify a registered immutable source snapshot.
- Every company evidence stage must be declared idempotent.
- The campaign controller publishes/verifies evidence through the approved `ArtifactStore`.
- A receipt hash is revalidated from the immutable store when the dossier is built.
- Promotion handoff records gates and creates a promotion package only. Admin approval stays separate.
- The same `campaign_id` + stage uses a deterministic idempotency identity across retries/resume.

## Source-snapshot lineage
The company adapter implements `resolve_source_snapshot(snapshot_id)` and returns `SourceSnapshotLineage` containing release/config/family identity, capture time, as-of time, parent snapshot where applicable, scope, and physical dataset revisions. A source-dependent stage cannot pass until its snapshot lineage is persisted.

For production replay, the evidence receipt and `ProductionReplayManifest` must reference the same source snapshot and `strict_available_at` must remain true.

## Execution sequence
Use `scripts/metrology_campaign_command_sequence.sh` as the exact operator template. The high-level phases are:
1. `ephi launch adapter-validate`
2. `ephi launch campaign-run ... RESEARCH -> OFFLINE_QUALIFIED`
3. `ephi launch handoff`
4. authenticated admin promotion approval
5. `ephi launch campaign-run ... OFFLINE_QUALIFIED -> SHADOW`
6. `ephi launch handoff`
7. authenticated admin shadow approval
8. later SHADOW -> SHADOW_QUALIFIED campaign with live runtime + engineer-shadow evidence

If a stage fails transiently, re-run `campaign-run` with the same `campaign-id`. Completed stages remain passed; the failed stage receives the next bounded attempt. Never create a new campaign ID merely to bypass a failed result.

## Failure semantics
- Adapter descriptor incomplete/non-idempotent -> do not execute.
- Evidence identity mismatch -> stage fails.
- Evidence artifact changes before immutable publish -> stage fails.
- Immutable artifact missing/hash mismatch -> dossier blocks.
- Source snapshot missing/identity mismatch/cycle -> stage fails.
- Duplicate evidence ID with different content -> reject.
- Retry budget exhausted -> operator intervention required.
- Dossier BLOCKED -> no control-plane handoff.
- READY dossier -> may be handed off, but remains unapproved until admin action.

## Portable dry run
The portable dry run deliberately uses `SIMULATED_INTERNAL` evidence:

```bash
ephi launch dry-run --release-manifest RELEASE_MANIFEST.json --inject-retry
```

It must execute the mechanism successfully while still reporting `promotion_ready=false` because simulated evidence cannot satisfy the internal launch policy.
