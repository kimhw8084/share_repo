# EPHI v0.19.1 — Work Environment Start

The company port is a semantic SQL-binding task. Generic EPHI scientific core must not change merely because proprietary table names, SQL syntax, or infrastructure differ.

## 0. Qualify the SQL execution API first

```bash
ephi autopilot db-qualify \
  --executor-module ephi_company.big_data \
  --config <company-config>
```

Do not inspect manufacturing history until parameter binding, subqueries, CASE, casts, timestamp parameters, NULL projection and LIMIT behavior pass.

## 1. Give OpenCode/Gemma a plausible table

Example: `TB_FAB_METRO_HIST probably contains metrology.`

Gemma should inspect metadata/partitions, bounded samples and aggregate statistics, then use the EPHI semantic requirement rather than trusting the name.

```bash
ephi autopilot discover --dataset metrology --hint TB_FAB_METRO_HIST \
  --inspector-module ephi_company.autopilot --config <company-config>
```

## 2. Generate the binding with explicit partition semantics

```bash
ephi autopilot candidate \
  --dataset metrology \
  --table <candidate> \
  --inspector-module ephi_company.autopilot \
  --config <company-config> \
  --partition-column <physical_partition> \
  --partition-source-field event_time \
  --partition-granularity date \
  --watermark-column <knowledge_time_column> \
  --output-binding company_bindings/metrology.yaml
```

Partition source/granularity must be confirmed from the real warehouse. Partition pruning is only a performance hint; EPHI re-applies exact canonical time predicates.

## 3. Intentional SQL edits must be resealed

A stale/tampered `binding_hash` fails closed. After Gemma intentionally edits reviewed SQL:

```bash
ephi autopilot seal-binding --binding company_bindings/metrology.yaml
```

Resolve review items only when their actual manufacturing semantics have been confirmed.

## 4. Repeat for feasible datasets

Prioritize executions + metrology, then signals/FDC, maintenance and quality. Genealogy/WIP/history are additive. Missing optional data should degrade capabilities rather than invent data.

## 5. Generate the strict port config

```bash
ephi autopilot bootstrap \
  --binding company_bindings/executions.yaml \
  --binding company_bindings/metrology.yaml \
  --output-config configs/company/generated.yaml
```

The generated config includes the core `port.required_capabilities` implied by accepted datasets.

## 6. Run the one-shot production preflight

```bash
ephi port production-preflight \
  --preflight-module ephi_company.production_preflight \
  --config configs/company/generated.yaml \
  --deployment-plan configs/deployment/shadow-reference.yaml \
  --release-manifest RELEASE_MANIFEST.json
```

This must pass before Data Reality/replay/workers. It checks all company runtime seams, SQL capability, schema fingerprints, accepted bindings, zero-row runtime SQL compilation and every enabled worker role.

## 7. Continue normal qualification

Only after production preflight:

```text
Data Reality
→ historical replay
→ Golden internal cases
→ production-scale measurement
→ DR drill
→ shadow
→ engineer review
```

Portable/synthetic evidence never becomes `INTERNAL_MEASURED` automatically.
