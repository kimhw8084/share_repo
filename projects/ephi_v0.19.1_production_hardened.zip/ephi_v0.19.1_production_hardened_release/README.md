# EPHI

**Equipment & Process Unit Health Intelligence** portable reference implementation.

EPHI is an evidence-driven semiconductor manufacturing health platform built as a modular monolith with strict manufacturing semantics, versioned analytical state, low-noise episode formation, and a columnar/batch-oriented production data contract.

## Current implementation — v0.19.1

v0.19.1 retains the fully qualified v0.19 AutoPort platform and adds **Production Hardening & Fail-Fast Database Integration**. The company port is now explicitly designed around one narrow integration job: map proprietary manufacturing tables into EPHI's stable semantic datasets through bounded schema/value/join investigation and efficient canonical SQL.

AutoPort ships a machine-readable data-requirements catalog, table-profile and candidate-ranking models, value-aware semantic mapping inference, knowledge-time checks, SQL binding validation, provisional capability/config synthesis, core-change auditing, a fail-closed company schema-inspector contract, OpenCode/Gemma 4 repository rules, and a hostile portability qualification where table/column names are deliberately unfamiliar. Generic scientific behavior remains unchanged.


### v0.19.1 production hardening

- strict tamper-evident binding loader and `autopilot seal-binding`;
- full canonical schema projection with NULL-safe optional fields;
- boolean-token normalization and safer semantic inference;
- repository-compatible SQL runtime without fake event-window requirements;
- conservative date/timestamp partition pruning plus exact canonical predicates;
- bounded query budgets and ISO temporal normalization;
- SQL-engine capability qualification;
- canonical type firewall, semantic/join/query-plan guards;
- source-schema fingerprint/drift detection and zero-row SQL startup preflight;
- fail-closed missing binding mounts;
- one-shot `port production-preflight`;
- formal process-level production-smoke qualification plane.

### AutoPort quick start

```bash
ephi autopilot catalog
ephi autopilot discover --dataset metrology --hint measurement --inspector-module ephi_company.autopilot --config <company-config>
ephi autopilot candidate --dataset metrology --table <candidate> --inspector-module ephi_company.autopilot --config <company-config> --partition-column <partition> --watermark-column <watermark> --output-binding company_bindings/metrology.yaml
ephi autopilot validate-binding --binding company_bindings/metrology.yaml
ephi autopilot bootstrap --binding company_bindings/executions.yaml --binding company_bindings/metrology.yaml --output-config configs/company/generated.yaml
ephi autopilot qualification
```

Read `PORTING_START_HERE.md` before the first internal OpenCode session.

## Install

Core:

```bash
python -m pip install -e .
```

Local analytical environment:

```bash
python -m pip install -e ".[local,dev]"
```

In an offline environment with build dependencies already installed, use `--no-build-isolation` to prevent pip from attempting external dependency resolution.

## Metrology campaign execution

Portable mechanism dry run:

```bash
ephi launch dry-run \
  --release-manifest RELEASE_MANIFEST.json \
  --inject-retry
```

Internal adapter contract validation:

```bash
ephi launch adapter-validate \
  --module ephi_company.launch \
  --release-manifest RELEASE_MANIFEST.json \
  --config configs/base.yaml \
  --config company_port/configs/company.yaml \
  --config configs/families/metrology.yaml
```

The exact internal operator sequence is documented in `scripts/metrology_campaign_command_sequence.sh` and `INTERNAL_CAMPAIGN_EXECUTION_RUNBOOK.md`. Re-running `campaign-run` with the same campaign ID resumes from the first non-passed stage.

## Behavioral replay

```bash
PYTHONPATH=src python -m ephi.cli.main replay synthetic \
  --scenario local-drift \
  --executions-per-asset 800 \
  --seed 7
```

```bash
PYTHONPATH=src python benchmarks/behavioral_vertical_slice.py \
  --seeds 20 \
  --executions-per-asset 800
```

## Metrology replay

```bash
PYTHONPATH=src python -m ephi.cli.main replay metrology \
  --scenario measurement-head-drift \
  --measurements-per-head 900 \
  --seed 100
```

Available metrology scenarios:

- `healthy`
- `measurement-head-drift`
- `process-shift`
- `remeasure-instability`
- `spatial-head-drift`

## Production-columnar benchmark

```bash
PYTHONPATH=src python benchmarks/production_columnar_path.py \
  --rows 1000000 \
  --assets 4 \
  --contexts 256
```

The older scalar-kernel microbenchmark remains available in `benchmarks/columnar_scalar_kernel.py`; it measures a narrower numerical kernel and should not be compared directly with the full grouped-peer path.

## Local columnar workflow

With `.[local,dev]` installed:

```bash
ephi synthetic generate \
  --output ./.ephi-data/synthetic/local-drift \
  --scenario local-drift \
  --assets 4 \
  --executions-per-asset 1000

ephi data audit --root ./.ephi-data/synthetic/local-drift --semantic
```

## API

```bash
ephi api serve --config configs/base.yaml --config configs/local.yaml
```

Current API includes health/version, the typed advisory episode surface, historical/RCA/value reads, read-only shadow-operations status, and read-only campaign qualification/observability views. v0.11 adds `/v1/operations/status`, `/v1/operations/controls`, `/v1/operations/certification`, and `/v1/operations/slo`. Control mutation remains CLI/backend-only until the company authorization adapter is wired. `EpisodeView` is a read model only and cannot recompute detector/model conclusions.

## Core invariants already enforced

1. `event_time` and `available_at` are distinct.
2. Replay cannot silently access future knowledge.
3. Current observations cannot enter their own reference before scoring.
4. Frozen anchors protect against adaptive baseline creep.
5. Peer comparisons use compatible context and cannot multiply a single poisoned peer into fleet truth.
6. Semantic and fast peer paths use the same three-head robust-consensus semantics.
7. Correlated detector/measurement transforms cannot multiply evidence as independent confirmations.
8. Pure common-mode movement does not create local alert storms; it can create one fleet parent episode.
9. Data-pipeline scale discontinuities do not masquerade as equipment emergencies.
10. Low-confidence metrology evidence cannot directly escalate to investigation.
11. Sparse metrology channels use their own persistence clocks.
12. Near-zero statistical MAD cannot create physically absurd evidence without a physical scale floor.
13. Characteristic-specific scale floors can be derived/qualified without embedding fab constants in code.
14. Sequential/references/local episodes/fleet episodes survive checkpoint/restart deterministically.
15. Economics and UI concerns cannot enter technical health logic.
16. Big Data access remains isolated behind adapters/repositories.
17. Company physical names are mapping/configuration concerns, not analytical-code concerns.
18. Missing source capability remains unavailable/partial rather than being interpreted as healthy.
19. Source-scale production execution remains columnar; semantic object replay is retained as the correctness oracle.
20. Quality outcomes cannot enter a training row if already available at prediction cutoff.
21. Intervention-censored material is excluded rather than mislabeled healthy.
22. Equipment-state quality value must beat a context-only M0 baseline before being called useful.
23. Binary quality probabilities are calibrated on a chronological calibration block, not the final test block.
24. Measurement-system uncertainty limits physical-process quality attribution but does not circularly invalidate measurement-system targets.
25. Exposed-vs-control quality evidence is observational support and is never automatically labeled causal.

## Qualification status

Current generation-environment suite:

- **175 passed + 1 optional PyArrow/DuckDB integration test skipped (176 collected)** in this sandbox;
- Python source/tests/benchmarks compile successfully;
- behavioral/metrology Golden Corpus: 9/9 pass, 100% expected actionable recall, 0 false actionable episodes;
- quality/harmfulness synthetic gate: PASS;
- exposure/priority synthetic gate: PASS;
- historical/RCA synthetic gate: PASS;
- Value Ledger/ROI semantic gate: PASS;
- shadow/release-operations gate: PASS;
- internal-port mechanism gate: PASS;
- family-onboarding/qualification-automation gate: PASS;
- OpenAPI exposes 26 typed paths;
- semantic Data Reality contract remains 11 logical datasets;
- Kubernetes shadow template is generated from a versioned provisional deployment plan.

Reference operations qualification verifies certification gates, self-certification rejection, champion isolation, challenger failure isolation, engineer shadow review gating, durable kill switches, freshness persistence, stale/unknown blocking, backfill priority/restart, work-queue idempotency/lease recovery, immutable family promotion history, persisted challenger comparison history, provisional deployment semantics, and rollback safety.

Synthetic results are qualification evidence for the implementation, **not production manufacturing performance claims**.

## Internal port / next gate

Read `INTERNAL_PORT_CHECKLIST.md`, `INTERNAL_QUALIFICATION_CHECKLIST.md`, `INTERNAL_QUALITY_QUALIFICATION_CHECKLIST.md`, `INTERNAL_EXPOSURE_PORT_CHECKLIST.md`, `INTERNAL_HISTORY_RCA_PORT_CHECKLIST.md`, `INTERNAL_VALUE_PORT_CHECKLIST.md`, and `INTERNAL_SHADOW_OPERATIONS_CHECKLIST.md`, `INTERNAL_FAMILY_ONBOARDING_RUNBOOK.md`, `INTERNAL_FAMILY_ONBOARDING_CHECKLIST.md`, `INTERNAL_RELIABILITY_DR_RUNBOOK.md`, and `INTERNAL_RELIABILITY_DR_CHECKLIST.md`.

The next real manufacturing gate is now driven by the v0.13 onboarding workflow:

1. implement the thin approved internal physical `BigDataClient`;
2. map internal datasets/columns and run mapping validation;
3. run the semantic Data Reality Audit on actual Big Data;
4. generate `FAMILY_ONBOARDING_PLAN.json` from the exact release/family policy;
5. close every required-capability blocker rather than overriding it;
6. derive real characteristic-specific scale policies and materialize integer state/peer keys;
7. benchmark Big Data pushdown + Arrow transfer + scorer on actual geometry;
8. curate the **internal** fixed Golden Historical Benchmark Corpus through the independent-review intake registry;
9. satisfy family-specific Golden coverage (healthy/excursion/common-mode/maintenance/data/ambiguous as required);
10. implement `HistoricalBenchmarkLoader` against approved internal materializations;
11. run strict no-lookahead historical replay, stress qualification, and baseline/challenger bake-offs;
12. generate READY capability promotion packages and a validated `OFFLINE_QUALIFIED` family manifest;
13. enter live shadow, populate the stratified engineer-review queue, and capture missed events;
14. require `ENGINEER_SHADOW` plus review coverage before `SHADOW_QUALIFIED`;
14. define and qualify internal `QualityTargetDefinition` objects for the first metrology/process outcomes;
15. build real M0/M1 target snapshots with outcome maturity, sampling, and intervention censoring;
16. run chronological/tool/product/lot-group quality qualification plus measurement-system confounding studies;
17. keep successful quality models in shadow until calibration/applicability and engineer usefulness gates pass;
18. map and qualify WIP routing + `asset_qualification`;
19. validate onset-aware past-material lists against manually reviewed cases;
20. compare possible/likely/committed WIP states with subsequent actual routing;
21. calibrate containment/disposition/RCA priority policy with engineers in replay/shadow mode;
22. proceed to historical analogue/RCA and Value Ledger capability only after operational exposure semantics are trustworthy.

Trace/deep/GPU methods remain challengers until they demonstrate incremental manufacturing value over this baseline.
