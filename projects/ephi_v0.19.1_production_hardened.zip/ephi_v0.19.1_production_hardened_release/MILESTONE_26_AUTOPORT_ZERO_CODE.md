# Milestone 26 — EPHI AutoPort / Zero-Code Onboarding

## Objective
Make the work-environment port primarily a **semantic SQL binding task**. A user may provide only a plausible table name; OpenCode/Gemma inspects bounded schema/value evidence, EPHI validates the candidate against a formal dataset contract, and accepted bindings synthesize strict EPHI configuration without modifying the scientific core.

## Acceptance criteria
- Generic `src/ephi` is not edited for physical company schema differences.
- Every logical dataset has machine-readable purpose, field semantics, aliases, value/validation hints and degradation behavior.
- Candidate tables can be profiled with bounded metadata/sample/statistics interfaces.
- Wrong-but-plausible tables are rejected when required semantics are absent.
- SQL bindings forbid `SELECT *` and mutating SQL, require canonical aliases, knowledge-time mapping and declared partition/watermark pushdown.
- Generated config validates under strict `EphiConfig`.
- AutoPort reports explicit human review items instead of guessing ambiguous physics.
- Company schema inspection is a fail-closed adapter seam.
- Porting instructions and SQL-binding contracts participate in release identity.
- Hostile portability benchmark achieves >=80% autoconfiguration coverage, <=15 manual decisions and zero generic-core changes.

## v0.19 result
The portable hostile benchmark uses deliberately unfamiliar execution/metrology tables plus a plausible wrong equipment-summary table. AutoPort identifies the correct execution and metrology sources, rejects the wrong candidate, generates bounded SQL, validates knowledge-time ordering, synthesizes a strict config, and leaves only the irreducible semantic confirmations for the engineer.

The benchmark is mechanism evidence. It does not claim Samsung internal table acceptance until the company inspector/adapters run against real data.
