# Internal Advisory/API Port Checklist — v0.7.0

The portable v0.7 build should require adapters/configuration rather than analytical rewrites.

## Required internal integration

1. **Advisory source repository**
   - implement `AdvisorySourceRepository` over approved persistent/materialized EPHI state;
   - provide current `HealthEpisode`, `HealthAssessment`, optional quality associations, comparison summary, and exposure summary;
   - preserve stable episode IDs and source versions.

2. **Durable workflow state**
   - use the existing `StateStore` checkpoint contract or implement equivalent approved persistence;
   - workflow/audit/closure/missed-event data are authoritative human records and must not exist only in pod memory.

3. **Identity / permissions**
   - map internal user identity to viewer/engineer/investigator/admin roles;
   - enforce write permissions for acknowledgment, assignment, closure, and missed-event submission;
   - do not implement permissions through client-side UI hiding alone.

4. **Internal notification adapter**
   - render `NotificationPayload` into the internal message API;
   - record `episode_version` last sent to support deduplication;
   - deep-link directly to the episode view;
   - do not reinterpret evidence in the renderer.

5. **Frontend**
   - consume the FastAPI/OpenAPI semantic contract;
   - display severity, confidence, priority, and maturity separately;
   - always surface contradiction state and confidence limitations;
   - raw/high-volume trace/site data should use bounded dedicated endpoints in a later build rather than expanding `EpisodeView`.

6. **Material/WIP data**
   - populate `ExposureSummary` and `MaterialExposureItem` only from qualified exposure/WIP logic;
   - unimplemented exposure remains zero/unknown rather than inferred by the UI.

7. **Configuration**
   - version the presentation policy;
   - keep operational-priority calculation outside the advisory layer;
   - use company terminology/display configuration where appropriate.

## Qualification before internal advisory pilot

- verify OpenAPI client compatibility;
- verify source-repository latency and freshness;
- verify workflow persistence across pod restart;
- verify authorization on every write endpoint;
- verify notification deduplication and deep links;
- verify no analytical conclusion changes between backend source and `EpisodeView`;
- run five-second comprehension review with metrology engineers;
- measure false-actionable episode burden before enabling push notifications.
