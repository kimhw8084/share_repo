from datetime import datetime,timezone
from ephi.domain.rca import *
from ephi.domain.evidence import Hypothesis
from ephi.rca.service import RCAService
T=datetime(2026,1,1,tzinfo=timezone.utc)
def ev(f,diff,rr,temp=TemporalPlausibility.SUPPORTS,health=0.0,rob=1.0):
    return CommonalityEvidence(factor=f,affected_count=9,affected_total=10,control_count=1,control_total=10,affected_prevalence=.9,control_prevalence=.1,prevalence_difference=diff,relative_risk=rr,odds_ratio=10,severity_association=.2,temporal_plausibility=temp,temporal_support=1 if temp is TemporalPlausibility.SUPPORTS else 0,health_support=health,control_robustness=rob,confidence=.9)
def test_health_and_temporal_support_rank_candidate_not_historical_analogy_alone():
    seed=InvestigationSeed(seed_id="S",episode_id="E",asset_id="A",context={},onset_low=T,onset_best=T,onset_high=T,affected_material_ids=("W",),control_set_ids=("C",),leading_hypotheses=(Hypothesis.LOCAL_ASSET_DEGRADATION,))
    good=ev("ASSET:SUSPECT",.8,8,health=1.0)
    future=ev("ASSET:HISTORICAL_FAVORITE",.9,9,temp=TemporalPlausibility.CONTRADICTS)
    out=RCAService().candidates(seed,(future,good),historical_factor_support={"ASSET:HISTORICAL_FAVORITE":1.0})
    assert out[0].factor=="ASSET:SUSPECT"
    assert next(x for x in out if x.factor=="ASSET:HISTORICAL_FAVORITE").confidence_band is CandidateConfidence.CONTRADICTED
