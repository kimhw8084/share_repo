from datetime import datetime,timezone
from ephi.domain.rca import *
from ephi.rca.interactions import rank_top_pairwise
T=datetime(2026,1,1,tzinfo=timezone.utc)
def token(mid,asset,recipe):return RouteToken(material_id=mid,sequence=1,operation='O',asset_id=asset,recipe_id=recipe,event_time=T)
def test_pairwise_is_bounded_and_requires_incremental_lift():
    aff=tuple(AffectedMaterial(material_id=f'A{i}',membership=AffectedMembership.DEFINITE) for i in range(6)); ctrl=(ControlPopulation(control_set_id='C',material_ids=tuple(f'C{i}' for i in range(6)),policy='m'),)
    toks=[]
    # A and recipe X each occur broadly, but their combination is specific to affected.
    for i in range(6):
        toks.append(token(f'A{i}','A','X'))
        toks.append(token(f'C{i}','A' if i<3 else 'B','Y' if i<3 else 'X'))
    out=rank_top_pairwise(aff,ctrl,tuple(toks),candidate_factors=('ASSET:A','RECIPE:X','ASSET:B'),top_k=3)
    assert out and out[0].factor_a in {'ASSET:A','RECIPE:X'} and out[0].factor_b in {'ASSET:A','RECIPE:X'}
    assert out[0].interaction_lift > 0
