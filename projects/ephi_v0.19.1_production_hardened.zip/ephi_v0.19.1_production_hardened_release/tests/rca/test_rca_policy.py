from ephi.rca.policy import load_rca_ranking_policy
def test_rca_policy_loads_external_thresholds():
    p=load_rca_ranking_policy('configs/rca/reference.yaml')
    assert p.version=='rca-ranking-v1' and p.high_score==3.0 and p.health_weight==.9
