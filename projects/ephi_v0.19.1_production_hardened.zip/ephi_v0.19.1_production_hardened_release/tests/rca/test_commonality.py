from datetime import datetime,timezone,timedelta
from ephi.domain.rca import *
from ephi.rca.commonality import CommonalityEngine

T=datetime(2026,1,2,tzinfo=timezone.utc)
def tok(mid,seq,asset,op="O",when=None,health=0,recipe="R"):
    return RouteToken(material_id=mid,sequence=seq,operation=op,asset_id=asset,event_time=when or T-timedelta(hours=2),recipe_id=recipe,health_strength=health)

def test_enrichment_beats_route_commonality_and_post_onset_contradicts():
    aff=tuple(AffectedMaterial(material_id=f"A{i}",membership=AffectedMembership.DEFINITE,severity_weight=1+i/20,outcome_time=T) for i in range(10))
    ctrl=ControlPopulation(control_set_id="C",material_ids=tuple(f"C{i}" for i in range(10)),policy="matched")
    routes=[]
    for i in range(10):
        # routine route factor is equally common in affected and controls
        routes += [tok(f"A{i}",0,"ROUTINE"), tok(f"C{i}",0,"ROUTINE")]
        if i<9: routes.append(tok(f"A{i}",1,"SUSPECT",health=1.2))
        if i<1: routes.append(tok(f"C{i}",1,"SUSPECT"))
    # future-only factor appears in affected but after onset -> temporal contradiction
    for i in range(8): routes.append(tok(f"A{i}",2,"FUTURE",when=T+timedelta(hours=1)))
    out=CommonalityEngine().rank(aff,(ctrl,),tuple(routes),onset_time=T,top_k=50)
    by={x.factor:x for x in out}
    assert by["ASSET:SUSPECT"].prevalence_difference > .7
    assert by["ASSET:ROUTINE"].prevalence_difference == 0
    assert by["ASSET:FUTURE"].temporal_plausibility is TemporalPlausibility.CONTRADICTS

def test_multiple_controls_expose_control_robustness():
    aff=tuple(AffectedMaterial(material_id=f"A{i}",membership=AffectedMembership.DEFINITE) for i in range(4))
    c1=ControlPopulation(control_set_id="C1",material_ids=("C1","C2","C3","C4"),policy="strict")
    c2=ControlPopulation(control_set_id="C2",material_ids=("D1","D2","D3","D4"),policy="broad")
    routes=[tok(x,0,"X") for x in ["A0","A1","A2","A3","C1","D1","D2","D3","D4"]]
    x=next(r for r in CommonalityEngine().rank(aff,(c1,c2),tuple(routes),onset_time=T) if r.factor=="ASSET:X")
    assert x.control_robustness == .5
