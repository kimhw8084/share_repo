from datetime import datetime,timezone
from ephi.domain.context import ContextKey
from ephi.domain.episode import HealthEpisode,EpisodeState
from ephi.domain.evidence import Hypothesis
from ephi.domain.health import HealthAssessment,HealthSeverity,HypothesisSupport
from ephi.domain.exposure import ExposureSnapshot,MaterialExposureAssessment,MaterialExposureClass
from ephi.rca.investigation import build_investigation_seed
T=datetime(2026,1,1,tzinfo=timezone.utc); C=ContextKey("O","R","P","T")
def test_seed_uses_past_affected_material_and_ranked_hypotheses():
    ep=HealthEpisode("E","A",C,T,T,EpisodeState.INVESTIGATE,HealthSeverity.INVESTIGATE,Hypothesis.LOCAL_ASSET_DEGRADATION,3)
    ha=HealthAssessment("H","X","A",C,T,HealthSeverity.INVESTIGATE,.9,3,Hypothesis.LOCAL_ASSET_DEGRADATION,(HypothesisSupport(Hypothesis.LOCAL_ASSET_DEGRADATION,1,.1),),())
    items=(MaterialExposureAssessment(material_id="W1",exposure_class=MaterialExposureClass.DEFINITE_PAST_EXPOSURE,exposure_confidence=1),MaterialExposureAssessment(material_id="W2",exposure_class=MaterialExposureClass.FUTURE_POSSIBLE_EXPOSURE,exposure_confidence=.5))
    ex=ExposureSnapshot(snapshot_id="S",episode_id="E",asset_id="A",operation="O",as_of=T,onset_low=T,onset_best=T,onset_high=T,onset_confidence=1,items=items,definitely_exposed=1,future_possible=1)
    seed=build_investigation_seed(ep,ha,ex)
    assert seed.affected_material_ids==("W1",)
    assert seed.leading_hypotheses[0] is Hypothesis.LOCAL_ASSET_DEGRADATION
