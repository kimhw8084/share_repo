from datetime import datetime, timezone
from ephi.domain.launch import ProductionScaleMeasurement, ReliabilityDrillMeasurement, ShadowRuntimeMeasurement


def test_typed_launch_measurements_keep_observed_metrics_explicit() -> None:
    now = datetime.now(timezone.utc)
    scale = ProductionScaleMeasurement(family_id="F", release_id="R", config_hash="c", source_snapshot_id="S", observed_at=now, rows_processed=1_000_000, elapsed_seconds=10, measured_environment="internal-shadow", passed_internal_slo=True)
    assert scale.rows_per_second == 100_000
    dr = ReliabilityDrillMeasurement(family_id="F", release_id="R", config_hash="c", backup_id="B", observed_at=now, observed_rpo_seconds=10, observed_rto_seconds=100, target_rpo_seconds=60, target_rto_seconds=300, authoritative_restore_exact=True, rebuildable_state_recovered=True, rollback_or_migration_drill_passed=True, passed_internal_dr_policy=True)
    assert dr.observed_rto_seconds < dr.target_rto_seconds
    shadow = ShadowRuntimeMeasurement(family_id="F", release_id="R", config_hash="c", observed_at=now, observation_hours=24, scored_executions=1000, generated_episodes=3, notifications_suppressed=True, passed_internal_shadow_slo=True)
    assert shadow.notifications_suppressed
