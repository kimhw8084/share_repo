from datetime import datetime, timezone
from ephi.domain.capabilities import Capability
from ephi.domain.data_reality import CapabilityAssessment, DataRealityReport, QualificationState
from ephi.domain.operations import CertificationState
from ephi.launch.planner import build_metrology_shadow_launch_plan
from ephi.launch.policy import load_launch_policy


def test_launch_plan_blocks_data_reality_from_different_config() -> None:
    policy=load_launch_policy("configs/launch/metrology_reference.yaml")
    report=DataRealityReport(datasets=(), joins=(), capabilities=tuple(
        CapabilityAssessment(capability=c,state=QualificationState.QUALIFIED) for c in policy.required_capabilities
    ), generated_at="x", config_hash="wrong")
    plan=build_metrology_shadow_launch_plan(
        family_id=policy.family_id, release_id="R", config_hash="right",
        current_state=CertificationState.RESEARCH, target_state=CertificationState.OFFLINE_QUALIFIED,
        policy=policy, data_reality=report, generated_at=datetime.now(timezone.utc),
    )
    assert any("config hash mismatch" in b for b in plan.blockers)
