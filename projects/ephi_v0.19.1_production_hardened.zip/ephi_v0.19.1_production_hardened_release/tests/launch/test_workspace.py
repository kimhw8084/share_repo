from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.launch import EvidenceDecision, EvidenceProvenance, LaunchEvidenceKind, LaunchEvidenceReceipt
from ephi.launch.registry import ShadowLaunchWorkspaceRepository


def test_concurrent_evidence_receipts_do_not_lose_updates(tmp_path) -> None:
    path = tmp_path / "state.sqlite3"
    now = datetime.now(timezone.utc)
    def attach(i: int):
        repo = ShadowLaunchWorkspaceRepository(SqliteStateStore(path))
        return repo.attach_evidence(LaunchEvidenceReceipt(
            evidence_id=f"E{i}", family_id="MET", release_id="R", config_hash="c"*64,
            kind=LaunchEvidenceKind.DATA_REALITY, provenance=EvidenceProvenance.INTERNAL_MEASURED,
            decision=EvidenceDecision.PASS, artifact=f"a{i}", artifact_sha256=f"{i:064x}"[-64:], observed_at=now,
        ), actor=f"u{i}")
    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(attach, range(8)))
    final = ShadowLaunchWorkspaceRepository(SqliteStateStore(path)).load("MET")
    assert len(final.evidence) == 8
    assert len(final.audit) == 8
