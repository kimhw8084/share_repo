from datetime import datetime, timezone
import pytest
from ephi.domain.benchmark import BenchmarkCase, BenchmarkCaseType, BenchmarkCorpus, BenchmarkFamily, BenchmarkLabelConfidence, BenchmarkSourceKind
from ephi.launch.golden import build_internal_golden_replay_manifest


def test_internal_golden_manifest_rejects_synthetic_cases() -> None:
    now = datetime.now(timezone.utc)
    corpus = BenchmarkCorpus(corpus_id="c", version="1", created_at=now, description="x", cases=(BenchmarkCase(
        case_id="x", family=BenchmarkFamily.METROLOGY, case_type=BenchmarkCaseType.HEALTHY,
        source_kind=BenchmarkSourceKind.SYNTHETIC_METROLOGY, scenario="healthy", label_confidence=BenchmarkLabelConfidence.CONFIRMED,
    ),))
    with pytest.raises(ValueError, match="synthetic"):
        build_internal_golden_replay_manifest(corpus=corpus, family_id="F", release_id="R", config_hash="c", source_snapshot_id="S", replay_as_of=now)
