from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from ephi.adapters.local.filesystem_artifact_store import FileSystemArtifactStore
from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.benchmark import BenchmarkCaseType, BenchmarkFamily, BenchmarkLabelConfidence
from ephi.domain.launch import CampaignStage, CampaignStageStatus, EvidenceProvenance
from ephi.domain.onboarding import FamilyOnboardingPlan, GoldenCaseIntake, GoldenCurationState
from ephi.domain.operations import CertificationState
from ephi.launch.execution import CampaignExecutionController
from ephi.launch.handoff import handoff_launch_dossier
from ephi.launch.policy import load_launch_policy
from ephi.launch.reference_executor import ReferenceLaunchEvidenceExecutor
from ephi.launch.registry import ShadowLaunchWorkspaceRepository
from ephi.onboarding.control_plane import QualificationControlPlaneService
from ephi.onboarding.control_repository import QualificationWorkspaceRepository
from ephi.onboarding.policy import FamilyOnboardingPolicy, GoldenCoveragePolicy


NOW = datetime(2026, 8, 19, 20, 30, tzinfo=timezone.utc)
FAMILY = "METROLOGY_REFERENCE"
RELEASE = "ephi-0.17.0-test"
CONFIG = "b" * 64


def _controller(tmp_path: Path, *, fail_once=frozenset(), provenance=EvidenceProvenance.SIMULATED_INTERNAL):
    executor = ReferenceLaunchEvidenceExecutor(
        tmp_path / "collected",
        family_id=FAMILY,
        release_id=RELEASE,
        config_hash=CONFIG,
        fail_once=fail_once,
        provenance=provenance,
    )
    repo = ShadowLaunchWorkspaceRepository(SqliteStateStore(tmp_path / "launch.sqlite3"))
    controller = CampaignExecutionController(
        family_id=FAMILY,
        release_id=RELEASE,
        config_hash=CONFIG,
        executor=executor,
        repository=repo,
        artifact_store=FileSystemArtifactStore(tmp_path / "artifacts"),
        required_provenance=provenance,
    )
    return controller, executor, repo


def test_campaign_retry_resume_publishes_immutable_evidence_and_lineage(tmp_path: Path) -> None:
    controller, executor, repo = _controller(
        tmp_path,
        fail_once=frozenset({CampaignStage.PRODUCTION_REPLAY_SCALE}),
    )
    with pytest.raises(RuntimeError, match="injected first-attempt failure"):
        controller.run(
            campaign_id="C1",
            target_state=CertificationState.OFFLINE_QUALIFIED,
            actor="engineer",
        )
    failed = repo.campaign(FAMILY, "C1")
    assert failed is not None
    assert failed.latest_attempt(CampaignStage.DATA_REALITY).status == CampaignStageStatus.PASSED
    assert failed.latest_attempt(CampaignStage.INTERNAL_GOLDEN_REPLAY).status == CampaignStageStatus.PASSED
    assert failed.latest_attempt(CampaignStage.PRODUCTION_REPLAY_SCALE).status == CampaignStageStatus.FAILED

    resumed = controller.run(
        campaign_id="C1",
        target_state=CertificationState.OFFLINE_QUALIFIED,
        actor="engineer",
    )
    assert all(resumed.stage_passed(stage) for stage in (
        CampaignStage.DATA_REALITY,
        CampaignStage.INTERNAL_GOLDEN_REPLAY,
        CampaignStage.PRODUCTION_REPLAY_SCALE,
    ))
    assert executor.calls[CampaignStage.DATA_REALITY] == 1
    assert executor.calls[CampaignStage.INTERNAL_GOLDEN_REPLAY] == 1
    assert executor.calls[CampaignStage.PRODUCTION_REPLAY_SCALE] == 2

    workspace = repo.load(FAMILY)
    assert len(workspace.source_snapshots) == 1
    assert workspace.source_snapshots[0].snapshot_id == executor.snapshot_id
    assert all(item.artifact_ref is not None for item in workspace.evidence)
    assert len(workspace.replay_manifests) == 1


def test_campaign_dossier_uses_artifact_store_and_simulated_evidence_remains_blocked(tmp_path: Path) -> None:
    controller, _, _ = _controller(tmp_path)
    campaign = controller.run(
        campaign_id="C2",
        target_state=CertificationState.OFFLINE_QUALIFIED,
        actor="engineer",
    )
    dossier = controller.build_dossier(
        campaign_id=campaign.campaign_id,
        current_state=CertificationState.RESEARCH,
        target_state=CertificationState.OFFLINE_QUALIFIED,
        policy=load_launch_policy("configs/launch/metrology_reference.yaml"),
    )
    assert not dossier.promotion_ready
    assert dossier.source_snapshots
    assert dossier.campaign_id == "C2"
    assert any("INTERNAL_MEASURED" in blocker for blocker in dossier.blockers)


def test_launch_dossier_handoff_is_restartable_and_does_not_auto_approve(tmp_path: Path) -> None:
    controller, _, _ = _controller(tmp_path, provenance=EvidenceProvenance.INTERNAL_MEASURED)
    campaign = controller.run(
        campaign_id="C3",
        target_state=CertificationState.OFFLINE_QUALIFIED,
        actor="collector",
    )
    dossier = controller.build_dossier(
        campaign_id=campaign.campaign_id,
        current_state=CertificationState.RESEARCH,
        target_state=CertificationState.OFFLINE_QUALIFIED,
        policy=load_launch_policy("configs/launch/metrology_reference.yaml"),
    )
    assert dossier.promotion_ready

    policy = FamilyOnboardingPolicy(
        family_id=FAMILY,
        target_state=CertificationState.OFFLINE_QUALIFIED,
        required_capabilities=(),
        golden=GoldenCoveragePolicy(
            min_cases=1,
            min_high_confidence_cases=0,
            required_case_types=(),
            require_internal_history=True,
        ),
    )
    control = QualificationControlPlaneService(
        QualificationWorkspaceRepository(SqliteStateStore(tmp_path / "qualification.sqlite3")),
        policy_resolver=lambda _: policy,
    )
    plan = FamilyOnboardingPlan(
        family_id=FAMILY,
        release_id=RELEASE,
        generated_at=NOW,
        current_state=CertificationState.RESEARCH,
        target_state=CertificationState.OFFLINE_QUALIFIED,
        required_capabilities=(),
        gaps=(),
        actions=(),
        blockers=(),
    )
    control.register_plan(plan, actor="admin", command_id="plan-1", at=NOW)
    intake = GoldenCaseIntake(
        intake_id="G1",
        family=BenchmarkFamily.METROLOGY,
        case_type=BenchmarkCaseType.HEALTHY,
        source_locator="internal://golden/G1",
        submitted_by="placeholder",
        submitted_at=NOW,
        scope_start=NOW - timedelta(days=2),
        scope_end=NOW - timedelta(days=1),
        label_confidence=BenchmarkLabelConfidence.CONFIRMED,
        evidence_refs=("internal://evidence/G1",),
    )
    control.submit_golden(FAMILY, intake, actor="submitter", command_id="golden-submit", at=NOW)
    control.review_golden(
        FAMILY, "G1", state=GoldenCurationState.ACCEPTED,
        actor="reviewer", command_id="golden-review", at=NOW,
    )

    first = handoff_launch_dossier(
        dossier=dossier,
        control_plane=control,
        actor="admin",
        command_prefix="C3-handoff",
    )
    second = handoff_launch_dossier(
        dossier=dossier,
        control_plane=control,
        actor="admin",
        command_prefix="C3-handoff",
    )
    assert first.package_id == second.package_id
    assert second.reused_commands
    workspace = control.workspace(FAMILY)
    assert len(workspace.promotion_records) == 1
    assert workspace.promotion_records[0].package.decision.value == "READY"
    assert not workspace.family_manifests  # explicit admin approval remains a separate action
