from ephi.launch.execution_qualification import run_campaign_execution_qualification


def test_campaign_execution_qualification_passes() -> None:
    report = run_campaign_execution_qualification()
    assert report.passed
    assert report.retry_resume_preserves_completed_stages
    assert report.artifact_tamper_blocked
    assert report.promotion_handoff_idempotent
    assert report.promotion_handoff_no_auto_approval
