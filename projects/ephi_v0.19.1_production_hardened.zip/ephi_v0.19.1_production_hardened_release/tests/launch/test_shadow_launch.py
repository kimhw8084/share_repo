from ephi.launch.qualification import run_launch_qualification


def test_shadow_launch_qualification_gate_passes() -> None:
    report = run_launch_qualification()
    assert report.passed, report.model_dump()
