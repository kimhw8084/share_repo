from datetime import datetime, timedelta, timezone
import pytest
from ephi.domain.launch import ProductionReplayManifest, ReplayPartition


def test_production_replay_requires_strict_knowledge_time() -> None:
    now = datetime.now(timezone.utc)
    part = ReplayPartition(partition_id="p", start_time=now-timedelta(days=2), end_time=now-timedelta(days=1), scope="x")
    with pytest.raises(ValueError, match="available_at"):
        ProductionReplayManifest(replay_id="r", family_id="f", release_id="rel", config_hash="c", replay_as_of=now, strict_available_at=False, partitions=(part,))
