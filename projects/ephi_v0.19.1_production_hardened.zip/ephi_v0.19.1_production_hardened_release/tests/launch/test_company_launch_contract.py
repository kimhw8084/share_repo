import importlib.util
from pathlib import Path
from ephi.launch.contract import validate_launch_module


def test_company_launch_scaffold_exposes_fail_closed_factory() -> None:
    path = Path("company_port/src/ephi_company/launch.py")
    spec = importlib.util.spec_from_file_location("ephi_company_launch_contract_test", path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    assert validate_launch_module(module).valid
