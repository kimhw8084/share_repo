from ephi.domain.evidence import Hypothesis
from ephi.domain.health import HealthSeverity
from ephi.metrology.engine import MetrologyHealthPipeline
from ephi.synthetic.metrology import MetrologyScenarioConfig, generate_metrology_observations


def _run(scenario: str, *, seed: int = 17, n: int = 900):
    pipeline = MetrologyHealthPipeline()
    result = pipeline.process(
        generate_metrology_observations(
            MetrologyScenarioConfig(
                n_heads=3,
                measurements_per_head=n,
                scenario=scenario,
                seed=seed,
            )
        )
    )
    return pipeline, result


def test_metrology_healthy_has_no_actionable_episode() -> None:
    pipeline, result = _run("healthy", n=700)
    assert not [a for a in result.assessments if a.severity >= HealthSeverity.INVESTIGATE]
    assert not pipeline.episodes.active()


def test_head_measurement_drift_isolated_to_target_head() -> None:
    pipeline, result = _run("measurement-head-drift")
    target = [
        a for a in result.assessments
        if a.asset_id == "METRO001/HEAD_A" and a.severity >= HealthSeverity.INVESTIGATE
    ]
    assert target
    assert any(a.leading_hypothesis == Hypothesis.METROLOGY_SYSTEM_SHIFT for a in target)
    assert not [
        a for a in result.assessments
        if a.asset_id != "METRO001/HEAD_A" and a.severity >= HealthSeverity.INVESTIGATE
    ]
    assert any(e.asset_id == "METRO001/HEAD_A" for e in pipeline.episodes.active())


def test_real_process_shift_is_common_mode_not_measurement_system_failure() -> None:
    pipeline, result = _run("process-shift")
    assert not [a for a in result.assessments if a.severity >= HealthSeverity.INVESTIGATE]
    late = result.assessments[-180:]
    assert any(a.leading_hypothesis == Hypothesis.COMMON_MODE_PROCESS_CHANGE for a in late)
    assert not pipeline.episodes.active()


def test_remeasure_instability_can_open_measurement_system_episode() -> None:
    pipeline, result = _run("remeasure-instability", n=1200)
    target = [
        a for a in result.assessments
        if a.asset_id == "METRO001/HEAD_A" and a.severity >= HealthSeverity.INVESTIGATE
    ]
    assert target
    assert any(a.leading_hypothesis == Hypothesis.METROLOGY_SYSTEM_SHIFT for a in target)


def test_spatial_head_drift_isolated_to_target_head() -> None:
    pipeline, result = _run("spatial-head-drift")
    target = [
        a for a in result.assessments
        if a.asset_id == "METRO001/HEAD_A" and a.severity >= HealthSeverity.INVESTIGATE
    ]
    assert target
    assert any(a.leading_hypothesis == Hypothesis.METROLOGY_SYSTEM_SHIFT for a in target)
    assert not [
        a for a in result.assessments
        if a.asset_id != "METRO001/HEAD_A" and a.severity >= HealthSeverity.INVESTIGATE
    ]
