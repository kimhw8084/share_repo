from collections import Counter

from ephi.domain.evidence import Hypothesis
from ephi.domain.health import HealthSeverity
from ephi.health.engine import BehavioralHealthPipeline
from ephi.synthetic.scalar import ScalarScenarioConfig, generate_scalar_observations


def _run(scenario: str, *, seed: int = 7):
    pipeline = BehavioralHealthPipeline()
    observations = generate_scalar_observations(
        ScalarScenarioConfig(
            n_assets=4,
            executions_per_asset=1000,
            scenario=scenario,
            seed=seed,
        )
    )
    result = pipeline.process(observations)
    return pipeline, result


def test_healthy_has_no_actionable_episode() -> None:
    pipeline, result = _run("healthy")
    assert not pipeline.episodes.active()
    assert not pipeline.episodes.history()
    assert max((a.severity for a in result.assessments), default=HealthSeverity.NORMAL) < HealthSeverity.INVESTIGATE


def test_local_drift_creates_target_local_episode_without_peer_flood() -> None:
    pipeline, result = _run("local-drift")
    target_actionable = [
        a for a in result.assessments
        if a.asset_id == "A000" and a.severity >= HealthSeverity.INVESTIGATE
    ]
    assert target_actionable
    assert any(a.leading_hypothesis == Hypothesis.LOCAL_ASSET_DEGRADATION for a in target_actionable)

    other_actionable = [
        a for a in result.assessments
        if a.asset_id != "A000" and a.severity >= HealthSeverity.INVESTIGATE
    ]
    assert not other_actionable
    assert any(e.asset_id == "A000" for e in pipeline.episodes.active())


def test_common_mode_redirects_hypothesis_and_suppresses_local_actionable_events() -> None:
    pipeline, result = _run("common-mode")
    late = [a for a in result.assessments if a.event_time >= result.assessments[-1].event_time]
    counts = Counter(a.leading_hypothesis for a in result.assessments[-80:])
    assert counts[Hypothesis.COMMON_MODE_PROCESS_CHANGE] > 0
    assert not [a for a in result.assessments if a.severity >= HealthSeverity.INVESTIGATE]
    assert not pipeline.episodes.active()
    assert pipeline.fleet_episodes.active()


def test_unit_scale_change_is_classified_as_pipeline_suspect_not_equipment_emergency() -> None:
    pipeline, result = _run("unit-scale-change")
    target = [a for a in result.assessments if a.asset_id == "A000"]
    assert any(a.leading_hypothesis == Hypothesis.DATA_PIPELINE_OR_SCHEMA_CHANGE for a in target)
    assert not [a for a in target if a.severity >= HealthSeverity.INVESTIGATE]
    assert not pipeline.episodes.active()


def test_slow_gradual_drift_is_not_absorbed_by_adaptive_reference() -> None:
    pipeline = BehavioralHealthPipeline()
    result = pipeline.process(
        generate_scalar_observations(
            ScalarScenarioConfig(
                n_assets=4,
                executions_per_asset=1600,
                scenario="local-drift",
                seed=3,
            )
        )
    )
    target_actionable = [
        a for a in result.assessments
        if a.asset_id == "A000" and a.severity >= HealthSeverity.INVESTIGATE
    ]
    assert target_actionable
    assert all(a.leading_hypothesis == Hypothesis.LOCAL_ASSET_DEGRADATION for a in target_actionable)
