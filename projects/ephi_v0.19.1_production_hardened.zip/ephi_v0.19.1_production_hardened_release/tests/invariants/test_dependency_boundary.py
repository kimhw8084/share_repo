from pathlib import Path


FORBIDDEN = ("fastapi", "ephi.api", "ephi.value")


def test_domain_does_not_import_high_layers() -> None:
    root = Path(__file__).parents[2] / "src" / "ephi" / "domain"
    for path in root.glob("*.py"):
        text = path.read_text(encoding="utf-8")
        for forbidden in FORBIDDEN:
            assert forbidden not in text, f"{path} imports/mentions forbidden dependency {forbidden}"
