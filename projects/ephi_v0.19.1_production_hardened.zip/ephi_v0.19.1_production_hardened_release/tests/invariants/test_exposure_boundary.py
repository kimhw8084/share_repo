import ast
from pathlib import Path
ROOT=Path(__file__).parents[2]/"src"/"ephi"/"exposure"
def test_no_detector_or_value_imports():
    for p in ROOT.glob("*.py"):
        t=ast.parse(p.read_text())
        for n in ast.walk(t):
            if isinstance(n,ast.ImportFrom) and n.module: assert not n.module.startswith(("ephi.detectors","ephi.value"))
