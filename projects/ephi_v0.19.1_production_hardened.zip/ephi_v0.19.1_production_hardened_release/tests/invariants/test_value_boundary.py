from pathlib import Path


def test_value_layer_is_downstream_and_never_imported_by_scientific_truth_stack() -> None:
    root = Path(__file__).parents[2] / "src" / "ephi"
    protected = [
        root / "features", root / "populations", root / "detectors", root / "evidence",
        root / "health", root / "quality", root / "episodes",
    ]
    offenders: list[str] = []
    for directory in protected:
        for path in directory.rglob("*.py"):
            if "ephi.value" in path.read_text(encoding="utf-8"):
                offenders.append(str(path.relative_to(root)))
    assert offenders == []
