from pathlib import Path


def test_qualification_control_plane_consumes_evidence_but_does_not_run_science() -> None:
    text = (Path(__file__).parents[2] / "src/ephi/onboarding/control_plane.py").read_text(encoding="utf-8")
    forbidden = (
        "ephi.detectors", "ephi.quality.modeling", "ephi.rca.commonality",
        "ephi.metrology.engine", "ephi.health.engine",
    )
    for token in forbidden:
        assert token not in text
