from pathlib import Path


def test_health_detection_stack_does_not_import_value_or_exposure() -> None:
    root = Path(__file__).parents[2] / "src" / "ephi"
    protected = [root / "features", root / "populations", root / "detectors", root / "evidence"]
    forbidden = ("ephi.value", "ephi.exposure")
    offenders: list[str] = []
    for directory in protected:
        for path in directory.rglob("*.py"):
            text = path.read_text(encoding="utf-8")
            if any(token in text for token in forbidden):
                offenders.append(str(path.relative_to(root)))
    assert offenders == []
