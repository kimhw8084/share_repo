from pathlib import Path


FORBIDDEN = ("ephi.detectors", "ephi.quality.modeling", "ephi.rca.commonality")


def test_operations_layer_does_not_recompute_scientific_truth() -> None:
    root = Path(__file__).parents[2] / "src/ephi/operations"
    for path in root.glob("*.py"):
        text = path.read_text(encoding="utf-8")
        for forbidden in FORBIDDEN:
            assert forbidden not in text, f"{path} must not import scientific implementation {forbidden}"
