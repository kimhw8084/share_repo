from pathlib import Path


def test_company_specific_code_stays_outside_generic_ephi_package():
    root = Path("src/ephi")
    forbidden_imports = ("import ephi_company", "from ephi_company")
    forbidden_physical_tokens = ("INTERNAL_REGISTRY", "__MAP_INTERNAL_")
    for path in root.rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        for token in forbidden_imports + forbidden_physical_tokens:
            assert token not in text, f"company-specific dependency {token} leaked into {path}"
