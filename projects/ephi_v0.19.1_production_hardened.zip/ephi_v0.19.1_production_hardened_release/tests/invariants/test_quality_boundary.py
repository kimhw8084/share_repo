from pathlib import Path


def test_detector_population_stack_does_not_depend_on_quality_models() -> None:
    root = Path(__file__).parents[2] / "src" / "ephi"
    protected = [root / "features", root / "populations", root / "detectors"]
    offenders = []
    for directory in protected:
        for path in directory.rglob("*.py"):
            text = path.read_text(encoding="utf-8")
            if "ephi.quality" in text:
                offenders.append(str(path.relative_to(root)))
    assert offenders == []
