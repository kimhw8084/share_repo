from pathlib import Path


def test_advisory_layer_does_not_import_analytical_implementations() -> None:
    root = Path(__file__).parents[2] / "src" / "ephi" / "advisory"
    prohibited = (
        "ephi.detectors",
        "ephi.populations",
        "ephi.quality.modeling",
        "ephi.quality.association",
        "ephi.metrology.engine",
        "ephi.health.engine",
    )
    for path in root.glob("*.py"):
        text = path.read_text(encoding="utf-8")
        for token in prohibited:
            assert token not in text, f"{path.name} must not import {token}"
