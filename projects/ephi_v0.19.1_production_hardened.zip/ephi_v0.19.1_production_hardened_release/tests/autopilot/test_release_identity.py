from pathlib import Path
from tempfile import TemporaryDirectory
import shutil

from ephi.config import EphiConfig
from ephi.registry.releases import build_release_manifest


def test_autopilot_instructions_participate_in_release_identity():
    root = Path(".").resolve()
    with TemporaryDirectory() as td:
        copy = Path(td) / "repo"
        for name in ("src", "configs", "company_port", "scripts", "company_bindings", ".opencode", "docs"):
            source = root / name
            if source.exists():
                shutil.copytree(source, copy / name)
        for name in ("pyproject.toml", "Dockerfile", ".env.example", "AGENTS.md", "opencode.json", "CUSTOMIZATION_MAP.yaml", "PORTING_START_HERE.md"):
            if (root / name).exists():
                (copy / name).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(root / name, copy / name)
        before = build_release_manifest(copy, EphiConfig()).code_tree_sha256
        p = copy / "AGENTS.md"
        p.write_text(p.read_text(encoding="utf-8") + "\n# changed\n", encoding="utf-8")
        after = build_release_manifest(copy, EphiConfig()).code_tree_sha256
        assert before != after
