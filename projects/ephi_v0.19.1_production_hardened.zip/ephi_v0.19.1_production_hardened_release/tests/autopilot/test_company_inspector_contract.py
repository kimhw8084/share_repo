from pathlib import Path


def test_company_autopilot_scaffold_is_fail_closed_and_bounded():
    text = Path("company_port/src/ephi_company/autopilot.py").read_text(encoding="utf-8")
    assert "CompanySchemaInspector" in text
    assert "PhysicalTableProfile" in text
    assert "CompanyPortNotConfiguredError" in text
    assert "unbounded" in text
