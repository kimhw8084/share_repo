from __future__ import annotations

from dataclasses import replace
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

from ephi.adapters.base.big_data import Predicate, PredicateOp, QuerySpec
from ephi.adapters.company.sql_bound_client import SqlBindingRegistry, SqlTemplateBigDataClient
from ephi.autopilot.dialect import qualify_sql_executor
from ephi.autopilot.guards import assess_join_explosion
from ephi.autopilot.inference import infer_dataset_mapping, proposal_to_sql_binding
from ephi.autopilot.inspect import SqliteTableInspector
from ephi.autopilot.models import PhysicalColumnProfile, PhysicalTableProfile, load_sql_binding
from ephi.autopilot.qualification import _build_hostile_db
from ephi.autopilot.sqlite_runtime import SqliteSqlExecutor
from ephi.autopilot.type_firewall import CanonicalTypeFirewall
from ephi.autopilot.validation import validate_sql_binding
from ephi.repositories.executions import ProcessExecutionRepository


def _binding_pair(root: Path):
    db = root / "hostile.db"
    _build_hostile_db(db)
    inspector = SqliteTableInspector(db)
    out = []
    for dataset, table, partition in (
        ("executions", "FAB_FLOW_ARCHIVE_X7", "PROC_DATE"),
        ("metrology", "MEASUREMENT_VAULT_Q", "MEAS_DATE"),
    ):
        prop = infer_dataset_mapping(dataset, inspector.profile(table))
        binding = proposal_to_sql_binding(
            prop,
            partition_column=partition,
            partition_source_field="event_time",
            partition_granularity="date",
            watermark_column="LOAD_DTTM",
        )
        path = root / f"{dataset}.yaml"
        binding.save(path)
        out.append((binding, path))
    return db, out


def test_binding_hash_and_unknown_keys_fail_closed():
    with TemporaryDirectory() as td:
        root = Path(td)
        _, pairs = _binding_pair(root)
        _, path = pairs[0]
        assert load_sql_binding(path).logical_dataset == "executions"
        text = path.read_text().replace("RUN_KEY", "RUN_KEY || ''", 1)
        path.write_text(text)
        with pytest.raises(ValueError, match="binding_hash mismatch"):
            load_sql_binding(path)
        path.write_text(path.read_text() + "typo_field: true\n")
        with pytest.raises(ValueError, match="unknown binding keys"):
            load_sql_binding(path, verify_hash=False)


def test_full_canonical_schema_projects_optional_nulls_and_material_can_be_missing():
    profile = PhysicalTableProfile("RUNS", (
        PhysicalColumnProfile("RUN_ID", "VARCHAR", distinct_count=2, sample_values=("R1", "R2")),
        PhysicalColumnProfile("TOOL_ID", "VARCHAR", distinct_count=1, sample_values=("T1", "T1")),
        PhysicalColumnProfile("END_TS", "TIMESTAMP", distinct_count=2, sample_values=("2026-01-01 10:00:00", "2026-01-01 11:00:00")),
        PhysicalColumnProfile("LOAD_TS", "TIMESTAMP", distinct_count=2, sample_values=("2026-01-01 10:01:00", "2026-01-01 11:01:00")),
    ), row_count=2, sample_records=(
        {"END_TS":"2026-01-01 10:00:00","LOAD_TS":"2026-01-01 10:01:00"},
        {"END_TS":"2026-01-01 11:00:00","LOAD_TS":"2026-01-01 11:01:00"},
    ))
    proposal = infer_dataset_mapping("executions", profile)
    assert "material_id" not in proposal.missing_required
    binding = proposal_to_sql_binding(proposal)
    assert "NULL AS material_id" in binding.sql
    assert "material_id" not in binding.columns
    assert validate_sql_binding(binding).passed


def test_reference_flag_not_stolen_by_y_coordinate_and_is_normalized():
    profile = PhysicalTableProfile("M", (
        PhysicalColumnProfile("RESULT_ID", "VARCHAR", distinct_count=2, sample_values=("1","2")),
        PhysicalColumnProfile("WAFER_KEY", "VARCHAR", distinct_count=2, sample_values=("W1","W2")),
        PhysicalColumnProfile("TOOL_ID", "VARCHAR", distinct_count=1, sample_values=("T","T")),
        PhysicalColumnProfile("ITEM_CD", "VARCHAR", distinct_count=1, sample_values=("CD","CD")),
        PhysicalColumnProfile("MEAS_VAL", "REAL", distinct_count=2, sample_values=(1.0,2.0)),
        PhysicalColumnProfile("MEAS_TIME", "TIMESTAMP", distinct_count=2, sample_values=("2026-01-01 10:00:00","2026-01-01 11:00:00")),
        PhysicalColumnProfile("LOAD_DTTM", "TIMESTAMP", distinct_count=2, sample_values=("2026-01-01 10:01:00","2026-01-01 11:01:00")),
        PhysicalColumnProfile("Y_POS", "REAL", distinct_count=2, sample_values=(1.0,2.0)),
        PhysicalColumnProfile("REF_YN", "VARCHAR", distinct_count=2, sample_values=("Y","N")),
    ), row_count=2)
    proposal = infer_dataset_mapping("metrology", profile)
    assert proposal.mapping()["y"] == "Y_POS"
    assert proposal.mapping()["is_reference_material"] == "REF_YN"
    binding = proposal_to_sql_binding(proposal)
    assert "LOWER(TRIM(CAST(REF_YN AS VARCHAR)))" in binding.sql


def test_date_partition_pruning_is_conservative_but_exact_timestamp_filter_remains():
    with TemporaryDirectory() as td:
        root = Path(td)
        db, pairs = _binding_pair(root)
        registry = SqlBindingRegistry({b.logical_dataset: b for b, _ in pairs})
        client = SqlTemplateBigDataClient(SqliteSqlExecutor(db), registry)
        sql, params = client._compile(QuerySpec(
            dataset="executions", columns=("execution_id",),
            predicates=(
                Predicate("event_time", PredicateOp.GTE, datetime(2026,1,1,10,30)),
                Predicate("event_time", PredicateOp.LT, datetime(2026,1,2,10,30)),
            ),
        ))
        assert "_ephi_partition >= :partition_0" in sql
        assert "_ephi_partition < :partition_1" in sql
        assert str(params["partition_0"]) == "2026-01-01"
        assert str(params["partition_1"]) == "2026-01-03"
        assert "event_time >= :p0" in sql and "event_time < :p1" in sql


def test_repository_incremental_and_id_lookup_execute_without_fake_event_window():
    with TemporaryDirectory() as td:
        root = Path(td)
        db, pairs = _binding_pair(root)
        client = SqlTemplateBigDataClient(SqliteSqlExecutor(db), SqlBindingRegistry({b.logical_dataset:b for b,_ in pairs}))
        repo = ProcessExecutionRepository(client)
        rows = repo.fetch_incremental(available_after=datetime(2026,1,1), available_until=datetime(2026,2,1))
        assert rows
        assert len(repo.fetch_by_ids(["RUN-00001"], as_of=datetime(2026,2,1))) == 1


def test_type_firewall_rejects_raw_string_boolean():
    result = CanonicalTypeFirewall().validate("metrology", [{"is_reference_material":"N"}])
    assert not result.passed
    assert "expected boolean" in result.errors[0]


def test_sql_capability_probe_and_join_guard():
    with TemporaryDirectory() as td:
        db = Path(td) / "probe.db"; db.touch()
        assert qualify_sql_executor(SqliteSqlExecutor(db)).passed
    assert assess_join_explosion(100, 100, 120, max_factor=2).passed
    assert not assess_join_explosion(100, 100, 1000, max_factor=2).passed


def test_temporal_predicate_rejects_ambiguous_non_iso_string():
    with TemporaryDirectory() as td:
        root=Path(td); db,pairs=_binding_pair(root)
        client=SqlTemplateBigDataClient(SqliteSqlExecutor(db), SqlBindingRegistry({b.logical_dataset:b for b,_ in pairs}))
        with pytest.raises(ValueError, match="not valid ISO-8601"):
            client.query_arrow(QuerySpec(dataset="executions", columns=("execution_id",), predicates=(Predicate("available_at",PredicateOp.GT,"yesterday"),)))
