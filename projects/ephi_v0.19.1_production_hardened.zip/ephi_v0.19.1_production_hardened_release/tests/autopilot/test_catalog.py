from ephi.autopilot.catalog import DEFAULT_REQUIREMENTS, assert_catalog_matches_contracts, requirement


def test_catalog_covers_core_contracts():
    assert_catalog_matches_contracts()
    assert len(DEFAULT_REQUIREMENTS) == 11
    assert requirement("metrology").field("available_at").criticality.value == "REQUIRED"
    assert "reference/control wafer" in requirement("metrology").field("is_reference_material").meaning
