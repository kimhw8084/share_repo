from ephi.autopilot.inference import infer_dataset_mapping, proposal_to_sql_binding
from ephi.autopilot.models import PhysicalColumnProfile, PhysicalTableProfile
from ephi.autopilot.validation import validate_sql_binding


def test_metrology_inference_from_companyish_names():
    profile = PhysicalTableProfile("TB_METRO_X", (
        PhysicalColumnProfile("RESULT_ID", "VARCHAR", sample_values=("M1","M2"), distinct_count=2),
        PhysicalColumnProfile("WAFER_KEY", "VARCHAR", sample_values=("L1:01","L1:02"), distinct_count=2),
        PhysicalColumnProfile("TOOL_ID", "VARCHAR", sample_values=("M01","M02"), distinct_count=2),
        PhysicalColumnProfile("ITEM_CD", "VARCHAR", sample_values=("CD","CD"), distinct_count=1),
        PhysicalColumnProfile("MEAS_VAL", "DOUBLE", sample_values=(40.1,40.2), distinct_count=2),
        PhysicalColumnProfile("MEAS_TIME", "TIMESTAMP", sample_values=("2026-01-01 10:00:00",), distinct_count=2),
        PhysicalColumnProfile("LOAD_DTTM", "TIMESTAMP", sample_values=("2026-01-01 10:01:00",), distinct_count=2),
        PhysicalColumnProfile("REF_YN", "VARCHAR", sample_values=("Y","N"), distinct_count=2),
        PhysicalColumnProfile("MEAS_DATE", "DATE", sample_values=("2026-01-01",), distinct_count=1),
    ))
    proposal = infer_dataset_mapping("metrology", profile)
    assert proposal.missing_required == ()
    assert proposal.mapping()["measurement_id"] == "RESULT_ID"
    assert proposal.mapping()["material_id"] == "WAFER_KEY"
    binding = proposal_to_sql_binding(
        proposal, partition_column="MEAS_DATE", partition_source_field="event_time",
        partition_granularity="date", watermark_column="LOAD_DTTM"
    )
    assert validate_sql_binding(binding).passed
    assert "SELECT *" not in binding.sql
    assert "MEAS_DATE AS _ephi_partition" in binding.sql
    assert "NULL AS product_id" in binding.sql
    assert "CASE WHEN" in binding.sql  # Y/N reference flag normalization


def test_knowledge_time_violation_reduces_candidate_confidence():
    profile = PhysicalTableProfile("BAD_TIME", (
        PhysicalColumnProfile("RESULT_ID", "VARCHAR", distinct_count=2, sample_values=("M1","M2")),
        PhysicalColumnProfile("WAFER_KEY", "VARCHAR", distinct_count=2, sample_values=("L:1","L:2")),
        PhysicalColumnProfile("TOOL_ID", "VARCHAR", distinct_count=1, sample_values=("T1","T1")),
        PhysicalColumnProfile("ITEM_CD", "VARCHAR", distinct_count=1, sample_values=("CD","CD")),
        PhysicalColumnProfile("MEAS_VAL", "DOUBLE", distinct_count=2, sample_values=(1.0,2.0)),
        PhysicalColumnProfile("MEAS_TIME", "TIMESTAMP", distinct_count=2, sample_values=("2026-01-01 10:00:00","2026-01-01 11:00:00")),
        PhysicalColumnProfile("LOAD_DTTM", "TIMESTAMP", distinct_count=2, sample_values=("2026-01-01 09:00:00","2026-01-01 10:00:00")),
    ), row_count=2, sample_records=(
        {"MEAS_TIME":"2026-01-01 10:00:00","LOAD_DTTM":"2026-01-01 09:00:00"},
        {"MEAS_TIME":"2026-01-01 11:00:00","LOAD_DTTM":"2026-01-01 10:00:00"},
    ))
    proposal = infer_dataset_mapping("metrology", profile)
    assert proposal.confidence < 0.5
    assert any("knowledge-time ordering violation" in item for item in proposal.review_items)


def test_binding_validator_rejects_manifest_sql_mismatch():
    from ephi.autopilot.models import SqlBindingManifest
    bad = SqlBindingManifest(
        logical_dataset="executions",
        physical_table="X",
        sql="SELECT RUN_ID AS execution_id, TOOL_ID AS asset_id, TS AS event_time, LOAD_TS AS not_available FROM X",
        columns={"execution_id":"RUN_ID","asset_id":"TOOL_ID","event_time":"TS","available_at":"LOAD_TS"},
        knowledge_time_column="LOAD_TS",
    )
    result = validate_sql_binding(bad)
    assert not result.passed
    assert any("available_at" in error for error in result.errors)
