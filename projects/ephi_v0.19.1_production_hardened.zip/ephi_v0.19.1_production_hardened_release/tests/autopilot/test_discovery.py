from pathlib import Path
from tempfile import TemporaryDirectory

from ephi.autopilot.inference import rank_dataset_candidates
from ephi.autopilot.inspect import SqliteTableInspector
from ephi.autopilot.qualification import _build_hostile_db


def test_discovery_recovers_from_approximate_hint_and_ranks_semantic_table():
    with TemporaryDirectory() as td:
        db = Path(td) / "x.db"
        _build_hostile_db(db)
        inspector = SqliteTableInspector(db)
        names = inspector.find_tables("measurement metro")
        profiles = tuple(inspector.profile(name) for name in names)
        ranked = rank_dataset_candidates("metrology", profiles)
        assert ranked[0].physical_table == "MEASUREMENT_VAULT_Q"
        assert not ranked[0].missing_required
        wrong = next(p for p in ranked if p.physical_table == "EQP_DAILY_SUMMARY_WRONG")
        assert wrong.missing_required
