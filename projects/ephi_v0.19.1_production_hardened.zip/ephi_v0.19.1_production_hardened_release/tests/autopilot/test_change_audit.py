from ephi.autopilot.change_audit import classify_changes


def test_company_only_port_passes_core_guard():
    report = classify_changes(("company_bindings/metrology.sql", "company_port/src/ephi_company/big_data.py", "configs/company/site.yaml"))
    assert report.portability_passed
    assert "CORE" not in report.classification


def test_core_change_fails_portability_guard():
    report = classify_changes(("src/ephi/evidence/fusion.py",))
    assert not report.portability_passed
