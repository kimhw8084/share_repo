from ephi.adapters.base.big_data import Predicate, PredicateOp, QuerySpec
from ephi.adapters.company.sql_bound_client import SqlBindingRegistry, SqlTemplateBigDataClient
from ephi.autopilot.models import SqlBindingManifest


class FakeSqlExecutor:
    def __init__(self):
        self.calls = []
    def query_sql_arrow(self, sql, parameters):
        self.calls.append((sql, parameters))
        return {"sql": sql, "parameters": parameters}
    def stream_sql_arrow(self, sql, parameters, *, batch_rows=65536):
        self.calls.append((sql, parameters))
        yield {"sql": sql, "parameters": parameters, "batch_rows": batch_rows}


def _binding():
    return SqlBindingManifest(
        logical_dataset="executions",
        physical_table="FAB_RUNS",
        sql="""SELECT RUN_ID AS execution_id, TOOL AS asset_id, END_TS AS event_time, LOAD_TS AS available_at,
NULL AS process_unit_id, NULL AS operation, NULL AS recipe_id, NULL AS product_id, NULL AS technology,
NULL AS material_id, NULL AS source_revision, RUN_DATE AS _ephi_partition FROM FAB_RUNS""",
        columns={"execution_id":"RUN_ID","asset_id":"TOOL","event_time":"END_TS","available_at":"LOAD_TS"},
        partition_column="RUN_DATE", partition_source_field="event_time", partition_granularity="date",
        watermark_column="LOAD_TS", knowledge_time_column="LOAD_TS",
        source_schema_fingerprint="abc",
    )


def test_sql_binding_is_actual_runtime_query_layer():
    executor = FakeSqlExecutor()
    client = SqlTemplateBigDataClient(executor, SqlBindingRegistry({"executions": _binding()}))
    result = client.query_arrow(QuerySpec(
        dataset="executions", columns=("execution_id","asset_id"),
        predicates=(
            Predicate("event_time", PredicateOp.GTE, "2026-01-01"),
            Predicate("event_time", PredicateOp.LT, "2026-01-02"),
            Predicate("available_at", PredicateOp.GTE, "2026-01-01"),
            Predicate("asset_id", PredicateOp.EQ, "T1"),
        ), limit=100,
    ))
    assert "FAB_RUNS" in result["sql"]
    assert "SELECT execution_id, asset_id" in result["sql"]
    assert str(result["parameters"]["partition_0"]) == "2026-01-01"
    assert result["parameters"]["p3"] == "T1"
    assert "event_time >= :p0" in result["sql"]
    assert "event_time < :p1" in result["sql"]
    assert "LIMIT 100" in result["sql"]


def test_unbounded_query_fails_but_id_query_does_not_require_event_window():
    client = SqlTemplateBigDataClient(FakeSqlExecutor(), SqlBindingRegistry({"executions": _binding()}))
    try:
        client.query_arrow(QuerySpec(dataset="executions", columns=("execution_id",)))
    except ValueError as exc:
        assert "refusing unbounded" in str(exc)
    else:
        raise AssertionError("expected fail-closed unbounded query")
    result = client.query_arrow(QuerySpec(
        dataset="executions", columns=("execution_id",),
        predicates=(Predicate("execution_id", PredicateOp.EQ, "R1"),)
    ))
    assert result["parameters"]["p0"] == "R1"
