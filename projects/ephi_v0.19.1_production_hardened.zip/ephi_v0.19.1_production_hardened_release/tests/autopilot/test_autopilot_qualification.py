from ephi.autopilot.qualification import run_autopilot_qualification


def test_autopilot_hostile_port_qualification():
    report = run_autopilot_qualification()
    assert report.passed, report.details
    assert report.zero_core_changes
    assert report.autoconfiguration_coverage >= 0.80
    assert report.manual_decision_count <= 15
