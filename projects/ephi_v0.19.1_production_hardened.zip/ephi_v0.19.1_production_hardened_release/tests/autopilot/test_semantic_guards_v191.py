from ephi.autopilot.query_plan import assess_query_plan
from ephi.autopilot.semantics import DatasetSemanticMetrics, assess_semantic_metrics


def test_semantic_acceptance_blocks_knowledge_time_and_join_explosion():
    report = assess_semantic_metrics(DatasetSemanticMetrics(
        row_count=1000,
        critical_null_fraction={"execution_id": 0.0},
        identity_duplicate_fraction=0.0,
        knowledge_time_violation_fraction=0.01,
        applicable_join_coverage={"execution_metrology": 0.99},
        join_multiplication={"execution_metrology": 10.0},
    ))
    assert not report.passed
    assert any("knowledge-time" in x for x in report.blockers)
    assert any("join multiplication" in x for x in report.blockers)


def test_query_plan_rejects_full_scan_and_accepts_index_plan():
    assert not assess_query_plan("Seq Scan on huge_table").passed
    assert assess_query_plan("SEARCH table USING INDEX ix_load_ts").passed
