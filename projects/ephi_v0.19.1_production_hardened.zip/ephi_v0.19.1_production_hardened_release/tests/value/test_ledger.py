from datetime import datetime, timezone

import pytest

from ephi.domain.value import (
    BenefitAttribution,
    BenefitAttributionRole,
    BenefitClaimGroup,
    ValidatedBenefitEvidence,
)
from ephi.value.ledger import InMemoryValueLedgerRepository
from ephi.value.service import ValueLedgerService


def test_economic_event_key_prevents_duplicate_claim_groups() -> None:
    repo = InMemoryValueLedgerRepository()
    now = datetime.now(timezone.utc)
    repo.add_claim_group(BenefitClaimGroup(
        claim_group_id="G1", economic_event_key="EVENT", episode_ids=("E1",), description="x", created_at=now
    ))
    with pytest.raises(ValueError):
        repo.add_claim_group(BenefitClaimGroup(
            claim_group_id="G2", economic_event_key="EVENT", episode_ids=("E2",), description="same", created_at=now
        ))


def test_validated_benefit_requires_non_none_attribution() -> None:
    now = datetime.now(timezone.utc)
    service = ValueLedgerService()
    service.register_claim_group(BenefitClaimGroup(
        claim_group_id="G", economic_event_key="EV", episode_ids=("E",), description="x", created_at=now
    ))
    service.record_attribution(BenefitAttribution(
        claim_group_id="G", episode_id="E", role=BenefitAttributionRole.NONE,
        attribution_confidence=1.0, review_status="REVIEWED"
    ))
    with pytest.raises(ValueError):
        service.validate_realized_benefit(ValidatedBenefitEvidence(
            claim_group_id="G", amount=1.0, currency="USD", method="x",
            validated_at=now, validated_by="v", source_references=("s",)
        ))


def test_duplicate_estimate_requires_explicit_revision() -> None:
    from ephi.domain.value import CostModelApproval, CostModelDefinition, LossEstimateEvidence, MoneyRate, ValueCategory
    from ephi.value.costs import CostModelRegistry

    now = datetime.now(timezone.utc)
    registry = CostModelRegistry()
    registry.register(CostModelDefinition(
        cost_model_id="C", version="1", approval_status=CostModelApproval.APPROVED,
        source="test", confidence=1.0,
        rates=(MoneyRate(rate_id="loss", amount_per_unit=10.0, unit="material", currency="USD"),),
    ))
    service = ValueLedgerService(cost_models=registry)
    service.register_claim_group(BenefitClaimGroup(
        claim_group_id="G", economic_event_key="EV", episode_ids=("E",), description="event", created_at=now
    ))
    evidence = LossEstimateEvidence(
        episode_id="E", claim_group_id="G", category=ValueCategory.SCRAP_EXPOSURE_ESTIMATE,
        material_count=2, material_ids=("M1", "M2"), risk_probability=0.5,
        rate_id="loss", computed_at=now,
    )
    first = service.estimate_loss(evidence, cost_model_id="C", cost_model_version="1")
    with pytest.raises(ValueError):
        service.estimate_loss(evidence, cost_model_id="C", cost_model_version="1")
    revised = service.estimate_loss(
        evidence.model_copy(update={"risk_probability": 0.7}),
        cost_model_id="C", cost_model_version="1", supersedes_entry_id=first.ledger_entry_id,
    )
    assert first not in service.repository.active_entries()
    assert revised in service.repository.active_entries()


def test_protected_materials_are_deduplicated_across_related_entries() -> None:
    from ephi.domain.value import ProtectionEvidence

    now = datetime.now(timezone.utc)
    service = ValueLedgerService()
    service.register_claim_group(BenefitClaimGroup(
        claim_group_id="G", economic_event_key="EV", episode_ids=("E1", "E2"), description="shared", created_at=now
    ))
    service.record_protection(ProtectionEvidence(
        episode_id="E1", claim_group_id="G", material_ids=("M1", "M2"), action="reroute",
        routing_evidence=("R1",), observed_at=now, confidence=1.0,
    ))
    service.record_protection(ProtectionEvidence(
        episode_id="E2", claim_group_id="G", material_ids=("M2", "M3"), action="hold/reroute",
        routing_evidence=("R2",), observed_at=now, confidence=1.0,
    ))
    assert service.program_summary(as_of=now).wafers_protected == 3


def test_program_summary_refuses_overlapping_validated_claim_groups_without_allocation() -> None:
    now = datetime.now(timezone.utc)
    service = ValueLedgerService()
    for gid, event, episode, materials in [
        ("G1", "EV1", "E1", ("M1", "M2")),
        ("G2", "EV2", "E2", ("M2", "M3")),
    ]:
        service.register_claim_group(BenefitClaimGroup(
            claim_group_id=gid, economic_event_key=event, episode_ids=(episode,),
            material_ids=materials, description=event, created_at=now,
        ))
        service.record_attribution(BenefitAttribution(
            claim_group_id=gid, episode_id=episode, role=BenefitAttributionRole.PRIMARY,
            attribution_confidence=0.9, review_status="REVIEWED",
        ))
        service.validate_realized_benefit(ValidatedBenefitEvidence(
            claim_group_id=gid, amount=100.0, currency="USD", method="review",
            validated_at=now, validated_by="reviewer", source_references=(event,),
        ))
    with pytest.raises(ValueError, match="overlap"):
        service.program_summary(as_of=now)
