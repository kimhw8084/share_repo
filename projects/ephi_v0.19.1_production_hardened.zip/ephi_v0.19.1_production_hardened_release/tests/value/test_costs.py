from pathlib import Path

from ephi.domain.value import CostModelApproval
from ephi.value.costs import load_cost_model


def test_synthetic_cost_model_is_explicitly_approved_fixture() -> None:
    root = Path(__file__).parents[2]
    model = load_cost_model(root / "configs/value/synthetic_reference.yaml")
    assert model.approval_status is CostModelApproval.APPROVED
    assert model.rate("wafer_loss").unit == "material"
