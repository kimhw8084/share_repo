from ephi.reliability.models import StateDurability
from ephi.reliability.policy import load_reliability_policy


def test_reference_reliability_policy_classifies_authoritative_and_rebuildable_state() -> None:
    policy = load_reliability_policy("configs/reliability/reference.yaml")
    assert policy.state_schema_version == "2"
    assert policy.fail_on_unclassified_state
    mapping = {item.prefix: item.durability for item in policy.policies}
    assert mapping["onboarding:"] == StateDurability.AUTHORITATIVE
    assert mapping["pipeline:"] == StateDurability.REBUILDABLE
    assert mapping["watermark:"] == StateDurability.AUTHORITATIVE
    assert mapping["launch:"] == StateDurability.AUTHORITATIVE
