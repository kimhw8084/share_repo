from ephi.reliability.qualification import run_reliability_qualification


def test_reliability_qualification_gate_passes() -> None:
    report = run_reliability_qualification()
    assert report.passed, report.model_dump()
