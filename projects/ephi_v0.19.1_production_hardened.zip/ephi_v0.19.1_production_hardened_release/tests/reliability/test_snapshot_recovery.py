from __future__ import annotations

import json
from datetime import datetime, timezone

import pytest

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.reliability.models import RecoveryState, StateDurability, StateNamespacePolicy
from ephi.reliability.snapshot import (
    assess_inventory,
    build_backup_bundle,
    load_backup_bundle,
    restore_backup_bundle,
    write_backup_bundle,
)


def _policies():
    return (
        StateNamespacePolicy(prefix="auth:", durability=StateDurability.AUTHORITATIVE, required=True),
        StateNamespacePolicy(prefix="derived:", durability=StateDurability.REBUILDABLE, required=True),
    )


def test_backup_restore_preserves_versions_values_and_timestamps(tmp_path) -> None:
    source = SqliteStateStore(tmp_path / "source.sqlite3")
    source.compare_and_set("auth:a", expected_version=None, value=b"one")
    source.compare_and_set("derived:b", expected_version=None, value=b"two")
    original = source.snapshot()
    bundle = build_backup_bundle(
        source,
        policies=_policies(),
        source_release_id="R1",
        state_schema_version="2",
        created_at=datetime(2026, 8, 19, tzinfo=timezone.utc),
        bundle_id="B1",
    )
    path = write_backup_bundle(bundle, tmp_path / "backup.json")
    target = SqliteStateStore(tmp_path / "target.sqlite3")
    restore_backup_bundle(target, load_backup_bundle(path))
    assert target.snapshot() == original


def test_corruption_and_dirty_restore_fail_closed(tmp_path) -> None:
    source = SqliteStateStore(tmp_path / "source.sqlite3")
    source.compare_and_set("auth:a", expected_version=None, value=b"one")
    source.compare_and_set("derived:b", expected_version=None, value=b"two")
    bundle = build_backup_bundle(
        source,
        policies=_policies(),
        source_release_id="R1",
        state_schema_version="2",
        bundle_id="B1",
    )
    path = write_backup_bundle(bundle, tmp_path / "backup.json")
    raw = json.loads(path.read_text())
    raw["records"][0]["value_b64"] = "AAAA"
    path.write_text(json.dumps(raw))
    with pytest.raises(ValueError):
        load_backup_bundle(path)

    clean = build_backup_bundle(source, policies=_policies(), source_release_id="R1", state_schema_version="2")
    target = SqliteStateStore(tmp_path / "target.sqlite3")
    target.compare_and_set("stale:key", expected_version=None, value=b"stale")
    with pytest.raises(ValueError, match="empty"):
        restore_backup_bundle(target, clean)


def test_authoritative_missing_blocks_but_derived_missing_rebuilds(tmp_path) -> None:
    store = SqliteStateStore(tmp_path / "state.sqlite3")
    store.compare_and_set("auth:a", expected_version=None, value=b"one")
    store.compare_and_set("derived:b", expected_version=None, value=b"two")
    records = store.snapshot()
    no_auth = tuple(item for item in records if not item.key.startswith("auth:"))
    no_derived = tuple(item for item in records if not item.key.startswith("derived:"))
    assert assess_inventory(no_auth, _policies()).state == RecoveryState.BLOCKED
    assert assess_inventory(no_derived, _policies()).state == RecoveryState.REBUILD_REQUIRED


def test_unclassified_state_key_blocks_backup(tmp_path) -> None:
    source = SqliteStateStore(tmp_path / "source.sqlite3")
    source.compare_and_set("auth:a", expected_version=None, value=b"one")
    source.compare_and_set("unknown:new-subsystem", expected_version=None, value=b"surprise")
    with pytest.raises(ValueError, match="does not classify"):
        build_backup_bundle(
            source,
            policies=_policies(),
            source_release_id="R1",
            state_schema_version="2",
        )


def test_backup_round_trips_through_immutable_artifact_store(tmp_path) -> None:
    from ephi.adapters.local.filesystem_artifact_store import FileSystemArtifactStore
    from ephi.reliability.snapshot import load_backup_artifact, publish_backup_bundle

    source = SqliteStateStore(tmp_path / "source.sqlite3")
    source.compare_and_set("auth:a", expected_version=None, value=b"one")
    source.compare_and_set("derived:b", expected_version=None, value=b"two")
    bundle = build_backup_bundle(
        source,
        policies=_policies(),
        source_release_id="R1",
        state_schema_version="2",
        bundle_id="B-ART",
    )
    artifacts = FileSystemArtifactStore(tmp_path / "artifacts")
    ref = publish_backup_bundle(bundle, artifacts, staging_dir=tmp_path / "staging")
    restored = load_backup_artifact(artifacts, ref)
    assert restored == bundle


def test_self_consistent_bundle_missing_required_authoritative_namespace_is_rejected(tmp_path) -> None:
    from ephi.reliability.models import StateBackupBundle
    from ephi.reliability.snapshot import _canonical_bundle_payload, _sha256, validate_backup_bundle

    source = SqliteStateStore(tmp_path / "source.sqlite3")
    source.compare_and_set("auth:a", expected_version=None, value=b"one")
    source.compare_and_set("derived:b", expected_version=None, value=b"two")
    bundle = build_backup_bundle(
        source, policies=_policies(), source_release_id="R1", state_schema_version="2", bundle_id="B1"
    )
    records = tuple(item for item in bundle.records if not item.key.startswith("auth:"))
    digest = _sha256(_canonical_bundle_payload(
        bundle_id=bundle.bundle_id,
        source_release_id=bundle.source_release_id,
        state_schema_version=bundle.state_schema_version,
        created_at=bundle.created_at,
        policies=bundle.policies,
        records=records,
    ))
    incomplete = StateBackupBundle(
        bundle_id=bundle.bundle_id,
        source_release_id=bundle.source_release_id,
        state_schema_version=bundle.state_schema_version,
        created_at=bundle.created_at,
        policies=bundle.policies,
        records=records,
        content_sha256=digest,
    )
    with pytest.raises(ValueError, match="required authoritative"):
        validate_backup_bundle(incomplete)
