import pytest

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.health.checkpoint import restore_pipeline_state
from ephi.health.engine import BehavioralHealthPipeline
from ephi.metrology.checkpoint import restore_metrology_pipeline_state
from ephi.metrology.engine import MetrologyHealthPipeline


def test_behavioral_corrupt_or_unknown_checkpoint_fails_closed(tmp_path) -> None:
    store = SqliteStateStore(tmp_path / "state.sqlite3")
    store.compare_and_set("pipeline:behavioral", expected_version=None, value=b"not-json")
    with pytest.raises(Exception):
        restore_pipeline_state(BehavioralHealthPipeline(), store)

    store2 = SqliteStateStore(tmp_path / "state2.sqlite3")
    store2.compare_and_set(
        "pipeline:behavioral",
        expected_version=None,
        value=b'{"schema":"behavioral_pipeline_state_v999","detector":{},"episodes":{}}',
    )
    with pytest.raises(ValueError, match="Unsupported pipeline checkpoint schema"):
        restore_pipeline_state(BehavioralHealthPipeline(), store2)


def test_metrology_incomplete_checkpoint_fails_closed(tmp_path) -> None:
    store = SqliteStateStore(tmp_path / "metrology.sqlite3")
    store.compare_and_set(
        "pipeline:metrology",
        expected_version=None,
        value=b'{"schema":"metrology_pipeline_state_v1","engine":{},"episodes":{}}',
    )
    with pytest.raises(TypeError, match="invalid metrology pipeline checkpoint"):
        restore_metrology_pipeline_state(MetrologyHealthPipeline(), store)
