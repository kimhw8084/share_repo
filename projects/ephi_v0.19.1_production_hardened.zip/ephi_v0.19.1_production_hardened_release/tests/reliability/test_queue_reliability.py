from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import pytest

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.runtime.queue import DurableWorkQueue


def test_conflicting_duplicate_is_rejected_and_dependencies_enforce_order(tmp_path) -> None:
    now = datetime.now(timezone.utc)
    queue = DurableWorkQueue(SqliteStateStore(tmp_path / "queue.sqlite3"))
    queue.enqueue("A", work_id="A", payload={"x": 1}, created_at=now)
    queue.enqueue("A", work_id="A", payload={"x": 1}, created_at=now)
    with pytest.raises(ValueError, match="different request"):
        queue.enqueue("A", work_id="A", payload={"x": 2}, created_at=now)
    queue.enqueue("B", work_id="B", depends_on=("A",), priority=0, created_at=now - timedelta(seconds=10))
    assert queue.claim(worker_id="b", accepted_job_types={"B"}, now=now) is None
    leased = queue.claim(worker_id="a", accepted_job_types={"A"}, now=now)
    assert leased is not None
    queue.complete("A", worker_id="a")
    assert queue.claim(worker_id="b", accepted_job_types={"B"}, now=now).work_id == "B"


def test_multi_instance_claim_has_exactly_one_winner(tmp_path) -> None:
    path = tmp_path / "queue.sqlite3"
    now = datetime.now(timezone.utc)
    DurableWorkQueue(SqliteStateStore(path)).enqueue("A", work_id="A", created_at=now)

    def claim(worker: str):
        return DurableWorkQueue(SqliteStateStore(path)).claim(worker_id=worker, now=now)

    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(claim, [f"W{i}" for i in range(8)]))
    winners = [item for item in results if item is not None]
    assert len(winners) == 1
    assert winners[0].work_id == "A"
