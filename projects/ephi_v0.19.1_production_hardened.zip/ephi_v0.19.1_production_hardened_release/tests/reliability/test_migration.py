from __future__ import annotations

import json
from datetime import datetime, timezone

from ephi.config import EphiConfig
from ephi.domain.operations import ReleaseCompatibilityState
from ephi.operations.release import assess_release_compatibility
from ephi.registry.releases import build_release_manifest
from ephi.reliability.migration import default_migration_registry


def test_behavioral_migration_is_deterministic_and_semantically_equivalent() -> None:
    payload = json.dumps({
        "schema": "behavioral_pipeline_state_v1",
        "detector": {"a": 1},
        "episodes": {"b": 2},
    }).encode()
    registry = default_migration_registry()
    a = registry.migrate("behavioral-pipeline", payload, from_schema="behavioral_pipeline_state_v1", to_schema="behavioral_pipeline_state_v2")
    b = registry.migrate("behavioral-pipeline", payload, from_schema="behavioral_pipeline_state_v1", to_schema="behavioral_pipeline_state_v2")
    assert a.payload == b.payload
    assert a.semantic_sha256 is not None
    assert json.loads(a.payload)["fleet_episodes"] == {}
    assert not a.reversible


def test_irreversible_state_migration_blocks_rollback(tmp_path) -> None:
    (tmp_path / "src/ephi").mkdir(parents=True)
    (tmp_path / "configs").mkdir()
    (tmp_path / "src/ephi/x.py").write_text("x=1\n")
    now = datetime.now(timezone.utc)
    source = build_release_manifest(tmp_path, EphiConfig(), created_at=now)
    target = build_release_manifest(tmp_path, EphiConfig(), created_at=now)
    result = assess_release_compatibility(
        source, target,
        source_state_schema_version="1",
        target_state_schema_version="2",
        migration_available=True,
        migration_reversible=False,
    )
    assert result.state == ReleaseCompatibilityState.REQUIRES_MIGRATION
    assert not result.rollback_allowed
