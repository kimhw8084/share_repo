from datetime import datetime, timezone

from ephi.operations.telemetry import evaluate_freshness
from ephi.reliability.models import ServiceAvailability
from ephi.reliability.readiness import assess_degraded_mode


def _targets():
    return {
        name: (60.0, 300.0)
        for name in (
            "source", "canonical", "feature", "reference", "peer", "assessment", "wip",
            "quality_model", "historical_index", "value_reconciliation",
        )
    }


def test_wip_outage_does_not_disable_behavioral_scoring() -> None:
    values = {name: 10.0 for name in _targets()}
    values["wip"] = None
    report = evaluate_freshness(as_of=datetime.now(timezone.utc), observations=values, targets=_targets())
    readiness = assess_degraded_mode(report)
    assert readiness.get("analytical_scoring").availability == ServiceAvailability.AVAILABLE
    assert readiness.get("exposure_priority").availability == ServiceAvailability.UNAVAILABLE


def test_source_outage_blocks_new_scoring_but_not_existing_advisory_read() -> None:
    values = {name: 10.0 for name in _targets()}
    values["source"] = 1000.0
    report = evaluate_freshness(as_of=datetime.now(timezone.utc), observations=values, targets=_targets())
    readiness = assess_degraded_mode(report)
    assert readiness.get("analytical_scoring").availability == ServiceAvailability.UNAVAILABLE
    assert readiness.get("advisory_reads").availability == ServiceAvailability.AVAILABLE
