from datetime import datetime, timedelta, timezone

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.operations.worker import WorkerHost
from ephi.runtime.idempotency import AppliedWorkLedger
from ephi.runtime.queue import DurableWorkQueue, WorkStatus


def test_applied_work_ledger_closes_success_before_queue_complete_crash_window(tmp_path) -> None:
    path = tmp_path / "runtime.sqlite3"
    store = SqliteStateStore(path)
    queue = DurableWorkQueue(store)
    now = datetime.now(timezone.utc)
    queue.enqueue("APPLY", work_id="W1", payload={"x": 1}, created_at=now)
    leased = queue.claim(worker_id="crashed", lease_seconds=1, now=now - timedelta(seconds=5))
    assert leased is not None
    AppliedWorkLedger(store).record(leased, completed_at=now - timedelta(seconds=4))

    calls: list[str] = []
    host = WorkerHost(
        worker_id="replacement",
        queue=DurableWorkQueue(SqliteStateStore(path)),
        handlers={"APPLY": lambda item: calls.append(item.work_id)},
        applied_work=AppliedWorkLedger(SqliteStateStore(path)),
    )
    completed = host.run_once()
    assert completed is not None and completed.status == WorkStatus.SUCCEEDED
    assert calls == []  # already applied before the simulated process crash
