from pathlib import Path

import pytest

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.errors import StateConflictError


def test_compare_and_set(tmp_path: Path) -> None:
    store = SqliteStateStore(tmp_path / "state.sqlite3")
    first = store.compare_and_set("x", expected_version=None, value=b"one")
    assert first.version == 1
    second = store.compare_and_set("x", expected_version=1, value=b"two")
    assert second.version == 2
    assert store.get("x").value == b"two"  # type: ignore[union-attr]

    with pytest.raises(StateConflictError):
        store.compare_and_set("x", expected_version=1, value=b"stale-writer")
