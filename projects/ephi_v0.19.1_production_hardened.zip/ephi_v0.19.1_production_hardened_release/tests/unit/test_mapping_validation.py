from ephi.adapters.company.validation import validate_mapping_config
from ephi.audit_contracts import DEFAULT_DATASET_CONTRACTS
from ephi.config import DataConfig, DatasetBindingConfig
from ephi.domain.data_reality import QualificationState


def test_mapping_validation_fails_missing_required_but_allows_unmapped_optional_datasets() -> None:
    config = DataConfig(
        datasets={
            "executions": DatasetBindingConfig(
                physical_name="X.EXEC",
                columns={
                    "execution_id": "RUN_ID",
                    "asset_id": "EQP",
                    "event_time": "EVENT_TS",
                    # available_at deliberately omitted
                },
            )
        }
    )
    results = {item.logical_name: item for item in validate_mapping_config(config, DEFAULT_DATASET_CONTRACTS)}
    assert results["executions"].state == QualificationState.FAILED
    assert results["executions"].missing_required_mappings == ("available_at",)
    assert results["metrology"].state == QualificationState.UNAVAILABLE
