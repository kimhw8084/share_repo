from datetime import datetime, timezone
from pathlib import Path

from ephi.config import EphiConfig
from ephi.registry.releases import build_release_manifest


def test_release_manifest_is_deterministic_except_timestamp(tmp_path: Path) -> None:
    (tmp_path / "src" / "ephi").mkdir(parents=True)
    (tmp_path / "configs").mkdir()
    (tmp_path / "src" / "ephi" / "x.py").write_text("x = 1\n")
    (tmp_path / "configs" / "base.yaml").write_text("app:\n  environment: test\n")
    benchmark = tmp_path / "bench.json"
    benchmark.write_text('{"x": 1}\n')
    when = datetime(2026, 1, 1, tzinfo=timezone.utc)
    a = build_release_manifest(tmp_path, EphiConfig(), benchmark_files=(benchmark,), created_at=when)
    b = build_release_manifest(tmp_path, EphiConfig(), benchmark_files=(benchmark,), created_at=when)
    assert a == b
    from ephi.version import __version__
    assert a.release_id.startswith(f"ephi-{__version__}-")
    assert a.benchmark_sha256["bench.json"]


def test_release_code_hash_includes_root_package_metadata(tmp_path: Path) -> None:
    (tmp_path / "src" / "ephi").mkdir(parents=True)
    (tmp_path / "configs").mkdir()
    (tmp_path / "src" / "ephi" / "x.py").write_text("x = 1\n")
    (tmp_path / "pyproject.toml").write_text('[project]\nname="ephi"\nversion="1"\n')
    when = datetime(2026, 1, 1, tzinfo=timezone.utc)
    a = build_release_manifest(tmp_path, EphiConfig(), created_at=when)
    (tmp_path / "pyproject.toml").write_text('[project]\nname="ephi"\nversion="2"\n')
    b = build_release_manifest(tmp_path, EphiConfig(), created_at=when)
    assert a.code_tree_sha256 != b.code_tree_sha256
