from pathlib import Path

from ephi.config import EphiConfig, load_config


def test_config_hash_is_stable() -> None:
    assert EphiConfig().stable_hash() == EphiConfig().stable_hash()


def test_config_merge(tmp_path: Path) -> None:
    base = tmp_path / "base.yaml"
    override = tmp_path / "override.yaml"
    base.write_text("runtime:\n  batch_rows: 100\n", encoding="utf-8")
    override.write_text("app:\n  environment: test\n", encoding="utf-8")
    config = load_config([base, override])
    assert config.runtime.batch_rows == 100
    assert config.app.environment == "test"
