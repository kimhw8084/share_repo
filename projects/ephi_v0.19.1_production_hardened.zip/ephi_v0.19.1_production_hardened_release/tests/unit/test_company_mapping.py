from ephi.adapters.base.big_data import Predicate, PredicateOp, QuerySpec
from ephi.adapters.company.mapping import DatasetMapping, MappingRegistry, map_query_spec


def test_company_mapping_translates_query_without_leaking_physical_names_upstream() -> None:
    registry = MappingRegistry(
        {
            "executions": DatasetMapping(
                logical_name="executions",
                physical_name="INTERNAL.EXEC_TABLE",
                columns={
                    "execution_id": "RUN_ID",
                    "asset_id": "EQP_ID",
                    "available_at": "LOAD_TS",
                },
            )
        }
    )
    query = QuerySpec(
        dataset="executions",
        columns=("execution_id", "asset_id"),
        predicates=(Predicate("available_at", PredicateOp.GT, "2026-01-01"),),
        order_by=("execution_id",),
    )
    mapped, rename = map_query_spec(query, registry)
    assert mapped.dataset == "INTERNAL.EXEC_TABLE"
    assert mapped.columns == ("RUN_ID", "EQP_ID")
    assert mapped.predicates[0].column == "LOAD_TS"
    assert mapped.order_by == ("RUN_ID",)
    assert rename == {"RUN_ID": "execution_id", "EQP_ID": "asset_id"}
