from datetime import datetime, timezone

from ephi.config import EphiConfig
from ephi.registry.releases import build_release_manifest


def test_release_manifest_hashes_qualification_and_deployment_evidence(tmp_path) -> None:
    (tmp_path / "src/ephi").mkdir(parents=True)
    (tmp_path / "configs").mkdir()
    (tmp_path / "src/ephi/x.py").write_text("x=1\n")
    q = tmp_path / "qualification.json"
    d = tmp_path / "deployment.yaml"
    q.write_text('{"passed": true}\n')
    d.write_text('kind: Deployment\n')
    manifest = build_release_manifest(
        tmp_path, EphiConfig(), qualification_files=(q,), deployment_files=(d,),
        created_at=datetime.now(timezone.utc),
    )
    assert manifest.qualification_sha256["qualification.json"]
    assert manifest.deployment_sha256["deployment.yaml"]
    assert manifest.schema_version == "2"
