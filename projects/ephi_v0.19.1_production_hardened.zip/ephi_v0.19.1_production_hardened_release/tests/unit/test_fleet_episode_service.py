from datetime import datetime, timezone

from ephi.domain.context import ContextKey
from ephi.domain.evidence import Hypothesis
from ephi.domain.health import HealthAssessment, HealthSeverity, HypothesisSupport
from ephi.episodes.fleet import FleetEpisodeService


def _assessment(asset_id: str, hypothesis: Hypothesis, severity: HealthSeverity) -> HealthAssessment:
    context = ContextKey("OP", "R", "P", "T")
    return HealthAssessment(
        assessment_id=f"HA:{asset_id}",
        execution_id=f"E:{asset_id}",
        asset_id=asset_id,
        context=context,
        event_time=datetime(2026, 1, 1, tzinfo=timezone.utc),
        severity=severity,
        confidence=1.0,
        behavioral_novelty=0.8,
        leading_hypothesis=hypothesis,
        hypothesis_support=(
            HypothesisSupport(Hypothesis.COMMON_MODE_PROCESS_CHANGE, 1.0, 0.0),
        ),
        evidence=(),
    )


def test_common_mode_creates_one_fleet_episode() -> None:
    service = FleetEpisodeService()
    update = service.process_group(
        [
            _assessment("A", Hypothesis.COMMON_MODE_PROCESS_CHANGE, HealthSeverity.MONITOR),
            _assessment("B", Hypothesis.COMMON_MODE_PROCESS_CHANGE, HealthSeverity.MONITOR),
            _assessment("C", Hypothesis.COMMON_MODE_PROCESS_CHANGE, HealthSeverity.MONITOR),
        ]
    )
    assert update is not None
    assert update.episode_id.startswith("EPHI-F")
    assert update.affected_asset_ids == ("A", "B", "C")
    assert len(service.active()) == 1
