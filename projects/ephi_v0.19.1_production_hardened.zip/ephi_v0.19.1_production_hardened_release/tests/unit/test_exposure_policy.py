from ephi.exposure.policy import load_exposure_policy,load_priority_policy

def test_reference_policies_load():
    e=load_exposure_policy("configs/exposure/reference.yaml"); p=load_priority_policy("configs/priority/reference.yaml")
    assert e.version=="exposure-v1" and p.version=="priority-v1"
