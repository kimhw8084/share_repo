from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.runtime.watermarks import WatermarkStore


def test_watermark_monotonic(tmp_path: Path) -> None:
    store = WatermarkStore(SqliteStateStore(tmp_path / "state.sqlite3"))
    t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
    _, version = store.commit(
        source_id="executions", available_through=t0, expected_state_version=None
    )
    _, version2 = store.commit(
        source_id="executions",
        available_through=t0 + timedelta(minutes=5),
        expected_state_version=version,
    )
    assert version2 == version + 1

    with pytest.raises(ValueError):
        store.commit(
            source_id="executions",
            available_through=t0 - timedelta(minutes=1),
            expected_state_version=version2,
        )
