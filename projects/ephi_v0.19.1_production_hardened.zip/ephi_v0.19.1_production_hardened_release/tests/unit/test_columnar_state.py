import numpy as np

from ephi.detectors.columnar import peer_decompose_arrays, peer_decompose_grouped_arrays
from ephi.domain.populations import MaterializedReferenceState
from ephi.populations.columnar_state import ReferenceStateMatrixIndex, stable_state_key_id
from ephi.runtime.columnar import ColumnarBehavioralBatch, ColumnarBehavioralScorer


def _state(asset: str, median: float = 10.0) -> MaterializedReferenceState:
    return MaterializedReferenceState(
        asset_id=asset,
        context_key="CTX",
        feature_id="F",
        median=median,
        mad=1.0,
        n=100,
        anchor_median=median,
        anchor_mad=1.0,
        anchor_n=60,
        adequate=True,
        confidence=1.0,
        scale_floor=0.1,
        practical_effect_floor=0.2,
    )


def test_reference_matrix_lookup_and_columnar_scoring() -> None:
    states = [_state("A"), _state("B"), _state("C")]
    index = ReferenceStateMatrixIndex(states)
    keys = np.array(
        [stable_state_key_id(asset, "CTX", "F") for asset in ("A", "B", "C")],
        dtype=np.uint64,
    )
    result = ColumnarBehavioralScorer(index).score(
        ColumnarBehavioralBatch(
            state_key_id=keys,
            peer_group_id=np.array([1, 1, 1]),
            value=np.array([13.0, 10.1, 9.9]),
        )
    )
    assert result.reference_found.all()
    assert result.scalar.anchor_z[0] == 3.0
    assert result.practical_effect_met[0]
    # Three-member consensus must identify A as the local outlier rather than
    # allowing A to poison the leave-one-out center for B/C.
    assert abs(result.peer.peer_change_z[0]) > abs(result.peer.peer_change_z[1])
    assert abs(result.peer.peer_change_z[0]) > abs(result.peer.peer_change_z[2])


def test_grouped_peer_kernel_matches_single_group_semantics() -> None:
    changes = np.array([3.0, 0.1, -0.1, 2.0, 2.1, 1.9])
    scales = np.ones(6)
    groups = np.array([10, 10, 10, 20, 20, 20])
    grouped = peer_decompose_grouped_arrays(changes, scales, groups)
    left = peer_decompose_arrays(changes[:3], scales[:3])
    right = peer_decompose_arrays(changes[3:], scales[3:])
    np.testing.assert_allclose(grouped.peer_change_z[:3], left.peer_change_z)
    np.testing.assert_allclose(grouped.peer_change_z[3:], right.peer_change_z)


def test_grouped_peer_kernel_exactly_matches_semantic_kernel_across_group_sizes() -> None:
    rng = np.random.default_rng(42)
    chunks = []
    scales = []
    groups = []
    for group_id, size in enumerate((2, 3, 4, 5, 6, 7), start=1):
        chunks.extend(rng.normal(group_id, 0.5, size=size))
        scales.extend(rng.uniform(0.4, 1.4, size=size))
        groups.extend([group_id] * size)
    changes = np.asarray(chunks)
    scale_array = np.asarray(scales)
    group_array = np.asarray(groups)
    grouped = peer_decompose_grouped_arrays(changes, scale_array, group_array)
    for group_id in np.unique(group_array):
        idx = np.flatnonzero(group_array == group_id)
        expected = peer_decompose_arrays(changes[idx], scale_array[idx])
        np.testing.assert_allclose(grouped.peer_center_change[idx], expected.peer_center_change)
        np.testing.assert_allclose(grouped.peer_change_mad[idx], expected.peer_change_mad)
        np.testing.assert_allclose(grouped.peer_change_z[idx], expected.peer_change_z)
        np.testing.assert_allclose(grouped.fleet_shift_z[idx], expected.fleet_shift_z)
