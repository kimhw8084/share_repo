from datetime import datetime, timezone

from ephi.domain.context import ContextKey
from ephi.domain.data_reality import QualificationState
from ephi.domain.features import ScalarFeatureObservation
from ephi.domain.measurement_scale import MeasurementScalePolicy, ScaleEvidenceSource
from ephi.metrology.engine import MeasurementSystemConfig
from ephi.populations.references import ReferenceConfig, ReferenceManager


def _obs(value: float) -> ScalarFeatureObservation:
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    return ScalarFeatureObservation(
        execution_id=str(value),
        asset_id="A",
        context=ContextKey("OP", "R", "P", "T"),
        feature_id="METRO_REF:CD:mean",
        value=value,
        event_time=now,
        available_at=now,
    )


def test_feature_specific_scale_floor_prevents_near_zero_reference_scale() -> None:
    manager = ReferenceManager(
        ReferenceConfig(
            min_reference_n=3,
            bootstrap_n=3,
            scale_floor=1e-9,
            feature_scale_floors={"METRO_REF:CD:mean": 0.02},
        )
    )
    for value in (10.0, 10.0, 10.0):
        manager.bootstrap(_obs(value))
    snapshot = manager.snapshot(_obs(10.01))
    assert snapshot is not None
    assert snapshot.mad == 0.02
    assert snapshot.anchor_mad == 0.02


def test_metrology_config_overlays_characteristic_policy_on_all_channels() -> None:
    policy = MeasurementScalePolicy(
        characteristic_id="CD",
        robust_scale_floor=0.012,
        practical_effect_floor=0.015,
        state=QualificationState.QUALIFIED,
        sources=(ScaleEvidenceSource.CONFIGURED_RESOLUTION,),
    )
    config = MeasurementSystemConfig.from_scale_policies([policy])
    assert config.reference.feature_scale_floors["METRO_REF:CD:mean"] == 0.012
    assert config.production.feature_scale_floors["METRO_PROD:CD:mean"] == 0.012
    assert config.matching.feature_scale_floors["CROSS_TOOL:CD"] == 0.012
    assert config.spatial.feature_scale_floors["SPATIAL_CENTER_EDGE:CD"] == 0.012
    assert config.repeatability.feature_scale_floors["REMEASURE_DELTA:CD"] == 0.012
