from datetime import datetime, timedelta, timezone

from ephi.domain.context import ContextKey
from ephi.domain.features import ScalarFeatureObservation
from ephi.populations.references import ReferenceConfig, ReferenceManager


def _obs(i: int, value: float) -> ScalarFeatureObservation:
    t = datetime(2026, 1, 1, tzinfo=timezone.utc) + timedelta(minutes=i)
    return ScalarFeatureObservation(
        execution_id=f"E{i}",
        asset_id="A",
        context=ContextKey("OP", "R", "P", "T"),
        feature_id="PRESSURE",
        value=value,
        event_time=t,
        available_at=t,
    )


def test_current_outlier_does_not_enter_its_own_reference() -> None:
    manager = ReferenceManager(
        ReferenceConfig(min_reference_n=5, bootstrap_n=5, max_adaptive_n=20, admission_abs_z=3.0)
    )
    for i, value in enumerate([100.0, 100.1, 99.9, 100.2, 99.8]):
        manager.bootstrap(_obs(i, value))

    outlier = _obs(10, 110.0)
    before = manager.debug_values(outlier)
    snapshot = manager.snapshot(outlier)
    assert snapshot is not None and snapshot.adequate
    z, _ = manager.robust_z(outlier, snapshot)
    assert z > 10
    admitted = manager.admit_after_score(outlier, self_z=z, anchor_z=z, data_pipeline_suspect=False)
    after = manager.debug_values(outlier)

    assert admitted is False
    assert after == before


def test_reference_scale_floor_prevents_numerical_z_explosion() -> None:
    from datetime import datetime, timedelta, timezone

    from ephi.domain.context import ContextKey
    from ephi.domain.features import ScalarFeatureObservation
    from ephi.populations.references import ReferenceConfig, ReferenceManager

    manager = ReferenceManager(
        ReferenceConfig(
            min_reference_n=12,
            bootstrap_n=18,
            confidence_full_n=18,
            scale_floor=0.05,
        )
    )
    context = ContextKey("METRO", "METHOD", "REF", "TECH")
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    for idx in range(30):
        value = 0.1 + (1e-6 if idx % 2 else -1e-6)
        obs = ScalarFeatureObservation(
            f"E{idx}", "HEAD_A", context, "MATCH", value,
            start + timedelta(minutes=idx), start + timedelta(minutes=idx),
        )
        snapshot = manager.snapshot(obs)
        if snapshot is None or not snapshot.adequate:
            manager.bootstrap(obs)
        else:
            self_z, anchor_z = manager.robust_z(obs, snapshot)
            manager.admit_after_score(
                obs,
                self_z=self_z,
                anchor_z=anchor_z,
                data_pipeline_suspect=False,
            )

    probe = ScalarFeatureObservation(
        "probe", "HEAD_A", context, "MATCH", 0.11,
        start + timedelta(hours=2), start + timedelta(hours=2),
    )
    snapshot = manager.snapshot(probe)
    assert snapshot is not None
    _, anchor_z = manager.robust_z(probe, snapshot)
    assert abs(anchor_z) < 1.0
    assert snapshot.anchor_mad >= 0.05
