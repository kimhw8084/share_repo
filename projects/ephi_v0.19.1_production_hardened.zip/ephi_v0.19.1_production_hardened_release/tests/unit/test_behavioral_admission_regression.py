from dataclasses import replace
from datetime import datetime, timedelta, timezone

from ephi.detectors.behavioral import BehavioralDetectorEngine
from ephi.domain.context import ContextKey
from ephi.domain.features import ScalarFeatureObservation


def test_each_asset_uses_its_own_anchor_z_for_reference_admission() -> None:
    engine = BehavioralDetectorEngine()
    context = ContextKey("OP", "R", "P", "T")
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)

    # Establish independent stable references.
    history = []
    for idx in range(80):
        t = start + timedelta(minutes=idx)
        history.extend(
            [
                ScalarFeatureObservation(f"A-{idx}", "A", context, "F", 100.0, t, t),
                ScalarFeatureObservation(f"B-{idx}", "B", context, "F", 200.0, t, t),
            ]
        )
    engine.process_batch(history)

    probe_time = start + timedelta(minutes=100)
    # A is normal and should be admitted; B is extreme and must be rejected.
    a = ScalarFeatureObservation("A-probe", "A", context, "F", 100.0, probe_time, probe_time)
    b = ScalarFeatureObservation("B-probe", "B", context, "F", 210.0, probe_time, probe_time)
    before_a = len(engine.references.debug_values(a))
    before_b = len(engine.references.debug_values(b))
    engine.process_batch([a, b])
    after_a = len(engine.references.debug_values(a))
    after_b = len(engine.references.debug_values(b))

    assert after_a == before_a + 1
    assert after_b == before_b
