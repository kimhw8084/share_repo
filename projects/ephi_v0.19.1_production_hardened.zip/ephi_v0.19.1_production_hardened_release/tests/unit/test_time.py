from datetime import datetime, timedelta, timezone

import pytest

from ephi.domain.time import KnowledgeTime
from ephi.errors import InvalidKnowledgeTimeError


def test_knowledge_time_visibility() -> None:
    event = datetime(2026, 1, 1, tzinfo=timezone.utc)
    available = event + timedelta(minutes=3)
    kt = KnowledgeTime(event_time=event, available_at=available)
    assert not kt.visible_as_of(event + timedelta(minutes=2))
    assert kt.visible_as_of(available)


def test_available_at_cannot_precede_event() -> None:
    event = datetime(2026, 1, 1, tzinfo=timezone.utc)
    with pytest.raises(InvalidKnowledgeTimeError):
        KnowledgeTime(event_time=event, available_at=event - timedelta(seconds=1))
