from ephi.audit import DEFAULT_CAPABILITY_RULES
from ephi.audit_contracts import DEFAULT_DATASET_CONTRACTS
from ephi.domain.capabilities import Capability

def test_history_and_rca_data_reality_contracts_exist():
    names={x.logical_name for x in DEFAULT_DATASET_CONTRACTS}
    caps={x.capability for x in DEFAULT_CAPABILITY_RULES}
    assert 'historical_cases' in names
    assert Capability.HISTORICAL_CASES in caps
    assert Capability.RCA_ROUTE_INDEX in caps
