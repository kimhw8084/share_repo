import numpy as np

from ephi.domain.data_reality import QualificationState
from ephi.domain.measurement_scale import derive_measurement_scale_policy


def test_configured_resolution_qualifies_scale_floor() -> None:
    values = np.repeat(np.arange(100, dtype=float) * 0.01, 2)
    policy = derive_measurement_scale_policy(
        "CD",
        values,
        configured_resolution=0.01,
        configured_uncertainty=0.02,
    )
    assert policy.state == QualificationState.QUALIFIED
    assert policy.robust_scale_floor >= 0.02
    assert policy.practical_effect_floor >= 0.02


def test_observed_quantization_without_instrument_metadata_is_provisional() -> None:
    values = np.repeat(np.arange(50, dtype=float) * 0.005, 3)
    policy = derive_measurement_scale_policy("THICKNESS", values)
    assert policy.state == QualificationState.PROVISIONAL
    assert policy.observed_quantization is not None
    assert policy.observed_quantization > 0
