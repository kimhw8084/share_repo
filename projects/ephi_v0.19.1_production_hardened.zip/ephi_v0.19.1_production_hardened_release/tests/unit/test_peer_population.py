from ephi.populations.peers import build_peer_snapshots


def test_peer_snapshot_uses_physical_change_and_detects_fleet_shift() -> None:
    snapshots = build_peer_snapshots(
        {
            "A": (3.0, 0.6),
            "B": (2.8, 0.7),
            "C": (3.2, 0.5),
            "D": (3.1, 0.8),
        }
    )
    target = snapshots["A"]
    assert "A" not in target.peer_asset_ids
    assert target.adequate
    assert target.fleet_shift_z > 3.5
    assert abs((3.0 - target.peer_center_change) / target.peer_change_mad) < 1.0


def test_three_member_peer_cohort_resists_single_poisoned_member() -> None:
    snapshots = build_peer_snapshots(
        {
            "BAD": (3.0, 1.0),
            "GOOD1": (0.0, 1.0),
            "GOOD2": (0.1, 1.0),
        }
    )
    assert snapshots["BAD"].adequate
    bad_residual = (3.0 - snapshots["BAD"].peer_center_change) / snapshots["BAD"].peer_change_mad
    good_residual = (0.0 - snapshots["GOOD1"].peer_center_change) / snapshots["GOOD1"].peer_change_mad
    assert bad_residual > 2.5
    assert abs(good_residual) < 0.5
