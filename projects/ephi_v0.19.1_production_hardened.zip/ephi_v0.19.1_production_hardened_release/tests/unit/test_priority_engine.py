from datetime import datetime,timedelta,timezone
from ephi.domain.exposure import EpisodeOnsetWindow,FutureRouteStep,WIPMaterialState
from ephi.domain.health import HealthSeverity
from ephi.domain.priority import OperationalPriority
from ephi.exposure.engine import ExposureEngine
from ephi.exposure.priority import OperationalPriorityEngine
NOW=datetime(2026,8,19,12,0,tzinfo=timezone.utc)
def snap(n):
    w=tuple(WIPMaterialState(f"W{i}",1,(FutureRouteStep(f"W{i}",2,"OP",("A",),eta=NOW+timedelta(minutes=20),likely_asset_id="A"),)) for i in range(n))
    return ExposureEngine().assess(episode_id="E",asset_id="A",operation="OP",as_of=NOW,onset=EpisodeOnsetWindow(NOW,NOW,NOW),wip=w)
def test_priority_changes_with_wip_not_technical_severity():
    e=OperationalPriorityEngine(); empty=ExposureEngine().assess(episode_id="E",asset_id="A",operation="OP",as_of=NOW,onset=EpisodeOnsetWindow(NOW,NOW,NOW)); sev=HealthSeverity.INVESTIGATE
    a=e.assess(episode_id="E",technical_severity=sev,technical_confidence=.9,exposure=empty); b=e.assess(episode_id="E",technical_severity=sev,technical_confidence=.9,exposure=snap(2))
    assert sev is HealthSeverity.INVESTIGATE and a.containment_priority is OperationalPriority.P4 and b.containment_priority is OperationalPriority.P2
def test_low_confidence_cannot_create_p1_containment():
    p=OperationalPriorityEngine().assess(episode_id="E",technical_severity=HealthSeverity.URGENT,technical_confidence=.2,exposure=snap(100))
    assert p.containment_priority is not OperationalPriority.P1
