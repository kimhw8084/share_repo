from datetime import datetime,timedelta,timezone
from ephi.domain.exposure import *
from ephi.domain.health import HealthSeverity
from ephi.exposure.engine import ExposureEngine

def t(m): return datetime(2026,8,19,12,0,tzinfo=timezone.utc)+timedelta(minutes=m)
def test_onset_window_drives_past_exposure():
    s=ExposureEngine().assess(episode_id="E",asset_id="A",operation="OP",as_of=t(60),onset=EpisodeOnsetWindow(t(10),t(20),t(30),.8),historical_executions=(HistoricalExecutionExposure("PRE","X0","A","OP",t(5)),HistoricalExecutionExposure("POSS","X1","A","OP",t(15)),HistoricalExecutionExposure("DEF","X2","A","OP",t(35))))
    assert s.possibly_exposed==1 and s.definitely_exposed==1 and {x.material_id for x in s.items}=={"POSS","DEF"}
def test_healthy_alternative_makes_likely_wip_preventable_but_unhealthy_does_not():
    w=(WIPMaterialState("W",1,(FutureRouteStep("W",2,"OP",("A","B"),eta=t(30),likely_asset_id="A"),)),)
    good=AlternativeAssetCandidate("B",True,AssetAvailability.AVAILABLE,HealthSeverity.NORMAL,.95,.9)
    s=ExposureEngine().assess(episode_id="E",asset_id="A",operation="OP",as_of=t(10),onset=EpisodeOnsetWindow(t(0),t(0),t(0)),wip=w,alternatives=(good,))
    assert s.future_preventable==1 and s.items[0].preventability is PreventabilityState.HIGH and s.items[0].alternatives[0].preferred
    bad=AlternativeAssetCandidate("B",True,AssetAvailability.AVAILABLE,HealthSeverity.INVESTIGATE,.95,.9)
    s2=ExposureEngine().assess(episode_id="E",asset_id="A",operation="OP",as_of=t(10),onset=EpisodeOnsetWindow(t(0),t(0),t(0)),wip=w,alternatives=(bad,))
    assert s2.future_likely==1 and s2.future_preventable==0 and s2.no_qualified_alternative==1
def test_unassigned_eligible_route_is_possible_and_committed_is_distinct():
    p=ExposureEngine().assess(episode_id="E",asset_id="A",operation="OP",as_of=t(0),onset=EpisodeOnsetWindow(t(0),t(0),t(0)),wip=(WIPMaterialState("W",1,(FutureRouteStep("W",2,"OP",("A","B"),eta=t(60)),)),))
    assert p.future_possible==1 and p.future_likely==0
    c=ExposureEngine().assess(episode_id="E",asset_id="A",operation="OP",as_of=t(0),onset=EpisodeOnsetWindow(t(0),t(0),t(0)),wip=(WIPMaterialState("W",1,(FutureRouteStep("W",2,"OP",("A","B"),eta=t(5),committed_asset_id="A"),)),))
    assert c.currently_committed==1 and c.items[0].preventability is PreventabilityState.ALREADY_COMMITTED

def test_repeated_executions_do_not_double_count_material_and_not_yet_mature_is_pending():
    s=ExposureEngine().assess(
        episode_id="E",asset_id="A",operation="OP",as_of=t(60),onset=EpisodeOnsetWindow(t(10),t(20),t(30),.9),
        historical_executions=(
            HistoricalExecutionExposure("W","X1","A","OP",t(35),quality_state="NOT_YET_MATURE"),
            HistoricalExecutionExposure("W","X2","A","OP",t(45),quality_state="NOT_YET_MATURE"),
        ),
    )
    assert s.definitely_exposed==1
    assert len(s.items)==1
    assert s.items[0].suspect_execution_ids==("X1","X2")
    assert "MULTIPLE_SUSPECT_EXECUTIONS" in s.items[0].reason_codes
    assert s.quality_mature==0 and s.quality_pending==1
