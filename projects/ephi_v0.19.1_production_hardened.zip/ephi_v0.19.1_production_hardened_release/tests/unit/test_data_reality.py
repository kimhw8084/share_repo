from ephi.audit import DataRealityAuditor, StaticAuditBackend
from ephi.domain.capabilities import Capability
from ephi.domain.data_reality import (
    DatasetContract,
    DatasetProfile,
    DatasetRole,
    JoinContract,
    JoinProfile,
    QualificationState,
)


def test_data_reality_audit_preserves_provisional_join_semantics() -> None:
    contracts = (
        DatasetContract(
            logical_name="executions",
            role=DatasetRole.EXECUTION,
            required_columns=("execution_id", "event_time", "available_at"),
            event_time_column="event_time",
            available_at_column="available_at",
        ),
        DatasetContract(
            logical_name="signals",
            role=DatasetRole.SIGNAL,
            required_columns=("execution_id", "signal_id", "value", "available_at"),
            available_at_column="available_at",
        ),
    )
    backend = StaticAuditBackend(
        datasets={
            "executions": DatasetProfile(
                logical_name="executions",
                row_count=1000,
                columns=("execution_id", "event_time", "available_at"),
                event_time_min="2026-01-01",
                event_time_max="2026-01-02",
                available_at_min="2026-01-01",
                available_at_max="2026-01-02",
            ),
            "signals": DatasetProfile(
                logical_name="signals",
                row_count=5000,
                columns=("execution_id", "signal_id", "value", "available_at"),
                available_at_min="2026-01-01",
                available_at_max="2026-01-02",
            ),
        },
        joins={
            "execution_signal": JoinProfile(
                join_id="execution_signal",
                left_rows=1000,
                matched_left_rows=980,
                matched_right_rows=4900,
            )
        },
    )
    report = DataRealityAuditor(backend).run(
        contracts,
        (
            JoinContract(
                join_id="execution_signal",
                left_dataset="executions",
                right_dataset="signals",
                left_keys=("execution_id",),
                right_keys=("execution_id",),
                required_for=(Capability.FDC_SCALAR,),
            ),
        ),
    )
    fdc = report.capability(Capability.FDC_SCALAR)
    assert fdc is not None
    assert fdc.state == QualificationState.PROVISIONAL
    assert "acceptance threshold" in report.joins[0].reasons[0]


def test_missing_required_column_fails_dataset() -> None:
    contract = DatasetContract(
        logical_name="metrology",
        role=DatasetRole.METROLOGY,
        required_columns=("measurement_id", "available_at"),
    )
    report = DataRealityAuditor(
        StaticAuditBackend(
            {"metrology": DatasetProfile("metrology", 12, ("measurement_id",))}
        )
    ).run((contract,))
    assert report.datasets[0].state == QualificationState.FAILED
    assert report.datasets[0].missing_required_columns == ("available_at",)
