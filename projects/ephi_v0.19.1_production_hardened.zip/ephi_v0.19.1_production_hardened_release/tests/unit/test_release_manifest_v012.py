from datetime import datetime, timezone

from ephi.config import EphiConfig
from ephi.registry.releases import build_release_manifest


def test_release_identity_includes_company_port_code(tmp_path):
    (tmp_path / "src/ephi").mkdir(parents=True)
    (tmp_path / "configs").mkdir()
    (tmp_path / "company_port/src/ephi_company").mkdir(parents=True)
    (tmp_path / "src/ephi/x.py").write_text("x=1\n", encoding="utf-8")
    (tmp_path / "configs/base.yaml").write_text("app:\n  environment: test\n", encoding="utf-8")
    hook = tmp_path / "company_port/src/ephi_company/auth.py"
    hook.write_text("ROLE='A'\n", encoding="utf-8")
    when = datetime(2026, 8, 19, tzinfo=timezone.utc)
    first = build_release_manifest(tmp_path, EphiConfig(), created_at=when)
    hook.write_text("ROLE='B'\n", encoding="utf-8")
    second = build_release_manifest(tmp_path, EphiConfig(), created_at=when)
    assert first.code_tree_sha256 != second.code_tree_sha256
    assert first.release_id != second.release_id


def test_release_identity_ignores_transient_build_artifacts(tmp_path):
    from ephi.registry.releases import _code_tree_hash

    (tmp_path / "src/ephi").mkdir(parents=True)
    (tmp_path / "src/ephi/core.py").write_text("VALUE = 1\n")
    (tmp_path / "company_port/src/ephi_company").mkdir(parents=True)
    (tmp_path / "company_port/src/ephi_company/auth.py").write_text("AUTH = 1\n")

    before = _code_tree_hash(tmp_path)

    transient = tmp_path / "company_port/build/lib/ephi_company"
    transient.mkdir(parents=True)
    (transient / "auth.py").write_text("AUTH = 999\n")
    egg = tmp_path / "company_port/src/ephi_company_port.egg-info"
    egg.mkdir(parents=True)
    (egg / "generated.py").write_text("SHOULD_NOT_COUNT = True\n")

    after = _code_tree_hash(tmp_path)
    assert after == before
