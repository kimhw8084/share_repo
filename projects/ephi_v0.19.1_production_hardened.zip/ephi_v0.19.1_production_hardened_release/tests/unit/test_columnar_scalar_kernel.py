from datetime import datetime, timedelta, timezone

import numpy as np

from ephi.detectors.columnar import peer_decompose_arrays, score_scalar_arrays
from ephi.domain.context import ContextKey
from ephi.domain.features import ScalarFeatureObservation
from ephi.populations.materialized import ReferenceStateIndex
from ephi.populations.references import ReferenceManager


def test_columnar_scalar_scores_match_reference_manager_semantics() -> None:
    manager = ReferenceManager()
    context = ContextKey("OP", "R", "P", "T")
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    for asset_idx, asset_id in enumerate(["A", "B", "C"]):
        for idx in range(80):
            t = start + timedelta(minutes=idx)
            obs = ScalarFeatureObservation(
                f"{asset_id}-{idx}",
                asset_id,
                context,
                "F",
                100.0 + asset_idx + np.sin(idx / 7.0) * 0.2,
                t,
                t,
            )
            snapshot = manager.snapshot(obs)
            if snapshot is None or not snapshot.adequate:
                manager.bootstrap(obs)
            else:
                self_z, anchor_z = manager.robust_z(obs, snapshot)
                manager.admit_after_score(
                    obs,
                    self_z=self_z,
                    anchor_z=anchor_z,
                    data_pipeline_suspect=False,
                )

    probe_time = start + timedelta(hours=4)
    probes = [
        ScalarFeatureObservation("A-x", "A", context, "F", 100.5, probe_time, probe_time),
        ScalarFeatureObservation("B-x", "B", context, "F", 101.7, probe_time, probe_time),
        ScalarFeatureObservation("C-x", "C", context, "F", 103.2, probe_time, probe_time),
    ]
    index = ReferenceStateIndex(manager.materialized_state())
    ref_batch = index.lookup_many(probes)
    scores = score_scalar_arrays(np.array([item.value for item in probes]), ref_batch)

    for idx, probe in enumerate(probes):
        snapshot = manager.snapshot(probe)
        assert snapshot is not None and snapshot.adequate
        expected_self, expected_anchor = manager.robust_z(probe, snapshot)
        assert np.isclose(scores.self_z[idx], expected_self)
        assert np.isclose(scores.anchor_z[idx], expected_anchor)
        assert np.isclose(scores.physical_change[idx], probe.value - snapshot.anchor_median)


def test_peer_columnar_decomposition_separates_local_from_fleet_shift() -> None:
    local = peer_decompose_arrays(
        np.array([3.0, 0.1, -0.1, 0.0]),
        np.ones(4),
    )
    assert local.adequate.all()
    assert local.peer_change_z[0] > 2.5
    assert abs(local.fleet_shift_z[0]) < 0.5

    common = peer_decompose_arrays(
        np.array([3.0, 3.1, 2.9, 3.0]),
        np.ones(4),
    )
    assert common.adequate.all()
    assert np.all(np.abs(common.peer_change_z) < 0.5)
    assert np.all(common.fleet_shift_z > 2.5)
