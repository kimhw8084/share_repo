from pathlib import Path

import pytest

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.port import PortRunIdentity, PortStage, PortStageState
from ephi.port.orchestrator import PortBootstrapOrchestrator, PortIdentityMismatchError
from ephi.port.qualification import ReferencePortRuntime


def identity(config_hash="cfg"):
    return PortRunIdentity(
        release_id="R",
        package_version="0.12.0",
        config_hash=config_hash,
        family_id="METROLOGY",
        environment="shadow",
    )


def test_ordered_port_bootstrap_passes():
    runtime = ReferencePortRuntime()
    report = PortBootstrapOrchestrator(runtime=runtime, identity=identity()).run()
    assert report.shadow_ready
    assert [item.stage for item in report.stages] == list(PortBootstrapOrchestrator.stage_order())
    assert all(item.state == PortStageState.PASSED for item in report.stages)


def test_failed_stage_blocks_downstream():
    runtime = ReferencePortRuntime(fail_stage=PortStage.DATA_REALITY)
    report = PortBootstrapOrchestrator(runtime=runtime, identity=identity()).run()
    assert report.stage(PortStage.DATA_REALITY).state == PortStageState.FAILED
    assert report.stage(PortStage.STATE_BOOTSTRAP).state == PortStageState.BLOCKED
    assert not report.shadow_ready


def test_resume_does_not_repeat_passed_stages(tmp_path: Path):
    runtime = ReferencePortRuntime()
    store = SqliteStateStore(tmp_path / "state.sqlite3")
    PortBootstrapOrchestrator(runtime=runtime, identity=identity(), state_store=store).run()
    calls = dict(runtime.calls)
    PortBootstrapOrchestrator(runtime=runtime, identity=identity(), state_store=store).run()
    assert dict(runtime.calls) == calls


def test_identity_change_refuses_old_bootstrap_state(tmp_path: Path):
    store = SqliteStateStore(tmp_path / "state.sqlite3")
    runtime = ReferencePortRuntime()
    PortBootstrapOrchestrator(runtime=runtime, identity=identity(), state_store=store).run()
    with pytest.raises(PortIdentityMismatchError):
        PortBootstrapOrchestrator(runtime=runtime, identity=identity("new-config"), state_store=store)
