from pathlib import Path


def test_shadow_overlay_preserves_base_env_and_has_bootstrap_job():
    root = Path("company_port/deploy")
    base = (root / "base/ephi-shadow.yaml").read_text(encoding="utf-8")
    kustomization = (root / "overlays/shadow/kustomization.yaml").read_text(encoding="utf-8")
    job = (root / "overlays/shadow/bootstrap-job.yaml").read_text(encoding="utf-8")
    assert "EPHI_RUNTIME_ROLE" in base
    assert "kind: Deployment" in kustomization
    assert "/spec/template/spec/containers/0/env/-" in kustomization
    assert "EPHI_CONFIG_PATHS" in kustomization
    assert "ephi_company.bootstrap" in job
    assert "--release-manifest" in job
    assert "sqlite" not in (base + kustomization + job).lower()
