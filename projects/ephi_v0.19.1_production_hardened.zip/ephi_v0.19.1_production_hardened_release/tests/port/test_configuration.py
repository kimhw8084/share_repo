from ephi.port.configuration import configured_paths, load_runtime_config


def test_runtime_config_uses_environment_paths(monkeypatch, tmp_path):
    cfg = tmp_path / "company.yaml"
    cfg.write_text("app:\n  environment: env-shadow\n", encoding="utf-8")
    monkeypatch.setenv("EPHI_CONFIG_PATHS", str(cfg))
    assert configured_paths() == (str(cfg),)
    assert load_runtime_config().app.environment == "env-shadow"


def test_explicit_config_paths_override_environment(monkeypatch, tmp_path):
    a = tmp_path / "a.yaml"; a.write_text("app:\n  environment: A\n", encoding="utf-8")
    b = tmp_path / "b.yaml"; b.write_text("app:\n  environment: B\n", encoding="utf-8")
    monkeypatch.setenv("EPHI_CONFIG_PATHS", str(a))
    assert load_runtime_config([str(b)]).app.environment == "B"
