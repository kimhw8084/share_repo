from ephi.port.qualification import run_port_kit_qualification


def test_port_kit_qualification_passes():
    report = run_port_kit_qualification(".")
    assert report.passed
    assert report.ordered_bootstrap
    assert report.downstream_blocking
    assert report.resume_idempotent
    assert report.identity_mismatch_blocked
    assert report.scaffold_complete
    assert report.deployment_no_sqlite
    assert report.fail_closed_hooks_present
