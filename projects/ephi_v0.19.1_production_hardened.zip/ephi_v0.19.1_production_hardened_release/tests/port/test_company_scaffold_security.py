from pathlib import Path


def test_company_app_scaffold_enforces_identity_and_roles():
    text = Path("company_port/src/ephi_company/app.py").read_text(encoding="utf-8")
    assert '@app.middleware("http")' in text
    assert "company identity required" in text
    assert "insufficient EPHI role" in text
    assert '{"/healthz", "/version"}' in text


def test_notification_scaffold_uses_ephi_delivery_gate():
    text = Path("company_port/src/ephi_company/notifications.py").read_text(encoding="utf-8")
    assert "NotificationDeliveryGate" in text
    assert "self.gate.allowed" in text


def test_company_qualification_approval_and_gate_paths_require_admin_role():
    app_text = Path("company_port/src/ephi_company/app.py").read_text(encoding="utf-8")
    auth_text = Path("company_port/src/ephi_company/auth.py").read_text(encoding="utf-8")
    assert 'request.url.path.endswith("/promotion/approve")' in app_text
    assert 'request.url.path.endswith("/gates")' in app_text
    assert 'request.url.path.endswith("/plan")' in app_text
    assert 'ADMIN_ROLES = frozenset({"EPHI_ADMIN"})' in auth_text


def test_company_state_scaffold_requires_snapshot_restore_backend_for_dr():
    text = Path("company_port/src/ephi_company/state.py").read_text(encoding="utf-8")
    bootstrap = Path("company_port/src/ephi_company/bootstrap.py").read_text(encoding="utf-8")
    assert "SnapshotStateStore" in text
    assert "build_recovery_state_store" in text
    assert "ordinary CAS alone is insufficient" in text
    assert "build_recovery_store" in bootstrap


def test_company_recovery_scaffold_is_operator_only_and_clean_target_only():
    text = Path("company_port/src/ephi_company/recovery.py").read_text(encoding="utf-8")
    app = Path("company_port/src/ephi_company/app.py").read_text(encoding="utf-8")
    assert "create_state_backup" in text
    assert "restore_state_backup" in text
    assert "confirm_clean_target" in text
    assert "require_empty=True" in text
    assert "/recovery/restore" not in app
