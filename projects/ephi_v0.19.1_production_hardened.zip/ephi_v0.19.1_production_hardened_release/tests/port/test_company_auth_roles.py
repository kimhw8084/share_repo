from ephi_company.auth import CompanyIdentity, authorized


def test_company_qualification_admin_role_is_stricter_than_engineer_write() -> None:
    engineer = CompanyIdentity(subject="eng", roles=frozenset({"EPHI_ENGINEER"}))
    admin = CompanyIdentity(subject="admin", roles=frozenset({"EPHI_ADMIN"}))
    assert authorized(engineer, write=True)
    assert not authorized(engineer, write=True, admin=True)
    assert authorized(admin, write=True, admin=True)
