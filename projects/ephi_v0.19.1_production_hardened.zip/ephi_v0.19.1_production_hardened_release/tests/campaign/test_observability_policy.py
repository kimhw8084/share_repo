from pathlib import Path

from ephi.launch.observability import load_campaign_retention_policy, load_campaign_slo_policy


def test_campaign_policies_load() -> None:
    slo = load_campaign_slo_policy(Path("configs/campaign/metrology_reference.yaml"))
    retention = load_campaign_retention_policy(Path("configs/campaign/retention_reference.yaml"))
    assert slo.max_retries_per_stage == 2
    assert slo.stage_max_elapsed_seconds["PRODUCTION_REPLAY_SCALE"] > 0
    assert retention.authoritative_retention_days >= retention.failed_attempt_retention_days
    assert retention.require_immutable_evidence
