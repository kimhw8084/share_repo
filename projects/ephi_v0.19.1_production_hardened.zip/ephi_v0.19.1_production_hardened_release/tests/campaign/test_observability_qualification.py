from ephi.launch.observability_qualification import run_campaign_observability_qualification


def test_campaign_observability_qualification() -> None:
    report = run_campaign_observability_qualification()
    assert report.passed, report.model_dump()
