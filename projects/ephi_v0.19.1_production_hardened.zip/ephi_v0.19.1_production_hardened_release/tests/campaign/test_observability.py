from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

from ephi.adapters.local.filesystem_artifact_store import FileSystemArtifactStore
from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.campaign_observability import (
    CampaignFailureCategory,
    CampaignReadinessState,
    EvidenceComparisonState,
    ReconciliationStatus,
)
from ephi.domain.launch import CampaignStage, EvidenceProvenance
from ephi.domain.operations import CertificationState
from ephi.launch.execution import CampaignExecutionController
from ephi.launch.observability import (
    CampaignObservabilityService,
    classify_campaign_failure,
    compare_campaigns,
    verify_campaign_export,
)
from ephi.launch.reference_executor import ReferenceLaunchEvidenceExecutor
from ephi.launch.registry import ShadowLaunchWorkspaceRepository


def _stack(tmp_path: Path, *, fail_once=frozenset()):
    family = "METROLOGY_REFERENCE"
    release = "ephi-0.18.0-test"
    config_hash = "c" * 64
    executor = ReferenceLaunchEvidenceExecutor(
        tmp_path / "collected",
        family_id=family,
        release_id=release,
        config_hash=config_hash,
        provenance=EvidenceProvenance.INTERNAL_MEASURED,
        fail_once=fail_once,
    )
    repo = ShadowLaunchWorkspaceRepository(SqliteStateStore(tmp_path / "launch.sqlite3"))
    artifacts = FileSystemArtifactStore(tmp_path / "artifacts")
    controller = CampaignExecutionController(
        family_id=family,
        release_id=release,
        config_hash=config_hash,
        executor=executor,
        repository=repo,
        artifact_store=artifacts,
        required_provenance=EvidenceProvenance.INTERNAL_MEASURED,
    )
    service = CampaignObservabilityService(repo, artifact_store=artifacts)
    return controller, repo, artifacts, service


def test_readiness_reconciliation_export_and_retention(tmp_path: Path) -> None:
    controller, _, _, service = _stack(tmp_path)
    controller.run(campaign_id="C1", target_state=CertificationState.OFFLINE_QUALIFIED, actor="eng")
    now = datetime.now(timezone.utc)
    view = service.readiness("METROLOGY_REFERENCE", "C1", now=now)
    assert view.state == CampaignReadinessState.READY_FOR_HANDOFF
    assert view.reconciliation.status == ReconciliationStatus.CONSISTENT
    assert view.reconciliation.evidence_fingerprint.evidence_count == 3
    assert view.reconciliation.evidence_fingerprint.replay_count == 1
    assert view.slo.passed
    retention = service.retention("METROLOGY_REFERENCE", "C1", now=now)
    assert not retention.blockers
    assert any(item.item_type == "EVIDENCE" for item in retention.items)
    first = service.export("METROLOGY_REFERENCE", "C1", now=now)
    second = service.export("METROLOGY_REFERENCE", "C1", now=now)
    assert first.export_sha256 == second.export_sha256
    assert len(first.export_sha256) == 64


def test_retry_changes_execution_not_semantic_evidence(tmp_path: Path) -> None:
    controller, repo, _, service = _stack(
        tmp_path, fail_once=frozenset({CampaignStage.PRODUCTION_REPLAY_SCALE})
    )
    try:
        controller.run(campaign_id="RETRY", target_state=CertificationState.OFFLINE_QUALIFIED, actor="eng")
    except RuntimeError:
        pass
    controller.run(campaign_id="RETRY", target_state=CertificationState.OFFLINE_QUALIFIED, actor="eng")
    retry_fp = service.reconciliation("METROLOGY_REFERENCE", "RETRY").evidence_fingerprint
    assert retry_fp.evidence_count == 3
    assert any(item.retries == 1 for item in service.readiness("METROLOGY_REFERENCE", "RETRY").stages)

    # Same semantic stage outputs in a fresh campaign reuse immutable evidence, but the
    # semantic evidence fingerprint stays equal even though attempt IDs/times differ.
    controller.run(campaign_id="CLEAN", target_state=CertificationState.OFFLINE_QUALIFIED, actor="eng")
    comparison = compare_campaigns(
        repo.load("METROLOGY_REFERENCE"),
        repo.campaign("METROLOGY_REFERENCE", "CLEAN"),
        repo.campaign("METROLOGY_REFERENCE", "CLEAN"),
    )
    assert comparison.state == EvidenceComparisonState.IDENTICAL
    clean_fp = service.reconciliation("METROLOGY_REFERENCE", "CLEAN").evidence_fingerprint
    assert retry_fp.evidence_sha256 == clean_fp.evidence_sha256
    assert retry_fp.execution_sha256 != clean_fp.execution_sha256


def test_artifact_tamper_blocks_reconciliation(tmp_path: Path) -> None:
    controller, repo, _, service = _stack(tmp_path)
    controller.run(campaign_id="C1", target_state=CertificationState.OFFLINE_QUALIFIED, actor="eng")
    workspace = repo.load("METROLOGY_REFERENCE")
    receipt = next(item for item in workspace.evidence if item.evidence_id == "REF-DATA_REALITY")
    assert receipt.artifact_ref is not None
    Path(receipt.artifact_ref.locator).write_text("tampered", encoding="utf-8")
    result = service.reconciliation("METROLOGY_REFERENCE", "C1")
    assert result.status == ReconciliationStatus.BLOCKED
    assert not result.artifact_integrity_passed
    assert any("artifact integrity" in item for item in result.blockers)


def test_campaign_scope_excludes_unreferenced_family_evidence(tmp_path: Path) -> None:
    controller, repo, _, service = _stack(tmp_path)
    controller.run(campaign_id="C1", target_state=CertificationState.OFFLINE_QUALIFIED, actor="eng")
    workspace = repo.load("METROLOGY_REFERENCE")
    extra = workspace.evidence[0].model_copy(update={"evidence_id": "UNRELATED-EVIDENCE"})
    repo.attach_evidence(extra, actor="other")
    fp = service.reconciliation("METROLOGY_REFERENCE", "C1").evidence_fingerprint
    assert "UNRELATED-EVIDENCE" not in fp.evidence_ids
    assert fp.evidence_count == 3



def test_completed_campaign_slo_does_not_age_after_completion(tmp_path: Path) -> None:
    controller, _, _, service = _stack(tmp_path)
    controller.run(campaign_id="OLD", target_state=CertificationState.OFFLINE_QUALIFIED, actor="eng")
    campaign = service.campaign("METROLOGY_REFERENCE", "OLD")
    much_later = campaign.updated_at + timedelta(days=90)
    report = service.slo("METROLOGY_REFERENCE", "OLD", now=much_later)
    assert report.passed
    assert report.campaign_elapsed_seconds < 3600


def test_qualification_export_can_be_published_immutably(tmp_path: Path) -> None:
    controller, _, artifacts, service = _stack(tmp_path)
    controller.run(campaign_id="EXP", target_state=CertificationState.OFFLINE_QUALIFIED, actor="eng")
    now = datetime.now(timezone.utc)
    export = service.export("METROLOGY_REFERENCE", "EXP", now=now)
    assert verify_campaign_export(export)
    published = service.publish_export("METROLOGY_REFERENCE", "EXP", now=now)
    from ephi.adapters.base.artifact_store import ArtifactRef
    materialized = artifacts.materialize(ArtifactRef(
        artifact_id=published.artifact.artifact_id,
        content_hash=published.artifact.content_hash,
        locator=published.artifact.locator,
    ))
    assert materialized.exists()
    assert published.export_sha256 == export.export_sha256


def test_failure_taxonomy() -> None:
    assert classify_campaign_failure("ValueError: source snapshot identity mismatch") == CampaignFailureCategory.SOURCE_IDENTITY
    assert classify_campaign_failure("ValueError: published evidence hash mismatch") == CampaignFailureCategory.ARTIFACT_INTEGRITY
    assert classify_campaign_failure("RuntimeError: stage evidence did not pass") == CampaignFailureCategory.EVIDENCE_REJECTED
    assert classify_campaign_failure(None) == CampaignFailureCategory.NONE
