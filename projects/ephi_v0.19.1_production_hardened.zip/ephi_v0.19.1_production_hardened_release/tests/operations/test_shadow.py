from datetime import datetime, timezone

from ephi.operations.shadow import ShadowRunner


def test_challenger_never_changes_production_output_and_failure_is_isolated() -> None:
    runner = ShadowRunner(
        "champion",
        lambda x: x * 2,
        {"challenger": lambda x: x * 3, "broken": lambda x: 1 / 0},
        actionable=lambda x: x > 0,
    )
    comparison, output = runner.compare(subject_id="A", as_of=datetime.now(timezone.utc), value=2)
    assert output == 4
    assert comparison.production_output_changed is False
    assert comparison.champion.error is None
    assert next(item for item in comparison.challengers if item.candidate_id == "broken").error
