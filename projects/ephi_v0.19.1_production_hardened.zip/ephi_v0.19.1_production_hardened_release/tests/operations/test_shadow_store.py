from datetime import datetime, timezone

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.operations.shadow import ShadowRunner
from ephi.operations.shadow_store import ShadowComparisonStore


def test_shadow_comparison_store_persists_and_summarizes_without_promotion(tmp_path) -> None:
    now = datetime.now(timezone.utc)
    runner = ShadowRunner("champ", lambda x: x > 0, {"chall": lambda x: x >= 0})
    store = ShadowComparisonStore(SqliteStateStore(tmp_path / "shadow.sqlite3"))
    for idx, value in enumerate((-1, 0, 1)):
        comparison, _ = runner.compare(subject_id=f"S{idx}", as_of=now, value=value)
        store.append(comparison)
    restored = ShadowComparisonStore(SqliteStateStore(tmp_path / "shadow.sqlite3"))
    summary = restored.summaries()[0]
    assert summary.observations == 3
    assert summary.actionable_disagreements == 1
    assert summary.errors == 0
