from datetime import datetime, timezone

from ephi.config import EphiConfig
from ephi.domain.operations import ReleaseCompatibilityState
from ephi.operations.release import assess_release_compatibility
from ephi.registry.releases import build_release_manifest


def test_rollback_is_blocked_for_destructive_migration(tmp_path) -> None:
    (tmp_path / "src/ephi").mkdir(parents=True)
    (tmp_path / "configs").mkdir()
    (tmp_path / "src/ephi/x.py").write_text("x=1\n")
    source = build_release_manifest(tmp_path, EphiConfig(), created_at=datetime.now(timezone.utc))
    target = build_release_manifest(tmp_path, EphiConfig(), created_at=datetime.now(timezone.utc))
    good = assess_release_compatibility(source, target)
    bad = assess_release_compatibility(source, target, destructive_migration=True)
    assert good.rollback_allowed
    assert bad.state == ReleaseCompatibilityState.INCOMPATIBLE
    assert not bad.rollback_allowed
