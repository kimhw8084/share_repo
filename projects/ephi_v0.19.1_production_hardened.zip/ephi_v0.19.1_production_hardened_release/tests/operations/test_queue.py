from datetime import datetime, timedelta, timezone

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.runtime.queue import DurableWorkQueue, WorkStatus


def test_queue_is_idempotent_and_expired_lease_is_reclaimable(tmp_path) -> None:
    now = datetime.now(timezone.utc)
    queue = DurableWorkQueue(SqliteStateStore(tmp_path / "queue.sqlite3"))
    a = queue.enqueue("SCORE", work_id="W1", created_at=now)
    b = queue.enqueue("SCORE", work_id="W1", created_at=now)
    assert a == b and len(queue.items()) == 1
    first = queue.claim(worker_id="A", lease_seconds=10, now=now)
    assert first is not None and first.status == WorkStatus.LEASED
    restored = DurableWorkQueue(SqliteStateStore(tmp_path / "queue.sqlite3"))
    second = restored.claim(worker_id="B", lease_seconds=10, now=now + timedelta(seconds=11))
    assert second is not None and second.work_id == "W1" and second.leased_by == "B"
