from datetime import datetime, timedelta, timezone

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.operations import BackfillPriority, BackfillStatus, BootstrapPhase
from ephi.operations.backfill import BackfillController, build_backfill_chunks


def test_live_work_preempts_historical_backfill_and_progress_restores(tmp_path) -> None:
    now = datetime.now(timezone.utc)
    store = SqliteStateStore(tmp_path / "state.sqlite3")
    controller = BackfillController(store)
    historical = build_backfill_chunks(
        phase=BootstrapPhase.CANONICAL_HISTORY, scope="F", start_time=now-timedelta(days=10), end_time=now-timedelta(days=4), chunk_days=2
    )
    live = build_backfill_chunks(
        phase=BootstrapPhase.CORE_FEATURES, scope="F", start_time=now-timedelta(hours=1), end_time=now, chunk_days=1, priority=BackfillPriority.LIVE
    )
    controller.register(historical + live, at=now)
    selected = controller.next_chunk()
    assert selected is not None and selected.priority == BackfillPriority.LIVE
    controller.update(selected.chunk_id, BackfillStatus.RUNNING, at=now)
    controller.update(selected.chunk_id, BackfillStatus.SUCCEEDED, at=now)
    restored = BackfillController(store)
    assert next(item for item in restored.progress() if item.chunk.chunk_id == selected.chunk_id).status == BackfillStatus.SUCCEEDED
