from datetime import datetime, timezone

import pytest

from ephi.domain.operations import CapabilityCertification, CertificationState, GateResult, QualificationPlane
from ephi.operations.certification import CertificationService


def _base_gates():
    return (
        GateResult(plane=QualificationPlane.DATA_REALITY, passed=True),
        GateResult(plane=QualificationPlane.BEHAVIORAL_METROLOGY, passed=True),
        GateResult(plane=QualificationPlane.RUNTIME_SCALE, passed=True),
    )


def test_certification_cannot_skip_states() -> None:
    service = CertificationService()
    item = CapabilityCertification(capability_id="behavioral-health", state=CertificationState.RESEARCH, gate_results=_base_gates())
    with pytest.raises(ValueError):
        service.transition(item, CertificationState.PRODUCTION_ADVISORY, qualified_at=datetime.now(timezone.utc))


def test_quality_capability_requires_quality_plane() -> None:
    service = CertificationService()
    item = CapabilityCertification(capability_id="quality-harmfulness", state=CertificationState.RESEARCH, gate_results=_base_gates())
    with pytest.raises(ValueError, match="QUALITY_HARMFULNESS"):
        service.transition(item, CertificationState.OFFLINE_QUALIFIED, qualified_at=datetime.now(timezone.utc))


def test_manifest_cannot_self_declare_offline_without_required_planes() -> None:
    from ephi.domain.operations import FamilyQualificationManifest
    now = datetime.now(timezone.utc)
    manifest = FamilyQualificationManifest(
        family_id="F", release_id="R", state=CertificationState.OFFLINE_QUALIFIED,
        capabilities=(CapabilityCertification(capability_id="behavioral-health", state=CertificationState.OFFLINE_QUALIFIED),),
        created_at=now,
    )
    with pytest.raises(ValueError, match="required planes"):
        CertificationService().validate_family_manifest(manifest)


def test_shadow_requires_reliability_dr_plane() -> None:
    service = CertificationService()
    offline = CapabilityCertification(
        capability_id="behavioral-health",
        state=CertificationState.OFFLINE_QUALIFIED,
        gate_results=_base_gates(),
    )
    with pytest.raises(ValueError, match="RELIABILITY_DR"):
        service.transition(offline, CertificationState.SHADOW, qualified_at=datetime.now(timezone.utc))


def test_shadow_qualified_requires_engineer_shadow_plane() -> None:
    service = CertificationService()
    item = CapabilityCertification(
        capability_id="behavioral-health",
        state=CertificationState.SHADOW,
        gate_results=_base_gates() + (GateResult(plane=QualificationPlane.RELIABILITY_DR, passed=True),),
    )
    with pytest.raises(ValueError, match="ENGINEER_SHADOW"):
        service.transition(item, CertificationState.SHADOW_QUALIFIED, qualified_at=datetime.now(timezone.utc))
