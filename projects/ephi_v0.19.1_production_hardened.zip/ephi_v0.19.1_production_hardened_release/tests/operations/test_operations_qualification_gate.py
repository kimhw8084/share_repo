from pathlib import Path

from ephi.operations.qualification import run_operations_qualification


def test_operations_qualification_gate_passes() -> None:
    root = Path(__file__).parents[2]
    report = run_operations_qualification(root / "configs/deployment/shadow-reference.yaml")
    assert report.passed
