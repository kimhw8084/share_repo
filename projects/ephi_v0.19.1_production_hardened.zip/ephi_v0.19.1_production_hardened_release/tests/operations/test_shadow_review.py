from datetime import datetime, timezone

from ephi.domain.operations import EngineerShadowReview, ShadowReviewDisposition
from ephi.operations.shadow_review import ShadowGatePolicy, apply_shadow_gate


def _review(i: int, disposition: ShadowReviewDisposition, *, comparison=True, verification=True):
    return EngineerShadowReview(
        review_id=f"R{i}", episode_id=f"E{i}", reviewer="eng",
        disposition=disposition, comparison_valid=comparison,
        hypothesis_reasonable=disposition != ShadowReviewDisposition.MISLEADING,
        verification_useful=verification, reviewed_at=datetime.now(timezone.utc),
    )


def test_engineer_shadow_gate_requires_useful_low_misleading_reviews() -> None:
    reviews = tuple(_review(i, ShadowReviewDisposition.WANT_EVENT) for i in range(18)) + tuple(
        _review(i + 18, ShadowReviewDisposition.PARTIALLY_USEFUL) for i in range(2)
    )
    decision = apply_shadow_gate(reviews, ShadowGatePolicy(min_reviews=20))
    assert decision.passed
    bad = reviews[:-1] + (_review(99, ShadowReviewDisposition.MISLEADING),)
    decision_bad = apply_shadow_gate(bad, ShadowGatePolicy(min_reviews=20, max_misleading_rate=0.01))
    assert not decision_bad.passed
