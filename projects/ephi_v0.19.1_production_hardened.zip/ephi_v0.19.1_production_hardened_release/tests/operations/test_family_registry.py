from datetime import datetime, timedelta, timezone

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.operations import (
    CapabilityCertification,
    CertificationState,
    FamilyQualificationManifest,
    GateResult,
    QualificationPlane,
)
from ephi.operations.family_registry import FamilyQualificationRegistry


def _gates():
    return (
        GateResult(plane=QualificationPlane.DATA_REALITY, passed=True),
        GateResult(plane=QualificationPlane.BEHAVIORAL_METROLOGY, passed=True),
        GateResult(plane=QualificationPlane.RUNTIME_SCALE, passed=True),
        GateResult(plane=QualificationPlane.RELIABILITY_DR, passed=True),
    )


def test_family_registry_preserves_immutable_promotion_history(tmp_path) -> None:
    now = datetime.now(timezone.utc)
    store = SqliteStateStore(tmp_path / "state.sqlite3")
    registry = FamilyQualificationRegistry(store)
    offline = FamilyQualificationManifest(
        family_id="METROLOGY", release_id="R1", state=CertificationState.OFFLINE_QUALIFIED,
        capabilities=(CapabilityCertification(capability_id="behavioral-health", state=CertificationState.OFFLINE_QUALIFIED, gate_results=_gates()),),
        created_at=now,
    )
    registry.register(offline)
    shadow = FamilyQualificationManifest(
        family_id="METROLOGY", release_id="R2", state=CertificationState.SHADOW,
        capabilities=(CapabilityCertification(capability_id="behavioral-health", state=CertificationState.SHADOW, gate_results=_gates()),),
        created_at=now + timedelta(minutes=1),
    )
    registry.register(shadow)
    restored = FamilyQualificationRegistry(store)
    assert restored.latest("METROLOGY").release_id == "R2"
    assert [item.release_id for item in restored.history("METROLOGY")] == ["R1", "R2"]
