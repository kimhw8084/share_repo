from datetime import datetime, timezone

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.operations import ControlKind, ControlScope
from ephi.operations.controls import OperationalControlService


def test_notification_kill_switch_persists_without_disabling_analytics(tmp_path) -> None:
    store = SqliteStateStore(tmp_path / "state.sqlite3")
    now = datetime.now(timezone.utc)
    service = OperationalControlService(store)
    control = service.activate(
        kind=ControlKind.NOTIFICATIONS,
        scope=ControlScope.FAMILY,
        target="METROLOGY",
        reason="alert storm drill",
        actor="operator",
        activated_at=now,
    )
    restored = OperationalControlService(store)
    assert restored.blocked(ControlKind.NOTIFICATIONS, family="METROLOGY", as_of=now)
    assert not restored.blocked(ControlKind.CAPABILITY, family="METROLOGY", as_of=now)
    restored.deactivate(control.control_id, actor="operator")
    assert not restored.active_controls()
    assert len(restored.history()) == 1
    assert restored.history()[0].deactivated_at is not None
