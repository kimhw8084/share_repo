from datetime import datetime, timezone

from ephi.domain.operations import FreshnessState
from ephi.operations.telemetry import evaluate_freshness


def test_stale_or_unknown_channels_block_overall_operational_freshness() -> None:
    report = evaluate_freshness(
        as_of=datetime.now(timezone.utc),
        observations={"source": 100.0, "assessment": 4000.0, "wip": None},
        targets={"source": (900.0, 3600.0), "assessment": (1500.0, 3600.0), "wip": (300.0, 900.0)},
    )
    assert report.overall_state in {FreshnessState.STALE, FreshnessState.UNKNOWN}
    assert set(report.blockers) == {"assessment", "wip"}
