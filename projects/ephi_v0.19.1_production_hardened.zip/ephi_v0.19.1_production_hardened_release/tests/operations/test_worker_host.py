from datetime import datetime, timezone

import pytest

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.operations.worker import WorkerHost
from ephi.runtime.queue import DurableWorkQueue, WorkStatus


def test_worker_host_completes_success_and_requeues_transient_failure(tmp_path) -> None:
    queue = DurableWorkQueue(SqliteStateStore(tmp_path / "queue.sqlite3"))
    now = datetime.now(timezone.utc)
    queue.enqueue("OK", work_id="W-OK", priority=1, created_at=now)
    queue.enqueue("FAIL", work_id="W-FAIL", priority=2, created_at=now)
    calls = []

    host = WorkerHost(
        worker_id="worker-a",
        queue=queue,
        handlers={
            "OK": lambda item: calls.append(item.work_id),
            "FAIL": lambda item: (_ for _ in ()).throw(RuntimeError("transient")),
        },
        lease_seconds=30,
    )
    completed = host.run_once()
    assert completed is not None and completed.status == WorkStatus.SUCCEEDED
    assert calls == ["W-OK"]
    with pytest.raises(RuntimeError, match="transient"):
        host.run_once()
    failed_item = next(item for item in queue.items() if item.work_id == "W-FAIL")
    assert failed_item.status == WorkStatus.PENDING
    assert "transient" in (failed_item.last_error or "")
    assert failed_item.attempts == 1
