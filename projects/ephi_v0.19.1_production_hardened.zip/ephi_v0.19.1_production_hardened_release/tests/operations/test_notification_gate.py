from datetime import datetime, timezone

from ephi.domain.operations import ControlKind, ControlScope
from ephi.operations.controls import OperationalControlService
from ephi.operations.notifications import NotificationDeliveryGate


def test_notification_gate_blocks_delivery_not_scoring_capability() -> None:
    now = datetime.now(timezone.utc)
    controls = OperationalControlService()
    controls.activate(kind=ControlKind.NOTIFICATIONS, scope=ControlScope.FAMILY, target="METROLOGY", reason="test", actor="ops", activated_at=now)
    gate = NotificationDeliveryGate(controls)
    assert not gate.allowed(family="METROLOGY", as_of=now)
    assert gate.allowed(family="ETCH", as_of=now)
    assert not controls.blocked(ControlKind.CAPABILITY, family="METROLOGY", as_of=now)
