from datetime import datetime, timedelta, timezone

import pytest

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.operations import FreshnessChannel, FreshnessState
from ephi.operations.freshness import FreshnessTracker
from ephi.operations.policy import load_operations_policy


def test_freshness_tracker_persists_and_unknown_is_not_normal(tmp_path) -> None:
    now = datetime.now(timezone.utc)
    store = SqliteStateStore(tmp_path / "state.sqlite3")
    tracker = FreshnessTracker(store)
    tracker.mark(FreshnessChannel.SOURCE, refreshed_at=now, source_as_of=now - timedelta(seconds=30), version="src-v1")
    restored = FreshnessTracker(store)
    report = restored.report(as_of=now, targets={"source": (60.0, 120.0), "wip": (60.0, 120.0)})
    states = {item.metric: item.state for item in report.observations}
    assert states["source"] == FreshnessState.CURRENT
    assert states["wip"] == FreshnessState.UNKNOWN
    assert report.overall_state == FreshnessState.UNKNOWN
    with pytest.raises(ValueError):
        restored.mark(FreshnessChannel.SOURCE, refreshed_at=now - timedelta(minutes=5))


def test_reference_operations_policy_is_valid() -> None:
    from pathlib import Path
    root = Path(__file__).parents[2]
    policy = load_operations_policy(root / "configs/operations/reference.yaml")
    assert "assessment" in policy.freshness_slo
    assert "quality_model" in policy.freshness_slo
