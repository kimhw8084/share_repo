from pathlib import Path

from ephi.domain.operations import RuntimeRole
from ephi.operations.deployment import load_deployment_plan, render_kubernetes_documents


def test_shadow_deployment_has_api_service_and_optional_gpu() -> None:
    root = Path(__file__).parents[2]
    plan = load_deployment_plan(root / "configs/deployment/shadow-reference.yaml")
    docs = render_kubernetes_documents(plan)
    assert any(doc["kind"] == "Service" for doc in docs)
    gpu = next(role for role in plan.roles if role.role == RuntimeRole.GPU_WORKER)
    assert gpu.replicas == 0
    assert gpu.gpu_count == 1
    assert all(role.qualification == "PROVISIONAL" for role in plan.roles)
    api_command = " ".join(next(role.command for role in plan.roles if role.role == RuntimeRole.API))
    assert "--app-factory-module ephi_company.app" in api_command
    worker_commands = [" ".join(role.command) for role in plan.roles if role.role != RuntimeRole.API]
    assert all("--runtime-module ephi_company.runtime" in command for command in worker_commands)
    assert all("sqlite" not in command.lower() for command in worker_commands)
