import json
from datetime import datetime, timezone
from pathlib import Path

from ephi.cli.main import main
from ephi.registry.releases import ReleaseManifest


def _manifest(tmp_path: Path) -> Path:
    manifest = ReleaseManifest(
        release_id="ephi-0.17.0-dry-run",
        package_version="0.17.0",
        created_at=datetime.now(timezone.utc).isoformat(),
        code_tree_sha256="a" * 64,
        config_sha256="b" * 64,
        benchmark_sha256={},
    )
    path = tmp_path / "release.json"
    path.write_text(manifest.model_dump_json(), encoding="utf-8")
    return path


def test_reference_campaign_dry_run_resumes_retry_and_remains_non_promotable(tmp_path: Path) -> None:
    output = tmp_path / "dry-run.json"
    rc = main([
        "launch", "dry-run",
        "--release-manifest", str(_manifest(tmp_path)),
        "--inject-retry",
        "--output", str(output),
    ])
    assert rc == 0
    payload = json.loads(output.read_text(encoding="utf-8"))
    assert payload["mechanism_passed"] is True
    assert payload["promotion_ready"] is False
    assert payload["expected_blocked_on_provenance"] is True
    attempts = payload["campaign"]["attempts"]
    scale = [item for item in attempts if item["stage"] == "PRODUCTION_REPLAY_SCALE"]
    assert [item["status"] for item in scale] == ["FAILED", "PASSED"]
    assert payload["workspace"]["source_snapshots"]
