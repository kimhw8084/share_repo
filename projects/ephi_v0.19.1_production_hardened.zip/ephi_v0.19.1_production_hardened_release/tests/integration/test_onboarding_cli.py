import json
from datetime import datetime, timezone
from pathlib import Path

from ephi.cli.main import main
from ephi.domain.benchmark import BenchmarkCase, BenchmarkCaseType, BenchmarkCorpus, BenchmarkFamily, BenchmarkLabelConfidence, BenchmarkSourceKind
from ephi.domain.operations import QualificationPlane
from ephi.registry.releases import ReleaseManifest


def test_onboarding_cli_plan_to_family_manifest(tmp_path: Path) -> None:
    now = datetime.now(timezone.utc)
    data_reality = tmp_path / "data-reality.json"
    data_reality.write_text(json.dumps({
        "generated_at": now.isoformat(),
        "config_hash": "cfg",
        "capabilities": [
            {"capability": "METROLOGY", "state": "QUALIFIED", "supporting_datasets": [], "supporting_joins": [], "reasons": []},
        ],
    }), encoding="utf-8")
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "policy_version: '1'\n"
        "family_id: MET\n"
        "target_state: OFFLINE_QUALIFIED\n"
        "required_capabilities: [METROLOGY]\n"
        "optional_capabilities: []\n"
        "golden:\n"
        "  min_cases: 1\n"
        "  min_high_confidence_cases: 1\n"
        "  require_internal_history: true\n"
        "  required_case_types: [HEALTHY]\n",
        encoding="utf-8",
    )
    release = tmp_path / "release.json"
    release.write_text(ReleaseManifest(
        release_id="ephi-0.13.0-test-cfg", package_version="0.13.0", created_at=now.isoformat(),
        code_tree_sha256="a" * 64, config_sha256="b" * 64, benchmark_sha256={},
    ).model_dump_json(), encoding="utf-8")
    plan = tmp_path / "plan.json"
    assert main([
        "onboarding", "plan", "--data-reality", str(data_reality), "--policy", str(policy),
        "--release-manifest", str(release), "--output", str(plan),
    ]) == 0

    corpus = BenchmarkCorpus(
        corpus_id="internal", version="1", created_at=now, description="internal",
        cases=(BenchmarkCase(
            case_id="CASE-1", family=BenchmarkFamily.METROLOGY, case_type=BenchmarkCaseType.HEALTHY,
            source_kind=BenchmarkSourceKind.INTERNAL_HISTORY, source_locator="internal://case/1",
            label_confidence=BenchmarkLabelConfidence.HIGH_CONFIDENCE,
        ),),
    )
    corpus_path = tmp_path / "corpus.json"
    corpus_path.write_text(corpus.model_dump_json(), encoding="utf-8")
    gates = tmp_path / "gates.json"
    gates.write_text(json.dumps([
        {"plane": QualificationPlane.DATA_REALITY.value, "passed": True},
        {"plane": QualificationPlane.BEHAVIORAL_METROLOGY.value, "passed": True},
        {"plane": QualificationPlane.RUNTIME_SCALE.value, "passed": True},
    ]), encoding="utf-8")
    package = tmp_path / "package.json"
    assert main([
        "onboarding", "promotion-package", "--policy", str(policy), "--plan", str(plan),
        "--corpus", str(corpus_path), "--gates", str(gates), "--from-state", "RESEARCH",
        "--target-state", "OFFLINE_QUALIFIED", "--output", str(package),
    ]) == 0
    manifest = tmp_path / "manifest.json"
    assert main([
        "onboarding", "family-manifest", "--package", str(package), "--approved-by", "approver",
        "--output", str(manifest),
    ]) == 0
    payload = json.loads(manifest.read_text(encoding="utf-8"))
    assert payload["state"] == "OFFLINE_QUALIFIED"
    assert payload["capabilities"][0]["capability_id"] == "behavioral-health"
