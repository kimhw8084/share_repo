from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

pa = pytest.importorskip("pyarrow")
pytest.importorskip("duckdb")

from ephi.adapters.base.big_data import Predicate, PredicateOp, QuerySpec
from ephi.adapters.local.duckdb_big_data import DuckDBBigDataClient
from ephi.adapters.local.parquet_materialization_store import ParquetMaterializationStore
from ephi.synthetic.factory import SyntheticConfig, generate_dataset


def test_synthetic_duckdb_and_materialization(tmp_path: Path) -> None:
    output = tmp_path / "synthetic"
    paths = generate_dataset(
        output,
        SyntheticConfig(n_assets=2, executions_per_asset=20, scenario="local-drift"),
    )
    client = DuckDBBigDataClient({"executions": paths["executions"]})
    cutoff = datetime(2026, 1, 2, tzinfo=timezone.utc)
    table = client.query_arrow(
        QuerySpec(
            dataset="executions",
            columns=("execution_id", "available_at"),
            predicates=(Predicate("available_at", PredicateOp.LTE, cutoff),),
        )
    )
    assert table.num_rows > 0

    store = ParquetMaterializationStore(tmp_path / "mats")
    a = pa.table({"id": [1, 2], "value": [10, 20]})
    store.overwrite("x", a)
    b = pa.table({"id": [2, 3], "value": [200, 30]})
    store.upsert("x", b, key_columns=("id",))
    result = store.read("x")
    assert sorted(zip(result["id"].to_pylist(), result["value"].to_pylist())) == [
        (1, 10),
        (2, 200),
        (3, 30),
    ]


def test_semantic_data_reality_audit_on_synthetic_parquet(tmp_path: Path) -> None:
    from ephi.adapters.local.duckdb_audit import DuckDBParquetAuditBackend
    from ephi.audit import DataRealityAuditor
    from ephi.audit_contracts import DEFAULT_DATASET_CONTRACTS, DEFAULT_JOIN_CONTRACTS
    from ephi.domain.capabilities import Capability
    from ephi.domain.data_reality import QualificationState

    paths = generate_dataset(
        tmp_path / "audit-source",
        SyntheticConfig(n_assets=3, executions_per_asset=30, scenario="healthy"),
    )
    report = DataRealityAuditor(DuckDBParquetAuditBackend(paths)).run(
        DEFAULT_DATASET_CONTRACTS,
        DEFAULT_JOIN_CONTRACTS,
    )
    process = report.capability(Capability.PROCESS_HISTORY)
    fdc = report.capability(Capability.FDC_SCALAR)
    assert process is not None and process.state in {
        QualificationState.QUALIFIED,
        QualificationState.PARTIAL,
        QualificationState.PROVISIONAL,
    }
    assert fdc is not None and fdc.state in {
        QualificationState.QUALIFIED,
        QualificationState.PARTIAL,
        QualificationState.PROVISIONAL,
    }
    execution = next(item for item in report.datasets if item.contract.logical_name == "executions")
    assert execution.profile is not None
    assert execution.profile.availability_delay_p95_seconds is not None
