from datetime import timedelta
from fastapi.testclient import TestClient
from ephi.advisory.demo import build_demo_advisory_service
from ephi.api.app import create_app
from ephi.domain.exposure import AlternativeAssetCandidate,AssetAvailability,EpisodeOnsetWindow,FutureRouteStep,WIPMaterialState
from ephi.domain.health import HealthSeverity
from ephi.exposure.engine import ExposurePriorityEngine
def op(service,with_wip):
    eid=service.list_attention()[0].episode_id; src=service.sources.get(eid); assert src; now=src.assessment.event_time; w=(); al=()
    if with_wip:
        w=tuple(WIPMaterialState(f"F{i}",1,(FutureRouteStep(f"F{i}",2,src.episode.context.operation,(src.episode.asset_id,"ALT"),eta=now+timedelta(minutes=20),likely_asset_id=src.episode.asset_id),)) for i in range(30)); al=(AlternativeAssetCandidate("ALT",True,AssetAvailability.AVAILABLE,HealthSeverity.NORMAL,.95,.95),)
    r=ExposurePriorityEngine().assess(episode_id=eid,asset_id=src.episode.asset_id,operation=src.episode.context.operation,technical_severity=src.assessment.severity,technical_confidence=src.assessment.confidence,as_of=now,onset=EpisodeOnsetWindow(src.episode.opened_at,src.episode.opened_at,src.episode.opened_at),wip=w,alternatives=al,quality_associations=src.quality_associations,trend=src.advisory_context.trend); return eid,r
def test_refresh_changes_priority_without_analytical_revision():
    s=build_demo_advisory_service(); eid,r=op(s,True); v1=s.update_operational_state(eid,exposure_snapshot=r.exposure,priority_assessment=r.priority); rev=v1.analytical_revisions; assert v1.exposure.future_preventable==30
    _,r2=op(s,False); v2=s.update_operational_state(eid,exposure_snapshot=r2.exposure,priority_assessment=r2.priority); assert v2.header.technical_severity==v1.header.technical_severity and v2.analytical_revisions==rev and v2.exposure.future_preventable==0
def test_typed_api():
    s=build_demo_advisory_service(); eid,r=op(s,True); s.update_operational_state(eid,exposure_snapshot=r.exposure,priority_assessment=r.priority); c=TestClient(create_app(advisory_service=s)); assert c.get(f"/v1/episodes/{eid}/exposure").json()["future_preventable"]==30; assert c.get(f"/v1/episodes/{eid}/priority").status_code==200; assert c.get(f"/v1/episodes/{eid}").json()["priority"] is not None
