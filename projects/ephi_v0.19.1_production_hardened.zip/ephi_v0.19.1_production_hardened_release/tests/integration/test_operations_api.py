from datetime import datetime, timezone

from fastapi.testclient import TestClient

from ephi.api.app import create_app
from ephi.domain.operations import (
    CapabilityCertification,
    CertificationState,
    ControlKind,
    ControlScope,
    FamilyQualificationManifest,
)
from ephi.operations.controls import OperationalControlService
from ephi.operations.status import OperationsStatusService
from ephi.operations.telemetry import evaluate_freshness


def test_operations_api_is_read_only_and_typed() -> None:
    now = datetime.now(timezone.utc)
    controls = OperationalControlService()
    controls.activate(kind=ControlKind.NOTIFICATIONS, scope=ControlScope.FAMILY, target="METROLOGY", reason="test", actor="ops", activated_at=now)
    manifest = FamilyQualificationManifest(
        family_id="METROLOGY",
        release_id="R1",
        state=CertificationState.SHADOW,
        capabilities=(CapabilityCertification(capability_id="behavioral-health", state=CertificationState.SHADOW),),
        created_at=now,
    )
    slo = evaluate_freshness(as_of=now, observations={"source": 10.0}, targets={"source": (60.0, 120.0)})
    service = OperationsStatusService(family_manifest=manifest, controls=controls, slo_report=slo)
    client = TestClient(create_app(operations_status_service=service))
    assert client.get("/v1/operations/status").status_code == 200
    assert client.get("/v1/operations/controls").json()[0]["kind"] == "NOTIFICATIONS"
    assert client.get("/v1/operations/certification").json()["state"] == "SHADOW"
    assert client.get("/v1/operations/slo").json()["overall_state"] == "CURRENT"
    assert client.post("/v1/operations/controls", json={}).status_code == 405


def test_operations_api_returns_503_if_not_configured() -> None:
    client = TestClient(create_app())
    assert client.get("/v1/operations/status").status_code == 503
