import json

from ephi.cli.main import main


def test_synthetic_replay_cli_local_drift(capsys) -> None:
    code = main(
        [
            "replay",
            "synthetic",
            "--scenario",
            "local-drift",
            "--executions-per-asset",
            "700",
            "--seed",
            "11",
        ]
    )
    assert code == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["scenario"] == "local-drift"
    assert payload["actionable_assessments"] > 0
    assert set(payload["actionable_by_asset"]) == {"A000"}


def test_metrology_replay_cli_process_shift(capsys) -> None:
    code = main(
        [
            "replay",
            "metrology",
            "--scenario",
            "process-shift",
            "--measurements-per-head",
            "700",
            "--seed",
            "23",
        ]
    )
    assert code == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["scenario"] == "process-shift"
    assert payload["actionable_assessments"] == 0
    assert payload["active_fleet_episodes"] >= 1


def test_data_contracts_cli(capsys) -> None:
    code = main(["data", "contracts"])
    assert code == 0
    payload = json.loads(capsys.readouterr().out)
    names = {item["logical_name"] for item in payload["datasets"]}
    assert {"executions", "signals", "metrology", "quality", "maintenance"} <= names
