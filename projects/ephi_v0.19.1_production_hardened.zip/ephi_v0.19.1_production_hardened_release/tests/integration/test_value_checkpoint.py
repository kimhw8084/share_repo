from datetime import datetime, timezone

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.value import (
    BenefitAttribution,
    BenefitAttributionRole,
    BenefitClaimGroup,
    ValidatedBenefitEvidence,
)
from ephi.value.checkpoint import restore_value_ledger_state, save_value_ledger_state
from ephi.value.service import ValueLedgerService


def test_value_ledger_checkpoint_preserves_revision_and_attribution(tmp_path) -> None:
    now = datetime.now(timezone.utc)
    service = ValueLedgerService()
    service.register_claim_group(BenefitClaimGroup(
        claim_group_id="G", economic_event_key="EV", episode_ids=("E",), description="event", created_at=now
    ))
    service.record_attribution(BenefitAttribution(
        claim_group_id="G", episode_id="E", role=BenefitAttributionRole.PRIMARY,
        attribution_confidence=0.9, supporting_evidence=("s",), review_status="REVIEWED"
    ))
    first = service.validate_realized_benefit(ValidatedBenefitEvidence(
        claim_group_id="G", amount=100.0, currency="USD", method="review",
        validated_at=now, validated_by="r1", source_references=("f1",)
    ))
    service.validate_realized_benefit(ValidatedBenefitEvidence(
        claim_group_id="G", amount=120.0, currency="USD", method="revision",
        validated_at=now, validated_by="r2", source_references=("f2",)
    ), supersedes_entry_id=first.ledger_entry_id)

    store = SqliteStateStore(tmp_path / "state.sqlite3")
    version = save_value_ledger_state(service, store)
    restored = ValueLedgerService()
    assert restore_value_ledger_state(restored, store) == version
    assert len(restored.repository.entries()) == 2
    assert len(restored.repository.active_entries()) == 1
    assert restored.program_summary(as_of=now).validated_realized_benefit == 120.0
    assert restored.repository.attributions("G")[0].role is BenefitAttributionRole.PRIMARY
