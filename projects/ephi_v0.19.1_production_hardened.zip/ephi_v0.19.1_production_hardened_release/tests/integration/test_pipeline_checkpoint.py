from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.health.checkpoint import restore_pipeline_state, save_pipeline_state
from ephi.health.engine import BehavioralHealthPipeline
from ephi.synthetic.scalar import ScalarScenarioConfig, generate_scalar_observations


def _signature(assessment):
    return (
        assessment.execution_id,
        assessment.severity,
        assessment.leading_hypothesis,
        round(assessment.behavioral_novelty, 12),
        round(assessment.confidence, 12),
    )


def test_checkpoint_restore_matches_uninterrupted_pipeline(tmp_path) -> None:
    observations = generate_scalar_observations(
        ScalarScenarioConfig(scenario="local-drift", executions_per_asset=800, seed=19)
    )
    split_time = observations[len(observations) // 2].event_time
    first = [o for o in observations if o.event_time < split_time]
    second = [o for o in observations if o.event_time >= split_time]

    uninterrupted = BehavioralHealthPipeline()
    uninterrupted.process(first)
    expected_second = uninterrupted.process(second)

    store = SqliteStateStore(tmp_path / "state.sqlite3")
    before_restart = BehavioralHealthPipeline()
    before_restart.process(first)
    version = save_pipeline_state(before_restart, store)
    assert version == 1

    after_restart = BehavioralHealthPipeline()
    restored_version = restore_pipeline_state(after_restart, store)
    assert restored_version == 1
    actual_second = after_restart.process(second)

    assert [_signature(a) for a in actual_second.assessments] == [
        _signature(a) for a in expected_second.assessments
    ]
    assert after_restart.episodes.active() == uninterrupted.episodes.active()
    assert after_restart.episodes.history() == uninterrupted.episodes.history()
    assert after_restart.fleet_episodes.active() == uninterrupted.fleet_episodes.active()
    assert after_restart.fleet_episodes.history() == uninterrupted.fleet_episodes.history()
