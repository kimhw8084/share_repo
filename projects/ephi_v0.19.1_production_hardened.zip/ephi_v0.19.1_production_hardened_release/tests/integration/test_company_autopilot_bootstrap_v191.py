from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

from ephi.adapters.company.sql_bound_client import SqlBindingRegistry, SqlTemplateBigDataClient
from ephi.autopilot.inference import infer_dataset_mapping, proposal_to_sql_binding
from ephi.autopilot.inspect import SqliteTableInspector
from ephi.autopilot.qualification import _build_hostile_db
from ephi.autopilot.sqlite_runtime import SqliteSqlExecutor
from ephi.config import EphiConfig
from ephi.registry.releases import ReleaseManifest

import ephi_company.big_data as company_big_data
import ephi_company.bootstrap as company_bootstrap
from ephi_company.errors import CompanyPortNotConfiguredError


def _setup(root: Path):
    db = root / "hostile.db"; _build_hostile_db(db)
    inspector = SqliteTableInspector(db)
    binding_dir = root / "bindings"; binding_dir.mkdir()
    for dataset, table, partition in (("executions","FAB_FLOW_ARCHIVE_X7","PROC_DATE"),("metrology","MEASUREMENT_VAULT_Q","MEAS_DATE")):
        prop = infer_dataset_mapping(dataset, inspector.profile(table))
        binding = proposal_to_sql_binding(prop, partition_column=partition, partition_source_field="event_time", partition_granularity="date", watermark_column="LOAD_DTTM")
        binding.save(binding_dir / f"{dataset}.yaml")
    config = EphiConfig.model_validate({
        "autopilot":{"accepted_datasets":["executions","metrology"],"binding_dir":str(binding_dir)},
        "port":{"required_capabilities":["PROCESS_HISTORY","METROLOGY"]},
    })
    manifest = ReleaseManifest.model_validate_json(Path("RELEASE_MANIFEST.json").read_text())
    client = SqlTemplateBigDataClient(SqliteSqlExecutor(db), SqlBindingRegistry.from_directory(binding_dir))
    return db, inspector, binding_dir, config, manifest, client


def test_company_bootstrap_accepts_valid_autopilot_bindings(monkeypatch):
    with TemporaryDirectory() as td:
        _, inspector, _, config, manifest, client = _setup(Path(td))
        monkeypatch.setattr(company_bootstrap, "build_schema_inspector", lambda config: inspector)
        monkeypatch.setattr(company_bootstrap, "build_big_data_client", lambda config: client)
        evidence = company_bootstrap.CompanyBootstrapRuntime(config, manifest).validate_mapping()
        assert evidence.passed, evidence
        assert "runtime SQL preflight passed" in evidence.summary


def test_company_bootstrap_runtime_preflight_catches_schema_drift(monkeypatch):
    with TemporaryDirectory() as td:
        _, inspector, _, config, manifest, client = _setup(Path(td))
        class DriftInspector:
            def profile_table(self, name, *, sample_rows=0):
                p = inspector.profile(name, sample_rows=sample_rows)
                from ephi.autopilot.models import PhysicalColumnProfile, PhysicalTableProfile
                cols = list(p.columns)
                cols[0] = PhysicalColumnProfile(cols[0].name, "CHANGED_TYPE")
                return PhysicalTableProfile(name, tuple(cols))
        monkeypatch.setattr(company_bootstrap, "build_schema_inspector", lambda config: DriftInspector())
        monkeypatch.setattr(company_bootstrap, "build_big_data_client", lambda config: client)
        evidence = company_bootstrap.CompanyBootstrapRuntime(config, manifest).validate_mapping()
        assert not evidence.passed
        assert any("schema drift" in x for x in evidence.blockers)


def test_autopilot_active_missing_binding_mount_fails_explicitly(tmp_path):
    config = EphiConfig.model_validate({
        "autopilot":{"accepted_datasets":["executions"],"binding_dir":str(tmp_path / "missing")},
        "port":{"required_capabilities":["PROCESS_HISTORY"]},
    })
    with pytest.raises(CompanyPortNotConfiguredError, match="no validated binding manifests"):
        company_big_data.build_big_data_client(config)
