from datetime import datetime, timezone, timedelta
from fastapi.testclient import TestClient
from ephi.api.app import create_app
from ephi.advisory.service import AdvisoryService,AdvisoryEpisodeSource
from ephi.domain.context import ContextKey
from ephi.domain.episode import HealthEpisode,EpisodeState
from ephi.domain.evidence import Hypothesis
from ephi.domain.health import HealthAssessment,HealthSeverity,HypothesisSupport
from ephi.domain.exposure import ExposureSnapshot,MaterialExposureAssessment,MaterialExposureClass
from ephi.domain.history import HistoricalCase,HistoricalCaseCuration
from ephi.domain.rca import RouteToken,ControlPopulation
from ephi.history.application import HistoryRCAApplicationService
from ephi.history.service import HistoricalIntelligenceService
from ephi.rca.source import InMemoryRCASourceRepository
from ephi.rca.orchestrator import RCAOrchestrator
T=datetime(2026,1,2,tzinfo=timezone.utc); C=ContextKey("O","R","P","T")
def _setup():
    adv=AdvisoryService(); ep=HealthEpisode("E","A",C,T,T,EpisodeState.INVESTIGATE,HealthSeverity.INVESTIGATE,Hypothesis.LOCAL_ASSET_DEGRADATION,3)
    ha=HealthAssessment("H","X","A",C,T,HealthSeverity.INVESTIGATE,.9,3,Hypothesis.LOCAL_ASSET_DEGRADATION,(HypothesisSupport(Hypothesis.LOCAL_ASSET_DEGRADATION,1,.1),),())
    items=tuple(MaterialExposureAssessment(material_id=f"W{i}",exposure_class=MaterialExposureClass.DEFINITE_PAST_EXPOSURE,exposure_confidence=1) for i in range(4))
    ex=ExposureSnapshot(snapshot_id="EX",episode_id="E",asset_id="A",operation="O",as_of=T,onset_low=T,onset_best=T,onset_high=T,onset_confidence=1,items=items,definitely_exposed=4)
    adv.upsert_source(AdvisoryEpisodeSource(ep,ha,exposure_snapshot=ex))
    hist=HistoricalIntelligenceService(); fp=hist.fingerprint(ep,ha,equipment_family="METRO"); appsvc=HistoryRCAApplicationService(adv,hist,RCAOrchestrator(InMemoryRCASourceRepository()))
    appsvc.register_fingerprint(fp)
    oldfp=fp.model_copy(update={"fingerprint_id":"OLD", "episode_id":"OLD-E", "asset_id":"B", "created_at":T-timedelta(days=2)})
    hist.add_case(HistoricalCase(case_id="CASE1",asset_id="B",equipment_family="METRO",opened_at=T-timedelta(days=2),available_at=T-timedelta(days=1),fingerprint=oldfp,curation=HistoricalCaseCuration.ENGINEER_REVIEWED,root_cause_category="CAL",root_cause_confidence=.8))
    routes=[]
    for i in range(4): routes.append(RouteToken(material_id=f"W{i}",sequence=1,operation="U",asset_id="SUSPECT",event_time=T-timedelta(hours=1),health_strength=1))
    for i in range(4): routes.append(RouteToken(material_id=f"C{i}",sequence=1,operation="U",asset_id="OTHER",event_time=T-timedelta(hours=1)))
    appsvc.rca.source.routes["E"]=tuple(routes); appsvc.rca.source.control_sets["E"]=(ControlPopulation(control_set_id="C",material_ids=tuple(f"C{i}" for i in range(4)),policy="matched"),)
    return create_app(advisory_service=adv,history_rca_service=appsvc)

def test_history_rca_typed_endpoints():
    c=TestClient(_setup())
    analogue=c.get('/v1/episodes/E/historical-analogues').json()[0]
    assert analogue['case_id']=='CASE1' and analogue['root_cause_category']=='CAL'
    recurrence=c.get('/v1/episodes/E/historical-recurrence').json()
    assert recurrence['matched_case_count'] >= 1
    assert c.get('/v1/episodes/E/investigation-seed').json()['affected_material_ids']==['W0','W1','W2','W3']
    r=c.get('/v1/episodes/E/rca-candidates').json()
    assert r and r[0]['factor']=='ASSET:SUSPECT'

def test_absent_substrate_is_503():
    assert TestClient(create_app()).get('/v1/episodes/X/historical-analogues').status_code==503
