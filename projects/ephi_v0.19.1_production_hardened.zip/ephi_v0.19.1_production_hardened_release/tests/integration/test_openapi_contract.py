from ephi.api.app import create_app


def test_v0110_openapi_contains_science_value_and_shadow_operations_contract_paths_and_semantic_enums() -> None:
    schema = create_app().openapi()
    paths = set(schema["paths"])
    expected = {
        "/healthz",
        "/version",
        "/v1/attention",
        "/v1/episodes",
        "/v1/episodes/{episode_id}",
        "/v1/episodes/{episode_id}/evidence",
        "/v1/episodes/{episode_id}/exposure",
        "/v1/episodes/{episode_id}/priority",
        "/v1/episodes/{episode_id}/material-exposure",
        "/v1/episodes/{episode_id}/notification",
        "/v1/episodes/{episode_id}/workflow",
        "/v1/episodes/{episode_id}/close",
        "/v1/episodes/{episode_id}/closure-feedback",
        "/v1/episodes/{episode_id}/audit",
        "/v1/episodes/{episode_id}/historical-analogues",
        "/v1/episodes/{episode_id}/historical-recurrence",
        "/v1/episodes/{episode_id}/investigation-seed",
        "/v1/episodes/{episode_id}/rca-candidates",
        "/v1/episodes/{episode_id}/value-ledger",
        "/v1/episodes/{episode_id}/value-summary",
        "/v1/value/program-summary",
        "/v1/operations/status",
        "/v1/operations/controls",
        "/v1/operations/certification",
        "/v1/operations/slo",
        "/v1/qualification/families/{family_id}",
        "/v1/qualification/families/{family_id}/plan",
        "/v1/qualification/families/{family_id}/golden",
        "/v1/qualification/families/{family_id}/golden/{intake_id}/history",
        "/v1/qualification/families/{family_id}/golden/{intake_id}/review",
        "/v1/qualification/families/{family_id}/shadow/queue",
        "/v1/qualification/families/{family_id}/shadow/claim",
        "/v1/qualification/families/{family_id}/shadow/{episode_id}/complete",
        "/v1/qualification/families/{family_id}/shadow/metrics",
        "/v1/qualification/families/{family_id}/gates",
        "/v1/qualification/families/{family_id}/promotion",
        "/v1/qualification/families/{family_id}/promotion/generate",
        "/v1/qualification/families/{family_id}/promotion/approve",
        "/v1/qualification/families/{family_id}/manifests",
        "/v1/qualification/families/{family_id}/manifests/current",
        "/v1/qualification/families/{family_id}/export",
        "/v1/qualification/families/{family_id}/audit",
        "/v1/launch/families/{family_id}/campaigns/{campaign_id}",
        "/v1/launch/families/{family_id}/campaigns/{campaign_id}/events",
        "/v1/launch/families/{family_id}/campaigns/{campaign_id}/reconciliation",
        "/v1/launch/families/{family_id}/campaigns/{campaign_id}/slo",
        "/v1/launch/families/{family_id}/campaigns/{campaign_id}/retention",
        "/v1/launch/families/{family_id}/campaigns/{campaign_id}/export",
        "/v1/launch/families/{family_id}/campaigns/{baseline_campaign_id}/compare/{candidate_campaign_id}",
        "/v1/missed-events",
    }
    assert paths == expected
    components = schema["components"]["schemas"]
    assert components["TechnicalSeverity"]["enum"] == [
        "UNKNOWN", "NORMAL", "OBSERVE", "MONITOR", "INVESTIGATE", "URGENT"
    ]
    assert components["OperationalPriority"]["enum"] == ["P1", "P2", "P3", "P4"]
    assert "EpisodeView" in components
    assert "NotificationPayload" in components
    assert "EpisodeValueLedgerView" in components
    assert "ProgramValueSummary" in components
    assert "OperationalStatus" in components
    assert "OperationalControl" in components
    assert "FamilyQualificationManifest" in components
    assert "OperationalSLOReport" in components
    assert "QualificationWorkspaceSummary" in components
    assert "QualificationWorkspaceExport" in components
    assert "PromotionEvidenceRecord" in components
    assert "QualificationAuditEvent" in components
    assert "CampaignReadinessView" in components
    assert "CrossStageReconciliation" in components
    assert "CampaignQualificationExport" in components
