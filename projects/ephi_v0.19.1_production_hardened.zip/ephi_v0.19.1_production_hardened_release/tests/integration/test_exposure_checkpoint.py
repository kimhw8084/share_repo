from datetime import datetime,timezone
from ephi.domain.exposure import EpisodeOnsetWindow
from ephi.domain.health import HealthSeverity
from ephi.exposure.engine import ExposurePriorityEngine
from ephi.exposure.service import ExposurePriorityService
def test_round_trip():
    n=datetime(2026,8,19,12,0,tzinfo=timezone.utc); r=ExposurePriorityEngine().assess(episode_id="E",asset_id="A",operation="OP",technical_severity=HealthSeverity.INVESTIGATE,technical_confidence=.9,as_of=n,onset=EpisodeOnsetWindow(n,n,n)); a=ExposurePriorityService(); a.upsert(r.exposure,r.priority); b=ExposurePriorityService(); b.restore_state(a.export_state()); assert b.get_exposure("E")==r.exposure and b.get_priority("E")==r.priority
