from fastapi.testclient import TestClient

from ephi.advisory.demo import build_demo_advisory_service
from ephi.api.app import create_app


def test_advisory_episode_api_workflow_notification_and_missed_event() -> None:
    service = build_demo_advisory_service()
    episode_id = service.list_attention()[0].episode_id
    client = TestClient(create_app(advisory_service=service))

    attention = client.get("/v1/attention")
    assert attention.status_code == 200
    assert attention.json()[0]["episode_id"] == episode_id

    detail = client.get(f"/v1/episodes/{episode_id}")
    assert detail.status_code == 200
    payload = detail.json()
    assert payload["top_support"]
    assert payload["top_contradictions"]
    assert payload["measurement_system"]["interpretation"] == "Measurement-system shift supported"

    contradiction = client.get(f"/v1/episodes/{episode_id}/evidence", params={"polarity": "CONTRADICTS"})
    assert contradiction.status_code == 200
    assert contradiction.json()

    material = client.get(f"/v1/episodes/{episode_id}/material-exposure")
    assert material.status_code == 200
    assert {item["exposure_class"] for item in material.json()} == {"DEFINITE_PAST_EXPOSURE", "FUTURE_PREVENTABLE_EXPOSURE"}

    note = client.get(f"/v1/episodes/{episode_id}/notification")
    assert note.status_code == 200
    assert note.json()["future_preventable_exposure"] == 168
    assert note.json()["top_contradiction"]

    ack = client.post(
        f"/v1/episodes/{episode_id}/workflow",
        json={"actor": "eng1", "state": "ACKNOWLEDGED", "owner": "eng1"},
    )
    assert ack.status_code == 200
    assert ack.json()["workflow"]["state"] == "ACKNOWLEDGED"

    investigate = client.post(
        f"/v1/episodes/{episode_id}/workflow",
        json={"actor": "eng1", "state": "INVESTIGATING"},
    )
    assert investigate.status_code == 200

    close = client.post(
        f"/v1/episodes/{episode_id}/close",
        json={
            "actor": "eng1",
            "behavior_confirmed": "YES",
            "quality_affected": "UNKNOWN",
            "likely_category": "Measurement system",
            "action_taken": "reference wafer check",
            "action_resolved_state": "YES",
            "confidence": "HIGH"
        },
    )
    assert close.status_code == 200
    assert close.json()["workflow"]["state"] == "RESOLVED"
    assert client.get(f"/v1/episodes/{episode_id}/closure-feedback").json()["feedback"]["action_taken"] == "reference wafer check"
    assert len(client.get(f"/v1/episodes/{episode_id}/audit").json()) >= 3
    assert client.get("/v1/attention").json() == []

    missed = client.post(
        "/v1/missed-events",
        json={
            "asset_id": "TOOL-404",
            "start_time": "2026-08-19T12:00:00Z",
            "reporter": "eng2",
            "description": "known excursion was not surfaced"
        },
    )
    assert missed.status_code == 201
    assert missed.json()["report_id"] == "MISS-000001"
    assert len(client.get("/v1/missed-events").json()) == 1


def test_advisory_api_uses_404_for_unknown_episode() -> None:
    client = TestClient(create_app(advisory_service=build_demo_advisory_service()))
    assert client.get("/v1/episodes/NOPE").status_code == 404
