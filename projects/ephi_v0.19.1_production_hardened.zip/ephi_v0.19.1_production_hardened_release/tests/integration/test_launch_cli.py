import json
from datetime import datetime, timezone
from pathlib import Path
from ephi.cli.main import main
from ephi.registry.releases import ReleaseManifest


def test_launch_receipt_and_qualification_cli(tmp_path: Path) -> None:
    artifact = tmp_path / "audit.json"
    artifact.write_text('{"passed":true}', encoding="utf-8")
    manifest = ReleaseManifest(
        release_id="ephi-0.16.0-test", package_version="0.16.0", created_at=datetime.now(timezone.utc).isoformat(),
        code_tree_sha256="a"*64, config_sha256="b"*64, benchmark_sha256={},
    )
    manifest_path = tmp_path / "release.json"
    manifest_path.write_text(manifest.model_dump_json(), encoding="utf-8")
    receipt = tmp_path / "receipt.json"
    assert main([
        "launch", "receipt", "--release-manifest", str(manifest_path), "--family-id", "METROLOGY_REFERENCE",
        "--evidence-id", "E1", "--kind", "DATA_REALITY", "--provenance", "INTERNAL_MEASURED",
        "--decision", "PASS", "--artifact", str(artifact), "--output", str(receipt),
    ]) == 0
    payload = json.loads(receipt.read_text())
    assert payload["artifact_sha256"]
    assert main(["launch", "qualification"]) == 0


def test_launch_plan_consumes_data_reality_and_blocks_without_evidence(tmp_path: Path) -> None:
    from ephi.registry.releases import ReleaseManifest
    manifest = ReleaseManifest(
        release_id="ephi-0.16.0-plan", package_version="0.16.0", created_at=datetime.now(timezone.utc).isoformat(),
        code_tree_sha256="a"*64, config_sha256="b"*64, benchmark_sha256={},
    )
    mp = tmp_path / "release.json"; mp.write_text(manifest.model_dump_json())
    dr = tmp_path / "dr.json"
    dr.write_text(json.dumps({"generated_at":"x","config_hash":"b"*64,"capabilities":[
        {"capability":"PROCESS_HISTORY","state":"QUALIFIED","supporting_datasets":[],"supporting_joins":[],"reasons":[]},
        {"capability":"METROLOGY","state":"QUALIFIED","supporting_datasets":[],"supporting_joins":[],"reasons":[]},
        {"capability":"REFERENCE_WAFER","state":"QUALIFIED","supporting_datasets":[],"supporting_joins":[],"reasons":[]},
    ]}))
    plan = tmp_path / "plan.json"
    assert main(["launch","plan","--release-manifest",str(mp),"--current-state","RESEARCH","--target-state","OFFLINE_QUALIFIED","--data-reality",str(dr),"--output",str(plan)]) == 2
    payload=json.loads(plan.read_text())
    assert all(x["state"]=="QUALIFIED" for x in payload["capability_assessments"] if x["required"])
    assert any("missing evidence" in b for b in payload["blockers"])
