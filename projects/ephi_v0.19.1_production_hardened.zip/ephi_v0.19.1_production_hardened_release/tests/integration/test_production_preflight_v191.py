from __future__ import annotations

import json
from pathlib import Path

from ephi.cli.main import main
from ephi.port.production_qualification import run_production_smoke_qualification


def test_reference_production_preflight_passes(capsys):
    rc = main([
        "port", "production-preflight",
        "--preflight-module", "ephi.port.reference_preflight",
        "--deployment-plan", "configs/deployment/shadow-reference.yaml",
        "--release-manifest", "RELEASE_MANIFEST.json",
    ])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["passed"]
    assert payload["check_count"] >= 20


def test_company_scaffold_reports_all_gaps_without_throwing(capsys):
    rc = main([
        "port", "production-preflight",
        "--preflight-module", "ephi_company.production_preflight",
        "--deployment-plan", "configs/deployment/shadow-reference.yaml",
        "--release-manifest", "RELEASE_MANIFEST.json",
    ])
    assert rc == 2
    captured = capsys.readouterr()
    payload = json.loads(captured.out)
    assert not payload["passed"]
    assert payload["failed_count"] >= 10
    assert "Traceback" not in captured.err


def test_production_smoke_qualification_plane_passes():
    report = run_production_smoke_qualification(".")
    assert report.passed, report.details
    assert report.reference_preflight_checks >= 20
    assert report.scaffold_failure_count >= 10
    assert report.http_process_smoke


def test_database_capability_cli_passes_against_reference_executor(capsys):
    rc = main(["autopilot", "db-qualify", "--executor-module", "ephi.port.reference_sql_executor"])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["passed"]
    assert all(check["passed"] for check in payload["checks"])
