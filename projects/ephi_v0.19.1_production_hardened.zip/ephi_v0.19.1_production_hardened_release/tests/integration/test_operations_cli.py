from pathlib import Path

from ephi.cli.main import main


def test_operations_benchmark_and_deployment_render_cli(tmp_path) -> None:
    root = Path(__file__).parents[2]
    output = tmp_path / "ops.json"
    assert main([
        "operations", "benchmark",
        "--deployment", str(root / "configs/deployment/shadow-reference.yaml"),
        "--output", str(output),
    ]) == 0
    assert '"passed": true' in output.read_text(encoding="utf-8")
    rendered = tmp_path / "k8s.yaml"
    assert main([
        "operations", "deployment-render",
        "--plan", str(root / "configs/deployment/shadow-reference.yaml"),
        "--output", str(rendered),
    ]) == 0
    text = rendered.read_text(encoding="utf-8")
    assert "kind: Deployment" in text
    assert "kind: Service" in text
