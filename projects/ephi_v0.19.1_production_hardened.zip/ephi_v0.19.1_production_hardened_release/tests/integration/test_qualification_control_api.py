from datetime import datetime, timedelta, timezone

from fastapi.testclient import TestClient

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.api.app import create_app
from ephi.domain.benchmark import BenchmarkCaseType, BenchmarkFamily, BenchmarkLabelConfidence
from ephi.domain.capabilities import Capability
from ephi.domain.data_reality import CapabilityAssessment, DataRealityReport, QualificationState
from ephi.domain.evidence import Hypothesis
from ephi.domain.onboarding import GoldenCaseIntake, GoldenCurationState
from ephi.domain.operations import CertificationState
from ephi.onboarding.control_plane import QualificationControlPlaneService
from ephi.onboarding.control_repository import QualificationWorkspaceRepository
from ephi.onboarding.planner import build_family_onboarding_plan
from ephi.onboarding.policy import FamilyOnboardingPolicy, GoldenCoveragePolicy

NOW = datetime(2026, 8, 19, 18, 0, tzinfo=timezone.utc)


def _policy(_: str):
    return FamilyOnboardingPolicy(
        family_id="MET", required_capabilities=(Capability.METROLOGY,),
        golden=GoldenCoveragePolicy(
            min_cases=1, min_high_confidence_cases=1,
            required_case_types=(BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT,),
        ),
    )


def _client(tmp_path):
    service = QualificationControlPlaneService(
        QualificationWorkspaceRepository(SqliteStateStore(tmp_path / "q.sqlite3")),
        policy_resolver=_policy,
    )
    app = create_app(
        qualification_service=service,
        actor_resolver=lambda request: request.headers.get("x-test-user", "authenticated-user"),
    )
    return TestClient(app), service


def _intake():
    return GoldenCaseIntake(
        intake_id="CASE-API", family=BenchmarkFamily.METROLOGY,
        case_type=BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT,
        source_locator="materialization://golden/api", submitted_by="spoofed", submitted_at=NOW,
        scope_start=NOW - timedelta(days=2), scope_end=NOW - timedelta(days=1),
        label_confidence=BenchmarkLabelConfidence.HIGH_CONFIDENCE,
        expected_hypothesis=Hypothesis.METROLOGY_SYSTEM_SHIFT,
        expected_local_actionable=True, expected_asset_ids=("HEAD-A",),
        evidence_refs=("review://api",), state=GoldenCurationState.DRAFT,
    )


def test_qualification_api_overrides_submitter_reviewer_and_surfaces_audit(tmp_path) -> None:
    client, _ = _client(tmp_path)
    submit = client.post(
        "/v1/qualification/families/MET/golden",
        headers={"x-test-user": "alice"},
        json={"command_id": "S1", "intake": _intake().model_dump(mode="json")},
    )
    assert submit.status_code == 201
    assert submit.json()["submitted_by"] == "alice"
    review = client.post(
        "/v1/qualification/families/MET/golden/CASE-API/review",
        headers={"x-test-user": "bob"},
        json={"command_id": "R1", "state": "ACCEPTED", "note": "confirmed"},
    )
    assert review.status_code == 200
    assert review.json()["reviewed_by"] == "bob"
    audit = client.get("/v1/qualification/families/MET/audit").json()
    assert [item["actor"] for item in audit] == ["alice", "bob"]
    assert client.get("/v1/qualification/families/MET").json()["accepted_golden_cases"] == 1


def test_qualification_mutation_fails_without_actor_resolver(tmp_path) -> None:
    service = QualificationControlPlaneService(
        QualificationWorkspaceRepository(SqliteStateStore(tmp_path / "q.sqlite3")),
        policy_resolver=_policy,
    )
    client = TestClient(create_app(qualification_service=service))
    response = client.post(
        "/v1/qualification/families/MET/golden",
        json={"command_id": "S1", "intake": _intake().model_dump(mode="json")},
    )
    assert response.status_code == 503


def test_plan_registration_api_is_typed(tmp_path) -> None:
    client, _ = _client(tmp_path)
    report = DataRealityReport(
        datasets=(), joins=(), generated_at=NOW.isoformat(),
        capabilities=(CapabilityAssessment(capability=Capability.METROLOGY, state=QualificationState.QUALIFIED),),
    )
    plan = build_family_onboarding_plan(
        family_id="MET", release_id="R14", report=report,
        required_capabilities=(Capability.METROLOGY,), target_state=CertificationState.OFFLINE_QUALIFIED,
        generated_at=NOW,
    )
    response = client.post(
        "/v1/qualification/families/MET/plan",
        headers={"x-test-user": "admin"},
        json={"command_id": "P1", "plan": plan.model_dump(mode="json")},
    )
    assert response.status_code == 200
    assert response.json()["release_id"] == "R14"
