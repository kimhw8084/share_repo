from ephi.cli.main import main


def test_campaign_observability_qualification_cli() -> None:
    assert main(["launch", "observability-qualification"]) == 0
