from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from ephi.adapters.local.filesystem_artifact_store import FileSystemArtifactStore
from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.api.app import create_app
from ephi.domain.launch import EvidenceProvenance
from ephi.domain.operations import CertificationState
from ephi.launch.execution import CampaignExecutionController
from ephi.launch.observability import CampaignObservabilityService
from ephi.launch.reference_executor import ReferenceLaunchEvidenceExecutor
from ephi.launch.registry import ShadowLaunchWorkspaceRepository


def _service(tmp_path: Path) -> CampaignObservabilityService:
    family = "METROLOGY_REFERENCE"
    release = "ephi-0.18.0-api-test"
    config_hash = "c" * 64
    repo = ShadowLaunchWorkspaceRepository(SqliteStateStore(tmp_path / "state.sqlite3"))
    artifacts = FileSystemArtifactStore(tmp_path / "artifacts")
    executor = ReferenceLaunchEvidenceExecutor(
        tmp_path / "collected",
        family_id=family,
        release_id=release,
        config_hash=config_hash,
        provenance=EvidenceProvenance.INTERNAL_MEASURED,
    )
    controller = CampaignExecutionController(
        family_id=family,
        release_id=release,
        config_hash=config_hash,
        executor=executor,
        repository=repo,
        artifact_store=artifacts,
        required_provenance=EvidenceProvenance.INTERNAL_MEASURED,
    )
    controller.run(campaign_id="C1", target_state=CertificationState.OFFLINE_QUALIFIED, actor="eng")
    return CampaignObservabilityService(repo, artifact_store=artifacts)


def test_campaign_observability_api_is_typed_and_read_only(tmp_path: Path) -> None:
    client = TestClient(create_app(campaign_observability_service=_service(tmp_path)))
    base = "/v1/launch/families/METROLOGY_REFERENCE/campaigns/C1"
    readiness = client.get(base)
    assert readiness.status_code == 200
    assert readiness.json()["state"] == "READY_FOR_HANDOFF"
    assert client.get(base + "/events").status_code == 200
    assert client.get(base + "/reconciliation").json()["status"] == "CONSISTENT"
    assert client.get(base + "/slo").json()["passed"] is True
    assert client.get(base + "/retention").status_code == 200
    exported = client.get(base + "/export")
    assert exported.status_code == 200
    assert len(exported.json()["export_sha256"]) == 64
    assert client.post(base).status_code == 405
    assert client.get("/v1/launch/families/METROLOGY_REFERENCE/campaigns/UNKNOWN").status_code == 404


def test_campaign_observability_api_fails_closed_when_unconfigured() -> None:
    client = TestClient(create_app())
    response = client.get("/v1/launch/families/METROLOGY_REFERENCE/campaigns/C1")
    assert response.status_code == 503
