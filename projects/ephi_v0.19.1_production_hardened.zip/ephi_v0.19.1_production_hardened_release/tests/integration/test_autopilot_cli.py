from pathlib import Path
from tempfile import TemporaryDirectory

from ephi.autopilot.qualification import _build_hostile_db
from ephi.cli.main import main


def test_autopilot_candidate_cli_generates_binding(capsys):
    with TemporaryDirectory() as td:
        root = Path(td)
        db = root / "hostile.sqlite3"
        binding = root / "metrology.yaml"
        _build_hostile_db(db)
        rc = main([
            "autopilot", "candidate", "--dataset", "metrology", "--table", "MEASUREMENT_VAULT_Q",
            "--sqlite-db", str(db), "--partition-column", "MEAS_DATE",
            "--partition-source-field", "event_time", "--partition-granularity", "date",
            "--watermark-column", "LOAD_DTTM",
            "--output-binding", str(binding),
        ])
        assert rc == 0
        assert binding.exists()
        assert "SELECT *" not in binding.read_text(encoding="utf-8")


def test_autopilot_wrong_candidate_cli_fails(capsys):
    with TemporaryDirectory() as td:
        root = Path(td)
        db = root / "hostile.sqlite3"
        _build_hostile_db(db)
        rc = main([
            "autopilot", "candidate", "--dataset", "metrology", "--table", "EQP_DAILY_SUMMARY_WRONG",
            "--sqlite-db", str(db),
        ])
        assert rc == 2

def test_autopilot_discover_ranks_metrology(capsys):
    with TemporaryDirectory() as td:
        root = Path(td)
        db = root / "hostile.sqlite3"
        _build_hostile_db(db)
        rc = main(["autopilot", "discover", "--dataset", "metrology", "--hint", "measurement", "--sqlite-db", str(db)])
        assert rc == 0
        out = capsys.readouterr().out
        assert "MEASUREMENT_VAULT_Q" in out

def test_autopilot_bootstrap_synthesizes_strict_config(capsys):
    from ephi.autopilot.inference import infer_dataset_mapping, proposal_to_sql_binding
    from ephi.autopilot.inspect import SqliteTableInspector
    with TemporaryDirectory() as td:
        root = Path(td)
        db = root / "hostile.sqlite3"
        _build_hostile_db(db)
        inspector = SqliteTableInspector(db)
        paths = []
        for dataset, table, partition in (("executions","FAB_FLOW_ARCHIVE_X7","PROC_DATE"),("metrology","MEASUREMENT_VAULT_Q","MEAS_DATE")):
            proposal = infer_dataset_mapping(dataset, inspector.profile(table))
            binding = proposal_to_sql_binding(
                proposal, partition_column=partition, partition_source_field="event_time",
                partition_granularity="date", watermark_column="LOAD_DTTM"
            )
            path = root / f"{dataset}.yaml"
            binding.save(path)
            paths.append(path)
        generated = root / "generated.yaml"
        args = ["autopilot","bootstrap","--binding",str(paths[0]),"--binding",str(paths[1]),"--output-config",str(generated)]
        assert main(args) == 0
        assert generated.exists()
        out = capsys.readouterr().out
        assert "READY_FOR_PORT_BOOTSTRAP" in out

def test_intentional_edit_can_be_validated_and_resealed(capsys):
    from ephi.autopilot.inference import infer_dataset_mapping, proposal_to_sql_binding
    from ephi.autopilot.inspect import SqliteTableInspector
    from ephi.autopilot.models import load_sql_binding
    with TemporaryDirectory() as td:
        root = Path(td)
        db = root / "hostile.sqlite3"; _build_hostile_db(db)
        proposal = infer_dataset_mapping("executions", SqliteTableInspector(db).profile("FAB_FLOW_ARCHIVE_X7"))
        binding = proposal_to_sql_binding(proposal, partition_column="PROC_DATE", partition_source_field="event_time", partition_granularity="date", watermark_column="LOAD_DTTM")
        path = root / "executions.yaml"; binding.save(path)
        path.write_text(path.read_text().replace("RUN_KEY AS execution_id", "TRIM(RUN_KEY) AS execution_id", 1))
        assert main(["autopilot","validate-binding","--binding",str(path)]) == 2
        err = capsys.readouterr().err
        assert "binding_hash mismatch" in err and "Traceback" not in err
        assert main(["autopilot","seal-binding","--binding",str(path)]) == 0
        capsys.readouterr()
        sealed = load_sql_binding(path)
        assert "TRIM(RUN_KEY)" in sealed.sql
