from datetime import datetime, timezone

from fastapi.testclient import TestClient

from ephi.api.app import create_app
from ephi.domain.value import BenefitAttribution, BenefitAttributionRole, BenefitClaimGroup, ValidatedBenefitEvidence
from ephi.value.service import ValueLedgerService


def test_value_api_is_read_only_and_returns_typed_summary() -> None:
    now = datetime.now(timezone.utc)
    service = ValueLedgerService()
    service.register_claim_group(BenefitClaimGroup(
        claim_group_id="G", economic_event_key="EV", episode_ids=("E",), description="event", created_at=now
    ))
    service.record_attribution(BenefitAttribution(
        claim_group_id="G", episode_id="E", role=BenefitAttributionRole.PRIMARY,
        attribution_confidence=0.9, review_status="REVIEWED"
    ))
    service.validate_realized_benefit(ValidatedBenefitEvidence(
        claim_group_id="G", amount=100.0, currency="USD", method="review",
        validated_at=now, validated_by="reviewer", source_references=("finance",)
    ))
    client = TestClient(create_app(value_service=service))
    summary = client.get("/v1/episodes/E/value-summary")
    assert summary.status_code == 200
    assert summary.json()["validated_realized_benefit"] == 100.0
    program = client.get("/v1/value/program-summary")
    assert program.status_code == 200
    assert program.json()["validated_claim_groups"] == 1
    # There is intentionally no HTTP endpoint that validates/mutates monetary claims.
    assert client.post("/v1/value/program-summary", json={}).status_code == 405


def test_value_api_returns_503_when_value_subsystem_not_configured() -> None:
    client = TestClient(create_app())
    assert client.get("/v1/value/program-summary").status_code == 503


def test_value_api_unknown_episode_is_404_when_subsystem_is_configured() -> None:
    client = TestClient(create_app(value_service=ValueLedgerService()))
    assert client.get("/v1/episodes/UNKNOWN/value-summary").status_code == 404
