from datetime import timedelta

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.metrology.checkpoint import restore_metrology_pipeline_state, save_metrology_pipeline_state
from ephi.metrology.engine import MetrologyHealthPipeline
from ephi.synthetic.metrology import MetrologyScenarioConfig, generate_metrology_observations


def _signature(assessment):
    return (
        assessment.execution_id,
        assessment.asset_id,
        assessment.severity,
        assessment.leading_hypothesis,
        round(assessment.behavioral_novelty, 12),
        round(assessment.confidence, 12),
    )


def test_metrology_checkpoint_restore_matches_uninterrupted_pipeline(tmp_path) -> None:
    config = MetrologyScenarioConfig(
        scenario="measurement-head-drift",
        measurements_per_head=700,
        seed=29,
    )
    observations = generate_metrology_observations(config)
    cutoff = config.start_time + timedelta(minutes=config.interval_minutes * 350)
    first = [row for row in observations if row.event_time < cutoff]
    second = [row for row in observations if row.event_time >= cutoff]

    uninterrupted = MetrologyHealthPipeline()
    uninterrupted.process(first)
    expected = uninterrupted.process(second)

    store = SqliteStateStore(tmp_path / "metrology.sqlite3")
    before_restart = MetrologyHealthPipeline()
    before_restart.process(first)
    assert save_metrology_pipeline_state(before_restart, store) == 1

    after_restart = MetrologyHealthPipeline()
    assert restore_metrology_pipeline_state(after_restart, store) == 1
    actual = after_restart.process(second)

    assert [_signature(item) for item in actual.assessments] == [
        _signature(item) for item in expected.assessments
    ]
    assert after_restart.episodes.active() == uninterrupted.episodes.active()
    assert after_restart.episodes.history() == uninterrupted.episodes.history()
    assert after_restart.fleet_episodes.active() == uninterrupted.fleet_episodes.active()
    assert after_restart.fleet_episodes.history() == uninterrupted.fleet_episodes.history()
