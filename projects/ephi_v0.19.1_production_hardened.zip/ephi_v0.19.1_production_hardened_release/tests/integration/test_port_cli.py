import json
import sys
from pathlib import Path

from ephi.cli.main import main


def release(path: Path):
    payload = {
        "release_id": "ephi-0.12.0-test-test",
        "package_version": "0.12.0",
        "created_at": "2026-08-19T12:00:00+00:00",
        "code_tree_sha256": "x",
        "config_sha256": "y",
        "benchmark_sha256": {},
        "qualification_sha256": {},
        "deployment_sha256": {},
        "state_schema_version": "1",
        "schema_version": "2",
    }
    path.write_text(json.dumps(payload), encoding="utf-8")


def test_port_bootstrap_cli_reference_completes(tmp_path, capsys):
    manifest = tmp_path / "release.json"; release(manifest)
    cfg = tmp_path / "local.yaml"; cfg.write_text("app:\n  environment: reference\noperations:\n  family_id: TEST\n", encoding="utf-8")
    code = main([
        "port", "bootstrap",
        "--runtime-module", "ephi.port.reference_runtime",
        "--config", str(cfg),
        "--release-manifest", str(manifest),
        "--local-state-db", str(tmp_path / "port.sqlite3"),
    ])
    payload = json.loads(capsys.readouterr().out)
    assert code == 0
    assert payload["shadow_ready"] is True
    assert all(item["state"] == "PASSED" for item in payload["stages"])


def test_company_scaffold_bootstrap_fails_closed_on_placeholders(tmp_path, capsys, monkeypatch):
    manifest = tmp_path / "release.json"; release(manifest)
    monkeypatch.syspath_prepend(str(Path("company_port/src").resolve()))
    # ensure a prior import from another test process cannot hide path behavior
    for name in tuple(sys.modules):
        if name == "ephi_company" or name.startswith("ephi_company."):
            sys.modules.pop(name, None)
    code = main([
        "port", "bootstrap",
        "--runtime-module", "ephi_company.bootstrap",
        "--config", "company_port/configs/company.yaml.example",
        "--release-manifest", str(manifest),
        "--local-state-db", str(tmp_path / "port.sqlite3"),
    ])
    payload = json.loads(capsys.readouterr().out)
    assert code == 2
    assert payload["shadow_ready"] is False
    assert payload["stages"][0]["state"] == "FAILED"
    assert payload["stages"][1]["state"] == "BLOCKED"
