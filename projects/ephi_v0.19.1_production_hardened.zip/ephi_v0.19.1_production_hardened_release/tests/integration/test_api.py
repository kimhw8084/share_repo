from fastapi.testclient import TestClient

from ephi.api.app import create_app


def test_health_and_version() -> None:
    client = TestClient(create_app())
    assert client.get("/healthz").json()["status"] == "ok"
    payload = client.get("/version").json()
    assert payload["version"]
    assert len(payload["config_hash"]) == 64
