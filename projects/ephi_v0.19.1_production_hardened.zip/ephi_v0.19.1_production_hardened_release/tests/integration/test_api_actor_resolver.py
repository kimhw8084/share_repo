from fastapi.testclient import TestClient

from ephi.advisory.demo import build_demo_advisory_service
from ephi.api.app import create_app


def test_authenticated_actor_resolver_overrides_body_identity():
    service = build_demo_advisory_service()
    episode_id = service.list_attention()[0].episode_id
    client = TestClient(create_app(advisory_service=service, actor_resolver=lambda request: "authenticated-user"))

    response = client.post(
        f"/v1/episodes/{episode_id}/workflow",
        json={"actor": "spoofed-user", "state": "ACKNOWLEDGED"},
    )
    assert response.status_code == 200
    audit = client.get(f"/v1/episodes/{episode_id}/audit").json()
    assert audit[-1]["actor"] == "authenticated-user"

    missed = client.post(
        "/v1/missed-events",
        json={
            "asset_id": "TOOL-X",
            "start_time": "2026-08-19T12:00:00Z",
            "reporter": "spoofed-reporter",
            "description": "missed event",
        },
    )
    assert missed.status_code == 201
    assert missed.json()["reporter"] == "authenticated-user"
