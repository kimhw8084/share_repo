from datetime import timedelta
from ephi.advisory.demo import build_demo_advisory_service
from ephi.domain.exposure import AlternativeAssetCandidate,AssetAvailability,EpisodeOnsetWindow,FutureRouteStep,WIPMaterialState
from ephi.domain.health import HealthSeverity
from ephi.exposure.coordinator import ExposureRefreshCoordinator
from ephi.repositories.exposure import InMemoryExposureSourceRepository

def test_coordinator_uses_semantic_repository_without_table_names():
    service=build_demo_advisory_service(); eid=service.list_attention()[0].episode_id; src=service.sources.get(eid); assert src
    now=src.assessment.event_time
    repo=InMemoryExposureSourceRepository(
        wip=(WIPMaterialState("W",1,(FutureRouteStep("W",2,src.episode.context.operation,(src.episode.asset_id,"ALT"),eta=now+timedelta(minutes=10),likely_asset_id=src.episode.asset_id),)),),
        alternatives=(AlternativeAssetCandidate("ALT",True,AssetAvailability.AVAILABLE,HealthSeverity.NORMAL,.95,.95),),
    )
    result=ExposureRefreshCoordinator(repo).refresh(episode=src.episode,assessment=src.assessment,onset=EpisodeOnsetWindow(src.episode.opened_at,src.episode.opened_at,src.episode.opened_at),as_of=now,quality_associations=src.quality_associations,trend="WORSENING")
    assert result.exposure.future_preventable==1
