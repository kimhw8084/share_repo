from pathlib import Path

from ephi.qualification.corpus import build_synthetic_golden_corpus, load_corpus, save_corpus


def test_golden_corpus_roundtrip_has_stable_hash(tmp_path: Path) -> None:
    corpus = build_synthetic_golden_corpus()
    path = save_corpus(corpus, tmp_path / "corpus.json")
    restored = load_corpus(path)
    assert restored == corpus
    assert restored.stable_hash() == corpus.stable_hash()
    assert len(restored.cases) == 9
