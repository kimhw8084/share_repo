from ephi.exposure.qualification import run_exposure_priority_qualification


def test_exposure_priority_reference_qualification_passes() -> None:
    report = run_exposure_priority_qualification(performance_materials=1000)
    assert report.passed
    assert all(report.checks.values())
    assert report.time_critical_priority == "P1"
    assert report.rerouted_containment_priority == "P4"
