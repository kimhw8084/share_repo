from dataclasses import replace
from datetime import timedelta

from ephi.health.engine import BehavioralHealthPipeline
from ephi.qualification.replay import strict_knowledge_replay
from ephi.synthetic.scalar import ScalarScenarioConfig, generate_scalar_observations


def test_late_fact_forces_knowledge_time_rebuild_and_never_appears_early() -> None:
    observations = generate_scalar_observations(
        ScalarScenarioConfig(n_assets=3, executions_per_asset=140, seed=5, scenario="healthy")
    )
    target = next(obs for obs in observations if obs.execution_id == "E-A000-0000040")
    delayed = replace(target, available_at=target.available_at + timedelta(hours=9))
    observations = [delayed if obs.execution_id == target.execution_id else obs for obs in observations]

    result = strict_knowledge_replay(observations, pipeline_factory=BehavioralHealthPipeline)
    assert result.rebuild_count >= 1
    available = {obs.execution_id: obs.available_at for obs in observations}
    for point in result.assessment_points:
        assert point.known_at >= available[point.execution_id]
