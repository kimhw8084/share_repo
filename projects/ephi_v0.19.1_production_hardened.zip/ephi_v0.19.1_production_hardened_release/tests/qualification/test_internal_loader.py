from datetime import datetime, timezone

from ephi.domain.benchmark import (
    BenchmarkCase,
    BenchmarkCaseType,
    BenchmarkFamily,
    BenchmarkLabelConfidence,
    BenchmarkSourceKind,
)
from ephi.qualification.evaluate import evaluate_case
from ephi.qualification.methods import baseline_method
from ephi.synthetic.scalar import ScalarScenarioConfig, generate_scalar_observations


class _Loader:
    def load(self, case: BenchmarkCase):
        assert case.source_locator == "internal://case/1"
        return generate_scalar_observations(
            ScalarScenarioConfig(n_assets=3, executions_per_asset=220, seed=3, scenario="healthy")
        )


def test_internal_history_uses_company_loader_contract_without_core_schema_knowledge() -> None:
    case = BenchmarkCase(
        case_id="INTERNAL-1",
        family=BenchmarkFamily.BEHAVIORAL,
        case_type=BenchmarkCaseType.HEALTHY,
        source_kind=BenchmarkSourceKind.INTERNAL_HISTORY,
        source_locator="internal://case/1",
        label_confidence=BenchmarkLabelConfidence.HIGH_CONFIDENCE,
        scope_start=datetime(2026, 1, 1, tzinfo=timezone.utc),
        scope_end=datetime(2026, 1, 2, tzinfo=timezone.utc),
        asset_count=3,
    )
    result = evaluate_case(case, baseline_method(), internal_loader=_Loader())
    assert result.passed
    assert result.false_actionable_episode_count == 0
