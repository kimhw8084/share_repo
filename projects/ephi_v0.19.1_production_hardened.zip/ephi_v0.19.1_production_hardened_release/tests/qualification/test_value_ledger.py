from pathlib import Path

from ephi.value.qualification import run_value_qualification


def test_value_ledger_reference_qualification_passes() -> None:
    root = Path(__file__).parents[2]
    report = run_value_qualification(str(root / "configs/value/synthetic_reference.yaml"))
    assert report.passed
    assert all(report.checks.values())
    assert report.estimated_avoidable_loss == 12500.0
    assert report.revised_validated_benefit == 8500.0
    assert report.wafers_protected == 20
