from ephi.qualification.evaluate import QualificationReport, QualificationSummary
from ephi.qualification.gates import QualificationGatePolicy, apply_gate_policy, load_gate_policy


def _report(*, pass_rate: float, recall: float, false_rate: float) -> QualificationReport:
    return QualificationReport(
        corpus_id="test",
        corpus_version="1",
        corpus_hash="abc",
        method_id="baseline",
        method_description="test",
        generated_at="2026-01-01T00:00:00+00:00",
        summary=QualificationSummary(
            cases=2,
            passed_cases=2 if pass_rate == 1.0 else 1,
            pass_rate=pass_rate,
            expected_actionable_cases=1,
            detected_actionable_cases=1 if recall == 1.0 else 0,
            episode_recall=recall,
            false_actionable_episodes=0 if false_rate == 0.0 else 1,
            false_actionable_episodes_per_1000_asset_hours=false_rate,
            mean_detection_delay_minutes=10.0,
            mean_labeled_lead_time_minutes=None,
            total_runtime_seconds=1.0,
        ),
        cases=(),
        strata={},
    )


def test_synthetic_gate_is_hard_not_aggregate_score() -> None:
    policy = QualificationGatePolicy.synthetic_regression()
    assert apply_gate_policy(_report(pass_rate=1.0, recall=1.0, false_rate=0.0), policy).passed
    failed = apply_gate_policy(_report(pass_rate=1.0, recall=1.0, false_rate=0.1), policy)
    assert not failed.passed
    assert any(gate.gate == "false_actionable_episode_burden" and not gate.passed for gate in failed.gates)


def test_gate_policy_loads_from_yaml(tmp_path):
    path = tmp_path / "policy.yaml"
    path.write_text(
        "policy_id: test\n"
        "min_case_pass_rate: 0.9\n"
        "min_episode_recall: 0.8\n"
        "max_false_actionable_episodes_per_1000_asset_hours: 1.0\n"
        "require_zero_case_failures: false\n"
    )
    policy = load_gate_policy(path)
    assert policy.policy_id == "test"
    assert policy.min_episode_recall == 0.8
