from ephi.qualification.stress import (
    run_peer_poisoning_stress,
    run_reference_contamination_stress,
)


def test_reference_contamination_remains_bounded_at_ten_percent() -> None:
    report = run_reference_contamination_stress()
    worst = report.contamination[-1]
    assert worst.contamination_fraction == 0.10
    assert abs(worst.median_shift) < 0.20
    assert worst.mad_ratio < 1.30


def test_peer_poisoning_and_common_mode_decomposition_are_robust() -> None:
    report = run_peer_poisoning_stress()
    assert abs(report.target_peer_center_one_poisoned) < 0.20
    assert abs(report.target_peer_center_three_member_poisoned) < 0.20
    assert report.common_mode_local_residual_max < 0.50
    assert report.common_mode_fleet_shift_min > 4.0
