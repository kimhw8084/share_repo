from ephi.domain.health import HealthSeverity
from ephi.metrology.engine import MetrologyHealthPipeline
from ephi.qualification.replay import strict_knowledge_replay
from ephi.synthetic.metrology import MetrologyScenarioConfig, generate_metrology_observations


def test_remeasure_fault_survives_incremental_attempt_arrival() -> None:
    observations = generate_metrology_observations(
        MetrologyScenarioConfig(
            measurements_per_head=800,
            seed=17,
            scenario="remeasure-instability",
        )
    )
    result = strict_knowledge_replay(observations, pipeline_factory=MetrologyHealthPipeline)
    actionable = [
        point for point in result.assessment_points if point.severity >= HealthSeverity.INVESTIGATE
    ]
    assert actionable
    assert {point.asset_id for point in actionable} == {"METRO001/HEAD_A"}
    assert len(result.local_episode_points) == 1


def test_healthy_metrology_has_no_transient_fleet_episode() -> None:
    pipeline = MetrologyHealthPipeline()
    pipeline.process(
        generate_metrology_observations(
            MetrologyScenarioConfig(measurements_per_head=900, seed=17, scenario="healthy")
        )
    )
    assert pipeline.fleet_episodes.active() == ()
    assert pipeline.fleet_episodes.history() == ()
