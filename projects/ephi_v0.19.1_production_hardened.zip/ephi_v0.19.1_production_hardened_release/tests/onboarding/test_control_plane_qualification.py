from ephi.onboarding.control_qualification import run_qualification_control_plane_qualification


def test_qualification_control_plane_gate_passes() -> None:
    report = run_qualification_control_plane_qualification()
    assert report.passed
    assert report.concurrent_writes_preserved
    assert report.stale_promotion_blocked
