from ephi.onboarding.qualification import run_family_onboarding_qualification


def test_family_onboarding_reference_qualification_passes() -> None:
    report = run_family_onboarding_qualification()
    assert report.passed
