from datetime import datetime, timezone

from ephi.domain.capabilities import Capability
from ephi.domain.data_reality import CapabilityAssessment, DataRealityReport, QualificationState
from ephi.domain.operations import CertificationState
from ephi.onboarding.planner import build_family_onboarding_plan


def _report(**states: QualificationState) -> DataRealityReport:
    return DataRealityReport(
        datasets=(), joins=(), generated_at=datetime.now(timezone.utc).isoformat(),
        capabilities=tuple(
            CapabilityAssessment(capability=Capability[name], state=state)
            for name, state in states.items()
        ),
    )


def test_required_gap_blocks_but_optional_gap_only_limits() -> None:
    plan = build_family_onboarding_plan(
        family_id="MET", release_id="R1",
        report=_report(METROLOGY=QualificationState.QUALIFIED, REFERENCE_WAFER=QualificationState.PARTIAL, SPATIAL_METROLOGY=QualificationState.UNAVAILABLE),
        required_capabilities=(Capability.METROLOGY, Capability.REFERENCE_WAFER),
        optional_capabilities=(Capability.SPATIAL_METROLOGY,),
        target_state=CertificationState.OFFLINE_QUALIFIED,
    )
    assert not plan.ready_for_target
    assert any("REFERENCE_WAFER" in item for item in plan.blockers)
    assert any("SPATIAL_METROLOGY" in item for item in plan.limitations)
    assert any(item.kind.value == "CURATE_GOLDEN_CASES" for item in plan.actions)


def test_fully_qualified_required_capabilities_unblock_plan() -> None:
    plan = build_family_onboarding_plan(
        family_id="MET", release_id="R1",
        report=_report(METROLOGY=QualificationState.QUALIFIED, REFERENCE_WAFER=QualificationState.QUALIFIED),
        required_capabilities=(Capability.METROLOGY, Capability.REFERENCE_WAFER),
    )
    assert plan.ready_for_target
