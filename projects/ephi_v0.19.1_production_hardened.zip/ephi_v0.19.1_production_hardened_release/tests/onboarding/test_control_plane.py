from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import pytest

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.benchmark import BenchmarkCaseType, BenchmarkFamily, BenchmarkLabelConfidence
from ephi.domain.capabilities import Capability
from ephi.domain.data_reality import CapabilityAssessment, DataRealityReport, QualificationState
from ephi.domain.evidence import Hypothesis
from ephi.domain.onboarding import GoldenCaseIntake, GoldenCurationState, ShadowReviewCandidate
from ephi.domain.operations import (
    CertificationState,
    EngineerShadowReview,
    GateResult,
    QualificationPlane,
    ShadowReviewDisposition,
)
from ephi.onboarding.control_plane import QualificationControlPlaneService
from ephi.onboarding.control_repository import QualificationWorkspaceRepository
from ephi.onboarding.planner import build_family_onboarding_plan
from ephi.onboarding.policy import FamilyOnboardingPolicy, GoldenCoveragePolicy, ShadowSamplingPolicy

NOW = datetime(2026, 8, 19, 18, 0, tzinfo=timezone.utc)


def _policy(_: str) -> FamilyOnboardingPolicy:
    return FamilyOnboardingPolicy(
        family_id="MET",
        required_capabilities=(Capability.METROLOGY,),
        golden=GoldenCoveragePolicy(
            min_cases=1,
            min_high_confidence_cases=1,
            required_case_types=(BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT,),
            require_internal_history=True,
        ),
        shadow_sampling=ShadowSamplingPolicy(),
    )


def _service(path) -> QualificationControlPlaneService:
    return QualificationControlPlaneService(
        QualificationWorkspaceRepository(SqliteStateStore(path)), policy_resolver=_policy
    )


def _plan():
    report = DataRealityReport(
        datasets=(), joins=(), generated_at=NOW.isoformat(),
        capabilities=(CapabilityAssessment(capability=Capability.METROLOGY, state=QualificationState.QUALIFIED),),
    )
    return build_family_onboarding_plan(
        family_id="MET", release_id="R14", report=report,
        required_capabilities=(Capability.METROLOGY,), target_state=CertificationState.OFFLINE_QUALIFIED,
        generated_at=NOW,
    )


def _intake(case_id: str, submitter: str = "spoofed") -> GoldenCaseIntake:
    return GoldenCaseIntake(
        intake_id=case_id,
        family=BenchmarkFamily.METROLOGY,
        case_type=BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT,
        source_locator=f"materialization://golden/{case_id}",
        submitted_by=submitter,
        submitted_at=NOW - timedelta(hours=1),
        scope_start=NOW - timedelta(days=2),
        scope_end=NOW - timedelta(days=1),
        label_confidence=BenchmarkLabelConfidence.HIGH_CONFIDENCE,
        expected_hypothesis=Hypothesis.METROLOGY_SYSTEM_SHIFT,
        expected_local_actionable=True,
        expected_asset_ids=("HEAD-A",),
        evidence_refs=(f"review://{case_id}",),
        state=GoldenCurationState.DRAFT,
    )


def _candidate(episode_id: str) -> ShadowReviewCandidate:
    return ShadowReviewCandidate(
        episode_id=episode_id, family_id="MET", asset_id="HEAD-A",
        technical_severity="INVESTIGATE", operational_priority="P1",
        leading_hypothesis=Hypothesis.METROLOGY_SYSTEM_SHIFT,
        confidence=0.8, opened_at=NOW,
    )


def test_multi_instance_concurrent_submissions_do_not_lose_updates(tmp_path) -> None:
    db = tmp_path / "control.sqlite3"

    def submit(i: int) -> None:
        service = _service(db)
        service.submit_golden(
            "MET", _intake(f"CASE-{i:02d}"), actor=f"engineer-{i}",
            command_id=f"CMD-{i:02d}", at=NOW + timedelta(seconds=i),
        )

    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(submit, range(24)))

    restored = _service(db)
    assert len(restored.latest_golden_intakes("MET")) == 24
    assert len(restored.audit("MET")) == 24


def test_golden_review_is_authenticated_terminal_and_restartable(tmp_path) -> None:
    service = _service(tmp_path / "control.sqlite3")
    submitted = service.submit_golden("MET", _intake("CASE-1"), actor="alice", command_id="S1", at=NOW)
    assert submitted.submitted_by == "alice"
    with pytest.raises(ValueError, match="self-approve"):
        service.review_golden(
            "MET", "CASE-1", state=GoldenCurationState.ACCEPTED,
            actor="alice", command_id="R1", at=NOW + timedelta(minutes=1),
        )
    accepted = service.review_golden(
        "MET", "CASE-1", state=GoldenCurationState.ACCEPTED,
        actor="bob", command_id="R2", at=NOW + timedelta(minutes=2),
    )
    assert accepted.reviewed_by == "bob"
    restored = _service(tmp_path / "control.sqlite3")
    assert restored.latest_golden_intakes("MET")[0] == accepted
    assert restored.accepted_golden_cases("MET")[0].source_locator.endswith("CASE-1")
    with pytest.raises(ValueError, match="terminal"):
        restored.review_golden(
            "MET", "CASE-1", state=GoldenCurationState.REJECTED,
            actor="carol", command_id="R3", at=NOW + timedelta(minutes=3),
        )


def test_shadow_claim_and_completion_are_atomic_and_exclusive(tmp_path) -> None:
    service = _service(tmp_path / "control.sqlite3")
    service.enqueue_shadow_candidates(
        "MET", (_candidate("EP-1"),), max_items=1,
        actor="system", command_id="E1", at=NOW,
    )
    claim = service.claim_shadow_review("MET", actor="alice", command_id="C1", at=NOW)
    assert claim is not None and claim.claimed_by == "alice"
    assert service.claim_shadow_review("MET", actor="bob", command_id="C2", at=NOW + timedelta(minutes=1)) is None
    review = EngineerShadowReview(
        review_id="REV-1", episode_id="spoofed", reviewer="spoofed",
        disposition=ShadowReviewDisposition.WANT_EVENT,
        comparison_valid=True, hypothesis_reasonable=True, verification_useful=True,
        reviewed_at=NOW - timedelta(days=1),
    )
    completed = service.complete_shadow_review(
        "MET", "EP-1", review, actor="alice", command_id="D1", at=NOW + timedelta(minutes=2),
    )
    assert completed.reviewer == "alice" and completed.episode_id == "EP-1"
    assert service.summary("MET").completed_shadow_reviews == 1
    with pytest.raises(ValueError, match="already has"):
        # Re-claim cannot happen because completion is atomic; force direct second completion path.
        service.complete_shadow_review(
            "MET", "EP-1", review.model_copy(update={"review_id": "REV-2"}),
            actor="alice", command_id="D2", at=NOW + timedelta(minutes=3),
        )


def test_gate_to_ready_promotion_to_manifest_is_audited(tmp_path) -> None:
    service = _service(tmp_path / "control.sqlite3")
    service.register_plan(_plan(), actor="qual-admin", command_id="P1", at=NOW)
    service.submit_golden("MET", _intake("CASE-1"), actor="alice", command_id="S1", at=NOW)
    service.review_golden(
        "MET", "CASE-1", state=GoldenCurationState.ACCEPTED,
        actor="bob", command_id="R1", at=NOW + timedelta(minutes=1),
    )
    for idx, plane in enumerate((
        QualificationPlane.DATA_REALITY,
        QualificationPlane.BEHAVIORAL_METROLOGY,
        QualificationPlane.RUNTIME_SCALE,
    )):
        service.record_gate(
            "MET", release_id="R14", capability_id="behavioral-health",
            result=GateResult(plane=plane, passed=True, artifact=f"{plane.value}.json"),
            actor="qual-admin", command_id=f"G{idx}", at=NOW + timedelta(minutes=2 + idx),
        )
    package = service.generate_promotion(
        "MET", capability_id="behavioral-health", target_state=CertificationState.OFFLINE_QUALIFIED,
        actor="qual-admin", command_id="PG1", at=NOW + timedelta(minutes=10),
    )
    assert package.package.decision.value == "READY"
    manifest = service.approve_promotion(
        "MET", package_ids=(package.package_id,), actor="approver",
        command_id="PA1", at=NOW + timedelta(minutes=11),
    )
    assert manifest.state == CertificationState.OFFLINE_QUALIFIED
    assert service.current_manifest("MET") == manifest
    assert len(service.manifest_history("MET")) == 1
    assert [item.actor for item in service.audit("MET")][-2:] == ["qual-admin", "approver"]


def test_duplicate_command_is_rejected_without_duplicate_side_effect(tmp_path) -> None:
    service = _service(tmp_path / "control.sqlite3")
    service.submit_golden("MET", _intake("CASE-1"), actor="alice", command_id="DUP", at=NOW)
    with pytest.raises(ValueError, match="command already applied"):
        service.submit_golden("MET", _intake("CASE-2"), actor="alice", command_id="DUP", at=NOW)
    assert [item.intake_id for item in service.latest_golden_intakes("MET")] == ["CASE-1"]


def test_concurrent_shadow_claim_has_exactly_one_winner(tmp_path) -> None:
    db = tmp_path / "claim.sqlite3"
    service = _service(db)
    service.enqueue_shadow_candidates(
        "MET", (_candidate("EP-RACE"),), max_items=1,
        actor="system", command_id="ENQ-RACE", at=NOW,
    )

    def claim(actor: str):
        return _service(db).claim_shadow_review(
            "MET", actor=actor, command_id=f"CLAIM-{actor}", at=NOW + timedelta(seconds=1)
        )

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(claim, ("alice", "bob")))
    winners = [item for item in results if item is not None]
    assert len(winners) == 1
    persisted = _service(db).shadow_queue("MET")[0]
    assert persisted.claimed_by == winners[0].claimed_by


def test_concurrent_promotion_approval_has_exactly_one_winner(tmp_path) -> None:
    db = tmp_path / "promotion.sqlite3"
    service = _service(db)
    service.register_plan(_plan(), actor="admin", command_id="P", at=NOW)
    service.submit_golden("MET", _intake("CASE-P"), actor="alice", command_id="S", at=NOW)
    service.review_golden(
        "MET", "CASE-P", state=GoldenCurationState.ACCEPTED,
        actor="bob", command_id="R", at=NOW + timedelta(minutes=1),
    )
    for idx, plane in enumerate((QualificationPlane.DATA_REALITY, QualificationPlane.BEHAVIORAL_METROLOGY, QualificationPlane.RUNTIME_SCALE)):
        service.record_gate(
            "MET", release_id="R14", capability_id="behavioral-health",
            result=GateResult(plane=plane, passed=True), actor="admin",
            command_id=f"G-{idx}", at=NOW + timedelta(minutes=2 + idx),
        )
    package = service.generate_promotion(
        "MET", capability_id="behavioral-health", target_state=CertificationState.OFFLINE_QUALIFIED,
        actor="admin", command_id="PG", at=NOW + timedelta(minutes=8),
    )

    def approve(actor: str):
        try:
            return _service(db).approve_promotion(
                "MET", package_ids=(package.package_id,), actor=actor,
                command_id=f"APPROVE-{actor}", at=NOW + timedelta(minutes=9)
            )
        except ValueError:
            return None

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(approve, ("approver-a", "approver-b")))
    assert sum(item is not None for item in results) == 1
    assert len(_service(db).manifest_history("MET")) == 1
