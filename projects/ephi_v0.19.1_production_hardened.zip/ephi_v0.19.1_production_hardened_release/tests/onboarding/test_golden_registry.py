from datetime import datetime, timedelta, timezone

import pytest

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.benchmark import BenchmarkCaseType, BenchmarkFamily, BenchmarkLabelConfidence, BenchmarkSourceKind
from ephi.domain.evidence import Hypothesis
from ephi.domain.onboarding import GoldenCaseIntake, GoldenCurationState
from ephi.onboarding.golden import GoldenCaseRegistry


def _intake(now: datetime) -> GoldenCaseIntake:
    return GoldenCaseIntake(
        intake_id="CASE-1", family=BenchmarkFamily.METROLOGY,
        case_type=BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT,
        source_locator="materialization://case/1", submitted_by="alice", submitted_at=now,
        scope_start=now - timedelta(days=1), scope_end=now,
        label_confidence=BenchmarkLabelConfidence.HIGH_CONFIDENCE,
        expected_hypothesis=Hypothesis.METROLOGY_SYSTEM_SHIFT,
        expected_local_actionable=True, expected_asset_ids=("HEAD-A",),
        evidence_refs=("review://1",), state=GoldenCurationState.PENDING_REVIEW,
    )


def test_golden_case_requires_independent_reviewer_and_persists(tmp_path) -> None:
    now = datetime.now(timezone.utc)
    store = SqliteStateStore(tmp_path / "state.sqlite3")
    registry = GoldenCaseRegistry(store)
    registry.submit(_intake(now))
    with pytest.raises(ValueError, match="self-approve"):
        registry.revise("CASE-1", state=GoldenCurationState.ACCEPTED, reviewer="alice", reviewed_at=now)
    accepted = registry.revise("CASE-1", state=GoldenCurationState.ACCEPTED, reviewer="bob", reviewed_at=now)
    restored = GoldenCaseRegistry(store)
    assert restored.latest("CASE-1") == accepted
    case = restored.accepted_cases()[0]
    assert case.source_kind == BenchmarkSourceKind.INTERNAL_HISTORY
    assert case.source_locator == "materialization://case/1"


def test_accepted_golden_case_history_is_terminal(tmp_path) -> None:
    now = datetime.now(timezone.utc)
    registry = GoldenCaseRegistry(SqliteStateStore(tmp_path / "state.sqlite3"))
    registry.submit(_intake(now))
    registry.revise("CASE-1", state=GoldenCurationState.ACCEPTED, reviewer="bob", reviewed_at=now)
    with pytest.raises(ValueError, match="terminal"):
        registry.revise("CASE-1", state=GoldenCurationState.REJECTED, reviewer="carol", reviewed_at=now)
