from datetime import datetime, timezone

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.advisory.models import MissedEventReport
from ephi.domain.evidence import Hypothesis
from ephi.domain.onboarding import ShadowReviewCandidate
from ephi.domain.operations import EngineerShadowReview, ShadowReviewDisposition
from ephi.onboarding.shadow_sampling import ShadowReviewQueue, build_review_sample, build_shadow_metrics


def _candidates(now):
    hypotheses = (
        Hypothesis.METROLOGY_SYSTEM_SHIFT,
        Hypothesis.COMMON_MODE_PROCESS_CHANGE,
        Hypothesis.LOCAL_ASSET_DEGRADATION,
        Hypothesis.DATA_PIPELINE_OR_SCHEMA_CHANGE,
    )
    return tuple(
        ShadowReviewCandidate(
            episode_id=f"EP-{i}", family_id="MET", asset_id="A",
            technical_severity="INVESTIGATE" if i == 0 else "MONITOR",
            operational_priority="P1" if i == 0 else "P3",
            leading_hypothesis=hypothesis, confidence=0.5 if i == 3 else 0.9, opened_at=now,
        )
        for i, hypothesis in enumerate(hypotheses)
    )


def test_sampler_guarantees_hypothesis_coverage() -> None:
    now = datetime.now(timezone.utc)
    sample = build_review_sample(_candidates(now), max_items=4)
    assert {item.leading_hypothesis for item in sample} == {item.leading_hypothesis for item in _candidates(now)}


def test_review_queue_is_idempotent_and_restartable(tmp_path) -> None:
    now = datetime.now(timezone.utc)
    store = SqliteStateStore(tmp_path / "state.sqlite3")
    sample = build_review_sample(_candidates(now), max_items=4)
    queue = ShadowReviewQueue(store)
    assert len(queue.enqueue(sample, at=now)) == 4
    assert queue.enqueue(sample, at=now) == ()
    claimed = queue.claim("alice", at=now)
    assert claimed is not None
    queue.complete(claimed.candidate.episode_id, "REV-1", reviewer="alice")
    assert len(ShadowReviewQueue(store).items()) == 4


def test_metrics_keep_missed_events_separate_from_review_false_rate() -> None:
    now = datetime.now(timezone.utc)
    candidates = _candidates(now)
    reviews = tuple(
        EngineerShadowReview(
            review_id=f"R{i}", episode_id=candidate.episode_id, reviewer="alice",
            disposition=ShadowReviewDisposition.NOT_USEFUL if i == 0 else ShadowReviewDisposition.WANT_EVENT,
            comparison_valid=True, hypothesis_reasonable=True, verification_useful=True, reviewed_at=now,
        )
        for i, candidate in enumerate(candidates)
    )
    missed = (MissedEventReport(report_id="M1", asset_id="A", start_time=now, reporter="bob", description="miss", created_at=now),)
    metrics = build_shadow_metrics(candidates=candidates, reviews=reviews, missed_reports=missed, generated_at=now)
    assert metrics.false_or_low_value_rate == 0.25
    assert metrics.missed_event_reports == 1
    assert metrics.missed_reports_per_100_reviews == 25.0


def test_expired_review_claim_can_be_recovered(tmp_path) -> None:
    from datetime import timedelta
    now = datetime.now(timezone.utc)
    store = SqliteStateStore(tmp_path / "state.sqlite3")
    queue = ShadowReviewQueue(store)
    sample = build_review_sample(_candidates(now), max_items=1)
    queue.enqueue(sample, at=now)
    first = queue.claim("alice", at=now, lease_seconds=10)
    assert first is not None
    assert queue.claim("bob", at=now + timedelta(seconds=5), lease_seconds=10) is None
    recovered = ShadowReviewQueue(store).claim("bob", at=now + timedelta(seconds=11), lease_seconds=10)
    assert recovered is not None
    assert recovered.claimed_by == "bob"
