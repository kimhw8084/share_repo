from datetime import datetime, timezone

from ephi.domain.benchmark import BenchmarkCase, BenchmarkCaseType, BenchmarkFamily, BenchmarkLabelConfidence, BenchmarkSourceKind
from ephi.domain.capabilities import Capability
from ephi.domain.data_reality import CapabilityAssessment, DataRealityReport, QualificationState
from ephi.domain.operations import CertificationState, GateResult, QualificationPlane
from ephi.onboarding.planner import build_family_onboarding_plan
from ephi.onboarding.policy import GoldenCoveragePolicy
from ephi.onboarding.promotion import PromotionEvidenceBuilder


def _plan(now):
    report = DataRealityReport(datasets=(), joins=(), generated_at=now.isoformat(), capabilities=(
        CapabilityAssessment(capability=Capability.METROLOGY, state=QualificationState.QUALIFIED),
    ))
    return build_family_onboarding_plan(
        family_id="MET", release_id="R", report=report,
        required_capabilities=(Capability.METROLOGY,), target_state=CertificationState.OFFLINE_QUALIFIED,
    )


def _case(case_id, case_type):
    return BenchmarkCase(
        case_id=case_id, family=BenchmarkFamily.METROLOGY, case_type=case_type,
        source_kind=BenchmarkSourceKind.INTERNAL_HISTORY, source_locator=f"x://{case_id}",
        label_confidence=BenchmarkLabelConfidence.HIGH_CONFIDENCE,
    )


def test_promotion_package_blocks_missing_golden_strata() -> None:
    now = datetime.now(timezone.utc)
    builder = PromotionEvidenceBuilder(golden_policy=GoldenCoveragePolicy(
        min_cases=2, min_high_confidence_cases=2,
        required_case_types=(BenchmarkCaseType.HEALTHY, BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT),
    ))
    package = builder.build(
        family_id="MET", release_id="R", from_state=CertificationState.RESEARCH,
        target_state=CertificationState.OFFLINE_QUALIFIED,
        gate_results=(
            GateResult(plane=QualificationPlane.DATA_REALITY, passed=True),
            GateResult(plane=QualificationPlane.BEHAVIORAL_METROLOGY, passed=True),
            GateResult(plane=QualificationPlane.RUNTIME_SCALE, passed=True),
        ),
        onboarding_plan=_plan(now), golden_cases=(_case("1", BenchmarkCaseType.HEALTHY),), generated_at=now,
    )
    assert package.decision.value == "BLOCKED"
    assert any("METROLOGY_SYSTEM_SHIFT" in reason for reason in package.blockers)


def test_promotion_package_ready_when_required_evidence_exists() -> None:
    now = datetime.now(timezone.utc)
    builder = PromotionEvidenceBuilder(golden_policy=GoldenCoveragePolicy(
        min_cases=2, min_high_confidence_cases=2,
        required_case_types=(BenchmarkCaseType.HEALTHY, BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT),
    ))
    package = builder.build(
        family_id="MET", release_id="R", from_state=CertificationState.RESEARCH,
        target_state=CertificationState.OFFLINE_QUALIFIED,
        gate_results=(
            GateResult(plane=QualificationPlane.DATA_REALITY, passed=True),
            GateResult(plane=QualificationPlane.BEHAVIORAL_METROLOGY, passed=True),
            GateResult(plane=QualificationPlane.RUNTIME_SCALE, passed=True),
        ),
        onboarding_plan=_plan(now), golden_cases=(
            _case("1", BenchmarkCaseType.HEALTHY),
            _case("2", BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT),
        ), generated_at=now,
    )
    assert package.decision.value == "READY"


def test_ready_packages_generate_valid_family_manifest() -> None:
    from ephi.onboarding.promotion import family_manifest_from_packages
    now = datetime.now(timezone.utc)
    builder = PromotionEvidenceBuilder()
    gates = (
        GateResult(plane=QualificationPlane.DATA_REALITY, passed=True),
        GateResult(plane=QualificationPlane.BEHAVIORAL_METROLOGY, passed=True),
        GateResult(plane=QualificationPlane.RUNTIME_SCALE, passed=True),
    )
    package = builder.build(
        family_id="MET", release_id="R", from_state=CertificationState.RESEARCH,
        target_state=CertificationState.OFFLINE_QUALIFIED, gate_results=gates,
        onboarding_plan=_plan(now), golden_cases=(_case("1", BenchmarkCaseType.HEALTHY),),
        generated_at=now, capability_id="behavioral-health",
    )
    manifest = family_manifest_from_packages((package,), approved_by="staff-engineer")
    assert manifest.state == CertificationState.OFFLINE_QUALIFIED
    assert manifest.capabilities[0].capability_id == "behavioral-health"


def test_promotion_package_blocks_illegal_state_jump() -> None:
    now = datetime.now(timezone.utc)
    package = PromotionEvidenceBuilder().build(
        family_id="MET", release_id="R", from_state=CertificationState.RESEARCH,
        target_state=CertificationState.SHADOW,
        gate_results=(
            GateResult(plane=QualificationPlane.DATA_REALITY, passed=True),
            GateResult(plane=QualificationPlane.BEHAVIORAL_METROLOGY, passed=True),
            GateResult(plane=QualificationPlane.RUNTIME_SCALE, passed=True),
        ),
        onboarding_plan=_plan(now), golden_cases=(_case("1", BenchmarkCaseType.HEALTHY),), generated_at=now,
    )
    assert package.decision.value == "BLOCKED"
    assert any("Illegal certification transition" in reason for reason in package.blockers)


def test_internal_family_policy_does_not_count_synthetic_golden_cases() -> None:
    now = datetime.now(timezone.utc)
    synthetic = BenchmarkCase(
        case_id="SYN", family=BenchmarkFamily.METROLOGY,
        case_type=BenchmarkCaseType.HEALTHY,
        source_kind=BenchmarkSourceKind.SYNTHETIC_METROLOGY,
        scenario="healthy", label_confidence=BenchmarkLabelConfidence.CONFIRMED,
    )
    builder = PromotionEvidenceBuilder(golden_policy=GoldenCoveragePolicy(
        min_cases=1, min_high_confidence_cases=1,
        required_case_types=(BenchmarkCaseType.HEALTHY,),
        require_internal_history=True,
    ))
    package = builder.build(
        family_id="MET", release_id="R", from_state=CertificationState.RESEARCH,
        target_state=CertificationState.OFFLINE_QUALIFIED,
        gate_results=(
            GateResult(plane=QualificationPlane.DATA_REALITY, passed=True),
            GateResult(plane=QualificationPlane.BEHAVIORAL_METROLOGY, passed=True),
            GateResult(plane=QualificationPlane.RUNTIME_SCALE, passed=True),
        ),
        onboarding_plan=_plan(now), golden_cases=(synthetic,), generated_at=now,
    )
    assert package.decision.value == "BLOCKED"
    assert any("eligible Golden case count 0" in reason for reason in package.blockers)


def test_shadow_promotion_requires_reliability_dr_plane() -> None:
    now = datetime.now(timezone.utc)
    # The plan target is SHADOW so the promotion evidence is evaluated for live-shadow entry.
    report = DataRealityReport(datasets=(), joins=(), generated_at=now.isoformat(), capabilities=(
        CapabilityAssessment(capability=Capability.METROLOGY, state=QualificationState.QUALIFIED),
    ))
    plan = build_family_onboarding_plan(
        family_id="MET", release_id="R", report=report,
        required_capabilities=(Capability.METROLOGY,), target_state=CertificationState.SHADOW,
    )
    package = PromotionEvidenceBuilder().build(
        family_id="MET", release_id="R", from_state=CertificationState.OFFLINE_QUALIFIED,
        target_state=CertificationState.SHADOW,
        gate_results=(
            GateResult(plane=QualificationPlane.DATA_REALITY, passed=True),
            GateResult(plane=QualificationPlane.BEHAVIORAL_METROLOGY, passed=True),
            GateResult(plane=QualificationPlane.RUNTIME_SCALE, passed=True),
        ),
        onboarding_plan=plan, golden_cases=(_case("1", BenchmarkCaseType.HEALTHY),), generated_at=now,
    )
    assert package.decision.value == "BLOCKED"
    assert any("RELIABILITY_DR" in reason for reason in package.blockers)
