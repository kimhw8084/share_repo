from datetime import datetime, timezone

import pytest

from ephi.advisory.demo import build_demo_advisory_service
from ephi.advisory.models import AdvisoryWorkflowState, ClosureFeedback, WorkflowMutation


def test_workflow_is_audited_and_closure_feedback_is_preserved() -> None:
    service = build_demo_advisory_service()
    episode_id = service.list_attention()[0].episode_id
    t0 = datetime(2026, 8, 19, 14, 10, tzinfo=timezone.utc)

    service.workflow.mutate(
        episode_id,
        WorkflowMutation(actor="eng1", state=AdvisoryWorkflowState.ACKNOWLEDGED, owner="eng1"),
        now=t0,
    )
    service.workflow.mutate(
        episode_id,
        WorkflowMutation(actor="eng1", state=AdvisoryWorkflowState.INVESTIGATING),
        now=t0,
    )
    service.workflow.close(
        episode_id,
        ClosureFeedback(
            actor="eng1",
            behavior_confirmed="YES",
            quality_affected="UNKNOWN",
            likely_category="Measurement system",
            action_taken="reference wafer and calibration review",
            action_resolved_state="YES",
            confidence="HIGH",
            note="confirmed head-local measurement bias",
        ),
        now=t0,
    )

    assert service.workflow.get(episode_id).state is AdvisoryWorkflowState.RESOLVED
    record = service.workflow.closure_feedback(episode_id)
    assert record is not None
    assert record.feedback.action_taken == "reference wafer and calibration review"
    actions = [item.action for item in service.workflow.audit(episode_id)]
    assert actions.count("WORKFLOW_MUTATION") == 3
    assert actions[-1] == "CLOSURE_FEEDBACK"

    with pytest.raises(ValueError):
        service.workflow.mutate(
            episode_id,
            WorkflowMutation(actor="eng2", state=AdvisoryWorkflowState.INVESTIGATING),
            now=t0,
        )
