import pytest
from pydantic import ValidationError

from ephi.advisory.models import EpisodeAdvisoryContext


def test_operational_priority_is_not_free_form() -> None:
    with pytest.raises(ValidationError):
        EpisodeAdvisoryContext(operational_priority="P9")
