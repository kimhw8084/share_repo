from datetime import datetime, timezone
from pathlib import Path

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.advisory.checkpoint import restore_advisory_state, save_advisory_state
from ephi.advisory.demo import build_demo_advisory_service
from ephi.advisory.models import AdvisoryWorkflowState, WorkflowMutation
from ephi.advisory.service import AdvisoryService


def test_advisory_checkpoint_preserves_workflow_missed_events_and_versions(tmp_path: Path) -> None:
    first = build_demo_advisory_service()
    episode_id = first.list_attention()[0].episode_id
    source = first.sources.get(episode_id)
    assert source is not None
    first.mutate_workflow(
        episode_id,
        WorkflowMutation(actor="eng1", state=AdvisoryWorkflowState.ACKNOWLEDGED, owner="eng1"),
    )
    first.create_missed_event(
        asset_id="TOOL-9",
        start_time=datetime(2026, 8, 19, 12, 0, tzinfo=timezone.utc),
        reporter="eng2",
        description="legacy excursion not surfaced by EPHI",
    )
    source_version = first.get_view(episode_id).episode_version

    store = SqliteStateStore(tmp_path / "state.sqlite")
    saved_version = save_advisory_state(first, store)
    assert saved_version == 1

    second = AdvisoryService()
    restored_version = restore_advisory_state(second, store)
    assert restored_version == 1
    second.upsert_source(source, source_version=source_version)

    view = second.get_view(episode_id)
    assert view.episode_version == source_version
    assert view.workflow.state is AdvisoryWorkflowState.ACKNOWLEDGED
    assert view.workflow.owner == "eng1"
    assert len(second.missed_events()) == 1
    assert second.missed_events()[0].asset_id == "TOOL-9"
