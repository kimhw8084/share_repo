from pathlib import Path

from ephi.advisory.policy import load_presentation_policy


def test_advisory_presentation_policy_loads_from_yaml() -> None:
    root = Path(__file__).parents[2]
    policy = load_presentation_policy(root / "configs" / "advisory" / "presentation.yaml")
    assert policy.version == "advisory-v1"
    assert policy.top_support == 4
    assert policy.strong_net == 0.90
