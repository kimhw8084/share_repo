from dataclasses import replace

from ephi.advisory.demo import build_demo_advisory_service
from ephi.advisory.read_models import build_episode_view
from ephi.advisory.service import AdvisoryEpisodeSource
from ephi.domain.evidence import EvidenceEffect, EvidenceItem, Hypothesis, HypothesisEffect


def test_episode_view_preserves_authoritative_conclusion_and_surfaces_limits() -> None:
    service = build_demo_advisory_service()
    item = service.list_attention()[0]
    view = service.get_view(item.episode_id)

    assert view.header.leading_hypothesis is Hypothesis.METROLOGY_SYSTEM_SHIFT
    assert view.header.operational_priority == "P1"
    assert view.header.technical_severity.name == "INVESTIGATE"
    assert view.presentation_policy_version == "advisory-v1"
    assert view.top_support
    assert view.top_contradictions
    assert view.contradiction_summary == "Material contradictory evidence is present."
    assert view.confidence_limitations
    assert view.comparison.peer_asset_ids == ("METRO001/HEAD_B", "METRO001/HEAD_C")
    assert view.measurement_system is not None
    assert view.measurement_system.interpretation == "Measurement-system shift supported"
    assert view.quality[0].state.value == "NOT_YET_MATURE"
    assert view.recommended_verification
    assert len(view.analytical_revisions) == 1


def test_read_model_deduplicates_correlated_evidence_by_dependency_group() -> None:
    service = build_demo_advisory_service()
    episode_id = service.list_attention()[0].episode_id
    source = service.sources.get(episode_id)
    assert source is not None
    original = source.assessment.evidence[0]
    duplicate = EvidenceItem(
        evidence_id="EV-REF-DUP",
        asset_id=original.asset_id,
        execution_id=original.execution_id,
        event_time=original.event_time,
        channel=original.channel,
        evidence_type="REFERENCE_STANDARD_EWMA",
        observation="correlated EWMA view of the same reference-standard shift",
        strength=0.40,
        confidence=0.95,
        dependency_group=original.dependency_group,
        effects=(
            HypothesisEffect(
                Hypothesis.METROLOGY_SYSTEM_SHIFT,
                EvidenceEffect.SUPPORTS,
                0.40,
                "REFERENCE_EWMA",
            ),
        ),
    )
    assessment = replace(source.assessment, evidence=source.assessment.evidence + (duplicate,))
    view = build_episode_view(
        source.episode,
        assessment,
        advisory_context=source.advisory_context,
        quality_associations=source.quality_associations,
    )
    reference_items = [item for item in view.top_support if item.dependency_group == original.dependency_group]
    assert len(reference_items) == 1
    assert reference_items[0].evidence_id == original.evidence_id


def test_read_model_cache_invalidates_on_source_version() -> None:
    service = build_demo_advisory_service()
    episode_id = service.list_attention()[0].episode_id
    first = service.get_view(episode_id)
    second = service.get_view(episode_id)
    assert first is second

    source = service.sources.get(episode_id)
    assert source is not None
    service.upsert_source(AdvisoryEpisodeSource(**source.__dict__)) if hasattr(source, "__dict__") else service.upsert_source(source)
    third = service.get_view(episode_id)
    assert third is not first
    assert third.episode_version == first.episode_version + 1


def test_analytical_revision_history_preserves_prior_hypothesis() -> None:
    service = build_demo_advisory_service()
    episode_id = service.list_attention()[0].episode_id
    source = service.sources.get(episode_id)
    assert source is not None
    changed_assessment = replace(
        source.assessment,
        event_time=source.assessment.event_time.replace(minute=source.assessment.event_time.minute + 1),
        leading_hypothesis=Hypothesis.LOCAL_ASSET_DEGRADATION,
    )
    service.upsert_source(replace(source, assessment=changed_assessment))
    view = service.get_view(episode_id)
    assert view.header.leading_hypothesis is Hypothesis.LOCAL_ASSET_DEGRADATION
    assert [item.leading_hypothesis for item in view.analytical_revisions] == [
        Hypothesis.METROLOGY_SYSTEM_SHIFT,
        Hypothesis.LOCAL_ASSET_DEGRADATION,
    ]
