from ephi.history.qualification import run_history_rca_qualification
def test_history_rca_qualification_gate():
    r=run_history_rca_qualification(case_count=300,affected_count=40)
    assert r.passed
    assert r.future_case_excluded
    assert r.routine_prevalence_difference == 0
    assert r.future_temporal_plausibility == 'CONTRADICTS'
