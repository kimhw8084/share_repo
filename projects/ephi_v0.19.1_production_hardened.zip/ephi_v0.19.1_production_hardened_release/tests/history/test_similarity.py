from datetime import datetime, timezone, timedelta
from ephi.domain.history import EpisodeFingerprint,FingerprintComponent,FingerprintDomain,HistoricalCase,HistoricalCaseCuration
from ephi.history.similarity import ExactSimilarityEngine

def fp(fid, *, op="OP1", product="P1", behavior=(1.0,2.0), measurement=(0.2,0.1), asset="A1"):
    now=datetime(2026,1,1,tzinfo=timezone.utc)
    return EpisodeFingerprint(fingerprint_id=fid,episode_id=f"E:{fid}",asset_id=asset,equipment_family="METRO",operation=op,recipe_id="R1",product_id=product,technology="T1",created_at=now,components=(FingerprintComponent(domain=FingerprintDomain.BEHAVIOR,values=behavior,confidence=.9),FingerprintComponent(domain=FingerprintDomain.MEASUREMENT_SYSTEM,values=measurement,confidence=.8)))

def case(cid,f,available):
    return HistoricalCase(case_id=cid,asset_id=f.asset_id,equipment_family=f.equipment_family,opened_at=f.created_at,available_at=available,fingerprint=f,curation=HistoricalCaseCuration.ROOT_CAUSE_CONFIRMED,root_cause_category="CALIBRATION",root_cause_confidence=.95)

def test_exact_similarity_and_availability_filter():
    engine=ExactSimilarityEngine(); q=fp("Q")
    c1=case("C1",fp("F1",asset="A2"),q.created_at-timedelta(days=1))
    c2=case("C2",fp("F2",behavior=(9.0,-2.0),measurement=(4.0,1.0)),q.created_at-timedelta(days=1))
    future=case("FUT",fp("FF"),q.created_at+timedelta(days=1))
    out=engine.search(q,(c2,future,c1),as_of=q.created_at,top_k=3)
    assert [x.case_id for x in out][0]=="C1"
    assert all(x.case_id!="FUT" for x in out)
    assert out[0].similarity > out[1].similarity

def test_unavailable_domain_is_not_zero_similarity_penalty():
    engine=ExactSimilarityEngine(); q=fp("Q")
    partial=EpisodeFingerprint(fingerprint_id="PART",episode_id="EP",asset_id="A3",equipment_family="METRO",operation="OP1",recipe_id="R1",product_id="P1",technology="T1",created_at=q.created_at,components=(FingerprintComponent(domain=FingerprintDomain.BEHAVIOR,values=(1.0,2.0),confidence=.9),))
    c=case("C",partial,q.created_at)
    r=engine.compare(q,c)
    assert r.similarity > .9
    assert all(x.domain is not FingerprintDomain.MEASUREMENT_SYSTEM for x in r.domain_results)

def test_strict_context_blocks_incompatible_operation():
    q=fp("Q"); c=case("C",fp("X",op="OTHER"),q.created_at)
    assert ExactSimilarityEngine().compare(q,c).similarity == 0
