from ephi.history.policy import load_similarity_policy
from ephi.domain.history import FingerprintDomain
def test_similarity_policy_loads_versioned_scales():
    p=load_similarity_policy('configs/history/reference.yaml')
    assert p.domain_weights[FingerprintDomain.BEHAVIOR]==1.0
    assert p.scale(FingerprintDomain.TEMPORAL,'duration_h',0)==24.0
