from datetime import datetime,timezone
from ephi.domain.history import *

def _fp():
    t=datetime(2026,1,1,tzinfo=timezone.utc)
    return EpisodeFingerprint(fingerprint_id="F",episode_id="E",asset_id="A",equipment_family="X",operation="O",recipe_id="R",product_id="P",technology="T",created_at=t,components=(FingerprintComponent(domain=FingerprintDomain.BEHAVIOR,values=(1.0,)),))
def test_confirmed_case_confidence_exceeds_unreviewed():
    f=_fp(); kw=dict(asset_id="A",equipment_family="X",opened_at=f.created_at,available_at=f.created_at,fingerprint=f,root_cause_category="X",root_cause_confidence=.9)
    a=HistoricalCase(case_id="A",curation=HistoricalCaseCuration.ROOT_CAUSE_CONFIRMED,**kw)
    b=HistoricalCase(case_id="B",curation=HistoricalCaseCuration.UNREVIEWED,**kw)
    assert a.case_confidence>b.case_confidence
