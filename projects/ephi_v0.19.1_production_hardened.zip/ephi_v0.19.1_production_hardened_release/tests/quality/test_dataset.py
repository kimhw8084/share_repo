from datetime import datetime, timedelta, timezone

import pytest

from ephi.domain.context import ContextKey
from ephi.domain.quality import (
    EquipmentStateVector,
    OutcomeMaturityState,
    PredictionTime,
    QualityOutcomeObservation,
    QualityStage,
    QualityTargetDefinition,
    QualityTargetType,
)
from ephi.quality.dataset import build_quality_dataset


def _target() -> QualityTargetDefinition:
    return QualityTargetDefinition(
        target_id="Q",
        version="1",
        target_type=QualityTargetType.CONTINUOUS,
        stage=QualityStage.INLINE_METROLOGY,
        prediction_time=PredictionTime.POST_PROCESS,
    )


def _state(t0: datetime) -> EquipmentStateVector:
    return EquipmentStateVector(
        execution_id="E1",
        material_id="W1",
        asset_id="A1",
        context=ContextKey("OP", "R", "P", "T"),
        event_time=t0,
        known_at=t0 + timedelta(minutes=2),
        behavioral_novelty=0.4,
        health_confidence=0.9,
        local_support=0.5,
        common_mode_support=0.0,
        measurement_system_support=0.0,
    )


def test_dataset_rejects_future_label_leakage() -> None:
    t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
    state = _state(t0)
    outcome = QualityOutcomeObservation(
        material_id="W1", execution_id="E1", asset_id="A1", context=state.context,
        target_id="Q", value=1.0, event_time=t0 + timedelta(minutes=3),
        available_at=t0 + timedelta(minutes=4), maturity=OutcomeMaturityState.MATURE_AVAILABLE,
    )
    with pytest.raises(ValueError, match="quality leakage"):
        build_quality_dataset(
            target=_target(), states=[state], outcomes=[outcome],
            knowledge_cutoff=t0 + timedelta(hours=1),
            prediction_cutoff_by_execution={"E1": t0 + timedelta(minutes=5)},
        )


def test_dataset_excludes_intervention_censoring_and_immature_outcome() -> None:
    t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
    state = _state(t0)
    censored = QualityOutcomeObservation(
        material_id="W1", execution_id="E1", asset_id="A1", context=state.context,
        target_id="Q", value=0.0, event_time=t0 + timedelta(hours=1),
        available_at=t0 + timedelta(hours=1, minutes=5), maturity=OutcomeMaturityState.HELD,
    )
    snapshot = build_quality_dataset(
        target=_target(), states=[state], outcomes=[censored],
        knowledge_cutoff=t0 + timedelta(hours=2),
    )
    assert snapshot.manifest.row_count == 0
    assert snapshot.manifest.excluded_intervention_censored == 1
