from datetime import timedelta
from pathlib import Path

from ephi.domain.quality import PredictionTime, QualityStage, QualityTargetDefinition, QualityTargetType
from ephi.health.engine import BehavioralHealthPipeline
from ephi.quality.artifacts import load_quality_model_bundle, save_quality_model_bundle
from ephi.quality.dataset import build_quality_dataset, equipment_state_vectors_from_assessments
from ephi.quality.modeling import train_quality_models
from ephi.quality.targets import load_quality_target
from ephi.synthetic.quality import QualityScenarioConfig, generate_quality_scenario


def test_example_quality_target_loads() -> None:
    root = Path(__file__).parents[2]
    target = load_quality_target(root / "configs" / "quality" / "example_inline.yaml")
    assert target.target_id == "INLINE_Q_EXAMPLE"
    assert target.harmful_direction == "UPPER"


def test_quality_model_artifact_has_hash_and_roundtrips(tmp_path: Path) -> None:
    observations, outcomes = generate_quality_scenario(QualityScenarioConfig(executions_per_asset=450, harmful=True))
    result = BehavioralHealthPipeline().process(observations)
    states = equipment_state_vectors_from_assessments(observations, result.assessments)
    target = QualityTargetDefinition(
        target_id="INLINE_Q_CONT", version="1", target_type=QualityTargetType.CONTINUOUS,
        stage=QualityStage.INLINE_METROLOGY, prediction_time=PredictionTime.POST_PROCESS,
        harmful_direction="UPPER", minimum_practical_effect=0.2,
    )
    dataset = build_quality_dataset(
        target=target, states=states, outcomes=outcomes,
        knowledge_cutoff=max(item.available_at for item in outcomes) + timedelta(minutes=1),
    )
    bundle = train_quality_models(dataset)
    metadata = save_quality_model_bundle(bundle, tmp_path)
    assert len(metadata.model_sha256) == 64
    loaded = load_quality_model_bundle(tmp_path)
    assert loaded.target == bundle.target
    assert loaded.comparison == bundle.comparison


def test_quality_model_artifact_detects_tampering(tmp_path: Path) -> None:
    observations, outcomes = generate_quality_scenario(QualityScenarioConfig(executions_per_asset=450, harmful=True))
    result = BehavioralHealthPipeline().process(observations)
    states = equipment_state_vectors_from_assessments(observations, result.assessments)
    target = QualityTargetDefinition(
        target_id="INLINE_Q_CONT", version="1", target_type=QualityTargetType.CONTINUOUS,
        stage=QualityStage.INLINE_METROLOGY, prediction_time=PredictionTime.POST_PROCESS,
        harmful_direction="UPPER", minimum_practical_effect=0.2,
    )
    dataset = build_quality_dataset(
        target=target, states=states, outcomes=outcomes,
        knowledge_cutoff=max(item.available_at for item in outcomes) + timedelta(minutes=1),
    )
    bundle = train_quality_models(dataset)
    save_quality_model_bundle(bundle, tmp_path)
    model_path = tmp_path / "model.joblib"
    model_path.write_bytes(model_path.read_bytes() + b"tamper")
    import pytest
    with pytest.raises(ValueError, match="content hash mismatch"):
        load_quality_model_bundle(tmp_path)
