from pathlib import Path

from ephi.domain.context import ContextKey
from ephi.domain.quality import EquipmentStateVector
from ephi.quality.gates import apply_quality_gate, load_quality_gate_policy
from ephi.quality.qualification import run_quality_qualification
from ephi.quality.sampling import diagnose_sampling_bias


def _state(i: int, novelty: float) -> EquipmentStateVector:
    from datetime import datetime, timedelta, timezone
    t = datetime(2026, 1, 1, tzinfo=timezone.utc) + timedelta(minutes=i)
    return EquipmentStateVector(
        execution_id=f"E{i}", material_id=f"W{i}", asset_id="A",
        context=ContextKey("OP", "R", f"P{i % 2}", "T"), event_time=t, known_at=t,
        behavioral_novelty=novelty, health_confidence=1.0, local_support=novelty,
        common_mode_support=0.0, measurement_system_support=0.0,
    )


def test_sampling_bias_diagnostic_detects_health_triggered_selection() -> None:
    states = [_state(i, i / 199.0) for i in range(200)]
    sampled = {row.execution_id for row in states if row.behavioral_novelty > 0.65}
    result = diagnose_sampling_bias(states, sampled_execution_ids=sampled)
    assert result.state_dependence_auc is not None and result.state_dependence_auc > 0.90
    assert result.diagnostic_state == "SELECTION_BIAS_RISK"


def test_external_quality_gate_policy_passes_reference_benchmark() -> None:
    root = Path(__file__).parents[2]
    policy = load_quality_gate_policy(root / "configs" / "qualification" / "synthetic_quality.yaml")
    decision = apply_quality_gate(run_quality_qualification(), policy)
    assert decision.passed
