from datetime import timedelta

from ephi.domain.quality import PredictionTime, QualityStage, QualityTargetDefinition, QualityTargetType
from ephi.health.engine import BehavioralHealthPipeline
from ephi.quality.dataset import build_quality_dataset, equipment_state_vectors_from_assessments
from ephi.quality.modeling import train_quality_models
from ephi.synthetic.quality import QualityScenarioConfig, generate_quality_scenario


def _bundle(*, harmful: bool, target_type: QualityTargetType, n: int = 450):
    observations, outcomes = generate_quality_scenario(
        QualityScenarioConfig(executions_per_asset=n, harmful=harmful, target_type=target_type)
    )
    result = BehavioralHealthPipeline().process(observations)
    states = equipment_state_vectors_from_assessments(observations, result.assessments)
    target_id = "INLINE_Q_CONT" if target_type is QualityTargetType.CONTINUOUS else "INLINE_Q_BIN"
    target = QualityTargetDefinition(
        target_id=target_id, version="1", target_type=target_type,
        stage=QualityStage.INLINE_METROLOGY, prediction_time=PredictionTime.POST_PROCESS,
        minimum_practical_effect=0.2 if target_type is QualityTargetType.CONTINUOUS else 0.05,
        measurement_system_sensitive=True,
        harmful_direction="UPPER",
    )
    snapshot = build_quality_dataset(
        target=target, states=states, outcomes=outcomes,
        knowledge_cutoff=max(item.available_at for item in outcomes) + timedelta(minutes=1),
    )
    return snapshot, train_quality_models(snapshot)


def test_m1_beats_context_only_for_harmful_equipment_state() -> None:
    _, bundle = _bundle(harmful=True, target_type=QualityTargetType.CONTINUOUS)
    assert bundle.comparison.equipment_state_useful
    assert bundle.comparison.m1.rmse < bundle.comparison.m0.rmse
    assert bundle.m1_interval_half_width is not None and bundle.m1_interval_half_width > 0


def test_m1_is_not_promoted_for_benign_equipment_novelty() -> None:
    _, bundle = _bundle(harmful=False, target_type=QualityTargetType.CONTINUOUS)
    assert not bundle.comparison.equipment_state_useful


def test_binary_path_is_chronologically_calibrated() -> None:
    _, bundle = _bundle(harmful=True, target_type=QualityTargetType.BINARY, n=800)
    assert bundle.comparison.equipment_state_useful
    assert bundle.comparison.m1.brier < bundle.comparison.m0.brier
    assert bundle.comparison.calibration_method == "PLATT_CHRONOLOGICAL_CALIBRATION"
    assert bundle.m1_calibrator is not None


def test_unseen_product_is_flagged_by_applicability_contract() -> None:
    from dataclasses import replace
    from ephi.domain.context import ContextKey

    snapshot, bundle = _bundle(harmful=True, target_type=QualityTargetType.CONTINUOUS)
    row = snapshot.rows[-1]
    unseen = replace(
        row,
        context=ContextKey(row.context.operation, row.context.recipe_id, "UNSEEN_PRODUCT", row.context.technology),
    )
    result = bundle.predict([unseen])[0]
    assert not result.applicability.applicable
    assert "UNSEEN_PRODUCT" in result.applicability.reason_codes
    assert result.model_confidence < row.health_confidence
