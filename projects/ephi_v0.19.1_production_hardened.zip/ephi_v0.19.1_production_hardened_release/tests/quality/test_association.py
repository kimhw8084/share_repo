from datetime import timedelta

from ephi.domain.quality import PredictionTime, QualityEvidenceState, QualityStage, QualityTargetDefinition, QualityTargetType
from ephi.health.engine import BehavioralHealthPipeline
from ephi.quality.association import build_quality_association
from ephi.quality.dataset import build_quality_dataset, equipment_state_vectors_from_assessments
from ephi.quality.evidence import evidence_from_quality_association
from ephi.synthetic.quality import QualityScenarioConfig, generate_quality_scenario


def _dataset(integrity: float = 1.0):
    n = 450
    observations, outcomes = generate_quality_scenario(QualityScenarioConfig(executions_per_asset=n, harmful=True))
    result = BehavioralHealthPipeline().process(observations)
    states = equipment_state_vectors_from_assessments(observations, result.assessments)
    target = QualityTargetDefinition(
        target_id="INLINE_Q_CONT", version="1", target_type=QualityTargetType.CONTINUOUS,
        stage=QualityStage.INLINE_METROLOGY, prediction_time=PredictionTime.POST_PROCESS,
        minimum_practical_effect=0.2, measurement_system_sensitive=True,
        harmful_direction="UPPER",
    )
    measurement = {state.execution_id: integrity for state in states}
    dataset = build_quality_dataset(
        target=target, states=states, outcomes=outcomes,
        knowledge_cutoff=max(item.available_at for item in outcomes) + timedelta(minutes=1),
        measurement_integrity_by_execution=measurement,
    )
    exposed = {
        row.execution_id for row in dataset.rows
        if row.asset_id == "A000" and int(row.execution_id.rsplit("-", 1)[1]) >= int(n * 0.60)
    }
    return target, dataset, exposed


def test_exposed_vs_control_supports_harmfulness_without_causal_claim() -> None:
    target, dataset, exposed = _dataset()
    evidence = build_quality_association(target=target, rows=dataset.rows, exposed_execution_ids=exposed)
    assert evidence.evidence_state in {QualityEvidenceState.SUPPORTED_ASSOCIATION, QualityEvidenceState.STRONG_ASSOCIATION}
    assert evidence.adjusted_effect is not None and evidence.adjusted_effect > target.minimum_practical_effect
    assert evidence.metadata["causal_claim"] is False


def test_measurement_integrity_limits_process_quality_confidence() -> None:
    target, dataset, exposed = _dataset(integrity=0.25)
    evidence = build_quality_association(target=target, rows=dataset.rows, exposed_execution_ids=exposed)
    assert evidence.association_confidence <= 0.25
    assert "MEASUREMENT_SYSTEM_INTEGRITY_LOW" in evidence.contradictions


def test_quality_association_becomes_dependency_aware_evidence() -> None:
    target, dataset, exposed = _dataset()
    association = build_quality_association(target=target, rows=dataset.rows, exposed_execution_ids=exposed)
    item = evidence_from_quality_association(
        association, asset_id="A000", execution_id="E-A000-0000449", event_time=dataset.rows[-1].prediction_cutoff,
    )
    assert item.dependency_group == "QUALITY:INLINE_Q_CONT"
    assert item.channel.value == "QUALITY_HARMFULNESS"


def test_measurement_system_target_supports_metrology_hypothesis_without_integrity_penalty() -> None:
    from dataclasses import replace
    from ephi.domain.evidence import EvidenceEffect, Hypothesis
    from ephi.quality.evidence import evidence_from_quality_association

    target, dataset, exposed = _dataset(integrity=0.25)
    measurement_target = target.model_copy(update={"stage": QualityStage.MEASUREMENT_SYSTEM})
    association = build_quality_association(
        target=measurement_target, rows=dataset.rows, exposed_execution_ids=exposed
    )
    assert association.association_confidence > 0.25
    item = evidence_from_quality_association(
        association, asset_id="METRO001/HEAD_A", execution_id="E1", event_time=dataset.rows[-1].prediction_cutoff
    )
    assert any(
        effect.hypothesis is Hypothesis.METROLOGY_SYSTEM_SHIFT and effect.effect is EvidenceEffect.SUPPORTS
        for effect in item.effects
    )


def test_opposite_direction_is_contradictory_not_harmful() -> None:
    target, dataset, exposed = _dataset()
    lower_is_bad = target.model_copy(update={"harmful_direction": "LOWER"})
    association = build_quality_association(
        target=lower_is_bad, rows=dataset.rows, exposed_execution_ids=exposed
    )
    assert association.evidence_state is QualityEvidenceState.CONTRADICTED
