# Internal Qualification Control Plane Runbook

## 1. Wire shared state and identity

Use the company-port composition root. The qualification service must use a shared, durable, compare-and-set-capable state backend. Do not use pod-local SQLite in a multi-pod deployment.

The company app must resolve authenticated identities into `EPHI_VIEWER`, `EPHI_ENGINEER`, and `EPHI_ADMIN` roles. Plan registration, gate recording, and promotion approval require admin.

## 2. Register the family onboarding plan

Generate the plan from the internal Data Reality report and the approved family onboarding policy. Register that exact plan in the control plane. A new release or new target state requires a new plan registration.

## 3. Curate Golden internal history

Engineers submit candidate historical cases with source locator, scope, expected behavior, label confidence, and evidence references. A different engineer reviews the case. Accepted cases become the internal historical Golden corpus; synthetic cases remain regression-only evidence.

Do not edit an accepted case in place. Material relabeling requires a new intake identity or an explicit future correction workflow.

## 4. Record qualification gates

Record gate evidence with release ID, capability ID, qualification plane, pass/fail state, and immutable artifact reference. Gate evidence is append-only; newer gate records supersede older records only when the promotion builder selects the latest record for the same release/capability/plane.

## 5. Generate promotion evidence

Promotion generation uses:

- current family certification state;
- current registered onboarding plan;
- latest gate records for the current release/capability;
- accepted internal Golden cases;
- shadow metrics for `SHADOW_QUALIFIED`.

If any evidence is missing or the state transition is illegal, the package is `BLOCKED`.

## 6. Shadow engineer review

System-side code supplies candidate episodes. The control plane applies the versioned stratified sampling policy and enqueues the selected episodes. Engineers claim work through a lease. Expired claims become reclaimable.

Completion is atomic: review record + queue completion commit together. Only one completed qualification review is accepted per episode in this reference workflow.

## 7. Approve promotion

Only approve a READY package. Approval re-validates that the package still matches the current family state and onboarding release. If another approver already promoted the family, the stale package is rejected after CAS retry.

## 8. Audit and export

Use the family export/read endpoints for qualification packages and promotion review. Preserve exports and linked evidence artifacts according to the internal engineering-quality retention policy.

Never modify exported JSON and re-import it as authoritative state.

## Failure handling

- **CAS contention:** retry is automatic and bounded. Persistent exhaustion indicates backend contention or an unhealthy shared-state service.
- **Duplicate command:** treat as a client retry/duplicate request; no side effect is duplicated.
- **Expired review lease:** reclaim the item; do not manually change workspace state.
- **Stale promotion:** regenerate evidence against the current family state/release.
- **Missing actor resolver:** qualification mutations must remain unavailable.
- **Missing shared state:** do not start qualification-control replicas.
