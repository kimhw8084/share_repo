# EPHI v0.12.0 — Internal Port Kit & Shadow Bootstrap Package

## Governing principle

**Port proprietary infrastructure at explicit seams; do not fork scientific logic.**

The company integration is intentionally outside `src/ephi` under the separately installable `company_port/src/ephi_company` package. EPHI continues to own logical manufacturing contracts, knowledge-time semantics, bootstrap ordering, qualification states, evidence/episode behavior, and release provenance. The company package owns physical table execution, durable infrastructure, identity, notification transport, materialized service composition, and internal qualification adapters.

## One controlled path to shadow

`ephi port bootstrap` executes these stages in fixed order:

1. `MAPPING_VALIDATION`
2. `DATA_REALITY`
3. `STATE_BOOTSTRAP`
4. `GOLDEN_REPLAY`
5. `OPERATIONS_QUALIFICATION`
6. `SHADOW_READINESS`

A failed stage blocks every downstream stage. Completed stages are checkpointed through `StateStore` and may be resumed only when release ID, package version, config hash, family ID, and environment match the stored `PortRunIdentity`.

Changing any of those identities refuses reuse of the old bootstrap checkpoint. This prevents a successful historical replay under release A from silently qualifying release B.

## Capability-scoped port target

The company configuration must declare `port.required_capabilities`. Mapping and Data Reality are hard gates only for the datasets/capabilities required by the chosen pilot. Optional future capabilities remain visible in the audit but do not block a focused deployment.

The reference metrology port declares:

- `PROCESS_HISTORY`
- `METROLOGY`
- `REFERENCE_WAFER`

`allow_partial_capabilities` defaults to false in the company example. Relaxing it is an explicit qualification policy choice, not an implicit fallback.

## Company package seams

### `big_data.py`

Implements only the approved physical Arrow query executor. `MappedBigDataClient` restores stable logical names before analytical repositories receive data.

### `state.py`

Provides shared durable CAS state, materialization storage, and immutable artifact storage. Multi-pod Kubernetes deployment must not use pod-local SQLite.

### `audit.py`

Provides a Data Reality backend that pushes profiling/aggregation into the internal Big Data platform rather than downloading whole manufacturing tables.

### `bootstrap_tasks.py`

Provides the company-specific executor for canonical history, exposure spine, features, maintenance state, references, peers, historical replay state, quality state, and history index bootstrap.

### `qualification.py`

Provides the internal Golden historical gate, measured runtime/scale gate, and real engineer shadow-readiness gate.

### `runtime.py`

Provides the shared queue plus idempotent role-specific work handlers.

### `services.py`

Composes company-backed materialized Advisory, History/RCA, Value, and Operations services. API requests must not turn into arbitrary raw-history queries.

### `auth.py` / `app.py`

Integrates company identity. Health/version probes remain open to platform checks; `/v1` reads require viewer/engineer/admin and mutation routes require engineer/admin. The core API `actor_resolver` overrides body-supplied actor/reporter fields with the authenticated identity for audit integrity.

### `notifications.py`

Wraps the approved internal publisher behind `NotificationDeliveryGate`, ensuring delivery suppression cannot be bypassed by the transport adapter.

## Runtime configuration

`EPHI_CONFIG_PATHS` may contain a comma-separated ordered config stack, for example:

```text
/etc/ephi/base.yaml,/etc/ephi/company.yaml,/etc/ephi/family.yaml
```

Explicit CLI `--config` values take precedence over the environment variable.

## Kubernetes package

`company_port/deploy/base` contains a self-contained copy of the rendered EPHI shadow deployment. `company_port/deploy/overlays/shadow`:

- appends `EPHI_CONFIG_PATHS` to every Deployment without replacing existing `EPHI_RUNTIME_ROLE` / qualification environment values;
- adds a one-shot `ephi-shadow-bootstrap` Job;
- runs `ephi port bootstrap --runtime-module ephi_company.bootstrap`;
- exits non-zero until all six port stages pass.

Company configuration volumes, secret/identity injection, image policy, ingress and resource sizing remain internal responsibilities.

## Release provenance

The v0.12 release code/config hash includes:

- `src/ephi` Python code;
- EPHI YAML config;
- `company_port` Python hooks;
- company-port YAML/kustomize templates;
- company-port packaging metadata and Docker composition.

Therefore an auth/runtime/adapter change cannot preserve the same EPHI release identity.

## Deliberate fail-closed behavior

The untouched company scaffold raises `CompanyPortNotConfiguredError` for unknown physical infrastructure. It never substitutes:

- local SQLite for shared multi-pod state;
- no-op worker handlers;
- anonymous API identity;
- in-memory production advisory state;
- fake Golden historical results;
- synthetic operations qualification;
- synthetic engineer shadow reviews.

## Reference qualification

The portable v0.12 port-kit gate checks:

- ordered bootstrap success;
- downstream blocking after failure;
- resume idempotency;
- release/config/family identity mismatch rejection;
- complete company scaffold;
- explicit capability target;
- all-deployment configuration overlay;
- bootstrap Job presence;
- fail-closed auth/service/state hooks;
- notification delivery gate usage;
- no SQLite dependency in Kubernetes deployment paths.

This qualification proves the **port mechanism**, not internal manufacturing readiness.

## Internal exit criteria

The company port can move from template/bootstrap into controlled shadow only after:

1. physical mappings contain no placeholders for required capabilities;
2. required Data Reality capabilities meet the chosen qualification state;
3. historical/bootstrap materializations complete under the exact release/config identity;
4. strict internal Golden historical replay passes;
5. measured shared-state/queue/runtime/freshness qualification passes;
6. family manifest remains legal under certification rules;
7. identity/authorization and notification controls are live;
8. real engineer shadow evidence meets the approved shadow gate.

No portable artifact in this release claims those internal gates have already passed.
