# Milestone 21 — Internal Qualification Control Plane (v0.14.0)

## Purpose

v0.14.0 turns the v0.13 family-onboarding primitives into a collaborative, auditable control plane suitable for internal qualification work. It does **not** alter detector, metrology, quality, exposure, RCA, value, or operational-priority algorithms.

The control plane consumes their already-produced evidence and governs how humans curate Golden history, review shadow episodes, record qualification gates, generate promotion packages, and approve family manifests.

## Governing invariants

1. **Scientific truth is upstream.** The control plane cannot import or execute detectors, health engines, metrology engines, quality modeling, or RCA commonality logic.
2. **Authenticated actor wins over request-body identity.** Golden submitter/reviewer and shadow reviewer audit identity are derived from the API actor resolver.
3. **Independent Golden review.** A submitter cannot accept their own historical case.
4. **Immutable history.** Golden revisions, gate records, promotion evidence, manifests, command receipts, and audit events are append-only.
5. **Atomic review completion.** A shadow review and its queue transition commit in the same family workspace CAS transaction.
6. **Exactly-one concurrent winner.** Concurrent claims or promotion approvals re-read after CAS conflict; stale losers fail safely.
7. **Stale promotion evidence cannot be approved.** Approval checks both current certification state and onboarding release identity.
8. **Plan target must match promotion target.** An OFFLINE plan cannot be repurposed to package a SHADOW promotion.
9. **Duplicate command protection.** Reusing a `command_id` cannot duplicate side effects.
10. **No unauthenticated qualification mutation.** The generic API returns 503 without an actor resolver; the company app enforces role-based access before requests reach the core API.

## Durable state architecture

The portable reference implementation stores one versioned qualification workspace per family:

```text
onboarding:qualification-control:<family_id>:v1
```

The workspace contains:

- current `FamilyOnboardingPlan`;
- complete `GoldenCaseIntake` revision history;
- shadow candidates and review queue state;
- completed `EngineerShadowReview` records;
- immutable qualification gate records;
- generated promotion evidence packages;
- approved family qualification manifests;
- immutable audit events;
- applied command receipts.

All writes use the existing `StateStore.compare_and_set` contract. The repository has no mutable process-local cache. Each mutation reads the latest family state, re-applies the command, and commits with optimistic CAS. Contention uses bounded retry/backoff.

The family partition is intentional: qualification volume is low, while atomicity across related qualification objects is more important than micro-optimizing per-record storage. An internal backend may replace the physical storage implementation as long as it preserves shared durability and CAS semantics.

## API surface

v0.14.0 adds typed read/write paths under:

```text
/v1/qualification/families/{family_id}
```

Key functions:

- workspace summary/dashboard;
- onboarding-plan registration;
- Golden intake/list/review/history;
- shadow queue/enqueue/claim/complete/metrics;
- gate-evidence recording;
- promotion evidence generation/listing;
- promotion approval;
- manifest history/current state;
- complete JSON qualification export;
- immutable audit history.

The full OpenAPI surface is 43 typed paths in v0.14.0.

## Company authorization model

The company scaffold retains:

- `EPHI_VIEWER` — read-only `/v1` access;
- `EPHI_ENGINEER` — engineer qualification actions such as Golden/shadow review;
- `EPHI_ADMIN` — all engineer actions plus qualification plan registration, gate recording, and promotion approval.

The generic EPHI package intentionally does not know the company identity mechanism. `ephi_company.app` resolves company identity and passes the authenticated subject into the core actor resolver.

## Qualification race semantics

Two race cases are directly regression-tested:

### Shadow claim race

Two reviewers claim one pending item concurrently.

Expected:

```text
1 CLAIMED
1 no-item result
1 persisted owner
```

### Promotion approval race

Two approvers attempt to approve the same READY package concurrently.

Expected:

```text
1 FamilyQualificationManifest
1 stale-state rejection
1 manifest in history
```

The second writer can never create a duplicate promoted family state.

## Qualification gate

`ephi onboarding control-benchmark` verifies:

- multi-instance concurrent Golden writes preserve every record;
- authenticated body-identity override;
- independent Golden review;
- exclusive shadow claim;
- atomic shadow completion;
- exactly-one concurrent shadow-claim winner;
- READY promotion evidence generation;
- persisted family manifest;
- exactly-one concurrent promotion-approval winner;
- stale promotion rejection;
- restart persistence;
- audit lineage;
- complete qualification export.

## Internal port requirements

Before enabling these APIs internally:

1. provide a shared CAS-capable `StateStore` — never pod-local SQLite across replicas;
2. wire the company identity resolver and role mapping;
3. build `QualificationControlPlaneService` from the shared store and approved family policy resolver;
4. connect missed-event history if shadow metrics should include missed-event burden;
5. define retention/backup policy for qualification workspace state;
6. ensure promotion approvers are a restricted role/group;
7. preserve release/config/family identity in gate artifacts and onboarding plans;
8. treat qualification export as audit evidence, not editable source data.

## Explicit non-goals

v0.14.0 does not:

- auto-accept Golden cases;
- auto-promote a family;
- infer engineer identity from body fields;
- modify analytical severity based on review feedback;
- train online from engineer feedback;
- expose raw manufacturing-query execution through qualification APIs;
- make a portable/synthetic family internally qualified.
