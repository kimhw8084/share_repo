# Milestone 12 — Golden Historical Benchmark & Qualification Framework (v0.5.0)

## Purpose

v0.5.0 makes EPHI's production-certification philosophy executable. The framework evaluates the same analytical pipelines that production uses, but replays historical facts according to when they were actually knowable.

The key rule is:

```text
manufacturing event_time != analytical decision known_at
```

A historical result is only visible when `available_at <= replay_as_of`. Late facts trigger replay from the known history rather than being treated as if they had always existed.

## Implemented

### Versioned benchmark truth

`BenchmarkCase` and `BenchmarkCorpus` now capture:

- family and case type;
- source kind (`SYNTHETIC_SCALAR`, `SYNTHETIC_METROLOGY`, `INTERNAL_HISTORY`);
- label confidence;
- expected local/fleet actionability;
- expected hypothesis and expected asset scope;
- best/low/high onset times;
- optional external detection time;
- source locator and replay scope;
- optional quality/root-cause/action/resolution metadata;
- evaluation exclusions and tags.

A corpus has a deterministic SHA-256 hash so benchmark changes cannot occur silently.

### Strict knowledge-time replay

`strict_knowledge_replay()`:

1. sorts source facts by `available_at`;
2. exposes only currently available facts;
3. updates incrementally while event time remains monotonic;
4. detects late or same-event-time additions;
5. rebuilds from the facts visible at that knowledge time when required;
6. records both the manufacturing event time and the first `known_at` time for each assessment transition;
7. records local and fleet episode emergence separately.

This implementation is correctness-first. The production late-data path remains checkpoint/dirty-range based, but both must implement equivalent knowledge-time semantics.

### Episode-level qualification

Each case reports:

- expected-episode detection;
- local/fleet episode counts;
- false actionable episodes;
- actionable asset scope;
- expected-hypothesis fraction;
- first decision `known_at`;
- first associated manufacturing event time;
- detection delay from labeled onset;
- lead time versus external/human detection when that timestamp is actually known;
- replay rebuild count;
- runtime;
- explicit failure reasons.

Corpus summaries report:

- case pass rate;
- episode recall;
- false actionable episodes;
- false actionable episodes per 1,000 asset-hours;
- mean detection delay;
- labeled lead time when available;
- runtime.

Performance is also stratified by label confidence, family, and case type.

### Hard release gates

`QualificationGatePolicy` is external policy, not detector code. It supports:

- minimum case pass rate;
- minimum episode recall;
- maximum false actionable episode burden;
- optional zero-case-failure requirement.

The included `configs/qualification/synthetic_regression.yaml` is intentionally strict because synthetic truth is exact. Internal pilot thresholds must be set from real manufacturing requirements rather than copied from the synthetic policy.

### Method bake-off

All candidate methods run against the identical corpus, population definitions, source availability timeline, and scoring criteria.

Built-in methods currently include:

- `baseline-v0.5`;
- `strict-reference-challenger`;
- `sensitive-sequential-challenger`.

The bake-off compares episode recall, false burden, detection delay, labeled lead time, and runtime. A challenger remains a challenger until real historical/shadow evidence justifies promotion.

### Reference and peer stress qualification

The v0.5 stress harness includes:

- 1%, 5%, and 10% reference contamination;
- one-peer poisoning;
- three-member-cohort poisoning;
- common-mode local-residual versus fleet-shift separation.

## Important defects discovered by the Golden Corpus

The qualification framework immediately found two issues that previous end-state benchmarks did not expose.

### 1. Healthy transient fleet episode

A short low-strength common-mode fluctuation could open and then resolve a fleet episode during otherwise healthy metrology history. End-of-replay checks missed it because no fleet episode remained active.

Fix:

`FleetEpisodeService` now requires a minimum common-mode support magnitude in addition to common-mode leading hypothesis, minimum severity, and minimum participating assets.

This suppresses weak transient fleet events while preserving the large common-mode support produced by true process shifts.

### 2. Remeasure attempts arriving in separate incremental batches

The metrology engine originally calculated repeatability from summaries present in one `process()` call. In real incremental operation, the first measurement and its remeasure arrive at different `available_at` times. Strict replay therefore correctly showed that a true repeatability problem could be missed.

Fix:

- pending remeasure summaries are retained across batches;
- a remeasure group is completed when later attempts arrive;
- repeatability evidence is emitted at the later attempt's knowledge time, not backdated onto the original measurement;
- pending remeasure state is checkpointed/restored;
- incomplete late peers can remain pending.

This is a production semantics correction, not a benchmark-specific patch.

## Fixed synthetic Golden Corpus

The fixed corpus contains nine cases:

```text
BEH-HEALTHY-001
BEH-LOCAL-001
BEH-COMMON-001
BEH-DATA-001
MET-HEALTHY-001
MET-HEAD-001
MET-PROCESS-001
MET-REMEASURE-001
MET-SPATIAL-001
```

The final baseline v0.5 result is recorded in `SYNTHETIC_QUALIFICATION_V050.json`.

Current fixed-corpus result:

```text
9 / 9 cases pass
6 / 6 expected actionable cases detected
Episode recall: 1.000
False actionable episodes: 0
False actionable episodes / 1,000 asset-hours: 0.000
Synthetic regression gate: PASS
```

Synthetic cases intentionally do not provide fabricated human/legacy detection timestamps. Therefore labeled lead-time is `null` until an internal historical corpus supplies a defensible external detection timestamp.

## Bake-off result

`METHOD_BAKEOFF_V050.json` shows all three current methods pass the small fixed synthetic corpus without false episodes.

The sensitive sequential challenger detects the fixed excursion set earlier on average than the baseline. This is useful research evidence, but **not sufficient for promotion**. The corpus is too small and synthetic to establish a safe false-event tradeoff for production manufacturing.

## Internal history bridge

The generic qualification core contains no company table names.

Company integration implements `HistoricalBenchmarkLoader`:

```text
BenchmarkCase
    ↓
company source_locator / approved materialization
    ↓
canonical ScalarFeatureObservation or MetrologyObservation
    ↓
strict knowledge-time replay
```

The returned observations must preserve `event_time` and `available_at`.

## Internal qualification sequence

1. Complete the Data Reality Audit.
2. Validate canonical golden samples manually.
3. Curate historical positives, negatives, benign cases, PM transitions, metrology-system events, common-mode events, and data incidents.
4. Assign label confidence rather than forcing uncertain truth.
5. Record onset best/low/high and external detection time only when defensible.
6. Build a fixed Golden Corpus and separate rolling recent corpus.
7. Run strict replay with the production release configuration.
8. Inspect failures by layer: data, reference, peer, feature, detector, fusion, decision policy.
9. Run reference/peer stress and relevant adversarial cases.
10. Run method bake-offs on identical snapshots.
11. Define family-specific gate policy from pilot requirements.
12. Only after offline qualification proceed to live shadow evaluation.

## What v0.5.0 does not claim

- The synthetic corpus is not production manufacturing validation.
- The synthetic detection-delay metric is not human lead-time or ROI.
- Current gate thresholds are not universal fab thresholds.
- The sensitive challenger is not promoted.
- Internal-history loading is deliberately an adapter contract because proprietary storage is environment-specific.
- This release does not yet implement supervised quality/harmfulness models or engineer `EpisodeView` workflows.
