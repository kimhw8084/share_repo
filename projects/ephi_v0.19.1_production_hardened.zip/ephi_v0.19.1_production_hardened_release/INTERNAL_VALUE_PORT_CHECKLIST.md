# Internal Value / ROI Port Checklist

The value subsystem is downstream of the qualified EPHI scientific stack. Do not begin by filling synthetic cost numbers into the reference model.

## Required governance inputs

- [ ] Identify the owner/approver for manufacturing cost/value definitions.
- [ ] Define whether official reporting uses one currency; if multiple currencies exist, provide an approved FX/version policy before aggregation.
- [ ] Define effective-dated product/stage/material value sources.
- [ ] Define rework, remeasurement, downtime, capacity, and engineering-hour accounting semantics if monetary conversion is desired.
- [ ] Define infrastructure-cost rates or decide to report CPU/GPU/bytes/storage only.
- [ ] Define who may validate realized benefits and which source references are mandatory.
- [ ] Define EPHI attribution review (`PRIMARY`, `CONTRIBUTORY`, `CONFIRMATORY`, `NONE`, `UNKNOWN`).

## Protected-material evidence

- [ ] Preserve material IDs, not only counts.
- [ ] Preserve original likely/committed suspect routing where available.
- [ ] Preserve reroute/hold/action timestamps and actor/system source.
- [ ] Do not count generic WIP as protected material.
- [ ] Verify related episodes reuse one `economic_event_key` / claim group.

## Cost-model port

- [ ] Replace `configs/value/synthetic_reference.yaml`; never modify it into a production model in place.
- [ ] Assign a new `cost_model_id` and immutable version.
- [ ] Store source/provenance and approval state.
- [ ] Configure effective-from/effective-to dates.
- [ ] Validate unit compatibility for every rate.
- [ ] Keep unapproved models `DRAFT` and out of official estimates.

## Realized-benefit reconciliation

- [ ] Require explicit validator identity and validation timestamp.
- [ ] Require source evidence (operations/finance/accounting/audit references).
- [ ] Do not convert estimated loss directly into validated benefit.
- [ ] Use supersession for revisions; never overwrite historical reported values.
- [ ] Ensure only the active revision enters official portfolio totals.
- [ ] Review contribution when legacy alarms, engineers, or other systems also drove containment.

## Operating cost / false-event cost

- [ ] Bind CPU/GPU/storage/Big-Data telemetry to the EPHI release/job where practical.
- [ ] Measure false-actionable-event engineering effort prospectively.
- [ ] Keep missed-opportunity exposure separate from realized benefit.
- [ ] Report raw resource metrics even if dollar rates are unavailable.

## Persistence / audit

- [ ] Map `ValueLedgerRepository` to an approved durable authoritative backend or use the versioned StateStore checkpoint contract as an interim implementation.
- [ ] Preserve append-only entries and `supersedes_entry_id` lineage.
- [ ] Preserve benefit claim groups and attribution records.
- [ ] Test restart/restore and compare active totals before/after restart.
- [ ] Retain ReleaseManifest / cost-model version with official reports.

## Launch gate

Official realized ROI reporting should remain disabled until the validation authority, cost model, attribution policy, and audit persistence above are approved. EPHI can still report physical exposure, protected material, lead time, engineering hours, and infrastructure usage before that gate.
