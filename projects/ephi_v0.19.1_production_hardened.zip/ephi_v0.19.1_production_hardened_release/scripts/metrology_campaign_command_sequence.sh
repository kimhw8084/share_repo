#!/usr/bin/env bash
set -euo pipefail

# EPHI v0.19.1 operator sequence. This script is a command template; company-specific
# config paths, identity, and approved backends must be supplied by the internal port.
RELEASE_MANIFEST="${RELEASE_MANIFEST:-RELEASE_MANIFEST.json}"
POLICY="${POLICY:-configs/launch/metrology_reference.yaml}"
FAMILY_ID="${FAMILY_ID:-METROLOGY_REFERENCE}"
CONFIG_BASE="${CONFIG_BASE:-configs/base.yaml}"
CONFIG_COMPANY="${CONFIG_COMPANY:-company_port/configs/company.yaml}"
CONFIG_FAMILY="${CONFIG_FAMILY:-configs/families/metrology.yaml}"
ACTOR="${ACTOR:?set ACTOR to the authenticated internal operator identity}"
CAMPAIGN_ROOT="${CAMPAIGN_ROOT:-./.ephi-campaign}"
mkdir -p "${CAMPAIGN_ROOT}"

COMMON_CONFIG=(--config "${CONFIG_BASE}" --config "${CONFIG_COMPANY}" --config "${CONFIG_FAMILY}")

# 1) Validate that the internal evidence adapter declares the complete idempotent v0.18 contract.
ephi launch adapter-validate \
  --module ephi_company.launch \
  "${COMMON_CONFIG[@]}" \
  --release-manifest "${RELEASE_MANIFEST}"

# 2) Execute/resume the offline qualification campaign. Re-run this exact command with
#    the same campaign-id after a transient failure; passed stages are not re-executed.
ephi launch campaign-run \
  --launch-module ephi_company.launch \
  --state-module ephi_company.state \
  "${COMMON_CONFIG[@]}" \
  --release-manifest "${RELEASE_MANIFEST}" \
  --policy "${POLICY}" \
  --family-id "${FAMILY_ID}" \
  --campaign-id "${FAMILY_ID}-OFFLINE-V180" \
  --current-state RESEARCH \
  --target-state OFFLINE_QUALIFIED \
  --actor "${ACTOR}" \
  --dossier-output "${CAMPAIGN_ROOT}/offline-dossier.json" \
  --workspace-output "${CAMPAIGN_ROOT}/offline-workspace.json"

# 3) Reconcile the completed campaign and publish the immutable qualification export.
ephi launch campaign-readiness \
  --state-module ephi_company.state \
  "${COMMON_CONFIG[@]}" \
  --policy "${POLICY}" \
  --family-id "${FAMILY_ID}" \
  --campaign-id "${FAMILY_ID}-OFFLINE-V180" \
  --current-state RESEARCH \
  --output "${CAMPAIGN_ROOT}/offline-readiness.json"

ephi launch campaign-export \
  --state-module ephi_company.state \
  "${COMMON_CONFIG[@]}" \
  --policy "${POLICY}" \
  --family-id "${FAMILY_ID}" \
  --campaign-id "${FAMILY_ID}-OFFLINE-V180" \
  --current-state RESEARCH \
  --publish \
  --output "${CAMPAIGN_ROOT}/offline-qualification-export.json"

# 4) Handoff gate evidence into the shared qualification control plane. This creates a
#    promotion package only; it deliberately does NOT approve the promotion.
ephi launch handoff \
  --services-module ephi_company.services \
  "${COMMON_CONFIG[@]}" \
  --dossier "${CAMPAIGN_ROOT}/offline-dossier.json" \
  --actor "${ACTOR}" \
  --command-prefix "${FAMILY_ID}-OFFLINE-V180" \
  --output "${CAMPAIGN_ROOT}/offline-handoff.json"

# 5) An EPHI_ADMIN approves the READY package through the authenticated qualification
#    control-plane endpoint: POST /v1/qualification/families/{family_id}/promotion/approve
#    Approval is intentionally separate from this evidence-execution script.

# 6) After OFFLINE_QUALIFIED is approved, execute/resume the DR-gated SHADOW campaign.
ephi launch campaign-run \
  --launch-module ephi_company.launch \
  --state-module ephi_company.state \
  "${COMMON_CONFIG[@]}" \
  --release-manifest "${RELEASE_MANIFEST}" \
  --policy "${POLICY}" \
  --family-id "${FAMILY_ID}" \
  --campaign-id "${FAMILY_ID}-SHADOW-V180" \
  --current-state OFFLINE_QUALIFIED \
  --target-state SHADOW \
  --actor "${ACTOR}" \
  --dossier-output "${CAMPAIGN_ROOT}/shadow-dossier.json" \
  --workspace-output "${CAMPAIGN_ROOT}/shadow-workspace.json"

# 7) Reconcile/publish the SHADOW qualification export before handoff.
ephi launch campaign-readiness \
  --state-module ephi_company.state \
  "${COMMON_CONFIG[@]}" \
  --policy "${POLICY}" \
  --family-id "${FAMILY_ID}" \
  --campaign-id "${FAMILY_ID}-SHADOW-V180" \
  --current-state OFFLINE_QUALIFIED \
  --output "${CAMPAIGN_ROOT}/shadow-readiness.json"

ephi launch campaign-export \
  --state-module ephi_company.state \
  "${COMMON_CONFIG[@]}" \
  --policy "${POLICY}" \
  --family-id "${FAMILY_ID}" \
  --campaign-id "${FAMILY_ID}-SHADOW-V180" \
  --current-state OFFLINE_QUALIFIED \
  --publish \
  --output "${CAMPAIGN_ROOT}/shadow-qualification-export.json"

# 8) Handoff the SHADOW dossier. Approval remains a separate authenticated admin action.
ephi launch handoff \
  --services-module ephi_company.services \
  "${COMMON_CONFIG[@]}" \
  --dossier "${CAMPAIGN_ROOT}/shadow-dossier.json" \
  --actor "${ACTOR}" \
  --command-prefix "${FAMILY_ID}-SHADOW-V180" \
  --output "${CAMPAIGN_ROOT}/shadow-handoff.json"
