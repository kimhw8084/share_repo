# Scripts

Reserved for narrow developer/CI helpers. Reproducible product operations belong in the `ephi` CLI.

`metrology_campaign_command_sequence.sh` is the audited v0.17 operator command template for the internal metrology qualification campaign; product state transitions still occur through the `ephi` CLI/API.
