# EPHI Internal Historical Qualification Checklist

## 1. Data truth before benchmark construction

- Run `ephi data mapping-validate`.
- Run the semantic Data Reality Audit.
- Verify `event_time` and `available_at` semantics for every participating source.
- Verify corrections/backfills can be discovered.
- Manually reconcile representative execution/material/metrology/maintenance joins.
- Record unavailable or partial channels explicitly.

## 2. Curate the Golden Corpus

Include both positive and negative manufacturing histories:

- confirmed local equipment excursions;
- healthy long-duration operation;
- benign offsets/novelty;
- common-mode process shifts;
- metrology measurement-system drift;
- real process shifts observed by metrology;
- PM/calibration expected transitions;
- post-maintenance failures;
- data/schema/unit incidents;
- false legacy alarms;
- ambiguous/unresolved cases;
- upstream-confounded examples when available.

Do not select only dramatic failures.

## 3. Label every case conservatively

For each `BenchmarkCase`, record where known:

- `label_confidence`;
- expected local/fleet actionability;
- expected asset/process-unit scope;
- broad expected hypothesis;
- `onset_event_time` plus `onset_low`/`onset_high`;
- external/human/legacy detection time;
- quality impact;
- root-cause confidence;
- action/resolution metadata;
- explicit evaluation exclusions.

Do not manufacture precision for uncertain historical records.

## 4. Implement the internal case loader

Implement `HistoricalBenchmarkLoader.load(case)` using approved internal data access.

It must return canonical EPHI observations with valid:

```text
event_time
available_at
asset/process-unit identity
context
feature/measurement semantics
```

The generic qualification framework should not receive proprietary table names.

## 5. Freeze benchmark identity

- Save the corpus definition.
- Record the corpus SHA-256.
- Separate the fixed Golden Corpus from a rolling recent corpus.
- Never silently edit a corpus used for a prior qualification claim.

## 6. Run strict historical replay

Measure at minimum:

- case pass/fail;
- episode recall;
- false actionable episodes / asset-time;
- detection delay from onset;
- lead time versus external detection when known;
- actionable asset scope;
- leading hypothesis behavior;
- replay rebuild count caused by late facts;
- runtime and source read cost.

Inspect results separately by label confidence and family.

## 7. Stress the population semantics

Run:

- reference contamination;
- gradual baseline creep;
- peer poisoning;
- peer removal sensitivity;
- common-mode synchronization;
- sparse-context fallback;
- cold-start periods;
- post-PM quarantine scenarios.

## 8. Run measurement-system separation certification

For metrology, explicitly include cases covering:

- production shift with stable reference material;
- reference + cross-tool shift;
- one-head shift;
- fleet-wide production shift;
- remeasure/repeatability degradation;
- spatial head-specific degradation;
- measurement recipe/regime change.

## 9. Run method bake-offs

Every challenger must use the identical:

- corpus;
- source availability timeline;
- feature version;
- reference/peer policy unless that is the explicit experimental variable;
- evaluation metric definition.

A challenger is promoted only for meaningful episode-level manufacturing benefit at acceptable compute/complexity cost.

## 10. Define internal release gates

Create a versioned `QualificationGatePolicy` based on actual pilot needs.

Do **not** copy synthetic regression thresholds as manufacturing policy.

At minimum define:

- minimum episode recall;
- false actionable episode budget;
- required case pass rate;
- family/process-specific exceptions if justified.

## 11. Build release evidence

For every candidate production release retain:

- ReleaseManifest;
- Data Reality report;
- corpus definition/hash;
- qualification report;
- gate decision;
- method bake-off;
- resource benchmark;
- known limitations;
- reviewer/approval record.

## 12. Proceed to shadow, not closed loop

Only after offline qualification:

- run live shadow;
- capture false and missed events;
- obtain engineer usefulness feedback;
- verify runtime/query load;
- re-run qualification after material policy/model changes.

Initial deployment remains advisory.

## v0.11 certification/promotion gate

Offline scientific qualification is necessary but no longer sufficient for advisory promotion. A family/capability must also use the v0.11 certification state machine and immutable family manifest. `SHADOW_QUALIFIED` / `ADVISORY_PILOT` require real engineer-shadow evidence, operational freshness/SLO qualification, tested rollback, and scoped kill-switch behavior. The shipped `FAMILY_QUALIFICATION_TEMPLATE_V110.json` is `RESEARCH` only and cannot be used as production evidence.
