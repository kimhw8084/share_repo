# Internal Quality / Harmfulness Qualification Checklist

This checklist is required before any v0.6 quality model or association channel is promoted beyond research/shadow status.

## 1. Target truth

- [ ] Target ID and version are defined.
- [ ] Physical/categorical semantics are documented.
- [ ] Outcome stage is correct (inline, inspection, electrical, yield/final, measurement-system).
- [ ] Harmful direction is explicitly defined.
- [ ] Minimum practical effect is justified by process/product engineering.
- [ ] Product-specific susceptibility is represented rather than hidden in one fab-wide threshold.

## 2. Knowledge time

- [ ] `event_time` exists for the quality observation.
- [ ] `available_at` reflects when EPHI could actually access the result.
- [ ] Prediction cutoff is defined for the use case.
- [ ] Replay proves the outcome is unavailable at prediction time.
- [ ] Late/corrected quality results are detectable.

## 3. Outcome maturity and interventions

- [ ] Mature versus pending outcomes are distinguishable.
- [ ] Held material is not labeled healthy.
- [ ] Material scrapped before outcome is not labeled healthy.
- [ ] Reroute/rework states are represented.
- [ ] Lost-to-follow-up is represented.
- [ ] Severe episodes with intervention censoring are quantified.

## 4. Sampling / selection

- [ ] Scheduled versus ad-hoc measurements can be distinguished where possible.
- [ ] Remeasure/engineering/hold-triggered samples are identifiable.
- [ ] Sampling-bias diagnostic is run on the eligible material population.
- [ ] Measurement selection dependence on EPHI health state is reported.
- [ ] IPW/weighting is not used unless overlap and assumptions are explicitly reviewed.

## 5. Dataset construction

- [ ] Material/execution join is verified manually on golden examples.
- [ ] No same-lot leakage across train/test when repeated wafers are present.
- [ ] Equipment-state feature availability is <= prediction cutoff.
- [ ] Target availability is > prediction cutoff.
- [ ] Dataset snapshot and knowledge cutoff are immutable/versioned.

## 6. M0/M1 admission

- [ ] M0 context-only model exists.
- [ ] M1 uses the same rows/split as M0.
- [ ] M1 improvement is measured on chronological test data.
- [ ] Improvement is operationally meaningful, not only statistically detectable.
- [ ] Benign equipment novelty does not spuriously create target lift.

## 7. Generalization

- [ ] Chronological holdout passes.
- [ ] Tool-held-out evaluation performed where fleet size permits.
- [ ] Product-held-out evaluation performed where feasible.
- [ ] Recipe/process-regime support is reported.
- [ ] OOD/applicability confidence falls for unsupported contexts.

## 8. Calibration / uncertainty

Binary:
- [ ] Brier score reported.
- [ ] Log loss reported.
- [ ] PR behavior reported under actual prevalence.
- [ ] Calibration curve/ECE reported.
- [ ] Calibration fitted before final test period.

Continuous:
- [ ] RMSE/MAE reported.
- [ ] Residual behavior by product/tool/time reviewed.
- [ ] Prediction interval coverage evaluated on final chronological test data.

## 9. Measurement-system separation

- [ ] Measurement integrity is available or explicitly unavailable.
- [ ] Reference-wafer/reference-material evidence reviewed.
- [ ] Cross-tool/head matching reviewed.
- [ ] Repeatability/reproducibility reviewed.
- [ ] Low measurement integrity caps physical-process quality attribution.
- [ ] Measurement-system targets use measurement-system harmfulness semantics, not physical-wafer-damage semantics.

## 10. Exposed / control evidence

- [ ] Exposure onset is temporally valid.
- [ ] Controls share appropriate product/tech/recipe/calendar context.
- [ ] Route/genealogy balance is evaluated.
- [ ] Same-lot/split-lot controls are used when valid.
- [ ] Control robustness is reported across alternative control definitions.
- [ ] No causal probability is claimed from observational matching alone.

## 11. Model artifact / release

- [ ] Target version is embedded in artifact metadata.
- [ ] Feature contract matches model artifact.
- [ ] Model content hash verifies.
- [ ] Calibration artifact/method is identified.
- [ ] Release manifest includes dataset/model/target qualification artifact.
- [ ] Newly retrained model remains challenger until replay + shadow qualification.

## 12. Production gate

- [ ] Historical harmful cases demonstrate useful M1 lift.
- [ ] Historical benign cases reject spurious equipment-state lift.
- [ ] Calibration/uncertainty gate passes.
- [ ] Sampling/censoring limitations are acceptable and visible.
- [ ] Runtime budget passes.
- [ ] Engineer review confirms quality interpretation is useful.
- [ ] Initial deployment is shadow/advisory only.
