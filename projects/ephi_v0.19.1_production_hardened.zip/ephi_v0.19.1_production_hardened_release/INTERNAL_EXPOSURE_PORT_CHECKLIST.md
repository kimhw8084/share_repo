# Internal Exposure / WIP Port Checklist — v0.8.0

## 1. Historical material exposure

Map exact execution-to-material membership with:

- stable `material_id`;
- stable `execution_id`;
- exact asset/process-unit identity;
- operation;
- manufacturing `event_time`;
- optional execution end time;
- route/rework context;
- knowledge availability/revision semantics upstream in the canonical layer.

Validate repeated/rework passes manually. A material may have multiple suspect executions, but material-level exposure counts must not be inflated.

## 2. Onset semantics

Feed the operational subsystem the detector/episode onset interval:

- `onset_low`;
- `onset_best`;
- `onset_high`;
- onset confidence.

Do not substitute notification/open time for physical onset.

## 3. WIP mapping

Profile and map, where available:

- current route sequence/position;
- next affected operation;
- queued/likely resource;
- committed resource;
- eligible resource set or qualification group;
- estimated arrival time;
- hold state;
- product/recipe/technology context.

If only eligibility is available, EPHI must report possible exposure, not likely exposure.

## 4. Asset qualification / alternatives

Implement the logical `asset_qualification` mapping or equivalent repository behavior:

- asset;
- operation/capability;
- product/recipe/technology restrictions where applicable;
- effective dates;
- qualification state;
- availability/capacity state if trustworthy.

Join the candidate resource with current EPHI health state. A qualified but unhealthy asset cannot be presented as a preferred healthy alternative.

## 5. ExposureSourceRepository

Implement the three semantic calls:

- `historical_exposures(...)`;
- `current_wip(...)`;
- `alternative_assets(...)`.

Use Big Data predicate/projection pushdown. Do not load whole-fab WIP or full process history for every active episode.

## 6. WIP freshness

Measure and expose:

- WIP source `as_of`;
- refresh lag;
- routing-state completeness;
- ETA coverage;
- stale-material rate.

WIP freshness is independent of the technical assessment clock.

## 7. Routing validation

During historical/shadow validation compare EPHI route states with what subsequently occurred:

- possible -> actual suspect routing rate;
- likely -> actual suspect routing rate;
- committed -> actual execution consistency;
- qualified alternative -> actual feasible reroute/dispatch evidence where available.

Do not invent probabilities until calibration data supports them.

## 8. Priority policy qualification

The portable thresholds in `configs/priority/reference.yaml` are reference values only. Calibrate from pilot reality:

- manufacturing action window;
- WIP volumes;
- acceptable confidence floor;
- engineer expectations for P1/P2/P3/P4;
- containment vs disposition vs RCA workflow.

Validate priority ranking with engineers under historical replay/shadow mode.

## 9. Safety / governance

v0.8 is advisory only. It must not automatically:

- hold tools;
- reroute wafers;
- change dispatch;
- disposition material;
- change recipes.

Any future closed-loop action requires a separate qualification/governance program.

## 10. Required acceptance evidence

Before claiming internal exposure/priority capability, retain:

- Data Reality Audit for `wip` and `asset_qualification`;
- manually verified exposed-material cases;
- onset sensitivity checks;
- actual-vs-predicted routing study;
- alternative-resource health/qualification review;
- WIP refresh latency benchmark;
- priority replay with engineer review;
- zero evidence that WIP/priority changes technical health conclusions.
