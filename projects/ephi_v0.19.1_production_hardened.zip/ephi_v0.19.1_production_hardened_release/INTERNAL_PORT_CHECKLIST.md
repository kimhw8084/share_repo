# EPHI Internal Port Checklist

## 1. Mapping only — no analytical rewrites

- [ ] Implement the approved internal physical `BigDataClient`.
- [ ] Map logical dataset names in `configs/company.yaml`.
- [ ] Map required logical columns before optional columns.
- [ ] Keep credentials outside YAML/source control.
- [ ] Run `ephi data mapping-validate --config ...`.

## 2. Data Reality Audit

- [ ] Profile row/history coverage.
- [ ] Profile event-time and `available_at` coverage.
- [ ] Profile nulls, key distinctness and duplicate-key rate.
- [ ] Measure source availability-delay quantiles.
- [ ] Measure execution↔FDC join coverage/ambiguity.
- [ ] Measure execution↔trace join coverage/ambiguity where traces exist.
- [ ] Add metrology/material/quality/maintenance/genealogy joins as internal contracts are mapped.
- [ ] Do not declare a capability `QUALIFIED` from dataset presence alone.

## 3. Metrology physics

- [ ] Obtain characteristic resolution or measurement uncertainty where available.
- [ ] Compare configured resolution against observed healthy quantization/dispersion.
- [ ] Review inferred-only scale policies as `PROVISIONAL`.
- [ ] Verify reference-material identity and calibration epochs.
- [ ] Verify cross-head/tool matching populations.
- [ ] Verify remeasure semantics and attempt ordering.
- [ ] Verify wafer/site coordinate normalization and sampling plan.

## 4. Columnar path

- [ ] Materialize stable `state_key_id` once per feature/execution context.
- [ ] Materialize bounded peer-group identifiers.
- [ ] Keep source filtering/projection in Big Data.
- [ ] Transfer only required Arrow columns.
- [ ] Benchmark batch sizes by bytes as well as rows.
- [ ] Confirm no Pydantic/domain-object construction occurs per source-scale row.

## 5. Qualification before shadow

- [ ] Canonical golden samples verified manually.
- [ ] No-lookahead canaries pass.
- [ ] Reference contamination/slow-creep tests pass.
- [ ] Peer poisoning/common-mode tests pass.
- [ ] Process-vs-measurement-system metrology cases pass.
- [ ] Healthy long-run false-event budget passes.
- [ ] Worker restart/late-data behavior passes internally.
- [ ] Big Data scan/resource budget passes.
- [ ] Release manifest frozen before shadow.

## v0.10 value / ROI port

Before official monetary or ROI reporting, complete `INTERNAL_VALUE_PORT_CHECKLIST.md`. The synthetic value rates shipped with the portable reference implementation are qualification fixtures only and must not be treated as company accounting values.

## v0.11 shadow/runtime integration

After the data/scientific port is functional, complete `INTERNAL_SHADOW_OPERATIONS_CHECKLIST.md` before advisory launch. In particular:

- provide `ephi_company.app.create_app(config)` for company-backed API services/identity;
- provide `ephi_company.runtime.build_queue(role)` and `build_handlers(role)` for approved shared worker execution;
- replace provisional Kubernetes sizing using measured internal load;
- establish real freshness/SLO policy per family;
- persist scoped kill switches and family certification history in approved durable state;
- run engineer shadow review and rollback/alert-storm drills before promotion.
