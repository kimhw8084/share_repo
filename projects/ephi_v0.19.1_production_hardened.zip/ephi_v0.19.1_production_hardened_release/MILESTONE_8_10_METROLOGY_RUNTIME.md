# Milestones 8–10 — Runtime Hardening + Metrology Flagship

EPHI v0.3.0 extends the v0.2 behavioral vertical slice in two directions at once:

1. **runtime hardening** of the already-qualified scalar/reference/peer logic; and
2. the first **metrology-family intelligence plugin** focused on separating measurement-system drift from real production/process movement.

The release remains a portable reference implementation. Synthetic thresholds and scale floors in this milestone are qualification defaults only; internal production values must be derived from the Data Reality Audit, measurement uncertainty, characteristic resolution, and historical replay.

## 1. Runtime hardening

### Materialized reference state

`ReferenceManager.materialized_state()` emits compact `MaterializedReferenceState` records containing adaptive and anchor location/scale, adequacy, and confidence. `ReferenceStateIndex` provides bounded lookup without rescanning historical observations.

### NumPy columnar scalar kernel

`ephi.detectors.columnar.score_scalar_arrays()` scores arrays against `ReferenceStateBatch` using NumPy and preserves the same core semantics as the object/reference implementation:

- self residual;
- frozen-anchor residual;
- physical change;
- reference adequacy/confidence; and
- unit-scale discontinuity detection.

A 1,000,000-row stateless kernel benchmark in the generation environment ran at approximately **6.64 million rows/second**. This is a microbenchmark of the scalar numerical kernel, not end-to-end Big Data throughput.

An optional Arrow bridge exists but is intentionally imported lazily. The sandbox used to build this release does not contain `pyarrow`, so Arrow/Polars/DuckDB source-scale integration remains an internal/local-environment qualification item.

### Fleet/common-mode parent episodes

Local DecisionEvents remain suppressed during qualified common-mode movement, but the phenomenon is no longer lost. `FleetEpisodeService` creates one parent analytical episode when enough compatible assets move together and manages recovery/resolution independently of local episodes.

### Checkpoint evolution

Behavioral checkpoint schema is now `behavioral_pipeline_state_v2` and includes fleet episode state. Restoration remains backward-compatible with v1 payloads.

## 2. Correctness defect found during implementation

A cross-asset reference-admission bug was found and fixed while hardening the behavioral pipeline: the admission loop could reuse the last group member's `anchor_z` when deciding admission for other assets in the same concurrent group.

The corrected path uses each observation's own anchor residual. `tests/unit/test_behavioral_admission_regression.py` permanently guards this failure mode.

This was a useful qualification result: scenario-level tests alone were not sufficient to expose all cross-asset state contamination paths.

## 3. Metrology canonical intelligence

The first family plugin adds:

- site-level `MetrologyObservation`;
- per-measurement robust summaries;
- compact spatial fingerprints;
- reference-material/reference-wafer behavior;
- cross-tool/head matching;
- production common-mode behavior;
- remeasure/repeatability behavior;
- metrology-specific sequential state; and
- metrology-specific EvidenceItems and hypothesis fusion.

The primary hypotheses qualified in this slice are:

- `METROLOGY_SYSTEM_SHIFT`; and
- `COMMON_MODE_PROCESS_CHANGE`.

A production measurement shift by itself is **not** sufficient to declare metrology-system failure.

## 4. Measurement-system evidence families

### Reference-material bias

Reference measurements are scored against each head's controlled adaptive and frozen-anchor history.

### Cross-tool matching

The same measurement characteristic is compared across compatible heads. With a three-head cohort, a small-cohort robust consensus is used to avoid the pathological leave-one-out case where one bad peer can pull the midpoint of the two remaining peers.

### Repeatability / remeasure

A crucial implementation correction was made here: repeatability degradation is treated primarily as a **recent distribution/variance shift**, not as isolated point anomalies. A rolling recent remeasure-error distribution is compared with the frozen healthy repeatability anchor.

Peer-relative repeatability remains useful for localization/explanation, but a single large remeasure residual does not create an actionable episode.

### Spatial stability

The compact baseline fingerprint currently includes:

- center-edge contrast;
- radial slope; and
- x/y directional slopes.

Spatial evidence requires both self-history departure and compatible-peer divergence with persistence. Site coverage contributes to spatial confidence.

## 5. Scientific corrections required to reach low false-event burden

The qualification work surfaced several nontrivial failure modes.

### A. Sparse channels need their own persistence clock

Reference-wafer, remeasure, and spatial observations do not occur at every production measurement. Their persistence therefore cannot be defined by consecutive production wafers. Sparse channels now maintain their own EWMA/persistence state.

### B. Small peer cohorts require robust single-outlier semantics

With exactly three heads, leave-one-out comparison leaves two peers. If one of those peers is faulty, the two-peer midpoint can make the healthy target look abnormal. For cohorts of three or fewer, EPHI now uses the all-member median as the robust single-outlier consensus while still reporting target-excluded peer eligibility separately.

### C. Statistical scale must respect practical measurement resolution

A nearly zero historical MAD can turn a tiny ordinary residual into an enormous z-score. Metrology reference managers therefore use feature-specific robust-scale floors.

The current synthetic/reference defaults are approximately 0.03–0.04 in synthetic measurement units. **These are not fab production thresholds.** Internal values must be tied to actual characteristic resolution/uncertainty and validated healthy history.

### D. Confidence floor precedes escalation

Low-maturity evidence may be statistically extreme but cannot open an `INVESTIGATE` episode until the measurement-system evidence reaches the configured confidence floor.

### E. Correlated evidence cannot double-count

On reference material, reference-wafer absolute bias and cross-tool residual may arise from the same measurement. They therefore share the same evidence dependency group and cannot masquerade as two independent confirmations.

### F. Extreme reference fast path still requires localization

A highly abnormal reference-standard measurement can escalate rapidly only when cross-head matching also shows that the same head diverges and temporal confirmation is present. A single reference-material excursion alone does not become a local metrology-system episode.

## 6. Metrology checkpoint/restart

`ephi.metrology.checkpoint` persists/restores:

- reference-material manager;
- production manager;
- cross-tool matching manager;
- spatial manager;
- repeatability manager;
- sparse sequential state;
- rolling repeatability windows;
- local episode state; and
- fleet episode state.

Integration qualification confirms restart equivalence for subsequent metrology assessments and episode state.

## 7. Synthetic metrology scenarios

`ephi.synthetic.metrology` supplies deterministic three-head scenarios:

- `healthy`;
- `measurement-head-drift`;
- `process-shift`;
- `remeasure-instability`; and
- `spatial-head-drift`.

They include production wafers, periodic reference material, repeated measurements, site coordinates, and a shared manufacturing clock across heads.

Example:

```bash
PYTHONPATH=src python -m ephi.cli.main replay metrology \
  --scenario process-shift \
  --measurements-per-head 700 \
  --seed 23
```

Bounded multi-seed qualification can be reproduced with:

```bash
PYTHONPATH=src python benchmarks/metrology_flagship.py \
  --scenario healthy \
  --seed-start 100 \
  --seeds 5 \
  --measurements-per-head 900
```

## 8. Qualification outcome

The release-level bounded stress batches recorded in `METROLOGY_BENCHMARK.json` produced:

- healthy: **10/10 seeds, zero actionable local events**;
- real production/process shift: **10/10 seeds, zero local actionable events**, with common-mode/fleet evidence in the tail;
- measurement-head drift: sampled 5/5 seeds localized all actionable assessments to `HEAD_A`;
- spatial-head drift: sampled 5/5 seeds localized all actionable assessments to `HEAD_A`;
- repeatability instability: sampled 5/5 seeds localized all actionable assessments to `HEAD_A`.

These results validate the synthetic qualification cases only. They are **not** evidence of fab-wide recall/false-event rates and cannot replace the internal Data Reality Audit, historical Golden Corpus, or live shadow qualification.

## 9. Current boundaries

This release still does **not** claim:

- production-scale Arrow/Polars end-to-end throughput;
- qualification against company Big Data geometry;
- actual metrology gauge R&R capability;
- calibrated product-quality harmfulness;
- automated RCA; or
- closed-loop manufacturing control.

The next production-critical step is to port the same semantics to internal data through the adapter layer, execute the Data Reality Audit, bind physical scale floors and context policies to real metrology characteristics, and run shadow/historical replay before any threshold is treated as production-qualified.
