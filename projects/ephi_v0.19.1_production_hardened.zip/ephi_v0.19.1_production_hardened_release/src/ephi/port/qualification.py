from __future__ import annotations

from collections import Counter
from pathlib import Path
from tempfile import TemporaryDirectory

from pydantic import BaseModel, ConfigDict

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.port import PortGateEvidence, PortRunIdentity, PortStage, PortStageState
from ephi.port.orchestrator import PortBootstrapOrchestrator, PortIdentityMismatchError
from ephi.version import __version__


class PortKitQualificationReport(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    passed: bool
    ordered_bootstrap: bool
    downstream_blocking: bool
    resume_idempotent: bool
    identity_mismatch_blocked: bool
    scaffold_complete: bool
    deployment_no_sqlite: bool
    fail_closed_hooks_present: bool
    recovery_snapshot_hook_present: bool
    recovery_operator_surface_present: bool
    explicit_capability_target: bool
    config_overlay_all_deployments: bool
    bootstrap_job_present: bool
    auth_fail_closed: bool
    notification_gate_enforced: bool
    launch_executor_present: bool
    launch_adapter_idempotency_contract_present: bool
    launch_source_lineage_contract_present: bool
    campaign_operator_sequence_present: bool
    campaign_observability_service_present: bool
    campaign_observability_operator_sequence_present: bool
    deployment_version_aligned: bool


class ReferencePortRuntime:
    def __init__(self, *, fail_stage: PortStage | None = None) -> None:
        self.fail_stage = fail_stage
        self.calls: Counter[str] = Counter()

    def _result(self, stage: PortStage) -> PortGateEvidence:
        self.calls[stage.value] += 1
        if stage == self.fail_stage:
            return PortGateEvidence(
                passed=False,
                summary=f"reference failure at {stage.value}",
                blockers=(f"blocked by {stage.value}",),
            )
        return PortGateEvidence(
            passed=True,
            summary=f"reference {stage.value} passed",
            metrics={"calls": self.calls[stage.value]},
        )

    def validate_mapping(self) -> PortGateEvidence:
        return self._result(PortStage.MAPPING_VALIDATION)

    def run_data_reality(self) -> PortGateEvidence:
        return self._result(PortStage.DATA_REALITY)

    def bootstrap_state(self) -> PortGateEvidence:
        return self._result(PortStage.STATE_BOOTSTRAP)

    def run_golden_replay(self) -> PortGateEvidence:
        return self._result(PortStage.GOLDEN_REPLAY)

    def run_operations_qualification(self) -> PortGateEvidence:
        return self._result(PortStage.OPERATIONS_QUALIFICATION)

    def assess_shadow_readiness(self) -> PortGateEvidence:
        return self._result(PortStage.SHADOW_READINESS)


def _identity(config_hash: str = "cfg") -> PortRunIdentity:
    return PortRunIdentity(
        release_id=f"ephi-{__version__}-reference",
        package_version=__version__,
        config_hash=config_hash,
        family_id="METROLOGY_REFERENCE",
        environment="company-shadow",
    )


def run_port_kit_qualification(root: str | Path = ".") -> PortKitQualificationReport:
    root = Path(root)
    with TemporaryDirectory() as tmp:
        state_path = Path(tmp) / "port.sqlite3"
        store = SqliteStateStore(state_path)
        runtime = ReferencePortRuntime()
        orch = PortBootstrapOrchestrator(runtime=runtime, identity=_identity(), state_store=store)
        report = orch.run()
        ordered_bootstrap = report.shadow_ready and all(
            report.stage(stage).state == PortStageState.PASSED
            for stage in PortBootstrapOrchestrator.stage_order()
        )
        calls_after_first = dict(runtime.calls)
        restored = PortBootstrapOrchestrator(runtime=runtime, identity=_identity(), state_store=store)
        report2 = restored.run(resume=True)
        resume_idempotent = report2.shadow_ready and dict(runtime.calls) == calls_after_first

        mismatch_store = SqliteStateStore(state_path)
        try:
            PortBootstrapOrchestrator(runtime=runtime, identity=_identity("different"), state_store=mismatch_store)
            identity_mismatch_blocked = False
        except PortIdentityMismatchError:
            identity_mismatch_blocked = True

    failing = ReferencePortRuntime(fail_stage=PortStage.DATA_REALITY)
    failed_report = PortBootstrapOrchestrator(runtime=failing, identity=_identity("fail")).run()
    downstream = [
        failed_report.stage(stage).state
        for stage in PortBootstrapOrchestrator.stage_order()[2:]
    ]
    downstream_blocking = (
        failed_report.stage(PortStage.DATA_REALITY).state == PortStageState.FAILED
        and all(state == PortStageState.BLOCKED for state in downstream)
        and not failed_report.shadow_ready
    )

    required = (
        "company_port/src/ephi_company/app.py",
        "company_port/src/ephi_company/big_data.py",
        "company_port/src/ephi_company/state.py",
        "company_port/src/ephi_company/runtime.py",
        "company_port/src/ephi_company/bootstrap.py",
        "company_port/src/ephi_company/bootstrap_tasks.py",
        "company_port/src/ephi_company/qualification.py",
        "company_port/src/ephi_company/auth.py",
        "company_port/src/ephi_company/notifications.py",
        "company_port/src/ephi_company/recovery.py",
        "company_port/src/ephi_company/launch.py",
        "company_port/deploy/overlays/shadow/kustomization.yaml",
    )
    scaffold_complete = all((root / item).exists() for item in required)

    deployment_paths = [
        root / "configs/deployment/shadow-reference.yaml",
        root / "company_port/deploy/base/ephi-shadow.yaml",
        root / "company_port/deploy/overlays/shadow/bootstrap-job.yaml",
    ]
    deployment_text = "\n".join(path.read_text(encoding="utf-8") for path in deployment_paths if path.exists()).lower()
    deployment_no_sqlite = "sqlite" not in deployment_text

    hook_files = (
        root / "company_port/src/ephi_company/state.py",
        root / "company_port/src/ephi_company/auth.py",
        root / "company_port/src/ephi_company/services.py",
    )
    fail_closed_hooks_present = all(
        "CompanyPortNotConfiguredError" in path.read_text(encoding="utf-8") for path in hook_files
    )
    state_text = (root / "company_port/src/ephi_company/state.py").read_text(encoding="utf-8")
    bootstrap_module_text = (root / "company_port/src/ephi_company/bootstrap.py").read_text(encoding="utf-8")
    recovery_snapshot_hook_present = (
        "build_recovery_state_store" in state_text
        and "SnapshotStateStore" in state_text
        and "build_recovery_store" in bootstrap_module_text
    )
    recovery_text = (root / "company_port/src/ephi_company/recovery.py").read_text(encoding="utf-8")
    recovery_operator_surface_present = (
        "create_state_backup" in recovery_text
        and "restore_state_backup" in recovery_text
        and "confirm_clean_target" in recovery_text
        and "require_empty=True" in recovery_text
    )
    company_config_text = (root / "company_port/configs/company.yaml.example").read_text(encoding="utf-8")
    explicit_capability_target = "required_capabilities:" in company_config_text and "METROLOGY" in company_config_text
    overlay_text = (root / "company_port/deploy/overlays/shadow/kustomization.yaml").read_text(encoding="utf-8")
    bootstrap_text = (root / "company_port/deploy/overlays/shadow/bootstrap-job.yaml").read_text(encoding="utf-8")
    config_overlay_all_deployments = "kind: Deployment" in overlay_text and "EPHI_CONFIG_PATHS" in overlay_text
    bootstrap_job_present = "ephi_company.bootstrap" in bootstrap_text and "--release-manifest" in bootstrap_text
    auth_text = (root / "company_port/src/ephi_company/app.py").read_text(encoding="utf-8")
    auth_fail_closed = "status_code=401" in auth_text and "status_code=403" in auth_text
    notification_text = (root / "company_port/src/ephi_company/notifications.py").read_text(encoding="utf-8")
    notification_gate_enforced = "NotificationDeliveryGate" in notification_text and "self.gate.allowed" in notification_text
    launch_text = (root / "company_port/src/ephi_company/launch.py").read_text(encoding="utf-8")
    launch_executor_present = (
        "build_launch_evidence_executor" in launch_text
        and "INTERNAL_MEASURED" in launch_text
        and "CompanyPortNotConfiguredError" in launch_text
    )
    launch_adapter_idempotency_contract_present = (
        "describe_adapter" in launch_text
        and "idempotent" in launch_text.lower()
        and "LaunchEvidenceAdapterDescriptor" in launch_text
    )
    launch_source_lineage_contract_present = (
        "resolve_source_snapshot" in launch_text
        and "SourceSnapshotLineage" in launch_text
    )
    campaign_script = root / "scripts/metrology_campaign_command_sequence.sh"
    campaign_script_text = campaign_script.read_text(encoding="utf-8") if campaign_script.exists() else ""
    campaign_operator_sequence_present = (
        campaign_script.exists()
        and all(token in campaign_script_text for token in (
            "launch adapter-validate", "launch campaign-run", "launch handoff"
        ))
    )
    services_text = (root / "company_port/src/ephi_company/services.py").read_text(encoding="utf-8")
    campaign_observability_service_present = (
        "CampaignObservabilityService" in services_text
        and "campaign_observability" in services_text
        and "campaign_observability_service=services.campaign_observability" in auth_text
    )
    campaign_observability_operator_sequence_present = all(
        token in campaign_script_text for token in ("launch campaign-readiness", "launch campaign-export", "--publish")
    )
    deployment_version_aligned = all(
        f":{__version__}" in path.read_text(encoding="utf-8")
        for path in deployment_paths if path.exists()
    )

    passed = all(
        (
            ordered_bootstrap,
            downstream_blocking,
            resume_idempotent,
            identity_mismatch_blocked,
            scaffold_complete,
            deployment_no_sqlite,
            fail_closed_hooks_present,
            recovery_snapshot_hook_present,
            recovery_operator_surface_present,
            explicit_capability_target,
            config_overlay_all_deployments,
            bootstrap_job_present,
            auth_fail_closed,
            notification_gate_enforced,
            launch_executor_present,
            launch_adapter_idempotency_contract_present,
            launch_source_lineage_contract_present,
            campaign_operator_sequence_present,
            campaign_observability_service_present,
            campaign_observability_operator_sequence_present,
            deployment_version_aligned,
        )
    )
    return PortKitQualificationReport(
        passed=passed,
        ordered_bootstrap=ordered_bootstrap,
        downstream_blocking=downstream_blocking,
        resume_idempotent=resume_idempotent,
        identity_mismatch_blocked=identity_mismatch_blocked,
        scaffold_complete=scaffold_complete,
        deployment_no_sqlite=deployment_no_sqlite,
        fail_closed_hooks_present=fail_closed_hooks_present,
        recovery_snapshot_hook_present=recovery_snapshot_hook_present,
        recovery_operator_surface_present=recovery_operator_surface_present,
        explicit_capability_target=explicit_capability_target,
        config_overlay_all_deployments=config_overlay_all_deployments,
        bootstrap_job_present=bootstrap_job_present,
        auth_fail_closed=auth_fail_closed,
        notification_gate_enforced=notification_gate_enforced,
        launch_executor_present=launch_executor_present,
        launch_adapter_idempotency_contract_present=launch_adapter_idempotency_contract_present,
        launch_source_lineage_contract_present=launch_source_lineage_contract_present,
        campaign_operator_sequence_present=campaign_operator_sequence_present,
        campaign_observability_service_present=campaign_observability_service_present,
        campaign_observability_operator_sequence_present=campaign_observability_operator_sequence_present,
        deployment_version_aligned=deployment_version_aligned,
    )
