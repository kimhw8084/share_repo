from ephi.autopilot.sqlite_runtime import SqliteSqlExecutor


def build_approved_sql_executor(config):
    return SqliteSqlExecutor(":memory:")
