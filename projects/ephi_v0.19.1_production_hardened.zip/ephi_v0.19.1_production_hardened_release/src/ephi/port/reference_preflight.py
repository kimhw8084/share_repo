from __future__ import annotations

from tempfile import TemporaryDirectory
from pathlib import Path

from ephi.autopilot.dialect import qualify_sql_executor
from ephi.autopilot.sqlite_runtime import SqliteSqlExecutor
from ephi.config import EphiConfig
from ephi.domain.operations import DeploymentPlan, RuntimeRole
from ephi.port.production_preflight import ProductionPreflightCheck, ProductionPreflightReport
from ephi.registry.releases import ReleaseManifest


def run_production_preflight(
    config: EphiConfig,
    deployment_plan: DeploymentPlan,
    release_manifest: ReleaseManifest,
) -> ProductionPreflightReport:
    checks: list[ProductionPreflightCheck] = []
    with TemporaryDirectory() as td:
        db = Path(td) / "probe.sqlite3"
        db.touch()
        dialect = qualify_sql_executor(SqliteSqlExecutor(db))
        checks.append(ProductionPreflightCheck("sql_dialect_capabilities", dialect.passed, "reference SQLite parameterized SQL"))
    names = (
        "schema_inspector", "sql_executor", "big_data_client", "state_store",
        "recovery_state_store", "materialization_store", "artifact_store", "audit_backend",
        "identity_resolver", "services", "notification_publisher", "bootstrap_executor",
        "launch_evidence_executor", "port_runtime", "port_mapping_runtime_preflight", "port_state_store", "port_recovery_store",
    )
    checks.extend(ProductionPreflightCheck(name, True, "reference contract implementation") for name in names)
    for profile in deployment_plan.roles:
        if profile.replicas <= 0 or profile.role == RuntimeRole.API:
            continue
        checks.extend((
            ProductionPreflightCheck(f"worker_state:{profile.role.value}", True, "reference shared CAS state"),
            ProductionPreflightCheck(f"worker_queue:{profile.role.value}", True, "reference durable queue"),
            ProductionPreflightCheck(f"worker_ledger:{profile.role.value}", True, "reference applied-work ledger"),
            ProductionPreflightCheck(f"worker_handlers:{profile.role.value}", True, "reference idempotent handlers"),
        ))
    return ProductionPreflightReport(all(c.passed for c in checks), tuple(checks), __name__)
