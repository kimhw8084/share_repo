from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path

from ephi.autopilot.guards import assess_join_explosion
from ephi.autopilot.qualification import run_autopilot_qualification


@dataclass(frozen=True, slots=True)
class ProductionSmokeQualificationReport:
    passed: bool
    autopilot_runtime: bool
    reference_preflight: bool
    reference_preflight_checks: int
    scaffold_failed_closed: bool
    scaffold_failure_count: int
    scaffold_traceback_free: bool
    http_process_smoke: bool
    http_traceback_free: bool
    join_guard: bool
    details: dict[str, object]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _run_cli(root: Path, args: list[str]) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    return subprocess.run(
        [sys.executable, "-m", "ephi.cli.main", *args],
        cwd=root,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=30,
        check=False,
    )


def _http_smoke(root: Path) -> tuple[bool, bool, str]:
    port = _free_port()
    proc = subprocess.Popen(
        [sys.executable, "-m", "ephi.cli.main", "api", "serve", "--host", "127.0.0.1", "--port", str(port)],
        cwd=root,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    ok = False
    try:
        deadline = time.time() + 12
        while time.time() < deadline:
            if proc.poll() is not None:
                break
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/healthz", timeout=1) as response:
                    health = response.status == 200
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/version", timeout=1) as response:
                    version_ok = response.status == 200
                if health and version_ok:
                    ok = True
                    break
            except Exception:
                time.sleep(0.2)
    finally:
        proc.terminate()
        try:
            out, err = proc.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            out, err = proc.communicate(timeout=5)
    traceback_free = "Traceback (most recent call last)" not in err and "ERROR:" not in err.upper()
    return ok, traceback_free, (out + "\n" + err)[-4000:]


def run_production_smoke_qualification(
    root: str | Path = ".",
    *,
    deployment_plan: str | Path = "configs/deployment/shadow-reference.yaml",
    release_manifest: str | Path = "RELEASE_MANIFEST.json",
) -> ProductionSmokeQualificationReport:
    root = Path(root).resolve()
    autopilot = run_autopilot_qualification()
    deployment = str(Path(deployment_plan))
    manifest = str(Path(release_manifest))
    common = ["--deployment-plan", deployment, "--release-manifest", manifest]

    reference = _run_cli(root, [
        "port", "production-preflight", "--preflight-module", "ephi.port.reference_preflight", *common,
    ])
    try:
        ref_payload = json.loads(reference.stdout)
    except json.JSONDecodeError:
        ref_payload = {}
    reference_ok = reference.returncode == 0 and ref_payload.get("passed") is True and "Traceback" not in reference.stderr

    scaffold = _run_cli(root, [
        "port", "production-preflight", "--preflight-module", "ephi_company.production_preflight", *common,
    ])
    try:
        scaffold_payload = json.loads(scaffold.stdout)
    except json.JSONDecodeError:
        scaffold_payload = {}
    scaffold_traceback_free = "Traceback (most recent call last)" not in scaffold.stderr
    scaffold_failed_closed = (
        scaffold.returncode == 2
        and scaffold_payload.get("passed") is False
        and int(scaffold_payload.get("failed_count", 0)) >= 10
        and scaffold_traceback_free
    )

    http_ok, http_traceback_free, http_log = _http_smoke(root)
    join = assess_join_explosion(1_000_000, 900_000, 950_000, max_factor=2.0)
    passed = all((autopilot.passed, reference_ok, scaffold_failed_closed, http_ok, http_traceback_free, join.passed))
    return ProductionSmokeQualificationReport(
        passed=passed,
        autopilot_runtime=autopilot.passed,
        reference_preflight=reference_ok,
        reference_preflight_checks=int(ref_payload.get("check_count", 0)),
        scaffold_failed_closed=scaffold_failed_closed,
        scaffold_failure_count=int(scaffold_payload.get("failed_count", 0)),
        scaffold_traceback_free=scaffold_traceback_free,
        http_process_smoke=http_ok,
        http_traceback_free=http_traceback_free,
        join_guard=join.passed,
        details={
            "reference": ref_payload,
            "reference_stderr": reference.stderr[-2000:],
            "scaffold": scaffold_payload,
            "scaffold_stderr": scaffold.stderr[-2000:],
            "http_log_tail": http_log,
            "join_guard": join.to_dict(),
            "autopilot": autopilot.to_dict(),
        },
    )
