from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Any

from ephi.config import EphiConfig
from ephi.domain.operations import DeploymentPlan
from ephi.registry.releases import ReleaseManifest


@dataclass(frozen=True, slots=True)
class ProductionPreflightCheck:
    name: str
    passed: bool
    detail: str

    def to_dict(self) -> dict[str, object]:
        return {"name": self.name, "passed": self.passed, "detail": self.detail}


@dataclass(frozen=True, slots=True)
class ProductionPreflightReport:
    passed: bool
    checks: tuple[ProductionPreflightCheck, ...]
    module: str

    @property
    def failed(self) -> tuple[ProductionPreflightCheck, ...]:
        return tuple(c for c in self.checks if not c.passed)

    def to_dict(self) -> dict[str, object]:
        return {
            "passed": self.passed,
            "module": self.module,
            "check_count": len(self.checks),
            "failed_count": len(self.failed),
            "checks": [c.to_dict() for c in self.checks],
        }


def run_production_preflight_module(
    module_name: str,
    config: EphiConfig,
    deployment_plan: DeploymentPlan,
    release_manifest: ReleaseManifest,
) -> ProductionPreflightReport:
    module = importlib.import_module(module_name)
    func = getattr(module, "run_production_preflight", None)
    if not callable(func):
        raise ValueError(f"production preflight module {module_name} must expose run_production_preflight")
    raw: Any = func(config, deployment_plan, release_manifest)
    if isinstance(raw, ProductionPreflightReport):
        return raw
    if not isinstance(raw, dict):
        raise ValueError(f"production preflight module {module_name} returned unsupported result")
    checks = tuple(
        ProductionPreflightCheck(str(item["name"]), bool(item["passed"]), str(item.get("detail", "")))
        for item in raw.get("checks", ())
    )
    return ProductionPreflightReport(all(c.passed for c in checks), checks, module_name)
