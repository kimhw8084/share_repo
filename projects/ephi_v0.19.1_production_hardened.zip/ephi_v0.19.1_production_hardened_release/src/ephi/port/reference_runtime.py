from __future__ import annotations

from pathlib import Path

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.config import EphiConfig
from ephi.port.qualification import ReferencePortRuntime
from ephi.registry.releases import ReleaseManifest


def _assert_reference_environment(config: EphiConfig) -> None:
    if config.app.environment not in {"local", "reference", "test"}:
        raise RuntimeError(
            "ephi.port.reference_runtime is qualification-only and cannot run in company environments"
        )


def build_port_runtime(config: EphiConfig, release_manifest: ReleaseManifest) -> ReferencePortRuntime:
    _assert_reference_environment(config)
    return ReferencePortRuntime()


def build_port_state_store(config: EphiConfig):
    _assert_reference_environment(config)
    return SqliteStateStore(config.local.state_db)


def build_recovery_store(config: EphiConfig):
    _assert_reference_environment(config)
    base = Path(config.local.state_db)
    recovery_path = base.with_name(f"{base.stem}.recovery{base.suffix or '.sqlite3'}")
    return SqliteStateStore(recovery_path)
