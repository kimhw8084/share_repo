from __future__ import annotations

from dataclasses import dataclass


REQUIRED_RUNTIME_FUNCTIONS = ("build_port_runtime", "build_port_state_store", "build_recovery_store")
REQUIRED_RUNTIME_METHODS = (
    "validate_mapping",
    "run_data_reality",
    "bootstrap_state",
    "run_golden_replay",
    "run_operations_qualification",
    "assess_shadow_readiness",
)


@dataclass(frozen=True, slots=True)
class ModuleContractValidation:
    valid: bool
    missing_functions: tuple[str, ...] = ()
    missing_runtime_methods: tuple[str, ...] = ()


def validate_port_module(module, *, runtime=None) -> ModuleContractValidation:
    missing_functions = tuple(name for name in REQUIRED_RUNTIME_FUNCTIONS if not hasattr(module, name))
    missing_runtime = ()
    if runtime is not None:
        missing_runtime = tuple(name for name in REQUIRED_RUNTIME_METHODS if not hasattr(runtime, name))
    return ModuleContractValidation(
        valid=not missing_functions and not missing_runtime,
        missing_functions=missing_functions,
        missing_runtime_methods=missing_runtime,
    )
