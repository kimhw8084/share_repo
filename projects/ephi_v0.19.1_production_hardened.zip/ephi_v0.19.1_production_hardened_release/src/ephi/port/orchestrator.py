from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Callable

from ephi.adapters.base.state_store import StateStore
from ephi.domain.port import (
    PortBootstrapReport,
    PortGateEvidence,
    PortRunIdentity,
    PortStage,
    PortStageRecord,
    PortStageState,
)
from ephi.port.runtime import CompanyPortRuntime


_STAGE_ORDER: tuple[PortStage, ...] = (
    PortStage.MAPPING_VALIDATION,
    PortStage.DATA_REALITY,
    PortStage.STATE_BOOTSTRAP,
    PortStage.GOLDEN_REPLAY,
    PortStage.OPERATIONS_QUALIFICATION,
    PortStage.SHADOW_READINESS,
)

_STAGE_METHOD: dict[PortStage, str] = {
    PortStage.MAPPING_VALIDATION: "validate_mapping",
    PortStage.DATA_REALITY: "run_data_reality",
    PortStage.STATE_BOOTSTRAP: "bootstrap_state",
    PortStage.GOLDEN_REPLAY: "run_golden_replay",
    PortStage.OPERATIONS_QUALIFICATION: "run_operations_qualification",
    PortStage.SHADOW_READINESS: "assess_shadow_readiness",
}


class PortIdentityMismatchError(RuntimeError):
    pass


class PortBootstrapOrchestrator:
    """Fail-closed, restartable company-port bootstrap sequence.

    A completed stage is never silently reused under a different release/config/family
    identity. Downstream stages are blocked after the first failure. This is an
    orchestration record, not a production certification by itself.
    """

    def __init__(
        self,
        *,
        runtime: CompanyPortRuntime,
        identity: PortRunIdentity,
        state_store: StateStore | None = None,
    ) -> None:
        self.runtime = runtime
        self.identity = identity
        self.state_store = state_store
        self._state_key = (
            f"port:bootstrap:v1:{identity.environment}:{identity.family_id}"
        )
        self._state_version: int | None = None
        self._report: PortBootstrapReport | None = None
        if state_store is not None:
            self.restore()

    @staticmethod
    def stage_order() -> tuple[PortStage, ...]:
        return _STAGE_ORDER

    def _new_report(self, now: datetime) -> PortBootstrapReport:
        fingerprint = self.identity.stable_hash()
        stages = tuple(PortStageRecord(stage=stage, state=PortStageState.PENDING) for stage in _STAGE_ORDER)
        return PortBootstrapReport(
            run_id=f"port-{fingerprint[:16]}",
            identity=self.identity,
            started_at=now,
            stages=stages,
        )

    def _assert_identity(self, report: PortBootstrapReport) -> None:
        if report.identity != self.identity:
            raise PortIdentityMismatchError(
                "existing bootstrap state belongs to a different release/config/family/environment; "
                "use an isolated state key or explicitly reset the port bootstrap state"
            )

    def report(self) -> PortBootstrapReport | None:
        return self._report

    def checkpoint(self) -> None:
        if self.state_store is None or self._report is None:
            return
        payload = json.dumps(
            self._report.model_dump(mode="json"), sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
        record = self.state_store.compare_and_set(
            self._state_key, expected_version=self._state_version, value=payload
        )
        self._state_version = record.version

    def restore(self) -> None:
        if self.state_store is None:
            return
        record = self.state_store.get(self._state_key)
        if record is None:
            return
        report = PortBootstrapReport.model_validate_json(record.value)
        self._assert_identity(report)
        self._report = report
        self._state_version = record.version

    def reset(self) -> None:
        # StateStore has no portable delete primitive. Reset is represented as a new
        # run under the same key via CAS and retains external store audit history.
        now = datetime.now(timezone.utc)
        self._report = self._new_report(now)
        self.checkpoint()

    @staticmethod
    def _replace_stage(
        report: PortBootstrapReport,
        replacement: PortStageRecord,
        *,
        completed_at: datetime | None = None,
        shadow_ready: bool | None = None,
        blockers: tuple[str, ...] | None = None,
    ) -> PortBootstrapReport:
        stages = tuple(replacement if item.stage == replacement.stage else item for item in report.stages)
        return report.model_copy(
            update={
                "stages": stages,
                "completed_at": completed_at if completed_at is not None else report.completed_at,
                "shadow_ready": report.shadow_ready if shadow_ready is None else shadow_ready,
                "blockers": report.blockers if blockers is None else blockers,
            }
        )

    def _invoke(self, stage: PortStage) -> PortGateEvidence:
        method: Callable[[], PortGateEvidence] = getattr(self.runtime, _STAGE_METHOD[stage])
        evidence = method()
        if not isinstance(evidence, PortGateEvidence):
            raise TypeError(f"{_STAGE_METHOD[stage]}() must return PortGateEvidence")
        return evidence

    def run(self, *, resume: bool = True, raise_on_error: bool = False) -> PortBootstrapReport:
        now = datetime.now(timezone.utc)
        if self._report is None or not resume:
            self._report = self._new_report(now)
            self.checkpoint()
        else:
            self._assert_identity(self._report)

        assert self._report is not None
        report = self._report
        blocker_messages: list[str] = []
        failed = False

        for stage in _STAGE_ORDER:
            current = report.stage(stage)
            if current.state == PortStageState.PASSED and resume and not failed:
                continue
            if failed:
                completed = datetime.now(timezone.utc)
                blocked = PortStageRecord(
                    stage=stage,
                    state=PortStageState.BLOCKED,
                    completed_at=completed,
                    evidence=PortGateEvidence(
                        passed=False,
                        summary="blocked by an earlier failed port stage",
                        blockers=tuple(blocker_messages),
                    ),
                )
                report = self._replace_stage(report, blocked)
                self._report = report
                self.checkpoint()
                continue

            started = datetime.now(timezone.utc)
            running = PortStageRecord(stage=stage, state=PortStageState.RUNNING, started_at=started)
            report = self._replace_stage(report, running)
            self._report = report
            self.checkpoint()
            try:
                evidence = self._invoke(stage)
                completed = datetime.now(timezone.utc)
                state = PortStageState.PASSED if evidence.passed else PortStageState.FAILED
                terminal = PortStageRecord(
                    stage=stage,
                    state=state,
                    started_at=started,
                    completed_at=completed,
                    evidence=evidence,
                )
                report = self._replace_stage(report, terminal)
                if not evidence.passed:
                    failed = True
                    blocker_messages.extend(evidence.blockers or (evidence.summary,))
            except Exception as exc:
                completed = datetime.now(timezone.utc)
                evidence = PortGateEvidence(
                    passed=False,
                    summary=f"{stage.value} raised {type(exc).__name__}",
                    blockers=(str(exc),),
                )
                terminal = PortStageRecord(
                    stage=stage,
                    state=PortStageState.FAILED,
                    started_at=started,
                    completed_at=completed,
                    evidence=evidence,
                    error_type=type(exc).__name__,
                )
                report = self._replace_stage(report, terminal)
                failed = True
                blocker_messages.append(str(exc))
                if raise_on_error:
                    self._report = report
                    self.checkpoint()
                    raise
            self._report = report
            self.checkpoint()

        final_time = datetime.now(timezone.utc)
        shadow_ready = all(item.state == PortStageState.PASSED for item in report.stages)
        final_blockers = tuple(dict.fromkeys(blocker_messages))
        report = report.model_copy(
            update={
                "completed_at": final_time,
                "shadow_ready": shadow_ready,
                "blockers": final_blockers,
            }
        )
        self._report = report
        self.checkpoint()
        return report
