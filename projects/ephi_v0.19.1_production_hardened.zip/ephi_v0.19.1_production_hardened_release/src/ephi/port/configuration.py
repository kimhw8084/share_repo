from __future__ import annotations

import os

from ephi.config import EphiConfig, load_config


def configured_paths(explicit: list[str] | tuple[str, ...] | None = None) -> tuple[str, ...]:
    if explicit:
        return tuple(str(item) for item in explicit)
    raw = os.environ.get("EPHI_CONFIG_PATHS", "").strip()
    if not raw:
        return ()
    return tuple(item.strip() for item in raw.split(",") if item.strip())


def load_runtime_config(explicit: list[str] | tuple[str, ...] | None = None) -> EphiConfig:
    paths = configured_paths(explicit)
    return load_config(paths) if paths else EphiConfig()
