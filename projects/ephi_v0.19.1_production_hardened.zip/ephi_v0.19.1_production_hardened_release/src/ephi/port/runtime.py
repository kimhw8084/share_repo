from __future__ import annotations

from typing import Protocol

from ephi.domain.port import PortGateEvidence


class CompanyPortRuntime(Protocol):
    """Company-side stage executor used by the generic bootstrap orchestrator.

    Implementations may call proprietary libraries, but they must return only stable
    EPHI gate evidence. The orchestrator owns stage order, persistence, and blocking.
    """

    def validate_mapping(self) -> PortGateEvidence: ...

    def run_data_reality(self) -> PortGateEvidence: ...

    def bootstrap_state(self) -> PortGateEvidence: ...

    def run_golden_replay(self) -> PortGateEvidence: ...

    def run_operations_qualification(self) -> PortGateEvidence: ...

    def assess_shadow_readiness(self) -> PortGateEvidence: ...
