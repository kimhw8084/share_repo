from __future__ import annotations

from dataclasses import dataclass, field, replace

from ephi.domain.episode import FleetEpisode, FleetEpisodeState
from ephi.domain.evidence import Hypothesis
from ephi.domain.health import HealthAssessment, HealthSeverity


@dataclass(frozen=True, slots=True)
class FleetEpisodeConfig:
    min_assets: int = 2
    open_severity: HealthSeverity = HealthSeverity.MONITOR
    min_common_support: float = 0.25
    recovery_required: int = 3


@dataclass(slots=True)
class FleetEpisodeService:
    """Episode aggregation for qualified common-mode changes.

    Local asset episodes remain suppressed by the decision engine; this service
    preserves the synchronized fleet phenomenon as one parent analytical object.
    """

    config: FleetEpisodeConfig = field(default_factory=FleetEpisodeConfig)
    _active: dict[str, FleetEpisode] = field(default_factory=dict)
    _history: list[FleetEpisode] = field(default_factory=list)
    _counter: int = 0

    @staticmethod
    def _key(assessment: HealthAssessment) -> str:
        return assessment.context.stable_key()

    @staticmethod
    def _common_support(assessment: HealthAssessment) -> float:
        for item in assessment.hypothesis_support:
            if item.hypothesis == Hypothesis.COMMON_MODE_PROCESS_CHANGE:
                return max(0.0, item.net)
        return 0.0

    def process_group(self, assessments: list[HealthAssessment]) -> FleetEpisode | None:
        if not assessments:
            return None
        key = self._key(assessments[0])
        if any(self._key(item) != key for item in assessments):
            raise ValueError("fleet episode group must share effective context")

        common = [
            item
            for item in assessments
            if item.leading_hypothesis == Hypothesis.COMMON_MODE_PROCESS_CHANGE
            and item.severity >= self.config.open_severity
            and self._common_support(item) >= self.config.min_common_support
        ]
        event_time = max(item.event_time for item in assessments)
        current = self._active.get(key)

        if len({item.asset_id for item in common}) >= self.config.min_assets:
            asset_ids = tuple(sorted({item.asset_id for item in common}))
            peak_support = max(self._common_support(item) for item in common)
            if current is None:
                self._counter += 1
                created = FleetEpisode(
                    episode_id=f"EPHI-F{self._counter:06d}",
                    context=assessments[0].context,
                    opened_at=event_time,
                    last_updated_at=event_time,
                    state=FleetEpisodeState.ACTIVE,
                    affected_asset_ids=asset_ids,
                    leading_hypothesis=Hypothesis.COMMON_MODE_PROCESS_CHANGE,
                    peak_common_support=peak_support,
                )
                self._active[key] = created
                return created

            updated = replace(
                current,
                last_updated_at=event_time,
                state=FleetEpisodeState.ACTIVE,
                affected_asset_ids=tuple(sorted(set(current.affected_asset_ids) | set(asset_ids))),
                peak_common_support=max(current.peak_common_support, peak_support),
                consecutive_recovery=0,
            )
            self._active[key] = updated
            return updated

        if current is None:
            return None

        recovery = current.consecutive_recovery + 1
        if recovery >= self.config.recovery_required:
            closed = replace(
                current,
                last_updated_at=event_time,
                state=FleetEpisodeState.RESOLVED,
                consecutive_recovery=recovery,
                closed_at=event_time,
            )
            self._history.append(closed)
            del self._active[key]
            return closed

        recovering = replace(
            current,
            last_updated_at=event_time,
            state=FleetEpisodeState.RECOVERING,
            consecutive_recovery=recovery,
        )
        self._active[key] = recovering
        return recovering

    def active(self) -> tuple[FleetEpisode, ...]:
        return tuple(self._active.values())

    def history(self) -> tuple[FleetEpisode, ...]:
        return tuple(self._history)

    @staticmethod
    def _to_dict(value: FleetEpisode) -> dict[str, object]:
        return {
            "episode_id": value.episode_id,
            "context": value.context.to_dict(),
            "opened_at": value.opened_at.isoformat(),
            "last_updated_at": value.last_updated_at.isoformat(),
            "state": value.state.value,
            "affected_asset_ids": list(value.affected_asset_ids),
            "leading_hypothesis": value.leading_hypothesis.value,
            "peak_common_support": value.peak_common_support,
            "consecutive_recovery": value.consecutive_recovery,
            "closed_at": value.closed_at.isoformat() if value.closed_at else None,
        }

    @staticmethod
    def _from_dict(value: dict[str, object]) -> FleetEpisode:
        from datetime import datetime

        from ephi.domain.context import ContextKey

        context_raw = value["context"]
        if not isinstance(context_raw, dict):
            raise TypeError("fleet episode checkpoint context must be a mapping")
        assets = value.get("affected_asset_ids", [])
        if not isinstance(assets, list):
            raise TypeError("fleet episode affected assets must be a list")
        closed_raw = value.get("closed_at")
        return FleetEpisode(
            episode_id=str(value["episode_id"]),
            context=ContextKey.from_dict({str(k): str(v) for k, v in context_raw.items()}),
            opened_at=datetime.fromisoformat(str(value["opened_at"])),
            last_updated_at=datetime.fromisoformat(str(value["last_updated_at"])),
            state=FleetEpisodeState(str(value["state"])),
            affected_asset_ids=tuple(str(v) for v in assets),
            leading_hypothesis=Hypothesis(str(value["leading_hypothesis"])),
            peak_common_support=float(value["peak_common_support"]),
            consecutive_recovery=int(value.get("consecutive_recovery", 0)),
            closed_at=datetime.fromisoformat(str(closed_raw)) if closed_raw else None,
        )

    def export_state(self) -> dict[str, object]:
        return {
            "counter": self._counter,
            "active": [self._to_dict(value) for value in self._active.values()],
            "history": [self._to_dict(value) for value in self._history],
        }

    def restore_state(self, state: dict[str, object]) -> None:
        active_raw = state.get("active", [])
        history_raw = state.get("history", [])
        if not isinstance(active_raw, list) or not isinstance(history_raw, list):
            raise TypeError("invalid fleet episode checkpoint payload")
        self._counter = int(state.get("counter", 0))
        active = [self._from_dict(v) for v in active_raw if isinstance(v, dict)]
        self._active = {value.context.stable_key(): value for value in active}
        self._history = [self._from_dict(v) for v in history_raw if isinstance(v, dict)]
