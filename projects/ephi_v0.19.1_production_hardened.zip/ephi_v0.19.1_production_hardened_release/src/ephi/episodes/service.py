from __future__ import annotations

from dataclasses import dataclass, field, replace

from ephi.domain.episode import EpisodeState, HealthEpisode
from ephi.domain.health import HealthAssessment, HealthSeverity


@dataclass(frozen=True, slots=True)
class EpisodeConfig:
    open_severity: HealthSeverity = HealthSeverity.INVESTIGATE
    recovery_required: int = 5


@dataclass(slots=True)
class EpisodeService:
    config: EpisodeConfig = field(default_factory=EpisodeConfig)
    _active: dict[tuple[str, str], HealthEpisode] = field(default_factory=dict)
    _history: list[HealthEpisode] = field(default_factory=list)
    _counter: int = 0

    def _key(self, assessment: HealthAssessment) -> tuple[str, str]:
        return assessment.asset_id, assessment.context.stable_key()

    def process(self, assessment: HealthAssessment) -> HealthEpisode | None:
        key = self._key(assessment)
        current = self._active.get(key)

        if current is None:
            if assessment.severity < self.config.open_severity:
                return None
            self._counter += 1
            state = EpisodeState.URGENT if assessment.severity >= HealthSeverity.URGENT else EpisodeState.INVESTIGATE
            episode = HealthEpisode(
                episode_id=f"EPHI-E{self._counter:06d}",
                asset_id=assessment.asset_id,
                context=assessment.context,
                opened_at=assessment.event_time,
                last_updated_at=assessment.event_time,
                state=state,
                severity=assessment.severity,
                leading_hypothesis=assessment.leading_hypothesis,
                peak_behavioral_novelty=assessment.behavioral_novelty,
            )
            self._active[key] = episode
            return episode

        if assessment.severity >= self.config.open_severity:
            updated = replace(
                current,
                last_updated_at=assessment.event_time,
                state=(
                    EpisodeState.URGENT
                    if assessment.severity >= HealthSeverity.URGENT
                    else EpisodeState.INVESTIGATE
                ),
                severity=max(current.severity, assessment.severity),
                leading_hypothesis=assessment.leading_hypothesis,
                peak_behavioral_novelty=max(
                    current.peak_behavioral_novelty, assessment.behavioral_novelty
                ),
                consecutive_recovery=0,
            )
            self._active[key] = updated
            return updated

        # Recovery requires sustained NORMAL/OBSERVE evidence. MONITOR does not count as healthy.
        if assessment.severity <= HealthSeverity.OBSERVE:
            recovery_count = current.consecutive_recovery + 1
            if recovery_count >= self.config.recovery_required:
                closed = replace(
                    current,
                    last_updated_at=assessment.event_time,
                    state=EpisodeState.RESOLVED,
                    consecutive_recovery=recovery_count,
                    closed_at=assessment.event_time,
                )
                self._history.append(closed)
                del self._active[key]
                return closed
            recovering = replace(
                current,
                last_updated_at=assessment.event_time,
                state=EpisodeState.RECOVERING,
                consecutive_recovery=recovery_count,
            )
            self._active[key] = recovering
            return recovering

        return current

    def active(self) -> tuple[HealthEpisode, ...]:
        return tuple(self._active.values())

    def history(self) -> tuple[HealthEpisode, ...]:
        return tuple(self._history)
    @staticmethod
    def _episode_to_dict(episode: HealthEpisode) -> dict[str, object]:
        return {
            "episode_id": episode.episode_id,
            "asset_id": episode.asset_id,
            "context": episode.context.to_dict(),
            "opened_at": episode.opened_at.isoformat(),
            "last_updated_at": episode.last_updated_at.isoformat(),
            "state": episode.state.value,
            "severity": int(episode.severity),
            "leading_hypothesis": episode.leading_hypothesis.value,
            "peak_behavioral_novelty": episode.peak_behavioral_novelty,
            "consecutive_recovery": episode.consecutive_recovery,
            "closed_at": episode.closed_at.isoformat() if episode.closed_at else None,
        }

    @staticmethod
    def _episode_from_dict(value: dict[str, object]) -> HealthEpisode:
        from datetime import datetime

        from ephi.domain.context import ContextKey
        from ephi.domain.evidence import Hypothesis

        context_raw = value["context"]
        if not isinstance(context_raw, dict):
            raise TypeError("episode checkpoint context must be a mapping")
        closed_raw = value.get("closed_at")
        return HealthEpisode(
            episode_id=str(value["episode_id"]),
            asset_id=str(value["asset_id"]),
            context=ContextKey.from_dict({str(k): str(v) for k, v in context_raw.items()}),
            opened_at=datetime.fromisoformat(str(value["opened_at"])),
            last_updated_at=datetime.fromisoformat(str(value["last_updated_at"])),
            state=EpisodeState(str(value["state"])),
            severity=HealthSeverity(int(value["severity"])),
            leading_hypothesis=Hypothesis(str(value["leading_hypothesis"])),
            peak_behavioral_novelty=float(value["peak_behavioral_novelty"]),
            consecutive_recovery=int(value.get("consecutive_recovery", 0)),
            closed_at=datetime.fromisoformat(str(closed_raw)) if closed_raw else None,
        )

    def export_state(self) -> dict[str, object]:
        return {
            "counter": self._counter,
            "active": [self._episode_to_dict(v) for v in self._active.values()],
            "history": [self._episode_to_dict(v) for v in self._history],
        }

    def restore_state(self, state: dict[str, object]) -> None:
        active_raw = state.get("active", [])
        history_raw = state.get("history", [])
        if not isinstance(active_raw, list) or not isinstance(history_raw, list):
            raise TypeError("invalid episode checkpoint payload")
        self._counter = int(state.get("counter", 0))
        active = [self._episode_from_dict(v) for v in active_raw if isinstance(v, dict)]
        self._active = {(v.asset_id, v.context.stable_key()): v for v in active}
        self._history = [self._episode_from_dict(v) for v in history_raw if isinstance(v, dict)]

