from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from ephi.domain.detection import DetectorResult
from ephi.domain.evidence import EvidenceEffect, EvidenceItem, Hypothesis
from ephi.domain.health import HealthAssessment, HealthSeverity, HypothesisSupport


@dataclass(frozen=True, slots=True)
class FusionConfig:
    investigate_novelty: float = 0.62
    urgent_novelty: float = 0.88
    monitor_novelty: float = 0.35
    min_action_confidence: float = 0.45
    local_persistence_min: int = 3
    local_peer_persistence_min: int = 2
    local_extreme_self_z: float = 8.0
    local_extreme_peer_z: float = 4.5
    common_mode_fleet_z: float = 2.5


def aggregate_hypothesis_support(items: tuple[EvidenceItem, ...]) -> tuple[HypothesisSupport, ...]:
    # Dependency-aware max within (hypothesis, dependency_group, polarity), then sum
    # across semantically independent groups. This prevents z/EWMA/CUSUM inflation.
    support_groups: dict[tuple[Hypothesis, str], float] = defaultdict(float)
    contradiction_groups: dict[tuple[Hypothesis, str], float] = defaultdict(float)
    for item in items:
        effective_item_conf = max(0.0, min(1.0, item.confidence))
        for effect in item.effects:
            effective = max(0.0, min(1.0, effect.strength)) * effective_item_conf
            key = (effect.hypothesis, item.dependency_group)
            if effect.effect == EvidenceEffect.SUPPORTS:
                support_groups[key] = max(support_groups[key], effective)
            elif effect.effect == EvidenceEffect.CONTRADICTS:
                contradiction_groups[key] = max(contradiction_groups[key], effective)

    output: list[HypothesisSupport] = []
    for hypothesis in Hypothesis:
        support = sum(v for (h, _), v in support_groups.items() if h == hypothesis)
        contradiction = sum(v for (h, _), v in contradiction_groups.items() if h == hypothesis)
        output.append(HypothesisSupport(hypothesis, support, contradiction))
    return tuple(output)


def build_health_assessment(
    result: DetectorResult,
    evidence: tuple[EvidenceItem, ...],
    *,
    config: FusionConfig = FusionConfig(),
) -> HealthAssessment:
    supports = aggregate_hypothesis_support(evidence)
    ranked = sorted(supports, key=lambda x: x.net, reverse=True)
    leading = ranked[0].hypothesis if ranked and ranked[0].net > 0 else Hypothesis.INSUFFICIENT_INFORMATION
    if result.data_pipeline_suspect:
        leading = Hypothesis.DATA_PIPELINE_OR_SCHEMA_CHANGE

    # Behavioral novelty intentionally uses detector magnitude, not hypothesis score.
    behavioral_novelty = min(
        1.0,
        max(
            abs(result.self_z) / 8.0,
            abs(result.anchor_z) / 8.0,
            abs(result.ewma_fast) / 5.0,
            min(result.persistence_count / 8.0, 1.0),
        ),
    )
    confidence = min(1.0, 0.65 * result.reference_confidence + 0.35 * result.peer_confidence)

    peer_z = abs(result.peer_change_z) if result.peer_change_z is not None else 0.0
    peer_ewma = abs(result.peer_ewma) if result.peer_ewma is not None else 0.0
    fleet_z = abs(result.fleet_shift_z) if result.fleet_shift_z is not None else 0.0
    extreme_local = (
        abs(result.self_z) >= config.local_extreme_self_z
        and peer_z >= config.local_extreme_peer_z
        and fleet_z < config.common_mode_fleet_z
    )
    persistent_local = (
        (
            result.persistence_count >= config.local_persistence_min
            or abs(result.anchor_z) >= 3.0
        )
        and result.peer_persistence_count >= config.local_peer_persistence_min
    )
    # If the fleet is also shifted, demand stronger persistent target-vs-peer evidence
    # before interpreting a local deviation inside the broader common-mode change.
    if fleet_z >= config.common_mode_fleet_z and leading == Hypothesis.LOCAL_ASSET_DEGRADATION:
        if result.peer_persistence_count < config.local_persistence_min or peer_ewma < config.monitor_novelty * 5.0:
            leading = Hypothesis.COMMON_MODE_PROCESS_CHANGE
    local_confirmed = persistent_local or extreme_local

    # Pipeline and common-mode explanations suppress local engineer-facing severity.
    if leading == Hypothesis.DATA_PIPELINE_OR_SCHEMA_CHANGE:
        severity = HealthSeverity.OBSERVE
    elif leading == Hypothesis.COMMON_MODE_PROCESS_CHANGE:
        severity = HealthSeverity.MONITOR if behavioral_novelty >= config.monitor_novelty else HealthSeverity.OBSERVE
    elif confidence < config.min_action_confidence:
        severity = HealthSeverity.OBSERVE if behavioral_novelty > 0.15 else HealthSeverity.NORMAL
    elif (
        behavioral_novelty >= config.urgent_novelty
        and leading == Hypothesis.LOCAL_ASSET_DEGRADATION
        and local_confirmed
    ):
        severity = HealthSeverity.URGENT
    elif (
        behavioral_novelty >= config.investigate_novelty
        and leading == Hypothesis.LOCAL_ASSET_DEGRADATION
        and local_confirmed
    ):
        severity = HealthSeverity.INVESTIGATE
    elif behavioral_novelty >= config.monitor_novelty:
        severity = HealthSeverity.MONITOR
    elif behavioral_novelty > 0.15:
        severity = HealthSeverity.OBSERVE
    else:
        severity = HealthSeverity.NORMAL

    return HealthAssessment(
        assessment_id=f"HA:{result.execution_id}:{result.feature_id}",
        execution_id=result.execution_id,
        asset_id=result.asset_id,
        context=result.context,
        event_time=result.event_time,
        severity=severity,
        confidence=confidence,
        behavioral_novelty=behavioral_novelty,
        leading_hypothesis=leading,
        hypothesis_support=supports,
        evidence=evidence,
    )
