from __future__ import annotations

from dataclasses import dataclass

from ephi.domain.detection import DetectorResult
from ephi.domain.evidence import (
    EvidenceChannel,
    EvidenceEffect,
    EvidenceItem,
    Hypothesis,
    HypothesisEffect,
)


def _bounded_strength(value: float, threshold: float, saturation: float = 8.0) -> float:
    if abs(value) <= threshold:
        return 0.0
    return min(1.0, (abs(value) - threshold) / max(saturation - threshold, 1e-9))


@dataclass(frozen=True, slots=True)
class EvidenceConfig:
    self_z_threshold: float = 3.0
    peer_z_threshold: float = 2.5
    peer_extreme_z: float = 4.5
    fleet_z_threshold: float = 2.5
    persistence_min: int = 3
    ewma_threshold: float = 2.0


def evidence_from_detector(
    result: DetectorResult,
    *,
    config: EvidenceConfig = EvidenceConfig(),
) -> tuple[EvidenceItem, ...]:
    items: list[EvidenceItem] = []
    base = f"{result.execution_id}:{result.feature_id}"

    behavioral_z = result.anchor_z if abs(result.anchor_z) > abs(result.self_z) else result.self_z
    self_strength = _bounded_strength(behavioral_z, config.self_z_threshold)
    if self_strength > 0:
        items.append(
            EvidenceItem(
                evidence_id=base + ":self",
                asset_id=result.asset_id,
                execution_id=result.execution_id,
                event_time=result.event_time,
                channel=EvidenceChannel.SELF_HEALTH,
                evidence_type="ROBUST_SELF_OR_ANCHOR_DEVIATION",
                observation=(
                    f"adaptive z={result.self_z:.2f}, anchor z={result.anchor_z:.2f}"
                ),
                strength=self_strength,
                confidence=result.reference_confidence,
                dependency_group=f"{result.feature_id}:behavior",
                effects=(
                    HypothesisEffect(
                        Hypothesis.LOCAL_ASSET_DEGRADATION,
                        EvidenceEffect.SUPPORTS,
                        self_strength,
                        "SELF_DEVIATION",
                    ),
                    HypothesisEffect(
                        Hypothesis.COMMON_MODE_PROCESS_CHANGE,
                        EvidenceEffect.SUPPORTS,
                        self_strength,
                        "SELF_DEVIATION_NON_DISCRIMINATING",
                    ),
                ),
            )
        )

    if result.peer_change_z is not None:
        peer_strength = _bounded_strength(result.peer_change_z, config.peer_z_threshold)
        peer_persistent = (
            result.peer_persistence_count >= config.persistence_min
            or (result.peer_ewma is not None and abs(result.peer_ewma) >= config.ewma_threshold)
            or (
                abs(result.peer_change_z) >= config.peer_extreme_z
                and (result.fleet_shift_z is None or abs(result.fleet_shift_z) < config.fleet_z_threshold)
            )
        )
        if peer_strength > 0 and peer_persistent:
            items.append(
                EvidenceItem(
                    evidence_id=base + ":peer",
                    asset_id=result.asset_id,
                    execution_id=result.execution_id,
                    event_time=result.event_time,
                    channel=EvidenceChannel.PEER_RELATIVE_HEALTH,
                    evidence_type="PEER_CHANGE_RESIDUAL",
                    observation=(
                        f"change-relative peer residual z={result.peer_change_z:.2f}, "
                        f"persistent={result.peer_persistence_count}"
                    ),
                    strength=peer_strength,
                    confidence=result.peer_confidence,
                    dependency_group=f"{result.feature_id}:peer",
                    effects=(
                        HypothesisEffect(
                            Hypothesis.LOCAL_ASSET_DEGRADATION,
                            EvidenceEffect.SUPPORTS,
                            peer_strength,
                            "TARGET_DIVERGES_FROM_PEERS",
                        ),
                        HypothesisEffect(
                            Hypothesis.COMMON_MODE_PROCESS_CHANGE,
                            EvidenceEffect.CONTRADICTS,
                            peer_strength * 0.8,
                            "TARGET_DIVERGES_FROM_PEERS",
                        ),
                    ),
                )
            )

    if result.fleet_shift_z is not None:
        fleet_strength = _bounded_strength(result.fleet_shift_z, config.fleet_z_threshold)
        if fleet_strength > 0:
            local_contradiction = fleet_strength
            if result.peer_change_z is not None and abs(result.peer_change_z) >= config.peer_z_threshold:
                local_contradiction *= 0.35
            items.append(
                EvidenceItem(
                    evidence_id=base + ":fleet",
                    asset_id=result.asset_id,
                    execution_id=result.execution_id,
                    event_time=result.event_time,
                    channel=EvidenceChannel.FLEET_COMMON_MODE,
                    evidence_type="FLEET_SHIFT",
                    observation=f"qualified peer cohort shifted z={result.fleet_shift_z:.2f}",
                    strength=fleet_strength,
                    confidence=result.peer_confidence,
                    dependency_group=f"{result.feature_id}:fleet",
                    effects=(
                        HypothesisEffect(
                            Hypothesis.COMMON_MODE_PROCESS_CHANGE,
                            EvidenceEffect.SUPPORTS,
                            fleet_strength,
                            "PEER_COHORT_SHIFT",
                        ),
                        HypothesisEffect(
                            Hypothesis.LOCAL_ASSET_DEGRADATION,
                            EvidenceEffect.CONTRADICTS,
                            local_contradiction,
                            "PEER_COHORT_SHIFT",
                        ),
                    ),
                )
            )

    temporal_strength = max(
        _bounded_strength(result.ewma_fast, config.ewma_threshold, 5.0),
        _bounded_strength(result.ewma_slow, config.ewma_threshold, 5.0),
    )
    if result.persistence_count >= config.persistence_min:
        temporal_strength = max(temporal_strength, min(1.0, result.persistence_count / 8.0))
    if temporal_strength > 0:
        items.append(
            EvidenceItem(
                evidence_id=base + ":temporal",
                asset_id=result.asset_id,
                execution_id=result.execution_id,
                event_time=result.event_time,
                channel=EvidenceChannel.TEMPORAL_STATE,
                evidence_type="PERSISTENT_SHIFT",
                observation=(
                    f"persistent shift count={result.persistence_count}, "
                    f"ewma_fast={result.ewma_fast:.2f}"
                ),
                strength=temporal_strength,
                confidence=result.reference_confidence,
                dependency_group=f"{result.feature_id}:behavior",  # dependent with self-z family
                effects=(
                    HypothesisEffect(
                        Hypothesis.LOCAL_ASSET_DEGRADATION,
                        EvidenceEffect.SUPPORTS,
                        temporal_strength * 0.55,
                        "PERSISTENT_BEHAVIOR_CHANGE",
                    ),
                    HypothesisEffect(
                        Hypothesis.COMMON_MODE_PROCESS_CHANGE,
                        EvidenceEffect.SUPPORTS,
                        temporal_strength * 0.55,
                        "PERSISTENT_BEHAVIOR_CHANGE",
                    ),
                ),
            )
        )

    if result.data_pipeline_suspect:
        items.append(
            EvidenceItem(
                evidence_id=base + ":pipeline",
                asset_id=result.asset_id,
                execution_id=result.execution_id,
                event_time=result.event_time,
                channel=EvidenceChannel.DATA_PIPELINE_HEALTH,
                evidence_type="UNIT_OR_SCALE_DISCONTINUITY",
                observation="value changed by an implausibly large scale relative to anchor reference",
                strength=1.0,
                confidence=result.reference_confidence,
                dependency_group=f"{result.feature_id}:data_pipeline",
                effects=(
                    HypothesisEffect(
                        Hypothesis.DATA_PIPELINE_OR_SCHEMA_CHANGE,
                        EvidenceEffect.SUPPORTS,
                        1.0,
                        "IMPLAUSIBLE_SCALE_CHANGE",
                    ),
                    HypothesisEffect(
                        Hypothesis.LOCAL_ASSET_DEGRADATION,
                        EvidenceEffect.CONTRADICTS,
                        0.85,
                        "IMPLAUSIBLE_SCALE_CHANGE",
                    ),
                ),
            )
        )

    return tuple(items)
