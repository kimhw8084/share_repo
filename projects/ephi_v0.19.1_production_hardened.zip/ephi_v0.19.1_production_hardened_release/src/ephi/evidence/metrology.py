from __future__ import annotations

from dataclasses import dataclass

from ephi.domain.evidence import (
    EvidenceChannel,
    EvidenceEffect,
    EvidenceItem,
    Hypothesis,
    HypothesisEffect,
)
from ephi.domain.health import HealthAssessment, HealthSeverity
from ephi.domain.metrology import MeasurementSystemResult
from ephi.evidence.fusion import aggregate_hypothesis_support


def _strength(z: float | None, threshold: float, saturation: float = 7.0) -> float:
    if z is None or abs(z) <= threshold:
        return 0.0
    return min(1.0, (abs(z) - threshold) / max(saturation - threshold, 1e-9))


@dataclass(frozen=True, slots=True)
class MetrologyEvidenceConfig:
    reference_z: float = 3.0
    cross_tool_z: float = 3.0
    repeatability_z: float = 3.0
    repeatability_peer_z: float = 2.5
    repeatability_distribution_z: float = 3.0
    repeatability_distribution_extreme_z: float = 4.0
    spatial_z: float = 3.0
    spatial_peer_z: float = 2.5
    fleet_z: float = 2.5
    persistence_min: int = 2
    extreme_repeatability_z: float = 4.5
    extreme_spatial_z: float = 4.8
    repeatability_ewma: float = 1.8
    repeatability_peer_ewma: float = 1.5
    spatial_ewma: float = 2.0
    spatial_peer_ewma: float = 1.5
    matching_ewma: float = 2.0
    reference_ewma: float = 2.0
    extreme_reference_z: float = 6.0
    single_channel_investigate_net: float = 0.20
    min_action_confidence: float = 0.50
    investigate_net_support: float = 0.65
    urgent_net_support: float = 1.55


def evidence_from_measurement_system(
    result: MeasurementSystemResult,
    *,
    config: MetrologyEvidenceConfig = MetrologyEvidenceConfig(),
) -> tuple[EvidenceItem, ...]:
    base = f"{result.measurement_id}:{result.characteristic_id}"
    items: list[EvidenceItem] = []

    reference_strength = _strength(result.reference_z, config.reference_z)
    reference_persistent = (
        result.reference_persistence >= config.persistence_min
        or (result.reference_ewma is not None and abs(result.reference_ewma) >= config.reference_ewma)
    )
    if reference_strength > 0 and reference_persistent:
        items.append(
            EvidenceItem(
                evidence_id=base + ":reference",
                asset_id=result.subject_id,
                execution_id=result.measurement_id,
                event_time=result.event_time,
                channel=EvidenceChannel.MEASUREMENT_SYSTEM_HEALTH,
                evidence_type="REFERENCE_MATERIAL_BIAS",
                observation=f"reference-material robust z={result.reference_z:.2f}",
                strength=reference_strength,
                confidence=result.reference_confidence,
                dependency_group=f"{result.characteristic_id}:reference_measurement",
                effects=(
                    HypothesisEffect(
                        Hypothesis.METROLOGY_SYSTEM_SHIFT,
                        EvidenceEffect.SUPPORTS,
                        reference_strength,
                        "REFERENCE_MATERIAL_SHIFT",
                    ),
                    HypothesisEffect(
                        Hypothesis.COMMON_MODE_PROCESS_CHANGE,
                        EvidenceEffect.CONTRADICTS,
                        reference_strength * 0.75,
                        "REFERENCE_MATERIAL_SHIFT",
                    ),
                ),
            )
        )

    matching_strength = _strength(result.cross_tool_z, config.cross_tool_z)
    matching_persistent = (
        result.cross_tool_persistence >= config.persistence_min
        or (result.cross_tool_ewma is not None and abs(result.cross_tool_ewma) >= config.matching_ewma)
    )
    if matching_strength > 0 and matching_persistent:
        items.append(
            EvidenceItem(
                evidence_id=base + ":matching",
                asset_id=result.subject_id,
                execution_id=result.measurement_id,
                event_time=result.event_time,
                channel=EvidenceChannel.CROSS_TOOL_MATCHING,
                evidence_type="CROSS_TOOL_RESIDUAL",
                observation=f"cross-tool matching robust z={result.cross_tool_z:.2f}",
                strength=matching_strength,
                confidence=result.matching_confidence,
                dependency_group=(
                    f"{result.characteristic_id}:reference_measurement"
                    if result.is_reference_material
                    else f"{result.characteristic_id}:cross_tool"
                ),
                effects=(
                    HypothesisEffect(
                        Hypothesis.METROLOGY_SYSTEM_SHIFT,
                        EvidenceEffect.SUPPORTS,
                        matching_strength,
                        "TARGET_DIVERGES_FROM_MATCHED_METROLOGY_PEERS",
                    ),
                    HypothesisEffect(
                        Hypothesis.COMMON_MODE_PROCESS_CHANGE,
                        EvidenceEffect.CONTRADICTS,
                        matching_strength * 0.6,
                        "TARGET_DIVERGES_FROM_MATCHED_METROLOGY_PEERS",
                    ),
                ),
            )
        )

    repeat_distribution_strength = _strength(
        result.repeatability_distribution_z,
        config.repeatability_distribution_z,
        saturation=6.0,
    )
    if repeat_distribution_strength > 0:
        peer_text = (
            f", peer-relative z={result.repeatability_peer_z:.2f}"
            if result.repeatability_peer_z is not None
            else ""
        )
        items.append(
            EvidenceItem(
                evidence_id=base + ":repeatability",
                asset_id=result.subject_id,
                execution_id=result.measurement_id,
                event_time=result.event_time,
                channel=EvidenceChannel.REPEATABILITY,
                evidence_type="REMEASURE_DISTRIBUTION_SHIFT",
                observation=(
                    f"recent repeatability distribution z={result.repeatability_distribution_z:.2f}"
                    f"{peer_text}"
                ),
                strength=repeat_distribution_strength,
                confidence=result.repeatability_confidence,
                dependency_group=f"{result.characteristic_id}:repeatability_distribution",
                effects=(
                    HypothesisEffect(
                        Hypothesis.METROLOGY_SYSTEM_SHIFT,
                        EvidenceEffect.SUPPORTS,
                        repeat_distribution_strength,
                        "REMEASURE_DISTRIBUTION_DEGRADED",
                    ),
                ),
            )
        )

    spatial_strength = _strength(result.spatial_z, config.spatial_z)
    spatial_peer_strength = _strength(
        result.spatial_peer_z, config.spatial_peer_z, saturation=6.0
    )
    spatial_persistent = (
        result.spatial_persistence >= config.persistence_min
        or (result.spatial_ewma is not None and abs(result.spatial_ewma) >= config.spatial_ewma)
    )
    spatial_peer_persistent = (
        result.spatial_peer_persistence >= config.persistence_min
        or (
            result.spatial_peer_ewma is not None
            and abs(result.spatial_peer_ewma) >= config.spatial_peer_ewma
        )
    )
    if (
        spatial_strength > 0
        and spatial_peer_strength > 0
        and spatial_persistent
        and spatial_peer_persistent
    ):
        combined_spatial_strength = min(1.0, 0.55 * spatial_strength + 0.45 * spatial_peer_strength)
        items.append(
            EvidenceItem(
                evidence_id=base + ":spatial",
                asset_id=result.subject_id,
                execution_id=result.measurement_id,
                event_time=result.event_time,
                channel=EvidenceChannel.SPATIAL_STABILITY,
                evidence_type="SPATIAL_CENTER_EDGE_SHIFT",
                observation=(
                    f"center-edge self z={result.spatial_z:.2f}, "
                    f"peer-relative z={result.spatial_peer_z:.2f}"
                ),
                strength=combined_spatial_strength,
                confidence=result.spatial_confidence,
                dependency_group=f"{result.characteristic_id}:spatial",
                effects=(
                    HypothesisEffect(
                        Hypothesis.METROLOGY_SYSTEM_SHIFT,
                        EvidenceEffect.SUPPORTS,
                        combined_spatial_strength,
                        "HEAD_SPECIFIC_SPATIAL_SHIFT_VS_SELF_AND_PEERS",
                    ),
                ),
            )
        )

    fleet_strength = _strength(result.production_fleet_shift_z, config.fleet_z)
    # Production common-mode evidence is only credible when the target itself also
    # moved from its historical production anchor.
    if (
        fleet_strength > 0
        and result.production_anchor_z is not None
        and abs(result.production_anchor_z) >= config.reference_z
    ):
        items.append(
            EvidenceItem(
                evidence_id=base + ":production_fleet",
                asset_id=result.subject_id,
                execution_id=result.measurement_id,
                event_time=result.event_time,
                channel=EvidenceChannel.PRODUCTION_METROLOGY,
                evidence_type="PRODUCTION_COMMON_MODE_SHIFT",
                observation=(
                    f"production anchor z={result.production_anchor_z:.2f}, "
                    f"fleet shift z={result.production_fleet_shift_z:.2f}"
                ),
                strength=fleet_strength,
                confidence=result.matching_confidence,
                dependency_group=f"{result.characteristic_id}:production_fleet",
                effects=(
                    HypothesisEffect(
                        Hypothesis.COMMON_MODE_PROCESS_CHANGE,
                        EvidenceEffect.SUPPORTS,
                        fleet_strength,
                        "PRODUCTION_MOVES_ACROSS_MATCHED_HEADS",
                    ),
                    HypothesisEffect(
                        Hypothesis.METROLOGY_SYSTEM_SHIFT,
                        EvidenceEffect.CONTRADICTS,
                        fleet_strength * 0.45,
                        "PRODUCTION_MOVES_ACROSS_MATCHED_HEADS",
                    ),
                ),
            )
        )

    return tuple(items)


def build_metrology_health_assessment(
    result: MeasurementSystemResult,
    evidence: tuple[EvidenceItem, ...],
    *,
    config: MetrologyEvidenceConfig = MetrologyEvidenceConfig(),
) -> HealthAssessment:
    supports = aggregate_hypothesis_support(evidence)
    by_hypothesis = {item.hypothesis: item for item in supports}
    metro_net = by_hypothesis[Hypothesis.METROLOGY_SYSTEM_SHIFT].net
    common_net = by_hypothesis[Hypothesis.COMMON_MODE_PROCESS_CHANGE].net

    ranked = sorted(supports, key=lambda item: item.net, reverse=True)
    leading = ranked[0].hypothesis if ranked and ranked[0].net > 0 else Hypothesis.INSUFFICIENT_INFORMATION

    independent_metro_groups = {
        item.dependency_group
        for item in evidence
        if any(
            effect.hypothesis == Hypothesis.METROLOGY_SYSTEM_SHIFT
            and effect.effect == EvidenceEffect.SUPPORTS
            and effect.strength >= 0.25
            for effect in item.effects
        )
    }
    reference_extreme = (
        result.is_reference_material
        and result.reference_z is not None
        and abs(result.reference_z) >= config.extreme_reference_z
        and result.cross_tool_z is not None
        and abs(result.cross_tool_z) >= config.cross_tool_z
        and (
            result.reference_persistence >= config.persistence_min
            or (
                result.reference_ewma is not None
                and abs(result.reference_ewma) >= config.reference_ewma
            )
        )
        and (
            result.cross_tool_persistence >= config.persistence_min
            or (
                result.cross_tool_ewma is not None
                and abs(result.cross_tool_ewma) >= config.matching_ewma
            )
        )
    )
    repeat_extreme = (
        result.repeatability_distribution_z is not None
        and result.repeatability_distribution_z >= config.repeatability_distribution_extreme_z
    )
    spatial_persistent_for_fusion = (
        result.spatial_persistence >= config.persistence_min
        or (result.spatial_ewma is not None and abs(result.spatial_ewma) >= config.spatial_ewma)
    )
    spatial_peer_persistent_for_fusion = (
        result.spatial_peer_persistence >= config.persistence_min
        or (
            result.spatial_peer_ewma is not None
            and abs(result.spatial_peer_ewma) >= config.spatial_peer_ewma
        )
    )
    spatial_extreme = (
        result.spatial_z is not None
        and abs(result.spatial_z) >= config.extreme_spatial_z
        and result.spatial_peer_z is not None
        and abs(result.spatial_peer_z) >= config.spatial_peer_z
        and spatial_persistent_for_fusion
        and spatial_peer_persistent_for_fusion
    )
    single_channel_confirmed = reference_extreme or repeat_extreme or spatial_extreme
    measurement_confirmed = len(independent_metro_groups) >= 2 or single_channel_confirmed

    confidence_values = [item.confidence for item in evidence if item.confidence > 0]
    confidence = (
        min(1.0, sum(confidence_values) / len(confidence_values))
        if confidence_values
        else 0.0
    )
    novelty = max((item.strength for item in evidence), default=0.0)

    if (
        leading == Hypothesis.METROLOGY_SYSTEM_SHIFT
        and measurement_confirmed
        and confidence >= config.min_action_confidence
    ):
        severity = (
            HealthSeverity.URGENT
            if metro_net >= config.urgent_net_support
            else HealthSeverity.INVESTIGATE
            if (
                metro_net >= config.investigate_net_support
                or (single_channel_confirmed and metro_net >= config.single_channel_investigate_net)
            )
            else HealthSeverity.MONITOR
        )
    elif leading == Hypothesis.COMMON_MODE_PROCESS_CHANGE and common_net > 0:
        severity = HealthSeverity.MONITOR
    elif novelty > 0.25:
        severity = HealthSeverity.OBSERVE
    else:
        severity = HealthSeverity.NORMAL

    system_context = result.context.__class__(
        operation="METRO_SYSTEM",
        recipe_id=result.characteristic_id,
        product_id="ALL",
        technology=result.context.technology,
    )
    return HealthAssessment(
        assessment_id=f"HA:METRO:{result.measurement_id}",
        execution_id=result.measurement_id,
        asset_id=result.subject_id,
        context=system_context,
        event_time=result.event_time,
        severity=severity,
        confidence=confidence,
        behavioral_novelty=novelty,
        leading_hypothesis=leading,
        hypothesis_support=supports,
        evidence=evidence,
    )
