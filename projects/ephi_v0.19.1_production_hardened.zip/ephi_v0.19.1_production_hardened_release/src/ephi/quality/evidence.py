from __future__ import annotations

from datetime import datetime

from ephi.domain.evidence import (
    EvidenceChannel,
    EvidenceEffect,
    EvidenceItem,
    Hypothesis,
    HypothesisEffect,
)
from ephi.domain.quality import QualityAssociationEvidence, QualityEvidenceState, QualityStage


def evidence_from_quality_association(
    association: QualityAssociationEvidence,
    *,
    asset_id: str,
    execution_id: str,
    event_time: datetime,
) -> EvidenceItem:
    supportive = association.evidence_state in {
        QualityEvidenceState.WEAK_ASSOCIATION,
        QualityEvidenceState.SUPPORTED_ASSOCIATION,
        QualityEvidenceState.STRONG_ASSOCIATION,
    }
    strength_scale = {
        QualityEvidenceState.UNAVAILABLE: 0.0,
        QualityEvidenceState.NOT_YET_MATURE: 0.0,
        QualityEvidenceState.NO_OBSERVED_ASSOCIATION: 0.0,
        QualityEvidenceState.WEAK_ASSOCIATION: 0.35,
        QualityEvidenceState.SUPPORTED_ASSOCIATION: 0.65,
        QualityEvidenceState.STRONG_ASSOCIATION: 0.90,
        QualityEvidenceState.CONTRADICTED: 0.0,
    }[association.evidence_state]
    strength = strength_scale * association.association_confidence
    if supportive:
        local_effect = EvidenceEffect.SUPPORTS
    elif association.evidence_state is QualityEvidenceState.CONTRADICTED:
        local_effect = EvidenceEffect.CONTRADICTS
    elif association.evidence_state in {QualityEvidenceState.UNAVAILABLE, QualityEvidenceState.NOT_YET_MATURE}:
        local_effect = EvidenceEffect.UNAVAILABLE
    else:
        local_effect = EvidenceEffect.NEUTRAL

    supported_hypothesis = (
        Hypothesis.METROLOGY_SYSTEM_SHIFT
        if association.stage is QualityStage.MEASUREMENT_SYSTEM
        else Hypothesis.LOCAL_ASSET_DEGRADATION
    )

    return EvidenceItem(
        evidence_id=f"quality:{association.target_id}:{execution_id}",
        asset_id=asset_id,
        execution_id=execution_id,
        event_time=event_time,
        channel=EvidenceChannel.QUALITY_HARMFULNESS,
        evidence_type="QUALITY_ASSOCIATION",
        observation=(
            f"{association.evidence_state}; effect={association.adjusted_effect}; "
            f"exposed={association.exposed_count}; controls={association.control_count}"
        ),
        strength=float(strength),
        confidence=float(association.association_confidence),
        dependency_group=f"QUALITY:{association.target_id}",
        effects=(
            HypothesisEffect(
                hypothesis=supported_hypothesis,
                effect=local_effect,
                strength=float(strength),
                reason_code="DOWNSTREAM_QUALITY_ASSOCIATION",
            ),
            HypothesisEffect(
                hypothesis=Hypothesis.BENIGN_NOVELTY,
                effect=EvidenceEffect.CONTRADICTS if supportive else EvidenceEffect.NEUTRAL,
                strength=float(strength),
                reason_code="QUALITY_HARMFULNESS_VS_BENIGN",
            ),
        ),
    )
