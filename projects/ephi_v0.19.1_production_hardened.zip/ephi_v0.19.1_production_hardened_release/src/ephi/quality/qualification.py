from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import timedelta

from ephi.domain.quality import (
    PredictionTime,
    QualityStage,
    QualityTargetDefinition,
    QualityTargetType,
)
from ephi.health.engine import BehavioralHealthPipeline
from ephi.quality.association import build_quality_association
from ephi.quality.dataset import build_quality_dataset, equipment_state_vectors_from_assessments
from ephi.quality.modeling import train_quality_models
from ephi.synthetic.quality import QualityScenarioConfig, generate_quality_scenario


@dataclass(frozen=True, slots=True)
class QualityQualificationScenarioResult:
    scenario: str
    target_type: str
    row_count: int
    m0_primary_metric: float
    m1_primary_metric: float
    equipment_state_increment: float
    equipment_state_useful: bool
    association_state: str
    association_effect: float | None
    association_confidence: float
    m1_calibration_error: float | None
    m1_uncertainty_interval_half_width: float | None


@dataclass(frozen=True, slots=True)
class QualityQualificationReport:
    version: str
    scenarios: tuple[QualityQualificationScenarioResult, ...]
    passed: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "version": self.version,
            "passed": self.passed,
            "scenarios": [asdict(item) for item in self.scenarios],
        }


def _run(*, harmful: bool, target_type: QualityTargetType, executions_per_asset: int = 600) -> QualityQualificationScenarioResult:
    observations, outcomes = generate_quality_scenario(
        QualityScenarioConfig(
            executions_per_asset=executions_per_asset,
            harmful=harmful,
            target_type=target_type,
        )
    )
    result = BehavioralHealthPipeline().process(observations)
    states = equipment_state_vectors_from_assessments(observations, result.assessments)
    target_id = "INLINE_Q_CONT" if target_type is QualityTargetType.CONTINUOUS else "INLINE_Q_BIN"
    target = QualityTargetDefinition(
        target_id=target_id,
        version="1.0.0",
        target_type=target_type,
        stage=QualityStage.INLINE_METROLOGY,
        prediction_time=PredictionTime.POST_PROCESS,
        minimum_practical_effect=0.20 if target_type is QualityTargetType.CONTINUOUS else 0.05,
        measurement_system_sensitive=True,
        harmful_direction="UPPER",
        description="Synthetic qualification target; not a fab production target.",
    )
    dataset = build_quality_dataset(
        target=target,
        states=states,
        outcomes=outcomes,
        knowledge_cutoff=max(item.available_at for item in outcomes) + timedelta(minutes=1),
    )
    model = train_quality_models(dataset)
    onset = int(executions_per_asset * 0.60)
    exposed_ids = {
        row.execution_id
        for row in dataset.rows
        if row.asset_id == "A000" and int(row.execution_id.rsplit("-", 1)[1]) >= onset
    }
    association = build_quality_association(
        target=target,
        rows=dataset.rows,
        exposed_execution_ids=exposed_ids,
        predictive_increment=model.comparison.equipment_state_increment,
    )
    if target_type is QualityTargetType.CONTINUOUS:
        m0 = float(model.comparison.m0.rmse or 0.0)
        m1 = float(model.comparison.m1.rmse or 0.0)
    else:
        m0 = float(model.comparison.m0.brier or 0.0)
        m1 = float(model.comparison.m1.brier or 0.0)
    return QualityQualificationScenarioResult(
        scenario="HARMFUL_LOCAL_DRIFT" if harmful else "BENIGN_LOCAL_DRIFT",
        target_type=target_type.value,
        row_count=len(dataset.rows),
        m0_primary_metric=m0,
        m1_primary_metric=m1,
        equipment_state_increment=float(model.comparison.equipment_state_increment),
        equipment_state_useful=bool(model.comparison.equipment_state_useful),
        association_state=association.evidence_state.value,
        association_effect=association.adjusted_effect,
        association_confidence=float(association.association_confidence),
        m1_calibration_error=model.comparison.m1.calibration_error,
        m1_uncertainty_interval_half_width=model.m1_interval_half_width,
    )


def run_quality_qualification() -> QualityQualificationReport:
    harmful_cont = _run(harmful=True, target_type=QualityTargetType.CONTINUOUS)
    benign_cont = _run(harmful=False, target_type=QualityTargetType.CONTINUOUS)
    harmful_binary = _run(harmful=True, target_type=QualityTargetType.BINARY, executions_per_asset=800)
    passed = (
        harmful_cont.equipment_state_useful
        and harmful_cont.m1_primary_metric < harmful_cont.m0_primary_metric
        and not benign_cont.equipment_state_useful
        and harmful_binary.equipment_state_useful
        and harmful_binary.m1_primary_metric < harmful_binary.m0_primary_metric
    )
    return QualityQualificationReport(
        version="v0.6.0-synthetic-quality-foundation",
        scenarios=(harmful_cont, benign_cont, harmful_binary),
        passed=passed,
    )
