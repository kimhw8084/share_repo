from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml

from ephi.domain.quality import QualityTargetDefinition


@dataclass(slots=True)
class QualityTargetRegistry:
    _targets: dict[tuple[str, str], QualityTargetDefinition] = field(default_factory=dict)

    def register(self, target: QualityTargetDefinition) -> None:
        key = (target.target_id, target.version)
        existing = self._targets.get(key)
        if existing is not None and existing != target:
            raise ValueError(f"quality target {target.target_id}@{target.version} already registered differently")
        self._targets[key] = target

    def get(self, target_id: str, version: str) -> QualityTargetDefinition:
        try:
            return self._targets[(target_id, version)]
        except KeyError as exc:
            raise KeyError(f"unknown quality target {target_id}@{version}") from exc

    def all(self) -> tuple[QualityTargetDefinition, ...]:
        return tuple(self._targets[key] for key in sorted(self._targets))


def load_quality_target(path: str | Path) -> QualityTargetDefinition:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise TypeError("quality target definition must be a mapping")
    return QualityTargetDefinition.model_validate(payload)
