from __future__ import annotations

from dataclasses import dataclass
from math import sqrt
from typing import Iterable

import numpy as np
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    log_loss,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from ephi.domain.quality import (
    ApplicabilityAssessment,
    QualityModelComparison,
    QualityModelMetrics,
    QualityModelResult,
    QualityTargetDefinition,
    QualityTargetType,
    QualityTrainingRow,
)
from .dataset import QualityDatasetSnapshot


def _context_matrix(rows: Iterable[QualityTrainingRow]) -> np.ndarray:
    return np.asarray(
        [[row.context.operation, row.context.recipe_id, row.context.product_id, row.context.technology] for row in rows],
        dtype=object,
    )


def _equipment_matrix(rows: Iterable[QualityTrainingRow]) -> np.ndarray:
    return np.asarray(
        [[
            row.behavioral_novelty,
            row.health_confidence,
            row.local_support,
            row.common_mode_support,
            row.measurement_system_support,
        ] for row in rows],
        dtype=np.float64,
    )


def _ece(y_true: np.ndarray, p: np.ndarray, bins: int = 10) -> float:
    edges = np.linspace(0.0, 1.0, bins + 1)
    total = max(len(y_true), 1)
    error = 0.0
    for left, right in zip(edges[:-1], edges[1:], strict=True):
        mask = (p >= left) & ((p < right) if right < 1.0 else (p <= right))
        if not np.any(mask):
            continue
        error += float(np.sum(mask)) / total * abs(float(np.mean(p[mask])) - float(np.mean(y_true[mask])))
    return float(error)


def _logit(p: np.ndarray) -> np.ndarray:
    clipped = np.clip(p, 1e-6, 1.0 - 1e-6)
    return np.log(clipped / (1.0 - clipped))[:, None]


@dataclass(slots=True)
class _PlattCalibrator:
    model: LogisticRegression

    @classmethod
    def fit(cls, p: np.ndarray, y: np.ndarray) -> "_PlattCalibrator":
        if len(np.unique(y)) < 2:
            raise ValueError("calibration window requires both binary classes")
        model = LogisticRegression(C=1.0, max_iter=500).fit(_logit(p), y)
        return cls(model)

    def predict(self, p: np.ndarray) -> np.ndarray:
        return np.asarray(self.model.predict_proba(_logit(p))[:, 1], dtype=np.float64)


@dataclass(frozen=True, slots=True)
class QualityTrainingConfig:
    test_fraction: float = 0.25
    calibration_fraction: float = 0.15
    ridge_alpha: float = 1.0
    logistic_c: float = 1.0
    min_rows: int = 120
    min_train_rows: int = 70
    min_calibration_rows: int = 25
    min_test_rows: int = 25
    regression_min_rmse_gain: float = 0.01
    classification_min_brier_gain: float = 0.002
    regression_interval_quantile: float = 0.90


@dataclass(slots=True)
class QualityModelBundle:
    target: QualityTargetDefinition
    comparison: QualityModelComparison
    context_encoder: OneHotEncoder
    equipment_scaler: StandardScaler
    m0_model: object
    m1_model: object
    train_products: frozenset[str]
    train_recipes: frozenset[str]
    train_context_keys: frozenset[str]
    m0_calibrator: _PlattCalibrator | None = None
    m1_calibrator: _PlattCalibrator | None = None
    m1_interval_half_width: float | None = None

    def _matrices(self, rows: tuple[QualityTrainingRow, ...]) -> tuple[np.ndarray, np.ndarray]:
        ctx = self.context_encoder.transform(_context_matrix(rows))
        eq = self.equipment_scaler.transform(_equipment_matrix(rows))
        return ctx, np.hstack((ctx, eq))

    def applicability(self, row: QualityTrainingRow) -> ApplicabilityAssessment:
        context_supported = row.context.stable_key() in self.train_context_keys
        product_supported = row.context.product_id in self.train_products
        recipe_supported = row.context.recipe_id in self.train_recipes
        reasons: list[str] = []
        if not context_supported:
            reasons.append("UNSEEN_EXACT_CONTEXT")
        if not product_supported:
            reasons.append("UNSEEN_PRODUCT")
        if not recipe_supported:
            reasons.append("UNSEEN_RECIPE")
        support = (float(context_supported) + float(product_supported) + float(recipe_supported)) / 3.0
        confidence = min(max(0.0, support * row.health_confidence), 1.0)
        return ApplicabilityAssessment(
            applicable=product_supported and recipe_supported,
            confidence=confidence,
            context_supported=context_supported,
            product_supported=product_supported,
            recipe_supported=recipe_supported,
            reason_codes=tuple(reasons),
        )

    def predict(self, rows: Iterable[QualityTrainingRow]) -> tuple[QualityModelResult, ...]:
        rows_t = tuple(rows)
        if not rows_t:
            return ()
        x0, x1 = self._matrices(rows_t)
        if self.target.target_type is QualityTargetType.CONTINUOUS:
            p0 = np.asarray(self.m0_model.predict(x0), dtype=np.float64)
            p1 = np.asarray(self.m1_model.predict(x1), dtype=np.float64)
        else:
            p0 = np.asarray(self.m0_model.predict_proba(x0)[:, 1], dtype=np.float64)
            p1 = np.asarray(self.m1_model.predict_proba(x1)[:, 1], dtype=np.float64)
            if self.m0_calibrator is not None:
                p0 = self.m0_calibrator.predict(p0)
            if self.m1_calibrator is not None:
                p1 = self.m1_calibrator.predict(p1)
        output: list[QualityModelResult] = []
        for row, a, b in zip(rows_t, p0, p1, strict=True):
            app = self.applicability(row)
            lower = upper = None
            if self.target.target_type is QualityTargetType.CONTINUOUS and self.m1_interval_half_width is not None:
                lower = float(b - self.m1_interval_half_width)
                upper = float(b + self.m1_interval_half_width)
            output.append(
                QualityModelResult(
                    target_id=self.target.target_id,
                    target_version=self.target.version,
                    execution_id=row.execution_id,
                    predicted_value_or_risk=float(b),
                    m0_prediction=float(a),
                    m1_prediction=float(b),
                    predictive_increment=float(b - a),
                    applicability=app,
                    measurement_integrity_confidence=row.measurement_integrity_confidence,
                    model_confidence=min(app.confidence, row.measurement_integrity_confidence),
                    interval_lower=lower,
                    interval_upper=upper,
                )
            )
        return tuple(output)


def _regression_metrics(target: QualityTargetDefinition, role: str, y: np.ndarray, pred: np.ndarray, n_train: int) -> QualityModelMetrics:
    return QualityModelMetrics(
        target_id=target.target_id,
        model_role=role,
        target_type=target.target_type,
        n_train=n_train,
        n_test=len(y),
        rmse=float(sqrt(mean_squared_error(y, pred))),
        mae=float(mean_absolute_error(y, pred)),
        r2=float(r2_score(y, pred)),
    )


def _classification_metrics(target: QualityTargetDefinition, role: str, y: np.ndarray, p: np.ndarray, n_train: int) -> QualityModelMetrics:
    clipped = np.clip(p, 1e-8, 1 - 1e-8)
    return QualityModelMetrics(
        target_id=target.target_id,
        model_role=role,
        target_type=target.target_type,
        n_train=n_train,
        n_test=len(y),
        brier=float(brier_score_loss(y, clipped)),
        log_loss=float(log_loss(y, clipped, labels=[0.0, 1.0])),
        average_precision=float(average_precision_score(y, clipped)) if len(np.unique(y)) > 1 else None,
        calibration_error=_ece(y, clipped),
    )


def _split_rows(rows: tuple[QualityTrainingRow, ...], config: QualityTrainingConfig):
    n = len(rows)
    if n < config.min_rows:
        raise ValueError(f"insufficient quality rows: {n} < {config.min_rows}")
    test_n = max(config.min_test_rows, int(round(n * config.test_fraction)))
    pretest_n = n - test_n
    calibration_n = max(config.min_calibration_rows, int(round(pretest_n * config.calibration_fraction)))
    train_n = pretest_n - calibration_n
    if train_n < config.min_train_rows or calibration_n < config.min_calibration_rows or test_n < config.min_test_rows:
        raise ValueError("unable to create train/calibration/test chronological quality split")
    return rows[:train_n], rows[train_n:pretest_n], rows[pretest_n:]


def train_quality_models(
    dataset: QualityDatasetSnapshot,
    *,
    config: QualityTrainingConfig = QualityTrainingConfig(),
) -> QualityModelBundle:
    rows = dataset.chronological_rows()
    train, calibration, test = _split_rows(rows, config)

    encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False, dtype=np.float64)
    x0_train = encoder.fit_transform(_context_matrix(train))
    x0_cal = encoder.transform(_context_matrix(calibration))
    x0_test = encoder.transform(_context_matrix(test))
    scaler = StandardScaler()
    eq_train = scaler.fit_transform(_equipment_matrix(train))
    eq_cal = scaler.transform(_equipment_matrix(calibration))
    eq_test = scaler.transform(_equipment_matrix(test))
    x1_train = np.hstack((x0_train, eq_train))
    x1_cal = np.hstack((x0_cal, eq_cal))
    x1_test = np.hstack((x0_test, eq_test))
    y_train = np.asarray([row.outcome_value for row in train], dtype=np.float64)
    y_cal = np.asarray([row.outcome_value for row in calibration], dtype=np.float64)
    y_test = np.asarray([row.outcome_value for row in test], dtype=np.float64)

    m0_calibrator = m1_calibrator = None
    interval_half_width = None
    if dataset.target.target_type is QualityTargetType.CONTINUOUS:
        m0 = Ridge(alpha=config.ridge_alpha).fit(x0_train, y_train)
        m1 = Ridge(alpha=config.ridge_alpha).fit(x1_train, y_train)
        p0_cal = np.asarray(m0.predict(x0_cal), dtype=np.float64)
        p1_cal = np.asarray(m1.predict(x1_cal), dtype=np.float64)
        residual = np.abs(y_cal - p1_cal)
        interval_half_width = float(np.quantile(residual, config.regression_interval_quantile))
        p0 = np.asarray(m0.predict(x0_test), dtype=np.float64)
        p1 = np.asarray(m1.predict(x1_test), dtype=np.float64)
        metrics0 = _regression_metrics(dataset.target, "M0_CONTEXT", y_test, p0, len(train))
        metrics1 = _regression_metrics(dataset.target, "M1_CONTEXT_EQUIPMENT", y_test, p1, len(train))
        increment = float((metrics0.rmse or 0.0) - (metrics1.rmse or 0.0))
        useful = increment >= config.regression_min_rmse_gain
        calibration_method = "NONE_REGRESSION"
        uncertainty_method = f"ABS_RESIDUAL_Q{config.regression_interval_quantile:.2f}_CHRONOLOGICAL_CALIBRATION"
    else:
        unique = np.unique(y_train)
        if not set(unique).issubset({0.0, 1.0}) or len(unique) < 2:
            raise ValueError("binary quality training requires both 0 and 1 classes")
        m0 = LogisticRegression(C=config.logistic_c, max_iter=500, class_weight=None).fit(x0_train, y_train)
        m1 = LogisticRegression(C=config.logistic_c, max_iter=500, class_weight=None).fit(x1_train, y_train)
        raw0_cal = np.asarray(m0.predict_proba(x0_cal)[:, 1], dtype=np.float64)
        raw1_cal = np.asarray(m1.predict_proba(x1_cal)[:, 1], dtype=np.float64)
        m0_calibrator = _PlattCalibrator.fit(raw0_cal, y_cal)
        m1_calibrator = _PlattCalibrator.fit(raw1_cal, y_cal)
        raw0_test = np.asarray(m0.predict_proba(x0_test)[:, 1], dtype=np.float64)
        raw1_test = np.asarray(m1.predict_proba(x1_test)[:, 1], dtype=np.float64)
        p0 = m0_calibrator.predict(raw0_test)
        p1 = m1_calibrator.predict(raw1_test)
        metrics0 = _classification_metrics(dataset.target, "M0_CONTEXT", y_test, p0, len(train))
        metrics1 = _classification_metrics(dataset.target, "M1_CONTEXT_EQUIPMENT", y_test, p1, len(train))
        increment = float((metrics0.brier or 0.0) - (metrics1.brier or 0.0))
        useful = increment >= config.classification_min_brier_gain
        calibration_method = "PLATT_CHRONOLOGICAL_CALIBRATION"
        uncertainty_method = None

    comparison = QualityModelComparison(
        target_id=dataset.target.target_id,
        target_version=dataset.target.version,
        target_type=dataset.target.target_type,
        m0=metrics0,
        m1=metrics1,
        equipment_state_increment=increment,
        equipment_state_useful=useful,
        chronological_split_time=test[0].prediction_cutoff,
        calibration_method=calibration_method,
        uncertainty_method=uncertainty_method,
    )
    return QualityModelBundle(
        target=dataset.target,
        comparison=comparison,
        context_encoder=encoder,
        equipment_scaler=scaler,
        m0_model=m0,
        m1_model=m1,
        train_products=frozenset(row.context.product_id for row in train),
        train_recipes=frozenset(row.context.recipe_id for row in train),
        train_context_keys=frozenset(row.context.stable_key() for row in train),
        m0_calibrator=m0_calibrator,
        m1_calibrator=m1_calibrator,
        m1_interval_half_width=interval_half_width,
    )
