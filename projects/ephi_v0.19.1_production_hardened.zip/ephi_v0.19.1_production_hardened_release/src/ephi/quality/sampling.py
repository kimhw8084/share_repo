from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from ephi.domain.quality import EquipmentStateVector


@dataclass(frozen=True, slots=True)
class SamplingBiasDiagnostic:
    population_count: int
    sampled_count: int
    sampling_rate: float
    state_dependence_auc: float | None
    diagnostic_state: str
    reason_codes: tuple[str, ...]


def diagnose_sampling_bias(
    states: Iterable[EquipmentStateVector],
    *,
    sampled_execution_ids: set[str] | frozenset[str],
    auc_attention_threshold: float = 0.70,
) -> SamplingBiasDiagnostic:
    """Diagnose whether measurement selection is predictable from context/health state.

    This deliberately does not apply inverse-probability weighting. A high AUC means
    selection is informative and outcome comparisons require explicit review; weighting
    is only appropriate later if overlap/ignorability assumptions are defensible.
    """
    rows = tuple(states)
    if not rows:
        return SamplingBiasDiagnostic(0, 0, 0.0, None, "UNAVAILABLE", ("EMPTY_POPULATION",))
    y = np.asarray([float(row.execution_id in sampled_execution_ids) for row in rows], dtype=np.float64)
    sampled = int(np.sum(y))
    rate = sampled / len(rows)
    if sampled == 0 or sampled == len(rows):
        return SamplingBiasDiagnostic(
            len(rows), sampled, rate, None, "UNINFORMATIVE",
            ("NO_SAMPLING_VARIATION",),
        )
    ctx = np.asarray(
        [[row.context.operation, row.context.recipe_id, row.context.product_id, row.context.technology] for row in rows],
        dtype=object,
    )
    eq = np.asarray(
        [[row.behavioral_novelty, row.local_support, row.common_mode_support, row.measurement_system_support] for row in rows],
        dtype=np.float64,
    )
    encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False, dtype=np.float64)
    x_ctx = encoder.fit_transform(ctx)
    x_eq = StandardScaler().fit_transform(eq)
    x = np.hstack((x_ctx, x_eq))
    model = LogisticRegression(max_iter=500, class_weight="balanced").fit(x, y)
    p = np.asarray(model.predict_proba(x)[:, 1], dtype=np.float64)
    auc = float(roc_auc_score(y, p))
    if auc >= auc_attention_threshold:
        state = "SELECTION_BIAS_RISK"
        reasons = ("SAMPLING_PREDICTABLE_FROM_CONTEXT_OR_HEALTH_STATE",)
    else:
        state = "LOW_DETECTED_SELECTION_DEPENDENCE"
        reasons = ()
    return SamplingBiasDiagnostic(len(rows), sampled, rate, auc, state, reasons)
