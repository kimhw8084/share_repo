from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path

import yaml
from pydantic import BaseModel, ConfigDict, Field

from .qualification import QualityQualificationReport


class QualityQualificationGatePolicy(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    policy_id: str
    min_harmful_continuous_gain: float = Field(ge=0.0)
    max_benign_continuous_gain: float
    min_harmful_binary_gain: float = Field(ge=0.0)
    require_harmful_association: bool = True
    require_benign_no_association: bool = True


@dataclass(frozen=True, slots=True)
class QualityGateResult:
    gate: str
    passed: bool
    actual: object
    requirement: str


@dataclass(frozen=True, slots=True)
class QualityQualificationDecision:
    policy_id: str
    passed: bool
    gates: tuple[QualityGateResult, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "policy_id": self.policy_id,
            "passed": self.passed,
            "gates": [asdict(item) for item in self.gates],
        }


def load_quality_gate_policy(path: str | Path) -> QualityQualificationGatePolicy:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise TypeError("quality gate policy must be a mapping")
    return QualityQualificationGatePolicy.model_validate(payload)


def apply_quality_gate(report: QualityQualificationReport, policy: QualityQualificationGatePolicy) -> QualityQualificationDecision:
    index = {(item.scenario, item.target_type): item for item in report.scenarios}
    hc = index[("HARMFUL_LOCAL_DRIFT", "CONTINUOUS")]
    bc = index[("BENIGN_LOCAL_DRIFT", "CONTINUOUS")]
    hb = index[("HARMFUL_LOCAL_DRIFT", "BINARY")]
    harmful_states = {"WEAK_ASSOCIATION", "SUPPORTED_ASSOCIATION", "STRONG_ASSOCIATION"}
    gates = (
        QualityGateResult(
            "harmful_continuous_m1_increment",
            hc.equipment_state_increment >= policy.min_harmful_continuous_gain,
            hc.equipment_state_increment,
            f">= {policy.min_harmful_continuous_gain}",
        ),
        QualityGateResult(
            "benign_continuous_rejection",
            bc.equipment_state_increment <= policy.max_benign_continuous_gain and not bc.equipment_state_useful,
            bc.equipment_state_increment,
            f"<= {policy.max_benign_continuous_gain} and not useful",
        ),
        QualityGateResult(
            "harmful_binary_m1_increment",
            hb.equipment_state_increment >= policy.min_harmful_binary_gain,
            hb.equipment_state_increment,
            f">= {policy.min_harmful_binary_gain}",
        ),
        QualityGateResult(
            "harmful_association",
            (not policy.require_harmful_association) or (hc.association_state in harmful_states and hb.association_state in harmful_states),
            (hc.association_state, hb.association_state),
            "harmful scenarios must show association" if policy.require_harmful_association else "not required",
        ),
        QualityGateResult(
            "benign_no_association",
            (not policy.require_benign_no_association) or bc.association_state == "NO_OBSERVED_ASSOCIATION",
            bc.association_state,
            "== NO_OBSERVED_ASSOCIATION" if policy.require_benign_no_association else "not required",
        ),
    )
    return QualityQualificationDecision(policy.policy_id, all(item.passed for item in gates), gates)
