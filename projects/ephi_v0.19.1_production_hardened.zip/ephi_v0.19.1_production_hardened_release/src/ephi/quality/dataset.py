from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Iterable, Mapping

import numpy as np

from ephi.domain.evidence import Hypothesis
from ephi.domain.features import ScalarFeatureObservation
from ephi.domain.health import HealthAssessment
from ephi.domain.quality import (
    EquipmentStateVector,
    OutcomeMaturityState,
    QualityDatasetManifest,
    QualityOutcomeObservation,
    QualityTargetDefinition,
    QualityTrainingRow,
)


@dataclass(frozen=True, slots=True)
class QualityDatasetSnapshot:
    manifest: QualityDatasetManifest
    target: QualityTargetDefinition
    rows: tuple[QualityTrainingRow, ...]

    def chronological_rows(self) -> tuple[QualityTrainingRow, ...]:
        return tuple(sorted(self.rows, key=lambda row: (row.prediction_cutoff, row.execution_id)))

    def outcome_array(self) -> np.ndarray:
        return np.asarray([row.outcome_value for row in self.rows], dtype=np.float64)


def _support(assessment: HealthAssessment, hypothesis: Hypothesis) -> float:
    for item in assessment.hypothesis_support:
        if item.hypothesis is hypothesis:
            return float(max(item.net, 0.0))
    return 0.0


def equipment_state_vectors_from_assessments(
    observations: Iterable[ScalarFeatureObservation],
    assessments: Iterable[HealthAssessment],
) -> tuple[EquipmentStateVector, ...]:
    by_execution = {obs.execution_id: obs for obs in observations}
    output: list[EquipmentStateVector] = []
    for assessment in assessments:
        obs = by_execution.get(assessment.execution_id)
        if obs is None:
            continue
        # The scalar synthetic/reference implementation uses one material per execution.
        # Company adapters should provide canonical material IDs directly.
        material_id = assessment.execution_id.replace("E-", "W-", 1)
        output.append(
            EquipmentStateVector(
                execution_id=assessment.execution_id,
                material_id=material_id,
                asset_id=assessment.asset_id,
                context=assessment.context,
                event_time=assessment.event_time,
                known_at=obs.available_at,
                behavioral_novelty=float(assessment.behavioral_novelty),
                health_confidence=float(assessment.confidence),
                local_support=_support(assessment, Hypothesis.LOCAL_ASSET_DEGRADATION),
                common_mode_support=_support(assessment, Hypothesis.COMMON_MODE_PROCESS_CHANGE),
                measurement_system_support=_support(assessment, Hypothesis.METROLOGY_SYSTEM_SHIFT),
            )
        )
    return tuple(output)


def build_quality_dataset(
    *,
    target: QualityTargetDefinition,
    states: Iterable[EquipmentStateVector],
    outcomes: Iterable[QualityOutcomeObservation],
    knowledge_cutoff: datetime,
    created_at: datetime | None = None,
    measurement_integrity_by_execution: Mapping[str, float] | None = None,
    prediction_cutoff_by_execution: Mapping[str, datetime] | None = None,
    strict_leakage: bool = True,
) -> QualityDatasetSnapshot:
    """Build a no-lookahead quality training snapshot.

    Only mature outcomes known by ``knowledge_cutoff`` are admitted. Equipment state
    must have been known by the declared prediction cutoff, while the target outcome
    must *not* have been known at prediction time. Intervention-censored outcomes are
    excluded rather than mislabeled healthy.
    """

    state_by_execution = {state.execution_id: state for state in states}
    integrity = measurement_integrity_by_execution or {}
    cutoffs = prediction_cutoff_by_execution or {}
    rows: list[QualityTrainingRow] = []
    excluded_not_mature = 0
    excluded_censored = 0
    excluded_leakage = 0
    excluded_missing_state = 0

    censored = {
        OutcomeMaturityState.HELD,
        OutcomeMaturityState.SCRAPPED_BEFORE_OUTCOME,
        OutcomeMaturityState.REROUTED,
        OutcomeMaturityState.REWORKED,
        OutcomeMaturityState.LOST_TO_FOLLOWUP,
    }

    for outcome in outcomes:
        if outcome.target_id != target.target_id:
            continue
        state = state_by_execution.get(outcome.execution_id)
        if state is None:
            excluded_missing_state += 1
            continue
        if outcome.maturity in censored:
            excluded_censored += 1
            continue
        if outcome.maturity is not OutcomeMaturityState.MATURE_AVAILABLE or outcome.available_at > knowledge_cutoff:
            excluded_not_mature += 1
            continue
        prediction_cutoff = cutoffs.get(outcome.execution_id, state.known_at)
        if state.known_at > prediction_cutoff or outcome.available_at <= prediction_cutoff:
            if strict_leakage:
                raise ValueError(
                    f"quality leakage for execution {outcome.execution_id}: "
                    f"state_known={state.known_at.isoformat()} cutoff={prediction_cutoff.isoformat()} "
                    f"outcome_available={outcome.available_at.isoformat()}"
                )
            excluded_leakage += 1
            continue
        measurement_integrity = float(integrity.get(outcome.execution_id, 1.0))
        rows.append(
            QualityTrainingRow(
                material_id=outcome.material_id,
                execution_id=outcome.execution_id,
                asset_id=outcome.asset_id,
                context=outcome.context,
                prediction_cutoff=prediction_cutoff,
                equipment_known_at=state.known_at,
                outcome_available_at=outcome.available_at,
                outcome_maturity=outcome.maturity,
                outcome_value=float(outcome.value),
                behavioral_novelty=state.behavioral_novelty,
                health_confidence=state.health_confidence,
                local_support=state.local_support,
                common_mode_support=state.common_mode_support,
                measurement_system_support=state.measurement_system_support,
                measurement_integrity_confidence=measurement_integrity,
                sampling_reason=outcome.sampling_reason,
            )
        )

    rows.sort(key=lambda row: (row.prediction_cutoff, row.execution_id))
    created = created_at or knowledge_cutoff
    manifest = QualityDatasetManifest(
        dataset_id=f"quality:{target.target_id}:{target.version}:{knowledge_cutoff.isoformat()}",
        target_id=target.target_id,
        target_version=target.version,
        created_at=created,
        knowledge_cutoff=knowledge_cutoff,
        row_count=len(rows),
        excluded_not_mature=excluded_not_mature,
        excluded_intervention_censored=excluded_censored,
        excluded_leakage=excluded_leakage,
        excluded_missing_state=excluded_missing_state,
    )
    return QualityDatasetSnapshot(manifest=manifest, target=target, rows=tuple(rows))
