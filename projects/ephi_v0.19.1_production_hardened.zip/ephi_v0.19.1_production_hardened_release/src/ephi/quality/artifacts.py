from __future__ import annotations

import hashlib
import json
from pathlib import Path

import joblib
from pydantic import BaseModel, ConfigDict

from ephi.quality.modeling import QualityModelBundle


class QualityModelArtifactMetadata(BaseModel):
    model_config = ConfigDict(frozen=True)

    schema_version: str = "1"
    target_id: str
    target_version: str
    target_type: str
    calibration_method: str
    uncertainty_method: str | None
    equipment_state_useful: bool
    feature_contract: tuple[str, ...] = (
        "context:operation",
        "context:recipe_id",
        "context:product_id",
        "context:technology",
        "equipment:behavioral_novelty",
        "equipment:health_confidence",
        "equipment:local_support",
        "equipment:common_mode_support",
        "equipment:measurement_system_support",
    )
    model_sha256: str


def save_quality_model_bundle(bundle: QualityModelBundle, directory: str | Path) -> QualityModelArtifactMetadata:
    """Persist a trusted internal sklearn bundle plus explicit compatibility metadata.

    Joblib/sklearn serialization is pickle-based and must only be loaded from trusted,
    content-hashed EPHI artifact storage. The metadata is the compatibility contract;
    the binary alone is never considered a production model identity.
    """
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=True)
    model_path = root / "model.joblib"
    joblib.dump(bundle, model_path, compress=3)
    digest = hashlib.sha256(model_path.read_bytes()).hexdigest()
    metadata = QualityModelArtifactMetadata(
        target_id=bundle.target.target_id,
        target_version=bundle.target.version,
        target_type=bundle.target.target_type.value,
        calibration_method=bundle.comparison.calibration_method,
        uncertainty_method=bundle.comparison.uncertainty_method,
        equipment_state_useful=bundle.comparison.equipment_state_useful,
        model_sha256=digest,
    )
    (root / "metadata.json").write_text(
        json.dumps(metadata.model_dump(mode="json"), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return metadata


def load_quality_model_bundle(directory: str | Path) -> QualityModelBundle:
    root = Path(directory)
    metadata = QualityModelArtifactMetadata.model_validate_json((root / "metadata.json").read_text(encoding="utf-8"))
    model_path = root / "model.joblib"
    actual = hashlib.sha256(model_path.read_bytes()).hexdigest()
    if actual != metadata.model_sha256:
        raise ValueError("quality model artifact content hash mismatch")
    bundle = joblib.load(model_path)
    if not isinstance(bundle, QualityModelBundle):
        raise TypeError("artifact does not contain a QualityModelBundle")
    if bundle.target.target_id != metadata.target_id or bundle.target.version != metadata.target_version:
        raise ValueError("quality model metadata/target compatibility mismatch")
    return bundle
