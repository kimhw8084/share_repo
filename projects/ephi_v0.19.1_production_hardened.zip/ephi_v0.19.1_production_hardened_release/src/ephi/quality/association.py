from __future__ import annotations

from collections import defaultdict
from math import sqrt
from statistics import mean, variance
from typing import Iterable, Mapping

from ephi.domain.quality import (
    QualityAssociationEvidence,
    QualityEvidenceState,
    QualityStage,
    QualityTargetDefinition,
    QualityTrainingRow,
)


def build_quality_association(
    *,
    target: QualityTargetDefinition,
    rows: Iterable[QualityTrainingRow],
    exposed_execution_ids: set[str] | frozenset[str],
    predictive_increment: float | None = None,
    minimum_controls_per_exposed: int = 1,
    measurement_integrity_by_execution: Mapping[str, float] | None = None,
) -> QualityAssociationEvidence:
    """Build transparent exposed-vs-context-matched control evidence.

    This is observational support, not causal proof. Controls are exact-context rows;
    future route/genealogy matching belongs to the company/historical qualification layer.
    """

    rows_t = tuple(rows)
    exposed = [row for row in rows_t if row.execution_id in exposed_execution_ids]
    controls_by_context: dict[str, list[QualityTrainingRow]] = defaultdict(list)
    for row in rows_t:
        if row.execution_id not in exposed_execution_ids:
            controls_by_context[row.context.stable_key()].append(row)

    matched_controls: dict[str, QualityTrainingRow] = {}
    covered = 0
    for item in exposed:
        candidates = controls_by_context.get(item.context.stable_key(), [])
        if len(candidates) < minimum_controls_per_exposed:
            continue
        # Prefer the nearest historical/contemporaneous context control without using outcome.
        chosen = min(candidates, key=lambda row: abs((row.prediction_cutoff - item.prediction_cutoff).total_seconds()))
        matched_controls[chosen.execution_id] = chosen
        covered += 1

    controls = list(matched_controls.values())
    if not exposed:
        return QualityAssociationEvidence(
            target_id=target.target_id,
            target_version=target.version,
            stage=target.stage,
            evidence_state=QualityEvidenceState.UNAVAILABLE,
            exposed_count=0,
            control_count=len(controls),
            temporal_consistency=0.0,
            control_robustness=0.0,
            sampling_confidence=0.0,
            measurement_integrity_confidence=0.0,
            maturity_confidence=0.0,
            association_confidence=0.0,
            contradictions=("NO_EXPOSED_MATERIAL",),
        )
    if not controls:
        return QualityAssociationEvidence(
            target_id=target.target_id,
            target_version=target.version,
            stage=target.stage,
            evidence_state=QualityEvidenceState.UNAVAILABLE,
            exposed_count=len(exposed),
            control_count=0,
            temporal_consistency=1.0,
            control_robustness=0.0,
            sampling_confidence=1.0,
            measurement_integrity_confidence=min(row.measurement_integrity_confidence for row in exposed),
            maturity_confidence=1.0,
            association_confidence=0.0,
            contradictions=("NO_MATCHED_CONTROLS",),
        )

    exposed_values = [row.outcome_value for row in exposed]
    control_values = [row.outcome_value for row in controls]
    exposed_mean = float(mean(exposed_values))
    control_mean = float(mean(control_values))
    effect = exposed_mean - control_mean
    var_e = variance(exposed_values) if len(exposed_values) > 1 else 0.0
    var_c = variance(control_values) if len(control_values) > 1 else 0.0
    se = sqrt(var_e / max(len(exposed_values), 1) + var_c / max(len(control_values), 1))
    control_robustness = min(1.0, covered / max(len(exposed), 1))
    sample_confidence = min(1.0, sqrt(min(len(exposed), len(controls)) / 25.0))
    integrity_values = [row.measurement_integrity_confidence for row in exposed + controls]
    measurement_integrity = float(mean(integrity_values)) if integrity_values else 0.0
    scheduled = sum(1 for row in exposed + controls if not row.sampling_reason or "AD_HOC" not in row.sampling_reason.upper())
    sampling_confidence = scheduled / max(len(exposed) + len(controls), 1)
    confidence_components = [control_robustness, sample_confidence, sampling_confidence]
    if target.stage is not QualityStage.MEASUREMENT_SYSTEM:
        confidence_components.append(measurement_integrity)
    association_confidence = min(confidence_components)

    if target.harmful_direction == "UPPER":
        harmful_effect = effect
    elif target.harmful_direction == "LOWER":
        harmful_effect = -effect
    else:
        harmful_effect = abs(effect)
    practical = harmful_effect >= target.minimum_practical_effect
    opposite = target.harmful_direction != "TWO_SIDED" and harmful_effect <= -target.minimum_practical_effect
    strong = practical and association_confidence >= 0.75 and harmful_effect >= max(target.minimum_practical_effect * 2.0, 1e-12)
    if opposite:
        state = QualityEvidenceState.CONTRADICTED
    elif strong:
        state = QualityEvidenceState.STRONG_ASSOCIATION
    elif practical and association_confidence >= 0.5:
        state = QualityEvidenceState.SUPPORTED_ASSOCIATION
    elif practical:
        state = QualityEvidenceState.WEAK_ASSOCIATION
    else:
        state = QualityEvidenceState.NO_OBSERVED_ASSOCIATION

    contradictions: list[str] = []
    if measurement_integrity < 0.5 and target.measurement_system_sensitive and target.stage is not QualityStage.MEASUREMENT_SYSTEM:
        contradictions.append("MEASUREMENT_SYSTEM_INTEGRITY_LOW")
        association_confidence *= measurement_integrity
        if state in {QualityEvidenceState.STRONG_ASSOCIATION, QualityEvidenceState.SUPPORTED_ASSOCIATION}:
            state = QualityEvidenceState.WEAK_ASSOCIATION

    return QualityAssociationEvidence(
        target_id=target.target_id,
        target_version=target.version,
        stage=target.stage,
        evidence_state=state,
        exposed_count=len(exposed),
        control_count=len(controls),
        exposed_mean=exposed_mean,
        control_mean=control_mean,
        adjusted_effect=float(effect),
        effect_standard_error=float(se),
        predictive_increment=predictive_increment,
        temporal_consistency=1.0,
        control_robustness=control_robustness,
        sampling_confidence=sampling_confidence,
        measurement_integrity_confidence=measurement_integrity,
        maturity_confidence=1.0,
        association_confidence=float(max(0.0, min(association_confidence, 1.0))),
        contradictions=tuple(contradictions),
        metadata={"matching": "EXACT_CONTEXT_NEAREST_TIME", "causal_claim": False},
    )
