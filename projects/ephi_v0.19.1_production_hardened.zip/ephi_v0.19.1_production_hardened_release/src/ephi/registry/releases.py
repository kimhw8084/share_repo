from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field

from ephi.config import EphiConfig
from ephi.version import __version__


class ReleaseManifest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    release_id: str
    package_version: str
    created_at: str
    code_tree_sha256: str
    config_sha256: str
    benchmark_sha256: dict[str, str]
    qualification_sha256: dict[str, str] = Field(default_factory=dict)
    deployment_sha256: dict[str, str] = Field(default_factory=dict)
    state_schema_version: str = "2"
    schema_version: str = "2"


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _code_tree_hash(root: Path) -> str:
    digest = hashlib.sha256()
    files: set[Path] = set()
    for base in (root / "src" / "ephi", root / "configs", root / "company_port", root / "scripts", root / "company_bindings", root / ".opencode", root / "docs" ):
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if not path.is_file():
                continue
            relative_parts = path.relative_to(root).parts
            if any(
                part in {"__pycache__", ".pytest_cache", "build", "dist"}
                or part.endswith(".egg-info")
                for part in relative_parts
            ) or path.suffix in {".pyc", ".pyo"}:
                continue
            if base == root / "company_port":
                allowed = path.suffix in {".py", ".yaml", ".yml", ".toml", ".example", ".sh"} or path.name == "Dockerfile"
            elif base == root / "scripts":
                allowed = path.suffix in {".py", ".sh"}
            elif base in {root / "company_bindings", root / ".opencode", root / "docs"}:
                allowed = path.suffix in {".sql", ".yaml", ".yml", ".md", ".json"}
            else:
                allowed = path.suffix in {".py", ".yaml", ".yml", ".example"}
            if allowed:
                files.add(path)
    # Package/deployment metadata affects the executable release identity as well.
    for path in (root / "pyproject.toml", root / "Dockerfile", root / ".env.example", root / "AGENTS.md", root / "opencode.json", root / "CUSTOMIZATION_MAP.yaml", root / "PORTING_START_HERE.md"):
        if path.exists() and path.is_file():
            files.add(path)
    for path in sorted(files):
        relative = path.relative_to(root).as_posix().encode("utf-8")
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        content = path.read_bytes()
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return digest.hexdigest()


def build_release_manifest(
    root: str | Path,
    config: EphiConfig,
    *,
    benchmark_files: tuple[str | Path, ...] = (),
    qualification_files: tuple[str | Path, ...] = (),
    deployment_files: tuple[str | Path, ...] = (),
    state_schema_version: str = "2",
    created_at: datetime | None = None,
) -> ReleaseManifest:
    root = Path(root).resolve()
    def collect(files: tuple[str | Path, ...]) -> dict[str, str]:
        hashes: dict[str, str] = {}
        for raw in files:
            path = Path(raw)
            if not path.is_absolute():
                path = root / path
            if not path.exists():
                raise FileNotFoundError(path)
            hashes[path.relative_to(root).as_posix()] = _sha256_file(path)
        return hashes

    benchmark_hashes = collect(benchmark_files)
    qualification_hashes = collect(qualification_files)
    deployment_hashes = collect(deployment_files)

    code_hash = _code_tree_hash(root)
    config_hash = config.stable_hash()
    release_id = f"ephi-{__version__}-{code_hash[:12]}-{config_hash[:12]}"
    timestamp = created_at or datetime.now(timezone.utc)
    return ReleaseManifest(
        release_id=release_id,
        package_version=__version__,
        created_at=timestamp.isoformat(),
        code_tree_sha256=code_hash,
        config_sha256=config_hash,
        benchmark_sha256=benchmark_hashes,
        qualification_sha256=qualification_hashes,
        deployment_sha256=deployment_hashes,
        state_schema_version=state_schema_version,
    )
