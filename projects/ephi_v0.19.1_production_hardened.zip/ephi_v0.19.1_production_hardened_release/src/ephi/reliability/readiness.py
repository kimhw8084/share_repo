from __future__ import annotations

from ephi.domain.operations import FreshnessState, OperationalSLOReport
from ephi.reliability.models import (
    CapabilityReadiness,
    DegradedModeAssessment,
    ServiceAvailability,
)


_CAPABILITIES: dict[str, tuple[str, ...]] = {
    "analytical_scoring": ("source", "canonical", "feature", "reference", "peer"),
    "advisory_reads": ("assessment",),
    "notification_delivery": ("assessment",),
    "exposure_priority": ("assessment", "wip"),
    "quality_harmfulness": ("assessment", "quality_model"),
    "historical_rca": ("assessment", "historical_index"),
    "value_roi": ("value_reconciliation",),
}


def assess_degraded_mode(report: OperationalSLOReport) -> DegradedModeAssessment:
    states = {item.metric: item.state for item in report.observations}
    results: list[CapabilityReadiness] = []
    for capability, dependencies in _CAPABILITIES.items():
        bad = [name for name in dependencies if states.get(name) in {FreshnessState.STALE, FreshnessState.UNKNOWN}]
        degraded = [name for name in dependencies if states.get(name) == FreshnessState.DEGRADED]
        missing = [name for name in dependencies if name not in states]
        reasons: list[str] = []
        # Historical/advisory materialized reads can remain visible while stale, but are
        # explicitly degraded; new scoring/priority/notifications must fail closed.
        stale_read_allowed = capability in {"advisory_reads", "historical_rca", "value_roi"}
        if bad or missing:
            reasons.extend(f"{name} unavailable/stale" for name in (*bad, *missing))
            availability = ServiceAvailability.DEGRADED if stale_read_allowed else ServiceAvailability.UNAVAILABLE
        elif degraded:
            reasons.extend(f"{name} degraded" for name in degraded)
            availability = ServiceAvailability.DEGRADED
        else:
            availability = ServiceAvailability.AVAILABLE
        results.append(
            CapabilityReadiness(
                capability=capability,
                availability=availability,
                reasons=tuple(reasons),
            )
        )
    return DegradedModeAssessment(capabilities=tuple(results))
