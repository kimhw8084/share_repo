from __future__ import annotations

import base64
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from ephi.adapters.base.artifact_store import ArtifactRef, ArtifactStore
from ephi.adapters.base.state_store import SnapshotStateStore, StateRecord
from ephi.reliability.models import (
    RecoveryAssessment,
    RecoveryState,
    SnapshotRecordModel,
    StateBackupBundle,
    StateDurability,
    StateNamespacePolicy,
)


def _sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _canonical_bundle_payload(
    *,
    bundle_id: str,
    source_release_id: str,
    state_schema_version: str,
    created_at: datetime,
    policies: tuple[StateNamespacePolicy, ...],
    records: tuple[SnapshotRecordModel, ...],
) -> bytes:
    raw = {
        "bundle_id": bundle_id,
        "source_release_id": source_release_id,
        "state_schema_version": state_schema_version,
        "created_at": created_at.isoformat(),
        "policies": [item.model_dump(mode="json") for item in policies],
        "records": [item.model_dump(mode="json") for item in records],
        "schema_version": "state_backup_v1",
    }
    return json.dumps(raw, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _policy_for_key(key: str, policies: tuple[StateNamespacePolicy, ...]) -> StateNamespacePolicy | None:
    matches = [item for item in policies if key.startswith(item.prefix)]
    if not matches:
        return None
    return max(matches, key=lambda item: len(item.prefix))


def build_backup_bundle(
    store: SnapshotStateStore,
    *,
    policies: tuple[StateNamespacePolicy, ...],
    source_release_id: str,
    state_schema_version: str,
    created_at: datetime | None = None,
    bundle_id: str | None = None,
    fail_on_unclassified: bool = True,
) -> StateBackupBundle:
    when = created_at or datetime.now(timezone.utc)
    state_records = store.snapshot()
    unclassified = tuple(record.key for record in state_records if _policy_for_key(record.key, policies) is None)
    if unclassified and fail_on_unclassified:
        raise ValueError(
            "state backup policy does not classify keys: " + ", ".join(sorted(unclassified))
        )
    records = tuple(
        SnapshotRecordModel(
            key=record.key,
            version=record.version,
            updated_at=record.updated_at,
            value_b64=base64.b64encode(record.value).decode("ascii"),
            value_sha256=_sha256(record.value),
        )
        for record in state_records
        if _policy_for_key(record.key, policies) is not None
    )
    identifier = bundle_id or f"BACKUP-{when.strftime('%Y%m%dT%H%M%SZ')}-{uuid4().hex[:8]}"
    canonical = _canonical_bundle_payload(
        bundle_id=identifier,
        source_release_id=source_release_id,
        state_schema_version=state_schema_version,
        created_at=when,
        policies=policies,
        records=records,
    )
    return StateBackupBundle(
        bundle_id=identifier,
        source_release_id=source_release_id,
        state_schema_version=state_schema_version,
        created_at=when,
        policies=policies,
        records=records,
        content_sha256=_sha256(canonical),
    )


def validate_backup_bundle(bundle: StateBackupBundle) -> None:
    canonical = _canonical_bundle_payload(
        bundle_id=bundle.bundle_id,
        source_release_id=bundle.source_release_id,
        state_schema_version=bundle.state_schema_version,
        created_at=bundle.created_at,
        policies=bundle.policies,
        records=bundle.records,
    )
    if _sha256(canonical) != bundle.content_sha256:
        raise ValueError("backup bundle checksum mismatch")
    for item in bundle.records:
        value = base64.b64decode(item.value_b64.encode("ascii"), validate=True)
        if _sha256(value) != item.value_sha256:
            raise ValueError(f"backup record checksum mismatch: {item.key}")
    keys = tuple(item.key for item in bundle.records)
    missing_authoritative = [
        policy.prefix
        for policy in bundle.policies
        if policy.required
        and policy.durability == StateDurability.AUTHORITATIVE
        and not any(key.startswith(policy.prefix) for key in keys)
    ]
    if missing_authoritative:
        raise ValueError(
            "backup missing required authoritative namespaces: "
            + ", ".join(sorted(missing_authoritative))
        )


def write_backup_bundle(bundle: StateBackupBundle, path: str | Path) -> Path:
    validate_backup_bundle(bundle)
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(bundle.model_dump_json(indent=2), encoding="utf-8")
    return output


def load_backup_bundle(path: str | Path) -> StateBackupBundle:
    bundle = StateBackupBundle.model_validate_json(Path(path).read_text(encoding="utf-8"))
    validate_backup_bundle(bundle)
    return bundle


def records_from_bundle(bundle: StateBackupBundle) -> tuple[StateRecord, ...]:
    validate_backup_bundle(bundle)
    return tuple(
        StateRecord(
            key=item.key,
            version=item.version,
            updated_at=item.updated_at,
            value=base64.b64decode(item.value_b64.encode("ascii"), validate=True),
        )
        for item in bundle.records
    )


def restore_backup_bundle(
    store: SnapshotStateStore,
    bundle: StateBackupBundle,
    *,
    require_empty: bool = True,
) -> None:
    store.restore_snapshot(records_from_bundle(bundle), require_empty=require_empty)


def assess_inventory(
    records: tuple[StateRecord, ...],
    policies: tuple[StateNamespacePolicy, ...],
) -> RecoveryAssessment:
    keys = tuple(item.key for item in records)
    missing_authoritative: list[str] = []
    missing_rebuildable: list[str] = []
    advisory_blockers: list[str] = []
    reasons: list[str] = []
    for policy in policies:
        present = any(key.startswith(policy.prefix) for key in keys)
        if not policy.required or present:
            continue
        if policy.durability == StateDurability.AUTHORITATIVE:
            missing_authoritative.append(policy.prefix)
            reasons.append(f"missing authoritative namespace {policy.prefix}")
        else:
            missing_rebuildable.append(policy.prefix)
            reasons.append(f"missing rebuildable namespace {policy.prefix}")
        if policy.required_for_advisory:
            advisory_blockers.append(policy.prefix)
    if missing_authoritative:
        state = RecoveryState.BLOCKED
    elif missing_rebuildable:
        state = RecoveryState.REBUILD_REQUIRED
    else:
        state = RecoveryState.READY
    return RecoveryAssessment(
        state=state,
        missing_authoritative=tuple(missing_authoritative),
        missing_rebuildable=tuple(missing_rebuildable),
        advisory_blockers=tuple(advisory_blockers),
        reasons=tuple(reasons),
    )


def select_latest_valid_backup(paths: tuple[str | Path, ...]) -> StateBackupBundle:
    valid: list[StateBackupBundle] = []
    for path in paths:
        try:
            valid.append(load_backup_bundle(path))
        except (ValueError, OSError, json.JSONDecodeError):
            continue
    if not valid:
        raise ValueError("no valid backup bundle available")
    return max(valid, key=lambda item: (item.created_at, item.bundle_id))


def publish_backup_bundle(
    bundle: StateBackupBundle,
    artifact_store: ArtifactStore,
    *,
    staging_dir: str | Path,
) -> ArtifactRef:
    """Publish a validated backup through the immutable artifact-store boundary."""
    staging = Path(staging_dir)
    staging.mkdir(parents=True, exist_ok=True)
    path = write_backup_bundle(bundle, staging / f"{bundle.bundle_id}.json")
    return artifact_store.put(
        bundle.bundle_id,
        path,
        metadata={
            "kind": "ephi-state-backup",
            "source_release_id": bundle.source_release_id,
            "state_schema_version": bundle.state_schema_version,
            "bundle_content_sha256": bundle.content_sha256,
            "created_at": bundle.created_at.isoformat(),
        },
    )


def load_backup_artifact(artifact_store: ArtifactStore, ref: ArtifactRef) -> StateBackupBundle:
    return load_backup_bundle(artifact_store.materialize(ref))
