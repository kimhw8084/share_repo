from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory

from ephi.adapters.local.filesystem_artifact_store import FileSystemArtifactStore
from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.config import EphiConfig
from ephi.domain.operations import ReleaseCompatibilityState
from ephi.operations.release import assess_release_compatibility
from ephi.operations.controls import OperationalControlService
from ephi.onboarding.control_repository import QualificationWorkspaceRepository
from ephi.domain.operations import ControlKind, ControlScope
from ephi.domain.value import BenefitClaimGroup
from ephi.value.service import ValueLedgerService
from ephi.value.checkpoint import save_value_ledger_state, restore_value_ledger_state
from ephi.operations.telemetry import evaluate_freshness
from ephi.registry.releases import build_release_manifest
from ephi.health.checkpoint import restore_pipeline_state
from ephi.health.engine import BehavioralHealthPipeline
from ephi.reliability.migration import default_migration_registry
from ephi.reliability.models import (
    RecoveryState,
    ReliabilityQualificationReport,
    ServiceAvailability,
    StateDurability,
    StateNamespacePolicy,
)
from ephi.reliability.readiness import assess_degraded_mode
from ephi.reliability.snapshot import (
    assess_inventory,
    build_backup_bundle,
    load_backup_bundle,
    load_backup_artifact,
    publish_backup_bundle,
    restore_backup_bundle,
    select_latest_valid_backup,
    write_backup_bundle,
)
from ephi.runtime.idempotency import AppliedWorkLedger
from ephi.operations.worker import WorkerHost
from ephi.runtime.queue import DurableWorkQueue


def reference_policies() -> tuple[StateNamespacePolicy, ...]:
    return (
        StateNamespacePolicy(
            prefix="business:value-ledger",
            durability=StateDurability.AUTHORITATIVE,
            required=True,
        ),
        StateNamespacePolicy(
            prefix="onboarding:qualification-control:",
            durability=StateDurability.AUTHORITATIVE,
            required=True,
            required_for_advisory=True,
        ),
        StateNamespacePolicy(
            prefix="operations:controls:",
            durability=StateDurability.AUTHORITATIVE,
            required=True,
            required_for_advisory=True,
        ),
        StateNamespacePolicy(
            prefix="pipeline:behavioral",
            durability=StateDurability.REBUILDABLE,
            required=True,
            required_for_advisory=True,
        ),
    )


def _seed(store: SqliteStateStore, *, now: datetime) -> None:
    value = ValueLedgerService()
    value.register_claim_group(
        BenefitClaimGroup(
            claim_group_id="CG-DR",
            economic_event_key="DR-EVENT",
            episode_ids=("EP-DR",),
            description="disaster recovery qualification",
            created_at=now,
        )
    )
    save_value_ledger_state(value, store)

    workspace = QualificationWorkspaceRepository(store)
    workspace.mutate(
        "MET",
        lambda current: current.model_copy(update={"updated_at": now}),
    )

    controls = OperationalControlService(store)
    controls.activate(
        kind=ControlKind.NOTIFICATIONS,
        scope=ControlScope.FAMILY,
        target="MET",
        reason="DR qualification control",
        actor="qualification",
        activated_at=now,
    )

    store.compare_and_set(
        "pipeline:behavioral",
        expected_version=None,
        value=b'{"schema":"behavioral_pipeline_state_v2","detector":{},"episodes":{},"fleet_episodes":{}}',
    )


def run_reliability_qualification(*, created_at: datetime | None = None) -> ReliabilityQualificationReport:
    now = created_at or datetime.now(timezone.utc)
    policies = reference_policies()

    with TemporaryDirectory() as temp_dir:
        root = Path(temp_dir)
        source_store = SqliteStateStore(root / "source.sqlite3")
        _seed(source_store, now=now)
        original = source_store.snapshot()
        bundle = build_backup_bundle(
            source_store,
            policies=policies,
            source_release_id="ephi-reliability-reference",
            state_schema_version="2",
            created_at=now,
            bundle_id="BACKUP-GOOD",
        )
        good_path = write_backup_bundle(bundle, root / "good.json")

        target_store = SqliteStateStore(root / "target.sqlite3")
        restore_backup_bundle(target_store, load_backup_bundle(good_path))
        restored = target_store.snapshot()
        backup_restore_exact = original == restored
        restored_value = ValueLedgerService()
        restore_value_ledger_state(restored_value, target_store)
        restored_workspace = QualificationWorkspaceRepository(target_store).load("MET")
        restored_controls = OperationalControlService(target_store).active_controls(as_of=now)
        authoritative_state_survives_restore = (
            restored_value.repository.claim_group("CG-DR").economic_event_key == "DR-EVENT"
            and restored_workspace.family_id == "MET"
            and restored_workspace.updated_at == now
            and len(restored_controls) == 1
            and restored_controls[0].target == "MET"
        )

        corrupt_raw = json.loads(good_path.read_text(encoding="utf-8"))
        corrupt_raw["records"][0]["value_b64"] = "AAAA"
        corrupt_path = root / "corrupt.json"
        corrupt_path.write_text(json.dumps(corrupt_raw), encoding="utf-8")
        try:
            load_backup_bundle(corrupt_path)
            corrupt_backup_rejected = False
        except ValueError:
            corrupt_backup_rejected = True

        unclassified_store = SqliteStateStore(root / "unclassified.sqlite3")
        unclassified_store.compare_and_set("unknown:new-state", expected_version=None, value=b"x")
        try:
            build_backup_bundle(
                unclassified_store,
                policies=policies,
                source_release_id="R",
                state_schema_version="2",
            )
            unclassified_state_blocked = False
        except ValueError:
            unclassified_state_blocked = True

        dirty_target = SqliteStateStore(root / "dirty.sqlite3")
        dirty_target.compare_and_set("stale:key", expected_version=None, value=b"stale")
        try:
            restore_backup_bundle(dirty_target, bundle)
            clean_target_restore_enforced = False
        except ValueError:
            clean_target_restore_enforced = True

        corrupt_checkpoint_store = SqliteStateStore(root / "corrupt-checkpoint.sqlite3")
        corrupt_checkpoint_store.compare_and_set("pipeline:behavioral", expected_version=None, value=b"not-json")
        try:
            restore_pipeline_state(BehavioralHealthPipeline(), corrupt_checkpoint_store)
            checkpoint_corruption_fails_closed = False
        except Exception:
            checkpoint_corruption_fails_closed = True

        artifact_store = FileSystemArtifactStore(root / "artifacts")
        artifact_ref = publish_backup_bundle(bundle, artifact_store, staging_dir=root / "staging")
        immutable_artifact_roundtrip = load_backup_artifact(artifact_store, artifact_ref) == bundle

        without_auth = tuple(
            record for record in restored if not record.key.startswith("onboarding:qualification-control:")
        )
        incomplete_authoritative_blocks = assess_inventory(without_auth, policies).state == RecoveryState.BLOCKED
        without_rebuildable = tuple(
            record for record in restored if not record.key.startswith("pipeline:behavioral")
        )
        missing_rebuildable_requires_rebuild = (
            assess_inventory(without_rebuildable, policies).state == RecoveryState.REBUILD_REQUIRED
        )
        chosen = select_latest_valid_backup((corrupt_path, good_path))
        previous_valid_backup_selected = chosen.bundle_id == "BACKUP-GOOD"

        registry = default_migration_registry()
        v1_payload = json.dumps(
            {
                "schema": "behavioral_pipeline_state_v1",
                "detector": {"x": 1},
                "episodes": {"y": 2},
            },
            sort_keys=True,
        ).encode("utf-8")
        migrated_a = registry.migrate(
            "behavioral-pipeline",
            v1_payload,
            from_schema="behavioral_pipeline_state_v1",
            to_schema="behavioral_pipeline_state_v2",
        )
        migrated_b = registry.migrate(
            "behavioral-pipeline",
            v1_payload,
            from_schema="behavioral_pipeline_state_v1",
            to_schema="behavioral_pipeline_state_v2",
        )
        deterministic_migration = migrated_a.payload == migrated_b.payload and migrated_a.after_sha256 == migrated_b.after_sha256
        semantic_migration_preserved = migrated_a.semantic_sha256 is not None

        release_root = root / "release"
        (release_root / "src" / "ephi").mkdir(parents=True)
        (release_root / "configs").mkdir()
        (release_root / "src" / "ephi" / "x.py").write_text("x=1\n", encoding="utf-8")
        source_release = build_release_manifest(release_root, EphiConfig(), created_at=now)
        target_release = build_release_manifest(release_root, EphiConfig(), created_at=now + timedelta(seconds=1))
        compatibility = assess_release_compatibility(
            source_release,
            target_release,
            source_state_schema_version="1",
            target_state_schema_version="2",
            migration_available=True,
            migration_reversible=False,
        )
        irreversible_migration_blocks_rollback = (
            compatibility.state == ReleaseCompatibilityState.REQUIRES_MIGRATION
            and not compatibility.rollback_allowed
        )

        queue_path = root / "queue.sqlite3"
        queue = DurableWorkQueue(SqliteStateStore(queue_path))
        first = queue.enqueue("SCORE", work_id="W1", payload={"x": 1}, created_at=now)
        same = queue.enqueue("SCORE", work_id="W1", payload={"x": 1}, created_at=now)
        duplicate_work_idempotent = first == same and len(queue.items()) == 1
        try:
            queue.enqueue("SCORE", work_id="W1", payload={"x": 2}, created_at=now)
            conflicting_duplicate_rejected = False
        except ValueError:
            conflicting_duplicate_rejected = True

        queue.enqueue("STEP2", work_id="W2", depends_on=("W1",), created_at=now - timedelta(seconds=1), priority=0)
        blocked_claim = queue.claim(worker_id="dep", accepted_job_types={"STEP2"}, now=now)
        first_claim = queue.claim(worker_id="dep", accepted_job_types={"SCORE"}, now=now)
        assert first_claim is not None
        queue.complete("W1", worker_id="dep")
        second_claim = queue.claim(worker_id="dep", accepted_job_types={"STEP2"}, now=now)
        work_dependency_order_enforced = blocked_claim is None and second_claim is not None and second_claim.work_id == "W2"

        crash_queue = DurableWorkQueue(SqliteStateStore(root / "crash.sqlite3"))
        crash_queue.enqueue("SCORE", work_id="CRASH", created_at=now)
        lease = crash_queue.claim(worker_id="dead", lease_seconds=5, now=now)
        reclaimed = DurableWorkQueue(SqliteStateStore(root / "crash.sqlite3")).claim(
            worker_id="replacement", lease_seconds=5, now=now + timedelta(seconds=6)
        )
        lease_crash_recovery = lease is not None and reclaimed is not None and reclaimed.leased_by == "replacement"

        race_path = root / "race.sqlite3"
        DurableWorkQueue(SqliteStateStore(race_path)).enqueue("SCORE", work_id="RACE", created_at=now)

        def claim(worker: str):
            return DurableWorkQueue(SqliteStateStore(race_path)).claim(worker_id=worker, now=now)

        with ThreadPoolExecutor(max_workers=8) as pool:
            race_results = list(pool.map(claim, [f"W{i}" for i in range(8)]))
        winners = [item for item in race_results if item is not None]
        concurrent_claim_exactly_once = len(winners) == 1 and winners[0].work_id == "RACE"

        applied_path = root / "applied.sqlite3"
        applied_store = SqliteStateStore(applied_path)
        applied_queue = DurableWorkQueue(applied_store)
        applied_queue.enqueue("APPLY", work_id="APPLIED", payload={"v": 1}, created_at=now)
        already_done = applied_queue.claim(worker_id="crashed", lease_seconds=1, now=now - timedelta(seconds=5))
        assert already_done is not None
        AppliedWorkLedger(applied_store).record(already_done, completed_at=now - timedelta(seconds=4))
        calls: list[str] = []
        replacement = WorkerHost(
            worker_id="replacement",
            queue=DurableWorkQueue(SqliteStateStore(applied_path)),
            handlers={"APPLY": lambda item: calls.append(item.work_id)},
            applied_work=AppliedWorkLedger(SqliteStateStore(applied_path)),
        )
        applied_result = replacement.run_once()
        crash_window_duplicate_suppressed = (
            applied_result is not None and applied_result.status.value == "SUCCEEDED" and calls == []
        )

    targets = {
        "source": (60.0, 300.0),
        "canonical": (60.0, 300.0),
        "feature": (60.0, 300.0),
        "reference": (60.0, 300.0),
        "peer": (60.0, 300.0),
        "assessment": (60.0, 300.0),
        "wip": (60.0, 300.0),
        "quality_model": (3600.0, 7200.0),
        "historical_index": (3600.0, 7200.0),
        "value_reconciliation": (86400.0, 172800.0),
    }
    current = {name: 10.0 for name in targets}
    wip_outage = dict(current)
    wip_outage["wip"] = None
    wip_mode = assess_degraded_mode(evaluate_freshness(as_of=now, observations=wip_outage, targets=targets))
    wip_outage_isolated = (
        wip_mode.get("analytical_scoring").availability == ServiceAvailability.AVAILABLE
        and wip_mode.get("exposure_priority").availability == ServiceAvailability.UNAVAILABLE
    )
    source_outage = dict(current)
    source_outage["source"] = 9999.0
    source_mode = assess_degraded_mode(evaluate_freshness(as_of=now, observations=source_outage, targets=targets))
    source_outage_blocks_scoring = source_mode.get("analytical_scoring").availability == ServiceAvailability.UNAVAILABLE

    checks = {
        "backup_restore_exact": backup_restore_exact,
        "corrupt_backup_rejected": corrupt_backup_rejected,
        "unclassified_state_blocked": unclassified_state_blocked,
        "clean_target_restore_enforced": clean_target_restore_enforced,
        "checkpoint_corruption_fails_closed": checkpoint_corruption_fails_closed,
        "immutable_artifact_roundtrip": immutable_artifact_roundtrip,
        "incomplete_authoritative_blocks": incomplete_authoritative_blocks,
        "missing_rebuildable_requires_rebuild": missing_rebuildable_requires_rebuild,
        "previous_valid_backup_selected": previous_valid_backup_selected,
        "deterministic_migration": deterministic_migration,
        "semantic_migration_preserved": semantic_migration_preserved,
        "irreversible_migration_blocks_rollback": irreversible_migration_blocks_rollback,
        "duplicate_work_idempotent": duplicate_work_idempotent,
        "conflicting_duplicate_rejected": conflicting_duplicate_rejected,
        "work_dependency_order_enforced": work_dependency_order_enforced,
        "lease_crash_recovery": lease_crash_recovery,
        "concurrent_claim_exactly_once": concurrent_claim_exactly_once,
        "crash_window_duplicate_suppressed": crash_window_duplicate_suppressed,
        "wip_outage_isolated": wip_outage_isolated,
        "source_outage_blocks_scoring": source_outage_blocks_scoring,
        "authoritative_state_survives_restore": authoritative_state_survives_restore,
    }
    return ReliabilityQualificationReport(passed=all(checks.values()), **checks)
