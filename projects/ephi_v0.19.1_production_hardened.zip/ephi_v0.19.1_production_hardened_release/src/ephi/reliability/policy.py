from __future__ import annotations

from pathlib import Path

import yaml

from ephi.reliability.models import ReliabilityPolicy


def load_reliability_policy(path: str | Path) -> ReliabilityPolicy:
    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    section = raw.get("reliability", raw)
    backup = section.get("backup", {})
    payload = {
        "state_schema_version": section.get("state_schema_version", "1"),
        "policies": backup.get("policies", ()),
        "fail_on_unclassified_state": backup.get("fail_on_unclassified_state", True),
    }
    return ReliabilityPolicy.model_validate(payload)
