from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictFrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class StateDurability(StrEnum):
    AUTHORITATIVE = "AUTHORITATIVE"
    REBUILDABLE = "REBUILDABLE"


class RecoveryState(StrEnum):
    READY = "READY"
    REBUILD_REQUIRED = "REBUILD_REQUIRED"
    BLOCKED = "BLOCKED"


class ServiceAvailability(StrEnum):
    AVAILABLE = "AVAILABLE"
    DEGRADED = "DEGRADED"
    UNAVAILABLE = "UNAVAILABLE"


class StateNamespacePolicy(StrictFrozenModel):
    prefix: str = Field(min_length=1)
    durability: StateDurability
    required: bool = False
    required_for_advisory: bool = False
    description: str | None = None


class ReliabilityPolicy(StrictFrozenModel):
    state_schema_version: str = Field(min_length=1)
    policies: tuple[StateNamespacePolicy, ...]
    fail_on_unclassified_state: bool = True


class SnapshotRecordModel(StrictFrozenModel):
    key: str = Field(min_length=1)
    version: int = Field(ge=1)
    updated_at: datetime
    value_b64: str
    value_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class StateBackupBundle(StrictFrozenModel):
    bundle_id: str = Field(min_length=1)
    source_release_id: str = Field(min_length=1)
    state_schema_version: str = Field(min_length=1)
    created_at: datetime
    policies: tuple[StateNamespacePolicy, ...]
    records: tuple[SnapshotRecordModel, ...]
    content_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    schema_version: str = "state_backup_v1"

    @model_validator(mode="after")
    def unique_keys(self) -> "StateBackupBundle":
        keys = [item.key for item in self.records]
        if len(keys) != len(set(keys)):
            raise ValueError("backup bundle contains duplicate state keys")
        return self


class RecoveryAssessment(StrictFrozenModel):
    state: RecoveryState
    missing_authoritative: tuple[str, ...] = ()
    missing_rebuildable: tuple[str, ...] = ()
    advisory_blockers: tuple[str, ...] = ()
    reasons: tuple[str, ...] = ()


class MigrationResult(StrictFrozenModel):
    domain: str
    from_schema: str
    to_schema: str
    steps: tuple[str, ...]
    before_sha256: str
    after_sha256: str
    semantic_sha256: str | None = None
    reversible: bool
    payload: bytes


class CapabilityReadiness(StrictFrozenModel):
    capability: str
    availability: ServiceAvailability
    reasons: tuple[str, ...] = ()


class DegradedModeAssessment(StrictFrozenModel):
    capabilities: tuple[CapabilityReadiness, ...]

    def get(self, capability: str) -> CapabilityReadiness:
        for item in self.capabilities:
            if item.capability == capability:
                return item
        raise KeyError(capability)


class ReliabilityQualificationReport(StrictFrozenModel):
    passed: bool
    backup_restore_exact: bool
    corrupt_backup_rejected: bool
    unclassified_state_blocked: bool
    clean_target_restore_enforced: bool
    checkpoint_corruption_fails_closed: bool
    immutable_artifact_roundtrip: bool
    incomplete_authoritative_blocks: bool
    missing_rebuildable_requires_rebuild: bool
    previous_valid_backup_selected: bool
    deterministic_migration: bool
    semantic_migration_preserved: bool
    irreversible_migration_blocks_rollback: bool
    duplicate_work_idempotent: bool
    conflicting_duplicate_rejected: bool
    work_dependency_order_enforced: bool
    lease_crash_recovery: bool
    concurrent_claim_exactly_once: bool
    crash_window_duplicate_suppressed: bool
    wip_outage_isolated: bool
    source_outage_blocks_scoring: bool
    authoritative_state_survives_restore: bool
