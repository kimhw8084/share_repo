from __future__ import annotations

import hashlib
import json
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass

from ephi.reliability.models import MigrationResult

JsonObject = dict[str, object]
MigrationFn = Callable[[JsonObject], JsonObject]
SemanticProjector = Callable[[JsonObject], object]


def _canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _sha(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


@dataclass(frozen=True, slots=True)
class MigrationStep:
    domain: str
    from_schema: str
    to_schema: str
    migrate: MigrationFn
    reversible: bool = False
    semantic_projector: SemanticProjector | None = None


class StateMigrationRegistry:
    """Deterministic JSON-state migration registry.

    Migrations are deliberately explicit and domain-scoped. A migration may optionally
    declare a semantic projection; when supplied, EPHI verifies that representation
    changes do not alter the projected scientific/business truth.
    """

    def __init__(self) -> None:
        self._steps: dict[tuple[str, str, str], MigrationStep] = {}

    def register(self, step: MigrationStep) -> None:
        key = (step.domain, step.from_schema, step.to_schema)
        if key in self._steps:
            raise ValueError(f"migration already registered: {key}")
        self._steps[key] = step

    def _path(self, domain: str, source: str, target: str) -> tuple[MigrationStep, ...]:
        if source == target:
            return ()
        queue: deque[tuple[str, tuple[MigrationStep, ...]]] = deque([(source, ())])
        seen = {source}
        while queue:
            schema, path = queue.popleft()
            for step in self._steps.values():
                if step.domain != domain or step.from_schema != schema:
                    continue
                next_path = (*path, step)
                if step.to_schema == target:
                    return next_path
                if step.to_schema not in seen:
                    seen.add(step.to_schema)
                    queue.append((step.to_schema, next_path))
        raise ValueError(f"no migration path for {domain}: {source} -> {target}")

    def migrate(
        self,
        domain: str,
        payload: bytes,
        *,
        from_schema: str,
        to_schema: str,
    ) -> MigrationResult:
        try:
            value = json.loads(payload.decode("utf-8"))
        except Exception as exc:
            raise ValueError("migration payload must be UTF-8 JSON") from exc
        if not isinstance(value, dict):
            raise TypeError("migration payload must be a JSON object")
        before = _canonical(value)
        path = self._path(domain, from_schema, to_schema)
        semantic_digest: str | None = None
        reversible = True
        labels: list[str] = []
        current = value
        for step in path:
            projector = step.semantic_projector
            before_semantic = _canonical(projector(current)) if projector else None
            migrated = step.migrate(dict(current))
            if not isinstance(migrated, dict):
                raise TypeError("migration function must return a JSON object")
            if projector is not None:
                after_semantic = _canonical(projector(migrated))
                if before_semantic != after_semantic:
                    raise ValueError(
                        f"migration changed semantic projection: {step.from_schema}->{step.to_schema}"
                    )
                semantic_digest = _sha(after_semantic)
            current = migrated
            reversible = reversible and step.reversible
            labels.append(f"{step.from_schema}->{step.to_schema}")
        after = _canonical(current)
        return MigrationResult(
            domain=domain,
            from_schema=from_schema,
            to_schema=to_schema,
            steps=tuple(labels),
            before_sha256=_sha(before),
            after_sha256=_sha(after),
            semantic_sha256=semantic_digest,
            reversible=reversible,
            payload=after,
        )


def default_migration_registry() -> StateMigrationRegistry:
    registry = StateMigrationRegistry()

    def behavioral_v1_v2(value: JsonObject) -> JsonObject:
        if value.get("schema") != "behavioral_pipeline_state_v1":
            raise ValueError("unexpected behavioral source schema")
        output = dict(value)
        output["schema"] = "behavioral_pipeline_state_v2"
        output.setdefault("fleet_episodes", {})
        return output

    def behavioral_semantics(value: JsonObject) -> object:
        return {
            "detector": value.get("detector"),
            "episodes": value.get("episodes"),
        }

    registry.register(
        MigrationStep(
            domain="behavioral-pipeline",
            from_schema="behavioral_pipeline_state_v1",
            to_schema="behavioral_pipeline_state_v2",
            migrate=behavioral_v1_v2,
            reversible=False,
            semantic_projector=behavioral_semantics,
        )
    )
    return registry
