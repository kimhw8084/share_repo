from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from ephi.domain.episode import HealthEpisode
from ephi.domain.exposure import EpisodeOnsetWindow
from ephi.domain.health import HealthAssessment
from ephi.domain.quality import QualityAssociationEvidence
from ephi.repositories.exposure import ExposureSourceRepository

from .engine import ExposurePriorityEngine, ExposurePriorityResult


@dataclass(slots=True)
class ExposureRefreshCoordinator:
    repository: ExposureSourceRepository
    engine: ExposurePriorityEngine = field(default_factory=ExposurePriorityEngine)

    def refresh(
        self,
        *,
        episode: HealthEpisode,
        assessment: HealthAssessment,
        onset: EpisodeOnsetWindow,
        as_of: datetime,
        quality_associations: tuple[QualityAssociationEvidence, ...] = (),
        trend: str = "PERSISTENT",
    ) -> ExposurePriorityResult:
        if episode.asset_id != assessment.asset_id or episode.context != assessment.context:
            raise ValueError("episode/assessment mismatch")
        history = self.repository.historical_exposures(
            asset_id=episode.asset_id,
            operation=episode.context.operation,
            start_time=onset.low,
            as_of=as_of,
        )
        wip = self.repository.current_wip(operation=episode.context.operation, as_of=as_of)
        alternatives = self.repository.alternative_assets(
            asset_id=episode.asset_id,
            context=episode.context,
            as_of=as_of,
        )
        return self.engine.assess(
            episode_id=episode.episode_id,
            asset_id=episode.asset_id,
            operation=episode.context.operation,
            technical_severity=assessment.severity,
            technical_confidence=assessment.confidence,
            as_of=as_of,
            onset=onset,
            historical_executions=history,
            wip=wip,
            alternatives=alternatives,
            quality_associations=quality_associations,
            trend=trend,
        )
