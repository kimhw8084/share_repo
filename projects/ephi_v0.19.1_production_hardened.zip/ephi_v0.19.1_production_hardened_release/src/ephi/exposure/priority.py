from dataclasses import dataclass
from ephi.domain.exposure import ExposureSnapshot
from ephi.domain.health import HealthSeverity
from ephi.domain.priority import HarmfulnessBand,OperationalPriority,OperationalPriorityAssessment
from ephi.domain.quality import QualityAssociationEvidence,QualityEvidenceState
from .policy import PriorityPolicy
R={OperationalPriority.P1:1,OperationalPriority.P2:2,OperationalPriority.P3:3,OperationalPriority.P4:4}
def _min(*x): return min(x,key=lambda v:R[v])
def _harm(q):
    s={x.evidence_state for x in q}
    if QualityEvidenceState.STRONG_ASSOCIATION in s:return HarmfulnessBand.STRONG
    if QualityEvidenceState.SUPPORTED_ASSOCIATION in s:return HarmfulnessBand.SUPPORTED
    if QualityEvidenceState.WEAK_ASSOCIATION in s:return HarmfulnessBand.WEAK
    if QualityEvidenceState.CONTRADICTED in s and s <= {QualityEvidenceState.CONTRADICTED,QualityEvidenceState.NO_OBSERVED_ASSOCIATION}:return HarmfulnessBand.CONTRADICTED
    if s & {QualityEvidenceState.NOT_YET_MATURE,QualityEvidenceState.UNAVAILABLE}:return HarmfulnessBand.PENDING
    return HarmfulnessBand.NONE
@dataclass(slots=True)
class OperationalPriorityEngine:
    policy:PriorityPolicy=PriorityPolicy()
    def assess(self,*,episode_id,technical_severity,technical_confidence,exposure,quality_associations=(),trend="PERSISTENT"):
        h=_harm(quality_associations); tte=None if exposure.earliest_future_eta is None else max(0,(exposure.earliest_future_eta-exposure.as_of).total_seconds()/60); ok=technical_confidence>=self.policy.confidence_floor; reasons=[]
        if ok and technical_severity>=HealthSeverity.INVESTIGATE and (exposure.currently_committed>0 or (exposure.future_preventable>=self.policy.high_preventable_count and tte is not None and tte<=self.policy.urgent_time_to_exposure_minutes)): c=OperationalPriority.P1; reasons.append("CONTAINMENT_TIME_CRITICAL_PREVENTABLE_OR_COMMITTED_WIP")
        elif ok and technical_severity>=HealthSeverity.INVESTIGATE and (exposure.future_preventable or exposure.future_likely or exposure.currently_committed): c=OperationalPriority.P2; reasons.append("CONTAINMENT_ACTIONABLE_FUTURE_EXPOSURE")
        elif exposure.future_possible or exposure.future_likely: c=OperationalPriority.P3; reasons.append("CONTAINMENT_POSSIBLE_FUTURE_EXPOSURE")
        else:c=OperationalPriority.P4
        past=exposure.definitely_exposed+exposure.possibly_exposed
        if h is HarmfulnessBand.STRONG and exposure.definitely_exposed>=self.policy.high_exposed_count:d=OperationalPriority.P1; reasons.append("DISPOSITION_STRONG_HARM_WITH_LARGE_EXPOSED_POPULATION")
        elif h in {HarmfulnessBand.STRONG,HarmfulnessBand.SUPPORTED} and past:d=OperationalPriority.P2; reasons.append("DISPOSITION_SUPPORTED_HARM_ON_EXPOSED_MATERIAL")
        elif past:d=OperationalPriority.P3; reasons.append("DISPOSITION_EXPOSED_MATERIAL_REQUIRES_MATURITY_REVIEW")
        else:d=OperationalPriority.P4
        if ok and technical_severity>=HealthSeverity.URGENT and h in {HarmfulnessBand.STRONG,HarmfulnessBand.SUPPORTED}: r=OperationalPriority.P1; reasons.append("RCA_URGENT_TECHNICAL_AND_QUALITY_SUPPORT")
        elif ok and (technical_severity>=HealthSeverity.INVESTIGATE or h in {HarmfulnessBand.STRONG,HarmfulnessBand.SUPPORTED}):r=OperationalPriority.P2; reasons.append("RCA_INVESTIGATION_WARRANTED")
        elif technical_severity>=HealthSeverity.MONITOR or trend.upper() in {"WORSENING","ACCELERATING"}:r=OperationalPriority.P3; reasons.append("RCA_MONITOR_OR_WORSENING")
        else:r=OperationalPriority.P4
        return OperationalPriorityAssessment(episode_id=episode_id,as_of=exposure.as_of,policy_version=self.policy.version,overall_priority=_min(c,d,r),containment_priority=c,disposition_priority=d,rca_priority=r,harmfulness=h,time_to_earliest_exposure_minutes=tte,reasons=tuple(dict.fromkeys(reasons)))
