from __future__ import annotations
from dataclasses import dataclass, field
from ephi.domain.exposure import *
from ephi.domain.health import HealthSeverity
from ephi.domain.priority import OperationalPriorityAssessment
from ephi.domain.quality import QualityAssociationEvidence
from .policy import ExposurePolicy
from .priority import OperationalPriorityEngine

def _alts(candidates, target, policy):
    out=[]
    for x in candidates:
        if x.asset_id==target: continue
        healthy=x.qualified and x.availability is not AssetAvailability.UNAVAILABLE and x.health_severity<=HealthSeverity.NORMAL and x.health_confidence>=policy.minimum_alternative_health_confidence and x.compatibility>=policy.minimum_alternative_compatibility
        if not x.qualified:r="NOT_QUALIFIED"
        elif x.availability is AssetAvailability.UNAVAILABLE:r="UNAVAILABLE"
        elif x.health_severity>HealthSeverity.NORMAL:r=f"HEALTH_{x.health_severity.name}"
        elif x.health_confidence<policy.minimum_alternative_health_confidence:r="LOW_HEALTH_CONFIDENCE"
        elif x.compatibility<policy.minimum_alternative_compatibility:r="LOW_COMPATIBILITY"
        else:r="QUALIFIED_HEALTHY_ALTERNATIVE"
        out.append(AlternativeAssetAssessment(asset_id=x.asset_id,qualified=x.qualified,availability=x.availability,health_severity=x.health_severity.name,health_confidence=x.health_confidence,compatibility=x.compatibility,preferred=healthy,reason=r))
    return tuple(sorted(out,key=lambda x:(not x.preferred,x.asset_id)))

@dataclass(slots=True)
class ExposureEngine:
    policy:ExposurePolicy=ExposurePolicy()
    def assess(self,*,episode_id,asset_id,operation,as_of,onset,historical_executions=(),wip=(),alternatives=()):
        items=[]
        # Material-level historical exposure: preserve every matching execution ID, but
        # never inflate wafer/material counts because of rework or repeated passes.
        by_material={}
        for x in historical_executions:
            if x.asset_id!=asset_id or x.event_time<onset.low: continue
            by_material.setdefault(x.material_id,[]).append(x)
        for material_id, rows in by_material.items():
            rows=sorted(rows,key=lambda x:x.event_time)
            definite=[x for x in rows if x.event_time>=onset.high]
            cls=MaterialExposureClass.DEFINITE_PAST_EXPOSURE if definite else MaterialExposureClass.POSSIBLE_PAST_EXPOSURE
            primary=(definite[0] if definite else rows[0])
            q=next((x.quality_state for x in reversed(rows) if x.quality_state is not None),None)
            items.append(MaterialExposureAssessment(material_id=material_id,exposure_class=cls,exposure_start=rows[0].event_time,exposure_end=max((x.exposure_end or x.event_time) for x in rows),exposure_confidence=onset.confidence,suspect_execution_id=primary.execution_id,suspect_execution_ids=tuple(x.execution_id for x in rows),route_position=primary.route_position,quality_state=q,preventability=PreventabilityState.NOT_APPLICABLE,reason_codes=(("AFTER_ONSET_HIGH" if definite else "WITHIN_ONSET_UNCERTAINTY"),"EXACT_EXECUTION_EXPOSURE") + (("MULTIPLE_SUSPECT_EXECUTIONS",) if len(rows)>1 else ())))
        av=_alts(alternatives,asset_id,self.policy); pref=tuple(x for x in av if x.preferred); avail=tuple(x for x in pref if x.availability is AssetAvailability.AVAILABLE)
        for m in wip:
            if m.held: continue
            steps=sorted((s for s in m.future_steps if s.sequence>m.current_sequence and s.operation==operation),key=lambda s:s.sequence)
            if not steps: continue
            s=steps[0]
            if s.committed_asset_id==asset_id:
                items.append(MaterialExposureAssessment(material_id=m.material_id,exposure_class=MaterialExposureClass.CURRENTLY_COMMITTED_EXPOSURE,exposure_confidence=1,route_position=s.route_position,preventability=PreventabilityState.ALREADY_COMMITTED,route_likelihood=RouteExposureLikelihood.COMMITTED,eta=s.eta,alternatives=av,reason_codes=("COMMITTED_TO_SUSPECT_ASSET",))); continue
            if s.likely_asset_id==asset_id:
                if avail: cls=MaterialExposureClass.FUTURE_PREVENTABLE_EXPOSURE; p=PreventabilityState.HIGH; rs=("LIKELY_SUSPECT_ROUTE","HEALTHY_AVAILABLE_ALTERNATIVE")
                elif pref: cls=MaterialExposureClass.FUTURE_PREVENTABLE_EXPOSURE; p=PreventabilityState.MODERATE; rs=("LIKELY_SUSPECT_ROUTE","HEALTHY_ALTERNATIVE_AVAILABILITY_UNKNOWN")
                else: cls=MaterialExposureClass.FUTURE_LIKELY_EXPOSURE; p=PreventabilityState.NO_QUALIFIED_ALTERNATIVE; rs=("LIKELY_SUSPECT_ROUTE","NO_HEALTHY_QUALIFIED_ALTERNATIVE")
                items.append(MaterialExposureAssessment(material_id=m.material_id,exposure_class=cls,exposure_confidence=.9,route_position=s.route_position,preventability=p,route_likelihood=RouteExposureLikelihood.LIKELY,eta=s.eta,alternatives=av,reason_codes=rs)); continue
            if asset_id in s.eligible_asset_ids:
                items.append(MaterialExposureAssessment(material_id=m.material_id,exposure_class=MaterialExposureClass.FUTURE_POSSIBLE_EXPOSURE,exposure_confidence=.6,route_position=s.route_position,preventability=(PreventabilityState.MODERATE if pref else PreventabilityState.UNKNOWN),route_likelihood=RouteExposureLikelihood.POSSIBLE,eta=s.eta,alternatives=av,reason_codes=("SUSPECT_ASSET_ELIGIBLE_ROUTING_NOT_ASSIGNED",)))
        items=tuple(sorted(items,key=lambda x:(x.material_id,x.exposure_class.value)))
        def n(k): return sum(x.exposure_class is k for x in items)
        etas=[x.eta for x in items if x.eta is not None and x.eta>=as_of]; conf=[x.exposure_confidence for x in items]
        mature_states={"MATURE","MATURE_AVAILABLE","INLINE_MATURE","OUTCOME_MATURE"}
        pending_states={"PENDING","NOT_YET_MATURE","QUALITY_PENDING","OUTCOME_PENDING"}
        states=[(x.quality_state or "").upper() for x in items]
        return ExposureSnapshot(snapshot_id=f"EXP-{episode_id}-{int(as_of.timestamp())}",episode_id=episode_id,asset_id=asset_id,operation=operation,as_of=as_of,onset_low=onset.low,onset_best=onset.best,onset_high=onset.high,onset_confidence=onset.confidence,items=items,definitely_exposed=n(MaterialExposureClass.DEFINITE_PAST_EXPOSURE),possibly_exposed=n(MaterialExposureClass.POSSIBLE_PAST_EXPOSURE),currently_committed=n(MaterialExposureClass.CURRENTLY_COMMITTED_EXPOSURE),future_possible=n(MaterialExposureClass.FUTURE_POSSIBLE_EXPOSURE),future_likely=n(MaterialExposureClass.FUTURE_LIKELY_EXPOSURE),future_preventable=n(MaterialExposureClass.FUTURE_PREVENTABLE_EXPOSURE),no_qualified_alternative=sum(x.preventability is PreventabilityState.NO_QUALIFIED_ALTERNATIVE for x in items),quality_mature=sum(x in mature_states for x in states),quality_pending=sum(x in pending_states for x in states),earliest_future_eta=min(etas) if etas else None,confidence=(sum(conf)/len(conf) if conf else onset.confidence),source_version=self.policy.version)

@dataclass(frozen=True, slots=True)
class ExposurePriorityResult: exposure:ExposureSnapshot; priority:OperationalPriorityAssessment
@dataclass(slots=True)
class ExposurePriorityEngine:
    exposure_engine:ExposureEngine=field(default_factory=ExposureEngine); priority_engine:OperationalPriorityEngine=field(default_factory=OperationalPriorityEngine)
    def assess(self,*,episode_id,asset_id,operation,technical_severity,technical_confidence,as_of,onset,historical_executions=(),wip=(),alternatives=(),quality_associations:tuple[QualityAssociationEvidence,...]=(),trend="PERSISTENT"):
        e=self.exposure_engine.assess(episode_id=episode_id,asset_id=asset_id,operation=operation,as_of=as_of,onset=onset,historical_executions=historical_executions,wip=wip,alternatives=alternatives)
        p=self.priority_engine.assess(episode_id=episode_id,technical_severity=technical_severity,technical_confidence=technical_confidence,exposure=e,quality_associations=quality_associations,trend=trend)
        return ExposurePriorityResult(e,p)
