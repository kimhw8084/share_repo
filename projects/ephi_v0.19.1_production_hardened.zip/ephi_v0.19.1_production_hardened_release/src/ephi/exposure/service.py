from dataclasses import dataclass, field
from ephi.domain.exposure import ExposureSnapshot
from ephi.domain.priority import OperationalPriorityAssessment
@dataclass(slots=True)
class ExposurePriorityService:
    snapshots:dict[str,ExposureSnapshot]=field(default_factory=dict); priorities:dict[str,OperationalPriorityAssessment]=field(default_factory=dict); versions:dict[str,int]=field(default_factory=dict)
    def upsert(self,e,p):
        if e.episode_id!=p.episode_id: raise ValueError("exposure/priority episode mismatch")
        k=e.episode_id; self.snapshots[k]=e; self.priorities[k]=p; self.versions[k]=self.versions.get(k,0)+1; return self.versions[k]
    def get_exposure(self,k):
        if k not in self.snapshots: raise KeyError(f"unknown exposure episode: {k}")
        return self.snapshots[k]
    def get_priority(self,k):
        if k not in self.priorities: raise KeyError(f"unknown priority episode: {k}")
        return self.priorities[k]
    def export_state(self): return {"schema":"exposure_priority_state_v1","versions":dict(self.versions),"snapshots":{k:v.model_dump(mode="json") for k,v in self.snapshots.items()},"priorities":{k:v.model_dump(mode="json") for k,v in self.priorities.items()}}
    def restore_state(self,s):
        if s.get("schema")!="exposure_priority_state_v1": raise ValueError("Unsupported exposure checkpoint schema")
        self.snapshots={str(k):ExposureSnapshot.model_validate(v) for k,v in s.get("snapshots",{}).items()}; self.priorities={str(k):OperationalPriorityAssessment.model_validate(v) for k,v in s.get("priorities",{}).items()}; self.versions={str(k):int(v) for k,v in s.get("versions",{}).items()}
