from pathlib import Path
import yaml
from pydantic import BaseModel, ConfigDict, Field
class ExposurePolicy(BaseModel):
    model_config=ConfigDict(frozen=True)
    version:str="exposure-v1"; minimum_alternative_health_confidence:float=Field(default=.60,ge=0,le=1); minimum_alternative_compatibility:float=Field(default=.70,ge=0,le=1)
class PriorityPolicy(BaseModel):
    model_config=ConfigDict(frozen=True)
    version:str="priority-v1"; confidence_floor:float=Field(default=.55,ge=0,le=1); urgent_time_to_exposure_minutes:float=Field(default=60,gt=0); high_preventable_count:int=Field(default=25,ge=1); high_exposed_count:int=Field(default=50,ge=1)


def load_exposure_policy(path: str | Path) -> ExposurePolicy:
    payload=yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    if not isinstance(payload,dict): raise TypeError("exposure policy must be a mapping")
    return ExposurePolicy.model_validate(payload)

def load_priority_policy(path: str | Path) -> PriorityPolicy:
    payload=yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    if not isinstance(payload,dict): raise TypeError("priority policy must be a mapping")
    return PriorityPolicy.model_validate(payload)
