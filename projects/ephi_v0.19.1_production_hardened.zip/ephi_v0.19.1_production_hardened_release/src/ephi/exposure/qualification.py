from __future__ import annotations

from datetime import datetime, timedelta, timezone
from time import perf_counter

from pydantic import BaseModel, ConfigDict

from ephi.domain.exposure import (
    AlternativeAssetCandidate,
    AssetAvailability,
    EpisodeOnsetWindow,
    FutureRouteStep,
    HistoricalExecutionExposure,
    WIPMaterialState,
)
from ephi.domain.health import HealthSeverity
from ephi.domain.priority import OperationalPriority

from .engine import ExposurePriorityEngine


class ExposurePriorityQualificationReport(BaseModel):
    model_config = ConfigDict(frozen=True)

    version: str = "0.8.0"
    passed: bool
    checks: dict[str, bool]
    time_critical_priority: str
    rerouted_containment_priority: str
    repeated_execution_material_count: int
    unhealthy_alternative_future_preventable: int
    performance_materials: int
    performance_seconds: float
    performance_materials_per_second: float


def _wip(now: datetime, count: int, *, asset: str = "A", alt: str = "B") -> tuple[WIPMaterialState, ...]:
    return tuple(
        WIPMaterialState(
            material_id=f"W{i:06d}",
            current_sequence=1,
            future_steps=(
                FutureRouteStep(
                    material_id=f"W{i:06d}",
                    sequence=2,
                    operation="OP",
                    eligible_asset_ids=(asset, alt),
                    eta=now + timedelta(minutes=20),
                    likely_asset_id=asset,
                ),
            ),
        )
        for i in range(count)
    )


def run_exposure_priority_qualification(*, performance_materials: int = 10_000) -> ExposurePriorityQualificationReport:
    now = datetime(2026, 8, 19, 12, 0, tzinfo=timezone.utc)
    onset = EpisodeOnsetWindow(now - timedelta(hours=2), now - timedelta(minutes=90), now - timedelta(hours=1), 0.9)
    engine = ExposurePriorityEngine()
    healthy_alt = AlternativeAssetCandidate(
        "B", True, AssetAvailability.AVAILABLE, HealthSeverity.NORMAL, 0.95, 0.95
    )
    unhealthy_alt = AlternativeAssetCandidate(
        "B", True, AssetAvailability.AVAILABLE, HealthSeverity.INVESTIGATE, 0.95, 0.95
    )

    history = (
        HistoricalExecutionExposure("PAST", "X1", "A", "OP", now - timedelta(minutes=50), quality_state="NOT_YET_MATURE"),
        HistoricalExecutionExposure("PAST", "X2", "A", "OP", now - timedelta(minutes=40), quality_state="NOT_YET_MATURE"),
    )
    repeated = engine.assess(
        episode_id="E-QUAL",
        asset_id="A",
        operation="OP",
        technical_severity=HealthSeverity.INVESTIGATE,
        technical_confidence=0.9,
        as_of=now,
        onset=onset,
        historical_executions=history,
    )

    urgent = engine.assess(
        episode_id="E-QUAL",
        asset_id="A",
        operation="OP",
        technical_severity=HealthSeverity.INVESTIGATE,
        technical_confidence=0.9,
        as_of=now,
        onset=onset,
        wip=_wip(now, 30),
        alternatives=(healthy_alt,),
        trend="WORSENING",
    )
    rerouted = engine.assess(
        episode_id="E-QUAL",
        asset_id="A",
        operation="OP",
        technical_severity=HealthSeverity.INVESTIGATE,
        technical_confidence=0.9,
        as_of=now + timedelta(minutes=5),
        onset=onset,
        wip=(),
        alternatives=(healthy_alt,),
        trend="WORSENING",
    )
    unhealthy = engine.assess(
        episode_id="E-QUAL",
        asset_id="A",
        operation="OP",
        technical_severity=HealthSeverity.INVESTIGATE,
        technical_confidence=0.9,
        as_of=now,
        onset=onset,
        wip=_wip(now, 1),
        alternatives=(unhealthy_alt,),
    )

    perf_wip = _wip(now, performance_materials)
    started = perf_counter()
    perf = engine.assess(
        episode_id="E-PERF",
        asset_id="A",
        operation="OP",
        technical_severity=HealthSeverity.INVESTIGATE,
        technical_confidence=0.9,
        as_of=now,
        onset=onset,
        wip=perf_wip,
        alternatives=(healthy_alt,),
    )
    elapsed = perf_counter() - started
    checks = {
        "repeated_execution_deduplicated": repeated.exposure.definitely_exposed == 1 and len(repeated.exposure.items) == 1,
        "not_yet_mature_is_pending": repeated.exposure.quality_mature == 0 and repeated.exposure.quality_pending == 1,
        "healthy_alternative_enables_preventability": urgent.exposure.future_preventable == 30,
        "time_critical_preventable_wip_is_p1_containment": urgent.priority.containment_priority is OperationalPriority.P1,
        "rerouting_removes_containment_urgency": rerouted.priority.containment_priority is OperationalPriority.P4,
        "unhealthy_alternative_not_counted": unhealthy.exposure.future_preventable == 0 and unhealthy.exposure.future_likely == 1,
        "technical_severity_input_unchanged": HealthSeverity.INVESTIGATE.name == "INVESTIGATE",
        "performance_count_preserved": perf.exposure.future_preventable == performance_materials,
    }
    return ExposurePriorityQualificationReport(
        passed=all(checks.values()),
        checks=checks,
        time_critical_priority=urgent.priority.overall_priority.value,
        rerouted_containment_priority=rerouted.priority.containment_priority.value,
        repeated_execution_material_count=repeated.exposure.definitely_exposed,
        unhealthy_alternative_future_preventable=unhealthy.exposure.future_preventable,
        performance_materials=performance_materials,
        performance_seconds=elapsed,
        performance_materials_per_second=(performance_materials / elapsed if elapsed > 0 else 0.0),
    )
