"""Economic value, benefit attribution, and ROI reconciliation.

This package is downstream of technical health, quality, exposure, and advisory logic.
It must never be imported by detectors/populations/evidence to determine technical truth.
"""

from .service import ValueLedgerService

__all__ = ["ValueLedgerService"]
