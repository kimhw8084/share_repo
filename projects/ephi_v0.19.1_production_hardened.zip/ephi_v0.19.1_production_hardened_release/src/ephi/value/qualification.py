from __future__ import annotations

from datetime import datetime, timedelta, timezone

from pydantic import BaseModel, ConfigDict, Field

from ephi.domain.exposure import (
    ExposureSnapshot,
    MaterialExposureAssessment,
    MaterialExposureClass,
    PreventabilityState,
    RouteExposureLikelihood,
)
from ephi.domain.value import (
    BenefitAttribution,
    BenefitAttributionRole,
    BenefitClaimGroup,
    EngineeringTimeEvidence,
    LossEstimateEvidence,
    ObservedCostEvidence,
    ProtectionEvidence,
    ResourceUsage,
    ValidatedBenefitEvidence,
    ValueCategory,
)
from ephi.value.costs import CostModelRegistry, load_cost_model
from ephi.value.service import ValueLedgerService


class ValueQualificationReport(BaseModel):
    model_config = ConfigDict(frozen=True)

    version: str = "0.10.0"
    passed: bool
    checks: dict[str, bool]
    observed_already_exposed: int = Field(ge=0)
    observed_future_preventable: int = Field(ge=0)
    estimated_avoidable_loss: float = Field(ge=0.0)
    wafers_protected: int = Field(ge=0)
    engineering_hours_saved: float = Field(ge=0.0)
    first_validated_benefit: float = Field(ge=0.0)
    revised_validated_benefit: float = Field(ge=0.0)
    operating_cost: float = Field(ge=0.0)
    net_validated_value: float
    benefit_cost_ratio: float | None = Field(default=None, ge=0.0)
    ledger_entries_total: int = Field(ge=0)
    active_entries: int = Field(ge=0)


def _snapshot(now: datetime) -> ExposureSnapshot:
    items: list[MaterialExposureAssessment] = []
    for i in range(100):
        items.append(MaterialExposureAssessment(
            material_id=f"PAST-{i:03d}",
            exposure_class=MaterialExposureClass.DEFINITE_PAST_EXPOSURE,
            exposure_confidence=0.98,
            suspect_execution_id=f"X-{i:03d}",
            suspect_execution_ids=(f"X-{i:03d}",),
            preventability=PreventabilityState.NOT_APPLICABLE,
        ))
    for i in range(40):
        items.append(MaterialExposureAssessment(
            material_id=f"POSS-{i:03d}",
            exposure_class=MaterialExposureClass.POSSIBLE_PAST_EXPOSURE,
            exposure_confidence=0.65,
            preventability=PreventabilityState.NOT_APPLICABLE,
        ))
    for i in range(50):
        items.append(MaterialExposureAssessment(
            material_id=f"WIP-{i:03d}",
            exposure_class=MaterialExposureClass.FUTURE_PREVENTABLE_EXPOSURE,
            exposure_confidence=0.9,
            preventability=PreventabilityState.HIGH,
            route_likelihood=RouteExposureLikelihood.LIKELY,
            eta=now + timedelta(minutes=30),
        ))
    return ExposureSnapshot(
        snapshot_id="EXP-VALUE-QUAL",
        episode_id="EP-1",
        asset_id="A",
        operation="OP",
        as_of=now,
        onset_low=now - timedelta(hours=3),
        onset_best=now - timedelta(hours=2),
        onset_high=now - timedelta(hours=1),
        onset_confidence=0.9,
        items=tuple(items),
        definitely_exposed=100,
        possibly_exposed=40,
        future_preventable=50,
        quality_mature=0,
        quality_pending=140,
        earliest_future_eta=now + timedelta(minutes=30),
        confidence=0.9,
    )


def run_value_qualification(cost_model_path: str = "configs/value/synthetic_reference.yaml") -> ValueQualificationReport:
    now = datetime(2026, 8, 19, 16, 0, tzinfo=timezone.utc)
    registry = CostModelRegistry()
    model = load_cost_model(cost_model_path)
    registry.register(model)
    service = ValueLedgerService(cost_models=registry)

    group = BenefitClaimGroup(
        claim_group_id="CG-1",
        economic_event_key="ECONOMIC-EVENT-1",
        episode_ids=("EP-1", "EP-2"),
        material_ids=tuple(f"WIP-{i:03d}" for i in range(20)),
        description="synthetic shared containment event",
        created_at=now,
    )
    service.register_claim_group(group)
    service.record_attribution(BenefitAttribution(
        claim_group_id="CG-1",
        episode_id="EP-1",
        role=BenefitAttributionRole.PRIMARY,
        attribution_confidence=0.9,
        supporting_evidence=("EPHI detected before routing change",),
        review_status="REVIEWED",
    ))
    service.record_attribution(BenefitAttribution(
        claim_group_id="CG-1",
        episode_id="EP-2",
        role=BenefitAttributionRole.CONTRIBUTORY,
        attribution_confidence=0.7,
        supporting_evidence=("secondary related episode",),
        review_status="REVIEWED",
    ))

    service.observe_exposure(_snapshot(now))
    estimate = service.estimate_loss(
        LossEstimateEvidence(
            episode_id="EP-1",
            claim_group_id="CG-1",
            category=ValueCategory.SCRAP_EXPOSURE_ESTIMATE,
            material_count=50,
            risk_probability=0.25,
            rate_id="wafer_loss",
            computed_at=now,
            source_references=("EXP-VALUE-QUAL", "QUALITY-RISK-SYNTHETIC"),
        ),
        cost_model_id=model.cost_model_id,
        cost_model_version=model.version,
    )
    service.record_protection(ProtectionEvidence(
        episode_id="EP-1",
        claim_group_id="CG-1",
        material_ids=tuple(f"WIP-{i:03d}" for i in range(20)),
        action="rerouted to healthy alternative",
        routing_evidence=("ROUTING-AUDIT-1",),
        observed_at=now + timedelta(minutes=10),
        confidence=0.95,
    ))
    service.record_engineering_time(
        EngineeringTimeEvidence(
            episode_id="EP-1",
            baseline_hours=8.0,
            actual_hours=3.0,
            method="matched historical investigation baseline",
            observed_at=now + timedelta(hours=4),
        ),
        cost_model_id=model.cost_model_id,
        cost_model_version=model.version,
    )
    compute = service.record_resource_usage(
        ResourceUsage(
            usage_id="RU-1",
            episode_id=None,
            cpu_hours=100.0,
            gpu_hours=2.0,
            storage_gb_month=10.0,
            big_data_tb_scanned=0.5,
            observed_at=now + timedelta(days=1),
            source_reference="RUNTIME-METRICS-1",
        ),
        cost_model_id=model.cost_model_id,
        cost_model_version=model.version,
    )
    false_cost = service.record_observed_cost(
        ObservedCostEvidence(
            episode_id="EP-FALSE",
            category=ValueCategory.FALSE_ACTIONABLE_EVENT_COST,
            quantity=1.0,
            unit="hour",
            rate_id="engineering_hour",
            observed_at=now + timedelta(hours=6),
            source_references=("FALSE-EVENT-REVIEW-1",),
        ),
        cost_model_id=model.cost_model_id,
        cost_model_version=model.version,
    )

    first = service.validate_realized_benefit(ValidatedBenefitEvidence(
        claim_group_id="CG-1",
        amount=8000.0,
        currency="USD",
        method="operations/finance reconciliation",
        validated_at=now + timedelta(days=30),
        validated_by="value-reviewer",
        source_references=("FINANCE-RECON-1", "ACTION-AUDIT-1"),
    ))
    revised = service.validate_realized_benefit(
        ValidatedBenefitEvidence(
            claim_group_id="CG-1",
            amount=8500.0,
            currency="USD",
            method="reconciled revision after mature outcome",
            validated_at=now + timedelta(days=45),
            validated_by="value-reviewer-2",
            source_references=("FINANCE-RECON-2",),
        ),
        supersedes_entry_id=first.ledger_entry_id,
    )

    duplicate_event_blocked = False
    try:
        service.register_claim_group(BenefitClaimGroup(
            claim_group_id="CG-DUP",
            economic_event_key="ECONOMIC-EVENT-1",
            episode_ids=("EP-3",),
            description="duplicate economic event",
            created_at=now,
        ))
    except ValueError:
        duplicate_event_blocked = True

    duplicate_validated_blocked = False
    try:
        service.validate_realized_benefit(ValidatedBenefitEvidence(
            claim_group_id="CG-1",
            amount=9000.0,
            currency="USD",
            method="invalid duplicate",
            validated_at=now + timedelta(days=50),
            validated_by="reviewer",
            source_references=("FINANCE-RECON-3",),
        ))
    except ValueError:
        duplicate_validated_blocked = True

    protected_without_route_blocked = False
    try:
        ProtectionEvidence(
            episode_id="EP-1",
            claim_group_id="CG-1",
            material_ids=("WIP-999",),
            action="claimed protected",
            routing_evidence=(),
            observed_at=now,
            confidence=0.9,
        )
    except ValueError:
        protected_without_route_blocked = True

    program = service.program_summary(as_of=now + timedelta(days=60))
    episode = service.episode_summary("EP-1", as_of=now + timedelta(days=60))
    all_entries = service.repository.entries()
    active_entries = service.repository.active_entries()

    expected_operating_cost = (100 * 0.10) + (2 * 2.0) + (10 * 0.02) + (0.5 * 5.0) + (1 * 200.0)
    checks = {
        "estimated_exposure_not_validated_benefit": estimate.monetary_value == 12500.0 and program.validated_realized_benefit == 8500.0,
        "wafers_protected_require_routing_evidence": protected_without_route_blocked and program.wafers_protected == 20,
        "engineering_time_physical_measure_preserved": episode.engineering_hours_saved == 5.0,
        "compute_and_false_event_cost_in_operating_cost": abs(program.operating_cost - expected_operating_cost) < 1e-9,
        "validated_benefit_requires_explicit_reconciliation": first.validated_by == "value-reviewer" and revised.validated_by == "value-reviewer-2",
        "validated_revision_is_immutable_and_latest_active": first in all_entries and first not in active_entries and revised in active_entries,
        "duplicate_economic_event_blocked": duplicate_event_blocked,
        "duplicate_active_validated_claim_blocked": duplicate_validated_blocked,
        "program_roi_uses_validated_benefit_only": abs(program.net_validated_value - (8500.0 - expected_operating_cost)) < 1e-9,
        "claim_group_shared_across_episodes_without_double_count": program.validated_claim_groups == 1,
        "resource_cost_is_observed_not_benefit": compute.category == ValueCategory.COMPUTE_COST and false_cost.category == ValueCategory.FALSE_ACTIONABLE_EVENT_COST,
    }
    return ValueQualificationReport(
        passed=all(checks.values()),
        checks=checks,
        observed_already_exposed=100,
        observed_future_preventable=50,
        estimated_avoidable_loss=float(estimate.monetary_value or 0.0),
        wafers_protected=program.wafers_protected,
        engineering_hours_saved=program.engineering_hours_saved,
        first_validated_benefit=float(first.monetary_value or 0.0),
        revised_validated_benefit=float(revised.monetary_value or 0.0),
        operating_cost=program.operating_cost,
        net_validated_value=program.net_validated_value,
        benefit_cost_ratio=program.benefit_cost_ratio,
        ledger_entries_total=len(all_entries),
        active_entries=len(active_entries),
    )
