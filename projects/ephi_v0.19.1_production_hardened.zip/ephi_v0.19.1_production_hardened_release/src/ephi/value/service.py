from __future__ import annotations

from datetime import datetime, timezone
from itertools import count

from ephi.domain.exposure import ExposureSnapshot
from ephi.domain.value import (
    BenefitAttribution,
    BenefitAttributionRole,
    BenefitClaimGroup,
    CostModelDefinition,
    EngineeringTimeEvidence,
    EpisodeValueLedgerView,
    EpisodeValueSummary,
    LossEstimateEvidence,
    MissedOpportunityEvidence,
    ObservedCostEvidence,
    OperationalBenefitEvidence,
    ProgramValueSummary,
    ProtectionEvidence,
    ResourceUsage,
    ValidatedBenefitEvidence,
    ValueCategory,
    ValueEvidenceState,
    ValueLedgerEntry,
    ValueMaturity,
)
from ephi.value.costs import CostModelRegistry
from ephi.value.ledger import InMemoryValueLedgerRepository, ValueLedgerRepository


class ValueLedgerService:
    def __init__(
        self,
        *,
        repository: ValueLedgerRepository | None = None,
        cost_models: CostModelRegistry | None = None,
    ) -> None:
        self.repository = repository or InMemoryValueLedgerRepository()
        self.cost_models = cost_models or CostModelRegistry()
        self._entry_counter = count(1)

    def _next_entry_id(self) -> str:
        return f"VAL-{next(self._entry_counter):08d}"

    def register_claim_group(self, group: BenefitClaimGroup) -> None:
        self.repository.add_claim_group(group)

    def record_attribution(self, attribution: BenefitAttribution) -> None:
        self.repository.add_attribution(attribution)

    def observe_exposure(self, snapshot: ExposureSnapshot) -> tuple[ValueLedgerEntry, ...]:
        specs = (
            (ValueCategory.MATERIAL_ALREADY_EXPOSED, snapshot.definitely_exposed, ValueEvidenceState.OBSERVED),
            (ValueCategory.MATERIAL_POTENTIALLY_AFFECTED, snapshot.possibly_exposed, ValueEvidenceState.ESTIMATED),
            (ValueCategory.MATERIAL_FUTURE_PREVENTABLE, snapshot.future_preventable, ValueEvidenceState.ESTIMATED),
        )
        created: list[ValueLedgerEntry] = []
        for category, quantity, state in specs:
            if quantity <= 0:
                continue
            entry = ValueLedgerEntry(
                ledger_entry_id=self._next_entry_id(),
                episode_id=snapshot.episode_id,
                category=category,
                quantity=float(quantity),
                unit="material",
                method="EPHI exposure snapshot",
                evidence_state=state,
                maturity=ValueMaturity.ESTIMATED_EXPOSURE,
                source_references=(snapshot.snapshot_id,),
                computed_at=snapshot.as_of,
                observed_at=snapshot.as_of if state == ValueEvidenceState.OBSERVED else None,
            )
            self.repository.append_entry(entry)
            created.append(entry)
        return tuple(created)

    def estimate_loss(
        self,
        evidence: LossEstimateEvidence,
        *,
        cost_model_id: str,
        cost_model_version: str,
        supersedes_entry_id: str | None = None,
    ) -> ValueLedgerEntry:
        model = self.cost_models.approved(cost_model_id, cost_model_version)
        if not model.is_effective(evidence.computed_at):
            raise ValueError("cost model is not effective at the estimate time")
        rate = model.rate(evidence.rate_id)
        active_estimates = [
            item for item in self.repository.active_entries()
            if item.claim_group_id == evidence.claim_group_id
            and item.category == evidence.category
            and item.currency == rate.currency
        ]
        if active_estimates and supersedes_entry_id is None:
            raise ValueError("claim group already has an active estimate for this category/currency; revise it explicitly")
        if supersedes_entry_id is not None and not any(item.ledger_entry_id == supersedes_entry_id for item in active_estimates):
            raise ValueError("supersedes_entry_id must reference the active estimate for this claim group/category")
        value = evidence.material_count * evidence.risk_probability * rate.amount_per_unit
        entry = ValueLedgerEntry(
            ledger_entry_id=self._next_entry_id(),
            episode_id=evidence.episode_id,
            claim_group_id=evidence.claim_group_id,
            category=evidence.category,
            quantity=float(evidence.material_count),
            unit="material",
            monetary_value=value,
            currency=rate.currency,
            method=(
                f"estimated exposure = material_count × risk_probability × {rate.rate_id}"
            ),
            cost_model_id=model.cost_model_id,
            cost_model_version=model.version,
            evidence_state=ValueEvidenceState.ESTIMATED,
            maturity=ValueMaturity.ESTIMATED_EXPOSURE,
            source_references=evidence.source_references,
            material_ids=evidence.material_ids,
            computed_at=evidence.computed_at,
            supersedes_entry_id=supersedes_entry_id,
        )
        self.repository.append_entry(entry)
        return entry

    def record_protection(self, evidence: ProtectionEvidence) -> ValueLedgerEntry:
        self.repository.claim_group(evidence.claim_group_id)
        entry = ValueLedgerEntry(
            ledger_entry_id=self._next_entry_id(),
            episode_id=evidence.episode_id,
            claim_group_id=evidence.claim_group_id,
            category=ValueCategory.WAFERS_PROTECTED,
            quantity=float(len(evidence.material_ids)),
            unit="material",
            method=f"observed routing/action evidence: {evidence.action}",
            evidence_state=ValueEvidenceState.OBSERVED,
            maturity=ValueMaturity.ACTION_RECORDED,
            source_references=evidence.routing_evidence,
            material_ids=evidence.material_ids,
            computed_at=evidence.observed_at,
            observed_at=evidence.observed_at,
        )
        self.repository.append_entry(entry)
        return entry

    def record_engineering_time(
        self,
        evidence: EngineeringTimeEvidence,
        *,
        cost_model_id: str | None = None,
        cost_model_version: str | None = None,
        rate_id: str = "engineering_hour",
    ) -> ValueLedgerEntry:
        value = None
        currency = None
        model_id = None
        model_version = None
        if cost_model_id is not None or cost_model_version is not None:
            if not cost_model_id or not cost_model_version:
                raise ValueError("cost_model_id and cost_model_version must be supplied together")
            model = self.cost_models.approved(cost_model_id, cost_model_version)
            if not model.is_effective(evidence.observed_at):
                raise ValueError("cost model is not effective at the observation time")
            rate = model.rate(rate_id)
            if rate.unit != "hour":
                raise ValueError("engineering time cost rate must use unit='hour'")
            value = evidence.hours_saved * rate.amount_per_unit
            currency = rate.currency
            model_id, model_version = model.cost_model_id, model.version
        entry = ValueLedgerEntry(
            ledger_entry_id=self._next_entry_id(),
            episode_id=evidence.episode_id,
            category=ValueCategory.ENGINEERING_TIME_SAVED,
            quantity=evidence.hours_saved,
            unit="hour",
            monetary_value=value,
            currency=currency,
            method=evidence.method,
            cost_model_id=model_id,
            cost_model_version=model_version,
            evidence_state=ValueEvidenceState.OBSERVED,
            maturity=ValueMaturity.OUTCOME_PARTIAL,
            source_references=(),
            computed_at=evidence.observed_at,
            observed_at=evidence.observed_at,
        )
        self.repository.append_entry(entry)
        return entry

    def record_resource_usage(
        self,
        usage: ResourceUsage,
        *,
        cost_model_id: str,
        cost_model_version: str,
    ) -> ValueLedgerEntry:
        model = self.cost_models.approved(cost_model_id, cost_model_version)
        if not model.is_effective(usage.observed_at):
            raise ValueError("cost model is not effective at the observation time")
        components = (
            ("cpu_hour", usage.cpu_hours, "hour"),
            ("gpu_hour", usage.gpu_hours, "hour"),
            ("storage_gb_month", usage.storage_gb_month, "GB-month"),
            ("big_data_tb_scan", usage.big_data_tb_scanned, "TB"),
        )
        total = 0.0
        currency: str | None = None
        used: list[str] = []
        for rate_id, quantity, expected_unit in components:
            if quantity <= 0:
                continue
            rate = model.rate(rate_id)
            if rate.unit != expected_unit:
                raise ValueError(f"{rate_id} must use unit={expected_unit!r}")
            if currency is None:
                currency = rate.currency
            elif currency != rate.currency:
                raise ValueError("resource cost model mixes currencies")
            total += quantity * rate.amount_per_unit
            used.append(rate_id)
        if currency is None:
            raise ValueError("resource usage contains no positive billable quantity")
        entry = ValueLedgerEntry(
            ledger_entry_id=self._next_entry_id(),
            episode_id=usage.episode_id,
            category=ValueCategory.COMPUTE_COST,
            quantity=1.0,
            unit="resource_usage_bundle",
            monetary_value=total,
            currency=currency,
            method=f"observed resource usage converted with rates: {', '.join(used)}",
            cost_model_id=model.cost_model_id,
            cost_model_version=model.version,
            evidence_state=ValueEvidenceState.OBSERVED,
            maturity=ValueMaturity.OUTCOME_MATURE,
            source_references=(usage.source_reference,),
            computed_at=usage.observed_at,
            observed_at=usage.observed_at,
        )
        self.repository.append_entry(entry)
        return entry


    def record_observed_cost(
        self,
        evidence: ObservedCostEvidence,
        *,
        cost_model_id: str,
        cost_model_version: str,
    ) -> ValueLedgerEntry:
        model = self.cost_models.approved(cost_model_id, cost_model_version)
        if not model.is_effective(evidence.observed_at):
            raise ValueError("cost model is not effective at the observation time")
        rate = model.rate(evidence.rate_id)
        if rate.unit != evidence.unit:
            raise ValueError("observed-cost unit does not match cost-model rate")
        entry = ValueLedgerEntry(
            ledger_entry_id=self._next_entry_id(),
            episode_id=evidence.episode_id,
            category=evidence.category,
            quantity=evidence.quantity,
            unit=evidence.unit,
            monetary_value=evidence.quantity * rate.amount_per_unit,
            currency=rate.currency,
            method=f"observed quantity × approved rate {rate.rate_id}",
            cost_model_id=model.cost_model_id,
            cost_model_version=model.version,
            evidence_state=ValueEvidenceState.OBSERVED,
            maturity=ValueMaturity.OUTCOME_MATURE,
            source_references=evidence.source_references,
            computed_at=evidence.observed_at,
            observed_at=evidence.observed_at,
        )
        self.repository.append_entry(entry)
        return entry

    def record_operational_benefit(
        self,
        evidence: OperationalBenefitEvidence,
        *,
        cost_model_id: str | None = None,
        cost_model_version: str | None = None,
    ) -> ValueLedgerEntry:
        value = None
        currency = None
        model_id = None
        model_version = None
        if evidence.claim_group_id is not None:
            self.repository.claim_group(evidence.claim_group_id)
        if cost_model_id is not None or cost_model_version is not None:
            if not cost_model_id or not cost_model_version or not evidence.rate_id:
                raise ValueError("monetary conversion requires cost model ID/version and rate_id")
            model = self.cost_models.approved(cost_model_id, cost_model_version)
            if not model.is_effective(evidence.observed_at):
                raise ValueError("cost model is not effective at the observation time")
            rate = model.rate(evidence.rate_id)
            if rate.unit != evidence.unit:
                raise ValueError("operational-benefit unit does not match cost-model rate")
            value = evidence.quantity * rate.amount_per_unit
            currency = rate.currency
            model_id, model_version = model.cost_model_id, model.version
        entry = ValueLedgerEntry(
            ledger_entry_id=self._next_entry_id(),
            episode_id=evidence.episode_id,
            claim_group_id=evidence.claim_group_id,
            category=evidence.category,
            quantity=evidence.quantity,
            unit=evidence.unit,
            monetary_value=value,
            currency=currency,
            method="observed operational benefit quantity" + (" with approved monetary conversion" if value is not None else ""),
            cost_model_id=model_id,
            cost_model_version=model_version,
            evidence_state=ValueEvidenceState.OBSERVED,
            maturity=ValueMaturity.OUTCOME_MATURE,
            source_references=evidence.source_references,
            computed_at=evidence.observed_at,
            observed_at=evidence.observed_at,
        )
        self.repository.append_entry(entry)
        return entry

    def record_missed_opportunity(
        self,
        evidence: MissedOpportunityEvidence,
        *,
        cost_model_id: str,
        cost_model_version: str,
    ) -> ValueLedgerEntry:
        model = self.cost_models.approved(cost_model_id, cost_model_version)
        if not model.is_effective(evidence.computed_at):
            raise ValueError("cost model is not effective at the estimate time")
        rate = model.rate(evidence.rate_id)
        value = evidence.material_count * evidence.risk_probability * rate.amount_per_unit
        entry = ValueLedgerEntry(
            ledger_entry_id=self._next_entry_id(),
            episode_id=evidence.episode_id,
            category=ValueCategory.MISSED_OPPORTUNITY_EXPOSURE,
            quantity=float(evidence.material_count),
            unit="material",
            monetary_value=value,
            currency=rate.currency,
            method="estimated missed opportunity = material_count × risk_probability × approved rate",
            cost_model_id=model.cost_model_id,
            cost_model_version=model.version,
            evidence_state=ValueEvidenceState.ESTIMATED,
            maturity=ValueMaturity.ESTIMATED_EXPOSURE,
            source_references=evidence.source_references,
            computed_at=evidence.computed_at,
        )
        self.repository.append_entry(entry)
        return entry

    def validate_realized_benefit(
        self,
        evidence: ValidatedBenefitEvidence,
        *,
        supersedes_entry_id: str | None = None,
    ) -> ValueLedgerEntry:
        group = self.repository.claim_group(evidence.claim_group_id)
        attributions = self.repository.attributions(evidence.claim_group_id)
        if not attributions or not any(
            item.role in {
                BenefitAttributionRole.PRIMARY,
                BenefitAttributionRole.CONTRIBUTORY,
                BenefitAttributionRole.CONFIRMATORY,
            }
            for item in attributions
        ):
            raise ValueError("validated benefit requires reviewed EPHI attribution")
        active_realized = [
            item for item in self.repository.active_entries()
            if item.claim_group_id == group.claim_group_id
            and item.category == ValueCategory.VALIDATED_REALIZED_BENEFIT
            and item.currency == evidence.currency
        ]
        if active_realized and supersedes_entry_id is None:
            raise ValueError("claim group already has an active validated realized-benefit entry; revise it explicitly")
        if supersedes_entry_id is not None and not any(
            item.ledger_entry_id == supersedes_entry_id for item in active_realized
        ):
            raise ValueError("supersedes_entry_id must reference the active validated benefit for this claim group")
        entry = ValueLedgerEntry(
            ledger_entry_id=self._next_entry_id(),
            claim_group_id=evidence.claim_group_id,
            category=ValueCategory.VALIDATED_REALIZED_BENEFIT,
            quantity=1.0,
            unit="validated_economic_event",
            monetary_value=float(evidence.amount),
            currency=evidence.currency,
            method=evidence.method,
            evidence_state=ValueEvidenceState.VALIDATED,
            maturity=ValueMaturity.VALIDATED_REALIZED_VALUE,
            source_references=evidence.source_references,
            computed_at=evidence.validated_at,
            validated_at=evidence.validated_at,
            validated_by=evidence.validated_by,
            supersedes_entry_id=supersedes_entry_id,
        )
        self.repository.append_entry(entry)
        return entry

    def has_episode(self, episode_id: str) -> bool:
        if self.repository.entries(episode_id):
            return True
        return any(episode_id in group.episode_ids for group in self.repository.claim_groups())

    def export_state(self) -> dict[str, object]:
        return {
            "schema": "value_ledger_service_v1",
            "repository": self.repository.export_state(),
        }

    def restore_state(self, state: dict[str, object]) -> None:
        if state.get("schema") != "value_ledger_service_v1":
            raise ValueError(f"unsupported value-ledger service schema: {state.get('schema')!r}")
        raw = state.get("repository")
        if not isinstance(raw, dict):
            raise TypeError("invalid value-ledger service checkpoint")
        self.repository.restore_state(raw)
        max_id = 0
        for item in self.repository.entries():
            if item.ledger_entry_id.startswith("VAL-"):
                try:
                    max_id = max(max_id, int(item.ledger_entry_id.split("-", 1)[1]))
                except ValueError:
                    pass
        self._entry_counter = count(max_id + 1)

    def _currency_or_none(self, entries: tuple[ValueLedgerEntry, ...]) -> str | None:
        currencies = {item.currency for item in entries if item.currency is not None}
        if not currencies:
            return None
        if len(currencies) > 1:
            raise ValueError("value summary cannot combine multiple currencies without an FX policy")
        return next(iter(currencies))

    def episode_summary(self, episode_id: str, *, as_of: datetime | None = None) -> EpisodeValueSummary:
        as_of = as_of or datetime.now(timezone.utc)
        entries = tuple(item for item in self.repository.active_entries(episode_id) if item.computed_at <= as_of)
        currency = self._currency_or_none(entries)
        estimated = sum(
            item.monetary_value or 0.0 for item in entries
            if item.category in {ValueCategory.SCRAP_EXPOSURE_ESTIMATE, ValueCategory.REWORK_EXPOSURE_ESTIMATE}
        )
        validated = sum(
            item.monetary_value or 0.0 for item in entries
            if item.category == ValueCategory.VALIDATED_REALIZED_BENEFIT
        )
        costs = sum(
            item.monetary_value or 0.0 for item in entries
            if item.category in {
                ValueCategory.COMPUTE_COST,
                ValueCategory.INVESTIGATION_COST,
                ValueCategory.FALSE_ACTIONABLE_EVENT_COST,
            }
        )
        protected_entries = tuple(item for item in entries if item.category == ValueCategory.WAFERS_PROTECTED)
        protected_ids = {mid for item in protected_entries for mid in item.material_ids}
        protected = len(protected_ids) if protected_ids else int(sum(item.quantity for item in protected_entries))
        engineering = sum(item.quantity for item in entries if item.category == ValueCategory.ENGINEERING_TIME_SAVED)
        maturity = ValueMaturity.ESTIMATED_EXPOSURE
        if validated > 0:
            maturity = ValueMaturity.VALIDATED_REALIZED_VALUE
        elif any(item.maturity == ValueMaturity.OUTCOME_MATURE for item in entries):
            maturity = ValueMaturity.FINANCIAL_VALIDATION_PENDING
        elif any(item.maturity == ValueMaturity.OUTCOME_PARTIAL for item in entries):
            maturity = ValueMaturity.OUTCOME_PARTIAL
        elif any(item.maturity == ValueMaturity.ACTION_RECORDED for item in entries):
            maturity = ValueMaturity.ACTION_RECORDED
        latest = max((item.computed_at for item in entries), default=None)
        return EpisodeValueSummary(
            episode_id=episode_id,
            as_of=as_of,
            estimated_exposure_value=estimated,
            validated_realized_benefit=validated,
            observed_operating_cost=costs,
            currency=currency,
            wafers_protected=protected,
            engineering_hours_saved=engineering,
            maturity=maturity,
            latest_entry_at=latest,
        )

    def episode_ledger(self, episode_id: str, *, as_of: datetime | None = None) -> EpisodeValueLedgerView:
        entries = self.repository.entries(episode_id)
        group_ids = {item.claim_group_id for item in entries if item.claim_group_id is not None}
        groups = tuple(self.repository.claim_group(group_id) for group_id in sorted(group_ids))
        attrs = tuple(
            attribution for group_id in sorted(group_ids)
            for attribution in self.repository.attributions(group_id)
        )
        return EpisodeValueLedgerView(
            summary=self.episode_summary(episode_id, as_of=as_of),
            entries=entries,
            claim_groups=groups,
            attributions=attrs,
        )

    def program_summary(self, *, as_of: datetime | None = None) -> ProgramValueSummary:
        as_of = as_of or datetime.now(timezone.utc)
        entries = tuple(item for item in self.repository.active_entries() if item.computed_at <= as_of)
        currency = self._currency_or_none(entries)
        estimated = sum(
            item.monetary_value or 0.0 for item in entries
            if item.category in {ValueCategory.SCRAP_EXPOSURE_ESTIMATE, ValueCategory.REWORK_EXPOSURE_ESTIMATE}
        )
        validated_entries = tuple(
            item for item in entries if item.category == ValueCategory.VALIDATED_REALIZED_BENEFIT
        )
        # Repository uniqueness of economic_event_key + one active validated benefit per claim group
        # is the official double-counting guard. No per-episode summation is used here.
        validated_group_ids = {item.claim_group_id for item in validated_entries if item.claim_group_id is not None}
        seen_materials: dict[str, str] = {}
        for group_id in sorted(validated_group_ids):
            group = self.repository.claim_group(group_id)
            for material_id in group.material_ids:
                other = seen_materials.get(material_id)
                if other is not None and other != group_id:
                    raise ValueError(
                        "validated claim groups overlap on material IDs; explicit benefit allocation/reconciliation is required "
                        f"before program aggregation ({other!r}, {group_id!r}, material={material_id!r})"
                    )
                seen_materials[material_id] = group_id
        validated = sum(item.monetary_value or 0.0 for item in validated_entries)
        costs = sum(
            item.monetary_value or 0.0 for item in entries
            if item.category in {
                ValueCategory.COMPUTE_COST,
                ValueCategory.INVESTIGATION_COST,
                ValueCategory.FALSE_ACTIONABLE_EVENT_COST,
            }
        )
        net = validated - costs
        bcr = validated / costs if costs > 0 else None
        protected_entries = tuple(item for item in entries if item.category == ValueCategory.WAFERS_PROTECTED)
        protected_ids = {mid for item in protected_entries for mid in item.material_ids}
        protected = len(protected_ids) if protected_ids else int(sum(item.quantity for item in protected_entries))
        engineering = sum(item.quantity for item in entries if item.category == ValueCategory.ENGINEERING_TIME_SAVED)
        return ProgramValueSummary(
            as_of=as_of,
            currency=currency,
            estimated_exposure_value=estimated,
            validated_realized_benefit=validated,
            operating_cost=costs,
            net_validated_value=net,
            benefit_cost_ratio=bcr,
            wafers_protected=protected,
            engineering_hours_saved=engineering,
            validated_claim_groups=len({item.claim_group_id for item in validated_entries}),
            active_entries=len(entries),
        )
