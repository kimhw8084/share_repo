from __future__ import annotations

from pathlib import Path

import yaml

from ephi.domain.value import CostModelApproval, CostModelDefinition


class CostModelRegistry:
    def __init__(self) -> None:
        self._models: dict[tuple[str, str], CostModelDefinition] = {}

    def register(self, model: CostModelDefinition) -> None:
        key = (model.cost_model_id, model.version)
        existing = self._models.get(key)
        if existing is not None and existing != model:
            raise ValueError(f"cost model already registered with different content: {key}")
        self._models[key] = model

    def get(self, cost_model_id: str, version: str) -> CostModelDefinition:
        try:
            return self._models[(cost_model_id, version)]
        except KeyError as exc:
            raise KeyError(f"unknown cost model: {cost_model_id}@{version}") from exc

    def approved(self, cost_model_id: str, version: str) -> CostModelDefinition:
        model = self.get(cost_model_id, version)
        if model.approval_status != CostModelApproval.APPROVED:
            raise ValueError(f"cost model is not approved: {cost_model_id}@{version}")
        return model


def load_cost_model(path: str | Path) -> CostModelDefinition:
    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("cost-model YAML root must be a mapping")
    return CostModelDefinition.model_validate(raw)
