from __future__ import annotations

from collections import defaultdict
from typing import Protocol

from ephi.domain.value import BenefitAttribution, BenefitClaimGroup, ValueLedgerEntry


class ValueLedgerRepository(Protocol):
    def add_claim_group(self, group: BenefitClaimGroup) -> None: ...
    def add_attribution(self, attribution: BenefitAttribution) -> None: ...
    def append_entry(self, entry: ValueLedgerEntry) -> None: ...
    def claim_group(self, claim_group_id: str) -> BenefitClaimGroup: ...
    def claim_groups(self) -> tuple[BenefitClaimGroup, ...]: ...
    def attributions(self, claim_group_id: str | None = None) -> tuple[BenefitAttribution, ...]: ...
    def entries(self, episode_id: str | None = None) -> tuple[ValueLedgerEntry, ...]: ...
    def active_entries(self, episode_id: str | None = None) -> tuple[ValueLedgerEntry, ...]: ...
    def export_state(self) -> dict[str, object]: ...
    def restore_state(self, state: dict[str, object]) -> None: ...


class InMemoryValueLedgerRepository:
    def __init__(self) -> None:
        self._groups: dict[str, BenefitClaimGroup] = {}
        self._economic_event_to_group: dict[str, str] = {}
        self._attributions: dict[tuple[str, str], BenefitAttribution] = {}
        self._entries: list[ValueLedgerEntry] = []
        self._entry_by_id: dict[str, ValueLedgerEntry] = {}
        self._superseded: set[str] = set()

    def add_claim_group(self, group: BenefitClaimGroup) -> None:
        existing = self._groups.get(group.claim_group_id)
        if existing is not None:
            if existing != group:
                raise ValueError(f"claim group already exists with different content: {group.claim_group_id}")
            return
        other = self._economic_event_to_group.get(group.economic_event_key)
        if other is not None and other != group.claim_group_id:
            raise ValueError(
                "economic_event_key already belongs to another claim group; combine contributing episodes "
                f"into the existing group {other!r}"
            )
        self._groups[group.claim_group_id] = group
        self._economic_event_to_group[group.economic_event_key] = group.claim_group_id

    def add_attribution(self, attribution: BenefitAttribution) -> None:
        group = self.claim_group(attribution.claim_group_id)
        if attribution.episode_id not in group.episode_ids:
            raise ValueError("attribution episode_id must belong to claim group")
        self._attributions[(attribution.claim_group_id, attribution.episode_id)] = attribution

    def append_entry(self, entry: ValueLedgerEntry) -> None:
        if entry.ledger_entry_id in self._entry_by_id:
            if self._entry_by_id[entry.ledger_entry_id] == entry:
                return
            raise ValueError(f"ledger entry ID already exists with different content: {entry.ledger_entry_id}")
        if entry.claim_group_id is not None:
            self.claim_group(entry.claim_group_id)
        if entry.supersedes_entry_id is not None:
            try:
                previous = self._entry_by_id[entry.supersedes_entry_id]
            except KeyError as exc:
                raise ValueError(f"supersedes unknown ledger entry: {entry.supersedes_entry_id}") from exc
            if previous.ledger_entry_id in self._superseded:
                raise ValueError("cannot supersede an entry that has already been superseded")
            if previous.claim_group_id != entry.claim_group_id or previous.category != entry.category:
                raise ValueError("ledger revision must preserve claim_group_id and category")
            self._superseded.add(previous.ledger_entry_id)
        self._entries.append(entry)
        self._entry_by_id[entry.ledger_entry_id] = entry

    def claim_group(self, claim_group_id: str) -> BenefitClaimGroup:
        try:
            return self._groups[claim_group_id]
        except KeyError as exc:
            raise KeyError(f"unknown benefit claim group: {claim_group_id}") from exc

    def claim_groups(self) -> tuple[BenefitClaimGroup, ...]:
        return tuple(self._groups.values())

    def attributions(self, claim_group_id: str | None = None) -> tuple[BenefitAttribution, ...]:
        values = tuple(self._attributions.values())
        if claim_group_id is None:
            return values
        return tuple(item for item in values if item.claim_group_id == claim_group_id)

    def entries(self, episode_id: str | None = None) -> tuple[ValueLedgerEntry, ...]:
        if episode_id is None:
            return tuple(self._entries)
        group_ids = {
            group.claim_group_id
            for group in self._groups.values()
            if episode_id in group.episode_ids
        }
        return tuple(
            item for item in self._entries
            if item.episode_id == episode_id or (item.claim_group_id is not None and item.claim_group_id in group_ids)
        )

    def active_entries(self, episode_id: str | None = None) -> tuple[ValueLedgerEntry, ...]:
        return tuple(
            item for item in self.entries(episode_id)
            if item.ledger_entry_id not in self._superseded
        )

    def export_state(self) -> dict[str, object]:
        return {
            "schema": "value_ledger_repository_v1",
            "claim_groups": [item.model_dump(mode="json") for item in self._groups.values()],
            "attributions": [item.model_dump(mode="json") for item in self._attributions.values()],
            "entries": [item.model_dump(mode="json") for item in self._entries],
        }

    def restore_state(self, state: dict[str, object]) -> None:
        if state.get("schema") != "value_ledger_repository_v1":
            raise ValueError(f"unsupported value-ledger repository schema: {state.get('schema')!r}")
        groups = state.get("claim_groups", [])
        attrs = state.get("attributions", [])
        entries = state.get("entries", [])
        if not isinstance(groups, list) or not isinstance(attrs, list) or not isinstance(entries, list):
            raise TypeError("invalid value-ledger repository checkpoint")
        self.__init__()
        for raw in groups:
            self.add_claim_group(BenefitClaimGroup.model_validate(raw))
        for raw in attrs:
            self.add_attribution(BenefitAttribution.model_validate(raw))
        for raw in entries:
            self.append_entry(ValueLedgerEntry.model_validate(raw))
