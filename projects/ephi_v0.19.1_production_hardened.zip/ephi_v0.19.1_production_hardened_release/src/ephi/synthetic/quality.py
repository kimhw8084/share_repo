from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta

import numpy as np

from ephi.domain.quality import OutcomeMaturityState, QualityOutcomeObservation, QualityTargetType
from ephi.synthetic.scalar import ScalarScenarioConfig, generate_scalar_observations


@dataclass(frozen=True, slots=True)
class QualityScenarioConfig:
    executions_per_asset: int = 1000
    n_assets: int = 4
    seed: int = 41
    harmful: bool = True
    target_type: QualityTargetType = QualityTargetType.CONTINUOUS
    quality_latency_hours: int = 4


def generate_quality_scenario(config: QualityScenarioConfig = QualityScenarioConfig()):
    scalar = generate_scalar_observations(
        ScalarScenarioConfig(
            n_assets=config.n_assets,
            executions_per_asset=config.executions_per_asset,
            seed=config.seed,
            scenario="local-drift",
        )
    )
    rng = np.random.default_rng(config.seed + 1000)
    onset = int(config.executions_per_asset * 0.60)
    outcomes: list[QualityOutcomeObservation] = []
    target_asset = "A000"
    for obs in scalar:
        idx = int(obs.execution_id.rsplit("-", 1)[1])
        asset = obs.asset_id
        product_idx = int(obs.context.product_id[1:])
        recipe_idx = int(obs.context.recipe_id[1:])
        latent_shift = 0.0
        if asset == target_asset and idx >= onset:
            latent_shift = (idx - onset) / max(config.executions_per_asset - onset, 1) * 4.0
        context_effect = product_idx * 0.18 + recipe_idx * 0.12
        harm = (0.80 * latent_shift) if config.harmful else 0.0
        if config.target_type is QualityTargetType.CONTINUOUS:
            value = 50.0 + context_effect + harm + float(rng.normal(0.0, 0.28))
            target_id = "INLINE_Q_CONT"
        else:
            logit = -3.0 + 0.30 * product_idx + 0.15 * recipe_idx + (1.35 * latent_shift if config.harmful else 0.0)
            prob = 1.0 / (1.0 + np.exp(-logit))
            value = float(rng.random() < prob)
            target_id = "INLINE_Q_BIN"
        outcome_event = obs.event_time + timedelta(hours=config.quality_latency_hours)
        outcomes.append(
            QualityOutcomeObservation(
                material_id=obs.execution_id.replace("E-", "W-", 1),
                execution_id=obs.execution_id,
                asset_id=asset,
                context=obs.context,
                target_id=target_id,
                value=float(value),
                event_time=outcome_event,
                available_at=outcome_event + timedelta(minutes=10),
                maturity=OutcomeMaturityState.MATURE_AVAILABLE,
                sampled=True,
                sampling_reason="SYNTHETIC_SCHEDULED",
            )
        )
    return scalar, tuple(outcomes)
