from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import numpy as np

from ephi.domain.context import ContextKey
from ephi.domain.metrology import MetrologyObservation


@dataclass(frozen=True, slots=True)
class MetrologyScenarioConfig:
    n_heads: int = 3
    measurements_per_head: int = 900
    seed: int = 17
    scenario: str = "healthy"
    start_time: datetime = datetime(2026, 1, 1, tzinfo=timezone.utc)
    interval_minutes: int = 4
    sites_per_measurement: int = 13
    reference_every: int = 5
    remeasure_every: int = 20


def _site_coordinates(n: int) -> list[tuple[float, float]]:
    # Deterministic compact wafer pattern: center + rings.
    coords: list[tuple[float, float]] = [(0.0, 0.0)]
    remaining = max(0, n - 1)
    ring_sizes = [4, 8, 12, 16]
    radius = 0.45
    for ring in ring_sizes:
        if remaining <= 0:
            break
        count = min(ring, remaining)
        for idx in range(count):
            angle = 2.0 * np.pi * idx / count
            coords.append((radius * float(np.cos(angle)), radius * float(np.sin(angle))))
        remaining -= count
        radius = min(1.0, radius + 0.25)
    return coords[:n]


def generate_metrology_observations(
    config: MetrologyScenarioConfig = MetrologyScenarioConfig(),
) -> list[MetrologyObservation]:
    supported = {
        "healthy",
        "measurement-head-drift",
        "process-shift",
        "remeasure-instability",
        "spatial-head-drift",
    }
    if config.scenario not in supported:
        raise ValueError(f"Unsupported metrology scenario: {config.scenario}")
    if config.n_heads < 2 or config.measurements_per_head < 1:
        raise ValueError("metrology generator requires at least two heads and positive history")

    rng = np.random.default_rng(config.seed)
    heads = [f"HEAD_{chr(ord('A') + idx)}" for idx in range(config.n_heads)]
    target = heads[0]
    drift_start = int(config.measurements_per_head * 0.60)
    coords = _site_coordinates(config.sites_per_measurement)
    observations: list[MetrologyObservation] = []

    def append_measurement(
        *,
        idx: int,
        head: str,
        material_id: str,
        context: ContextKey,
        event_time: datetime,
        is_reference: bool,
        attempt: int,
        remeasure_group: str | None,
    ) -> None:
        head_offset = 0.12 * heads.index(head)
        process_shift = 0.0
        measurement_shift = 0.0
        spatial_shift = 0.0
        repeat_sigma = 0.18
        if idx >= drift_start:
            if config.scenario == "process-shift" and not is_reference:
                process_shift = 1.8
            if config.scenario == "measurement-head-drift" and head == target:
                measurement_shift = 1.8
            if config.scenario == "spatial-head-drift" and head == target:
                spatial_shift = 1.4
            if config.scenario == "remeasure-instability" and head == target and attempt > 0:
                repeat_sigma = 3.5

        base = 50.0 if is_reference else 100.0
        wafer_level = base + head_offset + process_shift + measurement_shift + float(rng.normal(0.0, 0.16))
        measurement_id = f"M-{material_id}-{head}-A{attempt}"
        for site_idx, (x, y) in enumerate(coords):
            r = float(np.sqrt(x * x + y * y))
            nominal_spatial = 0.22 * r + 0.03 * x
            edge_effect = spatial_shift * max(0.0, (r - 0.55) / 0.45)
            site_noise = float(rng.normal(0.0, repeat_sigma if attempt > 0 else 0.18))
            observations.append(
                MetrologyObservation(
                    measurement_id=measurement_id,
                    material_id=material_id,
                    asset_id="METRO001",
                    process_unit_id=head,
                    context=context,
                    characteristic_id="CD_MAIN",
                    value=wafer_level + nominal_spatial + edge_effect + site_noise,
                    event_time=event_time,
                    available_at=event_time + timedelta(minutes=1),
                    site_x=x,
                    site_y=y,
                    is_reference_material=is_reference,
                    remeasure_group_id=remeasure_group,
                    attempt_index=attempt,
                )
            )

    for idx in range(config.measurements_per_head):
        event_time = config.start_time + timedelta(minutes=config.interval_minutes * idx)
        context = ContextKey("METRO_OP", f"METHOD_{idx % 2}", f"P{idx % 3}", "TECH1")
        material_id = f"W{idx:07d}"
        remeasure_group = f"RG-{idx:07d}" if idx % config.remeasure_every == 0 else None
        for head in heads:
            append_measurement(
                idx=idx,
                head=head,
                material_id=material_id,
                context=context,
                event_time=event_time,
                is_reference=False,
                attempt=0,
                remeasure_group=remeasure_group,
            )
            if remeasure_group is not None:
                append_measurement(
                    idx=idx,
                    head=head,
                    material_id=material_id,
                    context=context,
                    event_time=event_time + timedelta(seconds=20),
                    is_reference=False,
                    attempt=1,
                    remeasure_group=remeasure_group,
                )

        if idx % config.reference_every == 0:
            ref_time = event_time + timedelta(minutes=1)
            ref_context = ContextKey("METRO_REF", "REFERENCE_METHOD", "REFERENCE", "TECH1")
            ref_material = f"REF{idx:07d}"
            for head in heads:
                append_measurement(
                    idx=idx,
                    head=head,
                    material_id=ref_material,
                    context=ref_context,
                    event_time=ref_time,
                    is_reference=True,
                    attempt=0,
                    remeasure_group=None,
                )

    return observations
