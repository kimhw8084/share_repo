from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np

from ephi.errors import MissingOptionalDependencyError


@dataclass(frozen=True, slots=True)
class SyntheticConfig:
    n_assets: int = 4
    executions_per_asset: int = 1000
    seed: int = 7
    scenario: str = "healthy"
    start_time: datetime = datetime(2026, 1, 1, tzinfo=timezone.utc)
    interval_minutes: int = 5


def _require_pyarrow():
    try:
        import pyarrow as pa  # type: ignore
        import pyarrow.parquet as pq  # type: ignore
    except ImportError as exc:
        raise MissingOptionalDependencyError(
            "Synthetic Parquet generation requires `pip install -e '.[local]'`"
        ) from exc
    return pa, pq


def generate_dataset(output: str | Path, config: SyntheticConfig) -> dict[str, Path]:
    pa, pq = _require_pyarrow()
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(config.seed)

    asset_ids = [f"A{idx:03d}" for idx in range(config.n_assets)]
    assets = pa.table(
        {
            "asset_id": asset_ids,
            "family_id": ["GENERIC_PROCESS"] * config.n_assets,
            "asset_type": ["EQUIPMENT"] * config.n_assets,
            "parent_asset_id": [None] * config.n_assets,
        }
    )

    executions: dict[str, list] = {
        "execution_id": [],
        "asset_id": [],
        "event_time": [],
        "available_at": [],
        "operation": [],
        "recipe_id": [],
        "product_id": [],
        "technology": [],
        "material_id": [],
    }
    signals: dict[str, list] = {
        "execution_id": [],
        "asset_id": [],
        "signal_id": [],
        "step_id": [],
        "value": [],
        "event_time": [],
        "available_at": [],
    }
    quality: dict[str, list] = {
        "material_id": [],
        "characteristic": [],
        "value": [],
        "event_time": [],
        "available_at": [],
        "maturity": [],
    }

    total_per_asset = config.executions_per_asset
    drift_start = int(total_per_asset * 0.60)
    target_asset = asset_ids[0]

    for asset_idx, asset_id in enumerate(asset_ids):
        base = 100.0 + asset_idx * 0.4
        for idx in range(total_per_asset):
            # Compatible assets share a manufacturing time axis so peer/common-mode
            # scenarios are temporally comparable. Asset identity must not shift the clock.
            event_time = config.start_time + timedelta(minutes=config.interval_minutes * idx)
            arrival_delay = int(rng.integers(1, 5))
            available_at = event_time + timedelta(minutes=arrival_delay)
            execution_id = f"E-{asset_id}-{idx:07d}"
            material_id = f"W-{asset_idx:03d}-{idx:07d}"
            product_id = f"P{idx % 3}"
            recipe_id = f"R{idx % 2}"

            executions["execution_id"].append(execution_id)
            executions["asset_id"].append(asset_id)
            executions["event_time"].append(event_time)
            executions["available_at"].append(available_at)
            executions["operation"].append("OP100")
            executions["recipe_id"].append(recipe_id)
            executions["product_id"].append(product_id)
            executions["technology"].append("TECH1")
            executions["material_id"].append(material_id)

            shift = 0.0
            if config.scenario == "local-drift" and asset_id == target_asset and idx >= drift_start:
                shift = (idx - drift_start) / max(total_per_asset - drift_start, 1) * 4.0
            elif config.scenario == "common-mode" and idx >= drift_start:
                shift = 3.0
            elif config.scenario == "unit-scale-change" and asset_id == target_asset and idx >= drift_start:
                shift = 0.0

            value = base + shift + rng.normal(0.0, 0.6)
            if config.scenario == "unit-scale-change" and asset_id == target_asset and idx >= drift_start:
                value *= 1000.0

            signals["execution_id"].append(execution_id)
            signals["asset_id"].append(asset_id)
            signals["signal_id"].append("PRESSURE_MAIN")
            signals["step_id"].append("STEP_STABLE")
            signals["value"].append(float(value))
            signals["event_time"].append(event_time)
            signals["available_at"].append(available_at + timedelta(minutes=1))

            q = 50.0 + 0.15 * max(shift, 0.0) + rng.normal(0.0, 0.25)
            q_event = event_time + timedelta(hours=4)
            quality["material_id"].append(material_id)
            quality["characteristic"].append("INLINE_Q")
            quality["value"].append(float(q))
            quality["event_time"].append(q_event)
            quality["available_at"].append(q_event + timedelta(minutes=10))
            quality["maturity"].append("INLINE")

    maintenance = pa.table(
        {
            "maintenance_event_id": [f"M-{a}-0001" for a in asset_ids],
            "asset_id": asset_ids,
            "event_type": ["ROUTINE_PM"] * len(asset_ids),
            "event_time": [config.start_time - timedelta(days=2)] * len(asset_ids),
            "available_at": [config.start_time - timedelta(days=2) + timedelta(minutes=5)] * len(asset_ids),
        }
    )

    tables = {
        "assets": assets,
        "executions": pa.table(executions),
        "signals": pa.table(signals),
        "quality": pa.table(quality),
        "maintenance": maintenance,
    }
    outputs: dict[str, Path] = {}
    for name, table in tables.items():
        path = output / f"{name}.parquet"
        pq.write_table(table, path, compression="zstd")
        outputs[name] = path
    return outputs
