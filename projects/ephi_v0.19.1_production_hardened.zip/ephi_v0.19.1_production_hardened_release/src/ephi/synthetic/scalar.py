from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import numpy as np

from ephi.domain.context import ContextKey
from ephi.domain.features import ScalarFeatureObservation


@dataclass(frozen=True, slots=True)
class ScalarScenarioConfig:
    n_assets: int = 4
    executions_per_asset: int = 1000
    seed: int = 7
    scenario: str = "healthy"
    start_time: datetime = datetime(2026, 1, 1, tzinfo=timezone.utc)
    interval_minutes: int = 5


def generate_scalar_observations(
    config: ScalarScenarioConfig = ScalarScenarioConfig(),
) -> list[ScalarFeatureObservation]:
    """Generate concurrent scalar observations without optional Arrow dependencies."""

    if config.scenario not in {"healthy", "local-drift", "common-mode", "unit-scale-change"}:
        raise ValueError(f"Unsupported scenario: {config.scenario}")
    if config.n_assets < 1 or config.executions_per_asset < 1:
        raise ValueError("n_assets and executions_per_asset must be positive")

    rng = np.random.default_rng(config.seed)
    asset_ids = [f"A{idx:03d}" for idx in range(config.n_assets)]
    target_asset = asset_ids[0]
    drift_start = int(config.executions_per_asset * 0.60)
    observations: list[ScalarFeatureObservation] = []

    for idx in range(config.executions_per_asset):
        event_time = config.start_time + timedelta(minutes=config.interval_minutes * idx)
        product_id = f"P{idx % 3}"
        recipe_id = f"R{idx % 2}"
        context = ContextKey("OP100", recipe_id, product_id, "TECH1")

        for asset_idx, asset_id in enumerate(asset_ids):
            base = 100.0 + asset_idx * 0.4
            shift = 0.0
            if config.scenario == "local-drift" and asset_id == target_asset and idx >= drift_start:
                shift = (idx - drift_start) / max(config.executions_per_asset - drift_start, 1) * 4.0
            elif config.scenario == "common-mode" and idx >= drift_start:
                shift = 3.0

            value = base + shift + float(rng.normal(0.0, 0.6))
            if config.scenario == "unit-scale-change" and asset_id == target_asset and idx >= drift_start:
                value *= 1000.0

            observations.append(
                ScalarFeatureObservation(
                    execution_id=f"E-{asset_id}-{idx:07d}",
                    asset_id=asset_id,
                    context=context,
                    feature_id="PRESSURE_MAIN:STEP_STABLE:value",
                    value=value,
                    event_time=event_time,
                    available_at=event_time + timedelta(minutes=2),
                )
            )

    return observations
