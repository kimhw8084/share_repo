from __future__ import annotations

from dataclasses import dataclass, field

from ephi.detectors.behavioral import BehavioralDetectorEngine
from ephi.domain.episode import HealthEpisode
from ephi.domain.features import ScalarFeatureObservation
from ephi.domain.health import HealthAssessment
from ephi.episodes.fleet import FleetEpisodeService
from ephi.episodes.service import EpisodeService
from ephi.evidence.factory import evidence_from_detector
from ephi.evidence.fusion import build_health_assessment


@dataclass(frozen=True, slots=True)
class PipelineResult:
    assessments: tuple[HealthAssessment, ...]
    episode_updates: tuple[HealthEpisode, ...]
    fleet_episode_updates: tuple[object, ...] = ()


@dataclass(slots=True)
class BehavioralHealthPipeline:
    detector: BehavioralDetectorEngine = field(default_factory=BehavioralDetectorEngine)
    episodes: EpisodeService = field(default_factory=EpisodeService)
    fleet_episodes: FleetEpisodeService = field(default_factory=FleetEpisodeService)

    def process(self, observations: list[ScalarFeatureObservation]) -> PipelineResult:
        detector_results = self.detector.process_batch(observations)
        assessments: list[HealthAssessment] = []
        episode_updates: list[HealthEpisode] = []
        for result in detector_results:
            evidence = evidence_from_detector(result)
            assessment = build_health_assessment(result, evidence)
            assessments.append(assessment)
            episode = self.episodes.process(assessment)
            if episode is not None:
                episode_updates.append(episode)

        fleet_updates: list[object] = []
        groups: dict[tuple[object, str], list[HealthAssessment]] = {}
        for assessment in assessments:
            key = (assessment.event_time, assessment.context.stable_key())
            groups.setdefault(key, []).append(assessment)
        for group in groups.values():
            update = self.fleet_episodes.process_group(group)
            if update is not None:
                fleet_updates.append(update)

        return PipelineResult(
            tuple(assessments),
            tuple(episode_updates),
            tuple(fleet_updates),
        )
