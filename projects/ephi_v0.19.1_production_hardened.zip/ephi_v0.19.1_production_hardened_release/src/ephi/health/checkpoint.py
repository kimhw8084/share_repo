from __future__ import annotations

import json

from ephi.adapters.base.state_store import StateStore

CHECKPOINT_SCHEMA = "behavioral_pipeline_state_v2"
_SUPPORTED_SCHEMAS = {"behavioral_pipeline_state_v1", CHECKPOINT_SCHEMA}


def save_pipeline_state(
    pipeline,
    state_store: StateStore,
    *,
    key: str = "pipeline:behavioral",
    expected_version: int | None = None,
) -> int:
    payload = {
        "schema": CHECKPOINT_SCHEMA,
        "detector": pipeline.detector.export_state(),
        "episodes": pipeline.episodes.export_state(),
        "fleet_episodes": pipeline.fleet_episodes.export_state(),
    }
    record = state_store.compare_and_set(
        key,
        expected_version=expected_version,
        value=json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8"),
    )
    return record.version


def restore_pipeline_state(
    pipeline,
    state_store: StateStore,
    *,
    key: str = "pipeline:behavioral",
) -> int | None:
    record = state_store.get(key)
    if record is None:
        return None
    payload = json.loads(record.value.decode("utf-8"))
    schema = payload.get("schema")
    if schema not in _SUPPORTED_SCHEMAS:
        raise ValueError(f"Unsupported pipeline checkpoint schema: {schema!r}")
    detector = payload.get("detector")
    episodes = payload.get("episodes")
    if not isinstance(detector, dict) or not isinstance(episodes, dict):
        raise TypeError("invalid pipeline checkpoint")
    pipeline.detector.restore_state(detector)
    pipeline.episodes.restore_state(episodes)
    if schema == CHECKPOINT_SCHEMA:
        fleet = payload.get("fleet_episodes", {})
        if not isinstance(fleet, dict):
            raise TypeError("invalid fleet episode checkpoint")
        pipeline.fleet_episodes.restore_state(fleet)
    return record.version
