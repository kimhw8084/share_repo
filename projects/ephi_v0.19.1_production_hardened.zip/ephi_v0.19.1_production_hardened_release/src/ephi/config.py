from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field

from ephi.domain.capabilities import Capability


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class AppConfig(StrictModel):
    environment: str = "local"
    log_level: str = "INFO"


class RuntimeConfig(StrictModel):
    batch_rows: int = Field(default=50_000, ge=1)
    overlap_seconds: int = Field(default=300, ge=0)
    checkpoint_every_batches: int = Field(default=10, ge=1)


class LocalConfig(StrictModel):
    root_dir: str = "./.ephi-data"
    state_db: str = "./.ephi-data/state/ephi.sqlite3"
    materialization_dir: str = "./.ephi-data/materializations"
    artifact_dir: str = "./.ephi-data/artifacts"




class DatasetBindingConfig(StrictModel):
    physical_name: str
    columns: dict[str, str] = Field(default_factory=dict)


class DataConfig(StrictModel):
    datasets: dict[str, DatasetBindingConfig] = Field(default_factory=dict)


class CharacteristicScaleConfig(StrictModel):
    resolution: float | None = Field(default=None, gt=0)
    uncertainty: float | None = Field(default=None, gt=0)


class MeasurementConfig(StrictModel):
    characteristics: dict[str, CharacteristicScaleConfig] = Field(default_factory=dict)




class OperationsConfig(StrictModel):
    control_http_mutation_enabled: bool = False
    runtime_role: str = "LOCAL"
    family_id: str = "UNSPECIFIED"


class PortConfig(StrictModel):
    required_capabilities: tuple[Capability, ...] = ()
    allow_partial_capabilities: bool = False


class AutopilotConfig(StrictModel):
    accepted_datasets: tuple[str, ...] = ()
    unavailable_datasets: tuple[str, ...] = ()
    inferred_capabilities: tuple[Capability, ...] = ()
    family_profile_state: str = "UNINITIALIZED"
    binding_dir: str = "./company_bindings"


class EphiConfig(StrictModel):
    app: AppConfig = AppConfig()
    runtime: RuntimeConfig = RuntimeConfig()
    local: LocalConfig = LocalConfig()
    data: DataConfig = DataConfig()
    measurement: MeasurementConfig = MeasurementConfig()
    operations: OperationsConfig = OperationsConfig()
    port: PortConfig = PortConfig()
    autopilot: AutopilotConfig = AutopilotConfig()

    def stable_hash(self) -> str:
        payload = json.dumps(self.model_dump(mode="json"), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def load_config(paths: list[str | Path] | tuple[str | Path, ...]) -> EphiConfig:
    merged: dict[str, Any] = {}
    for raw_path in paths:
        path = Path(raw_path)
        with path.open("r", encoding="utf-8") as handle:
            content = yaml.safe_load(handle) or {}
        if not isinstance(content, dict):
            raise ValueError(f"Configuration root must be a mapping: {path}")
        merged = _deep_merge(merged, content)
    return EphiConfig.model_validate(merged)
