from __future__ import annotations

import json
from datetime import datetime, timezone

from ephi.adapters.base.state_store import StateStore
from ephi.domain.operations import FreshnessChannel, FreshnessHeartbeat, OperationalSLOReport
from ephi.operations.telemetry import evaluate_freshness


_STATE_KEY = "operations:freshness:v1"


class FreshnessTracker:
    """Persists latest analytical/data freshness heartbeats for fail-soft status reporting."""

    def __init__(self, state_store: StateStore | None = None) -> None:
        self.state_store = state_store
        self._heartbeats: dict[FreshnessChannel, FreshnessHeartbeat] = {}
        self._state_version: int | None = None
        if state_store is not None:
            self.restore()

    def mark(
        self,
        channel: FreshnessChannel,
        *,
        refreshed_at: datetime | None = None,
        source_as_of: datetime | None = None,
        version: str | None = None,
    ) -> FreshnessHeartbeat:
        heartbeat = FreshnessHeartbeat(
            channel=channel,
            refreshed_at=refreshed_at or datetime.now(timezone.utc),
            source_as_of=source_as_of,
            version=version,
        )
        previous = self._heartbeats.get(channel)
        if previous is not None and heartbeat.refreshed_at < previous.refreshed_at:
            raise ValueError(f"freshness heartbeat cannot move backward for {channel.value}")
        self._heartbeats[channel] = heartbeat
        self.checkpoint()
        return heartbeat

    def latest(self, channel: FreshnessChannel) -> FreshnessHeartbeat | None:
        return self._heartbeats.get(channel)

    def report(
        self,
        *,
        as_of: datetime,
        targets: dict[str, tuple[float, float]],
    ) -> OperationalSLOReport:
        observed: dict[str, float | None] = {}
        for metric in targets:
            try:
                channel = FreshnessChannel(metric)
            except ValueError:
                observed[metric] = None
                continue
            heartbeat = self._heartbeats.get(channel)
            if heartbeat is None:
                observed[metric] = None
                continue
            base = heartbeat.source_as_of or heartbeat.refreshed_at
            observed[metric] = max(0.0, (as_of - base).total_seconds())
        return evaluate_freshness(as_of=as_of, observations=observed, targets=targets)

    def checkpoint(self) -> None:
        if self.state_store is None:
            return
        payload = json.dumps(
            [self._heartbeats[key].model_dump(mode="json") for key in sorted(self._heartbeats, key=lambda item: item.value)],
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        record = self.state_store.compare_and_set(_STATE_KEY, expected_version=self._state_version, value=payload)
        self._state_version = record.version

    def restore(self) -> None:
        if self.state_store is None:
            return
        record = self.state_store.get(_STATE_KEY)
        if record is None:
            return
        items = [FreshnessHeartbeat.model_validate(item) for item in json.loads(record.value.decode("utf-8"))]
        self._heartbeats = {item.channel: item for item in items}
        self._state_version = record.version
