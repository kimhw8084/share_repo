from __future__ import annotations

import hashlib
import json
import time
from datetime import datetime
from typing import Any, Callable, Mapping

from ephi.domain.operations import CandidateRole, ShadowComparison, ShadowResult


def _fingerprint(value: Any) -> str:
    try:
        payload = json.dumps(value, sort_keys=True, default=str, separators=(",", ":")).encode("utf-8")
    except TypeError:
        payload = repr(value).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


class ShadowRunner:
    """Run challengers on identical inputs without allowing them to affect production output."""

    def __init__(
        self,
        champion_id: str,
        champion: Callable[[Any], Any],
        challengers: Mapping[str, Callable[[Any], Any]],
        *,
        actionable: Callable[[Any], bool] | None = None,
    ) -> None:
        self.champion_id = champion_id
        self.champion = champion
        self.challengers = dict(challengers)
        self.actionable = actionable or (lambda value: bool(value))

    def _run_one(self, candidate_id: str, role: CandidateRole, fn: Callable[[Any], Any], value: Any) -> tuple[ShadowResult, Any]:
        started = time.perf_counter()
        try:
            output = fn(value)
            error = None
            actionable = bool(self.actionable(output))
            fingerprint = _fingerprint(output)
        except Exception as exc:  # challengers must not break champion execution
            output = None
            error = f"{type(exc).__name__}: {exc}"
            actionable = False
            fingerprint = _fingerprint({"error": error})
        elapsed = (time.perf_counter() - started) * 1000.0
        return (
            ShadowResult(
                candidate_id=candidate_id,
                role=role,
                output_fingerprint=fingerprint,
                actionable=actionable,
                latency_ms=elapsed,
                error=error,
            ),
            output,
        )

    def compare(self, *, subject_id: str, as_of: datetime, value: Any) -> tuple[ShadowComparison, Any]:
        champion_result, champion_output = self._run_one(
            self.champion_id, CandidateRole.CHAMPION, self.champion, value
        )
        challengers: list[ShadowResult] = []
        for candidate_id, fn in self.challengers.items():
            result, _ = self._run_one(candidate_id, CandidateRole.CHALLENGER, fn, value)
            challengers.append(result)
        return (
            ShadowComparison(
                subject_id=subject_id,
                as_of=as_of,
                champion=champion_result,
                challengers=tuple(challengers),
                production_output_changed=False,
            ),
            champion_output,
        )
