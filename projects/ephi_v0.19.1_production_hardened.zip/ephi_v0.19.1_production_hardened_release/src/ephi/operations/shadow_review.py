from __future__ import annotations

from dataclasses import dataclass

from ephi.domain.operations import (
    EngineerShadowReview,
    EngineerShadowSummary,
    ShadowGateDecision,
    ShadowReviewDisposition,
)


@dataclass(frozen=True, slots=True)
class ShadowGatePolicy:
    min_reviews: int = 20
    min_useful_rate: float = 0.70
    max_misleading_rate: float = 0.05
    max_invalid_comparison_rate: float = 0.10
    min_verification_useful_rate: float = 0.60


def summarize_shadow_reviews(reviews: tuple[EngineerShadowReview, ...]) -> EngineerShadowSummary:
    n = len(reviews)
    useful = sum(
        review.disposition in {ShadowReviewDisposition.WANT_EVENT, ShadowReviewDisposition.PARTIALLY_USEFUL}
        for review in reviews
    )
    misleading = sum(review.disposition == ShadowReviewDisposition.MISLEADING for review in reviews)
    invalid = sum(not review.comparison_valid for review in reviews)
    verification = sum(review.verification_useful for review in reviews)
    denominator = n or 1
    return EngineerShadowSummary(
        reviews=n,
        want_or_partial=useful,
        misleading=misleading,
        invalid_comparison=invalid,
        verification_useful=verification,
        useful_rate=useful / denominator,
        misleading_rate=misleading / denominator,
        invalid_comparison_rate=invalid / denominator,
        verification_useful_rate=verification / denominator,
    )


def apply_shadow_gate(
    reviews: tuple[EngineerShadowReview, ...],
    policy: ShadowGatePolicy | None = None,
) -> ShadowGateDecision:
    policy = policy or ShadowGatePolicy()
    summary = summarize_shadow_reviews(reviews)
    reasons: list[str] = []
    if summary.reviews < policy.min_reviews:
        reasons.append(f"review count {summary.reviews} < {policy.min_reviews}")
    if summary.useful_rate < policy.min_useful_rate:
        reasons.append(f"useful rate {summary.useful_rate:.3f} < {policy.min_useful_rate:.3f}")
    if summary.misleading_rate > policy.max_misleading_rate:
        reasons.append(f"misleading rate {summary.misleading_rate:.3f} > {policy.max_misleading_rate:.3f}")
    if summary.invalid_comparison_rate > policy.max_invalid_comparison_rate:
        reasons.append(
            f"invalid comparison rate {summary.invalid_comparison_rate:.3f} > {policy.max_invalid_comparison_rate:.3f}"
        )
    if summary.verification_useful_rate < policy.min_verification_useful_rate:
        reasons.append(
            f"verification useful rate {summary.verification_useful_rate:.3f} < {policy.min_verification_useful_rate:.3f}"
        )
    return ShadowGateDecision(passed=not reasons, reasons=tuple(reasons), summary=summary)
