from __future__ import annotations

from ephi.domain.operations import ReleaseCompatibility, ReleaseCompatibilityState
from ephi.registry.releases import ReleaseManifest


def assess_release_compatibility(
    source: ReleaseManifest,
    target: ReleaseManifest,
    *,
    source_state_schema_version: str = "1",
    target_state_schema_version: str = "1",
    destructive_migration: bool = False,
    migration_available: bool = False,
    migration_reversible: bool = False,
) -> ReleaseCompatibility:
    reasons: list[str] = []
    rebuilds: list[str] = []
    if destructive_migration:
        return ReleaseCompatibility(
            from_release_id=source.release_id,
            to_release_id=target.release_id,
            state=ReleaseCompatibilityState.INCOMPATIBLE,
            reasons=("destructive state migration",),
            rollback_allowed=False,
        )
    if source_state_schema_version != target_state_schema_version:
        reasons.append("state schema version changed")
        if migration_available:
            reasons.append("deterministic state migration available")
            state = ReleaseCompatibilityState.REQUIRES_MIGRATION
        else:
            rebuilds.append("state/checkpoint compatibility review")
            state = ReleaseCompatibilityState.REQUIRES_REBUILD
    else:
        state = ReleaseCompatibilityState.COMPATIBLE
    if source.package_version == target.package_version and source.code_tree_sha256 != target.code_tree_sha256:
        reasons.append("same package version has different code hash")
        return ReleaseCompatibility(
            from_release_id=source.release_id,
            to_release_id=target.release_id,
            state=ReleaseCompatibilityState.INCOMPATIBLE,
            reasons=tuple(reasons),
            rollback_allowed=False,
            required_rebuilds=tuple(rebuilds),
        )
    return ReleaseCompatibility(
        from_release_id=source.release_id,
        to_release_id=target.release_id,
        state=state,
        reasons=tuple(reasons),
        rollback_allowed=(state != ReleaseCompatibilityState.INCOMPATIBLE and (state != ReleaseCompatibilityState.REQUIRES_MIGRATION or migration_reversible)),
        required_rebuilds=tuple(rebuilds),
    )
