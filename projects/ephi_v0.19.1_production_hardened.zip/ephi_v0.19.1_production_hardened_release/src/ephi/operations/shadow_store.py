from __future__ import annotations

import json
from collections import defaultdict

from ephi.adapters.base.state_store import StateStore
from ephi.domain.operations import ChallengerShadowSummary, ShadowComparison


_STATE_KEY = "operations:shadow-comparisons:v1"


class ShadowComparisonStore:
    def __init__(self, state_store: StateStore | None = None) -> None:
        self.state_store = state_store
        self._items: list[ShadowComparison] = []
        self._state_version: int | None = None
        if state_store is not None:
            self.restore()

    def append(self, comparison: ShadowComparison) -> None:
        self._items.append(comparison)
        self.checkpoint()

    def items(self) -> tuple[ShadowComparison, ...]:
        return tuple(self._items)

    def summaries(self) -> tuple[ChallengerShadowSummary, ...]:
        grouped: dict[str, list[tuple[ShadowComparison, object]]] = defaultdict(list)
        for comparison in self._items:
            for challenger in comparison.challengers:
                grouped[challenger.candidate_id].append((comparison, challenger))
        summaries: list[ChallengerShadowSummary] = []
        for candidate_id, rows in sorted(grouped.items()):
            n = len(rows)
            disagreements = sum(
                challenger.actionable != comparison.champion.actionable
                for comparison, challenger in rows
            )
            errors = sum(challenger.error is not None for _, challenger in rows)
            latency_delta = sum(
                challenger.latency_ms - comparison.champion.latency_ms
                for comparison, challenger in rows
            ) / (n or 1)
            summaries.append(
                ChallengerShadowSummary(
                    challenger_id=candidate_id,
                    observations=n,
                    actionable_disagreements=disagreements,
                    errors=errors,
                    actionable_disagreement_rate=disagreements / (n or 1),
                    error_rate=errors / (n or 1),
                    mean_latency_delta_ms=latency_delta,
                )
            )
        return tuple(summaries)

    def checkpoint(self) -> None:
        if self.state_store is None:
            return
        payload = json.dumps(
            [item.model_dump(mode="json") for item in self._items],
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        record = self.state_store.compare_and_set(_STATE_KEY, expected_version=self._state_version, value=payload)
        self._state_version = record.version

    def restore(self) -> None:
        if self.state_store is None:
            return
        record = self.state_store.get(_STATE_KEY)
        if record is None:
            return
        self._items = [ShadowComparison.model_validate(item) for item in json.loads(record.value.decode("utf-8"))]
        self._state_version = record.version
