from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from ephi.domain.operations import (
    CapabilityCertification,
    CertificationState,
    FamilyQualificationManifest,
    QualificationPlane,
)


_ALLOWED_TRANSITIONS: dict[CertificationState, frozenset[CertificationState]] = {
    CertificationState.RESEARCH: frozenset({CertificationState.OFFLINE_QUALIFIED, CertificationState.DEPRECATED}),
    CertificationState.OFFLINE_QUALIFIED: frozenset({CertificationState.SHADOW, CertificationState.DEPRECATED}),
    CertificationState.SHADOW: frozenset({CertificationState.SHADOW_QUALIFIED, CertificationState.OFFLINE_QUALIFIED, CertificationState.DEPRECATED}),
    CertificationState.SHADOW_QUALIFIED: frozenset({CertificationState.ADVISORY_PILOT, CertificationState.SHADOW, CertificationState.DEPRECATED}),
    CertificationState.ADVISORY_PILOT: frozenset({CertificationState.PRODUCTION_ADVISORY, CertificationState.SHADOW_QUALIFIED, CertificationState.DEPRECATED}),
    CertificationState.PRODUCTION_ADVISORY: frozenset({CertificationState.ADVISORY_PILOT, CertificationState.DEPRECATED}),
    CertificationState.DEPRECATED: frozenset(),
}


@dataclass(frozen=True, slots=True)
class CertificationPolicy:
    required_planes_for_offline: frozenset[QualificationPlane]
    required_planes_for_shadow: frozenset[QualificationPlane]
    required_planes_for_shadow_qualified: frozenset[QualificationPlane]
    required_planes_for_advisory: frozenset[QualificationPlane]

    @classmethod
    def reference(cls) -> "CertificationPolicy":
        scientific = frozenset({
            QualificationPlane.DATA_REALITY,
            QualificationPlane.BEHAVIORAL_METROLOGY,
            QualificationPlane.RUNTIME_SCALE,
        })
        shadow_ready = scientific | frozenset({QualificationPlane.RELIABILITY_DR})
        return cls(
            required_planes_for_offline=scientific,
            required_planes_for_shadow=shadow_ready,
            required_planes_for_shadow_qualified=shadow_ready | frozenset({QualificationPlane.ENGINEER_SHADOW}),
            required_planes_for_advisory=shadow_ready | frozenset({QualificationPlane.ENGINEER_SHADOW}),
        )

    def required_planes(self, target: CertificationState, capability_id: str | None = None) -> frozenset[QualificationPlane]:
        if target == CertificationState.OFFLINE_QUALIFIED:
            required = self.required_planes_for_offline
        elif target == CertificationState.SHADOW:
            required = self.required_planes_for_shadow
        elif target == CertificationState.SHADOW_QUALIFIED:
            required = self.required_planes_for_shadow_qualified
        elif target in {CertificationState.ADVISORY_PILOT, CertificationState.PRODUCTION_ADVISORY}:
            required = self.required_planes_for_advisory
        else:
            required = frozenset()
        capability = (capability_id or "").lower()
        if "quality" in capability or "harm" in capability:
            required |= frozenset({QualificationPlane.QUALITY_HARMFULNESS})
        if "exposure" in capability or "priority" in capability:
            required |= frozenset({QualificationPlane.EXPOSURE_PRIORITY})
        if "history" in capability or "rca" in capability:
            required |= frozenset({QualificationPlane.HISTORY_RCA})
        if "value" in capability or "roi" in capability:
            required |= frozenset({QualificationPlane.VALUE_ROI})
        return required


class CertificationService:
    def __init__(self, policy: CertificationPolicy | None = None) -> None:
        self.policy = policy or CertificationPolicy.reference()

    def validate_transition(
        self,
        capability: CapabilityCertification,
        target: CertificationState,
    ) -> None:
        if target not in _ALLOWED_TRANSITIONS[capability.state]:
            raise ValueError(f"Illegal certification transition {capability.state} -> {target}")
        missing = self.policy.required_planes(target, capability.capability_id) - capability.passed_planes
        if missing:
            names = ", ".join(sorted(item.value for item in missing))
            raise ValueError(f"Missing qualification planes for {target}: {names}")

    def transition(
        self,
        capability: CapabilityCertification,
        target: CertificationState,
        *,
        qualified_at: datetime,
    ) -> CapabilityCertification:
        self.validate_transition(capability, target)
        return capability.model_copy(update={"state": target, "qualified_at": qualified_at})

    def validate_family_manifest(self, manifest: FamilyQualificationManifest) -> None:
        if manifest.state == CertificationState.DEPRECATED:
            return
        for capability in manifest.capabilities:
            if capability.state == CertificationState.DEPRECATED:
                continue
            required = self.policy.required_planes(capability.state, capability.capability_id)
            missing = required - capability.passed_planes
            if missing:
                names = ", ".join(sorted(item.value for item in missing))
                raise ValueError(
                    f"Capability {capability.capability_id} declares {capability.state} without required planes: {names}"
                )
            if capability.state not in {manifest.state, CertificationState.PRODUCTION_ADVISORY}:
                # A family may contain already-production capabilities while a new family release is piloting,
                # but a less-qualified capability cannot be hidden beneath a more-qualified family state.
                family_order = list(CertificationState)
                if family_order.index(capability.state) < family_order.index(manifest.state):
                    raise ValueError(
                        f"Capability {capability.capability_id} state {capability.state} is below family state {manifest.state}"
                    )
