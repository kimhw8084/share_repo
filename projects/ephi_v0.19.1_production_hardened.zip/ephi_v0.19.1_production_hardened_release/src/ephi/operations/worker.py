from __future__ import annotations

from collections.abc import Callable, Mapping

from ephi.runtime.idempotency import AppliedWorkLedger
from ephi.runtime.queue import DurableWorkQueue, WorkItem


class WorkerHost:
    def __init__(
        self,
        *,
        worker_id: str,
        queue: DurableWorkQueue,
        handlers: Mapping[str, Callable[[WorkItem], None]],
        lease_seconds: int = 300,
        applied_work: AppliedWorkLedger | None = None,
    ) -> None:
        self.worker_id = worker_id
        self.queue = queue
        self.handlers = dict(handlers)
        self.lease_seconds = lease_seconds
        self.applied_work = applied_work

    def run_once(self) -> WorkItem | None:
        item = self.queue.claim(
            worker_id=self.worker_id,
            accepted_job_types=set(self.handlers),
            lease_seconds=self.lease_seconds,
        )
        if item is None:
            return None
        handler = self.handlers[item.job_type]
        if self.applied_work is not None and self.applied_work.already_applied(item):
            return self.queue.complete(item.work_id, worker_id=self.worker_id)
        try:
            handler(item)
            if self.applied_work is not None:
                self.applied_work.record(item)
        except Exception as exc:
            self.queue.fail(item.work_id, worker_id=self.worker_id, error=f"{type(exc).__name__}: {exc}", retry=True)
            raise
        return self.queue.complete(item.work_id, worker_id=self.worker_id)
