from __future__ import annotations

import json
from datetime import datetime, timezone
from uuid import uuid4

from ephi.adapters.base.state_store import StateStore
from ephi.domain.operations import ControlKind, ControlScope, OperationalControl


_STATE_KEY = "operations:controls:v1"


class OperationalControlService:
    """Authoritative scoped controls. Controls suppress/disable paths; they do not delete analytics."""

    def __init__(self, state_store: StateStore | None = None) -> None:
        self.state_store = state_store
        self._history: list[OperationalControl] = []
        self._state_version: int | None = None
        if state_store is not None:
            self.restore()

    def activate(
        self,
        *,
        kind: ControlKind,
        scope: ControlScope,
        target: str,
        reason: str,
        actor: str,
        expires_at: datetime | None = None,
        activated_at: datetime | None = None,
    ) -> OperationalControl:
        if not reason.strip():
            raise ValueError("control reason is required")
        if not actor.strip():
            raise ValueError("control actor is required")
        when = activated_at or datetime.now(timezone.utc)
        if expires_at is not None and expires_at <= when:
            raise ValueError("expires_at must be after activated_at")
        control = OperationalControl(
            control_id=f"CTRL-{uuid4().hex[:12]}",
            kind=kind,
            scope=scope,
            target=target,
            reason=reason,
            actor=actor,
            activated_at=when,
            expires_at=expires_at,
        )
        self._history.append(control)
        self.checkpoint()
        return control

    def deactivate(
        self,
        control_id: str,
        *,
        actor: str,
        at: datetime | None = None,
    ) -> OperationalControl:
        when = at or datetime.now(timezone.utc)
        for idx, item in enumerate(self._history):
            if item.control_id != control_id:
                continue
            if not item.active:
                raise ValueError(f"control {control_id} is already inactive")
            updated = item.model_copy(update={"deactivated_at": when, "deactivated_by": actor})
            self._history[idx] = updated
            self.checkpoint()
            return updated
        raise KeyError(control_id)

    def history(self) -> tuple[OperationalControl, ...]:
        return tuple(self._history)

    def active_controls(self, *, as_of: datetime | None = None) -> tuple[OperationalControl, ...]:
        now = as_of or datetime.now(timezone.utc)
        return tuple(
            item
            for item in self._history
            if item.active and (item.expires_at is None or item.expires_at > now)
        )

    def blocked(self, kind: ControlKind, *, family: str | None = None, component: str | None = None, as_of: datetime | None = None) -> bool:
        for item in self.active_controls(as_of=as_of):
            if item.kind != kind:
                continue
            if item.scope == ControlScope.GLOBAL:
                return True
            if item.scope == ControlScope.FAMILY and family is not None and item.target == family:
                return True
            if item.scope == ControlScope.COMPONENT and component is not None and item.target == component:
                return True
        return False

    def checkpoint(self) -> None:
        if self.state_store is None:
            return
        payload = json.dumps(
            [item.model_dump(mode="json") for item in self._history],
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        record = self.state_store.compare_and_set(
            _STATE_KEY,
            expected_version=self._state_version,
            value=payload,
        )
        self._state_version = record.version

    def restore(self) -> None:
        if self.state_store is None:
            return
        record = self.state_store.get(_STATE_KEY)
        if record is None:
            self._history = []
            self._state_version = None
            return
        raw = json.loads(record.value.decode("utf-8"))
        self._history = [OperationalControl.model_validate(item) for item in raw]
        self._state_version = record.version
