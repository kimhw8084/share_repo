from __future__ import annotations

from datetime import datetime

from ephi.domain.operations import ControlKind
from ephi.operations.controls import OperationalControlService


class NotificationDeliveryGate:
    """Delivery gate only; generating/storing analytical episodes continues while blocked."""

    def __init__(self, controls: OperationalControlService) -> None:
        self.controls = controls

    def allowed(
        self,
        *,
        family: str | None = None,
        component: str | None = None,
        as_of: datetime | None = None,
    ) -> bool:
        return not self.controls.blocked(
            ControlKind.NOTIFICATIONS,
            family=family,
            component=component,
            as_of=as_of,
        )
