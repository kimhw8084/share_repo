from __future__ import annotations

import json

from ephi.adapters.base.state_store import StateStore
from ephi.domain.operations import FamilyQualificationManifest
from ephi.operations.certification import CertificationService


_STATE_KEY = "operations:family-qualification:v1"


class FamilyQualificationRegistry:
    """Authoritative immutable family certification history."""

    def __init__(self, state_store: StateStore | None = None, *, certification: CertificationService | None = None) -> None:
        self.state_store = state_store
        self.certification = certification or CertificationService()
        self._history: list[FamilyQualificationManifest] = []
        self._state_version: int | None = None
        if state_store is not None:
            self.restore()

    def register(self, manifest: FamilyQualificationManifest) -> FamilyQualificationManifest:
        self.certification.validate_family_manifest(manifest)
        previous = self.latest(manifest.family_id)
        if previous is not None and previous.state != manifest.state:
            # Validate the family state transition using a representative capability shell.
            from ephi.domain.operations import CapabilityCertification

            shell = CapabilityCertification(
                capability_id="family-release",
                state=previous.state,
                gate_results=tuple(
                    gate
                    for capability in manifest.capabilities
                    for gate in capability.gate_results
                ),
            )
            self.certification.validate_transition(shell, manifest.state)
        if any(
            item.family_id == manifest.family_id
            and item.release_id == manifest.release_id
            and item.created_at == manifest.created_at
            for item in self._history
        ):
            raise ValueError("family qualification manifest already registered")
        self._history.append(manifest)
        self.checkpoint()
        return manifest

    def latest(self, family_id: str) -> FamilyQualificationManifest | None:
        matches = [item for item in self._history if item.family_id == family_id]
        if not matches:
            return None
        return max(matches, key=lambda item: item.created_at)

    def history(self, family_id: str | None = None) -> tuple[FamilyQualificationManifest, ...]:
        items = self._history if family_id is None else [item for item in self._history if item.family_id == family_id]
        return tuple(sorted(items, key=lambda item: (item.family_id, item.created_at, item.release_id)))

    def checkpoint(self) -> None:
        if self.state_store is None:
            return
        payload = json.dumps(
            [item.model_dump(mode="json") for item in self.history()],
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        record = self.state_store.compare_and_set(_STATE_KEY, expected_version=self._state_version, value=payload)
        self._state_version = record.version

    def restore(self) -> None:
        if self.state_store is None:
            return
        record = self.state_store.get(_STATE_KEY)
        if record is None:
            self._history = []
            self._state_version = None
            return
        self._history = [
            FamilyQualificationManifest.model_validate(item)
            for item in json.loads(record.value.decode("utf-8"))
        ]
        self._state_version = record.version
