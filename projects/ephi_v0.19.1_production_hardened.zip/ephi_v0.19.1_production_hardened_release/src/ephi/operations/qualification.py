from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory

from pydantic import BaseModel, ConfigDict

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.config import EphiConfig
from ephi.domain.operations import (
    BackfillPriority,
    BackfillStatus,
    BootstrapPhase,
    CapabilityCertification,
    CertificationState,
    ControlKind,
    ControlScope,
    GateResult,
    QualificationPlane,
    ReleaseCompatibilityState,
    EngineerShadowReview,
    ShadowReviewDisposition,
)
from ephi.operations.backfill import BackfillController, build_backfill_chunks
from ephi.operations.certification import CertificationService
from ephi.operations.controls import OperationalControlService
from ephi.operations.deployment import load_deployment_plan, render_kubernetes_documents
from ephi.operations.release import assess_release_compatibility
from ephi.operations.shadow import ShadowRunner
from ephi.operations.telemetry import evaluate_freshness
from ephi.operations.shadow_review import ShadowGatePolicy, apply_shadow_gate
from ephi.registry.releases import build_release_manifest


class OperationsQualificationReport(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    passed: bool
    certification_state_machine: bool
    capability_specific_gate: bool
    reliability_required_for_shadow: bool
    champion_isolation: bool
    challenger_failure_isolated: bool
    notification_control_persisted: bool
    notification_control_does_not_block_capability: bool
    backfill_live_priority: bool
    backfill_checkpoint_restore: bool
    stale_slo_blocks: bool
    deployment_profiles_valid: bool
    rollback_compatible: bool
    destructive_rollback_blocked: bool
    queue_lease_recovery: bool
    queue_idempotent_enqueue: bool
    engineer_shadow_gate: bool
    freshness_tracker_persisted: bool
    family_registry_history: bool
    shadow_comparison_persisted: bool
    self_declared_manifest_blocked: bool


def run_operations_qualification(deployment_path: str | Path = "configs/deployment/shadow-reference.yaml") -> OperationsQualificationReport:
    now = datetime(2026, 8, 19, 12, 0, tzinfo=timezone.utc)
    base_gates = (
        GateResult(plane=QualificationPlane.DATA_REALITY, passed=True),
        GateResult(plane=QualificationPlane.BEHAVIORAL_METROLOGY, passed=True),
        GateResult(plane=QualificationPlane.RUNTIME_SCALE, passed=True),
        GateResult(plane=QualificationPlane.RELIABILITY_DR, passed=True),
    )
    service = CertificationService()
    research = CapabilityCertification(capability_id="behavioral-health", state=CertificationState.RESEARCH, gate_results=base_gates)
    offline = service.transition(research, CertificationState.OFFLINE_QUALIFIED, qualified_at=now)
    service.transition(offline, CertificationState.SHADOW, qualified_at=now)
    certification_state_machine = True
    without_reliability = CapabilityCertification(
        capability_id="behavioral-health",
        state=CertificationState.OFFLINE_QUALIFIED,
        gate_results=tuple(item for item in base_gates if item.plane != QualificationPlane.RELIABILITY_DR),
    )
    try:
        service.transition(without_reliability, CertificationState.SHADOW, qualified_at=now)
        reliability_required_for_shadow = False
    except ValueError as exc:
        reliability_required_for_shadow = "RELIABILITY_DR" in str(exc)
    quality = CapabilityCertification(capability_id="quality-harmfulness", state=CertificationState.RESEARCH, gate_results=base_gates)
    try:
        service.transition(quality, CertificationState.OFFLINE_QUALIFIED, qualified_at=now)
        capability_gate = False
    except ValueError:
        capability_gate = True

    runner = ShadowRunner(
        "champion",
        lambda x: {"actionable": x > 0, "value": x},
        {
            "challenger": lambda x: {"actionable": x >= 0, "value": x + 1},
            "broken": lambda x: 1 / 0,
        },
        actionable=lambda out: bool(out["actionable"]),
    )
    comparison, production = runner.compare(subject_id="ASSET-A", as_of=now, value=1)
    champion_isolation = production == {"actionable": True, "value": 1} and not comparison.production_output_changed
    broken = next(item for item in comparison.challengers if item.candidate_id == "broken")
    challenger_failure_isolated = broken.error is not None and comparison.champion.error is None

    reviews = tuple(
        EngineerShadowReview(
            review_id=f"REV-{idx}",
            episode_id=f"EP-{idx}",
            reviewer="qualified-engineer",
            disposition=ShadowReviewDisposition.WANT_EVENT if idx < 18 else ShadowReviewDisposition.PARTIALLY_USEFUL,
            comparison_valid=True,
            hypothesis_reasonable=True,
            verification_useful=True,
            reviewed_at=now,
        )
        for idx in range(20)
    )
    engineer_shadow_gate = apply_shadow_gate(reviews, ShadowGatePolicy(min_reviews=20)).passed

    # A supplied manifest cannot self-declare qualification without the required gates.
    from ephi.domain.operations import FamilyQualificationManifest
    try:
        service.validate_family_manifest(
            FamilyQualificationManifest(
                family_id="BAD", release_id="R-BAD", state=CertificationState.OFFLINE_QUALIFIED,
                capabilities=(CapabilityCertification(capability_id="behavioral-health", state=CertificationState.OFFLINE_QUALIFIED),),
                created_at=now,
            )
        )
        self_declared_manifest_blocked = False
    except ValueError:
        self_declared_manifest_blocked = True

    with TemporaryDirectory() as temp:
        store = SqliteStateStore(Path(temp) / "state.sqlite3")
        controls = OperationalControlService(store)
        control = controls.activate(
            kind=ControlKind.NOTIFICATIONS,
            scope=ControlScope.FAMILY,
            target="METROLOGY",
            reason="shadow alert storm drill",
            actor="qualification",
            activated_at=now,
        )
        restored_controls = OperationalControlService(store)
        notification_control_persisted = any(item.control_id == control.control_id for item in restored_controls.active_controls(as_of=now))
        notification_control_does_not_block_capability = not restored_controls.blocked(
            ControlKind.CAPABILITY, family="METROLOGY", as_of=now
        )

        backfill = BackfillController(store)
        historical = build_backfill_chunks(
            phase=BootstrapPhase.CANONICAL_HISTORY,
            scope="METROLOGY",
            start_time=now - timedelta(days=10),
            end_time=now - timedelta(days=5),
            chunk_days=2,
        )
        live = build_backfill_chunks(
            phase=BootstrapPhase.CORE_FEATURES,
            scope="METROLOGY",
            start_time=now - timedelta(hours=1),
            end_time=now,
            chunk_days=1,
            priority=BackfillPriority.LIVE,
        )
        backfill.register(historical + live, at=now)
        first = backfill.next_chunk()
        backfill_live_priority = first is not None and first.priority == BackfillPriority.LIVE
        assert first is not None
        backfill.update(first.chunk_id, BackfillStatus.RUNNING, at=now)
        backfill.update(first.chunk_id, BackfillStatus.SUCCEEDED, at=now)
        restored_backfill = BackfillController(store)
        backfill_checkpoint_restore = any(
            item.chunk.chunk_id == first.chunk_id and item.status == BackfillStatus.SUCCEEDED
            for item in restored_backfill.progress()
        )

        from ephi.domain.operations import FreshnessChannel, FamilyQualificationManifest
        from ephi.operations.freshness import FreshnessTracker
        from ephi.operations.family_registry import FamilyQualificationRegistry
        from ephi.operations.shadow_store import ShadowComparisonStore

        tracker = FreshnessTracker(store)
        tracker.mark(FreshnessChannel.SOURCE, refreshed_at=now, source_as_of=now - timedelta(seconds=10), version="src-v1")
        freshness_tracker_persisted = FreshnessTracker(store).latest(FreshnessChannel.SOURCE) is not None

        registry = FamilyQualificationRegistry(store)
        offline_manifest = FamilyQualificationManifest(
            family_id="METROLOGY", release_id="R1", state=CertificationState.OFFLINE_QUALIFIED,
            capabilities=(CapabilityCertification(capability_id="behavioral-health", state=CertificationState.OFFLINE_QUALIFIED, gate_results=base_gates),),
            created_at=now,
        )
        registry.register(offline_manifest)
        shadow_manifest = FamilyQualificationManifest(
            family_id="METROLOGY", release_id="R2", state=CertificationState.SHADOW,
            capabilities=(CapabilityCertification(capability_id="behavioral-health", state=CertificationState.SHADOW, gate_results=base_gates),),
            created_at=now + timedelta(seconds=1),
        )
        registry.register(shadow_manifest)
        family_registry_history = [item.release_id for item in FamilyQualificationRegistry(store).history("METROLOGY")] == ["R1", "R2"]

        shadow_store = ShadowComparisonStore(store)
        shadow_store.append(comparison)
        shadow_comparison_persisted = len(ShadowComparisonStore(store).items()) == 1

    slo = evaluate_freshness(
        as_of=now,
        observations={"source": 100.0, "assessment": 4000.0, "wip": None},
        targets={"source": (900.0, 3600.0), "assessment": (1500.0, 3600.0), "wip": (300.0, 900.0)},
    )
    stale_slo_blocks = slo.overall_state.value in {"STALE", "UNKNOWN"} and set(slo.blockers) == {"assessment", "wip"}

    plan = load_deployment_plan(deployment_path)
    docs = render_kubernetes_documents(plan)
    deployment_profiles_valid = any(doc.get("kind") == "Service" for doc in docs) and all(
        role.qualification == "PROVISIONAL" for role in plan.roles
    )

    with TemporaryDirectory() as temp:
        from ephi.runtime.queue import DurableWorkQueue

        queue_store = SqliteStateStore(Path(temp) / "queue.sqlite3")
        queue = DurableWorkQueue(queue_store)
        first_enqueue = queue.enqueue("INCREMENTAL_SCORE", work_id="W1", priority=10, created_at=now)
        second_enqueue = queue.enqueue("INCREMENTAL_SCORE", work_id="W1", priority=10, created_at=now)
        queue_idempotent_enqueue = first_enqueue == second_enqueue and len(queue.items()) == 1
        lease = queue.claim(worker_id="worker-a", lease_seconds=10, now=now)
        restored_queue = DurableWorkQueue(queue_store)
        reclaimed = restored_queue.claim(worker_id="worker-b", lease_seconds=10, now=now + timedelta(seconds=11))
        queue_lease_recovery = lease is not None and reclaimed is not None and reclaimed.work_id == "W1" and reclaimed.leased_by == "worker-b"

    with TemporaryDirectory() as temp:
        root = Path(temp)
        (root / "src" / "ephi").mkdir(parents=True)
        (root / "configs").mkdir()
        (root / "src" / "ephi" / "x.py").write_text("x = 1\n", encoding="utf-8")
        source = build_release_manifest(root, EphiConfig(), created_at=now)
        target = build_release_manifest(root, EphiConfig(), created_at=now + timedelta(minutes=1))
        compatible = assess_release_compatibility(source, target)
        blocked = assess_release_compatibility(source, target, destructive_migration=True)
        rollback_compatible = compatible.state == ReleaseCompatibilityState.COMPATIBLE and compatible.rollback_allowed
        destructive_rollback_blocked = blocked.state == ReleaseCompatibilityState.INCOMPATIBLE and not blocked.rollback_allowed

    checks = {
        "certification_state_machine": certification_state_machine,
        "capability_specific_gate": capability_gate,
        "reliability_required_for_shadow": reliability_required_for_shadow,
        "champion_isolation": champion_isolation,
        "challenger_failure_isolated": challenger_failure_isolated,
        "notification_control_persisted": notification_control_persisted,
        "notification_control_does_not_block_capability": notification_control_does_not_block_capability,
        "backfill_live_priority": backfill_live_priority,
        "backfill_checkpoint_restore": backfill_checkpoint_restore,
        "stale_slo_blocks": stale_slo_blocks,
        "deployment_profiles_valid": deployment_profiles_valid,
        "rollback_compatible": rollback_compatible,
        "destructive_rollback_blocked": destructive_rollback_blocked,
        "queue_lease_recovery": queue_lease_recovery,
        "queue_idempotent_enqueue": queue_idempotent_enqueue,
        "engineer_shadow_gate": engineer_shadow_gate,
        "freshness_tracker_persisted": freshness_tracker_persisted,
        "family_registry_history": family_registry_history,
        "shadow_comparison_persisted": shadow_comparison_persisted,
        "self_declared_manifest_blocked": self_declared_manifest_blocked,
    }
    return OperationsQualificationReport(passed=all(checks.values()), **checks)
