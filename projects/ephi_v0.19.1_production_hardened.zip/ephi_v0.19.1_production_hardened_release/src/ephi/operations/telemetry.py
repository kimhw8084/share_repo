from __future__ import annotations

from datetime import datetime

from ephi.domain.operations import FreshnessObservation, FreshnessState, OperationalSLOReport


def _state(lag: float | None, target: float, hard: float) -> FreshnessState:
    if lag is None:
        return FreshnessState.UNKNOWN
    if lag <= target:
        return FreshnessState.CURRENT
    if lag <= hard:
        return FreshnessState.DEGRADED
    return FreshnessState.STALE


def evaluate_freshness(
    *,
    as_of: datetime,
    observations: dict[str, float | None],
    targets: dict[str, tuple[float, float]],
) -> OperationalSLOReport:
    result: list[FreshnessObservation] = []
    blockers: list[str] = []
    for metric, (target, hard) in targets.items():
        if hard < target:
            raise ValueError(f"hard limit must be >= target for {metric}")
        lag = observations.get(metric)
        state = _state(lag, target, hard)
        result.append(
            FreshnessObservation(
                metric=metric,
                observed_lag_seconds=lag,
                target_lag_seconds=target,
                hard_limit_seconds=hard,
                state=state,
                observed_at=as_of,
            )
        )
        if state in {FreshnessState.STALE, FreshnessState.UNKNOWN}:
            blockers.append(metric)

    states = {item.state for item in result}
    if FreshnessState.STALE in states:
        overall = FreshnessState.STALE
    elif FreshnessState.UNKNOWN in states:
        overall = FreshnessState.UNKNOWN
    elif FreshnessState.DEGRADED in states:
        overall = FreshnessState.DEGRADED
    else:
        overall = FreshnessState.CURRENT
    return OperationalSLOReport(
        as_of=as_of,
        observations=tuple(result),
        overall_state=overall,
        blockers=tuple(blockers),
    )
