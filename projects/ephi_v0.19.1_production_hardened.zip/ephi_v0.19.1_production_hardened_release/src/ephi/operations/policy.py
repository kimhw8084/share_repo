from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator


class OperationsPolicy(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    policy_version: str = "1"
    freshness_slo: dict[str, tuple[float, float]] = Field(default_factory=dict)
    notes: tuple[str, ...] = ()

    @field_validator("freshness_slo")
    @classmethod
    def validate_targets(cls, value: dict[str, tuple[float, float]]) -> dict[str, tuple[float, float]]:
        for metric, (target, hard) in value.items():
            if target <= 0 or hard <= 0 or hard < target:
                raise ValueError(f"invalid freshness SLO for {metric}")
        return value


def load_operations_policy(path: str | Path) -> OperationsPolicy:
    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    payload = {
        "policy_version": str(raw.get("policy_version", "1")),
        "freshness_slo": raw.get("freshness_slo", {}),
        "notes": tuple(raw.get("notes", ())),
    }
    return OperationsPolicy.model_validate(payload)
