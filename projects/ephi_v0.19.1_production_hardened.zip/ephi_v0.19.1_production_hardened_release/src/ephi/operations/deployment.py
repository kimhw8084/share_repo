from __future__ import annotations

from pathlib import Path

import yaml

from ephi.domain.operations import DeploymentPlan, RuntimeRole, RuntimeRoleProfile


def load_deployment_plan(path: str | Path) -> DeploymentPlan:
    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    return DeploymentPlan.model_validate(raw)


def render_kubernetes_documents(plan: DeploymentPlan) -> tuple[dict, ...]:
    documents: list[dict] = []
    for profile in plan.roles:
        if profile.replicas == 0:
            continue
        name = f"{plan.name}-{profile.role.value.lower().replace('_', '-')}"
        container = {
            "name": "ephi",
            "image": plan.image,
            "command": list(profile.command),
            "resources": {
                "requests": {"cpu": profile.cpu_request, "memory": profile.memory_request},
                "limits": {
                    "cpu": profile.cpu_limit or profile.cpu_request,
                    "memory": profile.memory_limit or profile.memory_request,
                },
            },
            "env": [
                {"name": "EPHI_RUNTIME_ROLE", "value": profile.role.value},
                {"name": "EPHI_DEPLOYMENT_QUALIFICATION", "value": profile.qualification},
            ],
        }
        if profile.gpu_count:
            container["resources"]["limits"]["nvidia.com/gpu"] = profile.gpu_count
        pod_spec = {"containers": [container]}
        if plan.service_account_name:
            pod_spec["serviceAccountName"] = plan.service_account_name
        documents.append(
            {
                "apiVersion": "apps/v1",
                "kind": "Deployment",
                "metadata": {"name": name, "namespace": plan.namespace},
                "spec": {
                    "replicas": profile.replicas,
                    "selector": {"matchLabels": {"app": name}},
                    "template": {
                        "metadata": {"labels": {"app": name, "ephi-role": profile.role.value}},
                        "spec": pod_spec,
                    },
                },
            }
        )
        if profile.role == RuntimeRole.API:
            documents.append(
                {
                    "apiVersion": "v1",
                    "kind": "Service",
                    "metadata": {"name": name, "namespace": plan.namespace},
                    "spec": {"selector": {"app": name}, "ports": [{"port": 80, "targetPort": 8000}]},
                }
            )
    return tuple(documents)


def render_kubernetes_yaml(plan: DeploymentPlan) -> str:
    return "---\n".join(yaml.safe_dump(doc, sort_keys=False) for doc in render_kubernetes_documents(plan))
