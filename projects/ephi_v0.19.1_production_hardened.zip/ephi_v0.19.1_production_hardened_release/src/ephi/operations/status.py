from __future__ import annotations

from datetime import datetime, timezone

from pydantic import BaseModel, ConfigDict

from ephi.domain.operations import FamilyQualificationManifest, OperationalControl, OperationalSLOReport


class OperationalStatus(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    as_of: datetime
    family_manifest: FamilyQualificationManifest | None = None
    active_controls: tuple[OperationalControl, ...] = ()
    slo_report: OperationalSLOReport | None = None
    notification_delivery_enabled: bool = True


class OperationsStatusService:
    def __init__(self, *, family_manifest: FamilyQualificationManifest | None = None, controls=None, slo_report: OperationalSLOReport | None = None) -> None:
        self.family_manifest = family_manifest
        self.controls = controls
        self.slo_report = slo_report

    def status(self, *, as_of: datetime | None = None) -> OperationalStatus:
        now = as_of or datetime.now(timezone.utc)
        active = self.controls.active_controls(as_of=now) if self.controls is not None else ()
        notification_enabled = not any(item.kind.value == "NOTIFICATIONS" for item in active)
        return OperationalStatus(
            as_of=now,
            family_manifest=self.family_manifest,
            active_controls=tuple(active),
            slo_report=self.slo_report,
            notification_delivery_enabled=notification_enabled,
        )
