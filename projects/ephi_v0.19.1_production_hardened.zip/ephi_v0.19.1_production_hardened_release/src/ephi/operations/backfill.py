from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from ephi.adapters.base.state_store import StateStore
from ephi.domain.operations import (
    BackfillChunk,
    BackfillPriority,
    BackfillProgress,
    BackfillStatus,
    BootstrapPhase,
)


_STATE_KEY = "operations:backfill:v1"


_PHASE_ORDER = (
    BootstrapPhase.CANONICAL_HISTORY,
    BootstrapPhase.MATERIAL_EXPOSURE,
    BootstrapPhase.CORE_FEATURES,
    BootstrapPhase.MAINTENANCE_STATE,
    BootstrapPhase.REFERENCES,
    BootstrapPhase.PEERS,
    BootstrapPhase.HISTORICAL_REPLAY,
    BootstrapPhase.QUALITY,
    BootstrapPhase.HISTORY_INDEX,
)


def build_backfill_chunks(
    *,
    phase: BootstrapPhase,
    scope: str,
    start_time: datetime,
    end_time: datetime,
    chunk_days: int,
    priority: BackfillPriority = BackfillPriority.HISTORICAL_BACKFILL,
) -> tuple[BackfillChunk, ...]:
    if chunk_days < 1:
        raise ValueError("chunk_days must be >= 1")
    chunks: list[BackfillChunk] = []
    cursor = start_time
    index = 0
    while cursor < end_time:
        stop = min(cursor + timedelta(days=chunk_days), end_time)
        chunks.append(
            BackfillChunk(
                chunk_id=f"{phase.value}:{scope}:{index:05d}",
                phase=phase,
                scope=scope,
                start_time=cursor,
                end_time=stop,
                priority=priority,
            )
        )
        cursor = stop
        index += 1
    return tuple(chunks)


class BackfillController:
    def __init__(self, state_store: StateStore | None = None) -> None:
        self.state_store = state_store
        self._progress: dict[str, BackfillProgress] = {}
        self._state_version: int | None = None
        if state_store is not None:
            self.restore()

    @staticmethod
    def phase_order() -> tuple[BootstrapPhase, ...]:
        return _PHASE_ORDER

    def register(self, chunks: tuple[BackfillChunk, ...], *, at: datetime | None = None) -> None:
        now = at or datetime.now(timezone.utc)
        for chunk in chunks:
            self._progress.setdefault(
                chunk.chunk_id,
                BackfillProgress(chunk=chunk, status=BackfillStatus.PENDING, updated_at=now),
            )
        self.checkpoint()

    def next_chunk(self) -> BackfillChunk | None:
        candidates = [p for p in self._progress.values() if p.status == BackfillStatus.PENDING]
        if not candidates:
            return None
        priority_order = {
            BackfillPriority.LIVE: 0,
            BackfillPriority.RECENT_CORRECTION: 1,
            BackfillPriority.HISTORICAL_BACKFILL: 2,
        }
        phase_index = {phase: idx for idx, phase in enumerate(_PHASE_ORDER)}
        candidates.sort(
            key=lambda p: (
                priority_order[p.chunk.priority],
                phase_index[p.chunk.phase],
                p.chunk.start_time,
                p.chunk.chunk_id,
            )
        )
        return candidates[0].chunk

    def update(self, chunk_id: str, status: BackfillStatus, *, error: str | None = None, at: datetime | None = None) -> BackfillProgress:
        current = self._progress[chunk_id]
        attempts = current.attempts + (1 if status == BackfillStatus.RUNNING else 0)
        updated = current.model_copy(
            update={
                "status": status,
                "attempts": attempts,
                "updated_at": at or datetime.now(timezone.utc),
                "error": error,
            }
        )
        self._progress[chunk_id] = updated
        self.checkpoint()
        return updated

    def progress(self) -> tuple[BackfillProgress, ...]:
        return tuple(sorted(self._progress.values(), key=lambda item: item.chunk.chunk_id))

    def checkpoint(self) -> None:
        if self.state_store is None:
            return
        payload = json.dumps(
            [item.model_dump(mode="json") for item in self.progress()],
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        record = self.state_store.compare_and_set(_STATE_KEY, expected_version=self._state_version, value=payload)
        self._state_version = record.version

    def restore(self) -> None:
        if self.state_store is None:
            return
        record = self.state_store.get(_STATE_KEY)
        if record is None:
            return
        items = [BackfillProgress.model_validate(item) for item in json.loads(record.value.decode("utf-8"))]
        self._progress = {item.chunk.chunk_id: item for item in items}
        self._state_version = record.version
