from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from itertools import groupby
from typing import Callable, Generic, Iterable, Protocol, TypeVar

from ephi.domain.evidence import Hypothesis
from ephi.domain.health import HealthAssessment, HealthSeverity

ObsT = TypeVar("ObsT")
PipelineT = TypeVar("PipelineT")


class _TimedObservation(Protocol):
    event_time: datetime
    available_at: datetime


@dataclass(frozen=True, slots=True)
class ReplayAssessmentPoint:
    assessment_id: str
    execution_id: str
    asset_id: str
    event_time: datetime
    known_at: datetime
    severity: HealthSeverity
    leading_hypothesis: Hypothesis
    confidence: float


@dataclass(frozen=True, slots=True)
class ReplayEpisodePoint:
    episode_key: str
    asset_id: str | None
    event_time: datetime
    known_at: datetime
    hypothesis: Hypothesis
    fleet: bool


@dataclass(frozen=True, slots=True)
class StrictReplayResult:
    assessment_points: tuple[ReplayAssessmentPoint, ...]
    local_episode_points: tuple[ReplayEpisodePoint, ...]
    fleet_episode_points: tuple[ReplayEpisodePoint, ...]
    processed_observations: int
    knowledge_steps: int
    rebuild_count: int
    first_actionable_known_at: datetime | None
    first_actionable_event_time: datetime | None
    first_fleet_known_at: datetime | None


class _PipelineResult(Protocol):
    assessments: tuple[HealthAssessment, ...]


def _episode_collections(pipeline) -> tuple[tuple[object, ...], tuple[object, ...]]:
    local = tuple(pipeline.episodes.active()) + tuple(pipeline.episodes.history())
    fleet_service = getattr(pipeline, "fleet_episodes", None)
    fleet = ()
    if fleet_service is not None:
        fleet = tuple(fleet_service.active()) + tuple(fleet_service.history())
    return local, fleet


def strict_knowledge_replay(
    observations: Iterable[ObsT],
    *,
    pipeline_factory: Callable[[], PipelineT],
    process: Callable[[PipelineT, list[ObsT]], _PipelineResult] | None = None,
) -> StrictReplayResult:
    """Replay only facts visible at each historical knowledge time.

    Normal arrivals update incrementally. If a fact arrives for an event time that
    has already been processed, the analytical pipeline is rebuilt from the facts
    visible *as of that moment*. This is intentionally correctness-first; production
    late-data handling uses checkpoints/dirty ranges, while qualification must prove
    equivalent knowledge-time semantics without pretending late data was always known.
    """

    ordered = sorted(
        observations,
        key=lambda item: (item.available_at, item.event_time),
    )
    if not ordered:
        return StrictReplayResult((), (), (), 0, 0, 0, None, None, None)

    runner = process or (lambda pipeline, batch: pipeline.process(batch))
    pipeline = pipeline_factory()
    known: list[ObsT] = []
    max_processed_event_time: datetime | None = None
    rebuild_count = 0
    knowledge_steps = 0

    assessment_transitions: list[ReplayAssessmentPoint] = []
    seen_assessment_states: set[tuple[str, int, Hypothesis]] = set()
    seen_local_keys: set[str] = set()
    seen_fleet_keys: set[str] = set()
    local_points: list[ReplayEpisodePoint] = []
    fleet_points: list[ReplayEpisodePoint] = []

    first_actionable_known_at: datetime | None = None
    first_actionable_event_time: datetime | None = None
    first_fleet_known_at: datetime | None = None

    for available_at, group_iter in groupby(ordered, key=lambda item: item.available_at):
        knowledge_steps += 1
        batch = list(group_iter)
        if any(item.available_at > available_at for item in batch):  # defensive canary
            raise AssertionError("replay attempted to expose future data")
        known.extend(batch)

        late_or_same_time = (
            max_processed_event_time is not None
            and min(item.event_time for item in batch) <= max_processed_event_time
        )
        if late_or_same_time:
            pipeline = pipeline_factory()
            visible = sorted(known, key=lambda item: (item.event_time, item.available_at))
            result = runner(pipeline, visible)
            rebuild_count += 1
        else:
            result = runner(pipeline, batch)

        max_processed_event_time = max(
            max_processed_event_time or batch[0].event_time,
            max(item.event_time for item in batch),
        )

        for assessment in result.assessments:
            state_key = (
                assessment.assessment_id,
                int(assessment.severity),
                assessment.leading_hypothesis,
            )
            if state_key in seen_assessment_states:
                continue
            seen_assessment_states.add(state_key)
            point = ReplayAssessmentPoint(
                assessment_id=assessment.assessment_id,
                execution_id=assessment.execution_id,
                asset_id=assessment.asset_id,
                event_time=assessment.event_time,
                known_at=available_at,
                severity=assessment.severity,
                leading_hypothesis=assessment.leading_hypothesis,
                confidence=assessment.confidence,
            )
            assessment_transitions.append(point)
            if assessment.severity >= HealthSeverity.INVESTIGATE:
                if first_actionable_known_at is None or available_at < first_actionable_known_at:
                    first_actionable_known_at = available_at
                    first_actionable_event_time = assessment.event_time

        local, fleet = _episode_collections(pipeline)
        for episode in local:
            context_key = episode.context.stable_key()
            semantic_key = f"LOCAL:{episode.asset_id}:{context_key}"
            if semantic_key in seen_local_keys:
                continue
            seen_local_keys.add(semantic_key)
            local_points.append(
                ReplayEpisodePoint(
                    episode_key=semantic_key,
                    asset_id=episode.asset_id,
                    event_time=episode.opened_at,
                    known_at=available_at,
                    hypothesis=episode.leading_hypothesis,
                    fleet=False,
                )
            )

        for episode in fleet:
            semantic_key = f"FLEET:{episode.context.stable_key()}"
            if semantic_key in seen_fleet_keys:
                continue
            seen_fleet_keys.add(semantic_key)
            fleet_points.append(
                ReplayEpisodePoint(
                    episode_key=semantic_key,
                    asset_id=None,
                    event_time=episode.opened_at,
                    known_at=available_at,
                    hypothesis=episode.leading_hypothesis,
                    fleet=True,
                )
            )
            if first_fleet_known_at is None or available_at < first_fleet_known_at:
                first_fleet_known_at = available_at

    return StrictReplayResult(
        assessment_points=tuple(assessment_transitions),
        local_episode_points=tuple(local_points),
        fleet_episode_points=tuple(fleet_points),
        processed_observations=len(ordered),
        knowledge_steps=knowledge_steps,
        rebuild_count=rebuild_count,
        first_actionable_known_at=first_actionable_known_at,
        first_actionable_event_time=first_actionable_event_time,
        first_fleet_known_at=first_fleet_known_at,
    )
