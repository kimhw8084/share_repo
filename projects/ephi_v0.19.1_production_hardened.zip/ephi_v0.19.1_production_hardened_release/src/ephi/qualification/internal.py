from __future__ import annotations

from typing import Any, Protocol, Sequence

from ephi.domain.benchmark import BenchmarkCase


class HistoricalBenchmarkLoader(Protocol):
    """Company-side bridge from a curated BenchmarkCase to canonical observations.

    The returned objects must be the same canonical observation types used by the
    production pipelines (e.g. ScalarFeatureObservation or MetrologyObservation),
    including event_time and available_at. The qualification framework intentionally
    does not know company table names or issue proprietary queries itself.
    """

    def load(self, case: BenchmarkCase) -> Sequence[Any]:
        ...
