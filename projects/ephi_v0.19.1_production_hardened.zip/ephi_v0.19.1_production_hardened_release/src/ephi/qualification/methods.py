from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from ephi.detectors.behavioral import BehavioralDetectorConfig, BehavioralDetectorEngine
from ephi.detectors.sequential import SequentialConfig
from ephi.health.engine import BehavioralHealthPipeline
from ephi.metrology.engine import MetrologyHealthPipeline
from ephi.populations.references import ReferenceConfig


@dataclass(frozen=True, slots=True)
class QualificationMethod:
    method_id: str
    description: str
    behavioral_factory: Callable[[], BehavioralHealthPipeline]
    metrology_factory: Callable[[], MetrologyHealthPipeline]


def baseline_method() -> QualificationMethod:
    return QualificationMethod(
        method_id="baseline-v0.5",
        description="Qualified production semantic baseline",
        behavioral_factory=BehavioralHealthPipeline,
        metrology_factory=MetrologyHealthPipeline,
    )


def strict_reference_challenger() -> QualificationMethod:
    def behavioral() -> BehavioralHealthPipeline:
        config = BehavioralDetectorConfig(
            reference=ReferenceConfig(
                admission_abs_z=2.5,
                anchor_admission_abs_z=2.5,
            )
        )
        return BehavioralHealthPipeline(detector=BehavioralDetectorEngine(config=config))

    return QualificationMethod(
        method_id="strict-reference-challenger",
        description="More conservative adaptive-reference admission; research challenger",
        behavioral_factory=behavioral,
        metrology_factory=MetrologyHealthPipeline,
    )


def sensitive_sequential_challenger() -> QualificationMethod:
    def behavioral() -> BehavioralHealthPipeline:
        config = BehavioralDetectorConfig(
            sequential=SequentialConfig(
                lambda_fast=0.40,
                lambda_slow=0.12,
                cusum_k=0.40,
                persistence_z=2.1,
            )
        )
        return BehavioralHealthPipeline(detector=BehavioralDetectorEngine(config=config))

    return QualificationMethod(
        method_id="sensitive-sequential-challenger",
        description="Earlier sequential sensitivity; expected to trade false burden for lead time",
        behavioral_factory=behavioral,
        metrology_factory=MetrologyHealthPipeline,
    )


def builtin_methods() -> dict[str, QualificationMethod]:
    methods = (
        baseline_method(),
        strict_reference_challenger(),
        sensitive_sequential_challenger(),
    )
    return {method.method_id: method for method in methods}
