from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from ephi.domain.benchmark import (
    BenchmarkCase,
    BenchmarkCaseType,
    BenchmarkCorpus,
    BenchmarkFamily,
    BenchmarkLabelConfidence,
    BenchmarkSourceKind,
)
from ephi.domain.evidence import Hypothesis


def _scalar_case(
    *,
    case_id: str,
    scenario: str,
    seed: int,
    case_type: BenchmarkCaseType,
    expected_hypothesis: Hypothesis | None,
    expected_local: bool = False,
    expected_fleet: bool = False,
    expected_assets: tuple[str, ...] = (),
) -> BenchmarkCase:
    executions = 1000
    assets = 4
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    interval = timedelta(minutes=5)
    onset = start + interval * int(executions * 0.60) if scenario != "healthy" else None
    # Synthetic external detection is deliberately later than onset. It validates the
    # lead-time plumbing only; it is not a manufacturing ROI claim.
    external = None
    return BenchmarkCase(
        case_id=case_id,
        family=BenchmarkFamily.BEHAVIORAL,
        case_type=case_type,
        source_kind=BenchmarkSourceKind.SYNTHETIC_SCALAR,
        scenario=scenario,
        generator_config={
            "n_assets": assets,
            "executions_per_asset": executions,
            "seed": seed,
            "scenario": scenario,
            "start_time": start.isoformat(),
            "interval_minutes": 5,
        },
        expected_hypothesis=expected_hypothesis,
        expected_local_actionable=expected_local,
        expected_fleet_actionable=expected_fleet,
        expected_asset_ids=expected_assets,
        onset_event_time=onset,
        onset_low=onset,
        onset_high=onset,
        external_detection_time=external,
        scope_start=start,
        scope_end=start + interval * (executions - 1),
        asset_count=assets,
        tags=("synthetic", "fixed-golden"),
    )


def _metrology_case(
    *,
    case_id: str,
    scenario: str,
    seed: int,
    case_type: BenchmarkCaseType,
    expected_hypothesis: Hypothesis | None,
    expected_local: bool = False,
    expected_fleet: bool = False,
    expected_assets: tuple[str, ...] = (),
) -> BenchmarkCase:
    measurements = 900
    heads = 3
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    interval = timedelta(minutes=4)
    onset = start + interval * int(measurements * 0.60) if scenario != "healthy" else None
    external = None
    return BenchmarkCase(
        case_id=case_id,
        family=BenchmarkFamily.METROLOGY,
        case_type=case_type,
        source_kind=BenchmarkSourceKind.SYNTHETIC_METROLOGY,
        scenario=scenario,
        generator_config={
            "n_heads": heads,
            "measurements_per_head": measurements,
            "seed": seed,
            "scenario": scenario,
            "start_time": start.isoformat(),
            "interval_minutes": 4,
            "sites_per_measurement": 13,
            "reference_every": 5,
            "remeasure_every": 20,
        },
        expected_hypothesis=expected_hypothesis,
        expected_local_actionable=expected_local,
        expected_fleet_actionable=expected_fleet,
        expected_asset_ids=expected_assets,
        onset_event_time=onset,
        onset_low=onset,
        onset_high=onset,
        external_detection_time=external,
        scope_start=start,
        scope_end=start + interval * (measurements - 1) + timedelta(minutes=1),
        asset_count=heads,
        tags=("synthetic", "fixed-golden", "metrology"),
    )


def build_synthetic_golden_corpus(*, version: str = "1.0.0") -> BenchmarkCorpus:
    cases = (
        _scalar_case(
            case_id="BEH-HEALTHY-001",
            scenario="healthy",
            seed=7,
            case_type=BenchmarkCaseType.HEALTHY,
            expected_hypothesis=None,
        ),
        _scalar_case(
            case_id="BEH-LOCAL-001",
            scenario="local-drift",
            seed=7,
            case_type=BenchmarkCaseType.LOCAL_ASSET_EXCURSION,
            expected_hypothesis=Hypothesis.LOCAL_ASSET_DEGRADATION,
            expected_local=True,
            expected_assets=("A000",),
        ),
        _scalar_case(
            case_id="BEH-COMMON-001",
            scenario="common-mode",
            seed=7,
            case_type=BenchmarkCaseType.COMMON_MODE_PROCESS_CHANGE,
            expected_hypothesis=Hypothesis.COMMON_MODE_PROCESS_CHANGE,
            expected_fleet=True,
        ),
        _scalar_case(
            case_id="BEH-DATA-001",
            scenario="unit-scale-change",
            seed=7,
            case_type=BenchmarkCaseType.DATA_PIPELINE_CHANGE,
            expected_hypothesis=Hypothesis.DATA_PIPELINE_OR_SCHEMA_CHANGE,
            expected_assets=("A000",),
        ),
        _metrology_case(
            case_id="MET-HEALTHY-001",
            scenario="healthy",
            seed=17,
            case_type=BenchmarkCaseType.HEALTHY,
            expected_hypothesis=None,
        ),
        _metrology_case(
            case_id="MET-HEAD-001",
            scenario="measurement-head-drift",
            seed=17,
            case_type=BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT,
            expected_hypothesis=Hypothesis.METROLOGY_SYSTEM_SHIFT,
            expected_local=True,
            expected_assets=("METRO001/HEAD_A",),
        ),
        _metrology_case(
            case_id="MET-PROCESS-001",
            scenario="process-shift",
            seed=17,
            case_type=BenchmarkCaseType.COMMON_MODE_PROCESS_CHANGE,
            expected_hypothesis=Hypothesis.COMMON_MODE_PROCESS_CHANGE,
            expected_fleet=True,
        ),
        _metrology_case(
            case_id="MET-REMEASURE-001",
            scenario="remeasure-instability",
            seed=17,
            case_type=BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT,
            expected_hypothesis=Hypothesis.METROLOGY_SYSTEM_SHIFT,
            expected_local=True,
            expected_assets=("METRO001/HEAD_A",),
        ),
        _metrology_case(
            case_id="MET-SPATIAL-001",
            scenario="spatial-head-drift",
            seed=17,
            case_type=BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT,
            expected_hypothesis=Hypothesis.METROLOGY_SYSTEM_SHIFT,
            expected_local=True,
            expected_assets=("METRO001/HEAD_A",),
        ),
    )
    return BenchmarkCorpus(
        corpus_id="ephi-synthetic-golden",
        version=version,
        created_at=datetime(2026, 8, 19, tzinfo=timezone.utc),
        description=(
            "Fixed synthetic regression corpus spanning healthy, local, common-mode, "
            "data-pipeline, and metrology measurement-system cases."
        ),
        cases=cases,
    )


def save_corpus(corpus: BenchmarkCorpus, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(corpus.model_dump(mode="json"), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return target


def load_corpus(path: str | Path) -> BenchmarkCorpus:
    return BenchmarkCorpus.model_validate_json(Path(path).read_text(encoding="utf-8"))
