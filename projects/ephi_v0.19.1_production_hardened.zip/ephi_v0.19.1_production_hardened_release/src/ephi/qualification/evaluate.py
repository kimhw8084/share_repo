from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from statistics import mean

from ephi.domain.benchmark import (
    BenchmarkCase,
    BenchmarkCorpus,
    BenchmarkFamily,
    BenchmarkLabelConfidence,
    BenchmarkSourceKind,
)
from ephi.domain.evidence import Hypothesis
from ephi.domain.health import HealthSeverity
from ephi.qualification.internal import HistoricalBenchmarkLoader
from ephi.qualification.methods import QualificationMethod, baseline_method
from ephi.qualification.replay import StrictReplayResult, strict_knowledge_replay
from ephi.synthetic.metrology import MetrologyScenarioConfig, generate_metrology_observations
from ephi.synthetic.scalar import ScalarScenarioConfig, generate_scalar_observations


def _parse_dt(value: object) -> datetime:
    if isinstance(value, datetime):
        return value
    return datetime.fromisoformat(str(value))


def _scalar_config(case: BenchmarkCase) -> ScalarScenarioConfig:
    cfg = dict(case.generator_config)
    if "start_time" in cfg:
        cfg["start_time"] = _parse_dt(cfg["start_time"])
    return ScalarScenarioConfig(**cfg)


def _metrology_config(case: BenchmarkCase) -> MetrologyScenarioConfig:
    cfg = dict(case.generator_config)
    if "start_time" in cfg:
        cfg["start_time"] = _parse_dt(cfg["start_time"])
    return MetrologyScenarioConfig(**cfg)


def replay_case(
    case: BenchmarkCase,
    method: QualificationMethod,
    *,
    internal_loader: HistoricalBenchmarkLoader | None = None,
) -> StrictReplayResult:
    if case.source_kind == BenchmarkSourceKind.SYNTHETIC_SCALAR:
        observations = generate_scalar_observations(_scalar_config(case))
        return strict_knowledge_replay(
            observations,
            pipeline_factory=method.behavioral_factory,
        )
    if case.source_kind == BenchmarkSourceKind.SYNTHETIC_METROLOGY:
        observations = generate_metrology_observations(_metrology_config(case))
        return strict_knowledge_replay(
            observations,
            pipeline_factory=method.metrology_factory,
        )
    if case.source_kind == BenchmarkSourceKind.INTERNAL_HISTORY:
        if internal_loader is None:
            raise ValueError(
                "INTERNAL_HISTORY case requires a HistoricalBenchmarkLoader supplied by the company port"
            )
        observations = list(internal_loader.load(case))
        if case.family == BenchmarkFamily.BEHAVIORAL:
            return strict_knowledge_replay(
                observations,
                pipeline_factory=method.behavioral_factory,
            )
        if case.family == BenchmarkFamily.METROLOGY:
            return strict_knowledge_replay(
                observations,
                pipeline_factory=method.metrology_factory,
            )
        raise ValueError(f"Unsupported internal benchmark family: {case.family}")
    raise ValueError(f"Unsupported benchmark source kind: {case.source_kind}")


@dataclass(frozen=True, slots=True)
class CaseQualification:
    case_id: str
    family: str
    case_type: str
    label_confidence: str
    passed: bool
    detected_expected_episode: bool
    expected_hypothesis_match: bool
    expected_hypothesis_fraction: float | None
    local_episode_count: int
    fleet_episode_count: int
    false_actionable_episode_count: int
    unexpected_fleet_episode_count: int
    actionable_assessment_count: int
    actionable_asset_ids: tuple[str, ...]
    first_detection_known_at: str | None
    first_detection_event_time: str | None
    detection_delay_minutes: float | None
    lead_time_minutes: float | None
    knowledge_steps: int
    rebuild_count: int
    runtime_seconds: float
    failure_reasons: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class QualificationSummary:
    cases: int
    passed_cases: int
    pass_rate: float
    expected_actionable_cases: int
    detected_actionable_cases: int
    episode_recall: float | None
    false_actionable_episodes: int
    false_actionable_episodes_per_1000_asset_hours: float | None
    mean_detection_delay_minutes: float | None
    mean_labeled_lead_time_minutes: float | None
    total_runtime_seconds: float


@dataclass(frozen=True, slots=True)
class QualificationReport:
    corpus_id: str
    corpus_version: str
    corpus_hash: str
    method_id: str
    method_description: str
    generated_at: str
    summary: QualificationSummary
    cases: tuple[CaseQualification, ...]
    strata: dict[str, object]

    def to_dict(self) -> dict[str, object]:
        return {
            "corpus_id": self.corpus_id,
            "corpus_version": self.corpus_version,
            "corpus_hash": self.corpus_hash,
            "method_id": self.method_id,
            "method_description": self.method_description,
            "generated_at": self.generated_at,
            "summary": asdict(self.summary),
            "cases": [asdict(case) for case in self.cases],
            "strata": self.strata,
        }

    def write_json(self, path: str | Path) -> Path:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return target


def _hypothesis_fraction(case: BenchmarkCase, replay: StrictReplayResult) -> float | None:
    if case.expected_hypothesis is None:
        return None
    points = list(replay.assessment_points)
    if case.onset_event_time is not None:
        points = [point for point in points if point.event_time >= case.onset_event_time]
    if case.expected_asset_ids:
        expected = set(case.expected_asset_ids)
        points = [point for point in points if point.asset_id in expected]
    if case.expected_local_actionable:
        points = [point for point in points if point.severity >= HealthSeverity.INVESTIGATE]
    if not points:
        return 0.0
    matches = sum(point.leading_hypothesis == case.expected_hypothesis for point in points)
    return matches / len(points)


def _first_detection(case: BenchmarkCase, replay: StrictReplayResult) -> tuple[datetime | None, datetime | None]:
    if case.expected_local_actionable:
        expected = set(case.expected_asset_ids)
        points = [
            point
            for point in replay.assessment_points
            if point.asset_id in expected and point.severity >= HealthSeverity.INVESTIGATE
        ]
        if points:
            first = min(points, key=lambda point: point.known_at)
            return first.known_at, first.event_time
        return None, None
    if case.expected_fleet_actionable:
        if replay.fleet_episode_points:
            first = min(replay.fleet_episode_points, key=lambda point: point.known_at)
            return first.known_at, first.event_time
    return None, None


def evaluate_case(
    case: BenchmarkCase,
    method: QualificationMethod,
    *,
    internal_loader: HistoricalBenchmarkLoader | None = None,
) -> CaseQualification:
    started = time.perf_counter()
    replay = replay_case(case, method, internal_loader=internal_loader)
    runtime = time.perf_counter() - started

    expected_assets = set(case.expected_asset_ids)
    actionable = [point for point in replay.assessment_points if point.severity >= HealthSeverity.INVESTIGATE]
    actionable_assets = tuple(sorted({point.asset_id for point in actionable}))

    if case.expected_local_actionable:
        false_local = sum(
            point.asset_id not in expected_assets for point in replay.local_episode_points
        )
        expected_local_detected = any(
            point.asset_id in expected_assets for point in replay.local_episode_points
        ) and any(point.asset_id in expected_assets for point in actionable)
    else:
        false_local = len(replay.local_episode_points)
        expected_local_detected = not case.expected_local_actionable

    unexpected_fleet = 0 if case.expected_fleet_actionable else len(replay.fleet_episode_points)
    expected_fleet_detected = (
        bool(replay.fleet_episode_points) if case.expected_fleet_actionable else True
    )
    detected_expected_episode = expected_local_detected and expected_fleet_detected

    hypothesis_fraction = _hypothesis_fraction(case, replay)
    hypothesis_match = (
        True
        if case.expected_hypothesis is None
        else (hypothesis_fraction is not None and hypothesis_fraction >= 0.50)
    )
    # Fleet hypotheses are represented by FleetEpisode even if per-asset assessment
    # transitions include competing local/insufficient states during onset.
    if case.expected_fleet_actionable and replay.fleet_episode_points:
        hypothesis_match = any(
            point.hypothesis == case.expected_hypothesis
            for point in replay.fleet_episode_points
        )

    first_known, first_event = _first_detection(case, replay)
    detection_delay = None
    if first_known is not None and case.onset_event_time is not None:
        detection_delay = (first_known - case.onset_event_time).total_seconds() / 60.0
    lead_time = None
    if first_known is not None and case.external_detection_time is not None:
        lead_time = (case.external_detection_time - first_known).total_seconds() / 60.0

    reasons: list[str] = []
    if not detected_expected_episode:
        reasons.append("expected episode was not detected with the required scope")
    if false_local:
        reasons.append(f"{false_local} false local actionable episode(s)")
    if unexpected_fleet:
        reasons.append(f"{unexpected_fleet} unexpected fleet episode(s)")
    if not hypothesis_match:
        reasons.append("expected hypothesis did not dominate qualified post-onset evidence")

    # Healthy/no-action cases pass only when they remain silent. Cases with a
    # non-actionable expected hypothesis (e.g. data-pipeline shift) must also match it.
    passed = not reasons
    return CaseQualification(
        case_id=case.case_id,
        family=case.family.value,
        case_type=case.case_type.value,
        label_confidence=case.label_confidence.value,
        passed=passed,
        detected_expected_episode=detected_expected_episode,
        expected_hypothesis_match=hypothesis_match,
        expected_hypothesis_fraction=hypothesis_fraction,
        local_episode_count=len(replay.local_episode_points),
        fleet_episode_count=len(replay.fleet_episode_points),
        false_actionable_episode_count=false_local,
        unexpected_fleet_episode_count=unexpected_fleet,
        actionable_assessment_count=len(actionable),
        actionable_asset_ids=actionable_assets,
        first_detection_known_at=first_known.isoformat() if first_known else None,
        first_detection_event_time=first_event.isoformat() if first_event else None,
        detection_delay_minutes=detection_delay,
        lead_time_minutes=lead_time,
        knowledge_steps=replay.knowledge_steps,
        rebuild_count=replay.rebuild_count,
        runtime_seconds=runtime,
        failure_reasons=tuple(reasons),
    )


def _asset_hours(case: BenchmarkCase) -> float:
    if case.scope_start is None or case.scope_end is None:
        return 0.0
    hours = max(0.0, (case.scope_end - case.scope_start).total_seconds() / 3600.0)
    return hours * case.asset_count


def _strata_summary(
    corpus: BenchmarkCorpus,
    results: tuple[CaseQualification, ...],
    *,
    key_name: str,
) -> dict[str, object]:
    grouped: dict[str, list[tuple[BenchmarkCase, CaseQualification]]] = {}
    for case, result in zip(corpus.cases, results, strict=True):
        raw = getattr(case, key_name)
        key = raw.value if hasattr(raw, "value") else str(raw)
        grouped.setdefault(key, []).append((case, result))
    output: dict[str, object] = {}
    for key, rows in sorted(grouped.items()):
        expected = [
            (case, result)
            for case, result in rows
            if case.expected_local_actionable or case.expected_fleet_actionable
        ]
        false_count = sum(
            result.false_actionable_episode_count + result.unexpected_fleet_episode_count
            for _case, result in rows
        )
        output[key] = {
            "cases": len(rows),
            "passed_cases": sum(result.passed for _case, result in rows),
            "pass_rate": sum(result.passed for _case, result in rows) / len(rows),
            "expected_actionable_cases": len(expected),
            "detected_actionable_cases": sum(result.detected_expected_episode for _case, result in expected),
            "episode_recall": (
                sum(result.detected_expected_episode for _case, result in expected) / len(expected)
                if expected
                else None
            ),
            "false_actionable_episodes": false_count,
        }
    return output


def evaluate_corpus(
    corpus: BenchmarkCorpus,
    *,
    method: QualificationMethod | None = None,
    internal_loader: HistoricalBenchmarkLoader | None = None,
) -> QualificationReport:
    method = method or baseline_method()
    case_results = tuple(
        evaluate_case(case, method, internal_loader=internal_loader) for case in corpus.cases
    )
    expected_actionable = [
        case
        for case in corpus.cases
        if case.expected_local_actionable or case.expected_fleet_actionable
    ]
    detected = sum(
        result.detected_expected_episode
        for result, case in zip(case_results, corpus.cases, strict=True)
        if case.expected_local_actionable or case.expected_fleet_actionable
    )
    false_episodes = sum(
        item.false_actionable_episode_count + item.unexpected_fleet_episode_count
        for item in case_results
    )
    total_asset_hours = sum(_asset_hours(case) for case in corpus.cases)
    detection_delays = [
        item.detection_delay_minutes
        for item in case_results
        if item.detection_delay_minutes is not None
    ]
    lead_times = [
        item.lead_time_minutes
        for item in case_results
        if item.lead_time_minutes is not None
    ]
    summary = QualificationSummary(
        cases=len(case_results),
        passed_cases=sum(item.passed for item in case_results),
        pass_rate=(sum(item.passed for item in case_results) / len(case_results)) if case_results else 1.0,
        expected_actionable_cases=len(expected_actionable),
        detected_actionable_cases=detected,
        episode_recall=(detected / len(expected_actionable)) if expected_actionable else None,
        false_actionable_episodes=false_episodes,
        false_actionable_episodes_per_1000_asset_hours=(
            false_episodes / total_asset_hours * 1000.0 if total_asset_hours > 0 else None
        ),
        mean_detection_delay_minutes=(mean(detection_delays) if detection_delays else None),
        mean_labeled_lead_time_minutes=(mean(lead_times) if lead_times else None),
        total_runtime_seconds=sum(item.runtime_seconds for item in case_results),
    )
    return QualificationReport(
        corpus_id=corpus.corpus_id,
        corpus_version=corpus.version,
        corpus_hash=corpus.stable_hash(),
        method_id=method.method_id,
        method_description=method.description,
        generated_at=datetime.now().astimezone().isoformat(),
        summary=summary,
        cases=case_results,
        strata={
            "by_label_confidence": _strata_summary(
                corpus, case_results, key_name="label_confidence"
            ),
            "by_family": _strata_summary(corpus, case_results, key_name="family"),
            "by_case_type": _strata_summary(corpus, case_results, key_name="case_type"),
        },
    )
