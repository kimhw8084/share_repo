from __future__ import annotations

from dataclasses import asdict, dataclass
from statistics import median

import numpy as np

from ephi.domain.context import ContextKey
from ephi.domain.features import ScalarFeatureObservation
from ephi.populations.peers import PeerConfig, build_peer_snapshots
from ephi.populations.references import ReferenceConfig, ReferenceManager


@dataclass(frozen=True, slots=True)
class ReferenceContaminationPoint:
    contamination_fraction: float
    median_shift: float
    mad_ratio: float


@dataclass(frozen=True, slots=True)
class ReferenceStressReport:
    clean_median: float
    clean_mad: float
    contamination: tuple[ReferenceContaminationPoint, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "clean_median": self.clean_median,
            "clean_mad": self.clean_mad,
            "contamination": [asdict(point) for point in self.contamination],
        }


@dataclass(frozen=True, slots=True)
class PeerStressReport:
    target_peer_center_clean: float
    target_peer_center_one_poisoned: float
    target_peer_center_three_member_poisoned: float
    common_mode_local_residual_max: float
    common_mode_fleet_shift_min: float

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def run_reference_contamination_stress(*, seed: int = 41, n: int = 1000) -> ReferenceStressReport:
    rng = np.random.default_rng(seed)
    clean = rng.normal(100.0, 0.6, n)
    clean_median = float(np.median(clean))
    clean_mad = float(1.4826 * np.median(np.abs(clean - clean_median)))
    points: list[ReferenceContaminationPoint] = []
    for fraction in (0.01, 0.05, 0.10):
        count = max(1, int(n * fraction))
        contaminated = clean.copy()
        contaminated[:count] = rng.normal(106.0, 0.6, count)
        current_median = float(np.median(contaminated))
        current_mad = float(1.4826 * np.median(np.abs(contaminated - current_median)))
        points.append(
            ReferenceContaminationPoint(
                contamination_fraction=fraction,
                median_shift=current_median - clean_median,
                mad_ratio=current_mad / max(clean_mad, 1e-12),
            )
        )
    return ReferenceStressReport(clean_median, clean_mad, tuple(points))


def run_peer_poisoning_stress() -> PeerStressReport:
    config = PeerConfig(min_peer_count=2, confidence_full_count=3)
    clean = {
        "A": (0.10, 0.60),
        "B": (0.00, 0.60),
        "C": (-0.10, 0.60),
        "D": (0.05, 0.60),
    }
    poisoned = dict(clean)
    poisoned["B"] = (5.0, 0.60)
    three_member = {
        "A": (0.10, 0.60),
        "B": (5.0, 0.60),
        "C": (-0.10, 0.60),
    }
    clean_snapshot = build_peer_snapshots(clean, config=config)["A"]
    poisoned_snapshot = build_peer_snapshots(poisoned, config=config)["A"]
    three_snapshot = build_peer_snapshots(three_member, config=config)["A"]

    common = {asset: (3.0 + offset, 0.60) for asset, offset in zip("ABCD", (0.0, 0.05, -0.05, 0.02))}
    common_snapshots = build_peer_snapshots(common, config=config)
    local_residuals = [
        abs((common[asset][0] - snapshot.peer_center_change) / snapshot.peer_change_mad)
        for asset, snapshot in common_snapshots.items()
    ]
    fleet = [abs(snapshot.fleet_shift_z) for snapshot in common_snapshots.values()]
    return PeerStressReport(
        target_peer_center_clean=clean_snapshot.peer_center_change,
        target_peer_center_one_poisoned=poisoned_snapshot.peer_center_change,
        target_peer_center_three_member_poisoned=three_snapshot.peer_center_change,
        common_mode_local_residual_max=max(local_residuals),
        common_mode_fleet_shift_min=min(fleet),
    )
