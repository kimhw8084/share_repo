from __future__ import annotations

from dataclasses import asdict, dataclass

from pathlib import Path

import yaml
from pydantic import BaseModel, ConfigDict, Field

from ephi.qualification.evaluate import QualificationReport


class QualificationGatePolicy(BaseModel):
    """Release gate thresholds are policy, not scientific constants."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    policy_id: str
    min_case_pass_rate: float = Field(ge=0.0, le=1.0)
    min_episode_recall: float = Field(ge=0.0, le=1.0)
    max_false_actionable_episodes_per_1000_asset_hours: float = Field(ge=0.0)
    require_zero_case_failures: bool = False

    @classmethod
    def synthetic_regression(cls) -> "QualificationGatePolicy":
        return cls(
            policy_id="synthetic-regression-v1",
            min_case_pass_rate=1.0,
            min_episode_recall=1.0,
            max_false_actionable_episodes_per_1000_asset_hours=0.0,
            require_zero_case_failures=True,
        )


@dataclass(frozen=True, slots=True)
class GateResult:
    gate: str
    passed: bool
    actual: float | int | None
    requirement: str


@dataclass(frozen=True, slots=True)
class QualificationDecision:
    policy_id: str
    passed: bool
    gates: tuple[GateResult, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "policy_id": self.policy_id,
            "passed": self.passed,
            "gates": [asdict(gate) for gate in self.gates],
        }


def apply_gate_policy(
    report: QualificationReport,
    policy: QualificationGatePolicy,
) -> QualificationDecision:
    false_rate = report.summary.false_actionable_episodes_per_1000_asset_hours
    recall = report.summary.episode_recall
    gates = [
        GateResult(
            "case_pass_rate",
            report.summary.pass_rate >= policy.min_case_pass_rate,
            report.summary.pass_rate,
            f">= {policy.min_case_pass_rate}",
        ),
        GateResult(
            "episode_recall",
            recall is not None and recall >= policy.min_episode_recall,
            recall,
            f">= {policy.min_episode_recall}",
        ),
        GateResult(
            "false_actionable_episode_burden",
            false_rate is not None
            and false_rate <= policy.max_false_actionable_episodes_per_1000_asset_hours,
            false_rate,
            f"<= {policy.max_false_actionable_episodes_per_1000_asset_hours} per 1000 asset-hours",
        ),
    ]
    if policy.require_zero_case_failures:
        failures = report.summary.cases - report.summary.passed_cases
        gates.append(GateResult("zero_case_failures", failures == 0, failures, "== 0"))
    result = tuple(gates)
    return QualificationDecision(policy.policy_id, all(gate.passed for gate in result), result)


def load_gate_policy(path: str | Path) -> QualificationGatePolicy:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise TypeError("qualification gate policy must be a mapping")
    return QualificationGatePolicy.model_validate(payload)
