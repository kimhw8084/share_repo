from __future__ import annotations

from dataclasses import asdict, dataclass

from ephi.domain.benchmark import BenchmarkCorpus
from ephi.qualification.evaluate import QualificationReport, evaluate_corpus
from ephi.qualification.methods import QualificationMethod


@dataclass(frozen=True, slots=True)
class MethodBakeoffRow:
    method_id: str
    pass_rate: float
    episode_recall: float | None
    false_actionable_episodes: int
    false_actionable_episodes_per_1000_asset_hours: float | None
    mean_detection_delay_minutes: float | None
    mean_labeled_lead_time_minutes: float | None
    runtime_seconds: float


@dataclass(frozen=True, slots=True)
class MethodBakeoffReport:
    corpus_id: str
    corpus_version: str
    rows: tuple[MethodBakeoffRow, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "corpus_id": self.corpus_id,
            "corpus_version": self.corpus_version,
            "rows": [asdict(row) for row in self.rows],
        }


def run_bakeoff(
    corpus: BenchmarkCorpus,
    methods: tuple[QualificationMethod, ...] | list[QualificationMethod],
) -> tuple[MethodBakeoffReport, tuple[QualificationReport, ...]]:
    reports = tuple(evaluate_corpus(corpus, method=method) for method in methods)
    rows = tuple(
        MethodBakeoffRow(
            method_id=report.method_id,
            pass_rate=report.summary.pass_rate,
            episode_recall=report.summary.episode_recall,
            false_actionable_episodes=report.summary.false_actionable_episodes,
            false_actionable_episodes_per_1000_asset_hours=(
                report.summary.false_actionable_episodes_per_1000_asset_hours
            ),
            mean_detection_delay_minutes=report.summary.mean_detection_delay_minutes,
            mean_labeled_lead_time_minutes=report.summary.mean_labeled_lead_time_minutes,
            runtime_seconds=report.summary.total_runtime_seconds,
        )
        for report in reports
    )
    return MethodBakeoffReport(corpus.corpus_id, corpus.version, rows), reports
