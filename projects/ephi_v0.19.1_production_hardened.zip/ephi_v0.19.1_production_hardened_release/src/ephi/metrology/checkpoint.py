from __future__ import annotations

import json

from ephi.adapters.base.state_store import StateStore

CHECKPOINT_SCHEMA = "metrology_pipeline_state_v1"


def save_metrology_pipeline_state(
    pipeline,
    state_store: StateStore,
    *,
    key: str = "pipeline:metrology",
    expected_version: int | None = None,
) -> int:
    payload = {
        "schema": CHECKPOINT_SCHEMA,
        "engine": pipeline.engine.export_state(),
        "episodes": pipeline.episodes.export_state(),
        "fleet_episodes": pipeline.fleet_episodes.export_state(),
    }
    record = state_store.compare_and_set(
        key,
        expected_version=expected_version,
        value=json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8"),
    )
    return record.version


def restore_metrology_pipeline_state(
    pipeline,
    state_store: StateStore,
    *,
    key: str = "pipeline:metrology",
) -> int | None:
    record = state_store.get(key)
    if record is None:
        return None
    payload = json.loads(record.value.decode("utf-8"))
    if payload.get("schema") != CHECKPOINT_SCHEMA:
        raise ValueError(f"Unsupported metrology checkpoint schema: {payload.get('schema')!r}")
    engine = payload.get("engine")
    episodes = payload.get("episodes")
    fleet = payload.get("fleet_episodes")
    if not isinstance(engine, dict) or not isinstance(episodes, dict) or not isinstance(fleet, dict):
        raise TypeError("invalid metrology pipeline checkpoint")
    pipeline.engine.restore_state(engine)
    pipeline.episodes.restore_state(episodes)
    pipeline.fleet_episodes.restore_state(fleet)
    return record.version
