from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field, replace
from itertools import groupby
from statistics import median

from ephi.detectors.sequential import SequentialConfig, SequentialState, update_sequential
from ephi.domain.context import ContextKey
from ephi.domain.features import ScalarFeatureObservation
from ephi.domain.health import HealthAssessment
from ephi.domain.measurement_scale import MeasurementScalePolicy
from ephi.domain.metrology import (
    MeasurementSystemResult,
    MetrologyMeasurementSummary,
    MetrologyObservation,
)
from ephi.episodes.fleet import FleetEpisodeService
from ephi.episodes.service import EpisodeService
from ephi.evidence.metrology import (
    MetrologyEvidenceConfig,
    build_metrology_health_assessment,
    evidence_from_measurement_system,
)
from ephi.features.metrology import summarize_metrology_observations
from ephi.populations.peers import PeerConfig, build_peer_snapshots
from ephi.populations.references import ReferenceConfig, ReferenceManager


@dataclass(frozen=True, slots=True)
class MeasurementSystemConfig:
    reference: ReferenceConfig = ReferenceConfig(
        min_reference_n=24,
        max_adaptive_n=180,
        bootstrap_n=36,
        confidence_full_n=72,
        scale_floor=0.04,
    )
    production: ReferenceConfig = ReferenceConfig(
        min_reference_n=36,
        max_adaptive_n=240,
        bootstrap_n=60,
        confidence_full_n=120,
        scale_floor=0.04,
    )
    matching: ReferenceConfig = ReferenceConfig(
        min_reference_n=30,
        max_adaptive_n=220,
        bootstrap_n=48,
        confidence_full_n=96,
        scale_floor=0.04,
    )
    spatial: ReferenceConfig = ReferenceConfig(
        min_reference_n=30,
        max_adaptive_n=220,
        bootstrap_n=48,
        confidence_full_n=96,
        scale_floor=0.03,
    )
    repeatability: ReferenceConfig = ReferenceConfig(
        min_reference_n=24,
        max_adaptive_n=120,
        bootstrap_n=30,
        confidence_full_n=45,
        admission_abs_z=3.5,
        anchor_admission_abs_z=3.0,
        scale_floor=0.03,
    )
    peers: PeerConfig = PeerConfig(min_peer_count=2, confidence_full_count=3)
    repeatability_recent_window: int = 8
    repeatability_recent_min: int = 6
    sequential: SequentialConfig = SequentialConfig(
        lambda_fast=0.35,
        lambda_slow=0.10,
        cusum_k=0.50,
        persistence_z=2.5,
    )

    @classmethod
    def from_scale_policies(
        cls,
        policies: tuple[MeasurementScalePolicy, ...] | list[MeasurementScalePolicy],
        *,
        base: "MeasurementSystemConfig | None" = None,
    ) -> "MeasurementSystemConfig":
        """Overlay characteristic-specific robust floors onto qualified channel configs.

        Synthetic defaults remain fallback values. Internal qualification should pass
        policies derived from configured instrument resolution/uncertainty and healthy
        data rather than carrying synthetic constants into production.
        """
        base = base or cls()
        channel_features = {
            "reference": lambda c: f"METRO_REF:{c}:mean",
            "production": lambda c: f"METRO_PROD:{c}:mean",
            "matching": lambda c: f"CROSS_TOOL:{c}",
            "spatial": lambda c: f"SPATIAL_CENTER_EDGE:{c}",
            "repeatability": lambda c: f"REMEASURE_DELTA:{c}",
        }
        configs = {}
        for channel, feature_name in channel_features.items():
            current = getattr(base, channel)
            overrides = dict(current.feature_scale_floors)
            for policy in policies:
                overrides[feature_name(policy.characteristic_id)] = policy.robust_scale_floor
            configs[channel] = replace(current, feature_scale_floors=overrides)
        return replace(
            base,
            reference=configs["reference"],
            production=configs["production"],
            matching=configs["matching"],
            spatial=configs["spatial"],
            repeatability=configs["repeatability"],
        )


@dataclass(frozen=True, slots=True)
class _PreparedMetric:
    obs: ScalarFeatureObservation
    self_z: float
    anchor_z: float
    confidence: float
    physical_change: float
    anchor_median: float
    anchor_mad: float


@dataclass(frozen=True, slots=True)
class _SparsePeerMetric:
    z: float | None
    persistence: int
    confidence: float
    ewma: float | None
    peer_z: float | None
    peer_persistence: int
    peer_ewma: float | None
    distribution_z: float | None = None


@dataclass(slots=True)
class MeasurementSystemEngine:
    config: MeasurementSystemConfig = field(default_factory=MeasurementSystemConfig)
    reference_manager: ReferenceManager = field(init=False)
    production_manager: ReferenceManager = field(init=False)
    matching_manager: ReferenceManager = field(init=False)
    spatial_manager: ReferenceManager = field(init=False)
    repeatability_manager: ReferenceManager = field(init=False)
    _sequential: dict[tuple[str, str, str], SequentialState] = field(default_factory=dict)
    _repeatability_recent: dict[tuple[str, str], deque[float]] = field(default_factory=dict)
    _pending_remeasure: dict[tuple[str, str], dict[str, MetrologyMeasurementSummary]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.reference_manager = ReferenceManager(self.config.reference)
        self.production_manager = ReferenceManager(self.config.production)
        self.matching_manager = ReferenceManager(self.config.matching)
        self.spatial_manager = ReferenceManager(self.config.spatial)
        self.repeatability_manager = ReferenceManager(self.config.repeatability)

    def _state(self, subject_id: str, characteristic_id: str, channel: str) -> SequentialState:
        key = (subject_id, characteristic_id, channel)
        if key not in self._sequential:
            self._sequential[key] = SequentialState()
        return self._sequential[key]

    @staticmethod
    def _metric_obs(
        summary: MetrologyMeasurementSummary,
        *,
        feature_id: str,
        value: float,
        context: ContextKey | None = None,
    ) -> ScalarFeatureObservation:
        return ScalarFeatureObservation(
            execution_id=summary.measurement_id,
            asset_id=summary.subject_id,
            context=context or summary.context,
            feature_id=feature_id,
            value=float(value),
            event_time=summary.event_time,
            available_at=summary.available_at,
        )

    @staticmethod
    def _prepare(manager: ReferenceManager, obs: ScalarFeatureObservation) -> _PreparedMetric | None:
        snapshot = manager.snapshot(obs)
        if snapshot is None or not snapshot.adequate:
            manager.bootstrap(obs)
            return None
        self_z, anchor_z = manager.robust_z(obs, snapshot)
        return _PreparedMetric(
            obs=obs,
            self_z=self_z,
            anchor_z=anchor_z,
            confidence=snapshot.confidence,
            physical_change=obs.value - snapshot.anchor_median,
            anchor_median=snapshot.anchor_median,
            anchor_mad=snapshot.anchor_mad,
        )

    @staticmethod
    def _admit(manager: ReferenceManager, prepared: _PreparedMetric) -> None:
        manager.admit_after_score(
            prepared.obs,
            self_z=prepared.self_z,
            anchor_z=prepared.anchor_z,
            data_pipeline_suspect=False,
        )

    def _score_sparse_metric(
        self,
        manager: ReferenceManager,
        obs: ScalarFeatureObservation,
        *,
        characteristic_id: str,
        channel: str,
    ) -> tuple[float | None, int, float, float | None]:
        prepared = self._prepare(manager, obs)
        if prepared is None:
            return None, 0, 0.0, None
        z = prepared.anchor_z if abs(prepared.anchor_z) > abs(prepared.self_z) else prepared.self_z
        state = update_sequential(
            self._state(obs.asset_id, characteristic_id, channel),
            z,
            self.config.sequential,
        )
        self._admit(manager, prepared)
        return float(z), state.persistence_count, prepared.confidence, float(state.ewma_fast)

    @staticmethod
    def _repeat_context(summary: MetrologyMeasurementSummary) -> ContextKey:
        return ContextKey(
            operation="METRO_REPEAT",
            recipe_id=summary.context.recipe_id,
            product_id="ALL",
            technology=summary.context.technology,
        )

    def _repeatability_distribution_z(
        self,
        *,
        subject_id: str,
        characteristic_id: str,
        value: float,
        anchor_median: float,
        anchor_mad: float,
    ) -> float | None:
        key = (subject_id, characteristic_id)
        if key not in self._repeatability_recent:
            self._repeatability_recent[key] = deque(maxlen=self.config.repeatability_recent_window)
        recent = self._repeatability_recent[key]
        recent.append(float(value))
        if len(recent) < self.config.repeatability_recent_min:
            return None
        return float((median(recent) - anchor_median) / max(anchor_mad, 1e-9))

    def _build_repeatability(
        self,
        summaries: list[MetrologyMeasurementSummary],
    ) -> dict[str, tuple[MetrologyMeasurementSummary, _SparsePeerMetric]]:
        # Remeasure attempts commonly arrive in different incremental batches. Keep a
        # compact pending summary cache until a subject has at least two attempts;
        # score the repeatability evidence at the later attempt's availability time.
        for summary in summaries:
            if not summary.remeasure_group_id:
                continue
            key = (summary.remeasure_group_id, summary.characteristic_id)
            self._pending_remeasure.setdefault(key, {})[summary.measurement_id] = summary

        output: dict[str, tuple[MetrologyMeasurementSummary, _SparsePeerMetric]] = {}
        for group_key, rows_by_id in list(self._pending_remeasure.items()):
            _group_id, characteristic_id = group_key
            rows = list(rows_by_id.values())
            by_subject: dict[str, list[MetrologyMeasurementSummary]] = defaultdict(list)
            for row in rows:
                by_subject[row.subject_id].append(row)

            complete = {
                subject_id: sorted(subject_rows, key=lambda row: row.attempt_index)
                for subject_id, subject_rows in by_subject.items()
                if len({row.attempt_index for row in subject_rows}) >= 2
            }
            if not complete:
                continue

            prepared_by_subject: dict[
                str, tuple[MetrologyMeasurementSummary, MetrologyMeasurementSummary, _PreparedMetric]
            ] = {}
            for subject_id, subject_rows in complete.items():
                primary = subject_rows[0]
                trigger = subject_rows[-1]
                delta = max(row.mean for row in subject_rows) - min(row.mean for row in subject_rows)
                obs = self._metric_obs(
                    trigger,
                    feature_id=f"REMEASURE_DELTA:{characteristic_id}",
                    value=abs(delta),
                    context=self._repeat_context(primary),
                )
                prepared = self._prepare(self.repeatability_manager, obs)
                if prepared is not None:
                    prepared_by_subject[subject_id] = (primary, trigger, prepared)

            peer_snapshots = build_peer_snapshots(
                {
                    subject_id: (prepared.physical_change, prepared.anchor_mad)
                    for subject_id, (_primary, _trigger, prepared) in prepared_by_subject.items()
                },
                config=self.config.peers,
            )

            for subject_id, (_primary, trigger, prepared) in prepared_by_subject.items():
                z = prepared.anchor_z if abs(prepared.anchor_z) > abs(prepared.self_z) else prepared.self_z
                self_state = update_sequential(
                    self._state(subject_id, characteristic_id, "repeatability"),
                    z,
                    self.config.sequential,
                )
                peer_z: float | None = None
                peer_persistence = 0
                peer_ewma: float | None = None
                confidence = prepared.confidence
                peer = peer_snapshots.get(subject_id)
                if peer is not None and peer.adequate:
                    peer_z = (prepared.physical_change - peer.peer_center_change) / peer.peer_change_mad
                    peer_state = update_sequential(
                        self._state(subject_id, characteristic_id, "repeatability_peer"),
                        peer_z,
                        self.config.sequential,
                    )
                    peer_persistence = peer_state.persistence_count
                    peer_ewma = float(peer_state.ewma_fast)
                    confidence = min(confidence, peer.confidence)
                distribution_z = self._repeatability_distribution_z(
                    subject_id=subject_id,
                    characteristic_id=characteristic_id,
                    value=prepared.obs.value,
                    anchor_median=prepared.anchor_median,
                    anchor_mad=prepared.anchor_mad,
                )
                output[trigger.measurement_id] = (
                    trigger,
                    _SparsePeerMetric(
                        z=float(z),
                        persistence=self_state.persistence_count,
                        confidence=confidence,
                        ewma=float(self_state.ewma_fast),
                        peer_z=peer_z,
                        peer_persistence=peer_persistence,
                        peer_ewma=peer_ewma,
                        distribution_z=distribution_z,
                    ),
                )

            for _primary, _trigger, prepared in prepared_by_subject.values():
                self._admit(self.repeatability_manager, prepared)

            # Completed subjects are removed only after their score is emitted. Any
            # incomplete late peer remains pending for a later batch.
            complete_subjects = set(complete)
            for measurement_id, row in list(rows_by_id.items()):
                if row.subject_id in complete_subjects:
                    del rows_by_id[measurement_id]
            if not rows_by_id:
                del self._pending_remeasure[group_key]

        return output

    def process(
        self,
        observations: list[MetrologyObservation],
    ) -> list[MeasurementSystemResult]:
        summaries = summarize_metrology_observations(observations)
        repeatability = self._build_repeatability(summaries)
        primaries = [summary for summary in summaries if summary.attempt_index == 0]
        results: list[MeasurementSystemResult] = []

        group_key = lambda row: (
            row.event_time,
            row.context,
            row.characteristic_id,
            row.material_id,
            row.is_reference_material,
        )
        for _, grouped in groupby(primaries, key=group_key):
            group = list(grouped)
            if not group:
                continue
            characteristic_id = group[0].characteristic_id

            primary_prepared: dict[str, _PreparedMetric] = {}
            primary_z: dict[str, tuple[float, float, float]] = {}
            manager = self.reference_manager if group[0].is_reference_material else self.production_manager
            prefix = "METRO_REF" if group[0].is_reference_material else "METRO_PROD"

            # Score all current values before admitting any current value.
            for summary in group:
                obs = self._metric_obs(
                    summary,
                    feature_id=f"{prefix}:{characteristic_id}:mean",
                    value=summary.mean,
                )
                prepared = self._prepare(manager, obs)
                if prepared is not None:
                    primary_prepared[summary.subject_id] = prepared
                    z = prepared.anchor_z if abs(prepared.anchor_z) > abs(prepared.self_z) else prepared.self_z
                    primary_z[summary.subject_id] = (z, prepared.anchor_z, prepared.confidence)

            peer_snapshots = {}
            if not group[0].is_reference_material:
                peer_snapshots = build_peer_snapshots(
                    {
                        subject_id: (prepared.physical_change, prepared.anchor_mad)
                        for subject_id, prepared in primary_prepared.items()
                    },
                    config=self.config.peers,
                )

            # Cross-tool matching is calculated from the same material measured on
            # qualified heads. Static head offsets are learned in the residual baseline.
            group_means = {summary.subject_id: summary.mean for summary in group}
            matching_prepared: dict[str, _PreparedMetric] = {}
            matching_z: dict[str, tuple[float, int, float, float]] = {}
            if len(group_means) >= 2:
                small_cohort_center = (
                    float(median(group_means.values())) if len(group_means) <= 3 else None
                )
                for summary in group:
                    peers = [value for subject, value in group_means.items() if subject != summary.subject_id]
                    if not peers:
                        continue
                    center = (
                        small_cohort_center
                        if small_cohort_center is not None
                        else float(median(peers))
                    )
                    residual = summary.mean - center
                    obs = self._metric_obs(
                        summary,
                        feature_id=f"CROSS_TOOL:{characteristic_id}",
                        value=residual,
                    )
                    prepared = self._prepare(self.matching_manager, obs)
                    if prepared is not None:
                        matching_prepared[summary.subject_id] = prepared
                        z = prepared.anchor_z if abs(prepared.anchor_z) > abs(prepared.self_z) else prepared.self_z
                        state = update_sequential(
                            self._state(summary.subject_id, characteristic_id, "cross_tool"),
                            z,
                            self.config.sequential,
                        )
                        matching_z[summary.subject_id] = (
                            z, state.persistence_count, prepared.confidence, float(state.ewma_fast)
                        )

            spatial_metrics: dict[str, _SparsePeerMetric] = {}
            spatial_prepared: dict[str, _PreparedMetric] = {}
            for summary in group:
                if summary.center_edge is None:
                    continue
                obs = self._metric_obs(
                    summary,
                    feature_id=f"SPATIAL_CENTER_EDGE:{characteristic_id}",
                    value=summary.center_edge,
                )
                prepared = self._prepare(self.spatial_manager, obs)
                if prepared is not None:
                    spatial_prepared[summary.subject_id] = prepared

            spatial_peers = build_peer_snapshots(
                {
                    subject_id: (prepared.physical_change, prepared.anchor_mad)
                    for subject_id, prepared in spatial_prepared.items()
                },
                config=self.config.peers,
            )
            for subject_id, prepared in spatial_prepared.items():
                z = prepared.anchor_z if abs(prepared.anchor_z) > abs(prepared.self_z) else prepared.self_z
                self_state = update_sequential(
                    self._state(subject_id, characteristic_id, "spatial"),
                    z,
                    self.config.sequential,
                )
                peer_z: float | None = None
                peer_persistence = 0
                peer_ewma: float | None = None
                confidence = prepared.confidence
                peer = spatial_peers.get(subject_id)
                if peer is not None and peer.adequate:
                    peer_z = (prepared.physical_change - peer.peer_center_change) / peer.peer_change_mad
                    peer_state = update_sequential(
                        self._state(subject_id, characteristic_id, "spatial_peer"),
                        peer_z,
                        self.config.sequential,
                    )
                    peer_persistence = peer_state.persistence_count
                    peer_ewma = float(peer_state.ewma_fast)
                    confidence = min(confidence, peer.confidence)
                spatial_metrics[subject_id] = _SparsePeerMetric(
                    z=float(z),
                    persistence=self_state.persistence_count,
                    confidence=confidence,
                    ewma=float(self_state.ewma_fast),
                    peer_z=peer_z,
                    peer_persistence=peer_persistence,
                    peer_ewma=peer_ewma,
                )

            # Build results before baseline admission so all channels describe the same
            # pre-update knowledge state.
            for summary in group:
                subject = summary.subject_id
                reference_z: float | None = None
                reference_persistence = 0
                reference_ewma: float | None = None
                production_z: float | None = None
                production_anchor_z: float | None = None
                production_fleet_shift_z: float | None = None
                production_peer_residual_z: float | None = None
                reference_confidence = 0.0
                if subject in primary_z:
                    z, anchor_z, ref_conf = primary_z[subject]
                    if summary.is_reference_material:
                        reference_z = z
                        state = update_sequential(
                            self._state(subject, characteristic_id, "reference"),
                            z,
                            self.config.sequential,
                        )
                        reference_persistence = state.persistence_count
                        reference_ewma = float(state.ewma_fast)
                        reference_confidence = ref_conf
                    else:
                        production_z = z
                        production_anchor_z = anchor_z
                        reference_confidence = ref_conf
                        peer = peer_snapshots.get(subject)
                        if peer is not None and peer.adequate:
                            prepared = primary_prepared[subject]
                            production_peer_residual_z = (
                                prepared.physical_change - peer.peer_center_change
                            ) / peer.peer_change_mad
                            production_fleet_shift_z = peer.fleet_shift_z

                cross_tool_z, cross_persistence, matching_conf, cross_ewma = matching_z.get(
                    subject, (None, 0, 0.0, None)
                )
                spatial_metric = spatial_metrics.get(
                    subject, _SparsePeerMetric(None, 0, 0.0, None, None, 0, None, None)
                )
                repeat_entry = repeatability.get(summary.measurement_id)
                repeat_metric = (
                    repeat_entry[1]
                    if repeat_entry is not None
                    else _SparsePeerMetric(None, 0, 0.0, None, None, 0, None, None)
                )
                peer_conf = (
                    peer_snapshots[subject].confidence
                    if subject in peer_snapshots and peer_snapshots[subject].adequate
                    else 0.0
                )

                results.append(
                    MeasurementSystemResult(
                        measurement_id=summary.measurement_id,
                        subject_id=subject,
                        context=summary.context,
                        characteristic_id=characteristic_id,
                        event_time=summary.event_time,
                        production_z=production_z,
                        production_anchor_z=production_anchor_z,
                        production_fleet_shift_z=production_fleet_shift_z,
                        production_peer_residual_z=production_peer_residual_z,
                        reference_z=reference_z,
                        cross_tool_z=cross_tool_z,
                        repeatability_z=repeat_metric.z,
                        repeatability_peer_z=repeat_metric.peer_z,
                        repeatability_distribution_z=repeat_metric.distribution_z,
                        spatial_z=spatial_metric.z,
                        spatial_peer_z=spatial_metric.peer_z,
                        reference_persistence=reference_persistence,
                        cross_tool_persistence=cross_persistence,
                        repeatability_persistence=repeat_metric.persistence,
                        repeatability_peer_persistence=repeat_metric.peer_persistence,
                        spatial_persistence=spatial_metric.persistence,
                        spatial_peer_persistence=spatial_metric.peer_persistence,
                        reference_ewma=reference_ewma,
                        cross_tool_ewma=cross_ewma,
                        repeatability_ewma=repeat_metric.ewma,
                        repeatability_peer_ewma=repeat_metric.peer_ewma,
                        spatial_ewma=spatial_metric.ewma,
                        spatial_peer_ewma=spatial_metric.peer_ewma,
                        is_reference_material=summary.is_reference_material,
                        reference_confidence=reference_confidence,
                        matching_confidence=max(matching_conf, peer_conf),
                        repeatability_confidence=repeat_metric.confidence,
                        spatial_confidence=min(summary.spatial_confidence, spatial_metric.confidence),
                    )
                )

            # Controlled baseline admission after all same-material comparisons exist.
            for prepared in primary_prepared.values():
                self._admit(manager, prepared)
            for prepared in matching_prepared.values():
                self._admit(self.matching_manager, prepared)
            for prepared in spatial_prepared.values():
                self._admit(self.spatial_manager, prepared)

        # A remeasure conclusion becomes knowable when the later attempt arrives.
        # Emit a separate measurement-system result at that trigger rather than
        # backdating repeatability evidence onto the earlier production measurement.
        existing_ids = {result.measurement_id for result in results}
        for measurement_id, (trigger, repeat_metric) in repeatability.items():
            if measurement_id in existing_ids:
                continue
            results.append(
                MeasurementSystemResult(
                    measurement_id=measurement_id,
                    subject_id=trigger.subject_id,
                    context=trigger.context,
                    characteristic_id=trigger.characteristic_id,
                    event_time=trigger.event_time,
                    production_z=None,
                    production_anchor_z=None,
                    production_fleet_shift_z=None,
                    production_peer_residual_z=None,
                    reference_z=None,
                    cross_tool_z=None,
                    repeatability_z=repeat_metric.z,
                    repeatability_peer_z=repeat_metric.peer_z,
                    repeatability_distribution_z=repeat_metric.distribution_z,
                    spatial_z=None,
                    spatial_peer_z=None,
                    reference_persistence=0,
                    cross_tool_persistence=0,
                    repeatability_persistence=repeat_metric.persistence,
                    repeatability_peer_persistence=repeat_metric.peer_persistence,
                    spatial_persistence=0,
                    spatial_peer_persistence=0,
                    reference_ewma=None,
                    cross_tool_ewma=None,
                    repeatability_ewma=repeat_metric.ewma,
                    repeatability_peer_ewma=repeat_metric.peer_ewma,
                    spatial_ewma=None,
                    spatial_peer_ewma=None,
                    is_reference_material=False,
                    reference_confidence=0.0,
                    matching_confidence=0.0,
                    repeatability_confidence=repeat_metric.confidence,
                    spatial_confidence=0.0,
                )
            )

        return sorted(results, key=lambda item: (item.event_time, item.measurement_id))

    def export_state(self) -> dict[str, object]:
        return {
            "reference_manager": self.reference_manager.export_state(),
            "production_manager": self.production_manager.export_state(),
            "matching_manager": self.matching_manager.export_state(),
            "spatial_manager": self.spatial_manager.export_state(),
            "repeatability_manager": self.repeatability_manager.export_state(),
            "sequential": [
                {
                    "subject_id": subject_id,
                    "characteristic_id": characteristic_id,
                    "channel": channel,
                    "ewma_fast": state.ewma_fast,
                    "ewma_slow": state.ewma_slow,
                    "cusum_pos": state.cusum_pos,
                    "cusum_neg": state.cusum_neg,
                    "persistence_count": state.persistence_count,
                }
                for (subject_id, characteristic_id, channel), state in self._sequential.items()
            ],
            "repeatability_recent": [
                {
                    "subject_id": subject_id,
                    "characteristic_id": characteristic_id,
                    "values": list(values),
                }
                for (subject_id, characteristic_id), values in self._repeatability_recent.items()
            ],
            "pending_remeasure": [
                {
                    "measurement_id": row.measurement_id,
                    "material_id": row.material_id,
                    "asset_id": row.asset_id,
                    "process_unit_id": row.process_unit_id,
                    "context": row.context.to_dict(),
                    "characteristic_id": row.characteristic_id,
                    "event_time": row.event_time.isoformat(),
                    "available_at": row.available_at.isoformat(),
                    "mean": row.mean,
                    "median": row.median,
                    "mad": row.mad,
                    "site_count": row.site_count,
                    "center_edge": row.center_edge,
                    "radial_slope": row.radial_slope,
                    "x_slope": row.x_slope,
                    "y_slope": row.y_slope,
                    "spatial_confidence": row.spatial_confidence,
                    "is_reference_material": row.is_reference_material,
                    "remeasure_group_id": row.remeasure_group_id,
                    "attempt_index": row.attempt_index,
                }
                for rows in self._pending_remeasure.values()
                for row in rows.values()
            ],
        }

    def restore_state(self, state: dict[str, object]) -> None:
        manager_fields = {
            "reference_manager": self.reference_manager,
            "production_manager": self.production_manager,
            "matching_manager": self.matching_manager,
            "spatial_manager": self.spatial_manager,
            "repeatability_manager": self.repeatability_manager,
        }
        for name, manager in manager_fields.items():
            records = state.get(name, [])
            if not isinstance(records, list):
                raise TypeError(f"invalid metrology checkpoint field: {name}")
            manager.restore_state(records)

        sequential_raw = state.get("sequential", [])
        if not isinstance(sequential_raw, list):
            raise TypeError("invalid metrology sequential checkpoint")
        self._sequential.clear()
        for record in sequential_raw:
            if not isinstance(record, dict):
                continue
            self._sequential[(
                str(record["subject_id"]),
                str(record["characteristic_id"]),
                str(record["channel"]),
            )] = SequentialState(
                ewma_fast=float(record["ewma_fast"]),
                ewma_slow=float(record["ewma_slow"]),
                cusum_pos=float(record["cusum_pos"]),
                cusum_neg=float(record["cusum_neg"]),
                persistence_count=int(record["persistence_count"]),
            )

        recent_raw = state.get("repeatability_recent", [])
        if not isinstance(recent_raw, list):
            raise TypeError("invalid repeatability recent checkpoint")
        self._repeatability_recent.clear()
        for record in recent_raw:
            if not isinstance(record, dict):
                continue
            values = record.get("values", [])
            if not isinstance(values, list):
                raise TypeError("repeatability recent values must be a list")
            self._repeatability_recent[(
                str(record["subject_id"]),
                str(record["characteristic_id"]),
            )] = deque(
                (float(value) for value in values),
                maxlen=self.config.repeatability_recent_window,
            )

        pending_raw = state.get("pending_remeasure", [])
        if not isinstance(pending_raw, list):
            raise TypeError("invalid pending remeasure checkpoint")
        self._pending_remeasure.clear()
        from datetime import datetime
        for record in pending_raw:
            if not isinstance(record, dict):
                continue
            context_raw = record.get("context")
            if not isinstance(context_raw, dict):
                raise TypeError("pending remeasure context must be a mapping")
            row = MetrologyMeasurementSummary(
                measurement_id=str(record["measurement_id"]),
                material_id=str(record["material_id"]),
                asset_id=str(record["asset_id"]),
                process_unit_id=(
                    str(record["process_unit_id"]) if record.get("process_unit_id") is not None else None
                ),
                context=ContextKey.from_dict({str(k): str(v) for k, v in context_raw.items()}),
                characteristic_id=str(record["characteristic_id"]),
                event_time=datetime.fromisoformat(str(record["event_time"])),
                available_at=datetime.fromisoformat(str(record["available_at"])),
                mean=float(record["mean"]),
                median=float(record["median"]),
                mad=float(record["mad"]),
                site_count=int(record["site_count"]),
                center_edge=(float(record["center_edge"]) if record.get("center_edge") is not None else None),
                radial_slope=(float(record["radial_slope"]) if record.get("radial_slope") is not None else None),
                x_slope=(float(record["x_slope"]) if record.get("x_slope") is not None else None),
                y_slope=(float(record["y_slope"]) if record.get("y_slope") is not None else None),
                spatial_confidence=float(record["spatial_confidence"]),
                is_reference_material=bool(record["is_reference_material"]),
                remeasure_group_id=(
                    str(record["remeasure_group_id"])
                    if record.get("remeasure_group_id") is not None
                    else None
                ),
                attempt_index=int(record["attempt_index"]),
            )
            if row.remeasure_group_id:
                key = (row.remeasure_group_id, row.characteristic_id)
                self._pending_remeasure.setdefault(key, {})[row.measurement_id] = row


@dataclass(frozen=True, slots=True)
class MetrologyPipelineResult:
    measurements: tuple[MeasurementSystemResult, ...]
    assessments: tuple[HealthAssessment, ...]
    episode_updates: tuple[object, ...]
    fleet_episode_updates: tuple[object, ...] = ()


@dataclass(slots=True)
class MetrologyHealthPipeline:
    engine: MeasurementSystemEngine = field(default_factory=MeasurementSystemEngine)
    episodes: EpisodeService = field(default_factory=EpisodeService)
    fleet_episodes: FleetEpisodeService = field(default_factory=FleetEpisodeService)
    evidence_config: MetrologyEvidenceConfig = field(default_factory=MetrologyEvidenceConfig)

    def process(self, observations: list[MetrologyObservation]) -> MetrologyPipelineResult:
        measurements = self.engine.process(observations)
        assessments: list[HealthAssessment] = []
        episode_updates: list[object] = []
        for result in measurements:
            evidence = evidence_from_measurement_system(result, config=self.evidence_config)
            assessment = build_metrology_health_assessment(
                result,
                evidence,
                config=self.evidence_config,
            )
            assessments.append(assessment)
            episode = self.episodes.process(assessment)
            if episode is not None:
                episode_updates.append(episode)

        fleet_updates: list[object] = []
        groups: dict[tuple[object, str], list[HealthAssessment]] = {}
        for assessment in assessments:
            key = (assessment.event_time, assessment.context.stable_key())
            groups.setdefault(key, []).append(assessment)
        for group in groups.values():
            update = self.fleet_episodes.process_group(group)
            if update is not None:
                fleet_updates.append(update)

        return MetrologyPipelineResult(
            measurements=tuple(measurements),
            assessments=tuple(assessments),
            episode_updates=tuple(episode_updates),
            fleet_episode_updates=tuple(fleet_updates),
        )
