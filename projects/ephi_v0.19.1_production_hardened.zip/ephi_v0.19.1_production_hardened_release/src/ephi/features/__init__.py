from .scalar import scalar_feature_from_records

__all__ = ["scalar_feature_from_records"]
