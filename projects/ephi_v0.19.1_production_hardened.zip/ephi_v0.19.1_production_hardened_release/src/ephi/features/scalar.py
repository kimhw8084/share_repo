from __future__ import annotations

from datetime import datetime
from typing import Iterable, Mapping

from ephi.domain.context import ContextKey
from ephi.domain.features import ScalarFeatureObservation


def scalar_feature_from_records(
    records: Iterable[Mapping[str, object]],
    *,
    feature_id: str = "PRESSURE_MAIN:STEP_STABLE:value",
    as_of: datetime | None = None,
) -> list[ScalarFeatureObservation]:
    """Convert already-reduced scalar records into semantic feature observations.

    This intentionally operates on small/local fixtures. Production source-scale
    extraction remains Arrow/Polars based; this function gives the same semantic
    contract to tests and replay logic without requiring optional columnar deps.
    """

    output: list[ScalarFeatureObservation] = []
    for row in records:
        event_time = row["event_time"]
        available_at = row["available_at"]
        if not isinstance(event_time, datetime) or not isinstance(available_at, datetime):
            raise TypeError("event_time and available_at must be datetime")
        if as_of is not None and available_at > as_of:
            continue
        output.append(
            ScalarFeatureObservation(
                execution_id=str(row["execution_id"]),
                asset_id=str(row["asset_id"]),
                context=ContextKey(
                    operation=str(row["operation"]),
                    recipe_id=str(row["recipe_id"]),
                    product_id=str(row["product_id"]),
                    technology=str(row["technology"]),
                ),
                feature_id=feature_id,
                value=float(row["value"]),
                event_time=event_time,
                available_at=available_at,
                valid=bool(row.get("valid", True)),
            )
        )
    return output
