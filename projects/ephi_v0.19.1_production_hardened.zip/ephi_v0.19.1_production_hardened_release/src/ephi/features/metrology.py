from __future__ import annotations

from collections import defaultdict

import numpy as np

from ephi.domain.metrology import MetrologyMeasurementSummary, MetrologyObservation

_ROBUST_SCALE = 1.4826
_EPS = 1e-12


def _robust_mad(values: np.ndarray) -> float:
    center = float(np.median(values))
    return max(float(_ROBUST_SCALE * np.median(np.abs(values - center))), _EPS)


def summarize_metrology_observations(
    observations: list[MetrologyObservation],
) -> list[MetrologyMeasurementSummary]:
    """Aggregate site observations without discarding spatial sampling confidence."""

    groups: dict[str, list[MetrologyObservation]] = defaultdict(list)
    for obs in observations:
        if obs.valid:
            groups[obs.measurement_id].append(obs)

    output: list[MetrologyMeasurementSummary] = []
    for measurement_id, rows in groups.items():
        first = rows[0]
        if any(
            (
                row.material_id != first.material_id
                or row.asset_id != first.asset_id
                or row.process_unit_id != first.process_unit_id
                or row.context != first.context
                or row.characteristic_id != first.characteristic_id
                or row.event_time != first.event_time
                or row.is_reference_material != first.is_reference_material
                or row.remeasure_group_id != first.remeasure_group_id
                or row.attempt_index != first.attempt_index
            )
            for row in rows[1:]
        ):
            raise ValueError(f"measurement_id {measurement_id!r} mixes incompatible observations")

        values = np.asarray([row.value for row in rows], dtype=np.float64)
        mean = float(values.mean())
        median = float(np.median(values))
        mad = _robust_mad(values) if len(values) > 1 else 0.0

        coords = [
            (float(row.site_x), float(row.site_y), float(row.value))
            for row in rows
            if row.site_x is not None and row.site_y is not None
        ]
        center_edge: float | None = None
        radial_slope: float | None = None
        x_slope: float | None = None
        y_slope: float | None = None
        spatial_confidence = 0.0
        if len(coords) >= 5:
            x = np.asarray([c[0] for c in coords], dtype=np.float64)
            y = np.asarray([c[1] for c in coords], dtype=np.float64)
            z = np.asarray([c[2] for c in coords], dtype=np.float64)
            radius = np.sqrt(x * x + y * y)
            max_radius = max(float(radius.max()), _EPS)
            r_norm = radius / max_radius

            inner = z[r_norm <= 0.45]
            outer = z[r_norm >= 0.75]
            if len(inner) and len(outer):
                center_edge = float(outer.mean() - inner.mean())

            design_r = np.column_stack([np.ones_like(r_norm), r_norm])
            radial_slope = float(np.linalg.lstsq(design_r, z, rcond=None)[0][1])
            design_xy = np.column_stack([np.ones_like(x), x, y])
            coeff = np.linalg.lstsq(design_xy, z, rcond=None)[0]
            x_slope = float(coeff[1])
            y_slope = float(coeff[2])
            spatial_confidence = min(1.0, len(coords) / 25.0)

        output.append(
            MetrologyMeasurementSummary(
                measurement_id=measurement_id,
                material_id=first.material_id,
                asset_id=first.asset_id,
                process_unit_id=first.process_unit_id,
                context=first.context,
                characteristic_id=first.characteristic_id,
                event_time=first.event_time,
                available_at=max(row.available_at for row in rows),
                mean=mean,
                median=median,
                mad=mad,
                site_count=len(values),
                center_edge=center_edge,
                radial_slope=radial_slope,
                x_slope=x_slope,
                y_slope=y_slope,
                spatial_confidence=spatial_confidence,
                is_reference_material=first.is_reference_material,
                remeasure_group_id=first.remeasure_group_id,
                attempt_index=first.attempt_index,
            )
        )

    return sorted(
        output,
        key=lambda row: (
            row.event_time,
            row.context,
            row.characteristic_id,
            row.material_id,
            row.subject_id,
            row.attempt_index,
        ),
    )
