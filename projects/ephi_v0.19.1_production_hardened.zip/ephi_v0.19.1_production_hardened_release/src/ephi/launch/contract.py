from __future__ import annotations

from dataclasses import dataclass

from ephi.domain.launch import CampaignStage, LaunchEvidenceAdapterDescriptor


REQUIRED_EXECUTOR_METHODS = (
    "describe_adapter",
    "resolve_source_snapshot",
    "collect_data_reality",
    "collect_internal_golden_replay",
    "collect_production_replay_scale",
    "collect_reliability_dr_drill",
    "collect_shadow_runtime",
    "collect_engineer_shadow",
)

REQUIRED_STAGES = tuple(CampaignStage)


@dataclass(frozen=True, slots=True)
class LaunchModuleContractValidation:
    valid: bool
    missing_functions: tuple[str, ...] = ()
    missing_executor_methods: tuple[str, ...] = ()
    descriptor_errors: tuple[str, ...] = ()


def validate_launch_module(module, *, executor=None) -> LaunchModuleContractValidation:
    missing_functions = () if hasattr(module, "build_launch_evidence_executor") else ("build_launch_evidence_executor",)
    missing_methods = () if executor is None else tuple(name for name in REQUIRED_EXECUTOR_METHODS if not hasattr(executor, name))
    descriptor_errors: list[str] = []
    if executor is not None and not missing_methods:
        try:
            descriptor = LaunchEvidenceAdapterDescriptor.model_validate(executor.describe_adapter())
            missing_stages = set(REQUIRED_STAGES) - set(descriptor.supported_stages)
            if missing_stages:
                descriptor_errors.append(
                    "missing supported stages: " + ",".join(sorted(item.value for item in missing_stages))
                )
            non_idempotent = set(REQUIRED_STAGES) - set(descriptor.idempotent_stages)
            if non_idempotent:
                descriptor_errors.append(
                    "non-idempotent stages: " + ",".join(sorted(item.value for item in non_idempotent))
                )
            if not descriptor.immutable_artifact_publishing:
                descriptor_errors.append("immutable_artifact_publishing must be true")
        except Exception as exc:  # contract validation must return a diagnostic, not leak adapter errors
            descriptor_errors.append(f"invalid adapter descriptor: {exc}")
    return LaunchModuleContractValidation(
        valid=not missing_functions and not missing_methods and not descriptor_errors,
        missing_functions=missing_functions,
        missing_executor_methods=missing_methods,
        descriptor_errors=tuple(descriptor_errors),
    )
