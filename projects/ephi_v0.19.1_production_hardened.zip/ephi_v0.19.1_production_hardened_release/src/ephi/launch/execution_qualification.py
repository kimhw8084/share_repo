from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory

from pydantic import BaseModel, ConfigDict

from ephi.adapters.local.filesystem_artifact_store import FileSystemArtifactStore
from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.benchmark import BenchmarkCaseType, BenchmarkFamily, BenchmarkLabelConfidence
from ephi.domain.launch import (
    CampaignStage,
    CampaignStageStatus,
    EvidenceProvenance,
    LaunchEvidenceAdapterDescriptor,
)
from ephi.domain.onboarding import FamilyOnboardingPlan, GoldenCaseIntake, GoldenCurationState
from ephi.domain.operations import CertificationState
from ephi.launch.execution import CampaignExecutionController
from ephi.launch.handoff import handoff_launch_dossier
from ephi.launch.policy import load_launch_policy
from ephi.launch.reference_executor import ReferenceLaunchEvidenceExecutor
from ephi.launch.registry import ShadowLaunchWorkspaceRepository
from ephi.onboarding.control_plane import QualificationControlPlaneService
from ephi.onboarding.control_repository import QualificationWorkspaceRepository
from ephi.onboarding.policy import FamilyOnboardingPolicy, GoldenCoveragePolicy


class CampaignExecutionQualificationReport(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    passed: bool
    adapter_descriptor_enforced: bool
    retry_resume_preserves_completed_stages: bool
    immutable_artifact_published: bool
    artifact_tamper_blocked: bool
    source_snapshot_lineage_persisted: bool
    source_snapshot_identity_enforced: bool
    evidence_identity_conflict_rejected: bool
    promotion_handoff_idempotent: bool
    promotion_handoff_no_auto_approval: bool
    simulated_campaign_non_promotable: bool


def _controller(root: Path, *, provenance: EvidenceProvenance, fail_once=frozenset()):
    family = "METROLOGY_REFERENCE"
    release = "ephi-0.19.1-campaign-qualification"
    config_hash = "c" * 64
    executor = ReferenceLaunchEvidenceExecutor(
        root / "collected",
        family_id=family,
        release_id=release,
        config_hash=config_hash,
        provenance=provenance,
        fail_once=fail_once,
    )
    repo = ShadowLaunchWorkspaceRepository(SqliteStateStore(root / "launch.sqlite3"))
    store = FileSystemArtifactStore(root / "artifacts")
    controller = CampaignExecutionController(
        family_id=family,
        release_id=release,
        config_hash=config_hash,
        executor=executor,
        repository=repo,
        artifact_store=store,
        required_provenance=provenance,
    )
    return controller, executor, repo, store


def run_campaign_execution_qualification(
    policy_path: str | Path = "configs/launch/metrology_reference.yaml",
) -> CampaignExecutionQualificationReport:
    policy = load_launch_policy(policy_path)
    now = datetime(2026, 8, 19, 21, 0, tzinfo=timezone.utc)

    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        # Descriptor enforcement.
        base = ReferenceLaunchEvidenceExecutor(
            root / "bad", family_id=policy.family_id,
            release_id="ephi-0.19.1-campaign-qualification", config_hash="c" * 64,
        )

        class MissingStageAdapter(ReferenceLaunchEvidenceExecutor):
            def describe_adapter(self):
                stages = tuple(item for item in CampaignStage if item != CampaignStage.ENGINEER_SHADOW)
                return LaunchEvidenceAdapterDescriptor(
                    adapter_id="bad", adapter_version="1", supported_stages=stages,
                    idempotent_stages=stages, immutable_artifact_publishing=True,
                )

        bad = MissingStageAdapter(
            root / "bad2", family_id=base.family_id, release_id=base.release_id, config_hash=base.config_hash
        )
        try:
            CampaignExecutionController(
                family_id=base.family_id, release_id=base.release_id, config_hash=base.config_hash,
                executor=bad, repository=ShadowLaunchWorkspaceRepository(SqliteStateStore(root / "bad.sqlite3")),
                artifact_store=FileSystemArtifactStore(root / "bad-artifacts"),
                required_provenance=EvidenceProvenance.SIMULATED_INTERNAL,
            )
            adapter_descriptor_enforced = False
        except ValueError:
            adapter_descriptor_enforced = True

        # Retry/resume and immutable publication.
        controller, executor, repo, _ = _controller(
            root / "resume", provenance=EvidenceProvenance.SIMULATED_INTERNAL,
            fail_once=frozenset({CampaignStage.PRODUCTION_REPLAY_SCALE}),
        )
        try:
            controller.run(
                campaign_id="RESUME", target_state=CertificationState.OFFLINE_QUALIFIED, actor="engineer"
            )
        except RuntimeError:
            pass
        first = repo.campaign(policy.family_id, "RESUME")
        controller.run(
            campaign_id="RESUME", target_state=CertificationState.OFFLINE_QUALIFIED, actor="engineer"
        )
        final = repo.campaign(policy.family_id, "RESUME")
        retry_resume_preserves_completed_stages = bool(
            first and final
            and first.latest_attempt(CampaignStage.DATA_REALITY).status == CampaignStageStatus.PASSED
            and final.stage_passed(CampaignStage.PRODUCTION_REPLAY_SCALE)
            and executor.calls[CampaignStage.DATA_REALITY] == 1
            and executor.calls[CampaignStage.INTERNAL_GOLDEN_REPLAY] == 1
            and executor.calls[CampaignStage.PRODUCTION_REPLAY_SCALE] == 2
        )
        workspace = repo.load(policy.family_id)
        immutable_artifact_published = bool(workspace.evidence) and all(item.artifact_ref is not None for item in workspace.evidence)
        source_snapshot_lineage_persisted = (
            len(workspace.source_snapshots) == 1 and workspace.source_snapshots[0].snapshot_id == executor.snapshot_id
        )

        # Tamper with the immutable-store object and verify readiness fails.
        first_receipt = workspace.evidence[0]
        assert first_receipt.artifact_ref is not None
        Path(first_receipt.artifact_ref.locator).write_text("tampered", encoding="utf-8")
        try:
            tampered = controller.build_dossier(
                campaign_id="RESUME", current_state=CertificationState.RESEARCH,
                target_state=CertificationState.OFFLINE_QUALIFIED, policy=policy,
            )
            artifact_tamper_blocked = (
                not tampered.promotion_ready and any("checksum mismatch" in item for item in tampered.blockers)
            )
        except ValueError as exc:
            artifact_tamper_blocked = "hash mismatch" in str(exc).lower()

        # Source snapshot identity mismatch fails the stage.
        class WrongSnapshotAdapter(ReferenceLaunchEvidenceExecutor):
            def resolve_source_snapshot(self, snapshot_id: str):
                item = super().resolve_source_snapshot(snapshot_id)
                return item.model_copy(update={"config_hash": "d" * 64})

        wrong = WrongSnapshotAdapter(
            root / "wrong-snapshot", family_id=policy.family_id,
            release_id="ephi-0.19.1-campaign-qualification", config_hash="c" * 64,
            provenance=EvidenceProvenance.SIMULATED_INTERNAL,
        )
        try:
            CampaignExecutionController(
                family_id=policy.family_id, release_id=wrong.release_id, config_hash=wrong.config_hash,
                executor=wrong,
                repository=ShadowLaunchWorkspaceRepository(SqliteStateStore(root / "wrong.sqlite3")),
                artifact_store=FileSystemArtifactStore(root / "wrong-artifacts"),
                required_provenance=EvidenceProvenance.SIMULATED_INTERNAL,
            ).execute_stage(
                campaign_id="WRONG", target_state=CertificationState.OFFLINE_QUALIFIED,
                stage=CampaignStage.DATA_REALITY, actor="engineer",
            )
            source_snapshot_identity_enforced = False
        except ValueError:
            source_snapshot_identity_enforced = True

        # Existing evidence IDs cannot be reused with different content.
        internal_controller, _, internal_repo, _ = _controller(root / "internal", provenance=EvidenceProvenance.INTERNAL_MEASURED)
        internal_campaign = internal_controller.run(
            campaign_id="INTERNAL", target_state=CertificationState.OFFLINE_QUALIFIED, actor="collector"
        )
        internal_ws = internal_repo.load(policy.family_id)
        existing = internal_ws.evidence[0]
        try:
            internal_repo.attach_evidence(existing.model_copy(update={"metrics": {"changed": True}}), actor="other")
            evidence_identity_conflict_rejected = False
        except ValueError:
            evidence_identity_conflict_rejected = True

        # Simulated mechanism executes but remains non-promotable.
        sim_controller, _, _, _ = _controller(root / "sim", provenance=EvidenceProvenance.SIMULATED_INTERNAL)
        sim_campaign = sim_controller.run(
            campaign_id="SIM", target_state=CertificationState.OFFLINE_QUALIFIED, actor="reference"
        )
        sim_dossier = sim_controller.build_dossier(
            campaign_id=sim_campaign.campaign_id, current_state=CertificationState.RESEARCH,
            target_state=CertificationState.OFFLINE_QUALIFIED, policy=policy,
        )
        simulated_campaign_non_promotable = (
            not sim_dossier.promotion_ready and any("INTERNAL_MEASURED" in item for item in sim_dossier.blockers)
        )

        # Qualification-control handoff is restartable and does not approve itself.
        dossier = internal_controller.build_dossier(
            campaign_id=internal_campaign.campaign_id, current_state=CertificationState.RESEARCH,
            target_state=CertificationState.OFFLINE_QUALIFIED, policy=policy,
        )
        control_policy = FamilyOnboardingPolicy(
            family_id=policy.family_id,
            target_state=CertificationState.OFFLINE_QUALIFIED,
            required_capabilities=(),
            golden=GoldenCoveragePolicy(
                min_cases=1, min_high_confidence_cases=0,
                required_case_types=(), require_internal_history=True,
            ),
        )
        control = QualificationControlPlaneService(
            QualificationWorkspaceRepository(SqliteStateStore(root / "control.sqlite3")),
            policy_resolver=lambda _: control_policy,
        )
        plan = FamilyOnboardingPlan(
            family_id=policy.family_id,
            release_id=internal_controller.release_id,
            generated_at=now,
            current_state=CertificationState.RESEARCH,
            target_state=CertificationState.OFFLINE_QUALIFIED,
            required_capabilities=(), gaps=(), actions=(), blockers=(),
        )
        control.register_plan(plan, actor="admin", command_id="plan", at=now)
        intake = GoldenCaseIntake(
            intake_id="INTERNAL-G1", family=BenchmarkFamily.METROLOGY, case_type=BenchmarkCaseType.HEALTHY,
            source_locator="internal://golden/INTERNAL-G1", submitted_by="placeholder", submitted_at=now,
            scope_start=now - timedelta(days=2), scope_end=now - timedelta(days=1),
            label_confidence=BenchmarkLabelConfidence.CONFIRMED,
            evidence_refs=("internal://evidence/INTERNAL-G1",),
        )
        control.submit_golden(policy.family_id, intake, actor="submitter", command_id="submit", at=now)
        control.review_golden(
            policy.family_id, intake.intake_id, state=GoldenCurationState.ACCEPTED,
            actor="reviewer", command_id="review", at=now,
        )
        first_handoff = handoff_launch_dossier(
            dossier=dossier, control_plane=control, actor="admin", command_prefix="handoff"
        )
        second_handoff = handoff_launch_dossier(
            dossier=dossier, control_plane=control, actor="admin", command_prefix="handoff"
        )
        control_ws = control.workspace(policy.family_id)
        promotion_handoff_idempotent = (
            first_handoff.package_id == second_handoff.package_id
            and len(control_ws.promotion_records) == 1
            and bool(second_handoff.reused_commands)
        )
        promotion_handoff_no_auto_approval = len(control_ws.family_manifests) == 0

    checks = {
        "adapter_descriptor_enforced": adapter_descriptor_enforced,
        "retry_resume_preserves_completed_stages": retry_resume_preserves_completed_stages,
        "immutable_artifact_published": immutable_artifact_published,
        "artifact_tamper_blocked": artifact_tamper_blocked,
        "source_snapshot_lineage_persisted": source_snapshot_lineage_persisted,
        "source_snapshot_identity_enforced": source_snapshot_identity_enforced,
        "evidence_identity_conflict_rejected": evidence_identity_conflict_rejected,
        "promotion_handoff_idempotent": promotion_handoff_idempotent,
        "promotion_handoff_no_auto_approval": promotion_handoff_no_auto_approval,
        "simulated_campaign_non_promotable": simulated_campaign_non_promotable,
    }
    return CampaignExecutionQualificationReport(passed=all(checks.values()), **checks)
