"""Metrology shadow-launch campaign planning and evidence execution contracts."""
