from __future__ import annotations

from datetime import datetime, timezone

from ephi.adapters.base.artifact_store import ArtifactStore

from ephi.domain.launch import LaunchEvidenceReceipt, ProductionReplayManifest, ShadowLaunchDossier, SourceSnapshotLineage
from ephi.domain.operations import CertificationState
from ephi.launch.planner import build_metrology_shadow_launch_plan
from ephi.domain.launch import MetrologyShadowLaunchPolicy
from ephi.operations.certification import CapabilityCertification, CertificationService
from ephi.domain.data_reality import DataRealityReport


def build_shadow_launch_dossier(
    *,
    family_id: str,
    release_id: str,
    config_hash: str,
    current_state: CertificationState,
    target_state: CertificationState,
    policy: MetrologyShadowLaunchPolicy,
    evidence: tuple[LaunchEvidenceReceipt, ...],
    data_reality: DataRealityReport | None = None,
    replay_manifests: tuple[ProductionReplayManifest, ...] = (),
    source_snapshots: tuple[SourceSnapshotLineage, ...] = (),
    campaign_id: str | None = None,
    limitations: tuple[str, ...] = (),
    generated_at: datetime | None = None,
    capability_id: str = "behavioral-health",
    artifact_store: ArtifactStore | None = None,
) -> ShadowLaunchDossier:
    generated_at = generated_at or datetime.now(timezone.utc)
    plan = build_metrology_shadow_launch_plan(
        family_id=family_id,
        release_id=release_id,
        config_hash=config_hash,
        current_state=current_state,
        target_state=target_state,
        policy=policy,
        evidence=evidence,
        data_reality=data_reality,
        limitations=limitations,
        generated_at=generated_at,
        capability_id=capability_id,
        artifact_store=artifact_store,
    )
    blockers = list(plan.blockers)
    if target_state in {CertificationState.OFFLINE_QUALIFIED, CertificationState.SHADOW, CertificationState.SHADOW_QUALIFIED}:
        if not replay_manifests:
            blockers.append("production replay manifest missing")
        for manifest in replay_manifests:
            if manifest.family_id != family_id or manifest.release_id != release_id or manifest.config_hash != config_hash:
                blockers.append(f"replay manifest identity mismatch: {manifest.replay_id}")
    promotion_ready = not blockers
    if promotion_ready:
        shell = CapabilityCertification(capability_id=capability_id, state=current_state, gate_results=plan.gate_results)
        try:
            CertificationService().validate_transition(shell, target_state)
        except ValueError as exc:
            blockers.append(str(exc))
            promotion_ready = False
    return ShadowLaunchDossier(
        family_id=family_id,
        release_id=release_id,
        config_hash=config_hash,
        current_state=current_state,
        target_state=target_state,
        generated_at=generated_at,
        plan=plan,
        evidence=evidence,
        replay_manifests=replay_manifests,
        source_snapshots=source_snapshots,
        campaign_id=campaign_id,
        gate_results=plan.gate_results,
        blockers=tuple(blockers),
        limitations=limitations,
        promotion_ready=promotion_ready,
    )
