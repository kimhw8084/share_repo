from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from ephi.domain.launch import (
    CampaignStage,
    EvidenceDecision,
    EvidenceProvenance,
    LaunchEvidenceAdapterDescriptor,
    LaunchEvidenceKind,
    LaunchEvidenceReceipt,
    ProductionReplayManifest,
    ReplayPartition,
    SourceSnapshotLineage,
)
from ephi.launch.evidence import receipt_from_artifact


class ReferenceLaunchEvidenceExecutor:
    """Mechanism-only launch adapter used for portable dry-run qualification.

    It intentionally emits SIMULATED_INTERNAL provenance. Therefore the real launch
    policy will still block promotion even though execution, artifact publication,
    source-lineage, retry/resume and dossier assembly all function end-to-end.
    """

    def __init__(
        self,
        root: str | Path,
        *,
        family_id: str,
        release_id: str,
        config_hash: str,
        fail_once: frozenset[CampaignStage] = frozenset(),
        provenance: EvidenceProvenance = EvidenceProvenance.SIMULATED_INTERNAL,
    ) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.family_id = family_id
        self.release_id = release_id
        self.config_hash = config_hash
        self.fail_once = fail_once
        self.provenance = provenance
        self.calls: dict[CampaignStage, int] = {}
        self.now = datetime(2026, 8, 19, 20, 0, tzinfo=timezone.utc)
        self.snapshot_id = "REFERENCE-SNAPSHOT-001"

    def describe_adapter(self) -> LaunchEvidenceAdapterDescriptor:
        stages = tuple(CampaignStage)
        return LaunchEvidenceAdapterDescriptor(
            adapter_id="reference-simulated-launch-adapter",
            adapter_version="0.19.1",
            supported_stages=stages,
            idempotent_stages=stages,
            immutable_artifact_publishing=True,
            notes=("portable mechanism qualification only",),
        )

    def resolve_source_snapshot(self, snapshot_id: str) -> SourceSnapshotLineage:
        if snapshot_id != self.snapshot_id:
            raise KeyError(snapshot_id)
        return SourceSnapshotLineage(
            snapshot_id=self.snapshot_id,
            family_id=self.family_id,
            release_id=self.release_id,
            config_hash=self.config_hash,
            captured_at=self.now,
            as_of=self.now - timedelta(minutes=5),
            scope="REFERENCE_MECHANISM_ONLY",
            dataset_revisions={"executions": "ref-r1", "metrology": "ref-r1"},
            notes=("not internal manufacturing evidence",),
        )

    def _begin(self, stage: CampaignStage) -> None:
        count = self.calls.get(stage, 0) + 1
        self.calls[stage] = count
        if stage in self.fail_once and count == 1:
            raise RuntimeError(f"reference injected first-attempt failure: {stage.value}")

    def _artifact(self, stage: CampaignStage, payload: dict[str, object]) -> Path:
        path = self.root / f"{stage.value.lower()}.json"
        path.write_text(json.dumps(payload, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        return path

    def _receipt(
        self,
        stage: CampaignStage,
        kind: LaunchEvidenceKind,
        payload: dict[str, object],
        *,
        source_snapshot: bool = False,
    ) -> LaunchEvidenceReceipt:
        self._begin(stage)
        path = self._artifact(stage, payload)
        return receipt_from_artifact(
            evidence_id=f"REF-{stage.value}",
            family_id=self.family_id,
            release_id=self.release_id,
            config_hash=self.config_hash,
            kind=kind,
            provenance=self.provenance,
            decision=EvidenceDecision.PASS,
            artifact=path,
            observed_at=self.now,
            validator="reference-mechanism-validator",
            source_snapshot_id=self.snapshot_id if source_snapshot else None,
            limitations=("portable simulated evidence; cannot qualify internal promotion",),
        )

    def collect_data_reality(self) -> LaunchEvidenceReceipt:
        return self._receipt(
            CampaignStage.DATA_REALITY,
            LaunchEvidenceKind.DATA_REALITY,
            {
                "generated_at": self.now.isoformat(),
                "config_hash": self.config_hash,
                "capabilities": [
                    {"capability": "PROCESS_HISTORY", "state": "QUALIFIED", "supporting_datasets": [], "supporting_joins": [], "reasons": []},
                    {"capability": "METROLOGY", "state": "QUALIFIED", "supporting_datasets": [], "supporting_joins": [], "reasons": []},
                    {"capability": "REFERENCE_WAFER", "state": "QUALIFIED", "supporting_datasets": [], "supporting_joins": [], "reasons": []},
                ],
                "qualification": "REFERENCE_MECHANISM_ONLY",
            },
            source_snapshot=True,
        )

    def collect_internal_golden_replay(self) -> LaunchEvidenceReceipt:
        return self._receipt(
            CampaignStage.INTERNAL_GOLDEN_REPLAY,
            LaunchEvidenceKind.INTERNAL_GOLDEN_REPLAY,
            {"passed": True, "cases": 9, "source": "SIMULATED_INTERNAL"},
            source_snapshot=True,
        )

    def collect_production_replay_scale(self) -> tuple[LaunchEvidenceReceipt, ProductionReplayManifest]:
        receipt = self._receipt(
            CampaignStage.PRODUCTION_REPLAY_SCALE,
            LaunchEvidenceKind.PRODUCTION_REPLAY_SCALE,
            {"passed": True, "rows": 1_000_000, "environment": "REFERENCE_MECHANISM_ONLY"},
            source_snapshot=True,
        )
        replay = ProductionReplayManifest(
            replay_id="REFERENCE-REPLAY-001",
            family_id=self.family_id,
            release_id=self.release_id,
            config_hash=self.config_hash,
            replay_as_of=self.now,
            strict_available_at=True,
            source_snapshot_id=self.snapshot_id,
            partitions=(ReplayPartition(
                partition_id="P1",
                start_time=self.now - timedelta(days=30),
                end_time=self.now - timedelta(days=1),
                scope="reference-metrology",
                estimated_rows=1_000_000,
            ),),
            expected_total_rows=1_000_000,
            notes=("portable mechanism qualification only",),
        )
        return receipt, replay

    def collect_reliability_dr_drill(self) -> LaunchEvidenceReceipt:
        return self._receipt(
            CampaignStage.RELIABILITY_DR_DRILL,
            LaunchEvidenceKind.RELIABILITY_DR_DRILL,
            {"passed": True, "rpo_seconds": 0, "rto_seconds": 1, "source": "SIMULATED_INTERNAL"},
        )

    def collect_shadow_runtime(self) -> LaunchEvidenceReceipt:
        return self._receipt(
            CampaignStage.SHADOW_RUNTIME,
            LaunchEvidenceKind.SHADOW_RUNTIME,
            {"passed": True, "hours": 24, "source": "SIMULATED_INTERNAL"},
        )

    def collect_engineer_shadow(self) -> LaunchEvidenceReceipt:
        return self._receipt(
            CampaignStage.ENGINEER_SHADOW,
            LaunchEvidenceKind.ENGINEER_SHADOW,
            {"passed": True, "reviews": 20, "source": "SIMULATED_INTERNAL"},
        )
