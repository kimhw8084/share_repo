from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory

from pydantic import BaseModel, ConfigDict

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.launch import (
    EvidenceDecision,
    EvidenceProvenance,
    LaunchEvidenceKind,
    ReplayPartition,
)
from ephi.domain.operations import CertificationState
from ephi.launch.dossier import build_shadow_launch_dossier
from ephi.launch.evidence import receipt_from_artifact
from ephi.launch.policy import load_launch_policy
from ephi.launch.registry import ShadowLaunchWorkspaceRepository
from ephi.launch.replay import build_replay_manifest


class LaunchQualificationReport(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    passed: bool
    portable_evidence_blocked: bool
    simulated_internal_blocked: bool
    internal_offline_ready: bool
    shadow_requires_dr: bool
    internal_shadow_ready: bool
    shadow_qualified_requires_live_and_engineer: bool
    artifact_mutation_blocked: bool
    expired_evidence_blocked: bool
    workspace_identity_enforced: bool
    duplicate_evidence_conflict_rejected: bool
    strict_knowledge_time_replay: bool


def run_launch_qualification(policy_path: str | Path = "configs/launch/metrology_reference.yaml") -> LaunchQualificationReport:
    policy = load_launch_policy(policy_path)
    now = datetime(2026, 8, 19, 19, 0, tzinfo=timezone.utc)
    family_id = policy.family_id
    release_id = "ephi-0.19.1-launch-qualification"
    config_hash = "c" * 64

    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        artifacts = {}
        for kind in LaunchEvidenceKind:
            path = root / f"{kind.value.lower()}.json"
            path.write_text(json.dumps({"kind": kind.value, "passed": True}, sort_keys=True), encoding="utf-8")
            artifacts[kind] = path

        replay = build_replay_manifest(
            replay_id="REPLAY-1", family_id=family_id, release_id=release_id, config_hash=config_hash,
            replay_as_of=now, source_snapshot_id="SNAP-1",
            partitions=(ReplayPartition(
                partition_id="P1", start_time=now - timedelta(days=30), end_time=now - timedelta(days=1),
                scope="metrology-reference", estimated_rows=1_000_000,
            ),), expected_total_rows=1_000_000,
        )
        strict_knowledge_time_replay = replay.strict_available_at

        def receipts(provenance: EvidenceProvenance, *, include_dr=True, include_live=True):
            kinds = [
                LaunchEvidenceKind.DATA_REALITY,
                LaunchEvidenceKind.INTERNAL_GOLDEN_REPLAY,
                LaunchEvidenceKind.PRODUCTION_REPLAY_SCALE,
            ]
            if include_dr:
                kinds.append(LaunchEvidenceKind.RELIABILITY_DR_DRILL)
            if include_live:
                kinds += [LaunchEvidenceKind.SHADOW_RUNTIME, LaunchEvidenceKind.ENGINEER_SHADOW]
            return tuple(receipt_from_artifact(
                evidence_id=f"E-{kind.value}-{provenance.value}", family_id=family_id,
                release_id=release_id, config_hash=config_hash, kind=kind, provenance=provenance,
                decision=EvidenceDecision.PASS, artifact=artifacts[kind], observed_at=now - timedelta(minutes=1),
                validator="qualification", source_snapshot_id="SNAP-1",
            ) for kind in kinds)

        portable = build_shadow_launch_dossier(
            family_id=family_id, release_id=release_id, config_hash=config_hash,
            current_state=CertificationState.RESEARCH, target_state=CertificationState.OFFLINE_QUALIFIED,
            policy=policy, evidence=receipts(EvidenceProvenance.PORTABLE_REFERENCE, include_dr=False, include_live=False),
            replay_manifests=(replay,), generated_at=now,
        )
        portable_evidence_blocked = not portable.promotion_ready
        simulated = build_shadow_launch_dossier(
            family_id=family_id, release_id=release_id, config_hash=config_hash,
            current_state=CertificationState.RESEARCH, target_state=CertificationState.OFFLINE_QUALIFIED,
            policy=policy, evidence=receipts(EvidenceProvenance.SIMULATED_INTERNAL, include_dr=False, include_live=False),
            replay_manifests=(replay,), generated_at=now,
        )
        simulated_internal_blocked = not simulated.promotion_ready
        internal = receipts(EvidenceProvenance.INTERNAL_MEASURED)
        offline = build_shadow_launch_dossier(
            family_id=family_id, release_id=release_id, config_hash=config_hash,
            current_state=CertificationState.RESEARCH, target_state=CertificationState.OFFLINE_QUALIFIED,
            policy=policy, evidence=internal, replay_manifests=(replay,), generated_at=now,
        )
        internal_offline_ready = offline.promotion_ready
        no_dr = build_shadow_launch_dossier(
            family_id=family_id, release_id=release_id, config_hash=config_hash,
            current_state=CertificationState.OFFLINE_QUALIFIED, target_state=CertificationState.SHADOW,
            policy=policy, evidence=receipts(EvidenceProvenance.INTERNAL_MEASURED, include_dr=False, include_live=False),
            replay_manifests=(replay,), generated_at=now,
        )
        shadow_requires_dr = not no_dr.promotion_ready and any("RELIABILITY" in b for b in no_dr.blockers)
        shadow = build_shadow_launch_dossier(
            family_id=family_id, release_id=release_id, config_hash=config_hash,
            current_state=CertificationState.OFFLINE_QUALIFIED, target_state=CertificationState.SHADOW,
            policy=policy, evidence=internal, replay_manifests=(replay,), generated_at=now,
        )
        internal_shadow_ready = shadow.promotion_ready
        shadow_qualified_missing = build_shadow_launch_dossier(
            family_id=family_id, release_id=release_id, config_hash=config_hash,
            current_state=CertificationState.SHADOW, target_state=CertificationState.SHADOW_QUALIFIED,
            policy=policy, evidence=receipts(EvidenceProvenance.INTERNAL_MEASURED, include_dr=True, include_live=False),
            replay_manifests=(replay,), generated_at=now,
        )
        shadow_qualified_requires_live_and_engineer = not shadow_qualified_missing.promotion_ready

        mutable_receipt = receipt_from_artifact(
            evidence_id="E-MUT", family_id=family_id, release_id=release_id, config_hash=config_hash,
            kind=LaunchEvidenceKind.DATA_REALITY, provenance=EvidenceProvenance.INTERNAL_MEASURED,
            decision=EvidenceDecision.PASS, artifact=artifacts[LaunchEvidenceKind.DATA_REALITY], observed_at=now - timedelta(minutes=1),
        )
        artifacts[LaunchEvidenceKind.DATA_REALITY].write_text('{"mutated": true}', encoding="utf-8")
        other = tuple(x for x in internal if x.kind != LaunchEvidenceKind.DATA_REALITY)
        mutated = build_shadow_launch_dossier(
            family_id=family_id, release_id=release_id, config_hash=config_hash,
            current_state=CertificationState.RESEARCH, target_state=CertificationState.OFFLINE_QUALIFIED,
            policy=policy, evidence=(mutable_receipt,) + other, replay_manifests=(replay,), generated_at=now,
        )
        artifact_mutation_blocked = not mutated.promotion_ready and any("checksum" in b for b in mutated.blockers)
        # restore data reality artifact for remaining tests
        artifacts[LaunchEvidenceKind.DATA_REALITY].write_text(json.dumps({"kind": "DATA_REALITY", "passed": True}, sort_keys=True), encoding="utf-8")

        expired = receipt_from_artifact(
            evidence_id="E-EXP", family_id=family_id, release_id=release_id, config_hash=config_hash,
            kind=LaunchEvidenceKind.DATA_REALITY, provenance=EvidenceProvenance.INTERNAL_MEASURED,
            decision=EvidenceDecision.PASS, artifact=artifacts[LaunchEvidenceKind.DATA_REALITY],
            observed_at=now - timedelta(days=2), valid_until=now - timedelta(days=1),
        )
        expired_plan = build_shadow_launch_dossier(
            family_id=family_id, release_id=release_id, config_hash=config_hash,
            current_state=CertificationState.RESEARCH, target_state=CertificationState.OFFLINE_QUALIFIED,
            policy=policy, evidence=(expired,) + other, replay_manifests=(replay,), generated_at=now,
        )
        expired_evidence_blocked = not expired_plan.promotion_ready and any("expired" in b for b in expired_plan.blockers)

        repo = ShadowLaunchWorkspaceRepository(SqliteStateStore(root / "launch.sqlite3"))
        first = internal[0]
        repo.attach_evidence(first, actor="engineer")
        try:
            changed = first.model_copy(update={"artifact_sha256": "f" * 64})
            repo.attach_evidence(changed, actor="engineer")
            duplicate_evidence_conflict_rejected = False
        except ValueError:
            duplicate_evidence_conflict_rejected = True
        try:
            mismatch = internal[1].model_copy(update={"release_id": "OTHER"})
            repo.attach_evidence(mismatch, actor="engineer")
            workspace_identity_enforced = False
        except ValueError:
            workspace_identity_enforced = True

    checks = {
        "portable_evidence_blocked": portable_evidence_blocked,
        "simulated_internal_blocked": simulated_internal_blocked,
        "internal_offline_ready": internal_offline_ready,
        "shadow_requires_dr": shadow_requires_dr,
        "internal_shadow_ready": internal_shadow_ready,
        "shadow_qualified_requires_live_and_engineer": shadow_qualified_requires_live_and_engineer,
        "artifact_mutation_blocked": artifact_mutation_blocked,
        "expired_evidence_blocked": expired_evidence_blocked,
        "workspace_identity_enforced": workspace_identity_enforced,
        "duplicate_evidence_conflict_rejected": duplicate_evidence_conflict_rejected,
        "strict_knowledge_time_replay": strict_knowledge_time_replay,
    }
    return LaunchQualificationReport(passed=all(checks.values()), **checks)
