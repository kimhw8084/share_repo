from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from uuid import uuid4

from ephi.adapters.base.state_store import StateStore
from ephi.domain.launch import (
    CampaignExecutionRecord,
    LaunchAuditEvent,
    LaunchEvidenceReceipt,
    ProductionReplayManifest,
    ShadowLaunchWorkspace,
    SourceSnapshotLineage,
)
from ephi.errors import StateConflictError


class ShadowLaunchWorkspaceRepository:
    def __init__(self, state_store: StateStore, *, max_conflict_retries: int = 64) -> None:
        self.state_store = state_store
        self.max_conflict_retries = max_conflict_retries

    @staticmethod
    def key(family_id: str) -> str:
        family_id = family_id.strip()
        if not family_id:
            raise ValueError("family_id cannot be blank")
        return f"launch:metrology-shadow:{family_id}:v1"

    def load(self, family_id: str) -> ShadowLaunchWorkspace:
        record = self.state_store.get(self.key(family_id))
        return ShadowLaunchWorkspace(family_id=family_id) if record is None else ShadowLaunchWorkspace.model_validate_json(record.value)

    def _mutate(self, family_id: str, fn) -> ShadowLaunchWorkspace:
        key = self.key(family_id)
        last: Exception | None = None
        for attempt in range(self.max_conflict_retries):
            record = self.state_store.get(key)
            current = ShadowLaunchWorkspace(family_id=family_id) if record is None else ShadowLaunchWorkspace.model_validate_json(record.value)
            updated = fn(current).model_copy(update={"updated_at": datetime.now(timezone.utc)})
            payload = json.dumps(updated.model_dump(mode="json"), sort_keys=True, separators=(",", ":")).encode()
            try:
                self.state_store.compare_and_set(key, expected_version=None if record is None else record.version, value=payload)
                return updated
            except StateConflictError as exc:
                last = exc
                time.sleep(min(0.0005 * (2 ** min(attempt, 6)), 0.02))
        raise StateConflictError(f"launch workspace retry budget exhausted for {family_id}") from last

    @staticmethod
    def _identity_guard(workspace: ShadowLaunchWorkspace, *, release_id: str, config_hash: str) -> None:
        if workspace.release_id is not None and workspace.release_id != release_id:
            raise ValueError("launch workspace release identity mismatch")
        if workspace.config_hash is not None and workspace.config_hash != config_hash:
            raise ValueError("launch workspace config identity mismatch")

    def attach_evidence(self, receipt: LaunchEvidenceReceipt, *, actor: str) -> ShadowLaunchWorkspace:
        def mutate(ws: ShadowLaunchWorkspace) -> ShadowLaunchWorkspace:
            self._identity_guard(ws, release_id=receipt.release_id, config_hash=receipt.config_hash)
            existing = next((x for x in ws.evidence if x.evidence_id == receipt.evidence_id), None)
            if existing is not None:
                if existing != receipt:
                    raise ValueError(f"evidence_id {receipt.evidence_id} already exists with different content")
                return ws
            audit = LaunchAuditEvent(
                event_id=f"LA-{uuid4().hex}", family_id=receipt.family_id, action="EVIDENCE_ATTACHED",
                actor=actor, at=datetime.now(timezone.utc), entity_id=receipt.evidence_id,
                detail=f"{receipt.kind.value}:{receipt.decision.value}:{receipt.provenance.value}",
            )
            return ws.model_copy(update={
                "release_id": receipt.release_id,
                "config_hash": receipt.config_hash,
                "evidence": ws.evidence + (receipt,),
                "audit": ws.audit + (audit,),
            })
        return self._mutate(receipt.family_id, mutate)

    def attach_replay_manifest(self, manifest: ProductionReplayManifest, *, actor: str) -> ShadowLaunchWorkspace:
        def mutate(ws: ShadowLaunchWorkspace) -> ShadowLaunchWorkspace:
            self._identity_guard(ws, release_id=manifest.release_id, config_hash=manifest.config_hash)
            existing = next((x for x in ws.replay_manifests if x.replay_id == manifest.replay_id), None)
            if existing is not None:
                if existing != manifest:
                    raise ValueError(f"replay_id {manifest.replay_id} already exists with different content")
                return ws
            audit = LaunchAuditEvent(
                event_id=f"LA-{uuid4().hex}", family_id=manifest.family_id, action="REPLAY_MANIFEST_ATTACHED",
                actor=actor, at=datetime.now(timezone.utc), entity_id=manifest.replay_id,
            )
            return ws.model_copy(update={
                "release_id": manifest.release_id,
                "config_hash": manifest.config_hash,
                "replay_manifests": ws.replay_manifests + (manifest,),
                "audit": ws.audit + (audit,),
            })
        return self._mutate(manifest.family_id, mutate)

    def attach_source_snapshot(self, snapshot: SourceSnapshotLineage, *, actor: str) -> ShadowLaunchWorkspace:
        def mutate(ws: ShadowLaunchWorkspace) -> ShadowLaunchWorkspace:
            self._identity_guard(ws, release_id=snapshot.release_id, config_hash=snapshot.config_hash)
            existing = next((x for x in ws.source_snapshots if x.snapshot_id == snapshot.snapshot_id), None)
            if existing is not None:
                if existing != snapshot:
                    raise ValueError(f"snapshot_id {snapshot.snapshot_id} already exists with different content")
                return ws
            if snapshot.parent_snapshot_id is not None and not any(
                item.snapshot_id == snapshot.parent_snapshot_id for item in ws.source_snapshots
            ):
                raise ValueError(f"unknown parent snapshot: {snapshot.parent_snapshot_id}")
            audit = LaunchAuditEvent(
                event_id=f"LA-{uuid4().hex}", family_id=snapshot.family_id, action="SOURCE_SNAPSHOT_ATTACHED",
                actor=actor, at=datetime.now(timezone.utc), entity_id=snapshot.snapshot_id,
                detail=snapshot.scope,
            )
            return ws.model_copy(update={
                "release_id": snapshot.release_id,
                "config_hash": snapshot.config_hash,
                "source_snapshots": ws.source_snapshots + (snapshot,),
                "audit": ws.audit + (audit,),
            })
        return self._mutate(snapshot.family_id, mutate)

    def upsert_campaign(self, campaign: CampaignExecutionRecord, *, actor: str, action: str = "CAMPAIGN_UPDATED") -> ShadowLaunchWorkspace:
        def mutate(ws: ShadowLaunchWorkspace) -> ShadowLaunchWorkspace:
            self._identity_guard(ws, release_id=campaign.release_id, config_hash=campaign.config_hash)
            existing = next((x for x in ws.campaigns if x.campaign_id == campaign.campaign_id), None)
            campaigns = tuple(x for x in ws.campaigns if x.campaign_id != campaign.campaign_id) + (campaign,)
            detail = "created" if existing is None else "updated"
            audit = LaunchAuditEvent(
                event_id=f"LA-{uuid4().hex}", family_id=campaign.family_id, action=action,
                actor=actor, at=datetime.now(timezone.utc), entity_id=campaign.campaign_id,
                detail=detail,
            )
            return ws.model_copy(update={
                "release_id": campaign.release_id,
                "config_hash": campaign.config_hash,
                "campaigns": campaigns,
                "audit": ws.audit + (audit,),
            })
        return self._mutate(campaign.family_id, mutate)

    def campaign(self, family_id: str, campaign_id: str) -> CampaignExecutionRecord | None:
        return next((x for x in self.load(family_id).campaigns if x.campaign_id == campaign_id), None)
