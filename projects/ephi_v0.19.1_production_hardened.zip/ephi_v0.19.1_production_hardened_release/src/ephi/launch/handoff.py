from __future__ import annotations

import hashlib
from dataclasses import dataclass

from ephi.domain.launch import ShadowLaunchDossier
from ephi.domain.qualification_control import PromotionEvidenceRecord, QualificationAction
from ephi.onboarding.control_plane import QualificationControlPlaneService


def _command(prefix: str, action: str, suffix: str) -> str:
    digest = hashlib.sha256(f"{prefix}|{action}|{suffix}".encode("utf-8")).hexdigest()[:16]
    return f"launch-{action.lower()}-{digest}"


@dataclass(frozen=True, slots=True)
class LaunchHandoffResult:
    family_id: str
    package_id: str
    recorded_planes: tuple[str, ...]
    reused_commands: tuple[str, ...]


def handoff_launch_dossier(
    *,
    dossier: ShadowLaunchDossier,
    control_plane: QualificationControlPlaneService,
    actor: str,
    capability_id: str = "behavioral-health",
    command_prefix: str | None = None,
) -> LaunchHandoffResult:
    """Record launch gates and create a promotion package in the qualification control plane.

    This does *not* approve promotion. Approval remains the existing admin-only control-plane
    action. Deterministic command IDs make the handoff restartable without duplicating gate
    records or promotion packages.
    """
    if not dossier.promotion_ready:
        raise ValueError("BLOCKED launch dossier cannot be handed off for promotion")
    workspace = control_plane.workspace(dossier.family_id)
    if workspace.onboarding_plan is None:
        raise ValueError("qualification control plane requires a registered onboarding plan")
    plan = workspace.onboarding_plan
    if plan.release_id != dossier.release_id:
        raise ValueError("launch dossier release does not match onboarding plan")
    if plan.target_state != dossier.target_state:
        raise ValueError("launch dossier target state does not match onboarding plan")

    prefix = command_prefix or dossier.campaign_id or f"{dossier.release_id}:{dossier.target_state.value}"
    reused: list[str] = []
    recorded: list[str] = []
    for gate in dossier.gate_results:
        command_id = _command(prefix, "gate", gate.plane.value)
        current = control_plane.workspace(dossier.family_id)
        receipt = next((item for item in current.command_receipts if item.command_id == command_id), None)
        if receipt is not None:
            if receipt.action != QualificationAction.GATE_RECORDED:
                raise ValueError(f"command_id collision: {command_id}")
            reused.append(command_id)
            recorded.append(gate.plane.value)
            continue
        control_plane.record_gate(
            dossier.family_id,
            release_id=dossier.release_id,
            capability_id=capability_id,
            result=gate,
            actor=actor,
            command_id=command_id,
        )
        recorded.append(gate.plane.value)

    promotion_command = _command(prefix, "promotion", dossier.target_state.value)
    current = control_plane.workspace(dossier.family_id)
    prior = next((item for item in current.command_receipts if item.command_id == promotion_command), None)
    record: PromotionEvidenceRecord
    if prior is not None:
        if prior.action != QualificationAction.PROMOTION_GENERATED:
            raise ValueError(f"command_id collision: {promotion_command}")
        record = next((item for item in current.promotion_records if item.package_id == prior.result_id), None)
        if record is None:
            raise RuntimeError("promotion command receipt exists without promotion record")
        reused.append(promotion_command)
    else:
        record = control_plane.generate_promotion(
            dossier.family_id,
            capability_id=capability_id,
            target_state=dossier.target_state,
            actor=actor,
            command_id=promotion_command,
            evidence_artifacts=tuple(sorted({item.artifact for item in dossier.evidence})),
        )
    return LaunchHandoffResult(
        family_id=dossier.family_id,
        package_id=record.package_id,
        recorded_planes=tuple(sorted(set(recorded))),
        reused_commands=tuple(reused),
    )
