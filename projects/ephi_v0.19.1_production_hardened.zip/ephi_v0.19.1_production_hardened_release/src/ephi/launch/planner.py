from __future__ import annotations

from datetime import datetime, timezone

from ephi.adapters.base.artifact_store import ArtifactStore

from ephi.domain.launch import (
    EvidenceDecision,
    EvidenceProvenance,
    LaunchEvidenceReceipt,
    LaunchRequirementAssessment,
    CapabilityLaunchAssessment, MetrologyShadowLaunchPlan,
    MetrologyShadowLaunchPolicy,
    RequirementStatus,
)
from ephi.domain.operations import CertificationState, GateResult
from ephi.domain.data_reality import DataRealityReport, QualificationState
from ephi.operations.certification import CertificationPolicy
from ephi.launch.evidence import receipt_artifact_matches


def _latest_receipt(
    evidence: tuple[LaunchEvidenceReceipt, ...],
    *,
    kind,
    family_id: str,
    release_id: str,
    config_hash: str,
    as_of: datetime,
) -> LaunchEvidenceReceipt | None:
    candidates = [
        item for item in evidence
        if item.kind == kind
        and item.family_id == family_id
        and item.release_id == release_id
        and item.config_hash == config_hash
        and item.observed_at <= as_of
    ]
    return max(candidates, key=lambda item: (item.observed_at, item.evidence_id)) if candidates else None


def build_metrology_shadow_launch_plan(
    *,
    family_id: str,
    release_id: str,
    config_hash: str,
    current_state: CertificationState,
    target_state: CertificationState,
    policy: MetrologyShadowLaunchPolicy,
    evidence: tuple[LaunchEvidenceReceipt, ...] = (),
    data_reality: DataRealityReport | None = None,
    limitations: tuple[str, ...] = (),
    generated_at: datetime | None = None,
    capability_id: str = "behavioral-health",
    artifact_store: ArtifactStore | None = None,
) -> MetrologyShadowLaunchPlan:
    generated_at = generated_at or datetime.now(timezone.utc)
    blockers: list[str] = []
    assessments: list[LaunchRequirementAssessment] = []
    gates: list[GateResult] = []
    capability_assessments: list[CapabilityLaunchAssessment] = []
    if data_reality is not None and data_reality.config_hash != config_hash:
        blockers.append(
            f"Data Reality config hash mismatch: {data_reality.config_hash!r} != {config_hash!r}"
        )

    for required, capabilities in ((True, policy.required_capabilities), (False, policy.optional_capabilities)):
        for capability in capabilities:
            assessment = data_reality.capability(capability) if data_reality is not None else None
            state = assessment.state.value if assessment is not None else "NOT_EVALUATED"
            reasons = assessment.reasons if assessment is not None else ("Data Reality report not supplied to launch plan",)
            capability_assessments.append(CapabilityLaunchAssessment(
                capability=capability, required=required, state=state, reasons=tuple(reasons),
            ))
            if required and assessment is not None and assessment.state != QualificationState.QUALIFIED:
                blockers.append(f"required capability {capability.value} is {assessment.state.value}")

    for requirement in policy.requirements:
        if target_state not in requirement.required_for:
            continue
        receipt = _latest_receipt(
            evidence,
            kind=requirement.kind,
            family_id=family_id,
            release_id=release_id,
            config_hash=config_hash,
            as_of=generated_at,
        )
        if receipt is None:
            msg = f"missing evidence: {requirement.kind.value}"
            blockers.append(msg)
            assessments.append(LaunchRequirementAssessment(kind=requirement.kind, status=RequirementStatus.BLOCKED, blocker=msg))
            continue
        if not receipt_artifact_matches(receipt, artifact_store):
            msg = f"evidence artifact missing or checksum mismatch: {requirement.kind.value}"
            blockers.append(msg)
            assessments.append(LaunchRequirementAssessment(kind=requirement.kind, status=RequirementStatus.FAILED, evidence_id=receipt.evidence_id, blocker=msg))
            continue
        if not receipt.valid_as_of(generated_at):
            msg = f"expired evidence: {requirement.kind.value}"
            blockers.append(msg)
            assessments.append(LaunchRequirementAssessment(kind=requirement.kind, status=RequirementStatus.EXPIRED, evidence_id=receipt.evidence_id, blocker=msg))
            continue
        if requirement.require_internal_measured and receipt.provenance != EvidenceProvenance.INTERNAL_MEASURED:
            msg = f"{requirement.kind.value} requires INTERNAL_MEASURED evidence"
            blockers.append(msg)
            assessments.append(LaunchRequirementAssessment(kind=requirement.kind, status=RequirementStatus.BLOCKED, evidence_id=receipt.evidence_id, blocker=msg))
            continue
        if receipt.decision != EvidenceDecision.PASS:
            msg = f"evidence did not pass: {requirement.kind.value}={receipt.decision.value}"
            blockers.append(msg)
            assessments.append(LaunchRequirementAssessment(kind=requirement.kind, status=RequirementStatus.FAILED, evidence_id=receipt.evidence_id, blocker=msg))
            if requirement.plane is not None:
                gates.append(GateResult(plane=requirement.plane, passed=False, artifact=receipt.artifact, summary=msg))
            continue
        assessments.append(LaunchRequirementAssessment(kind=requirement.kind, status=RequirementStatus.SATISFIED, evidence_id=receipt.evidence_id))
        if requirement.plane is not None:
            gates.append(GateResult(
                plane=requirement.plane,
                passed=True,
                artifact=receipt.artifact,
                summary=f"{requirement.kind.value} passed ({receipt.provenance.value})",
            ))

    # The launch planner deliberately delegates certification sufficiency to the existing policy.
    passed = frozenset(item.plane for item in gates if item.passed)
    missing_planes = CertificationPolicy.reference().required_planes(target_state, capability_id) - passed
    for plane in sorted(missing_planes, key=lambda item: item.value):
        msg = f"certification plane not satisfied by launch evidence: {plane.value}"
        if msg not in blockers:
            blockers.append(msg)

    return MetrologyShadowLaunchPlan(
        family_id=family_id,
        release_id=release_id,
        config_hash=config_hash,
        current_state=current_state,
        target_state=target_state,
        generated_at=generated_at,
        required_capabilities=policy.required_capabilities,
        optional_capabilities=policy.optional_capabilities,
        capability_assessments=tuple(capability_assessments),
        requirements=tuple(item for item in policy.requirements if target_state in item.required_for),
        assessments=tuple(assessments),
        gate_results=tuple(gates),
        blockers=tuple(blockers),
        limitations=limitations,
    )
