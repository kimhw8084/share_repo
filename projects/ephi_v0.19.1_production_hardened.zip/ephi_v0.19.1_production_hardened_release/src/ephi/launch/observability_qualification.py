from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory

from pydantic import BaseModel, ConfigDict

from ephi.adapters.local.filesystem_artifact_store import FileSystemArtifactStore
from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.campaign_observability import EvidenceComparisonState, ReconciliationStatus
from ephi.domain.launch import CampaignStage, EvidenceProvenance, SourceSnapshotLineage
from ephi.domain.operations import CertificationState
from ephi.launch.execution import CampaignExecutionController
from ephi.launch.observability import CampaignObservabilityService
from ephi.launch.reference_executor import ReferenceLaunchEvidenceExecutor
from ephi.launch.registry import ShadowLaunchWorkspaceRepository


class CampaignObservabilityQualificationReport(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    passed: bool
    campaign_scoping_passed: bool
    artifact_reverification_passed: bool
    cross_stage_lineage_passed: bool
    retry_vs_evidence_reconciliation_passed: bool
    failure_event_taxonomy_passed: bool
    completed_campaign_slo_stable: bool
    immutable_retention_passed: bool
    deterministic_export_passed: bool
    immutable_export_publication_passed: bool


def _stack(root: Path, *, fail_once=frozenset()):
    family = "METROLOGY_REFERENCE"
    release = "ephi-0.19.1-observability-qualification"
    config_hash = "c" * 64
    executor = ReferenceLaunchEvidenceExecutor(
        root / "collected",
        family_id=family,
        release_id=release,
        config_hash=config_hash,
        provenance=EvidenceProvenance.INTERNAL_MEASURED,
        fail_once=fail_once,
    )
    repo = ShadowLaunchWorkspaceRepository(SqliteStateStore(root / "state.sqlite3"))
    artifacts = FileSystemArtifactStore(root / "artifacts")
    controller = CampaignExecutionController(
        family_id=family,
        release_id=release,
        config_hash=config_hash,
        executor=executor,
        repository=repo,
        artifact_store=artifacts,
        required_provenance=EvidenceProvenance.INTERNAL_MEASURED,
    )
    service = CampaignObservabilityService(repo, artifact_store=artifacts)
    return controller, repo, artifacts, service


def run_campaign_observability_qualification() -> CampaignObservabilityQualificationReport:
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        controller, repo, artifacts, service = _stack(
            root / "main", fail_once=frozenset({CampaignStage.PRODUCTION_REPLAY_SCALE})
        )
        try:
            controller.run(
                campaign_id="RETRY",
                target_state=CertificationState.OFFLINE_QUALIFIED,
                actor="engineer",
            )
        except RuntimeError:
            pass
        controller.run(
            campaign_id="RETRY",
            target_state=CertificationState.OFFLINE_QUALIFIED,
            actor="engineer",
        )
        controller.run(
            campaign_id="CLEAN",
            target_state=CertificationState.OFFLINE_QUALIFIED,
            actor="engineer",
        )
        now = datetime.now(timezone.utc)

        retry_recon = service.reconciliation("METROLOGY_REFERENCE", "RETRY")
        clean_recon = service.reconciliation("METROLOGY_REFERENCE", "CLEAN")
        comparison = service.compare("METROLOGY_REFERENCE", "CLEAN", "RETRY")
        retry_vs_evidence_reconciliation_passed = bool(
            retry_recon.status == ReconciliationStatus.CONSISTENT
            and clean_recon.status == ReconciliationStatus.CONSISTENT
            and retry_recon.evidence_fingerprint.evidence_sha256
            == clean_recon.evidence_fingerprint.evidence_sha256
            and retry_recon.evidence_fingerprint.execution_sha256
            != clean_recon.evidence_fingerprint.execution_sha256
            and comparison.state == EvidenceComparisonState.EXECUTION_CHANGED
        )

        workspace = repo.load("METROLOGY_REFERENCE")
        extra = workspace.evidence[0].model_copy(update={"evidence_id": "UNRELATED"})
        repo.attach_evidence(extra, actor="other")
        campaign_scoping_passed = (
            "UNRELATED" not in service.reconciliation("METROLOGY_REFERENCE", "CLEAN").evidence_fingerprint.evidence_ids
        )

        events = service.events("METROLOGY_REFERENCE", "RETRY")
        failure_event_taxonomy_passed = any(
            item.event_type == "STAGE_FAILED" and item.failure_category.value != "NONE" for item in events
        )

        campaign = service.campaign("METROLOGY_REFERENCE", "CLEAN")
        completed_campaign_slo_stable = service.slo(
            "METROLOGY_REFERENCE", "CLEAN", now=campaign.updated_at + timedelta(days=90)
        ).passed

        retention = service.retention("METROLOGY_REFERENCE", "CLEAN", now=now)
        immutable_retention_passed = bool(
            not retention.blockers
            and any(item.item_type == "EVIDENCE" for item in retention.items)
            and all(item.artifact_ref is not None for item in repo.load("METROLOGY_REFERENCE").evidence if item.evidence_id != "UNRELATED")
        )

        export_a = service.export("METROLOGY_REFERENCE", "CLEAN", now=now)
        export_b = service.export("METROLOGY_REFERENCE", "CLEAN", now=now)
        deterministic_export_passed = export_a.export_sha256 == export_b.export_sha256
        published = service.publish_export("METROLOGY_REFERENCE", "CLEAN", now=now)
        from ephi.adapters.base.artifact_store import ArtifactRef
        materialized = artifacts.materialize(ArtifactRef(
            artifact_id=published.artifact.artifact_id,
            content_hash=published.artifact.content_hash,
            locator=published.artifact.locator,
        ))
        immutable_export_publication_passed = materialized.exists() and published.export_sha256 == export_a.export_sha256

        # An unrelated source snapshot introduced at the production stage must be blocked.
        original = repo.campaign("METROLOGY_REFERENCE", "CLEAN")
        assert original is not None
        divergent = SourceSnapshotLineage(
            snapshot_id="DIVERGENT-SNAPSHOT",
            family_id=original.family_id,
            release_id=original.release_id,
            config_hash=original.config_hash,
            captured_at=now,
            as_of=now - timedelta(minutes=1),
            scope="divergent",
            dataset_revisions={"metrology": "different"},
        )
        repo.attach_source_snapshot(divergent, actor="tester")
        prod = original.latest_attempt(CampaignStage.PRODUCTION_REPLAY_SCALE)
        assert prod is not None
        changed_prod = prod.model_copy(update={"source_snapshot_ids": (divergent.snapshot_id,)})
        changed_attempts = tuple(
            changed_prod if item.attempt_id == prod.attempt_id else item for item in original.attempts
        )
        repo.upsert_campaign(original.model_copy(update={"attempts": changed_attempts}), actor="tester")
        divergent_result = service.reconciliation("METROLOGY_REFERENCE", "CLEAN")
        cross_stage_lineage_passed = (
            divergent_result.status == ReconciliationStatus.BLOCKED
            and not divergent_result.source_lineage_consistent
            and not divergent_result.replay_snapshot_consistent
        )

        # Artifact tampering must be detected on read, not just when collected.
        retry_ws = repo.load("METROLOGY_REFERENCE")
        receipt = next(item for item in retry_ws.evidence if item.evidence_id == "REF-DATA_REALITY")
        assert receipt.artifact_ref is not None
        Path(receipt.artifact_ref.locator).write_text("tampered", encoding="utf-8")
        artifact_reverification_passed = not service.reconciliation(
            "METROLOGY_REFERENCE", "RETRY"
        ).artifact_integrity_passed

        checks = (
            campaign_scoping_passed,
            artifact_reverification_passed,
            cross_stage_lineage_passed,
            retry_vs_evidence_reconciliation_passed,
            failure_event_taxonomy_passed,
            completed_campaign_slo_stable,
            immutable_retention_passed,
            deterministic_export_passed,
            immutable_export_publication_passed,
        )
        return CampaignObservabilityQualificationReport(
            passed=all(checks),
            campaign_scoping_passed=campaign_scoping_passed,
            artifact_reverification_passed=artifact_reverification_passed,
            cross_stage_lineage_passed=cross_stage_lineage_passed,
            retry_vs_evidence_reconciliation_passed=retry_vs_evidence_reconciliation_passed,
            failure_event_taxonomy_passed=failure_event_taxonomy_passed,
            completed_campaign_slo_stable=completed_campaign_slo_stable,
            immutable_retention_passed=immutable_retention_passed,
            deterministic_export_passed=deterministic_export_passed,
            immutable_export_publication_passed=immutable_export_publication_passed,
        )
