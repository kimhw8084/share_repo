from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Iterable

from ephi.adapters.base.artifact_store import ArtifactStore
from ephi.domain.launch import (
    CampaignExecutionRecord,
    CampaignStage,
    CampaignStageAttempt,
    CampaignStageStatus,
    LaunchEvidenceAdapterDescriptor,
    SourceSnapshotLineage,
)
from ephi.domain.operations import CertificationState
from ephi.domain.launch import MetrologyShadowLaunchPolicy, ShadowLaunchDossier, LaunchEvidenceKind
from ephi.launch.dossier import build_shadow_launch_dossier
from ephi.onboarding.planner import capability_report_from_payload
from ephi.launch.adapter_validation import validate_and_publish_stage_output
from ephi.launch.contract import validate_launch_module
from ephi.launch.registry import ShadowLaunchWorkspaceRepository


_STAGE_METHODS = {
    CampaignStage.DATA_REALITY: "collect_data_reality",
    CampaignStage.INTERNAL_GOLDEN_REPLAY: "collect_internal_golden_replay",
    CampaignStage.PRODUCTION_REPLAY_SCALE: "collect_production_replay_scale",
    CampaignStage.RELIABILITY_DR_DRILL: "collect_reliability_dr_drill",
    CampaignStage.SHADOW_RUNTIME: "collect_shadow_runtime",
    CampaignStage.ENGINEER_SHADOW: "collect_engineer_shadow",
}

_STAGE_ORDER = tuple(CampaignStage)


def required_campaign_stages(target: CertificationState) -> tuple[CampaignStage, ...]:
    if target == CertificationState.OFFLINE_QUALIFIED:
        return _STAGE_ORDER[:3]
    if target == CertificationState.SHADOW:
        return _STAGE_ORDER[:4]
    if target in {CertificationState.SHADOW_QUALIFIED, CertificationState.ADVISORY_PILOT, CertificationState.PRODUCTION_ADVISORY}:
        return _STAGE_ORDER
    return ()


def _idempotency_key(campaign_id: str, stage: CampaignStage) -> str:
    return hashlib.sha256(f"{campaign_id}|{stage.value}".encode("utf-8")).hexdigest()


class CampaignExecutionController:
    """Durable, resume-safe launch-stage orchestration.

    External company evidence stages are required by contract to be idempotent. EPHI
    persists RUNNING before invoking them, publishes/validates immutable evidence, then
    records the attempt as PASSED/FAILED. A crash before the final commit can therefore
    re-invoke the stage using the same deterministic idempotency identity without
    changing campaign semantics.
    """

    def __init__(
        self,
        *,
        family_id: str,
        release_id: str,
        config_hash: str,
        executor,
        repository: ShadowLaunchWorkspaceRepository,
        artifact_store: ArtifactStore,
        max_attempts_per_stage: int = 3,
        required_provenance=None,
    ) -> None:
        if max_attempts_per_stage < 1:
            raise ValueError("max_attempts_per_stage must be positive")
        self.family_id = family_id
        self.release_id = release_id
        self.config_hash = config_hash
        self.executor = executor
        self.repository = repository
        self.artifact_store = artifact_store
        self.max_attempts_per_stage = max_attempts_per_stage
        from ephi.domain.launch import EvidenceProvenance
        self.required_provenance = required_provenance or EvidenceProvenance.INTERNAL_MEASURED
        contract = validate_launch_module(type("ModuleShell", (), {"build_launch_evidence_executor": object()})(), executor=executor)
        if not contract.valid:
            raise ValueError(
                "invalid launch executor: "
                + "; ".join((*contract.missing_executor_methods, *contract.descriptor_errors))
            )
        self.descriptor = LaunchEvidenceAdapterDescriptor.model_validate(executor.describe_adapter())

    def _new_campaign(self, campaign_id: str, target_state: CertificationState, now: datetime) -> CampaignExecutionRecord:
        return CampaignExecutionRecord(
            campaign_id=campaign_id,
            family_id=self.family_id,
            release_id=self.release_id,
            config_hash=self.config_hash,
            created_at=now,
            updated_at=now,
            target_state=target_state,
        )

    def _load_or_create(self, campaign_id: str, target_state: CertificationState, actor: str) -> CampaignExecutionRecord:
        existing = self.repository.campaign(self.family_id, campaign_id)
        if existing is not None:
            if (existing.release_id, existing.config_hash, existing.family_id) != (self.release_id, self.config_hash, self.family_id):
                raise ValueError("campaign identity mismatch")
            if existing.target_state != target_state:
                raise ValueError("campaign target_state cannot change during resume")
            return existing
        now = datetime.now(timezone.utc)
        campaign = self._new_campaign(campaign_id, target_state, now)
        self.repository.upsert_campaign(campaign, actor=actor, action="CAMPAIGN_CREATED")
        return campaign

    def _replace_attempt(self, campaign: CampaignExecutionRecord, attempt: CampaignStageAttempt) -> CampaignExecutionRecord:
        attempts = tuple(item for item in campaign.attempts if item.attempt_id != attempt.attempt_id) + (attempt,)
        return campaign.model_copy(update={"attempts": attempts, "updated_at": datetime.now(timezone.utc)})

    def _ensure_snapshot(self, snapshot_id: str, *, actor: str, visiting: set[str] | None = None) -> SourceSnapshotLineage:
        workspace = self.repository.load(self.family_id)
        existing = next((item for item in workspace.source_snapshots if item.snapshot_id == snapshot_id), None)
        if existing is not None:
            return existing
        visiting = visiting or set()
        if snapshot_id in visiting:
            raise ValueError(f"source snapshot lineage cycle at {snapshot_id}")
        visiting.add(snapshot_id)
        snapshot = SourceSnapshotLineage.model_validate(self.executor.resolve_source_snapshot(snapshot_id))
        if (snapshot.family_id, snapshot.release_id, snapshot.config_hash) != (self.family_id, self.release_id, self.config_hash):
            raise ValueError(f"source snapshot identity mismatch: {snapshot_id}")
        if snapshot.parent_snapshot_id:
            self._ensure_snapshot(snapshot.parent_snapshot_id, actor=actor, visiting=visiting)
        self.repository.attach_source_snapshot(snapshot, actor=actor)
        visiting.remove(snapshot_id)
        return snapshot

    def execute_stage(
        self,
        *,
        campaign_id: str,
        target_state: CertificationState,
        stage: CampaignStage,
        actor: str,
    ) -> CampaignExecutionRecord:
        campaign = self._load_or_create(campaign_id, target_state, actor)
        latest = campaign.latest_attempt(stage)
        if latest is not None and latest.status == CampaignStageStatus.PASSED:
            return campaign
        attempt_no = 1 if latest is None else latest.attempt + 1
        if attempt_no > self.max_attempts_per_stage:
            raise RuntimeError(f"stage retry budget exhausted: {stage.value}")
        if stage not in self.descriptor.supported_stages or stage not in self.descriptor.idempotent_stages:
            raise ValueError(f"adapter cannot safely execute stage: {stage.value}")

        now = datetime.now(timezone.utc)
        attempt = CampaignStageAttempt(
            attempt_id=f"{campaign_id}:{stage.value}:{attempt_no}",
            campaign_id=campaign_id,
            stage=stage,
            attempt=attempt_no,
            idempotency_key=_idempotency_key(campaign_id, stage),
            status=CampaignStageStatus.RUNNING,
            started_at=now,
        )
        campaign = self._replace_attempt(campaign, attempt)
        self.repository.upsert_campaign(campaign, actor=actor, action="CAMPAIGN_STAGE_STARTED")

        try:
            raw = getattr(self.executor, _STAGE_METHODS[stage])()
            output = validate_and_publish_stage_output(
                stage=stage,
                result=raw,
                family_id=self.family_id,
                release_id=self.release_id,
                config_hash=self.config_hash,
                artifact_store=self.artifact_store,
                required_provenance=self.required_provenance,
            )
            snapshot_ids = set()
            if output.receipt.source_snapshot_id:
                snapshot_ids.add(output.receipt.source_snapshot_id)
            for manifest in output.replay_manifests:
                if manifest.source_snapshot_id:
                    snapshot_ids.add(manifest.source_snapshot_id)
            for snapshot_id in sorted(snapshot_ids):
                self._ensure_snapshot(snapshot_id, actor=actor)

            self.repository.attach_evidence(output.receipt, actor=actor)
            for manifest in output.replay_manifests:
                self.repository.attach_replay_manifest(manifest, actor=actor)
            completed = attempt.model_copy(update={
                "status": CampaignStageStatus.PASSED if output.passed else CampaignStageStatus.FAILED,
                "completed_at": datetime.now(timezone.utc),
                "evidence_ids": (output.receipt.evidence_id,),
                "replay_ids": tuple(item.replay_id for item in output.replay_manifests),
                "source_snapshot_ids": tuple(sorted(snapshot_ids)),
                "error": None if output.passed else f"evidence decision={output.receipt.decision.value}",
            })
            campaign = self.repository.campaign(self.family_id, campaign_id) or campaign
            campaign = self._replace_attempt(campaign, completed)
            self.repository.upsert_campaign(campaign, actor=actor, action="CAMPAIGN_STAGE_COMPLETED")
            if not output.passed:
                raise RuntimeError(f"stage evidence did not pass: {stage.value}")
            return campaign
        except Exception as exc:
            current = self.repository.campaign(self.family_id, campaign_id) or campaign
            latest_now = current.latest_attempt(stage)
            if latest_now is not None and latest_now.attempt_id == attempt.attempt_id and latest_now.status == CampaignStageStatus.RUNNING:
                failed = latest_now.model_copy(update={
                    "status": CampaignStageStatus.FAILED,
                    "completed_at": datetime.now(timezone.utc),
                    "error": f"{type(exc).__name__}: {exc}",
                })
                current = self._replace_attempt(current, failed)
                self.repository.upsert_campaign(current, actor=actor, action="CAMPAIGN_STAGE_FAILED")
            raise

    def run(
        self,
        *,
        campaign_id: str,
        target_state: CertificationState,
        actor: str,
        stages: Iterable[CampaignStage] | None = None,
    ) -> CampaignExecutionRecord:
        selected = tuple(stages) if stages is not None else required_campaign_stages(target_state)
        last = self._load_or_create(campaign_id, target_state, actor)
        for stage in selected:
            last = self.execute_stage(
                campaign_id=campaign_id,
                target_state=target_state,
                stage=stage,
                actor=actor,
            )
        return last

    def build_dossier(
        self,
        *,
        campaign_id: str,
        current_state: CertificationState,
        target_state: CertificationState,
        policy: MetrologyShadowLaunchPolicy,
        limitations: tuple[str, ...] = (),
        capability_id: str = "behavioral-health",
    ) -> ShadowLaunchDossier:
        campaign = self.repository.campaign(self.family_id, campaign_id)
        if campaign is None:
            raise KeyError(campaign_id)
        workspace = self.repository.load(self.family_id)
        evidence = tuple(
            item for item in workspace.evidence
            if item.release_id == self.release_id and item.config_hash == self.config_hash
        )
        reality_receipts = [item for item in evidence if item.kind == LaunchEvidenceKind.DATA_REALITY]
        data_reality = None
        if reality_receipts:
            latest = max(reality_receipts, key=lambda item: (item.observed_at, item.evidence_id))
            if latest.artifact_ref is None:
                path = latest.artifact
            else:
                from ephi.adapters.base.artifact_store import ArtifactRef
                path = self.artifact_store.materialize(ArtifactRef(
                    artifact_id=latest.artifact_ref.artifact_id,
                    content_hash=latest.artifact_ref.content_hash,
                    locator=latest.artifact_ref.locator,
                ))
            with open(path, "r", encoding="utf-8") as handle:
                data_reality = capability_report_from_payload(json.load(handle))
        return build_shadow_launch_dossier(
            family_id=self.family_id,
            release_id=self.release_id,
            config_hash=self.config_hash,
            current_state=current_state,
            target_state=target_state,
            policy=policy,
            evidence=evidence,
            data_reality=data_reality,
            replay_manifests=tuple(workspace.replay_manifests),
            source_snapshots=tuple(workspace.source_snapshots),
            campaign_id=campaign_id,
            limitations=limitations,
            capability_id=capability_id,
            artifact_store=self.artifact_store,
        )

    def export_workspace(self) -> dict[str, object]:
        return self.repository.load(self.family_id).model_dump(mode="json")
