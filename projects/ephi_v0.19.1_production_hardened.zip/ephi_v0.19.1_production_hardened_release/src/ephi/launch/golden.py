from __future__ import annotations

from collections import Counter
from datetime import datetime

from ephi.domain.benchmark import BenchmarkCorpus, BenchmarkSourceKind
from ephi.domain.launch import InternalGoldenReplayManifest


def build_internal_golden_replay_manifest(
    *,
    corpus: BenchmarkCorpus,
    family_id: str,
    release_id: str,
    config_hash: str,
    source_snapshot_id: str,
    replay_as_of: datetime,
) -> InternalGoldenReplayManifest:
    if any(case.source_kind != BenchmarkSourceKind.INTERNAL_HISTORY for case in corpus.cases):
        raise ValueError("internal Golden replay manifest cannot include synthetic cases")
    case_types = Counter(case.case_type.value for case in corpus.cases)
    confidence = Counter(case.label_confidence.value for case in corpus.cases)
    return InternalGoldenReplayManifest(
        family_id=family_id,
        release_id=release_id,
        config_hash=config_hash,
        corpus_id=corpus.corpus_id,
        corpus_version=corpus.version,
        corpus_sha256=corpus.stable_hash(),
        source_snapshot_id=source_snapshot_id,
        accepted_case_ids=tuple(case.case_id for case in corpus.cases),
        case_type_counts=dict(sorted(case_types.items())),
        confidence_counts=dict(sorted(confidence.items())),
        replay_as_of=replay_as_of,
        strict_available_at=True,
    )
