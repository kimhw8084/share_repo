from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Mapping

from ephi.adapters.base.artifact_store import ArtifactRef, ArtifactStore
from ephi.domain.launch import (
    EvidenceDecision,
    EvidenceProvenance,
    LaunchArtifactReference,
    LaunchEvidenceKind,
    LaunchEvidenceReceipt,
)


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def receipt_from_artifact(
    *,
    evidence_id: str,
    family_id: str,
    release_id: str,
    config_hash: str,
    kind: LaunchEvidenceKind,
    provenance: EvidenceProvenance,
    decision: EvidenceDecision,
    artifact: str | Path,
    observed_at: datetime | None = None,
    valid_until: datetime | None = None,
    validator: str | None = None,
    source_snapshot_id: str | None = None,
    metrics: dict[str, object] | None = None,
    limitations: tuple[str, ...] = (),
) -> LaunchEvidenceReceipt:
    path = Path(artifact)
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(path)
    return LaunchEvidenceReceipt(
        evidence_id=evidence_id,
        family_id=family_id,
        release_id=release_id,
        config_hash=config_hash,
        kind=kind,
        provenance=provenance,
        decision=decision,
        artifact=str(path),
        artifact_sha256=sha256_file(path),
        observed_at=observed_at or datetime.now(timezone.utc),
        valid_until=valid_until,
        validator=validator,
        source_snapshot_id=source_snapshot_id,
        metrics=dict(metrics or {}),
        limitations=limitations,
    )


def receipt_from_artifact_ref(
    *,
    evidence_id: str,
    family_id: str,
    release_id: str,
    config_hash: str,
    kind: LaunchEvidenceKind,
    provenance: EvidenceProvenance,
    decision: EvidenceDecision,
    artifact_ref: ArtifactRef,
    observed_at: datetime | None = None,
    valid_until: datetime | None = None,
    validator: str | None = None,
    source_snapshot_id: str | None = None,
    metrics: dict[str, object] | None = None,
    limitations: tuple[str, ...] = (),
) -> LaunchEvidenceReceipt:
    ref = LaunchArtifactReference(
        artifact_id=artifact_ref.artifact_id,
        content_hash=artifact_ref.content_hash,
        locator=artifact_ref.locator,
    )
    return LaunchEvidenceReceipt(
        evidence_id=evidence_id,
        family_id=family_id,
        release_id=release_id,
        config_hash=config_hash,
        kind=kind,
        provenance=provenance,
        decision=decision,
        artifact=ref.locator,
        artifact_sha256=ref.content_hash,
        artifact_ref=ref,
        observed_at=observed_at or datetime.now(timezone.utc),
        valid_until=valid_until,
        validator=validator,
        source_snapshot_id=source_snapshot_id,
        metrics=dict(metrics or {}),
        limitations=limitations,
    )


def publish_receipt_artifact(
    receipt: LaunchEvidenceReceipt,
    artifact_store: ArtifactStore,
    *,
    metadata: Mapping[str, object] | None = None,
) -> LaunchEvidenceReceipt:
    """Publish a locally collected evidence artifact into the immutable ArtifactStore.

    Already-published receipts are verified and returned unchanged. This function is
    deterministic by evidence_id + content hash in the reference FileSystemArtifactStore
    and relies on the production ArtifactStore contract to preserve the same immutability.
    """
    if receipt.artifact_ref is not None:
        materialized = artifact_store.materialize(ArtifactRef(
            artifact_id=receipt.artifact_ref.artifact_id,
            content_hash=receipt.artifact_ref.content_hash,
            locator=receipt.artifact_ref.locator,
        ))
        if sha256_file(materialized) != receipt.artifact_sha256:
            raise ValueError(f"published evidence hash mismatch: {receipt.evidence_id}")
        return receipt

    local = Path(receipt.artifact)
    if not local.exists() or not local.is_file():
        raise FileNotFoundError(local)
    if sha256_file(local) != receipt.artifact_sha256:
        raise ValueError(f"local evidence changed before publish: {receipt.evidence_id}")
    ref = artifact_store.put(
        f"launch/{receipt.family_id}/{receipt.evidence_id}",
        local,
        metadata={
            "family_id": receipt.family_id,
            "release_id": receipt.release_id,
            "config_hash": receipt.config_hash,
            "kind": receipt.kind.value,
            "provenance": receipt.provenance.value,
            **dict(metadata or {}),
        },
    )
    if ref.content_hash != receipt.artifact_sha256:
        raise ValueError(f"ArtifactStore changed evidence content: {receipt.evidence_id}")
    return receipt.model_copy(update={
        "artifact": ref.locator,
        "artifact_ref": LaunchArtifactReference(
            artifact_id=ref.artifact_id,
            content_hash=ref.content_hash,
            locator=ref.locator,
        ),
    })


def receipt_artifact_matches(
    receipt: LaunchEvidenceReceipt,
    artifact_store: ArtifactStore | None = None,
) -> bool:
    try:
        if receipt.artifact_ref is not None:
            if artifact_store is None:
                # A local reference store locator can still be verified without the
                # store object; non-filesystem locators intentionally fail closed.
                path = Path(receipt.artifact_ref.locator)
                return path.exists() and path.is_file() and sha256_file(path) == receipt.artifact_sha256
            path = artifact_store.materialize(ArtifactRef(
                artifact_id=receipt.artifact_ref.artifact_id,
                content_hash=receipt.artifact_ref.content_hash,
                locator=receipt.artifact_ref.locator,
            ))
            return sha256_file(path) == receipt.artifact_sha256
        path = Path(receipt.artifact)
        return path.exists() and path.is_file() and sha256_file(path) == receipt.artifact_sha256
    except (FileNotFoundError, ValueError, OSError):
        return False
