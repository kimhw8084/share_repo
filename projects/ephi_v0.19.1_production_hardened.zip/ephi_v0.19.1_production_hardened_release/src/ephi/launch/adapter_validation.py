from __future__ import annotations

from dataclasses import dataclass

from ephi.adapters.base.artifact_store import ArtifactStore
from ephi.domain.launch import (
    CampaignStage,
    EvidenceDecision,
    EvidenceProvenance,
    LaunchEvidenceKind,
    LaunchEvidenceReceipt,
    ProductionReplayManifest,
)
from ephi.launch.evidence import publish_receipt_artifact, receipt_artifact_matches


_STAGE_KIND = {
    CampaignStage.DATA_REALITY: LaunchEvidenceKind.DATA_REALITY,
    CampaignStage.INTERNAL_GOLDEN_REPLAY: LaunchEvidenceKind.INTERNAL_GOLDEN_REPLAY,
    CampaignStage.PRODUCTION_REPLAY_SCALE: LaunchEvidenceKind.PRODUCTION_REPLAY_SCALE,
    CampaignStage.RELIABILITY_DR_DRILL: LaunchEvidenceKind.RELIABILITY_DR_DRILL,
    CampaignStage.SHADOW_RUNTIME: LaunchEvidenceKind.SHADOW_RUNTIME,
    CampaignStage.ENGINEER_SHADOW: LaunchEvidenceKind.ENGINEER_SHADOW,
}

_SOURCE_BOUND = frozenset({
    CampaignStage.DATA_REALITY,
    CampaignStage.INTERNAL_GOLDEN_REPLAY,
    CampaignStage.PRODUCTION_REPLAY_SCALE,
})


@dataclass(frozen=True, slots=True)
class ValidatedStageOutput:
    receipt: LaunchEvidenceReceipt
    replay_manifests: tuple[ProductionReplayManifest, ...] = ()

    @property
    def passed(self) -> bool:
        return self.receipt.decision == EvidenceDecision.PASS


def normalize_stage_output(stage: CampaignStage, result) -> tuple[LaunchEvidenceReceipt, tuple[ProductionReplayManifest, ...]]:
    if stage == CampaignStage.PRODUCTION_REPLAY_SCALE:
        if not isinstance(result, tuple) or len(result) != 2:
            raise TypeError("production replay/scale stage must return (LaunchEvidenceReceipt, ProductionReplayManifest)")
        receipt, manifest = result
        return LaunchEvidenceReceipt.model_validate(receipt), (ProductionReplayManifest.model_validate(manifest),)
    return LaunchEvidenceReceipt.model_validate(result), ()


def validate_and_publish_stage_output(
    *,
    stage: CampaignStage,
    result,
    family_id: str,
    release_id: str,
    config_hash: str,
    artifact_store: ArtifactStore,
    required_provenance: EvidenceProvenance = EvidenceProvenance.INTERNAL_MEASURED,
) -> ValidatedStageOutput:
    receipt, replay_manifests = normalize_stage_output(stage, result)
    expected_kind = _STAGE_KIND[stage]
    if receipt.kind != expected_kind:
        raise ValueError(f"{stage.value} returned {receipt.kind.value}, expected {expected_kind.value}")
    if (receipt.family_id, receipt.release_id, receipt.config_hash) != (family_id, release_id, config_hash):
        raise ValueError(f"{stage.value} evidence identity mismatch")
    if receipt.provenance != required_provenance:
        raise ValueError(f"{stage.value} must return {required_provenance.value} evidence")
    if not receipt.validator or not receipt.validator.strip():
        raise ValueError(f"{stage.value} evidence must identify a validator")
    if stage in _SOURCE_BOUND and not receipt.source_snapshot_id:
        raise ValueError(f"{stage.value} evidence requires source_snapshot_id")

    published = publish_receipt_artifact(receipt, artifact_store, metadata={"campaign_stage": stage.value})
    if not receipt_artifact_matches(published, artifact_store):
        raise ValueError(f"{stage.value} immutable artifact verification failed")

    for manifest in replay_manifests:
        if (manifest.family_id, manifest.release_id, manifest.config_hash) != (family_id, release_id, config_hash):
            raise ValueError("production replay manifest identity mismatch")
        if not manifest.source_snapshot_id:
            raise ValueError("production replay manifest requires source_snapshot_id")
        if published.source_snapshot_id != manifest.source_snapshot_id:
            raise ValueError("production replay receipt and manifest must reference the same source snapshot")
        if not manifest.strict_available_at:
            raise ValueError("production replay manifest must enforce strict available_at")
    return ValidatedStageOutput(receipt=published, replay_manifests=replay_manifests)
