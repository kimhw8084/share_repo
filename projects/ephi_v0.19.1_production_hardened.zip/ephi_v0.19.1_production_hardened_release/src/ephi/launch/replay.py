from __future__ import annotations

from datetime import datetime

from ephi.domain.launch import ProductionReplayManifest, ReplayPartition


def build_replay_manifest(
    *,
    replay_id: str,
    family_id: str,
    release_id: str,
    config_hash: str,
    replay_as_of: datetime,
    partitions: tuple[ReplayPartition, ...],
    source_snapshot_id: str | None = None,
    expected_total_rows: int | None = None,
    notes: tuple[str, ...] = (),
) -> ProductionReplayManifest:
    return ProductionReplayManifest(
        replay_id=replay_id,
        family_id=family_id,
        release_id=release_id,
        config_hash=config_hash,
        replay_as_of=replay_as_of,
        strict_available_at=True,
        source_snapshot_id=source_snapshot_id,
        partitions=partitions,
        expected_total_rows=expected_total_rows,
        notes=notes,
    )
