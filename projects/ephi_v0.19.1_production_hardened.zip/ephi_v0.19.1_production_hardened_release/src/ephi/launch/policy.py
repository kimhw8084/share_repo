from __future__ import annotations

from pathlib import Path

import yaml

from ephi.domain.launch import MetrologyShadowLaunchPolicy


def load_launch_policy(path: str | Path) -> MetrologyShadowLaunchPolicy:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    return MetrologyShadowLaunchPolicy.model_validate(payload)
