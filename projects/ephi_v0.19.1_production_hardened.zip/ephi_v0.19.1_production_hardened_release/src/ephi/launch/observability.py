from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable

import yaml

from ephi.adapters.base.artifact_store import ArtifactStore
from ephi.domain.campaign_observability import (
    CampaignEventView,
    CampaignEvidenceComparison,
    CampaignFailureCategory,
    CampaignQualificationArtifact,
    CampaignQualificationExport,
    CampaignReadinessState,
    CampaignReadinessView,
    CampaignRetentionAssessment,
    CampaignRetentionPolicy,
    CampaignSLOPolicy,
    CampaignSLOReport,
    CampaignStageSLO,
    CampaignStageView,
    CrossStageReconciliation,
    EvidenceComparisonState,
    EvidenceSetFingerprint,
    ReconciliationStatus,
    RetentionDisposition,
    RetentionItemAssessment,
)
from ephi.domain.launch import (
    CampaignExecutionRecord,
    CampaignStage,
    CampaignStageStatus,
    LaunchEvidenceKind,
    LaunchEvidenceReceipt,
    ProductionReplayManifest,
    SourceSnapshotLineage,
)
from ephi.domain.operations import CertificationState
from ephi.launch.dossier import build_shadow_launch_dossier
from ephi.launch.evidence import receipt_artifact_matches
from ephi.launch.execution import required_campaign_stages
from ephi.launch.policy import load_launch_policy
from ephi.launch.registry import ShadowLaunchWorkspaceRepository
from ephi.onboarding.planner import capability_report_from_payload


def _canonical_hash(payload: object) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def load_campaign_slo_policy(path: str | Path) -> CampaignSLOPolicy:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    return CampaignSLOPolicy.model_validate(payload)


def load_campaign_retention_policy(path: str | Path) -> CampaignRetentionPolicy:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    return CampaignRetentionPolicy.model_validate(payload)


def classify_campaign_failure(error: str | None) -> CampaignFailureCategory:
    if not error:
        return CampaignFailureCategory.NONE
    text = error.lower()
    if "retry budget" in text or "retry" in text and "exhaust" in text:
        return CampaignFailureCategory.RETRY_EXHAUSTED
    if "hash mismatch" in text or "checksum" in text or "artifact" in text and "changed" in text:
        return CampaignFailureCategory.ARTIFACT_INTEGRITY
    if "source snapshot identity" in text or "snapshot identity mismatch" in text or "lineage cycle" in text:
        return CampaignFailureCategory.SOURCE_IDENTITY
    if "file not found" in text or "filenotfound" in text or "unavailable" in text or "timeout" in text or "connection" in text:
        return CampaignFailureCategory.SOURCE_UNAVAILABLE
    if "adapter" in text or "contract" in text or "idempotent" in text:
        return CampaignFailureCategory.ADAPTER_CONTRACT
    if "evidence decision" in text or "evidence did not pass" in text or "stage evidence did not pass" in text:
        return CampaignFailureCategory.EVIDENCE_REJECTED
    if "handoff" in text or "promotion" in text and "control" in text:
        return CampaignFailureCategory.CONTROL_PLANE_HANDOFF
    if "config" in text or "identity mismatch" in text or "family_id mismatch" in text:
        return CampaignFailureCategory.CONFIGURATION
    return CampaignFailureCategory.UNKNOWN


def _campaign_scope(workspace, campaign: CampaignExecutionRecord):
    evidence_ids = {item for attempt in campaign.attempts for item in attempt.evidence_ids}
    replay_ids = {item for attempt in campaign.attempts for item in attempt.replay_ids}
    snapshot_ids = {item for attempt in campaign.attempts for item in attempt.source_snapshot_ids}
    evidence = tuple(sorted((x for x in workspace.evidence if x.evidence_id in evidence_ids), key=lambda x: x.evidence_id))
    replays = tuple(sorted((x for x in workspace.replay_manifests if x.replay_id in replay_ids), key=lambda x: x.replay_id))
    snapshots = tuple(sorted((x for x in workspace.source_snapshots if x.snapshot_id in snapshot_ids), key=lambda x: x.snapshot_id))
    return evidence, replays, snapshots


def _evidence_payload(receipt: LaunchEvidenceReceipt) -> dict[str, object]:
    return {
        "evidence_id": receipt.evidence_id,
        "kind": receipt.kind.value,
        "provenance": receipt.provenance.value,
        "decision": receipt.decision.value,
        "artifact_sha256": receipt.artifact_sha256,
        "validator": receipt.validator,
        "metrics": receipt.metrics,
        "limitations": receipt.limitations,
    }


def _replay_payload(replay: ProductionReplayManifest) -> dict[str, object]:
    return {
        "strict_available_at": replay.strict_available_at,
        "replay_as_of": replay.replay_as_of.isoformat(),
        "expected_total_rows": replay.expected_total_rows,
        "partitions": [
            {
                "partition_id": p.partition_id,
                "start_time": p.start_time.isoformat(),
                "end_time": p.end_time.isoformat(),
                "scope": p.scope,
                "estimated_rows": p.estimated_rows,
            }
            for p in replay.partitions
        ],
        "notes": replay.notes,
    }


def _source_payload(snapshot: SourceSnapshotLineage) -> dict[str, object]:
    return {
        "scope": snapshot.scope,
        "as_of": snapshot.as_of.isoformat(),
        "dataset_revisions": dict(sorted(snapshot.dataset_revisions.items())),
        "parent_snapshot_id": snapshot.parent_snapshot_id,
        "notes": snapshot.notes,
    }


def build_evidence_set_fingerprint(workspace, campaign: CampaignExecutionRecord) -> EvidenceSetFingerprint:
    evidence, replays, snapshots = _campaign_scope(workspace, campaign)
    evidence_payload = {
        "evidence": [_evidence_payload(x) for x in evidence],
        "replays": [_replay_payload(x) for x in replays],
    }
    source_payload = [_source_payload(x) for x in snapshots]
    execution_payload = [
        {
            "stage": item.stage.value,
            "attempt": item.attempt,
            "status": item.status.value,
            "evidence_ids": tuple(sorted(item.evidence_ids)),
            "replay_ids": tuple(sorted(item.replay_ids)),
            "source_snapshot_ids": tuple(sorted(item.source_snapshot_ids)),
            "failure_category": classify_campaign_failure(item.error).value,
        }
        for item in sorted(campaign.attempts, key=lambda x: (x.stage.value, x.attempt))
    ]
    return EvidenceSetFingerprint(
        family_id=campaign.family_id,
        release_id=campaign.release_id,
        config_hash=campaign.config_hash,
        campaign_id=campaign.campaign_id,
        evidence_sha256=_canonical_hash(evidence_payload),
        source_sha256=_canonical_hash(source_payload),
        execution_sha256=_canonical_hash(execution_payload),
        evidence_count=len(evidence),
        replay_count=len(replays),
        snapshot_count=len(snapshots),
        evidence_ids=tuple(x.evidence_id for x in evidence),
        replay_ids=tuple(x.replay_id for x in replays),
        snapshot_ids=tuple(x.snapshot_id for x in snapshots),
    )


def _is_same_or_descendant(current: str, previous: str, snapshots: dict[str, SourceSnapshotLineage]) -> bool:
    if current == previous:
        return True
    seen: set[str] = set()
    cursor = snapshots.get(current)
    while cursor is not None and cursor.parent_snapshot_id is not None:
        parent = cursor.parent_snapshot_id
        if parent == previous:
            return True
        if parent in seen:
            return False
        seen.add(parent)
        cursor = snapshots.get(parent)
    return False


def reconcile_campaign(
    workspace,
    campaign: CampaignExecutionRecord,
    *,
    artifact_store: ArtifactStore | None = None,
) -> CrossStageReconciliation:
    evidence, replays, snapshots = _campaign_scope(workspace, campaign)
    fingerprint = build_evidence_set_fingerprint(workspace, campaign)
    blockers: list[str] = []
    warnings: list[str] = []

    identity_consistent = all(
        (item.family_id, item.release_id, item.config_hash)
        == (campaign.family_id, campaign.release_id, campaign.config_hash)
        for item in (*evidence, *replays, *snapshots)
    )
    if not identity_consistent:
        blockers.append("campaign evidence/replay/source identity mismatch")

    bad_artifacts = tuple(x.evidence_id for x in evidence if not receipt_artifact_matches(x, artifact_store))
    artifact_integrity_passed = not bad_artifacts
    if bad_artifacts:
        blockers.append("artifact integrity failure: " + ",".join(sorted(bad_artifacts)))

    by_id = {x.snapshot_id: x for x in snapshots}
    stage_snapshot_ids: dict[str, tuple[str, ...]] = {}
    ordered_stage_snapshots: list[tuple[CampaignStage, tuple[str, ...]]] = []
    for stage in CampaignStage:
        latest = campaign.latest_attempt(stage)
        ids = tuple(sorted(latest.source_snapshot_ids)) if latest is not None else ()
        if ids:
            stage_snapshot_ids[stage.value] = ids
            ordered_stage_snapshots.append((stage, ids))
            unknown = [item for item in ids if item not in by_id]
            if unknown:
                blockers.append(f"unknown source snapshot for {stage.value}: {','.join(unknown)}")

    source_lineage_consistent = True
    previous_ids: tuple[str, ...] | None = None
    previous_as_of: datetime | None = None
    for stage, ids in ordered_stage_snapshots:
        known_ids = tuple(item for item in ids if item in by_id)
        if previous_ids and known_ids:
            for current in known_ids:
                if not any(_is_same_or_descendant(current, prev, by_id) for prev in previous_ids if prev in by_id):
                    source_lineage_consistent = False
                    blockers.append(f"source lineage diverges at {stage.value}: {current}")
        current_as_of = max((by_id[item].as_of for item in known_ids), default=None)
        if previous_as_of is not None and current_as_of is not None and current_as_of < previous_as_of:
            source_lineage_consistent = False
            blockers.append(f"source as_of moves backward at {stage.value}")
        if known_ids:
            previous_ids = known_ids
        if current_as_of is not None:
            previous_as_of = current_as_of

    replay_snapshot_consistent = True
    attempt_by_replay = {
        replay_id: attempt
        for attempt in campaign.attempts
        for replay_id in attempt.replay_ids
    }
    for replay in replays:
        if replay.source_snapshot_id is None:
            warnings.append(f"replay has no source snapshot: {replay.replay_id}")
            continue
        attempt = attempt_by_replay.get(replay.replay_id)
        if replay.source_snapshot_id not in by_id or attempt is None or replay.source_snapshot_id not in attempt.source_snapshot_ids:
            replay_snapshot_consistent = False
            blockers.append(f"replay/source snapshot mismatch: {replay.replay_id}")

    required = required_campaign_stages(campaign.target_state)
    missing = tuple(stage.value for stage in required if not campaign.stage_passed(stage))
    required_stage_coverage = not missing
    if missing:
        blockers.append("required campaign stages not passed: " + ",".join(missing))

    if blockers:
        status = ReconciliationStatus.BLOCKED
    elif warnings:
        status = ReconciliationStatus.WARNING
    else:
        status = ReconciliationStatus.CONSISTENT
    return CrossStageReconciliation(
        status=status,
        identity_consistent=identity_consistent,
        artifact_integrity_passed=artifact_integrity_passed,
        source_lineage_consistent=source_lineage_consistent,
        replay_snapshot_consistent=replay_snapshot_consistent,
        required_stage_coverage=required_stage_coverage,
        evidence_fingerprint=fingerprint,
        stage_snapshot_ids=stage_snapshot_ids,
        blockers=tuple(blockers),
        warnings=tuple(warnings),
    )


def _attempt_elapsed_seconds(attempt, now: datetime) -> float:
    end = attempt.completed_at or now
    return max(0.0, (end - attempt.started_at).total_seconds())


def build_stage_views(campaign: CampaignExecutionRecord, *, now: datetime | None = None) -> tuple[CampaignStageView, ...]:
    now = now or datetime.now(timezone.utc)
    items: list[CampaignStageView] = []
    required = set(required_campaign_stages(campaign.target_state))
    for stage in CampaignStage:
        attempts = sorted((x for x in campaign.attempts if x.stage == stage), key=lambda x: x.attempt)
        if not attempts and stage not in required:
            continue
        latest = attempts[-1] if attempts else None
        elapsed = None
        if attempts:
            elapsed = max(0.0, ((latest.completed_at or now) - attempts[0].started_at).total_seconds())
        status = latest.status.value if latest is not None else CampaignStageStatus.PENDING.value
        items.append(CampaignStageView(
            stage=stage,
            status=status,
            attempts=len(attempts),
            retries=max(0, len(attempts) - 1),
            elapsed_seconds=elapsed,
            evidence_ids=latest.evidence_ids if latest else (),
            replay_ids=latest.replay_ids if latest else (),
            source_snapshot_ids=latest.source_snapshot_ids if latest else (),
            failure_category=classify_campaign_failure(latest.error if latest else None),
            last_error=latest.error if latest else None,
        ))
    return tuple(items)


def evaluate_campaign_slo(
    campaign: CampaignExecutionRecord,
    policy: CampaignSLOPolicy,
    *,
    now: datetime | None = None,
) -> CampaignSLOReport:
    now = now or datetime.now(timezone.utc)
    blockers: list[str] = []
    stage_reports: list[CampaignStageSLO] = []
    total_retries = 0
    running_attempts = 0
    for stage_view in build_stage_views(campaign, now=now):
        total_retries += stage_view.retries
        max_elapsed = policy.stage_max_elapsed_seconds.get(stage_view.stage.value)
        reasons: list[str] = []
        passed = True
        if stage_view.retries > policy.max_retries_per_stage:
            passed = False
            reasons.append(f"retries {stage_view.retries} > {policy.max_retries_per_stage}")
        if max_elapsed is not None and stage_view.elapsed_seconds is not None and stage_view.elapsed_seconds > max_elapsed:
            passed = False
            reasons.append(f"elapsed {stage_view.elapsed_seconds:.1f}s > {max_elapsed:.1f}s")
        if stage_view.status == CampaignStageStatus.RUNNING.value:
            running_attempts += 1
            latest = campaign.latest_attempt(stage_view.stage)
            if latest and _attempt_elapsed_seconds(latest, now) > policy.max_running_age_seconds:
                passed = False
                reasons.append("RUNNING attempt exceeded max_running_age_seconds")
        if not passed:
            blockers.append(f"{stage_view.stage.value}: " + "; ".join(reasons))
        stage_reports.append(CampaignStageSLO(
            stage=stage_view.stage,
            elapsed_seconds=stage_view.elapsed_seconds,
            max_elapsed_seconds=max_elapsed,
            retries=stage_view.retries,
            max_retries=policy.max_retries_per_stage,
            passed=passed,
            reasons=tuple(reasons),
        ))
    required = required_campaign_stages(campaign.target_state)
    latest_required = [campaign.latest_attempt(stage) for stage in required]
    terminal = bool(required) and all(
        item is not None and item.status in {CampaignStageStatus.PASSED, CampaignStageStatus.FAILED}
        for item in latest_required
    )
    completed_times = [item.completed_at for item in campaign.attempts if item.completed_at is not None]
    end_time = max(completed_times) if terminal and completed_times else now
    campaign_elapsed = max(0.0, (end_time - campaign.created_at).total_seconds())
    if campaign_elapsed > policy.max_campaign_elapsed_seconds:
        blockers.append(
            f"campaign elapsed {campaign_elapsed:.1f}s > {policy.max_campaign_elapsed_seconds:.1f}s"
        )
    return CampaignSLOReport(
        passed=not blockers,
        campaign_elapsed_seconds=campaign_elapsed,
        max_campaign_elapsed_seconds=policy.max_campaign_elapsed_seconds,
        total_retries=total_retries,
        running_attempts=running_attempts,
        stage_reports=tuple(stage_reports),
        blockers=tuple(blockers),
    )


def build_retention_assessment(
    workspace,
    campaign: CampaignExecutionRecord,
    policy: CampaignRetentionPolicy,
    *,
    generated_at: datetime | None = None,
) -> CampaignRetentionAssessment:
    generated_at = generated_at or datetime.now(timezone.utc)
    evidence, replays, snapshots = _campaign_scope(workspace, campaign)
    items: list[RetentionItemAssessment] = []
    blockers: list[str] = []
    for receipt in evidence:
        retain_until = receipt.observed_at + timedelta(days=policy.authoritative_retention_days)
        if policy.require_immutable_evidence and receipt.artifact_ref is None:
            blockers.append(f"immutable ArtifactStore reference missing: {receipt.evidence_id}")
        items.append(RetentionItemAssessment(
            item_type="EVIDENCE",
            item_id=receipt.evidence_id,
            disposition=RetentionDisposition.KEEP_REQUIRED,
            retain_until=retain_until,
            reason="promotion/qualification evidence is authoritative",
        ))
    for replay in replays:
        items.append(RetentionItemAssessment(
            item_type="REPLAY_MANIFEST",
            item_id=replay.replay_id,
            disposition=RetentionDisposition.KEEP_REQUIRED,
            retain_until=replay.replay_as_of + timedelta(days=policy.authoritative_retention_days),
            reason="qualification replay provenance is authoritative",
        ))
    for snapshot in snapshots:
        items.append(RetentionItemAssessment(
            item_type="SOURCE_SNAPSHOT",
            item_id=snapshot.snapshot_id,
            disposition=RetentionDisposition.KEEP_REQUIRED,
            retain_until=snapshot.captured_at + timedelta(days=policy.source_lineage_retention_days),
            reason="source lineage required to reproduce qualification evidence",
        ))
    for attempt in campaign.attempts:
        if attempt.status == CampaignStageStatus.FAILED and attempt.completed_at is not None:
            items.append(RetentionItemAssessment(
                item_type="FAILED_ATTEMPT",
                item_id=attempt.attempt_id,
                disposition=RetentionDisposition.ELIGIBLE_AFTER,
                retain_until=attempt.completed_at + timedelta(days=policy.failed_attempt_retention_days),
                reason="retain failed-attempt diagnostics for campaign audit",
            ))
    return CampaignRetentionAssessment(
        policy_version=policy.policy_version,
        generated_at=generated_at,
        items=tuple(items),
        blockers=tuple(blockers),
    )


def campaign_events(workspace, campaign: CampaignExecutionRecord) -> tuple[CampaignEventView, ...]:
    scoped_evidence, scoped_replays, scoped_snapshots = _campaign_scope(workspace, campaign)
    entity_ids = {
        campaign.campaign_id,
        *(x.evidence_id for x in scoped_evidence),
        *(x.replay_id for x in scoped_replays),
        *(x.snapshot_id for x in scoped_snapshots),
    }
    events: list[CampaignEventView] = []
    for attempt in campaign.attempts:
        events.append(CampaignEventView(
            event_id=f"{attempt.attempt_id}:START",
            campaign_id=campaign.campaign_id,
            at=attempt.started_at,
            event_type="STAGE_STARTED",
            stage=attempt.stage,
            attempt=attempt.attempt,
            status=CampaignStageStatus.RUNNING.value,
        ))
        if attempt.completed_at is not None:
            events.append(CampaignEventView(
                event_id=f"{attempt.attempt_id}:END",
                campaign_id=campaign.campaign_id,
                at=attempt.completed_at,
                event_type="STAGE_COMPLETED" if attempt.status == CampaignStageStatus.PASSED else "STAGE_FAILED",
                stage=attempt.stage,
                attempt=attempt.attempt,
                status=attempt.status.value,
                detail=attempt.error,
                failure_category=classify_campaign_failure(attempt.error),
            ))
    for audit in workspace.audit:
        if audit.entity_id not in entity_ids:
            continue
        events.append(CampaignEventView(
            event_id=audit.event_id,
            campaign_id=campaign.campaign_id,
            at=audit.at,
            event_type=f"AUDIT:{audit.action}",
            actor=audit.actor,
            entity_id=audit.entity_id,
            detail=audit.detail,
        ))
    return tuple(sorted(events, key=lambda x: (x.at, x.event_id)))


def compare_campaigns(workspace, baseline: CampaignExecutionRecord, candidate: CampaignExecutionRecord) -> CampaignEvidenceComparison:
    if baseline.family_id != candidate.family_id:
        raise ValueError("campaign comparison requires the same family")
    a = build_evidence_set_fingerprint(workspace, baseline)
    b = build_evidence_set_fingerprint(workspace, candidate)
    source_changed = a.source_sha256 != b.source_sha256
    target_changed = baseline.target_state != candidate.target_state
    execution_changed = a.execution_sha256 != b.execution_sha256
    details: list[str] = []
    if target_changed:
        state = EvidenceComparisonState.TARGET_CHANGED
        details.append("target certification state changed")
    elif source_changed:
        state = EvidenceComparisonState.SOURCE_CHANGED
        details.append("source snapshot semantics changed")
    elif a.evidence_sha256 != b.evidence_sha256:
        state = EvidenceComparisonState.EVIDENCE_CHANGED
        details.append("evidence/replay semantic fingerprint changed")
    elif execution_changed:
        state = EvidenceComparisonState.EXECUTION_CHANGED
        details.append("attempt/retry execution shape changed")
    else:
        state = EvidenceComparisonState.IDENTICAL
    return CampaignEvidenceComparison(
        baseline_campaign_id=baseline.campaign_id,
        candidate_campaign_id=candidate.campaign_id,
        state=state,
        baseline_fingerprint=a.evidence_sha256,
        candidate_fingerprint=b.evidence_sha256,
        source_snapshot_changed=source_changed,
        target_state_changed=target_changed,
        execution_shape_changed=execution_changed,
        details=tuple(details),
    )


def _current_state_from_qualification(qualification_service, family_id: str) -> CertificationState:
    if qualification_service is None:
        return CertificationState.RESEARCH
    manifest = qualification_service.current_manifest(family_id)
    if manifest is not None:
        return manifest.state
    workspace = qualification_service.workspace(family_id)
    if workspace.onboarding_plan is not None:
        return workspace.onboarding_plan.current_state
    return CertificationState.RESEARCH


def _handoff_package(qualification_service, dossier) -> str | None:
    if qualification_service is None:
        return None
    workspace = qualification_service.workspace(dossier.family_id)
    artifacts = {item.artifact for item in dossier.evidence}
    matching = [
        item for item in workspace.promotion_records
        if item.package.release_id == dossier.release_id
        and item.package.target_state == dossier.target_state
        and artifacts.issubset(set(item.package.evidence_artifacts))
    ]
    if not matching:
        return None
    return max(matching, key=lambda x: x.generated_at).package_id


def verify_campaign_export(export: CampaignQualificationExport) -> bool:
    payload = {
        "family_id": export.family_id,
        "release_id": export.release_id,
        "config_hash": export.config_hash,
        "campaign_id": export.campaign_id,
        "generated_at": export.generated_at.isoformat(),
        "readiness": export.readiness.model_dump(mode="json"),
        "dossier": export.dossier.model_dump(mode="json"),
        "events": [item.model_dump(mode="json") for item in export.events],
        "retention": export.retention.model_dump(mode="json"),
        "metadata": export.metadata,
    }
    return _canonical_hash(payload) == export.export_sha256


class CampaignObservabilityService:
    def __init__(
        self,
        repository: ShadowLaunchWorkspaceRepository,
        *,
        artifact_store: ArtifactStore,
        launch_policy_path: str | Path = "configs/launch/metrology_reference.yaml",
        slo_policy_path: str | Path = "configs/campaign/metrology_reference.yaml",
        retention_policy_path: str | Path = "configs/campaign/retention_reference.yaml",
        qualification_service=None,
    ) -> None:
        self.repository = repository
        self.artifact_store = artifact_store
        self.launch_policy = load_launch_policy(launch_policy_path)
        self.slo_policy = load_campaign_slo_policy(slo_policy_path)
        self.retention_policy = load_campaign_retention_policy(retention_policy_path)
        self.qualification_service = qualification_service

    def campaign(self, family_id: str, campaign_id: str) -> CampaignExecutionRecord:
        campaign = self.repository.campaign(family_id, campaign_id)
        if campaign is None:
            raise KeyError(campaign_id)
        return campaign

    def events(self, family_id: str, campaign_id: str) -> tuple[CampaignEventView, ...]:
        campaign = self.campaign(family_id, campaign_id)
        return campaign_events(self.repository.load(family_id), campaign)

    def reconciliation(self, family_id: str, campaign_id: str) -> CrossStageReconciliation:
        campaign = self.campaign(family_id, campaign_id)
        return reconcile_campaign(self.repository.load(family_id), campaign, artifact_store=self.artifact_store)

    def slo(self, family_id: str, campaign_id: str, *, now: datetime | None = None) -> CampaignSLOReport:
        return evaluate_campaign_slo(self.campaign(family_id, campaign_id), self.slo_policy, now=now)

    def retention(self, family_id: str, campaign_id: str, *, now: datetime | None = None) -> CampaignRetentionAssessment:
        campaign = self.campaign(family_id, campaign_id)
        return build_retention_assessment(
            self.repository.load(family_id), campaign, self.retention_policy, generated_at=now
        )

    def _dossier(
        self, family_id: str, campaign_id: str, *, generated_at: datetime,
        current_state: CertificationState | None = None,
    ):
        campaign = self.campaign(family_id, campaign_id)
        workspace = self.repository.load(family_id)
        evidence, replays, snapshots = _campaign_scope(workspace, campaign)
        reality = next((x for x in evidence if x.kind == LaunchEvidenceKind.DATA_REALITY), None)
        data_reality = None
        if reality is not None:
            if reality.artifact_ref is not None:
                from ephi.adapters.base.artifact_store import ArtifactRef
                path = self.artifact_store.materialize(ArtifactRef(
                    artifact_id=reality.artifact_ref.artifact_id,
                    content_hash=reality.artifact_ref.content_hash,
                    locator=reality.artifact_ref.locator,
                ))
            else:
                path = Path(reality.artifact)
            data_reality = capability_report_from_payload(json.loads(path.read_text(encoding="utf-8")))
        current_state = current_state or _current_state_from_qualification(self.qualification_service, family_id)
        return build_shadow_launch_dossier(
            family_id=family_id,
            release_id=campaign.release_id,
            config_hash=campaign.config_hash,
            current_state=current_state,
            target_state=campaign.target_state,
            policy=self.launch_policy,
            evidence=evidence,
            data_reality=data_reality,
            replay_manifests=replays,
            source_snapshots=snapshots,
            campaign_id=campaign_id,
            generated_at=generated_at,
            artifact_store=self.artifact_store,
        )

    def readiness(
        self, family_id: str, campaign_id: str, *, now: datetime | None = None,
        current_state: CertificationState | None = None,
    ) -> CampaignReadinessView:
        now = now or datetime.now(timezone.utc)
        campaign = self.campaign(family_id, campaign_id)
        workspace = self.repository.load(family_id)
        reconciliation = reconcile_campaign(workspace, campaign, artifact_store=self.artifact_store)
        slo = evaluate_campaign_slo(campaign, self.slo_policy, now=now)
        retention = build_retention_assessment(workspace, campaign, self.retention_policy, generated_at=now)
        dossier = self._dossier(family_id, campaign_id, generated_at=now, current_state=current_state)
        handoff_package_id = _handoff_package(self.qualification_service, dossier)
        blockers = list(reconciliation.blockers) + list(slo.blockers) + list(retention.blockers) + list(dossier.blockers)
        warnings = list(reconciliation.warnings)
        latest_failed = any(
            campaign.latest_attempt(stage) is not None
            and campaign.latest_attempt(stage).status == CampaignStageStatus.FAILED
            for stage in required_campaign_stages(campaign.target_state)
        )
        if handoff_package_id:
            state = CampaignReadinessState.HANDED_OFF
        elif latest_failed:
            state = CampaignReadinessState.FAILED
        elif blockers:
            required = required_campaign_stages(campaign.target_state)
            started = any(campaign.latest_attempt(stage) is not None for stage in required)
            state = CampaignReadinessState.BLOCKED if started else CampaignReadinessState.IN_PROGRESS
        elif dossier.promotion_ready:
            state = CampaignReadinessState.READY_FOR_HANDOFF
        else:
            state = CampaignReadinessState.IN_PROGRESS
        return CampaignReadinessView(
            family_id=family_id,
            release_id=campaign.release_id,
            config_hash=campaign.config_hash,
            campaign_id=campaign_id,
            target_state=campaign.target_state.value,
            generated_at=now,
            state=state,
            campaign=campaign,
            stages=build_stage_views(campaign, now=now),
            reconciliation=reconciliation,
            slo=slo,
            dossier_promotion_ready=dossier.promotion_ready,
            handoff_package_id=handoff_package_id,
            blockers=tuple(dict.fromkeys(blockers)),
            warnings=tuple(dict.fromkeys(warnings)),
        )

    def export(
        self, family_id: str, campaign_id: str, *, now: datetime | None = None,
        current_state: CertificationState | None = None,
    ) -> CampaignQualificationExport:
        now = now or datetime.now(timezone.utc)
        readiness = self.readiness(family_id, campaign_id, now=now, current_state=current_state)
        dossier = self._dossier(family_id, campaign_id, generated_at=now, current_state=current_state)
        events = self.events(family_id, campaign_id)
        retention = self.retention(family_id, campaign_id, now=now)
        payload = {
            "family_id": family_id,
            "release_id": readiness.release_id,
            "config_hash": readiness.config_hash,
            "campaign_id": campaign_id,
            "generated_at": now.isoformat(),
            "readiness": readiness.model_dump(mode="json"),
            "dossier": dossier.model_dump(mode="json"),
            "events": [item.model_dump(mode="json") for item in events],
            "retention": retention.model_dump(mode="json"),
            "metadata": {"export_format": "EPHI_CAMPAIGN_QUALIFICATION"},
        }
        digest = _canonical_hash(payload)
        return CampaignQualificationExport(
            family_id=family_id,
            release_id=readiness.release_id,
            config_hash=readiness.config_hash,
            campaign_id=campaign_id,
            generated_at=now,
            readiness=readiness,
            dossier=dossier,
            events=events,
            retention=retention,
            export_sha256=digest,
            metadata={"export_format": "EPHI_CAMPAIGN_QUALIFICATION"},
        )

    def publish_export(
        self,
        family_id: str,
        campaign_id: str,
        *,
        now: datetime | None = None,
        current_state: CertificationState | None = None,
    ) -> CampaignQualificationArtifact:
        from tempfile import TemporaryDirectory
        from ephi.domain.launch import LaunchArtifactReference

        export = self.export(family_id, campaign_id, now=now, current_state=current_state)
        if not verify_campaign_export(export):
            raise ValueError("campaign qualification export hash mismatch before publish")
        with TemporaryDirectory() as tmp:
            path = Path(tmp) / f"{campaign_id}.qualification.json"
            path.write_text(
                json.dumps(export.model_dump(mode="json"), sort_keys=True, indent=2) + "\n",
                encoding="utf-8",
            )
            ref = self.artifact_store.put(
                f"launch/{family_id}/{campaign_id}/qualification-export",
                path,
                metadata={
                    "family_id": family_id,
                    "campaign_id": campaign_id,
                    "release_id": export.release_id,
                    "config_hash": export.config_hash,
                    "export_sha256": export.export_sha256,
                },
            )
        return CampaignQualificationArtifact(
            family_id=family_id,
            campaign_id=campaign_id,
            export_sha256=export.export_sha256,
            artifact=LaunchArtifactReference(
                artifact_id=ref.artifact_id, content_hash=ref.content_hash, locator=ref.locator
            ),
            published_at=now or datetime.now(timezone.utc),
        )

    def compare(self, family_id: str, baseline_campaign_id: str, candidate_campaign_id: str) -> CampaignEvidenceComparison:
        workspace = self.repository.load(family_id)
        baseline = self.campaign(family_id, baseline_campaign_id)
        candidate = self.campaign(family_id, candidate_campaign_id)
        return compare_campaigns(workspace, baseline, candidate)
