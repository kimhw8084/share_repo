from __future__ import annotations

from datetime import datetime

from ephi.errors import MissingOptionalDependencyError, SchemaContractError


REQUIRED_EXECUTION_COLUMNS = (
    "execution_id",
    "asset_id",
    "event_time",
    "available_at",
    "operation",
    "recipe_id",
    "product_id",
    "technology",
    "material_id",
)


class ExecutionCanonicalizer:
    """Validate/reorder execution batches without row-object materialization."""

    def canonicalize(self, batch, *, as_of: datetime):
        try:
            import pyarrow as pa  # type: ignore
            import pyarrow.compute as pc  # type: ignore
        except ImportError as exc:
            raise MissingOptionalDependencyError(
                "Execution canonicalization requires `pip install -e '.[local]'`"
            ) from exc

        missing = [column for column in REQUIRED_EXECUTION_COLUMNS if column not in batch.column_names]
        if missing:
            raise SchemaContractError(f"Execution batch missing required columns: {missing}")

        visible = pc.less_equal(batch["available_at"], pa.scalar(as_of))
        result = batch.filter(visible).select(REQUIRED_EXECUTION_COLUMNS)

        invalid_time = pc.less(result["available_at"], result["event_time"])
        if pc.any(invalid_time).as_py():
            raise SchemaContractError("Canonical execution contains available_at < event_time")
        return result
