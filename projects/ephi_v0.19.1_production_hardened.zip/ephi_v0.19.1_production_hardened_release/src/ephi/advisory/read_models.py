from __future__ import annotations

from collections import defaultdict
from datetime import datetime

from ephi.domain.evidence import EvidenceChannel, EvidenceEffect, EvidenceItem, Hypothesis
from ephi.domain.exposure import ExposureSnapshot, MaterialExposureAssessment
from ephi.domain.priority import OperationalPriorityAssessment
from ephi.domain.episode import HealthEpisode
from ephi.domain.health import HealthAssessment
from ephi.domain.quality import QualityAssociationEvidence, QualityEvidenceState

from .models import (
    ComparisonSummary,
    ConfidenceLimiter,
    EpisodeAdvisoryContext,
    EpisodeHeader,
    EpisodeView,
    EvidenceView,
    ExposureSummary,
    HypothesisView,
    MeasurementSystemSummary,
    MaterialExposureItem,
    QualityStageSummary,
    TechnicalSeverity,
    TimelineEvent,
    VerificationRecommendation,
    WorkflowView,
)
from .policy import PresentationPolicy


def _band(value: float, policy: PresentationPolicy) -> str:
    if value >= policy.very_strong_net:
        return "VERY_STRONG"
    if value >= policy.strong_net:
        return "STRONG"
    if value >= policy.moderate_net:
        return "MODERATE"
    if value > 0.0:
        return "WEAK"
    return "NONE"


def _evidence_views(
    evidence: tuple[EvidenceItem, ...],
    *,
    hypothesis: Hypothesis,
    effect_kind: EvidenceEffect,
    limit: int = 4,
) -> tuple[EvidenceView, ...]:
    # Show at most one strongest item per dependency group. The product layer therefore
    # cannot visually manufacture "independent confirmation" from z/EWMA/CUSUM variants.
    best: dict[str, EvidenceView] = {}
    for item in evidence:
        for effect in item.effects:
            if effect.hypothesis != hypothesis or effect.effect != effect_kind:
                continue
            score = max(0.0, effect.strength) * max(0.0, min(1.0, item.confidence))
            view = EvidenceView(
                evidence_id=item.evidence_id,
                channel=item.channel,
                evidence_type=item.evidence_type,
                observation=item.observation,
                strength=max(0.0, effect.strength),
                confidence=max(0.0, min(1.0, item.confidence)),
                dependency_group=item.dependency_group,
                hypothesis=hypothesis,
                effect=effect_kind,
                reason_code=effect.reason_code,
                discriminating_score=score,
            )
            prior = best.get(item.dependency_group)
            if prior is None or view.discriminating_score > prior.discriminating_score:
                best[item.dependency_group] = view
    return tuple(sorted(best.values(), key=lambda x: x.discriminating_score, reverse=True)[:limit])


def all_evidence_views(
    evidence: tuple[EvidenceItem, ...],
    *,
    hypothesis: Hypothesis,
) -> tuple[EvidenceView, ...]:
    output: list[EvidenceView] = []
    for item in evidence:
        for effect in item.effects:
            if effect.hypothesis != hypothesis:
                continue
            output.append(
                EvidenceView(
                    evidence_id=item.evidence_id,
                    channel=item.channel,
                    evidence_type=item.evidence_type,
                    observation=item.observation,
                    strength=max(0.0, effect.strength),
                    confidence=max(0.0, min(1.0, item.confidence)),
                    dependency_group=item.dependency_group,
                    hypothesis=hypothesis,
                    effect=effect.effect,
                    reason_code=effect.reason_code,
                    discriminating_score=max(0.0, effect.strength) * max(0.0, min(1.0, item.confidence)),
                )
            )
    return tuple(sorted(output, key=lambda x: x.discriminating_score, reverse=True))


def _confidence_limiters(
    assessment: HealthAssessment,
    quality: tuple[QualityAssociationEvidence, ...],
    policy: PresentationPolicy,
) -> tuple[ConfidenceLimiter, ...]:
    output: list[ConfidenceLimiter] = []
    if assessment.confidence < policy.preferred_high_confidence:
        output.append(
            ConfidenceLimiter(
                code="ASSESSMENT_CONFIDENCE",
                description="Overall technical confidence is below the preferred high-confidence band.",
                confidence=assessment.confidence,
            )
        )
    low_evidence = sorted(
        (item for item in assessment.evidence if item.confidence < policy.low_evidence_confidence),
        key=lambda x: x.confidence,
    )
    seen_groups: set[str] = set()
    for item in low_evidence:
        if item.dependency_group in seen_groups:
            continue
        seen_groups.add(item.dependency_group)
        output.append(
            ConfidenceLimiter(
                code=f"LOW_EVIDENCE_CONFIDENCE:{item.dependency_group}",
                description=f"{item.channel.value} evidence has limited confidence.",
                confidence=item.confidence,
            )
        )
        if len(output) >= 3:
            break
    if assessment.maturity.value.endswith("PENDING") or assessment.maturity.value == "BEHAVIOR_ONLY":
        output.append(
            ConfidenceLimiter(
                code="QUALITY_MATURITY",
                description="Downstream quality evidence is not yet fully mature.",
                confidence=None,
            )
        )
    for assoc in quality:
        if assoc.evidence_state in {QualityEvidenceState.UNAVAILABLE, QualityEvidenceState.NOT_YET_MATURE}:
            output.append(
                ConfidenceLimiter(
                    code=f"QUALITY:{assoc.target_id}:{assoc.evidence_state.value}",
                    description=f"{assoc.target_id} is {assoc.evidence_state.value.lower().replace('_', ' ')}.",
                    confidence=assoc.association_confidence,
                )
            )
    return tuple(output[:5])


def _measurement_summary(assessment: HealthAssessment) -> MeasurementSystemSummary | None:
    channels = {
        EvidenceChannel.MEASUREMENT_SYSTEM_HEALTH,
        EvidenceChannel.CROSS_TOOL_MATCHING,
        EvidenceChannel.REPEATABILITY,
        EvidenceChannel.SPATIAL_STABILITY,
        EvidenceChannel.PRODUCTION_METROLOGY,
    }
    items = tuple(item for item in assessment.evidence if item.channel in channels)
    if not items and assessment.leading_hypothesis is not Hypothesis.METROLOGY_SYSTEM_SHIFT:
        return None

    def channel_state(channel: EvidenceChannel) -> str:
        matches = [item for item in items if item.channel is channel]
        if not matches:
            return "UNAVAILABLE"
        best = max(matches, key=lambda x: x.strength * x.confidence)
        return f"{best.evidence_type}: {best.observation}"

    support = next(
        (x for x in assessment.hypothesis_support if x.hypothesis is Hypothesis.METROLOGY_SYSTEM_SHIFT),
        None,
    )
    confidence = assessment.confidence
    return MeasurementSystemSummary(
        interpretation=(
            "Measurement-system shift supported"
            if assessment.leading_hypothesis is Hypothesis.METROLOGY_SYSTEM_SHIFT
            else "Measurement-system evidence available"
        ),
        confidence=confidence,
        reference_standard=channel_state(EvidenceChannel.MEASUREMENT_SYSTEM_HEALTH),
        cross_tool_matching=channel_state(EvidenceChannel.CROSS_TOOL_MATCHING),
        repeatability=channel_state(EvidenceChannel.REPEATABILITY),
        spatial_stability=channel_state(EvidenceChannel.SPATIAL_STABILITY),
        production_metrology=channel_state(EvidenceChannel.PRODUCTION_METROLOGY),
    )


def _norm_support(value: float) -> float:
    if value <= 0:
        return 0.0
    return min(1.0, value / 1.5)


def _quality_summary(associations: tuple[QualityAssociationEvidence, ...]) -> tuple[QualityStageSummary, ...]:
    return tuple(
        QualityStageSummary(
            target_id=item.target_id,
            stage=item.stage,
            state=item.evidence_state,
            association_confidence=item.association_confidence,
            adjusted_effect=item.adjusted_effect,
            exposed_count=item.exposed_count,
            control_count=item.control_count,
            contradictions=item.contradictions,
        )
        for item in associations
    )


def _recommendations(hypothesis: Hypothesis) -> tuple[VerificationRecommendation, ...]:
    recipes: dict[Hypothesis, tuple[tuple[str, str, tuple[Hypothesis, ...]], ...]] = {
        Hypothesis.METROLOGY_SYSTEM_SHIFT: (
            (
                "Run or review a reference-standard measurement on a matched healthy head/tool.",
                "Separates head-local measurement bias from a real production-material shift.",
                (Hypothesis.METROLOGY_SYSTEM_SHIFT, Hypothesis.COMMON_MODE_PROCESS_CHANGE),
            ),
            (
                "Compare the same material/characteristic on a compatible metrology peer.",
                "Cross-tool reproducibility is strongly discriminating for measurement-system attribution.",
                (Hypothesis.METROLOGY_SYSTEM_SHIFT, Hypothesis.LOCAL_ASSET_DEGRADATION),
            ),
        ),
        Hypothesis.LOCAL_ASSET_DEGRADATION: (
            (
                "Inspect the dominant physical feature/subsystem against the healthy reference and matched peers.",
                "Confirms that the deviation is local rather than context or fleet common mode.",
                (Hypothesis.LOCAL_ASSET_DEGRADATION, Hypothesis.COMMON_MODE_PROCESS_CHANGE),
            ),
            (
                "Review maintenance/calibration/component events around the estimated onset.",
                "Tests whether an intervention or wear transition explains the state change.",
                (Hypothesis.LOCAL_ASSET_DEGRADATION, Hypothesis.MAINTENANCE_TRANSITION),
            ),
        ),
        Hypothesis.COMMON_MODE_PROCESS_CHANGE: (
            (
                "Check shared recipe/process-regime changes near the common onset.",
                "A shared onset across compatible assets is more consistent with process/regime change than local hardware failure.",
                (Hypothesis.COMMON_MODE_PROCESS_CHANGE, Hypothesis.RECIPE_OR_PROCESS_REGIME_CHANGE),
            ),
        ),
        Hypothesis.DATA_PIPELINE_OR_SCHEMA_CHANGE: (
            (
                "Verify source units, schema revision, and collection completeness at the onset.",
                "Rules out data-pipeline transformation as the cause of the apparent physical change.",
                (Hypothesis.DATA_PIPELINE_OR_SCHEMA_CHANGE, Hypothesis.LOCAL_ASSET_DEGRADATION),
            ),
        ),
        Hypothesis.UPSTREAM_ROUTE_CONFOUNDING: (
            (
                "Compare affected material with route-matched controls before the suspect operation.",
                "Determines whether upstream exposure explains the downstream difference.",
                (Hypothesis.UPSTREAM_ROUTE_CONFOUNDING, Hypothesis.LOCAL_ASSET_DEGRADATION),
            ),
        ),
    }
    selected = recipes.get(
        hypothesis,
        (("Review the highest-confidence independent evidence channel.", "Improves attribution before operational action.", (hypothesis,)),),
    )
    return tuple(
        VerificationRecommendation(
            recommendation_id=f"VERIFY-{hypothesis.value}-{index}",
            rank=index,
            action=action,
            rationale=rationale,
            discriminates=discriminates,
        )
        for index, (action, rationale, discriminates) in enumerate(selected, start=1)
    )



def _exposure_summary(snapshot: ExposureSnapshot) -> ExposureSummary:
    return ExposureSummary(definitely_exposed=snapshot.definitely_exposed, possibly_exposed=snapshot.possibly_exposed, currently_committed=snapshot.currently_committed, quality_mature=snapshot.quality_mature, quality_pending=snapshot.quality_pending, future_possible_exposure=snapshot.future_possible, future_likely_exposure=snapshot.future_likely, future_preventable=snapshot.future_preventable, no_qualified_alternative=snapshot.no_qualified_alternative, as_of=snapshot.as_of, confidence=snapshot.confidence, earliest_future_eta=snapshot.earliest_future_eta)

def material_exposure_view(item: MaterialExposureAssessment) -> MaterialExposureItem:
    return MaterialExposureItem(material_id=item.material_id, exposure_class=item.exposure_class, exposure_start=item.exposure_start, exposure_end=item.exposure_end, exposure_confidence=item.exposure_confidence, suspect_execution_id=item.suspect_execution_id, suspect_execution_ids=item.suspect_execution_ids, route_position=item.route_position, quality_state=item.quality_state, preventability=item.preventability, route_likelihood=item.route_likelihood, eta=item.eta, alternatives=item.alternatives, reason_codes=item.reason_codes)

def build_episode_view(
    episode: HealthEpisode,
    assessment: HealthAssessment,
    *,
    advisory_context: EpisodeAdvisoryContext | None = None,
    quality_associations: tuple[QualityAssociationEvidence, ...] = (),
    exposure_snapshot: ExposureSnapshot | None = None,
    priority_assessment: OperationalPriorityAssessment | None = None,
    workflow: WorkflowView | None = None,
    episode_version: int = 1,
    presentation_policy: PresentationPolicy = PresentationPolicy(),
) -> EpisodeView:
    if episode.asset_id != assessment.asset_id:
        raise ValueError("episode/assessment asset mismatch")
    if episode.context != assessment.context:
        raise ValueError("episode/assessment context mismatch")

    advisory_context = advisory_context or EpisodeAdvisoryContext()
    workflow = workflow or WorkflowView()
    effective_exposure = _exposure_summary(exposure_snapshot) if exposure_snapshot is not None else advisory_context.exposure
    effective_priority = priority_assessment or advisory_context.priority_assessment
    overall_priority = effective_priority.overall_priority if effective_priority is not None else advisory_context.operational_priority
    leading = assessment.leading_hypothesis
    support = _evidence_views(assessment.evidence, hypothesis=leading, effect_kind=EvidenceEffect.SUPPORTS, limit=presentation_policy.top_support)
    contradiction = _evidence_views(
        assessment.evidence,
        hypothesis=leading,
        effect_kind=EvidenceEffect.CONTRADICTS,
        limit=presentation_policy.top_contradictions,
    )
    hypotheses = tuple(
        HypothesisView(
            hypothesis=item.hypothesis,
            support=item.support,
            contradiction=item.contradiction,
            net=item.net,
            band=_band(item.net, presentation_policy),
        )
        for item in sorted(assessment.hypothesis_support, key=lambda x: x.net, reverse=True)
    )
    estimated_onset = advisory_context.estimated_onset or episode.opened_at
    short_title = leading.value.replace("_", " ").title()
    strongest = support[0].observation if support else "No single supporting item dominates."
    summary = (
        f"{episode.asset_id} is {assessment.severity.name.lower()} with "
        f"{leading.value.replace('_', ' ').lower()} as the leading interpretation. "
        f"Strongest current evidence: {strongest}"
    )
    why_now = (
        f"EPHI opened/maintained this episode because behavioral novelty is "
        f"{assessment.behavioral_novelty:.2f} at technical confidence {assessment.confidence:.2f}."
    )
    timeline = [
        TimelineEvent(at=episode.opened_at, event_type="EPISODE_OPENED", summary="Health episode opened.", source="EPHI"),
        TimelineEvent(
            at=assessment.event_time,
            event_type="ASSESSMENT_UPDATED",
            summary=f"Assessment updated: {assessment.severity.name}; leading hypothesis {leading.value}.",
            source="EPHI",
        ),
    ]
    timeline.extend(advisory_context.timeline_events)
    timeline = sorted(timeline, key=lambda x: x.at)

    return EpisodeView(
        episode_version=episode_version,
        presentation_policy_version=presentation_policy.version,
        header=EpisodeHeader(
            episode_id=episode.episode_id,
            asset_id=episode.asset_id,
            context=episode.context.to_dict(),
            state=episode.state.value,
            technical_severity=TechnicalSeverity.from_health(assessment.severity),
            operational_priority=overall_priority,
            confidence=assessment.confidence,
            maturity=assessment.maturity,
            leading_hypothesis=leading,
            opened_at=episode.opened_at,
            last_updated_at=max(episode.last_updated_at, assessment.event_time),
            estimated_onset=estimated_onset,
            trend=advisory_context.trend,
        ),
        short_title=short_title,
        summary=summary,
        why_now=why_now,
        top_support=support,
        top_contradictions=contradiction,
        contradiction_summary=(
            "Material contradictory evidence is present."
            if contradiction
            else "No material contradictory evidence currently observed."
        ),
        confidence_limitations=_confidence_limiters(assessment, quality_associations, presentation_policy),
        hypotheses=hypotheses,
        comparison=advisory_context.comparison,
        measurement_system=_measurement_summary(assessment),
        quality=_quality_summary(quality_associations),
        exposure=effective_exposure,
        priority=effective_priority,
        recommended_verification=_recommendations(leading),
        timeline=tuple(timeline),
        workflow=workflow,
    )
