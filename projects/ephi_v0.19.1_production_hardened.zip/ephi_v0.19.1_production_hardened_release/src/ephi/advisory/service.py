from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from typing import Protocol

from ephi.domain.episode import HealthEpisode
from ephi.domain.exposure import ExposureSnapshot
from ephi.domain.priority import OperationalPriorityAssessment
from ephi.domain.health import HealthAssessment
from ephi.domain.quality import QualityAssociationEvidence

from .models import (
    AnalyticalRevision,
    AttentionQueueItem,
    ClosureFeedback,
    EpisodeAdvisoryContext,
    EpisodeView,
    EvidenceView,
    MaterialExposureItem,
    MissedEventReport,
    NotificationPayload,
    OperationalPriority,
    TechnicalSeverity,
    WorkflowMutation,
)
from .policy import PresentationPolicy
from .read_models import all_evidence_views, build_episode_view, material_exposure_view
from .workflow import WorkflowService


@dataclass(frozen=True, slots=True)
class AdvisoryEpisodeSource:
    episode: HealthEpisode
    assessment: HealthAssessment
    advisory_context: EpisodeAdvisoryContext = EpisodeAdvisoryContext()
    quality_associations: tuple[QualityAssociationEvidence, ...] = ()
    exposure_snapshot: ExposureSnapshot | None = None
    priority_assessment: OperationalPriorityAssessment | None = None


class AdvisorySourceRepository(Protocol):
    def get(self, episode_id: str) -> AdvisoryEpisodeSource | None:
        ...

    def list_episode_ids(self) -> tuple[str, ...]:
        ...

    def upsert(self, source: AdvisoryEpisodeSource) -> None:
        ...


@dataclass(slots=True)
class InMemoryAdvisorySourceRepository:
    _items: dict[str, AdvisoryEpisodeSource] = field(default_factory=dict)

    def get(self, episode_id: str) -> AdvisoryEpisodeSource | None:
        return self._items.get(episode_id)

    def list_episode_ids(self) -> tuple[str, ...]:
        return tuple(self._items)

    def upsert(self, source: AdvisoryEpisodeSource) -> None:
        self._items[source.episode.episode_id] = source


@dataclass(slots=True)
class AdvisoryService:
    """Read-model + workflow facade over authoritative EPHI domain objects."""

    sources: AdvisorySourceRepository = field(default_factory=InMemoryAdvisorySourceRepository)
    workflow: WorkflowService = field(default_factory=WorkflowService)
    presentation_policy: PresentationPolicy = field(default_factory=PresentationPolicy)
    _versions: dict[str, int] = field(default_factory=dict)
    _missed_events: list[MissedEventReport] = field(default_factory=list)
    _missed_counter: int = 0
    _view_cache: dict[tuple[str, int, str], EpisodeView] = field(default_factory=dict)
    _analytical_revisions: dict[str, list[AnalyticalRevision]] = field(default_factory=dict)

    def upsert_source(self, source: AdvisoryEpisodeSource, *, source_version: int | None = None) -> int:
        episode_id = source.episode.episode_id
        self.sources.upsert(source)
        self._versions[episode_id] = (
            int(source_version) if source_version is not None else self._versions.get(episode_id, 0) + 1
        )
        revision = AnalyticalRevision(
            source_version=self._versions[episode_id],
            at=source.assessment.event_time,
            technical_severity=TechnicalSeverity.from_health(source.assessment.severity),
            confidence=source.assessment.confidence,
            maturity=source.assessment.maturity,
            leading_hypothesis=source.assessment.leading_hypothesis,
            behavioral_novelty=source.assessment.behavioral_novelty,
        )
        revisions = self._analytical_revisions.setdefault(episode_id, [])
        if not revisions or revisions[-1] != revision:
            revisions.append(revision)
        self._invalidate_cache(episode_id)
        return self._versions[episode_id]

    def exists(self, episode_id: str) -> bool:
        return self.sources.get(episode_id) is not None

    def _invalidate_cache(self, episode_id: str) -> None:
        for key in [key for key in self._view_cache if key[0] == episode_id]:
            self._view_cache.pop(key, None)

    def get_view(self, episode_id: str) -> EpisodeView:
        source = self.sources.get(episode_id)
        if source is None:
            raise KeyError(f"unknown episode: {episode_id}")
        version = self._versions[episode_id]
        key = (episode_id, version, self.presentation_policy.version)
        cached = self._view_cache.get(key)
        if cached is not None:
            return cached
        view = build_episode_view(
            source.episode,
            source.assessment,
            advisory_context=source.advisory_context,
            quality_associations=source.quality_associations,
            exposure_snapshot=source.exposure_snapshot,
            priority_assessment=source.priority_assessment,
            workflow=self.workflow.get(episode_id),
            episode_version=version,
            presentation_policy=self.presentation_policy,
        )
        view = view.model_copy(update={
            "analytical_revisions": tuple(self._analytical_revisions.get(episode_id, ())),
        })
        self._view_cache[key] = view
        return view

    def evidence(
        self,
        episode_id: str,
        *,
        polarity: str | None = None,
        channel: str | None = None,
    ) -> tuple[EvidenceView, ...]:
        source = self.sources.get(episode_id)
        if source is None:
            raise KeyError(f"unknown episode: {episode_id}")
        items = all_evidence_views(
            source.assessment.evidence,
            hypothesis=source.assessment.leading_hypothesis,
        )
        if polarity is not None:
            items = tuple(item for item in items if item.effect.value == polarity)
        if channel is not None:
            items = tuple(item for item in items if item.channel.value == channel)
        return items

    def material_exposure(self, episode_id: str) -> tuple[MaterialExposureItem, ...]:
        source = self.sources.get(episode_id)
        if source is None: raise KeyError(f"unknown episode: {episode_id}")
        if source.exposure_snapshot is not None: return tuple(material_exposure_view(item) for item in source.exposure_snapshot.items)
        return source.advisory_context.material_exposure_items

    def exposure_snapshot(self, episode_id: str) -> ExposureSnapshot:
        source=self.sources.get(episode_id)
        if source is None: raise KeyError(f"unknown episode: {episode_id}")
        if source.exposure_snapshot is None: raise KeyError(f"exposure unavailable for episode: {episode_id}")
        return source.exposure_snapshot

    def priority_assessment(self, episode_id: str) -> OperationalPriorityAssessment:
        source=self.sources.get(episode_id)
        if source is None: raise KeyError(f"unknown episode: {episode_id}")
        if source.priority_assessment is None: raise KeyError(f"priority unavailable for episode: {episode_id}")
        return source.priority_assessment

    def update_operational_state(self, episode_id: str, *, exposure_snapshot: ExposureSnapshot, priority_assessment: OperationalPriorityAssessment) -> EpisodeView:
        source=self.sources.get(episode_id)
        if source is None: raise KeyError(f"unknown episode: {episode_id}")
        if exposure_snapshot.episode_id != episode_id or priority_assessment.episode_id != episode_id: raise ValueError("operational update episode mismatch")
        self.sources.upsert(replace(source, exposure_snapshot=exposure_snapshot, priority_assessment=priority_assessment))
        self._versions[episode_id]=self._versions.get(episode_id,0)+1
        self._invalidate_cache(episode_id)
        return self.get_view(episode_id)

    def list_attention(self) -> tuple[AttentionQueueItem, ...]:
        items: list[AttentionQueueItem] = []
        for episode_id in self.sources.list_episode_ids():
            view = self.get_view(episode_id)
            if view.header.state == "RESOLVED" or view.workflow.state.value in {
                "RESOLVED",
                "BENIGN",
                "DATA_ISSUE",
                "DUPLICATE",
            }:
                continue
            items.append(
                AttentionQueueItem(
                    episode_id=episode_id,
                    asset_id=view.header.asset_id,
                    short_title=view.short_title,
                    technical_severity=view.header.technical_severity,
                    operational_priority=view.header.operational_priority,
                    confidence=view.header.confidence,
                    leading_hypothesis=view.header.leading_hypothesis,
                    opened_at=view.header.opened_at,
                    last_updated_at=view.header.last_updated_at,
                    trend=view.header.trend,
                    workflow_state=view.workflow.state,
                    future_preventable=view.exposure.future_preventable,
                )
            )
        priority_rank = {
            OperationalPriority.P1: 0,
            OperationalPriority.P2: 1,
            OperationalPriority.P3: 2,
            OperationalPriority.P4: 3,
        }
        return tuple(
            sorted(
                items,
                key=lambda x: (
                    priority_rank.get(x.operational_priority, 9),
                    -{
                        TechnicalSeverity.UNKNOWN: 0,
                        TechnicalSeverity.NORMAL: 1,
                        TechnicalSeverity.OBSERVE: 2,
                        TechnicalSeverity.MONITOR: 3,
                        TechnicalSeverity.INVESTIGATE: 4,
                        TechnicalSeverity.URGENT: 5,
                    }[x.technical_severity],
                    -x.confidence,
                    x.opened_at,
                ),
            )
        )

    def mutate_workflow(self, episode_id: str, mutation: WorkflowMutation) -> EpisodeView:
        if self.sources.get(episode_id) is None:
            raise KeyError(f"unknown episode: {episode_id}")
        self.workflow.mutate(episode_id, mutation)
        self._versions[episode_id] += 1
        self._invalidate_cache(episode_id)
        return self.get_view(episode_id)

    def close(self, episode_id: str, feedback: ClosureFeedback) -> EpisodeView:
        if self.sources.get(episode_id) is None:
            raise KeyError(f"unknown episode: {episode_id}")
        self.workflow.close(episode_id, feedback)
        self._versions[episode_id] += 1
        self._invalidate_cache(episode_id)
        return self.get_view(episode_id)

    def notification(self, episode_id: str, *, base_path: str = "/v1/episodes") -> NotificationPayload:
        view = self.get_view(episode_id)
        return NotificationPayload(
            episode_id=episode_id,
            episode_version=view.episode_version,
            asset_id=view.header.asset_id,
            severity=view.header.technical_severity,
            operational_priority=view.header.operational_priority,
            confidence=view.header.confidence,
            short_title=view.short_title,
            summary=view.summary,
            estimated_onset=view.header.estimated_onset,
            top_support=tuple(item.observation for item in view.top_support[:3]),
            top_contradiction=(view.top_contradictions[0].observation if view.top_contradictions else None),
            past_exposure=view.exposure.definitely_exposed + view.exposure.possibly_exposed,
            future_preventable_exposure=view.exposure.future_preventable,
            recommended_verification=(
                view.recommended_verification[0].action if view.recommended_verification else None
            ),
            deep_link=f"{base_path}/{episode_id}",
        )

    def create_missed_event(
        self,
        *,
        asset_id: str,
        start_time: datetime,
        reporter: str,
        description: str,
        end_time: datetime | None = None,
        context: dict[str, str] | None = None,
        external_event_type: str | None = None,
        created_at: datetime | None = None,
    ) -> MissedEventReport:
        self._missed_counter += 1
        report = MissedEventReport(
            report_id=f"MISS-{self._missed_counter:06d}",
            asset_id=asset_id,
            start_time=start_time,
            end_time=end_time,
            context=context or {},
            reporter=reporter,
            description=description,
            external_event_type=external_event_type,
            created_at=created_at or datetime.now(timezone.utc),
        )
        self._missed_events.append(report)
        return report

    def missed_events(self) -> tuple[MissedEventReport, ...]:
        return tuple(self._missed_events)

    def export_state(self) -> dict[str, object]:
        return {
            "schema": "advisory_state_v1",
            "presentation_policy_version": self.presentation_policy.version,
            "versions": dict(self._versions),
            "workflow": self.workflow.export_state(),
            "analytical_revisions": {
                key: [item.model_dump(mode="json") for item in value]
                for key, value in self._analytical_revisions.items()
            },
            "missed_counter": self._missed_counter,
            "missed_events": [item.model_dump(mode="json") for item in self._missed_events],
        }

    def restore_state(self, state: dict[str, object]) -> None:
        if state.get("schema") != "advisory_state_v1":
            raise ValueError(f"Unsupported advisory checkpoint schema: {state.get('schema')!r}")
        workflow_raw = state.get("workflow", {})
        versions_raw = state.get("versions", {})
        missed_raw = state.get("missed_events", [])
        revisions_raw = state.get("analytical_revisions", {})
        if not isinstance(workflow_raw, dict) or not isinstance(versions_raw, dict) or not isinstance(missed_raw, list) or not isinstance(revisions_raw, dict):
            raise TypeError("invalid advisory checkpoint")
        self.workflow.restore_state(workflow_raw)
        self._versions = {str(key): int(value) for key, value in versions_raw.items()}
        self._missed_counter = int(state.get("missed_counter", 0))
        self._missed_events = [MissedEventReport.model_validate(value) for value in missed_raw]
        self._analytical_revisions = {
            str(key): [AnalyticalRevision.model_validate(item) for item in value]
            for key, value in revisions_raw.items()
            if isinstance(value, list)
        }
        self._view_cache.clear()
