from __future__ import annotations

from datetime import datetime, timedelta, timezone

from ephi.domain.context import ContextKey
from ephi.domain.evidence import EvidenceChannel, EvidenceEffect, EvidenceItem, Hypothesis, HypothesisEffect
from ephi.domain.episode import EpisodeState, HealthEpisode
from ephi.domain.health import AssessmentMaturity, HealthAssessment, HealthSeverity, HypothesisSupport
from ephi.domain.quality import QualityAssociationEvidence, QualityEvidenceState, QualityStage

from .models import (
    ComparisonSummary,
    EpisodeAdvisoryContext,
    ExposureSummary,
    MaterialExposureClass,
    MaterialExposureItem,
    PreventabilityState,
    TimelineEvent,
)
from .service import AdvisoryEpisodeSource, AdvisoryService


def build_demo_advisory_service() -> AdvisoryService:
    now = datetime(2026, 8, 19, 14, 0, tzinfo=timezone.utc)
    context = ContextKey("METRO_OP", "MET_RECIPE_A", "PROD_X", "TECH_1")
    evidence = (
        EvidenceItem(
            evidence_id="EV-REF",
            asset_id="METRO001/HEAD_A",
            execution_id="M-9001",
            event_time=now,
            channel=EvidenceChannel.MEASUREMENT_SYSTEM_HEALTH,
            evidence_type="REFERENCE_STANDARD_BIAS",
            observation="reference-standard bias shifted +0.74 units and persisted",
            strength=0.92,
            confidence=0.91,
            dependency_group="METRO_REFERENCE",
            effects=(HypothesisEffect(Hypothesis.METROLOGY_SYSTEM_SHIFT, EvidenceEffect.SUPPORTS, 0.92, "REFERENCE_BIAS"),),
        ),
        EvidenceItem(
            evidence_id="EV-XTOOL",
            asset_id="METRO001/HEAD_A",
            execution_id="M-9001",
            event_time=now,
            channel=EvidenceChannel.CROSS_TOOL_MATCHING,
            evidence_type="CROSS_HEAD_RESIDUAL",
            observation="HEAD_A diverged from two compatible healthy heads",
            strength=0.86,
            confidence=0.88,
            dependency_group="METRO_CROSS_TOOL",
            effects=(HypothesisEffect(Hypothesis.METROLOGY_SYSTEM_SHIFT, EvidenceEffect.SUPPORTS, 0.86, "CROSS_HEAD_MISMATCH"),),
        ),
        EvidenceItem(
            evidence_id="EV-FLEET",
            asset_id="METRO001/HEAD_A",
            execution_id="M-9001",
            event_time=now,
            channel=EvidenceChannel.FLEET_COMMON_MODE,
            evidence_type="FLEET_SHIFT",
            observation="compatible metrology peers remain stable",
            strength=0.72,
            confidence=0.90,
            dependency_group="FLEET",
            effects=(
                HypothesisEffect(Hypothesis.METROLOGY_SYSTEM_SHIFT, EvidenceEffect.SUPPORTS, 0.72, "LOCALIZED_TO_HEAD"),
                HypothesisEffect(Hypothesis.COMMON_MODE_PROCESS_CHANGE, EvidenceEffect.CONTRADICTS, 0.72, "PEERS_STABLE"),
            ),
        ),
        EvidenceItem(
            evidence_id="EV-PROD",
            asset_id="METRO001/HEAD_A",
            execution_id="M-9001",
            event_time=now,
            channel=EvidenceChannel.PRODUCTION_METROLOGY,
            evidence_type="PRODUCTION_SHIFT",
            observation="production-wafer mean shift is weak relative to reference-standard shift",
            strength=0.42,
            confidence=0.72,
            dependency_group="PRODUCTION_METROLOGY",
            effects=(HypothesisEffect(Hypothesis.METROLOGY_SYSTEM_SHIFT, EvidenceEffect.CONTRADICTS, 0.22, "WEAK_PRODUCTION_SHIFT"),),
        ),
    )
    supports = (
        HypothesisSupport(Hypothesis.METROLOGY_SYSTEM_SHIFT, 2.10, 0.16),
        HypothesisSupport(Hypothesis.LOCAL_ASSET_DEGRADATION, 0.42, 0.15),
        HypothesisSupport(Hypothesis.COMMON_MODE_PROCESS_CHANGE, 0.10, 0.65),
        HypothesisSupport(Hypothesis.RECIPE_OR_PROCESS_REGIME_CHANGE, 0.08, 0.15),
        HypothesisSupport(Hypothesis.UPSTREAM_ROUTE_CONFOUNDING, 0.0, 0.0),
        HypothesisSupport(Hypothesis.MAINTENANCE_TRANSITION, 0.15, 0.0),
        HypothesisSupport(Hypothesis.DATA_PIPELINE_OR_SCHEMA_CHANGE, 0.0, 0.4),
        HypothesisSupport(Hypothesis.BENIGN_NOVELTY, 0.0, 0.7),
        HypothesisSupport(Hypothesis.INSUFFICIENT_INFORMATION, 0.0, 0.0),
    )
    assessment = HealthAssessment(
        assessment_id="HA-DEMO",
        execution_id="M-9001",
        asset_id="METRO001/HEAD_A",
        context=context,
        event_time=now,
        severity=HealthSeverity.INVESTIGATE,
        confidence=0.88,
        behavioral_novelty=0.78,
        leading_hypothesis=Hypothesis.METROLOGY_SYSTEM_SHIFT,
        hypothesis_support=supports,
        evidence=evidence,
        maturity=AssessmentMaturity.EARLY_QUALITY_PENDING,
    )
    episode = HealthEpisode(
        episode_id="EPHI-E000101",
        asset_id=assessment.asset_id,
        context=context,
        opened_at=now - timedelta(minutes=42),
        last_updated_at=now,
        state=EpisodeState.INVESTIGATE,
        severity=HealthSeverity.INVESTIGATE,
        leading_hypothesis=assessment.leading_hypothesis,
        peak_behavioral_novelty=0.82,
    )
    quality = QualityAssociationEvidence(
        target_id="inline_cd",
        target_version="1.0.0",
        stage=QualityStage.INLINE_METROLOGY,
        evidence_state=QualityEvidenceState.NOT_YET_MATURE,
        exposed_count=146,
        control_count=0,
        temporal_consistency=0.0,
        control_robustness=0.0,
        sampling_confidence=0.70,
        measurement_integrity_confidence=0.55,
        maturity_confidence=0.25,
        association_confidence=0.20,
    )
    advisory_context = EpisodeAdvisoryContext(
        comparison=ComparisonSummary(
            self_reference_label="current AssetEpoch validated healthy history",
            reference_count=18462,
            reference_effective_count=15120.0,
            reference_confidence=0.94,
            peer_asset_ids=("METRO001/HEAD_B", "METRO001/HEAD_C"),
            peer_confidence=0.91,
            fallback_level="NONE",
        ),
        exposure=ExposureSummary(
            definitely_exposed=146,
            possibly_exposed=31,
            quality_mature=92,
            quality_pending=85,
            future_likely_exposure=214,
            future_preventable=168,
            no_qualified_alternative=46,
            as_of=now,
            confidence=0.78,
        ),
        material_exposure_items=(
            MaterialExposureItem(
                material_id="WAFER-001",
                exposure_class=MaterialExposureClass.DEFINITE_PAST_EXPOSURE,
                exposure_start=now - timedelta(hours=2),
                exposure_confidence=0.96,
                suspect_execution_id="M-8501",
                quality_state="INLINE_MATURE",
                preventability=PreventabilityState.NOT_APPLICABLE,
            ),
            MaterialExposureItem(
                material_id="WAFER-900",
                exposure_class=MaterialExposureClass.FUTURE_PREVENTABLE_EXPOSURE,
                exposure_confidence=0.82,
                route_position="2 operations upstream",
                quality_state="NOT_YET_EXPOSED",
                preventability=PreventabilityState.HIGH,
            ),
        ),
        operational_priority="P1",
        trend="WORSENING",
        estimated_onset=now - timedelta(hours=3, minutes=6),
        timeline_events=(
            TimelineEvent(at=now - timedelta(hours=4), event_type="CALIBRATION", summary="Calibration completed.", source="MAINTENANCE"),
        ),
    )
    service = AdvisoryService()
    service.upsert_source(
        AdvisoryEpisodeSource(
            episode=episode,
            assessment=assessment,
            advisory_context=advisory_context,
            quality_associations=(quality,),
        )
    )
    return service
