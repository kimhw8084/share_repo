from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from ephi.domain.evidence import EvidenceChannel, EvidenceEffect, Hypothesis
from ephi.domain.exposure import AlternativeAssetAssessment, MaterialExposureClass, PreventabilityState, RouteExposureLikelihood
from ephi.domain.health import AssessmentMaturity, HealthSeverity
from ephi.domain.priority import OperationalPriority, OperationalPriorityAssessment
from ephi.domain.quality import QualityEvidenceState, QualityStage


class AdvisoryWorkflowState(StrEnum):
    NEW = "NEW"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    INVESTIGATING = "INVESTIGATING"
    ACTION_TAKEN = "ACTION_TAKEN"
    MONITORING_RECOVERY = "MONITORING_RECOVERY"
    RESOLVED = "RESOLVED"
    BENIGN = "BENIGN"
    DATA_ISSUE = "DATA_ISSUE"
    DUPLICATE = "DUPLICATE"
    UNRESOLVED = "UNRESOLVED"


class TechnicalSeverity(StrEnum):
    UNKNOWN = "UNKNOWN"
    NORMAL = "NORMAL"
    OBSERVE = "OBSERVE"
    MONITOR = "MONITOR"
    INVESTIGATE = "INVESTIGATE"
    URGENT = "URGENT"

    @classmethod
    def from_health(cls, severity: HealthSeverity) -> "TechnicalSeverity":
        return cls[severity.name]


class EvidenceView(BaseModel):
    model_config = ConfigDict(frozen=True)

    evidence_id: str
    channel: EvidenceChannel
    evidence_type: str
    observation: str
    strength: float = Field(ge=0.0)
    confidence: float = Field(ge=0.0, le=1.0)
    dependency_group: str
    hypothesis: Hypothesis
    effect: EvidenceEffect
    reason_code: str
    discriminating_score: float = Field(ge=0.0)


class ConfidenceLimiter(BaseModel):
    model_config = ConfigDict(frozen=True)

    code: str
    description: str
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)


class HypothesisView(BaseModel):
    model_config = ConfigDict(frozen=True)

    hypothesis: Hypothesis
    support: float
    contradiction: float
    net: float
    band: str


class ComparisonSummary(BaseModel):
    model_config = ConfigDict(frozen=True)

    self_reference_label: str = "validated healthy reference"
    reference_count: int | None = Field(default=None, ge=0)
    reference_effective_count: float | None = Field(default=None, ge=0.0)
    reference_confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    peer_asset_ids: tuple[str, ...] = ()
    peer_confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    fallback_level: str | None = None
    excluded_peer_reasons: tuple[str, ...] = ()


class MeasurementSystemSummary(BaseModel):
    model_config = ConfigDict(frozen=True)

    interpretation: str
    confidence: float = Field(ge=0.0, le=1.0)
    reference_standard: str
    cross_tool_matching: str
    repeatability: str
    spatial_stability: str
    production_metrology: str


class QualityStageSummary(BaseModel):
    model_config = ConfigDict(frozen=True)

    target_id: str
    stage: QualityStage
    state: QualityEvidenceState
    association_confidence: float = Field(ge=0.0, le=1.0)
    adjusted_effect: float | None = None
    exposed_count: int = Field(ge=0)
    control_count: int = Field(ge=0)
    contradictions: tuple[str, ...] = ()


class ExposureSummary(BaseModel):
    model_config = ConfigDict(frozen=True)

    definitely_exposed: int = Field(default=0, ge=0)
    possibly_exposed: int = Field(default=0, ge=0)
    currently_committed: int = Field(default=0, ge=0)
    quality_mature: int = Field(default=0, ge=0)
    quality_pending: int = Field(default=0, ge=0)
    future_possible_exposure: int = Field(default=0, ge=0)
    future_likely_exposure: int = Field(default=0, ge=0)
    future_preventable: int = Field(default=0, ge=0)
    no_qualified_alternative: int = Field(default=0, ge=0)
    as_of: datetime | None = None
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    earliest_future_eta: datetime | None = None


class MaterialExposureItem(BaseModel):
    model_config = ConfigDict(frozen=True)

    material_id: str
    exposure_class: MaterialExposureClass
    exposure_start: datetime | None = None
    exposure_end: datetime | None = None
    exposure_confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    suspect_execution_id: str | None = None
    suspect_execution_ids: tuple[str, ...] = ()
    route_position: str | None = None
    quality_state: str | None = None
    preventability: PreventabilityState = PreventabilityState.UNKNOWN
    route_likelihood: RouteExposureLikelihood | None = None
    eta: datetime | None = None
    alternatives: tuple[AlternativeAssetAssessment, ...] = ()
    reason_codes: tuple[str, ...] = ()


class VerificationRecommendation(BaseModel):
    model_config = ConfigDict(frozen=True)

    recommendation_id: str
    rank: int = Field(ge=1)
    action: str
    rationale: str
    discriminates: tuple[Hypothesis, ...] = ()


class TimelineEvent(BaseModel):
    model_config = ConfigDict(frozen=True)

    at: datetime
    event_type: str
    summary: str
    source: str


class AnalyticalRevision(BaseModel):
    model_config = ConfigDict(frozen=True)

    source_version: int = Field(ge=1)
    at: datetime
    technical_severity: TechnicalSeverity
    confidence: float = Field(ge=0.0, le=1.0)
    maturity: AssessmentMaturity
    leading_hypothesis: Hypothesis
    behavioral_novelty: float = Field(ge=0.0)


class WorkflowView(BaseModel):
    model_config = ConfigDict(frozen=True)

    state: AdvisoryWorkflowState = AdvisoryWorkflowState.NEW
    owner: str | None = None
    acknowledged_by: str | None = None
    acknowledged_at: datetime | None = None
    updated_at: datetime | None = None
    resolution_category: str | None = None


class EpisodeHeader(BaseModel):
    model_config = ConfigDict(frozen=True)

    episode_id: str
    asset_id: str
    context: dict[str, str]
    state: str
    technical_severity: TechnicalSeverity
    operational_priority: OperationalPriority
    confidence: float = Field(ge=0.0, le=1.0)
    maturity: AssessmentMaturity
    leading_hypothesis: Hypothesis
    opened_at: datetime
    last_updated_at: datetime
    estimated_onset: datetime
    trend: str


class EpisodeView(BaseModel):
    model_config = ConfigDict(frozen=True)

    episode_version: int = Field(ge=1)
    presentation_policy_version: str
    header: EpisodeHeader
    short_title: str
    summary: str
    why_now: str
    top_support: tuple[EvidenceView, ...]
    top_contradictions: tuple[EvidenceView, ...]
    contradiction_summary: str
    confidence_limitations: tuple[ConfidenceLimiter, ...]
    hypotheses: tuple[HypothesisView, ...]
    comparison: ComparisonSummary
    measurement_system: MeasurementSystemSummary | None
    quality: tuple[QualityStageSummary, ...]
    exposure: ExposureSummary
    priority: OperationalPriorityAssessment | None = None
    recommended_verification: tuple[VerificationRecommendation, ...]
    timeline: tuple[TimelineEvent, ...]
    analytical_revisions: tuple[AnalyticalRevision, ...] = ()
    workflow: WorkflowView


class AttentionQueueItem(BaseModel):
    model_config = ConfigDict(frozen=True)

    episode_id: str
    asset_id: str
    short_title: str
    technical_severity: TechnicalSeverity
    operational_priority: OperationalPriority
    confidence: float = Field(ge=0.0, le=1.0)
    leading_hypothesis: Hypothesis
    opened_at: datetime
    last_updated_at: datetime
    trend: str
    workflow_state: AdvisoryWorkflowState
    future_preventable: int = Field(default=0, ge=0)


class NotificationPayload(BaseModel):
    model_config = ConfigDict(frozen=True)

    episode_id: str
    episode_version: int = Field(ge=1)
    asset_id: str
    severity: TechnicalSeverity
    operational_priority: OperationalPriority
    confidence: float = Field(ge=0.0, le=1.0)
    short_title: str
    summary: str
    estimated_onset: datetime
    top_support: tuple[str, ...]
    top_contradiction: str | None
    past_exposure: int = Field(default=0, ge=0)
    future_preventable_exposure: int = Field(default=0, ge=0)
    recommended_verification: str | None
    deep_link: str


class EpisodeAdvisoryContext(BaseModel):
    """Optional presentation context produced by already-authoritative subsystems.

    This object carries comparison/exposure metadata into the read model. It does not
    change analytical conclusions.
    """

    model_config = ConfigDict(frozen=True)

    comparison: ComparisonSummary = Field(default_factory=ComparisonSummary)
    exposure: ExposureSummary = Field(default_factory=ExposureSummary)
    material_exposure_items: tuple[MaterialExposureItem, ...] = ()
    operational_priority: OperationalPriority = OperationalPriority.P3
    priority_assessment: OperationalPriorityAssessment | None = None
    trend: str = "PERSISTENT"
    estimated_onset: datetime | None = None
    timeline_events: tuple[TimelineEvent, ...] = ()


class WorkflowMutation(BaseModel):
    model_config = ConfigDict(frozen=True)

    actor: str
    state: AdvisoryWorkflowState | None = None
    owner: str | None = None
    note: str | None = None
    resolution_category: str | None = None


class ClosureFeedback(BaseModel):
    model_config = ConfigDict(frozen=True)

    actor: str
    behavior_confirmed: str = Field(pattern="^(YES|NO|UNCERTAIN)$")
    quality_affected: str = Field(pattern="^(YES|NO|UNKNOWN)$")
    likely_category: str
    action_taken: str | None = None
    action_resolved_state: str = Field(pattern="^(YES|NO|PARTIAL|UNKNOWN)$")
    confidence: str = Field(pattern="^(HIGH|MEDIUM|LOW)$")
    note: str | None = None


class ClosureRecord(BaseModel):
    model_config = ConfigDict(frozen=True)

    episode_id: str
    submitted_at: datetime
    feedback: ClosureFeedback


class AuditEvent(BaseModel):
    model_config = ConfigDict(frozen=True)

    audit_id: str
    episode_id: str
    at: datetime
    actor: str
    action: str
    previous: dict[str, Any]
    current: dict[str, Any]
    reason: str | None = None


class MissedEventReport(BaseModel):
    model_config = ConfigDict(frozen=True)

    report_id: str
    asset_id: str
    start_time: datetime
    end_time: datetime | None = None
    context: dict[str, str] = Field(default_factory=dict)
    reporter: str
    description: str
    external_event_type: str | None = None
    created_at: datetime
