from __future__ import annotations

import json

from ephi.adapters.base.state_store import StateStore

from .service import AdvisoryService

CHECKPOINT_SCHEMA = "advisory_state_v1"


def save_advisory_state(
    service: AdvisoryService,
    state_store: StateStore,
    *,
    key: str = "product:advisory",
    expected_version: int | None = None,
) -> int:
    payload = service.export_state()
    record = state_store.compare_and_set(
        key,
        expected_version=expected_version,
        value=json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8"),
    )
    return record.version


def restore_advisory_state(
    service: AdvisoryService,
    state_store: StateStore,
    *,
    key: str = "product:advisory",
) -> int | None:
    record = state_store.get(key)
    if record is None:
        return None
    payload = json.loads(record.value.decode("utf-8"))
    if payload.get("schema") != CHECKPOINT_SCHEMA:
        raise ValueError(f"Unsupported advisory checkpoint schema: {payload.get('schema')!r}")
    service.restore_state(payload)
    return record.version
