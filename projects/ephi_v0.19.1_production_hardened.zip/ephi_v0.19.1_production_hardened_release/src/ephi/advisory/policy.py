from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel, ConfigDict, Field


class PresentationPolicy(BaseModel):
    """Versioned display-only policy.

    It controls ranking/bands in the read model and cannot change analytical severity,
    hypothesis support, or evidence polarity.
    """

    model_config = ConfigDict(frozen=True)

    version: str = "advisory-v1"
    top_support: int = Field(default=4, ge=1, le=10)
    top_contradictions: int = Field(default=4, ge=1, le=10)
    moderate_net: float = 0.45
    strong_net: float = 0.90
    very_strong_net: float = 1.50
    preferred_high_confidence: float = Field(default=0.75, ge=0.0, le=1.0)
    low_evidence_confidence: float = Field(default=0.50, ge=0.0, le=1.0)


def load_presentation_policy(path: str | Path) -> PresentationPolicy:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    if not isinstance(payload, dict):
        raise TypeError("advisory presentation policy must be a mapping")
    return PresentationPolicy.model_validate(payload)
