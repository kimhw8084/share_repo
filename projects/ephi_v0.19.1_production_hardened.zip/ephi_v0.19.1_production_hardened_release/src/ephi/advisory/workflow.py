from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import datetime, timezone

from .models import (
    AdvisoryWorkflowState,
    AuditEvent,
    ClosureFeedback,
    ClosureRecord,
    WorkflowMutation,
    WorkflowView,
)


_TERMINAL = {
    AdvisoryWorkflowState.RESOLVED,
    AdvisoryWorkflowState.BENIGN,
    AdvisoryWorkflowState.DATA_ISSUE,
    AdvisoryWorkflowState.DUPLICATE,
    AdvisoryWorkflowState.UNRESOLVED,
}

_ALLOWED: dict[AdvisoryWorkflowState, set[AdvisoryWorkflowState]] = {
    AdvisoryWorkflowState.NEW: {
        AdvisoryWorkflowState.ACKNOWLEDGED,
        AdvisoryWorkflowState.INVESTIGATING,
        AdvisoryWorkflowState.BENIGN,
        AdvisoryWorkflowState.DATA_ISSUE,
        AdvisoryWorkflowState.DUPLICATE,
        AdvisoryWorkflowState.UNRESOLVED,
    },
    AdvisoryWorkflowState.ACKNOWLEDGED: {
        AdvisoryWorkflowState.INVESTIGATING,
        AdvisoryWorkflowState.ACTION_TAKEN,
        AdvisoryWorkflowState.BENIGN,
        AdvisoryWorkflowState.DATA_ISSUE,
        AdvisoryWorkflowState.DUPLICATE,
        AdvisoryWorkflowState.UNRESOLVED,
    },
    AdvisoryWorkflowState.INVESTIGATING: {
        AdvisoryWorkflowState.ACTION_TAKEN,
        AdvisoryWorkflowState.MONITORING_RECOVERY,
        AdvisoryWorkflowState.RESOLVED,
        AdvisoryWorkflowState.BENIGN,
        AdvisoryWorkflowState.DATA_ISSUE,
        AdvisoryWorkflowState.UNRESOLVED,
    },
    AdvisoryWorkflowState.ACTION_TAKEN: {
        AdvisoryWorkflowState.MONITORING_RECOVERY,
        AdvisoryWorkflowState.RESOLVED,
        AdvisoryWorkflowState.UNRESOLVED,
    },
    AdvisoryWorkflowState.MONITORING_RECOVERY: {
        AdvisoryWorkflowState.INVESTIGATING,
        AdvisoryWorkflowState.RESOLVED,
        AdvisoryWorkflowState.UNRESOLVED,
    },
}


@dataclass(slots=True)
class WorkflowService:
    _records: dict[str, WorkflowView] = field(default_factory=dict)
    _audit: list[AuditEvent] = field(default_factory=list)
    _counter: int = 0
    _closures: dict[str, ClosureRecord] = field(default_factory=dict)

    def get(self, episode_id: str) -> WorkflowView:
        return self._records.get(episode_id, WorkflowView())

    def mutate(
        self,
        episode_id: str,
        mutation: WorkflowMutation,
        *,
        now: datetime | None = None,
    ) -> WorkflowView:
        now = now or datetime.now(timezone.utc)
        current = self.get(episode_id)
        requested = mutation.state or current.state
        if current.state in _TERMINAL and requested != current.state:
            raise ValueError(f"terminal workflow state cannot transition: {current.state} -> {requested}")
        if requested != current.state and requested not in _ALLOWED.get(current.state, set()):
            raise ValueError(f"invalid workflow transition: {current.state} -> {requested}")

        acknowledged_by = current.acknowledged_by
        acknowledged_at = current.acknowledged_at
        if requested in {
            AdvisoryWorkflowState.ACKNOWLEDGED,
            AdvisoryWorkflowState.INVESTIGATING,
            AdvisoryWorkflowState.ACTION_TAKEN,
            AdvisoryWorkflowState.MONITORING_RECOVERY,
        } and acknowledged_at is None:
            acknowledged_by = mutation.actor
            acknowledged_at = now

        updated = WorkflowView(
            state=requested,
            owner=mutation.owner if mutation.owner is not None else current.owner,
            acknowledged_by=acknowledged_by,
            acknowledged_at=acknowledged_at,
            updated_at=now,
            resolution_category=(
                mutation.resolution_category
                if mutation.resolution_category is not None
                else current.resolution_category
            ),
        )
        self._records[episode_id] = updated
        self._counter += 1
        self._audit.append(
            AuditEvent(
                audit_id=f"AUD-{self._counter:08d}",
                episode_id=episode_id,
                at=now,
                actor=mutation.actor,
                action="WORKFLOW_MUTATION",
                previous=current.model_dump(mode="json"),
                current=updated.model_dump(mode="json"),
                reason=mutation.note,
            )
        )
        return updated

    def close(
        self,
        episode_id: str,
        feedback: ClosureFeedback,
        *,
        now: datetime | None = None,
    ) -> WorkflowView:
        terminal = (
            AdvisoryWorkflowState.BENIGN
            if feedback.behavior_confirmed == "NO"
            else AdvisoryWorkflowState.RESOLVED
        )
        now = now or datetime.now(timezone.utc)
        updated = self.mutate(
            episode_id,
            WorkflowMutation(
                actor=feedback.actor,
                state=terminal,
                note=feedback.note,
                resolution_category=feedback.likely_category,
            ),
            now=now,
        )
        self._closures[episode_id] = ClosureRecord(
            episode_id=episode_id,
            submitted_at=now,
            feedback=feedback,
        )
        self._counter += 1
        self._audit.append(
            AuditEvent(
                audit_id=f"AUD-{self._counter:08d}",
                episode_id=episode_id,
                at=now,
                actor=feedback.actor,
                action="CLOSURE_FEEDBACK",
                previous={},
                current=self._closures[episode_id].model_dump(mode="json"),
                reason=feedback.note,
            )
        )
        return updated

    def closure_feedback(self, episode_id: str) -> ClosureRecord | None:
        return self._closures.get(episode_id)

    def audit(self, episode_id: str | None = None) -> tuple[AuditEvent, ...]:
        if episode_id is None:
            return tuple(self._audit)
        return tuple(item for item in self._audit if item.episode_id == episode_id)

    def export_state(self) -> dict[str, object]:
        return {
            "counter": self._counter,
            "records": {key: value.model_dump(mode="json") for key, value in self._records.items()},
            "audit": [item.model_dump(mode="json") for item in self._audit],
            "closures": {key: value.model_dump(mode="json") for key, value in self._closures.items()},
        }

    def restore_state(self, state: dict[str, object]) -> None:
        records_raw = state.get("records", {})
        audit_raw = state.get("audit", [])
        closures_raw = state.get("closures", {})
        if not isinstance(records_raw, dict) or not isinstance(audit_raw, list) or not isinstance(closures_raw, dict):
            raise TypeError("invalid advisory workflow checkpoint")
        self._counter = int(state.get("counter", 0))
        self._records = {str(key): WorkflowView.model_validate(value) for key, value in records_raw.items()}
        self._audit = [AuditEvent.model_validate(value) for value in audit_raw]
        self._closures = {str(key): ClosureRecord.model_validate(value) for key, value in closures_raw.items()}
