"""Typed API request/response schema helpers."""
