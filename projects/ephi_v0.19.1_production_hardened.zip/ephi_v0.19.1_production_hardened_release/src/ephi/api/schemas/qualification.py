from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from ephi.domain.onboarding import FamilyOnboardingPlan, GoldenCaseIntake, GoldenCurationState, ShadowReviewCandidate
from ephi.domain.operations import CertificationState, GateResult, ShadowReviewDisposition


class StrictRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")


class PlanRegistrationRequest(StrictRequest):
    command_id: str = Field(min_length=1)
    plan: FamilyOnboardingPlan


class GoldenSubmitRequest(StrictRequest):
    command_id: str = Field(min_length=1)
    intake: GoldenCaseIntake


class GoldenReviewRequest(StrictRequest):
    command_id: str = Field(min_length=1)
    state: GoldenCurationState
    note: str | None = None


class ShadowEnqueueRequest(StrictRequest):
    command_id: str = Field(min_length=1)
    candidates: tuple[ShadowReviewCandidate, ...]
    max_items: int = Field(default=20, ge=1, le=500)


class ShadowClaimRequest(StrictRequest):
    command_id: str = Field(min_length=1)
    lease_seconds: int = Field(default=1800, ge=30, le=14400)


class ShadowReviewCompleteRequest(StrictRequest):
    command_id: str = Field(min_length=1)
    review_id: str = Field(min_length=1)
    disposition: ShadowReviewDisposition
    comparison_valid: bool
    hypothesis_reasonable: bool
    verification_useful: bool
    false_event_reason: str | None = None
    notes: str | None = None


class GateRecordRequest(StrictRequest):
    command_id: str = Field(min_length=1)
    release_id: str = Field(min_length=1)
    capability_id: str = Field(min_length=1)
    result: GateResult


class PromotionGenerateRequest(StrictRequest):
    command_id: str = Field(min_length=1)
    capability_id: str = Field(min_length=1)
    target_state: CertificationState
    evidence_artifacts: tuple[str, ...] = ()


class PromotionApproveRequest(StrictRequest):
    command_id: str = Field(min_length=1)
    package_ids: tuple[str, ...] = Field(min_length=1)
    notes: tuple[str, ...] = ()
