from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from ephi.advisory.models import AdvisoryWorkflowState


class WorkflowMutationRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    actor: str = Field(min_length=1)
    state: AdvisoryWorkflowState | None = None
    owner: str | None = None
    note: str | None = None
    resolution_category: str | None = None


class ClosureFeedbackRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    actor: str = Field(min_length=1)
    behavior_confirmed: str = Field(pattern="^(YES|NO|UNCERTAIN)$")
    quality_affected: str = Field(pattern="^(YES|NO|UNKNOWN)$")
    likely_category: str = Field(min_length=1)
    action_taken: str | None = None
    action_resolved_state: str = Field(pattern="^(YES|NO|PARTIAL|UNKNOWN)$")
    confidence: str = Field(pattern="^(HIGH|MEDIUM|LOW)$")
    note: str | None = None


class MissedEventRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    asset_id: str = Field(min_length=1)
    start_time: datetime
    end_time: datetime | None = None
    context: dict[str, str] = Field(default_factory=dict)
    reporter: str = Field(min_length=1)
    description: str = Field(min_length=1)
    external_event_type: str | None = None
