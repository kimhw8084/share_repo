from __future__ import annotations

from collections.abc import Callable
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException, Query, Request, status

from ephi.advisory.models import (
    AttentionQueueItem,
    AuditEvent,
    ClosureFeedback,
    ClosureRecord,
    EpisodeView,
    EvidenceView,
    MaterialExposureItem,
    MissedEventReport,
    NotificationPayload,
    WorkflowMutation,
)
from ephi.advisory.service import AdvisoryService
from ephi.domain.exposure import ExposureSnapshot
from ephi.domain.priority import OperationalPriorityAssessment
from ephi.api.schemas.advisory import ClosureFeedbackRequest, MissedEventRequest, WorkflowMutationRequest
from ephi.config import EphiConfig
from ephi.version import __version__
from ephi.domain.history import HistoricalAnalogue
from ephi.history.recurrence import RecurrenceSummary
from ephi.domain.rca import InvestigationSeed, RCACandidate
from ephi.history.application import HistoryRCAApplicationService
from ephi.domain.value import EpisodeValueLedgerView, EpisodeValueSummary, ProgramValueSummary
from ephi.value.service import ValueLedgerService
from ephi.domain.operations import EngineerShadowReview, FamilyQualificationManifest, OperationalControl, OperationalSLOReport
from ephi.operations.status import OperationalStatus, OperationsStatusService
from ephi.onboarding.control_plane import QualificationControlPlaneService
from ephi.domain.onboarding import FamilyOnboardingPlan, GoldenCaseIntake, ShadowReviewQueueItem, ShadowQualificationMetrics
from ephi.domain.qualification_control import (
    PromotionEvidenceRecord, QualificationAuditEvent, QualificationGateRecord, QualificationWorkspaceExport, QualificationWorkspaceSummary,
)
from ephi.launch.observability import CampaignObservabilityService
from ephi.domain.campaign_observability import (
    CampaignEventView, CampaignEvidenceComparison, CampaignQualificationExport,
    CampaignReadinessView, CampaignRetentionAssessment, CampaignSLOReport, CrossStageReconciliation,
)
from ephi.api.schemas.qualification import (
    GateRecordRequest, GoldenReviewRequest, GoldenSubmitRequest, PlanRegistrationRequest,
    PromotionApproveRequest, PromotionGenerateRequest, ShadowClaimRequest,
    ShadowEnqueueRequest, ShadowReviewCompleteRequest,
)


def create_app(
    config: EphiConfig | None = None,
    *,
    advisory_service: AdvisoryService | None = None,
    history_rca_service: HistoryRCAApplicationService | None = None,
    value_service: ValueLedgerService | None = None,
    operations_status_service: OperationsStatusService | None = None,
    qualification_service: QualificationControlPlaneService | None = None,
    campaign_observability_service: CampaignObservabilityService | None = None,
    actor_resolver: Callable[[Request], str] | None = None,
) -> FastAPI:
    config = config or EphiConfig()
    advisory_service = advisory_service or AdvisoryService()
    app = FastAPI(title="EPHI", version=__version__)
    app.state.advisory_service = advisory_service
    app.state.history_rca_service = history_rca_service
    app.state.value_service = value_service
    app.state.operations_status_service = operations_status_service
    app.state.qualification_service = qualification_service
    app.state.campaign_observability_service = campaign_observability_service

    @app.get("/healthz")
    def healthz() -> dict[str, str]:
        return {"status": "ok", "environment": config.app.environment}

    @app.get("/version")
    def version() -> dict[str, str]:
        return {
            "version": __version__,
            "environment": config.app.environment,
            "config_hash": config.stable_hash(),
        }

    @app.get("/v1/attention", response_model=list[AttentionQueueItem])
    def attention() -> list[AttentionQueueItem]:
        return list(advisory_service.list_attention())

    @app.get("/v1/episodes", response_model=list[AttentionQueueItem])
    def episodes() -> list[AttentionQueueItem]:
        # The attention queue is intentionally the initial episode list contract. A later
        # historical endpoint can expose resolved episodes without bloating the hot API.
        return list(advisory_service.list_attention())

    @app.get("/v1/episodes/{episode_id}", response_model=EpisodeView)
    def episode(episode_id: str) -> EpisodeView:
        try:
            return advisory_service.get_view(episode_id)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.get("/v1/episodes/{episode_id}/evidence", response_model=list[EvidenceView])
    def episode_evidence(
        episode_id: str,
        polarity: str | None = Query(default=None, pattern="^(SUPPORTS|CONTRADICTS)$"),
        channel: str | None = None,
    ) -> list[EvidenceView]:
        try:
            selected = advisory_service.evidence(episode_id, polarity=polarity, channel=channel)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
        return list(selected)

    @app.get("/v1/episodes/{episode_id}/exposure", response_model=ExposureSnapshot)
    def exposure_snapshot(episode_id: str) -> ExposureSnapshot:
        try: return advisory_service.exposure_snapshot(episode_id)
        except KeyError as exc: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.get("/v1/episodes/{episode_id}/priority", response_model=OperationalPriorityAssessment)
    def priority_assessment(episode_id: str) -> OperationalPriorityAssessment:
        try: return advisory_service.priority_assessment(episode_id)
        except KeyError as exc: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.get("/v1/episodes/{episode_id}/material-exposure", response_model=list[MaterialExposureItem])
    def material_exposure(episode_id: str) -> list[MaterialExposureItem]:
        try:
            items = advisory_service.material_exposure(episode_id)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
        return list(items)

    @app.get("/v1/episodes/{episode_id}/notification", response_model=NotificationPayload)
    def notification(episode_id: str) -> NotificationPayload:
        try:
            return advisory_service.notification(episode_id)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.post("/v1/episodes/{episode_id}/workflow", response_model=EpisodeView)
    def mutate_workflow(episode_id: str, request: WorkflowMutationRequest, http_request: Request) -> EpisodeView:
        try:
            payload = request.model_dump()
            if actor_resolver is not None:
                payload["actor"] = actor_resolver(http_request)
            return advisory_service.mutate_workflow(
                episode_id,
                WorkflowMutation(**payload),
            )
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    @app.post("/v1/episodes/{episode_id}/close", response_model=EpisodeView)
    def close_episode(episode_id: str, request: ClosureFeedbackRequest, http_request: Request) -> EpisodeView:
        try:
            payload = request.model_dump()
            if actor_resolver is not None:
                payload["actor"] = actor_resolver(http_request)
            return advisory_service.close(
                episode_id,
                ClosureFeedback(**payload),
            )
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    @app.get("/v1/episodes/{episode_id}/closure-feedback", response_model=ClosureRecord | None)
    def closure_feedback(episode_id: str) -> ClosureRecord | None:
        if not advisory_service.exists(episode_id):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"unknown episode: {episode_id}")
        return advisory_service.workflow.closure_feedback(episode_id)

    @app.get("/v1/episodes/{episode_id}/audit", response_model=list[AuditEvent])
    def episode_audit(episode_id: str) -> list[AuditEvent]:
        if not advisory_service.exists(episode_id):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"unknown episode: {episode_id}")
        return list(advisory_service.workflow.audit(episode_id))


    @app.get("/v1/episodes/{episode_id}/historical-analogues", response_model=list[HistoricalAnalogue])
    def historical_analogues(episode_id: str, top_k: int = Query(default=5, ge=1, le=20)) -> list[HistoricalAnalogue]:
        if history_rca_service is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="historical intelligence unavailable")
        try:
            return list(history_rca_service.analogues(episode_id, top_k=top_k))
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.get("/v1/episodes/{episode_id}/historical-recurrence", response_model=RecurrenceSummary)
    def historical_recurrence(episode_id: str, min_similarity: float = Query(default=0.65, ge=0.0, le=1.0)) -> RecurrenceSummary:
        if history_rca_service is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="historical intelligence unavailable")
        try:
            return history_rca_service.recurrence(episode_id, min_similarity=min_similarity)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.get("/v1/episodes/{episode_id}/investigation-seed", response_model=InvestigationSeed)
    def investigation_seed(episode_id: str) -> InvestigationSeed:
        if history_rca_service is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="RCA substrate unavailable")
        try:
            return history_rca_service.investigation_seed(episode_id)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.get("/v1/episodes/{episode_id}/rca-candidates", response_model=list[RCACandidate])
    def rca_candidates(episode_id: str, top_k: int = Query(default=10, ge=1, le=25)) -> list[RCACandidate]:
        if history_rca_service is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="RCA substrate unavailable")
        try:
            return list(history_rca_service.rca_candidates(episode_id, top_k=top_k))
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.get("/v1/episodes/{episode_id}/value-ledger", response_model=EpisodeValueLedgerView)
    def value_ledger(episode_id: str) -> EpisodeValueLedgerView:
        if value_service is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="value ledger unavailable")
        if not value_service.has_episode(episode_id):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"unknown value-ledger episode: {episode_id}")
        try:
            return value_service.episode_ledger(episode_id)
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    @app.get("/v1/episodes/{episode_id}/value-summary", response_model=EpisodeValueSummary)
    def value_summary(episode_id: str) -> EpisodeValueSummary:
        if value_service is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="value ledger unavailable")
        if not value_service.has_episode(episode_id):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"unknown value-ledger episode: {episode_id}")
        try:
            return value_service.episode_summary(episode_id)
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    @app.get("/v1/value/program-summary", response_model=ProgramValueSummary)
    def program_value_summary() -> ProgramValueSummary:
        if value_service is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="value ledger unavailable")
        try:
            return value_service.program_summary()
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc


    @app.get("/v1/operations/status", response_model=OperationalStatus)
    def operations_status() -> OperationalStatus:
        if operations_status_service is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="operations status unavailable")
        return operations_status_service.status()

    @app.get("/v1/operations/controls", response_model=list[OperationalControl])
    def operations_controls() -> list[OperationalControl]:
        if operations_status_service is None or operations_status_service.controls is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="operations controls unavailable")
        return list(operations_status_service.controls.active_controls())

    @app.get("/v1/operations/certification", response_model=FamilyQualificationManifest)
    def operations_certification() -> FamilyQualificationManifest:
        if operations_status_service is None or operations_status_service.family_manifest is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="family certification unavailable")
        return operations_status_service.family_manifest

    @app.get("/v1/operations/slo", response_model=OperationalSLOReport)
    def operations_slo() -> OperationalSLOReport:
        if operations_status_service is None or operations_status_service.slo_report is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="operational SLO report unavailable")
        return operations_status_service.slo_report


    def _qualification_actor(request: Request) -> str:
        if actor_resolver is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="authenticated qualification actor resolver unavailable",
            )
        actor = actor_resolver(request).strip()
        if not actor:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="qualification actor required")
        return actor

    def _qualification_service() -> QualificationControlPlaneService:
        if qualification_service is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="qualification control plane unavailable")
        return qualification_service

    @app.get("/v1/qualification/families/{family_id}", response_model=QualificationWorkspaceSummary)
    def qualification_summary(family_id: str) -> QualificationWorkspaceSummary:
        return _qualification_service().summary(family_id)

    @app.post("/v1/qualification/families/{family_id}/plan", response_model=FamilyOnboardingPlan)
    def qualification_register_plan(family_id: str, payload: PlanRegistrationRequest, request: Request) -> FamilyOnboardingPlan:
        if payload.plan.family_id != family_id:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="plan family_id mismatch")
        try:
            return _qualification_service().register_plan(
                payload.plan, actor=_qualification_actor(request), command_id=payload.command_id
            )
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    @app.get("/v1/qualification/families/{family_id}/golden", response_model=list[GoldenCaseIntake])
    def qualification_golden_list(family_id: str) -> list[GoldenCaseIntake]:
        return list(_qualification_service().latest_golden_intakes(family_id))

    @app.get("/v1/qualification/families/{family_id}/golden/{intake_id}/history", response_model=list[GoldenCaseIntake])
    def qualification_golden_history(family_id: str, intake_id: str) -> list[GoldenCaseIntake]:
        items = _qualification_service().golden_history(family_id, intake_id)
        if not items:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"unknown Golden intake: {intake_id}")
        return list(items)

    @app.post("/v1/qualification/families/{family_id}/golden", status_code=status.HTTP_201_CREATED, response_model=GoldenCaseIntake)
    def qualification_golden_submit(family_id: str, payload: GoldenSubmitRequest, request: Request) -> GoldenCaseIntake:
        try:
            return _qualification_service().submit_golden(
                family_id, payload.intake, actor=_qualification_actor(request), command_id=payload.command_id
            )
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    @app.post("/v1/qualification/families/{family_id}/golden/{intake_id}/review", response_model=GoldenCaseIntake)
    def qualification_golden_review(family_id: str, intake_id: str, payload: GoldenReviewRequest, request: Request) -> GoldenCaseIntake:
        try:
            return _qualification_service().review_golden(
                family_id, intake_id, state=payload.state, actor=_qualification_actor(request),
                command_id=payload.command_id, note=payload.note,
            )
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    @app.get("/v1/qualification/families/{family_id}/shadow/queue", response_model=list[ShadowReviewQueueItem])
    def qualification_shadow_queue(family_id: str) -> list[ShadowReviewQueueItem]:
        return list(_qualification_service().shadow_queue(family_id))

    @app.post("/v1/qualification/families/{family_id}/shadow/queue", response_model=list[ShadowReviewQueueItem])
    def qualification_shadow_enqueue(family_id: str, payload: ShadowEnqueueRequest, request: Request) -> list[ShadowReviewQueueItem]:
        try:
            return list(_qualification_service().enqueue_shadow_candidates(
                family_id, payload.candidates, max_items=payload.max_items,
                actor=_qualification_actor(request), command_id=payload.command_id,
            ))
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    @app.post("/v1/qualification/families/{family_id}/shadow/claim", response_model=ShadowReviewQueueItem | None)
    def qualification_shadow_claim(family_id: str, payload: ShadowClaimRequest, request: Request) -> ShadowReviewQueueItem | None:
        try:
            return _qualification_service().claim_shadow_review(
                family_id, actor=_qualification_actor(request), command_id=payload.command_id,
                lease_seconds=payload.lease_seconds,
            )
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    @app.post("/v1/qualification/families/{family_id}/shadow/{episode_id}/complete", response_model=EngineerShadowReview)
    def qualification_shadow_complete(family_id: str, episode_id: str, payload: ShadowReviewCompleteRequest, request: Request) -> EngineerShadowReview:
        actor = _qualification_actor(request)
        review = EngineerShadowReview(
            review_id=payload.review_id,
            episode_id=episode_id,
            reviewer=actor,
            disposition=payload.disposition,
            comparison_valid=payload.comparison_valid,
            hypothesis_reasonable=payload.hypothesis_reasonable,
            verification_useful=payload.verification_useful,
            reviewed_at=datetime.now(timezone.utc),
            false_event_reason=payload.false_event_reason,
            notes=payload.notes,
        )
        try:
            return _qualification_service().complete_shadow_review(
                family_id, episode_id, review, actor=actor, command_id=payload.command_id
            )
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    @app.get("/v1/qualification/families/{family_id}/shadow/metrics", response_model=ShadowQualificationMetrics)
    def qualification_shadow_metrics(family_id: str) -> ShadowQualificationMetrics:
        return _qualification_service().shadow_metrics(family_id)

    @app.post("/v1/qualification/families/{family_id}/gates", status_code=status.HTTP_201_CREATED, response_model=QualificationGateRecord)
    def qualification_gate_record(family_id: str, payload: GateRecordRequest, request: Request) -> QualificationGateRecord:
        try:
            return _qualification_service().record_gate(
                family_id, release_id=payload.release_id, capability_id=payload.capability_id,
                result=payload.result, actor=_qualification_actor(request), command_id=payload.command_id,
            )
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    @app.get("/v1/qualification/families/{family_id}/promotion", response_model=list[PromotionEvidenceRecord])
    def qualification_promotion_list(family_id: str) -> list[PromotionEvidenceRecord]:
        return list(_qualification_service().promotion_records(family_id))

    @app.post("/v1/qualification/families/{family_id}/promotion/generate", response_model=PromotionEvidenceRecord)
    def qualification_promotion_generate(family_id: str, payload: PromotionGenerateRequest, request: Request) -> PromotionEvidenceRecord:
        try:
            return _qualification_service().generate_promotion(
                family_id, capability_id=payload.capability_id, target_state=payload.target_state,
                actor=_qualification_actor(request), command_id=payload.command_id,
                evidence_artifacts=payload.evidence_artifacts,
            )
        except (KeyError, ValueError) as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    @app.post("/v1/qualification/families/{family_id}/promotion/approve", response_model=FamilyQualificationManifest)
    def qualification_promotion_approve(family_id: str, payload: PromotionApproveRequest, request: Request) -> FamilyQualificationManifest:
        try:
            return _qualification_service().approve_promotion(
                family_id, package_ids=payload.package_ids, actor=_qualification_actor(request),
                command_id=payload.command_id, notes=payload.notes,
            )
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    @app.get("/v1/qualification/families/{family_id}/manifests", response_model=list[FamilyQualificationManifest])
    def qualification_manifest_history(family_id: str) -> list[FamilyQualificationManifest]:
        return list(_qualification_service().manifest_history(family_id))

    @app.get("/v1/qualification/families/{family_id}/manifests/current", response_model=FamilyQualificationManifest | None)
    def qualification_manifest_current(family_id: str) -> FamilyQualificationManifest | None:
        return _qualification_service().current_manifest(family_id)

    @app.get("/v1/qualification/families/{family_id}/export", response_model=QualificationWorkspaceExport)
    def qualification_export(family_id: str) -> QualificationWorkspaceExport:
        return _qualification_service().export_workspace(family_id)

    @app.get("/v1/qualification/families/{family_id}/audit", response_model=list[QualificationAuditEvent])
    def qualification_audit(family_id: str) -> list[QualificationAuditEvent]:
        return list(_qualification_service().audit(family_id))


    def _campaign_observability() -> CampaignObservabilityService:
        if campaign_observability_service is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="campaign observability unavailable")
        return campaign_observability_service

    @app.get("/v1/launch/families/{family_id}/campaigns/{campaign_id}", response_model=CampaignReadinessView)
    def launch_campaign_readiness(family_id: str, campaign_id: str) -> CampaignReadinessView:
        try:
            return _campaign_observability().readiness(family_id, campaign_id)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.get("/v1/launch/families/{family_id}/campaigns/{campaign_id}/events", response_model=list[CampaignEventView])
    def launch_campaign_events(family_id: str, campaign_id: str) -> list[CampaignEventView]:
        try:
            return list(_campaign_observability().events(family_id, campaign_id))
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.get("/v1/launch/families/{family_id}/campaigns/{campaign_id}/reconciliation", response_model=CrossStageReconciliation)
    def launch_campaign_reconciliation(family_id: str, campaign_id: str) -> CrossStageReconciliation:
        try:
            return _campaign_observability().reconciliation(family_id, campaign_id)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.get("/v1/launch/families/{family_id}/campaigns/{campaign_id}/slo", response_model=CampaignSLOReport)
    def launch_campaign_slo(family_id: str, campaign_id: str) -> CampaignSLOReport:
        try:
            return _campaign_observability().slo(family_id, campaign_id)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.get("/v1/launch/families/{family_id}/campaigns/{campaign_id}/retention", response_model=CampaignRetentionAssessment)
    def launch_campaign_retention(family_id: str, campaign_id: str) -> CampaignRetentionAssessment:
        try:
            return _campaign_observability().retention(family_id, campaign_id)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.get("/v1/launch/families/{family_id}/campaigns/{campaign_id}/export", response_model=CampaignQualificationExport)
    def launch_campaign_export(family_id: str, campaign_id: str) -> CampaignQualificationExport:
        try:
            return _campaign_observability().export(family_id, campaign_id)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.get("/v1/launch/families/{family_id}/campaigns/{baseline_campaign_id}/compare/{candidate_campaign_id}", response_model=CampaignEvidenceComparison)
    def launch_campaign_compare(family_id: str, baseline_campaign_id: str, candidate_campaign_id: str) -> CampaignEvidenceComparison:
        try:
            return _campaign_observability().compare(family_id, baseline_campaign_id, candidate_campaign_id)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.post("/v1/missed-events", status_code=status.HTTP_201_CREATED, response_model=MissedEventReport)
    def create_missed_event(request: MissedEventRequest, http_request: Request) -> MissedEventReport:
        payload = request.model_dump()
        if actor_resolver is not None:
            payload["reporter"] = actor_resolver(http_request)
        return advisory_service.create_missed_event(**payload)

    @app.get("/v1/missed-events", response_model=list[MissedEventReport])
    def missed_events() -> list[MissedEventReport]:
        return list(advisory_service.missed_events())

    return app
