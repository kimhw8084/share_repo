from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Mapping

import numpy as np

from ephi.domain.context import ContextKey
from ephi.domain.features import ScalarFeatureObservation
from ephi.domain.populations import MaterializedReferenceState, ReferenceSnapshot

_ROBUST_SCALE = 1.4826
_EPS = 1e-9


def _median_mad(values: list[float], *, scale_floor: float = _EPS) -> tuple[float, float]:
    arr = np.asarray(values, dtype=np.float64)
    median = float(np.median(arr))
    mad = float(np.median(np.abs(arr - median)))
    return median, max(_ROBUST_SCALE * mad, scale_floor, _EPS)


@dataclass(frozen=True, slots=True)
class ReferenceConfig:
    min_reference_n: int = 36
    max_adaptive_n: int = 240
    bootstrap_n: int = 60
    admission_abs_z: float = 3.0
    anchor_admission_abs_z: float = 3.0
    confidence_full_n: int = 120
    scale_floor: float = _EPS
    feature_scale_floors: Mapping[str, float] = field(default_factory=dict)


@dataclass(slots=True)
class _ReferenceBuffer:
    adaptive: deque[float]
    anchor: tuple[float, ...] | None = None


@dataclass(slots=True)
class ReferenceManager:
    """Controlled known-good reference admission.

    Critical invariant: score the current observation against the *previous*
    reference, then call ``admit_after_score``. Current observations never affect
    their own baseline.
    """

    config: ReferenceConfig = field(default_factory=ReferenceConfig)
    _buffers: dict[tuple[str, ContextKey, str], _ReferenceBuffer] = field(default_factory=dict)

    def _key(self, obs: ScalarFeatureObservation) -> tuple[str, ContextKey, str]:
        return obs.asset_id, obs.context, obs.feature_id

    def _buffer(self, obs: ScalarFeatureObservation) -> _ReferenceBuffer:
        key = self._key(obs)
        if key not in self._buffers:
            self._buffers[key] = _ReferenceBuffer(
                adaptive=deque(maxlen=self.config.max_adaptive_n)
            )
        return self._buffers[key]

    def _scale_floor(self, obs: ScalarFeatureObservation) -> float:
        return max(
            self.config.scale_floor,
            float(self.config.feature_scale_floors.get(obs.feature_id, 0.0)),
            _EPS,
        )

    def snapshot(self, obs: ScalarFeatureObservation) -> ReferenceSnapshot | None:
        buffer = self._buffer(obs)
        if not buffer.adaptive:
            return None
        adaptive_values = list(buffer.adaptive)
        scale_floor = self._scale_floor(obs)
        median, mad = _median_mad(adaptive_values, scale_floor=scale_floor)
        anchor_values = list(buffer.anchor or tuple(adaptive_values))
        anchor_median, anchor_mad = _median_mad(
            anchor_values, scale_floor=scale_floor
        )
        n = len(adaptive_values)
        confidence = min(1.0, n / max(self.config.confidence_full_n, 1))
        return ReferenceSnapshot(
            median=median,
            mad=mad,
            n=n,
            anchor_median=anchor_median,
            anchor_mad=anchor_mad,
            anchor_n=len(anchor_values),
            adequate=n >= self.config.min_reference_n,
            confidence=confidence,
        )

    def bootstrap(self, obs: ScalarFeatureObservation) -> bool:
        """Admit valid observations only until a usable initial reference exists."""
        if not obs.valid:
            return False
        buffer = self._buffer(obs)
        if len(buffer.adaptive) >= self.config.bootstrap_n:
            return False
        buffer.adaptive.append(obs.value)
        if len(buffer.adaptive) == self.config.bootstrap_n and buffer.anchor is None:
            buffer.anchor = tuple(buffer.adaptive)
        return True

    def robust_z(self, obs: ScalarFeatureObservation, snapshot: ReferenceSnapshot) -> tuple[float, float]:
        self_z = (obs.value - snapshot.median) / snapshot.mad
        anchor_z = (obs.value - snapshot.anchor_median) / snapshot.anchor_mad
        return float(self_z), float(anchor_z)

    def admit_after_score(
        self,
        obs: ScalarFeatureObservation,
        *,
        self_z: float,
        anchor_z: float,
        data_pipeline_suspect: bool,
    ) -> bool:
        if not obs.valid or data_pipeline_suspect:
            return False
        if abs(self_z) > self.config.admission_abs_z:
            return False
        if abs(anchor_z) > self.config.anchor_admission_abs_z:
            return False
        buffer = self._buffer(obs)
        buffer.adaptive.append(obs.value)
        if buffer.anchor is None and len(buffer.adaptive) >= self.config.bootstrap_n:
            buffer.anchor = tuple(buffer.adaptive)
        return True

    def debug_values(self, obs: ScalarFeatureObservation) -> tuple[float, ...]:
        return tuple(self._buffer(obs).adaptive)

    def materialized_state(self) -> tuple[MaterializedReferenceState, ...]:
        records: list[MaterializedReferenceState] = []
        for (asset_id, context, feature_id), buffer in self._buffers.items():
            if not buffer.adaptive:
                continue
            adaptive_values = list(buffer.adaptive)
            scale_floor = max(
                self.config.scale_floor,
                float(self.config.feature_scale_floors.get(feature_id, 0.0)),
                _EPS,
            )
            median_value, mad_value = _median_mad(
                adaptive_values, scale_floor=scale_floor
            )
            anchor_values = list(buffer.anchor or tuple(adaptive_values))
            anchor_median, anchor_mad = _median_mad(
                anchor_values, scale_floor=scale_floor
            )
            n = len(adaptive_values)
            records.append(
                MaterializedReferenceState(
                    asset_id=asset_id,
                    context_key=context.stable_key(),
                    feature_id=feature_id,
                    median=median_value,
                    mad=mad_value,
                    n=n,
                    anchor_median=anchor_median,
                    anchor_mad=anchor_mad,
                    anchor_n=len(anchor_values),
                    adequate=n >= self.config.min_reference_n,
                    confidence=min(1.0, n / max(self.config.confidence_full_n, 1)),
                    scale_floor=scale_floor,
                    practical_effect_floor=scale_floor,
                )
            )
        return tuple(records)

    def export_state(self) -> list[dict[str, object]]:
        records: list[dict[str, object]] = []
        for (asset_id, context, feature_id), buffer in self._buffers.items():
            records.append(
                {
                    "asset_id": asset_id,
                    "context": context.to_dict(),
                    "feature_id": feature_id,
                    "adaptive": list(buffer.adaptive),
                    "anchor": list(buffer.anchor) if buffer.anchor is not None else None,
                }
            )
        return records

    def restore_state(self, records: list[dict[str, object]]) -> None:
        self._buffers.clear()
        for record in records:
            context_raw = record["context"]
            if not isinstance(context_raw, dict):
                raise TypeError("reference checkpoint context must be a mapping")
            context = ContextKey.from_dict({str(k): str(v) for k, v in context_raw.items()})
            adaptive_raw = record["adaptive"]
            if not isinstance(adaptive_raw, list):
                raise TypeError("reference checkpoint adaptive must be a list")
            anchor_raw = record.get("anchor")
            anchor = (
                tuple(float(v) for v in anchor_raw)
                if isinstance(anchor_raw, list)
                else None
            )
            self._buffers[(str(record["asset_id"]), context, str(record["feature_id"]))] = _ReferenceBuffer(
                adaptive=deque(
                    (float(v) for v in adaptive_raw),
                    maxlen=self.config.max_adaptive_n,
                ),
                anchor=anchor,
            )
