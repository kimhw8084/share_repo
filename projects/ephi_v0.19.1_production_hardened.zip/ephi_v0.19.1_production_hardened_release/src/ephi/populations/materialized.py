from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ephi.domain.features import ScalarFeatureObservation
from ephi.domain.populations import MaterializedReferenceState


@dataclass(frozen=True, slots=True)
class ReferenceStateBatch:
    median: np.ndarray
    mad: np.ndarray
    anchor_median: np.ndarray
    anchor_mad: np.ndarray
    confidence: np.ndarray
    adequate: np.ndarray

    @property
    def size(self) -> int:
        return int(self.median.shape[0])


class ReferenceStateIndex:
    """Bounded O(1) hot-path lookup over materialized reference states."""

    def __init__(self, states: tuple[MaterializedReferenceState, ...] | list[MaterializedReferenceState]):
        self._states = {state.key: state for state in states}

    def lookup_many(self, observations: list[ScalarFeatureObservation]) -> ReferenceStateBatch:
        n = len(observations)
        median = np.full(n, np.nan, dtype=np.float64)
        mad = np.full(n, np.nan, dtype=np.float64)
        anchor_median = np.full(n, np.nan, dtype=np.float64)
        anchor_mad = np.full(n, np.nan, dtype=np.float64)
        confidence = np.zeros(n, dtype=np.float64)
        adequate = np.zeros(n, dtype=bool)

        for idx, obs in enumerate(observations):
            state = self._states.get((obs.asset_id, obs.context.stable_key(), obs.feature_id))
            if state is None:
                continue
            median[idx] = state.median
            mad[idx] = state.mad
            anchor_median[idx] = state.anchor_median
            anchor_mad[idx] = state.anchor_mad
            confidence[idx] = state.confidence
            adequate[idx] = state.adequate

        return ReferenceStateBatch(
            median=median,
            mad=mad,
            anchor_median=anchor_median,
            anchor_mad=anchor_mad,
            confidence=confidence,
            adequate=adequate,
        )
