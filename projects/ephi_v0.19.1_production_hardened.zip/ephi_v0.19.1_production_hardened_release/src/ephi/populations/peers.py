from __future__ import annotations

from dataclasses import dataclass
from statistics import median

from ephi.domain.populations import PeerSnapshot

_EPS = 1e-9


@dataclass(frozen=True, slots=True)
class PeerConfig:
    min_peer_count: int = 2
    confidence_full_count: int = 4


def _raw_robust_mad(values: list[float]) -> float:
    if not values:
        return 0.0
    center = median(values)
    return 1.4826 * median([abs(v - center) for v in values])


def build_peer_snapshots(
    changes: dict[str, tuple[float, float]],
    *,
    config: PeerConfig = PeerConfig(),
) -> dict[str, PeerSnapshot]:
    """Build peer snapshots from physical change-from-own-baseline.

    Each tuple is ``(physical_change, own_reference_scale)``. Comparing physical
    change rather than raw self-z prevents different tool noise scales from making
    the same fleet-wide process shift look like a local equipment divergence.
    """

    result: dict[str, PeerSnapshot] = {}
    all_changes = [values[0] for values in changes.values()]
    all_scales = [max(values[1], _EPS) for values in changes.values()]
    small_cohort = len(changes) <= 3
    for asset_id in changes:
        peers = {peer: values for peer, values in changes.items() if peer != asset_id}
        peer_changes = [values[0] for values in peers.values()]
        peer_scales = [max(values[1], _EPS) for values in peers.values()]
        count = len(peer_changes)
        # With only two peers, their median is their midpoint and is vulnerable to a
        # single poisoned peer. For a three-member cohort, the all-member median is
        # the robust single-outlier consensus. Eligibility still excludes the target.
        consensus_changes = all_changes if small_cohort else peer_changes
        consensus_scales = all_scales if small_cohort else peer_scales
        center_change = float(median(consensus_changes)) if consensus_changes else 0.0
        typical_scale = float(median(consensus_scales)) if consensus_scales else 1.0
        change_mad = max(_raw_robust_mad(consensus_changes), typical_scale, _EPS)
        fleet_shift_z = center_change / max(typical_scale, _EPS)
        confidence = min(1.0, count / max(config.confidence_full_count, 1))
        result[asset_id] = PeerSnapshot(
            peer_asset_ids=tuple(sorted(peers)),
            peer_center_change=center_change,
            peer_change_mad=change_mad,
            fleet_shift_z=float(fleet_shift_z),
            peer_count=count,
            adequate=count >= config.min_peer_count,
            confidence=confidence,
        )
    return result
