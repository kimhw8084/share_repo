from __future__ import annotations

from dataclasses import dataclass
from hashlib import blake2b
from typing import Iterable

import numpy as np

from ephi.domain.populations import MaterializedReferenceState
from ephi.populations.materialized import ReferenceStateBatch


def stable_state_key_id(asset_id: str, context_key: str, feature_id: str) -> np.uint64:
    """Stable 64-bit analytical key for pre-materialized hot-path state.

    IDs are intended to be computed when the execution/feature spine is materialized,
    not repeatedly on every detector operation. A collision check is performed when
    building the reference index.
    """

    payload = f"{asset_id}\x1f{context_key}\x1f{feature_id}".encode("utf-8")
    digest = blake2b(payload, digest_size=8, person=b"EPHIKEY1").digest()
    return np.uint64(int.from_bytes(digest, "big", signed=False))


@dataclass(frozen=True, slots=True)
class ReferenceMatrixLookup:
    reference: ReferenceStateBatch
    scale_floor: np.ndarray
    practical_effect_floor: np.ndarray
    found: np.ndarray


class ReferenceStateMatrixIndex:
    """Sorted NumPy reference index for vectorized O(log N) batch lookup.

    The source-scale batch carries uint64 ``state_key_id`` values. Lookup therefore
    avoids Python domain-object construction and composite-string dictionary access on
    the scoring path.
    """

    def __init__(self, states: Iterable[MaterializedReferenceState]) -> None:
        rows = list(states)
        key_ids = np.asarray(
            [stable_state_key_id(row.asset_id, row.context_key, row.feature_id) for row in rows],
            dtype=np.uint64,
        )
        if key_ids.size:
            unique, counts = np.unique(key_ids, return_counts=True)
            duplicates = unique[counts > 1]
            if duplicates.size:
                # A duplicate may be either a genuine duplicate state or an exceedingly
                # unlikely hash collision. Both are unsafe for a unique hot-path index.
                raise ValueError(f"duplicate/colliding reference state key(s): {duplicates.tolist()}")
        order = np.argsort(key_ids)
        self.key_ids = key_ids[order]
        self.median = np.asarray([rows[i].median for i in order], dtype=np.float64)
        self.mad = np.asarray([rows[i].mad for i in order], dtype=np.float64)
        self.anchor_median = np.asarray([rows[i].anchor_median for i in order], dtype=np.float64)
        self.anchor_mad = np.asarray([rows[i].anchor_mad for i in order], dtype=np.float64)
        self.confidence = np.asarray([rows[i].confidence for i in order], dtype=np.float64)
        self.adequate = np.asarray([rows[i].adequate for i in order], dtype=bool)
        self.scale_floor = np.asarray([rows[i].scale_floor for i in order], dtype=np.float64)
        self.practical_effect_floor = np.asarray(
            [rows[i].practical_effect_floor for i in order], dtype=np.float64
        )

    @property
    def size(self) -> int:
        return int(self.key_ids.size)

    def lookup_ids(self, state_key_ids: np.ndarray) -> ReferenceMatrixLookup:
        keys = np.asarray(state_key_ids, dtype=np.uint64)
        if keys.ndim != 1:
            raise ValueError("state_key_ids must be one-dimensional")
        n = keys.size
        median = np.full(n, np.nan, dtype=np.float64)
        mad = np.full(n, np.nan, dtype=np.float64)
        anchor_median = np.full(n, np.nan, dtype=np.float64)
        anchor_mad = np.full(n, np.nan, dtype=np.float64)
        confidence = np.zeros(n, dtype=np.float64)
        adequate = np.zeros(n, dtype=bool)
        scale_floor = np.full(n, np.nan, dtype=np.float64)
        practical_effect_floor = np.full(n, np.nan, dtype=np.float64)
        found = np.zeros(n, dtype=bool)
        if self.key_ids.size == 0 or n == 0:
            return ReferenceMatrixLookup(
                ReferenceStateBatch(median, mad, anchor_median, anchor_mad, confidence, adequate),
                scale_floor,
                practical_effect_floor,
                found,
            )

        positions = np.searchsorted(self.key_ids, keys)
        candidate = positions < self.key_ids.size
        safe_positions = np.minimum(positions, max(self.key_ids.size - 1, 0))
        found = candidate & (self.key_ids[safe_positions] == keys)
        dst = np.flatnonzero(found)
        src = safe_positions[found]
        median[dst] = self.median[src]
        mad[dst] = self.mad[src]
        anchor_median[dst] = self.anchor_median[src]
        anchor_mad[dst] = self.anchor_mad[src]
        confidence[dst] = self.confidence[src]
        adequate[dst] = self.adequate[src]
        scale_floor[dst] = self.scale_floor[src]
        practical_effect_floor[dst] = self.practical_effect_floor[src]
        return ReferenceMatrixLookup(
            ReferenceStateBatch(median, mad, anchor_median, anchor_mad, confidence, adequate),
            scale_floor,
            practical_effect_floor,
            found,
        )
