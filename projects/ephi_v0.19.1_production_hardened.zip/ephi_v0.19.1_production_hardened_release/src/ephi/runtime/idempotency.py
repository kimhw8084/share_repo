from __future__ import annotations

import hashlib
import json
import time
from datetime import datetime, timezone

from pydantic import BaseModel, ConfigDict

from ephi.adapters.base.state_store import StateStore
from ephi.errors import StateConflictError
from ephi.runtime.queue import WorkItem

_STATE_KEY = "runtime:applied-work:v1"
_MAX_RETRIES = 64


class AppliedWork(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    work_id: str
    job_type: str
    request_sha256: str
    completed_at: datetime


def _request_digest(item: WorkItem) -> str:
    payload = {
        "work_id": item.work_id,
        "job_type": item.job_type,
        "payload": item.payload,
        "depends_on": item.depends_on,
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


class AppliedWorkLedger:
    """Durable completion ledger for the queue crash window.

    The ledger is written after a handler reports success and before queue completion.
    If a process dies in that interval, a replacement worker can reclaim the lease and
    recognize that EPHI already applied the work. External effects still need their own
    idempotency key because no generic local ledger can transactionally cover arbitrary
    external systems.
    """

    def __init__(self, state_store: StateStore) -> None:
        self.state_store = state_store

    def _load(self) -> tuple[dict[str, AppliedWork], int | None]:
        record = self.state_store.get(_STATE_KEY)
        if record is None:
            return {}, None
        raw = json.loads(record.value.decode("utf-8"))
        items = [AppliedWork.model_validate(item) for item in raw]
        return {item.work_id: item for item in items}, record.version

    @staticmethod
    def _encode(items: dict[str, AppliedWork]) -> bytes:
        return json.dumps(
            [items[key].model_dump(mode="json") for key in sorted(items)],
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")

    def get(self, work_id: str) -> AppliedWork | None:
        items, _ = self._load()
        return items.get(work_id)

    def already_applied(self, item: WorkItem) -> bool:
        existing = self.get(item.work_id)
        if existing is None:
            return False
        if existing.job_type != item.job_type or existing.request_sha256 != _request_digest(item):
            raise ValueError(f"applied-work identity collision for {item.work_id}")
        return True

    def record(self, item: WorkItem, *, completed_at: datetime | None = None) -> AppliedWork:
        applied = AppliedWork(
            work_id=item.work_id,
            job_type=item.job_type,
            request_sha256=_request_digest(item),
            completed_at=completed_at or datetime.now(timezone.utc),
        )
        last: StateConflictError | None = None
        for attempt in range(_MAX_RETRIES):
            items, version = self._load()
            existing = items.get(item.work_id)
            if existing is not None:
                if existing.job_type != applied.job_type or existing.request_sha256 != applied.request_sha256:
                    raise ValueError(f"applied-work identity collision for {item.work_id}")
                return existing
            updated = dict(items)
            updated[item.work_id] = applied
            try:
                self.state_store.compare_and_set(
                    _STATE_KEY,
                    expected_version=version,
                    value=self._encode(updated),
                )
                return applied
            except StateConflictError as exc:
                last = exc
                time.sleep(min(0.0005 * (attempt + 1), 0.02))
        raise StateConflictError("applied-work ledger remained contended") from last
