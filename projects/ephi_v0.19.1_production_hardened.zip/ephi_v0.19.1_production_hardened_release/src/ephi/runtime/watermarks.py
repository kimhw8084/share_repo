from __future__ import annotations

import json
from datetime import datetime, timezone

from pydantic import BaseModel, ConfigDict

from ephi.adapters.base.state_store import StateStore


class Watermark(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    source_id: str
    available_through: datetime
    source_revision: str | None = None
    updated_at: datetime


class WatermarkStore:
    def __init__(self, state_store: StateStore, *, namespace: str = "watermark") -> None:
        self.state_store = state_store
        self.namespace = namespace

    def _key(self, source_id: str) -> str:
        return f"{self.namespace}:{source_id}"

    def get(self, source_id: str) -> tuple[Watermark | None, int | None]:
        record = self.state_store.get(self._key(source_id))
        if record is None:
            return None, None
        payload = json.loads(record.value.decode("utf-8"))
        return Watermark.model_validate(payload), record.version

    def commit(
        self,
        *,
        source_id: str,
        available_through: datetime,
        expected_state_version: int | None,
        source_revision: str | None = None,
    ) -> tuple[Watermark, int]:
        current, _ = self.get(source_id)
        if current is not None and available_through < current.available_through:
            raise ValueError("Watermark cannot move backward")
        watermark = Watermark(
            source_id=source_id,
            available_through=available_through,
            source_revision=source_revision,
            updated_at=datetime.now(timezone.utc),
        )
        record = self.state_store.compare_and_set(
            self._key(source_id),
            expected_version=expected_state_version,
            value=watermark.model_dump_json().encode("utf-8"),
        )
        return watermark, record.version
