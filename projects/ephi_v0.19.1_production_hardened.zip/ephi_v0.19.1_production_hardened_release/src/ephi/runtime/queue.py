from __future__ import annotations

import json
import time
from datetime import datetime, timedelta, timezone
from enum import StrEnum
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ephi.adapters.base.state_store import StateStore
from ephi.errors import StateConflictError


_STATE_KEY = "runtime:work-queue:v1"
_MAX_CAS_RETRIES = 64


class WorkStatus(StrEnum):
    PENDING = "PENDING"
    LEASED = "LEASED"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"


class WorkItem(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    work_id: str
    job_type: str
    payload: dict[str, object] = Field(default_factory=dict)
    priority: int = Field(default=100, ge=0)
    depends_on: tuple[str, ...] = ()
    status: WorkStatus = WorkStatus.PENDING
    attempts: int = Field(default=0, ge=0)
    created_at: datetime
    leased_by: str | None = None
    lease_expires_at: datetime | None = None
    last_error: str | None = None

    @model_validator(mode="after")
    def valid_dependencies(self) -> "WorkItem":
        if self.work_id in self.depends_on:
            raise ValueError("work item cannot depend on itself")
        if len(self.depends_on) != len(set(self.depends_on)):
            raise ValueError("work dependencies must be unique")
        return self


class DurableWorkQueue:
    """Portable CAS queue with at-least-once delivery and explicit dependencies.

    ``work_id`` is the idempotency key. Re-enqueueing the same logical request is a
    no-op; reusing the same ID for different content is rejected. Claims are committed
    through compare-and-set with bounded retry so multiple reference processes cannot
    silently lose queue updates. Handlers must remain idempotent because leases may be
    reclaimed after a crash.
    """

    def __init__(self, state_store: StateStore) -> None:
        self.state_store = state_store
        self._items: dict[str, WorkItem] = {}
        self._state_version: int | None = None
        self.restore()

    @staticmethod
    def _same_request(
        existing: WorkItem,
        *,
        job_type: str,
        payload: dict[str, object],
        priority: int,
        depends_on: tuple[str, ...],
    ) -> bool:
        return (
            existing.job_type == job_type
            and existing.payload == payload
            and existing.priority == priority
            and existing.depends_on == depends_on
        )

    @staticmethod
    def _encode(items: dict[str, WorkItem]) -> bytes:
        ordered = [items[key].model_dump(mode="json") for key in sorted(items)]
        return json.dumps(ordered, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def _commit(self, items: dict[str, WorkItem], *, expected_version: int | None) -> None:
        record = self.state_store.compare_and_set(
            _STATE_KEY,
            expected_version=expected_version,
            value=self._encode(items),
        )
        self._items = items
        self._state_version = record.version

    def _retry(self, operation):
        last: StateConflictError | None = None
        for attempt in range(_MAX_CAS_RETRIES):
            self.restore()
            try:
                return operation()
            except StateConflictError as exc:
                last = exc
                time.sleep(min(0.0005 * (attempt + 1), 0.02))
        raise StateConflictError("work queue remained contended after bounded retry") from last

    def enqueue(
        self,
        job_type: str,
        *,
        payload: dict[str, object] | None = None,
        priority: int = 100,
        depends_on: tuple[str, ...] = (),
        work_id: str | None = None,
        created_at: datetime | None = None,
    ) -> WorkItem:
        identifier = work_id or f"WORK-{uuid4().hex[:16]}"
        request_payload = payload or {}
        dependencies = tuple(depends_on)

        def op() -> WorkItem:
            existing = self._items.get(identifier)
            if existing is not None:
                if not self._same_request(
                    existing,
                    job_type=job_type,
                    payload=request_payload,
                    priority=priority,
                    depends_on=dependencies,
                ):
                    raise ValueError(f"work_id {identifier!r} reused for different request")
                return existing
            item = WorkItem(
                work_id=identifier,
                job_type=job_type,
                payload=request_payload,
                priority=priority,
                depends_on=dependencies,
                created_at=created_at or datetime.now(timezone.utc),
            )
            updated = dict(self._items)
            updated[identifier] = item
            self._commit(updated, expected_version=self._state_version)
            return item

        return self._retry(op)

    def _dependencies_satisfied(self, item: WorkItem) -> bool:
        for dependency_id in item.depends_on:
            dependency = self._items.get(dependency_id)
            if dependency is None or dependency.status != WorkStatus.SUCCEEDED:
                return False
        return True

    def _eligible(self, item: WorkItem, now: datetime, accepted: set[str] | None) -> bool:
        if accepted is not None and item.job_type not in accepted:
            return False
        if not self._dependencies_satisfied(item):
            return False
        if item.status == WorkStatus.PENDING:
            return True
        if item.status == WorkStatus.LEASED and item.lease_expires_at is not None and item.lease_expires_at <= now:
            return True
        return False

    def claim(
        self,
        *,
        worker_id: str,
        accepted_job_types: set[str] | None = None,
        lease_seconds: int = 300,
        now: datetime | None = None,
    ) -> WorkItem | None:
        if lease_seconds < 1:
            raise ValueError("lease_seconds must be >= 1")
        when = now or datetime.now(timezone.utc)

        def op() -> WorkItem | None:
            eligible = [item for item in self._items.values() if self._eligible(item, when, accepted_job_types)]
            if not eligible:
                return None
            eligible.sort(key=lambda item: (item.priority, item.created_at, item.work_id))
            item = eligible[0]
            leased = item.model_copy(
                update={
                    "status": WorkStatus.LEASED,
                    "attempts": item.attempts + 1,
                    "leased_by": worker_id,
                    "lease_expires_at": when + timedelta(seconds=lease_seconds),
                    "last_error": None,
                }
            )
            updated = dict(self._items)
            updated[item.work_id] = leased
            self._commit(updated, expected_version=self._state_version)
            return leased

        return self._retry(op)

    def complete(self, work_id: str, *, worker_id: str) -> WorkItem:
        def op() -> WorkItem:
            item = self._items[work_id]
            if item.status != WorkStatus.LEASED or item.leased_by != worker_id:
                raise ValueError("work item is not leased by this worker")
            completed = item.model_copy(
                update={
                    "status": WorkStatus.SUCCEEDED,
                    "leased_by": None,
                    "lease_expires_at": None,
                }
            )
            updated = dict(self._items)
            updated[work_id] = completed
            self._commit(updated, expected_version=self._state_version)
            return completed

        return self._retry(op)

    def fail(self, work_id: str, *, worker_id: str, error: str, retry: bool = True) -> WorkItem:
        def op() -> WorkItem:
            item = self._items[work_id]
            if item.status != WorkStatus.LEASED or item.leased_by != worker_id:
                raise ValueError("work item is not leased by this worker")
            failed = item.model_copy(
                update={
                    "status": WorkStatus.PENDING if retry else WorkStatus.FAILED,
                    "leased_by": None,
                    "lease_expires_at": None,
                    "last_error": error,
                }
            )
            updated = dict(self._items)
            updated[work_id] = failed
            self._commit(updated, expected_version=self._state_version)
            return failed

        return self._retry(op)

    def items(self) -> tuple[WorkItem, ...]:
        return tuple(sorted(self._items.values(), key=lambda item: item.work_id))

    def checkpoint(self) -> None:
        self._commit(dict(self._items), expected_version=self._state_version)

    def restore(self) -> None:
        record = self.state_store.get(_STATE_KEY)
        if record is None:
            self._items = {}
            self._state_version = None
            return
        raw = json.loads(record.value.decode("utf-8"))
        items = [WorkItem.model_validate(item) for item in raw]
        self._items = {item.work_id: item for item in items}
        self._state_version = record.version
