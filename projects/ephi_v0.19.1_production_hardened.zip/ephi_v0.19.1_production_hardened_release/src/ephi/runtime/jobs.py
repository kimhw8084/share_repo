from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from enum import StrEnum
from typing import Callable

from pydantic import BaseModel, ConfigDict


class JobStatus(StrEnum):
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"


class JobDefinition(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    job_id: str
    version: str
    incremental: bool = True
    resource_profile: str = "core"


@dataclass(frozen=True, slots=True)
class JobResult:
    job_id: str
    status: JobStatus
    started_at: datetime
    ended_at: datetime
    records_in: int = 0
    records_out: int = 0


class JobRunner:
    """Thin job envelope. Scientific orchestration remains outside this class."""

    def run(self, definition: JobDefinition, operation: Callable[[], tuple[int, int]]) -> JobResult:
        started = datetime.now(timezone.utc)
        try:
            records_in, records_out = operation()
        except Exception:
            ended = datetime.now(timezone.utc)
            # The caller/logging layer owns error persistence and retry classification.
            raise
        ended = datetime.now(timezone.utc)
        return JobResult(
            job_id=definition.job_id,
            status=JobStatus.SUCCEEDED,
            started_at=started,
            ended_at=ended,
            records_in=records_in,
            records_out=records_out,
        )
