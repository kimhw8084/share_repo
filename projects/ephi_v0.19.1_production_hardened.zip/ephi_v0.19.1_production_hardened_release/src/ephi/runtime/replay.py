from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass

from ephi.domain.evidence import Hypothesis
from ephi.domain.health import HealthSeverity
from ephi.health.engine import BehavioralHealthPipeline
from ephi.synthetic.scalar import ScalarScenarioConfig, generate_scalar_observations


@dataclass(frozen=True, slots=True)
class SyntheticReplaySummary:
    scenario: str
    seed: int
    assets: int
    executions_per_asset: int
    observations: int
    assessments: int
    actionable_assessments: int
    actionable_by_asset: dict[str, int]
    leading_hypotheses: dict[str, int]
    active_episodes: int
    resolved_episodes: int
    first_actionable_execution: str | None

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def run_synthetic_replay(config: ScalarScenarioConfig) -> SyntheticReplaySummary:
    observations = generate_scalar_observations(config)
    pipeline = BehavioralHealthPipeline()
    result = pipeline.process(observations)
    actionable = [a for a in result.assessments if a.severity >= HealthSeverity.INVESTIGATE]
    by_asset = Counter(a.asset_id for a in actionable)
    hypotheses = Counter(a.leading_hypothesis.value for a in result.assessments)
    return SyntheticReplaySummary(
        scenario=config.scenario,
        seed=config.seed,
        assets=config.n_assets,
        executions_per_asset=config.executions_per_asset,
        observations=len(observations),
        assessments=len(result.assessments),
        actionable_assessments=len(actionable),
        actionable_by_asset=dict(sorted(by_asset.items())),
        leading_hypotheses=dict(sorted(hypotheses.items())),
        active_episodes=len(pipeline.episodes.active()),
        resolved_episodes=len(pipeline.episodes.history()),
        first_actionable_execution=actionable[0].execution_id if actionable else None,
    )


@dataclass(frozen=True, slots=True)
class MetrologyReplaySummary:
    scenario: str
    seed: int
    heads: int
    measurements_per_head: int
    site_observations: int
    measurement_results: int
    assessments: int
    actionable_assessments: int
    actionable_by_asset: dict[str, int]
    leading_hypotheses: dict[str, int]
    active_local_episodes: int
    active_fleet_episodes: int
    first_actionable_measurement: str | None

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def run_metrology_replay(config) -> MetrologyReplaySummary:
    from ephi.metrology.engine import MetrologyHealthPipeline
    from ephi.synthetic.metrology import generate_metrology_observations

    observations = generate_metrology_observations(config)
    pipeline = MetrologyHealthPipeline()
    result = pipeline.process(observations)
    actionable = [a for a in result.assessments if a.severity >= HealthSeverity.INVESTIGATE]
    by_asset = Counter(a.asset_id for a in actionable)
    hypotheses = Counter(a.leading_hypothesis.value for a in result.assessments)
    return MetrologyReplaySummary(
        scenario=config.scenario,
        seed=config.seed,
        heads=config.n_heads,
        measurements_per_head=config.measurements_per_head,
        site_observations=len(observations),
        measurement_results=len(result.measurements),
        assessments=len(result.assessments),
        actionable_assessments=len(actionable),
        actionable_by_asset=dict(sorted(by_asset.items())),
        leading_hypotheses=dict(sorted(hypotheses.items())),
        active_local_episodes=len(pipeline.episodes.active()),
        active_fleet_episodes=len(pipeline.fleet_episodes.active()),
        first_actionable_measurement=actionable[0].execution_id if actionable else None,
    )
