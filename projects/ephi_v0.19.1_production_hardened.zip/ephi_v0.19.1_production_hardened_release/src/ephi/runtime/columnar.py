from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ephi.detectors.columnar import (
    PeerColumnarScores,
    ScalarColumnarScores,
    peer_decompose_grouped_arrays,
    score_scalar_arrays,
)
from ephi.populations.columnar_state import ReferenceStateMatrixIndex


@dataclass(frozen=True, slots=True)
class ColumnarBehavioralBatch:
    state_key_id: np.ndarray
    peer_group_id: np.ndarray
    value: np.ndarray

    def validate(self) -> int:
        arrays = (
            np.asarray(self.state_key_id),
            np.asarray(self.peer_group_id),
            np.asarray(self.value),
        )
        if any(array.ndim != 1 for array in arrays):
            raise ValueError("columnar behavioral batch arrays must be one-dimensional")
        if not (arrays[0].shape == arrays[1].shape == arrays[2].shape):
            raise ValueError("columnar behavioral batch arrays must have equal length")
        return int(arrays[0].size)


@dataclass(frozen=True, slots=True)
class ColumnarBehavioralResult:
    scalar: ScalarColumnarScores
    peer: PeerColumnarScores
    reference_confidence: np.ndarray
    reference_found: np.ndarray
    practical_effect_met: np.ndarray


class ColumnarBehavioralScorer:
    """Production-oriented stateless scoring over materialized reference state.

    Sequential state and reference admission remain separate incremental stages;
    this scorer is intentionally free of historical queries and Python row objects.
    """

    def __init__(self, references: ReferenceStateMatrixIndex, *, unit_jump_ratio: float = 100.0) -> None:
        self.references = references
        self.unit_jump_ratio = unit_jump_ratio

    def score(self, batch: ColumnarBehavioralBatch) -> ColumnarBehavioralResult:
        batch.validate()
        lookup = self.references.lookup_ids(np.asarray(batch.state_key_id, dtype=np.uint64))
        scalar = score_scalar_arrays(
            np.asarray(batch.value, dtype=np.float64),
            lookup.reference,
            unit_jump_ratio=self.unit_jump_ratio,
        )
        peer = peer_decompose_grouped_arrays(
            scalar.physical_change,
            np.maximum(lookup.reference.anchor_mad, lookup.scale_floor),
            np.asarray(batch.peer_group_id),
        )
        effect = np.abs(scalar.physical_change)
        practical_effect_met = (
            lookup.found
            & np.isfinite(effect)
            & np.isfinite(lookup.practical_effect_floor)
            & (effect >= lookup.practical_effect_floor)
        )
        return ColumnarBehavioralResult(
            scalar=scalar,
            peer=peer,
            reference_confidence=lookup.reference.confidence,
            reference_found=lookup.found,
            practical_effect_met=practical_effect_met,
        )
