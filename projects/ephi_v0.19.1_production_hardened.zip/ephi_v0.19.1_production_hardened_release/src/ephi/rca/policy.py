from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import yaml

@dataclass(frozen=True, slots=True)
class RCARankingPolicy:
    version:str="rca-ranking-v1"
    prevalence_weight:float=2.5
    relative_risk_weight:float=.5
    temporal_weight:float=.8
    health_weight:float=.9
    control_robustness_weight:float=.7
    historical_weight:float=.5
    temporal_contradiction_multiplier:float=.1
    high_score:float=3.0
    moderate_score:float=1.8
    weak_score:float=.8
    high_min_control_robustness:float=.75


def load_rca_ranking_policy(path:str|Path)->RCARankingPolicy:
    raw=yaml.safe_load(Path(path).read_text()) or {}
    base=RCARankingPolicy()
    values={name:raw.get(name,getattr(base,name)) for name in base.__dataclass_fields__}
    values['version']=str(values['version'])
    for k in values:
        if k!='version': values[k]=float(values[k])
    return RCARankingPolicy(**values)
