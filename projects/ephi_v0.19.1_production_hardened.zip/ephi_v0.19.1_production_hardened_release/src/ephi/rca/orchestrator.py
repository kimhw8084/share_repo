from __future__ import annotations
from ephi.domain.rca import AffectedMaterial, InvestigationSeed, RCACandidate
from .commonality import CommonalityEngine
from .service import RCAService
from .source import RCASourceRepository

class RCAOrchestrator:
    def __init__(self, source:RCASourceRepository, *, commonality:CommonalityEngine|None=None, ranking:RCAService|None=None):
        self.source=source; self.commonality=commonality or CommonalityEngine(); self.ranking=ranking or RCAService()
    def run(self, seed:InvestigationSeed, affected:tuple[AffectedMaterial,...], *, historical_factor_support:dict[str,float]|None=None, top_k:int=10)->tuple[RCACandidate,...]:
        controls=self.source.controls(seed.episode_id); routes=self.source.route_tokens(seed.episode_id)
        common=self.commonality.rank(affected,controls,routes,onset_time=seed.onset_best,max_sequence_lookback=seed.lookback_operations,top_k=max(25,top_k*3))
        return self.ranking.candidates(seed,common,historical_factor_support=historical_factor_support,top_k=top_k)
