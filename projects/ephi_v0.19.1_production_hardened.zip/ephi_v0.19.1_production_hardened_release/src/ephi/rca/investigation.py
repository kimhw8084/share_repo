from __future__ import annotations

from ephi.domain.evidence import Hypothesis
from ephi.domain.exposure import ExposureSnapshot, MaterialExposureClass
from ephi.domain.rca import InvestigationSeed
from ephi.domain.episode import HealthEpisode
from ephi.domain.health import HealthAssessment


def build_investigation_seed(episode:HealthEpisode, assessment:HealthAssessment, exposure:ExposureSnapshot, *, control_set_ids:tuple[str,...]=(), historical_case_ids:tuple[str,...]=(), lookback_operations:int=5)->InvestigationSeed:
    affected=tuple(i.material_id for i in exposure.items if i.exposure_class in {MaterialExposureClass.DEFINITE_PAST_EXPOSURE,MaterialExposureClass.POSSIBLE_PAST_EXPOSURE})
    ordered=sorted(assessment.hypothesis_support,key=lambda x:x.net,reverse=True)
    leading=tuple(x.hypothesis for x in ordered[:3] if x.net>0) or (assessment.leading_hypothesis,)
    return InvestigationSeed(seed_id=f"SEED:{episode.episode_id}:v1",episode_id=episode.episode_id,asset_id=episode.asset_id,context=episode.context.to_dict(),onset_low=exposure.onset_low,onset_best=exposure.onset_best,onset_high=exposure.onset_high,affected_material_ids=affected,control_set_ids=control_set_ids,leading_hypotheses=leading,top_historical_case_ids=historical_case_ids,lookback_operations=lookback_operations)
