from __future__ import annotations
from dataclasses import dataclass, field
from typing import Protocol
from ephi.domain.rca import ControlPopulation, RouteToken

class RCASourceRepository(Protocol):
    def route_tokens(self, episode_id:str)->tuple[RouteToken,...]: ...
    def controls(self, episode_id:str)->tuple[ControlPopulation,...]: ...

@dataclass(slots=True)
class InMemoryRCASourceRepository:
    routes:dict[str,tuple[RouteToken,...]]=field(default_factory=dict)
    control_sets:dict[str,tuple[ControlPopulation,...]]=field(default_factory=dict)
    def route_tokens(self,episode_id:str)->tuple[RouteToken,...]: return self.routes.get(episode_id,())
    def controls(self,episode_id:str)->tuple[ControlPopulation,...]: return self.control_sets.get(episode_id,())
