from __future__ import annotations

from collections import defaultdict
from math import log
from ephi.domain.rca import AffectedMaterial, CommonalityEvidence, ControlPopulation, RouteToken, TemporalPlausibility


def _rr(a:int,n_a:int,c:int,n_c:int)->float:
    # Haldane-like smoothing only when needed; keeps zero-cell factors finite and comparable.
    pa=(a+0.5)/(n_a+1.0); pc=(c+0.5)/(n_c+1.0)
    return pa/pc if pc else 0.0

def _or(a:int,n_a:int,c:int,n_c:int)->float:
    b=max(0,n_a-a); d=max(0,n_c-c)
    return ((a+0.5)*(d+0.5))/((b+0.5)*(c+0.5))


class CommonalityEngine:
    def rank(
        self,
        affected: tuple[AffectedMaterial,...],
        controls: tuple[ControlPopulation,...],
        route_tokens: tuple[RouteToken,...],
        *,
        onset_time=None,
        max_sequence_lookback:int|None=None,
        top_k:int=25,
    )->tuple[CommonalityEvidence,...]:
        affected_ids={x.material_id for x in affected}
        severity={x.material_id:x.severity_weight for x in affected}
        outcome_times={x.material_id:x.outcome_time for x in affected}
        control_sets=[set(c.material_ids) for c in controls]
        all_control_ids=set().union(*control_sets) if control_sets else set()
        by_material:dict[str,list[RouteToken]]=defaultdict(list)
        for tok in route_tokens:
            if tok.material_id in affected_ids or tok.material_id in all_control_ids:
                by_material[tok.material_id].append(tok)
        # progressive lookback: retain only the latest N route tokens for each material when requested.
        if max_sequence_lookback:
            for mid,toks in by_material.items():
                by_material[mid]=sorted(toks,key=lambda x:x.sequence)[-max_sequence_lookback:]
        factor_materials:dict[str,set[str]]=defaultdict(set)
        factor_health:dict[str,list[float]]=defaultdict(list)
        factor_times:dict[tuple[str,str],list]=defaultdict(list)
        for mid,toks in by_material.items():
            for tok in toks:
                for factor in tok.factor_keys:
                    factor_materials[factor].add(mid)
                    factor_health[factor].append(tok.health_strength)
                    factor_times[(factor,mid)].append(tok.event_time)
        output=[]
        n_a=len(affected_ids)
        for factor,mids in factor_materials.items():
            a=len(mids & affected_ids)
            if a==0: continue
            per_controls=[]
            for control,ids in zip(controls,control_sets):
                c=len(mids & ids); n_c=len(ids)
                if n_c==0: continue
                ap=a/n_a if n_a else 0.0; cp=c/n_c
                per_controls.append((control.confidence, c,n_c,ap-cp,_rr(a,n_a,c,n_c),_or(a,n_a,c,n_c)))
            if not per_controls: continue
            # conservative aggregation across multiple valid control definitions.
            c=sum(x[1] for x in per_controls); n_c=sum(x[2] for x in per_controls)
            control_prev=sum((x[1]/x[2])*x[0] for x in per_controls)/max(1e-12,sum(x[0] for x in per_controls))
            ap=a/n_a if n_a else 0.0
            robustness=sum(1 for x in per_controls if x[3]>0)/len(per_controls)
            weights=[severity[mid] for mid in mids & affected_ids]
            sev_assoc=(sum(weights)/len(weights)-1.0) if weights else 0.0
            ordered_pairs=[(t,outcome_times.get(mid)) for mid in mids & affected_ids for t in factor_times[(factor,mid)] if outcome_times.get(mid) is not None]
            if not ordered_pairs:
                # Episode onset is not a valid substitute for downstream material outcome time.
                # Without material-level ordering evidence, abstain rather than fabricate contradiction.
                temporal=TemporalPlausibility.UNCERTAIN; temporal_support=0.5
            else:
                before=sum(1 for t,outcome in ordered_pairs if t <= outcome)
                temporal_support=before/len(ordered_pairs)
                if before == 0:
                    temporal=TemporalPlausibility.CONTRADICTS
                elif temporal_support >= 0.8:
                    temporal=TemporalPlausibility.SUPPORTS
                else:
                    temporal=TemporalPlausibility.UNCERTAIN
            rr=sum(x[4]*x[0] for x in per_controls)/max(1e-12,sum(x[0] for x in per_controls))
            odds=sum(x[5]*x[0] for x in per_controls)/max(1e-12,sum(x[0] for x in per_controls))
            health=max(factor_health[factor],default=0.0)
            confidence=min(1.0, (0.35+0.65*min(1.0,n_a/20))*robustness)
            output.append(CommonalityEvidence(factor=factor,affected_count=a,affected_total=n_a,control_count=c,control_total=n_c,affected_prevalence=ap,control_prevalence=control_prev,prevalence_difference=ap-control_prev,relative_risk=rr,odds_ratio=odds,severity_association=sev_assoc,temporal_plausibility=temporal,temporal_support=temporal_support,health_support=health,control_robustness=robustness,confidence=confidence))
        output.sort(key=lambda x:(x.temporal_plausibility is TemporalPlausibility.SUPPORTS, x.control_robustness, x.prevalence_difference, log1p_safe(x.relative_risk), x.health_support),reverse=True)
        return tuple(output[:top_k])

def log1p_safe(value:float)->float:
    from math import log1p
    return log1p(max(0.0,value))
