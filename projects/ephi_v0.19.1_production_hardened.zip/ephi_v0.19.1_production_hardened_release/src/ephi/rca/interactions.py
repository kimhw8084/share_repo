from __future__ import annotations
from itertools import combinations
from collections import defaultdict
from pydantic import BaseModel,ConfigDict,Field
from ephi.domain.rca import AffectedMaterial,ControlPopulation,RouteToken

class PairwiseInteraction(BaseModel):
    model_config=ConfigDict(frozen=True)
    factor_a:str; factor_b:str
    affected_prevalence:float=Field(ge=0,le=1)
    control_prevalence:float=Field(ge=0,le=1)
    interaction_lift:float
    affected_count:int=Field(ge=0)
    control_count:int=Field(ge=0)


def rank_top_pairwise(affected:tuple[AffectedMaterial,...],controls:tuple[ControlPopulation,...],tokens:tuple[RouteToken,...],*,candidate_factors:tuple[str,...],top_k:int=10)->tuple[PairwiseInteraction,...]:
    """Bounded pairwise follow-up only; never a fab-wide combinatorial search."""
    def eligible(f:str)->bool:
        family=f.split(":",1)[0]
        return family in {"ASSET","RECIPE","PROCESS_REGIME","HEALTH_EPISODE","MAINTENANCE","COMPONENT"}
    factors=tuple(f for f in dict.fromkeys(candidate_factors[:top_k]) if eligible(f))
    if len(factors)<2:return ()
    aff_ids={x.material_id for x in affected}; ctrl_ids=set().union(*(set(c.material_ids) for c in controls)) if controls else set()
    by_mid=defaultdict(set)
    for t in tokens:
        if t.material_id in aff_ids or t.material_id in ctrl_ids:
            by_mid[t.material_id].update(t.factor_keys)
    individual={f:(sum(f in by_mid[m] for m in aff_ids)/max(1,len(aff_ids)),sum(f in by_mid[m] for m in ctrl_ids)/max(1,len(ctrl_ids))) for f in factors}
    out=[]
    for a,b in combinations(factors,2):
        ac=sum(a in by_mid[m] and b in by_mid[m] for m in aff_ids); cc=sum(a in by_mid[m] and b in by_mid[m] for m in ctrl_ids)
        ap=ac/max(1,len(aff_ids)); cp=cc/max(1,len(ctrl_ids))
        # Interaction lift asks whether joint affected-vs-control separation exceeds the better single factor.\n
        single=max(individual[a][0]-individual[a][1],individual[b][0]-individual[b][1])
        lift=(ap-cp)-single
        if ac>0 and lift>0:
            out.append(PairwiseInteraction(factor_a=a,factor_b=b,affected_prevalence=ap,control_prevalence=cp,interaction_lift=lift,affected_count=ac,control_count=cc))
    return tuple(sorted(out,key=lambda x:(x.interaction_lift,x.affected_prevalence),reverse=True)[:top_k])
