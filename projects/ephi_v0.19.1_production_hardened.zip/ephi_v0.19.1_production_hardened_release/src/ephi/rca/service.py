from __future__ import annotations

from ephi.domain.rca import CandidateConfidence, CommonalityEvidence, InvestigationSeed, RCACandidate, TemporalPlausibility
from .policy import RCARankingPolicy


class RCAService:
    def __init__(self, policy: RCARankingPolicy | None = None):
        self.policy = policy or RCARankingPolicy()

    def candidates(
        self,
        seed: InvestigationSeed,
        commonalities: tuple[CommonalityEvidence,...],
        *,
        historical_factor_support: dict[str,float] | None=None,
        top_k:int=10,
    )->tuple[RCACandidate,...]:
        historical_factor_support=historical_factor_support or {}
        scored=[]
        for ev in commonalities:
            contradictions=[]
            if ev.temporal_plausibility is TemporalPlausibility.CONTRADICTS:
                contradictions.append("candidate exposure occurs after the suspected onset")
            if ev.control_robustness < 0.5:
                contradictions.append("enrichment is not robust across control definitions")
            if ev.prevalence_difference <= 0:
                contradictions.append("factor is not enriched versus controls")
            hist=max(0.0,min(1.0,historical_factor_support.get(ev.factor,0.0)))
            p=self.policy
            score=(
                max(0.0,ev.prevalence_difference)*p.prevalence_weight
                + min(2.0,max(0.0,ev.relative_risk-1.0))*p.relative_risk_weight
                + ev.temporal_support*p.temporal_weight
                + min(1.0,ev.health_support)*p.health_weight
                + ev.control_robustness*p.control_robustness_weight
                + hist*p.historical_weight
            )*ev.confidence
            if ev.temporal_plausibility is TemporalPlausibility.CONTRADICTS:
                score*=p.temporal_contradiction_multiplier
            if contradictions and ev.temporal_plausibility is TemporalPlausibility.CONTRADICTS:
                band=CandidateConfidence.CONTRADICTED
            elif score>=p.high_score and ev.control_robustness>=p.high_min_control_robustness:
                band=CandidateConfidence.HIGH
            elif score>=p.moderate_score:
                band=CandidateConfidence.MODERATE
            elif score>=p.weak_score:
                band=CandidateConfidence.WEAK
            else:
                band=CandidateConfidence.INSUFFICIENT
            scored.append((score,ev,hist,tuple(contradictions),band))
        scored.sort(key=lambda x:x[0],reverse=True)
        return tuple(RCACandidate(candidate_id=f"{seed.seed_id}:CAND:{i+1}",factor=ev.factor,rank=i+1,enrichment=ev,historical_support=hist,contradiction_reasons=contradictions,evidence_score=max(0.0,score),confidence_band=band,recommended_check=self._recommended_check(ev.factor)) for i,(score,ev,hist,contradictions,band) in enumerate(scored[:top_k]))

    @staticmethod
    def _recommended_check(factor:str)->str:
        if factor.startswith("HEALTH_EPISODE:"):
            return "Verify the candidate asset state, exposure timing, and downstream recovery around the linked EPHI episode."
        if factor.startswith("ASSET_RECIPE:"):
            return "Compare the same recipe on unaffected qualified assets and inspect asset×recipe interaction evidence."
        if factor.startswith("ASSET:"):
            return "Verify affected-versus-control exposure on this asset and inspect its EPHI health state before exposure."
        if factor.startswith("RECIPE:") or factor.startswith("PROCESS_REGIME:"):
            return "Compare affected and control material under the same route while varying recipe/process regime."
        return "Verify temporal ordering and matched-control enrichment for this factor before assigning causal meaning."
