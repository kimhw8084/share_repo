from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from ephi.advisory.service import AdvisoryService
from ephi.domain.history import EpisodeFingerprint, SimilarityResult, HistoricalAnalogue
from ephi.domain.rca import AffectedMaterial, AffectedMembership, InvestigationSeed, RCACandidate
from ephi.history.service import HistoricalIntelligenceService
from ephi.history.recurrence import RecurrenceSummary
from ephi.rca.investigation import build_investigation_seed
from ephi.rca.orchestrator import RCAOrchestrator


@dataclass(slots=True)
class HistoryRCAApplicationService:
    advisory: AdvisoryService
    historical: HistoricalIntelligenceService
    rca: RCAOrchestrator
    fingerprints: dict[str, EpisodeFingerprint] = field(default_factory=dict)

    def register_fingerprint(self, fingerprint: EpisodeFingerprint) -> None:
        self.fingerprints[fingerprint.episode_id] = fingerprint

    def _fingerprint_and_source(self, episode_id: str):
        source = self.advisory.sources.get(episode_id)
        if source is None:
            raise KeyError(f"unknown episode: {episode_id}")
        fp = self.fingerprints.get(episode_id)
        if fp is None:
            raise KeyError(f"historical fingerprint unavailable for episode: {episode_id}")
        return fp, source

    def analogue_matches(self, episode_id: str, *, top_k: int = 5, as_of: datetime | None = None) -> tuple[SimilarityResult, ...]:
        fp, source = self._fingerprint_and_source(episode_id)
        return self.historical.analogues(fp, as_of=as_of or source.assessment.event_time, top_k=top_k)

    def analogues(self, episode_id: str, *, top_k: int = 5, as_of: datetime | None = None) -> tuple[HistoricalAnalogue, ...]:
        fp, source = self._fingerprint_and_source(episode_id)
        return self.historical.analogue_views(fp, as_of=as_of or source.assessment.event_time, top_k=top_k)

    def recurrence(self, episode_id: str, *, top_k: int = 20, min_similarity: float = 0.65) -> RecurrenceSummary:
        matches=self.analogue_matches(episode_id,top_k=top_k)
        return self.historical.recurrence(matches,min_similarity=min_similarity)

    def investigation_seed(self, episode_id: str, *, top_k_analogues: int = 5) -> InvestigationSeed:
        source = self.advisory.sources.get(episode_id)
        if source is None:
            raise KeyError(f"unknown episode: {episode_id}")
        if source.exposure_snapshot is None:
            raise KeyError(f"exposure unavailable for episode: {episode_id}")
        analogues = self.analogues(episode_id, top_k=top_k_analogues)
        controls = self.rca.source.controls(episode_id)
        return build_investigation_seed(
            source.episode,
            source.assessment,
            source.exposure_snapshot,
            control_set_ids=tuple(x.control_set_id for x in controls),
            historical_case_ids=tuple(x.case_id for x in analogues),
        )

    def rca_candidates(self, episode_id: str, *, top_k: int = 10) -> tuple[RCACandidate, ...]:
        source = self.advisory.sources.get(episode_id)
        if source is None:
            raise KeyError(f"unknown episode: {episode_id}")
        if source.exposure_snapshot is None:
            raise KeyError(f"exposure unavailable for episode: {episode_id}")
        seed = self.investigation_seed(episode_id)
        affected = tuple(
            AffectedMaterial(
                material_id=item.material_id,
                membership=(AffectedMembership.DEFINITE if item.exposure_class.value == "DEFINITE_PAST_EXPOSURE" else AffectedMembership.POSSIBLE),
                severity_weight=1.0,
            )
            for item in source.exposure_snapshot.items
            if item.material_id in set(seed.affected_material_ids)
        )
        return self.rca.run(seed, affected, top_k=top_k)
