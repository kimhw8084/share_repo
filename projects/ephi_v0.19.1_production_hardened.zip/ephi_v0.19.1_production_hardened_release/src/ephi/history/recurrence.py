from __future__ import annotations

from collections import Counter
from pydantic import BaseModel, ConfigDict, Field
from ephi.domain.history import HistoricalCase, SimilarityResult

class RecurrenceSummary(BaseModel):
    model_config=ConfigDict(frozen=True)
    matched_case_count:int=Field(ge=0)
    confirmed_case_count:int=Field(ge=0)
    dominant_root_cause:str|None=None
    dominant_action:str|None=None
    benign_match_count:int=Field(ge=0)
    confidence:float=Field(ge=0.0,le=1.0)


def summarize_recurrence(matches:tuple[SimilarityResult,...], cases:tuple[HistoricalCase,...], *, min_similarity:float=0.65)->RecurrenceSummary:
    by_id={c.case_id:c for c in cases}
    selected=[(m,by_id[m.case_id]) for m in matches if m.case_id in by_id and m.similarity>=min_similarity]
    causes=Counter(c.root_cause_category for _,c in selected if c.root_cause_category and c.root_cause_confidence>=0.6)
    actions=Counter(a.action_type for _,c in selected for a in c.actions if a.result.value in {"RESOLVED","PARTIAL_IMPROVEMENT"})
    confirmed=sum(1 for _,c in selected if c.root_cause_confidence>=0.75)
    benign=sum(1 for _,c in selected if c.benign)
    weighted=sum(m.similarity*m.similarity_confidence*c.case_confidence for m,c in selected)
    conf=min(1.0, weighted/max(1,len(selected))) if selected else 0.0
    return RecurrenceSummary(matched_case_count=len(selected),confirmed_case_count=confirmed,dominant_root_cause=causes.most_common(1)[0][0] if causes else None,dominant_action=actions.most_common(1)[0][0] if actions else None,benign_match_count=benign,confidence=conf)
