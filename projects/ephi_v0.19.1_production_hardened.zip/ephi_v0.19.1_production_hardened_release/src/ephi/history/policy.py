from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
import yaml
from ephi.domain.history import FingerprintDomain

@dataclass(frozen=True, slots=True)
class SimilarityPolicy:
    version:str="similarity-v1"
    domain_weights:dict[FingerprintDomain,float]=field(default_factory=lambda:{
        FingerprintDomain.BEHAVIOR:1.0,FingerprintDomain.TEMPORAL:.7,FingerprintDomain.MEASUREMENT_SYSTEM:1.0,
        FingerprintDomain.QUALITY:.8,FingerprintDomain.SPATIAL:.8,FingerprintDomain.MAINTENANCE:.5,FingerprintDomain.ROUTE:.5,
    })
    label_scales:dict[str,float]=field(default_factory=lambda:{
        "BEHAVIOR:novelty":5.0,"BEHAVIOR:severity":5.0,"BEHAVIOR:self":5.0,"BEHAVIOR:peer":5.0,"BEHAVIOR:fleet":5.0,
        "TEMPORAL:duration_h":24.0,"TEMPORAL:peak_novelty":5.0,"TEMPORAL:recovering":1.0,
        "MEASUREMENT_SYSTEM:measurement":5.0,"MEASUREMENT_SYSTEM:cross_tool":5.0,"MEASUREMENT_SYSTEM:repeatability":5.0,"MEASUREMENT_SYSTEM:spatial":5.0,"MEASUREMENT_SYSTEM:production":5.0,
        "QUALITY:association_confidence":1.0,"QUALITY:max_effect":1.0,"MAINTENANCE:age":1000.0,
    })
    strict_context:bool=True
    context_bonus:float=.08
    distance_scale:float=1.0

    def scale(self,domain:FingerprintDomain,label:str|None,index:int)->float:
        key=f"{domain.value}:{label}" if label else f"{domain.value}:{index}"
        return max(1e-12,float(self.label_scales.get(key,1.0)))


def load_similarity_policy(path:str|Path)->SimilarityPolicy:
    raw=yaml.safe_load(Path(path).read_text()) or {}
    weights={FingerprintDomain(k):float(v) for k,v in (raw.get("domain_weights") or {}).items()}
    base=SimilarityPolicy()
    return SimilarityPolicy(version=str(raw.get("version",base.version)),domain_weights={**base.domain_weights,**weights},label_scales={**base.label_scales,**{str(k):float(v) for k,v in (raw.get("label_scales") or {}).items()}},strict_context=bool(raw.get("strict_context",base.strict_context)),context_bonus=float(raw.get("context_bonus",base.context_bonus)),distance_scale=float(raw.get("distance_scale",base.distance_scale)))
