from __future__ import annotations

from math import sqrt

from ephi.domain.history import EpisodeFingerprint, FingerprintDomain, HistoricalCase, SimilarityDomainResult, SimilarityResult


from .policy import SimilarityPolicy


class ExactSimilarityEngine:
    def __init__(self, policy: SimilarityPolicy | None = None): self.policy = policy or SimilarityPolicy()

    @staticmethod
    def _cosine_distance(a: tuple[float, ...], b: tuple[float, ...]) -> float:
        n=min(len(a),len(b))
        if n == 0: return 1.0
        aa=a[:n]; bb=b[:n]
        na=sqrt(sum(x*x for x in aa)); nb=sqrt(sum(x*x for x in bb))
        if na == 0 and nb == 0: return 0.0
        if na == 0 or nb == 0: return 1.0
        cos=sum(x*y for x,y in zip(aa,bb))/(na*nb)
        return max(0.0,min(2.0,1.0-cos))

    @staticmethod
    def _normalized_l2(a: tuple[float, ...], b: tuple[float, ...]) -> float:
        n=min(len(a),len(b))
        if n == 0: return 1.0
        diffs=[a[i]-b[i] for i in range(n)]
        scale=max(1.0, sqrt(sum(a[i]*a[i]+b[i]*b[i] for i in range(n))/max(1,n)))
        return sqrt(sum(x*x for x in diffs)/n)/scale

    def compare(self, query: EpisodeFingerprint, case: HistoricalCase) -> SimilarityResult:
        other=case.fingerprint
        shared=[]; differences=[]
        for name, qa, ob in (
            ("operation",query.operation,other.operation),("recipe",query.recipe_id,other.recipe_id),
            ("product",query.product_id,other.product_id),("technology",query.technology,other.technology),
            ("equipment_family",query.equipment_family,other.equipment_family),
        ):
            (shared if qa==ob else differences).append(name if qa==ob else f"{name}: {qa} != {ob}")
        if self.policy.strict_context and (query.equipment_family != other.equipment_family or query.operation != other.operation):
            return SimilarityResult(case_id=case.case_id,fingerprint_id=other.fingerprint_id,similarity=0.0,similarity_confidence=1.0,case_confidence=case.case_confidence,domain_results=(),shared_context=tuple(shared),important_differences=tuple(differences))
        domain_results=[]; total=0.0; denom=0.0; conf_num=0.0
        for domain,weight in self.policy.domain_weights.items():
            qa=query.component(domain); ob=other.component(domain)
            if qa is None or ob is None: continue
            labels=qa.labels if qa.labels and len(qa.labels)==len(qa.values) else tuple("" for _ in qa.values)
            qvals=tuple(v/self.policy.scale(domain,labels[i] or None,i) for i,v in enumerate(qa.values))
            olabels=ob.labels if ob.labels and len(ob.labels)==len(ob.values) else tuple("" for _ in ob.values)
            ovals=tuple(v/self.policy.scale(domain,olabels[i] or None,i) for i,v in enumerate(ob.values))
            # Cosine captures shape/direction; normalized L2 preserves magnitude after versioned physical/statistical scaling.
            distance=0.45*self._cosine_distance(qvals,ovals)+0.55*self._normalized_l2(qvals,ovals)
            sim=1.0/(1.0+self.policy.distance_scale*distance)
            conf=min(qa.confidence,ob.confidence)
            effective=weight*conf
            domain_results.append(SimilarityDomainResult(domain=domain,similarity=sim,weight=weight,confidence=conf))
            total += sim*effective; denom += effective; conf_num += conf*weight
        similarity=total/denom if denom else 0.0
        if query.recipe_id==other.recipe_id: similarity=min(1.0, similarity+self.policy.context_bonus/2)
        if query.product_id==other.product_id: similarity=min(1.0, similarity+self.policy.context_bonus/2)
        similarity_conf=conf_num/sum(r.weight for r in domain_results) if domain_results else 0.0
        return SimilarityResult(case_id=case.case_id,fingerprint_id=other.fingerprint_id,similarity=similarity,similarity_confidence=similarity_conf,case_confidence=case.case_confidence,domain_results=tuple(domain_results),shared_context=tuple(shared),important_differences=tuple(differences))

    def search(self, query: EpisodeFingerprint, cases: tuple[HistoricalCase,...], *, top_k:int=5, as_of=None, exclude_episode_id:str|None=None) -> tuple[SimilarityResult,...]:
        eligible=[]
        for case in cases:
            if as_of is not None and case.available_at > as_of: continue
            if exclude_episode_id and case.source_episode_id == exclude_episode_id: continue
            result=self.compare(query,case)
            if result.similarity > 0: eligible.append(result)
        eligible.sort(key=lambda x:(x.similarity*x.similarity_confidence*x.case_confidence,x.similarity),reverse=True)
        return tuple(eligible[:top_k])
