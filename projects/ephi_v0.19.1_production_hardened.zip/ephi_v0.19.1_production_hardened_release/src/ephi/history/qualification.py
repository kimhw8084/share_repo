from __future__ import annotations

import time
from datetime import datetime, timezone, timedelta
from pydantic import BaseModel, ConfigDict, Field

from ephi.domain.history import EpisodeFingerprint,FingerprintComponent,FingerprintDomain,HistoricalCase,HistoricalCaseCuration
from ephi.history.similarity import ExactSimilarityEngine
from ephi.domain.rca import AffectedMaterial,AffectedMembership,ControlPopulation,RouteToken,TemporalPlausibility,InvestigationSeed
from ephi.domain.evidence import Hypothesis
from ephi.rca.commonality import CommonalityEngine
from ephi.rca.service import RCAService


class HistoryRCAQualificationReport(BaseModel):
    model_config=ConfigDict(frozen=True)
    passed: bool
    analogue_case_count:int=Field(ge=0)
    top_analogue:str|None=None
    future_case_excluded:bool
    analogue_search_seconds:float=Field(ge=0)
    analogue_search_cases_per_second:float=Field(ge=0)
    affected_materials:int=Field(ge=0)
    control_materials:int=Field(ge=0)
    route_tokens:int=Field(ge=0)
    commonality_seconds:float=Field(ge=0)
    route_tokens_per_second:float=Field(ge=0)
    suspect_prevalence_difference:float
    routine_prevalence_difference:float
    future_temporal_plausibility:str
    top_rca_candidate:str|None=None
    future_candidate_band:str|None=None


def _fp(fid:str,behavior:tuple[float,...],measurement:tuple[float,...]=(0.2,0.1),op:str='MET',asset:str='A', *, at:datetime)->EpisodeFingerprint:
    return EpisodeFingerprint(fingerprint_id=fid,episode_id='E:'+fid,asset_id=asset,equipment_family='METRO',operation=op,recipe_id='R1',product_id='P1',technology='T1',created_at=at,components=(FingerprintComponent(domain=FingerprintDomain.BEHAVIOR,values=behavior,confidence=.95),FingerprintComponent(domain=FingerprintDomain.MEASUREMENT_SYSTEM,values=measurement,confidence=.9)))


def run_history_rca_qualification(*, case_count:int=2000, affected_count:int=100)->HistoryRCAQualificationReport:
    t=datetime(2026,1,10,tzinfo=timezone.utc)
    query=_fp('Q',(3.0,1.0),(2.5,1.5),at=t)
    cases=[]
    correct_index=max(1,min(case_count-1,case_count//3))
    for i in range(case_count):
        if i==correct_index:
            f=_fp('CORRECT',(3.02,1.01),(2.48,1.52),asset='H',at=t); cur=HistoricalCaseCuration.ROOT_CAUSE_CONFIRMED; rc='CALIBRATION'; conf=.95
        else:
            f=_fp(f'F{i}',(0.2+(i%11)*.1,2.5 if i%7==0 else .1),(0.1+(i%5)*.2,.05),asset=f'H{i%17}',at=t); cur=HistoricalCaseCuration.ENGINEER_REVIEWED; rc='OTHER'; conf=.65
        cases.append(HistoricalCase(case_id=f'C{i}',asset_id=f.asset_id,equipment_family='METRO',opened_at=t-timedelta(days=100-i%50),available_at=t-timedelta(days=1),fingerprint=f,curation=cur,root_cause_category=rc,root_cause_confidence=conf))
    future=HistoricalCase(case_id='FUTURE',asset_id='Z',equipment_family='METRO',opened_at=t,available_at=t+timedelta(days=2),fingerprint=query.model_copy(update={'fingerprint_id':'FUT','episode_id':'EFUT'}),curation=HistoricalCaseCuration.ROOT_CAUSE_CONFIRMED,root_cause_category='FUTURE_INFO',root_cause_confidence=1)
    start=time.perf_counter(); matches=ExactSimilarityEngine().search(query,tuple(cases)+(future,),as_of=t,top_k=10); sim_s=time.perf_counter()-start

    affected=tuple(AffectedMaterial(material_id=f'A{i}',membership=AffectedMembership.DEFINITE,severity_weight=1+i/max(1,affected_count*2),outcome_time=t) for i in range(affected_count))
    controls=(ControlPopulation(control_set_id='STRICT',material_ids=tuple(f'C{i}' for i in range(affected_count)),policy='route-matched',confidence=.95),ControlPopulation(control_set_id='BROAD',material_ids=tuple(f'D{i}' for i in range(affected_count)),policy='broad',confidence=.8))
    tokens=[]
    for i in range(affected_count):
        tokens += [RouteToken(material_id=f'A{i}',sequence=1,operation='ROUTE',asset_id='ROUTINE',event_time=t-timedelta(hours=4)),RouteToken(material_id=f'C{i}',sequence=1,operation='ROUTE',asset_id='ROUTINE',event_time=t-timedelta(hours=4)),RouteToken(material_id=f'D{i}',sequence=1,operation='ROUTE',asset_id='ROUTINE',event_time=t-timedelta(hours=4))]
        if i<int(.9*affected_count): tokens.append(RouteToken(material_id=f'A{i}',sequence=2,operation='ETCH',asset_id='SUSPECT',recipe_id='RX',event_time=t-timedelta(hours=2),health_episode_id='EP-S',health_strength=1.4))
        if i<int(.08*affected_count): tokens.append(RouteToken(material_id=f'C{i}',sequence=2,operation='ETCH',asset_id='SUSPECT',recipe_id='RX',event_time=t-timedelta(hours=2)))
        if i<int(.12*affected_count): tokens.append(RouteToken(material_id=f'D{i}',sequence=2,operation='ETCH',asset_id='SUSPECT',recipe_id='RX',event_time=t-timedelta(hours=2)))
        if i<int(.95*affected_count): tokens.append(RouteToken(material_id=f'A{i}',sequence=3,operation='POST',asset_id='FUTURE_FACTOR',event_time=t+timedelta(hours=2)))
    start=time.perf_counter(); common=CommonalityEngine().rank(affected,controls,tuple(tokens),max_sequence_lookback=5,top_k=30); common_s=time.perf_counter()-start
    seed=InvestigationSeed(seed_id='S',episode_id='E',asset_id='TARGET',context={},onset_low=t-timedelta(hours=3),onset_best=t-timedelta(hours=2),onset_high=t,affected_material_ids=tuple(x.material_id for x in affected),control_set_ids=tuple(x.control_set_id for x in controls),leading_hypotheses=(Hypothesis.LOCAL_ASSET_DEGRADATION,),top_historical_case_ids=tuple(x.case_id for x in matches[:5]))
    candidates=RCAService().candidates(seed,common,historical_factor_support={'ASSET:FUTURE_FACTOR':1.0},top_k=10)
    by={x.factor:x for x in common}
    expected_top=f'C{correct_index}'
    passed=bool(matches and matches[0].case_id==expected_top and all(x.case_id!='FUTURE' for x in matches) and candidates and candidates[0].factor in {'HEALTH_EPISODE:EP-S','ASSET:SUSPECT','ASSET_RECIPE:SUSPECT|RX'} and abs(by['ASSET:ROUTINE'].prevalence_difference)<1e-12 and by['ASSET:FUTURE_FACTOR'].temporal_plausibility is TemporalPlausibility.CONTRADICTS)
    return HistoryRCAQualificationReport(passed=passed,analogue_case_count=len(cases)+1,top_analogue=matches[0].case_id if matches else None,future_case_excluded=all(x.case_id!='FUTURE' for x in matches),analogue_search_seconds=sim_s,analogue_search_cases_per_second=case_count/sim_s if sim_s else 0,affected_materials=len(affected),control_materials=sum(len(x.material_ids) for x in controls),route_tokens=len(tokens),commonality_seconds=common_s,route_tokens_per_second=len(tokens)/common_s if common_s else 0,suspect_prevalence_difference=by['ASSET:SUSPECT'].prevalence_difference,routine_prevalence_difference=by['ASSET:ROUTINE'].prevalence_difference,future_temporal_plausibility=by['ASSET:FUTURE_FACTOR'].temporal_plausibility.value,top_rca_candidate=candidates[0].factor if candidates else None,future_candidate_band=next(x.confidence_band.value for x in candidates if x.factor=='ASSET:FUTURE_FACTOR'))
