from __future__ import annotations

from datetime import datetime, timezone

from ephi.domain.episode import HealthEpisode
from ephi.domain.evidence import EvidenceChannel, Hypothesis
from ephi.domain.health import HealthAssessment
from ephi.domain.history import EpisodeFingerprint, FingerprintComponent, FingerprintDomain
from ephi.domain.quality import QualityAssociationEvidence


class FingerprintBuilder:
    """Build a compact, explainable episode fingerprint from already-authoritative outputs."""

    version = "fingerprint-v1"

    @staticmethod
    def _channel_strength(assessment: HealthAssessment, channel: EvidenceChannel) -> float:
        return max((x.strength * x.confidence for x in assessment.evidence if x.channel is channel), default=0.0)

    def build(
        self,
        episode: HealthEpisode,
        assessment: HealthAssessment,
        *,
        equipment_family: str,
        quality: tuple[QualityAssociationEvidence, ...] = (),
        maintenance_age: float | None = None,
        spatial_signature: tuple[float, ...] = (),
        route_signature: tuple[float, ...] = (),
        created_at: datetime | None = None,
    ) -> EpisodeFingerprint:
        duration_h = max(0.0, (episode.last_updated_at - episode.opened_at).total_seconds() / 3600.0)
        quality_strength = max((q.association_confidence for q in quality), default=0.0)
        quality_effect = max((abs(q.adjusted_effect or 0.0) for q in quality), default=0.0)
        components = [
            FingerprintComponent(
                domain=FingerprintDomain.BEHAVIOR,
                labels=("novelty", "severity", "self", "peer", "fleet"),
                values=(
                    assessment.behavioral_novelty,
                    float(assessment.severity),
                    self._channel_strength(assessment, EvidenceChannel.SELF_HEALTH),
                    self._channel_strength(assessment, EvidenceChannel.PEER_RELATIVE_HEALTH),
                    self._channel_strength(assessment, EvidenceChannel.FLEET_COMMON_MODE),
                ),
                confidence=assessment.confidence,
            ),
            FingerprintComponent(
                domain=FingerprintDomain.TEMPORAL,
                labels=("duration_h", "peak_novelty", "recovering"),
                values=(duration_h, episode.peak_behavioral_novelty, 1.0 if episode.state.value == "RECOVERING" else 0.0),
                confidence=assessment.confidence,
            ),
            FingerprintComponent(
                domain=FingerprintDomain.MEASUREMENT_SYSTEM,
                labels=("measurement", "cross_tool", "repeatability", "spatial", "production"),
                values=(
                    self._channel_strength(assessment, EvidenceChannel.MEASUREMENT_SYSTEM_HEALTH),
                    self._channel_strength(assessment, EvidenceChannel.CROSS_TOOL_MATCHING),
                    self._channel_strength(assessment, EvidenceChannel.REPEATABILITY),
                    self._channel_strength(assessment, EvidenceChannel.SPATIAL_STABILITY),
                    self._channel_strength(assessment, EvidenceChannel.PRODUCTION_METROLOGY),
                ),
                confidence=assessment.confidence,
            ),
            FingerprintComponent(
                domain=FingerprintDomain.QUALITY,
                labels=("association_confidence", "max_effect"),
                values=(quality_strength, quality_effect),
                confidence=quality_strength if quality else 0.0,
            ),
        ]
        if maintenance_age is not None:
            components.append(FingerprintComponent(domain=FingerprintDomain.MAINTENANCE, labels=("age",), values=(maintenance_age,), confidence=1.0))
        if spatial_signature:
            components.append(FingerprintComponent(domain=FingerprintDomain.SPATIAL, values=spatial_signature, confidence=assessment.confidence))
        if route_signature:
            components.append(FingerprintComponent(domain=FingerprintDomain.ROUTE, values=route_signature, confidence=1.0))
        return EpisodeFingerprint(
            fingerprint_id=f"FP:{episode.episode_id}:{self.version}",
            episode_id=episode.episode_id,
            asset_id=episode.asset_id,
            equipment_family=equipment_family,
            operation=episode.context.operation,
            recipe_id=episode.context.recipe_id,
            product_id=episode.context.product_id,
            technology=episode.context.technology,
            created_at=created_at or datetime.now(timezone.utc),
            version=self.version,
            components=tuple(components),
        )
