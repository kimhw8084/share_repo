from __future__ import annotations

from datetime import datetime
from ephi.domain.episode import HealthEpisode
from ephi.domain.health import HealthAssessment
from ephi.domain.history import EpisodeFingerprint, HistoricalCase, SimilarityResult, HistoricalAnalogue
from ephi.domain.quality import QualityAssociationEvidence
from .cases import HistoricalCaseRepository, InMemoryHistoricalCaseRepository
from .fingerprints import FingerprintBuilder
from .similarity import ExactSimilarityEngine
from .recurrence import RecurrenceSummary, summarize_recurrence

class HistoricalIntelligenceService:
    def __init__(self, repository:HistoricalCaseRepository|None=None, *, similarity:ExactSimilarityEngine|None=None, fingerprints:FingerprintBuilder|None=None):
        self.repository=repository or InMemoryHistoricalCaseRepository(); self.similarity=similarity or ExactSimilarityEngine(); self.fingerprints=fingerprints or FingerprintBuilder()

    def add_case(self, case:HistoricalCase)->None: self.repository.upsert(case)

    def fingerprint(self, episode:HealthEpisode, assessment:HealthAssessment, *, equipment_family:str, quality:tuple[QualityAssociationEvidence,...]=())->EpisodeFingerprint:
        return self.fingerprints.build(episode,assessment,equipment_family=equipment_family,quality=quality)

    def analogues(self, fingerprint:EpisodeFingerprint, *, as_of:datetime, top_k:int=5)->tuple[SimilarityResult,...]:
        return self.similarity.search(fingerprint,self.repository.list_cases(),top_k=top_k,as_of=as_of,exclude_episode_id=fingerprint.episode_id)


    def analogue_views(self, fingerprint:EpisodeFingerprint, *, as_of:datetime, top_k:int=5)->tuple[HistoricalAnalogue,...]:
        matches=self.analogues(fingerprint,as_of=as_of,top_k=top_k)
        by_id={c.case_id:c for c in self.repository.list_cases()}
        out=[]
        for m in matches:
            case=by_id[m.case_id]
            out.append(HistoricalAnalogue(case_id=case.case_id,similarity=m.similarity,similarity_confidence=m.similarity_confidence,case_confidence=m.case_confidence,domain_results=m.domain_results,shared_context=m.shared_context,important_differences=m.important_differences,curation=case.curation,root_cause_category=case.root_cause_category,root_cause_confidence=case.root_cause_confidence,resolution_summary=case.resolution_summary,actions=case.actions,benign=case.benign))
        return tuple(out)

    def recurrence(self, matches:tuple[SimilarityResult,...], *, min_similarity:float=0.65)->RecurrenceSummary:
        return summarize_recurrence(matches,self.repository.list_cases(),min_similarity=min_similarity)
