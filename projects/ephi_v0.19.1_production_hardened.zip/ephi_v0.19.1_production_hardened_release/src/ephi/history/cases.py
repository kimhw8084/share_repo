from __future__ import annotations
from dataclasses import dataclass, field
from typing import Protocol
from ephi.domain.history import HistoricalCase

class HistoricalCaseRepository(Protocol):
    def get(self, case_id: str) -> HistoricalCase | None: ...
    def list_cases(self) -> tuple[HistoricalCase, ...]: ...
    def upsert(self, case: HistoricalCase) -> None: ...

@dataclass(slots=True)
class InMemoryHistoricalCaseRepository:
    _items: dict[str, HistoricalCase] = field(default_factory=dict)
    def get(self, case_id: str) -> HistoricalCase | None: return self._items.get(case_id)
    def list_cases(self) -> tuple[HistoricalCase, ...]: return tuple(self._items.values())
    def upsert(self, case: HistoricalCase) -> None: self._items[case.case_id] = case
