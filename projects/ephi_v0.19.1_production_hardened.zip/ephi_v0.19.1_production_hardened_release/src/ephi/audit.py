from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Mapping, Protocol

from ephi.domain.capabilities import Capability
from ephi.domain.data_reality import (
    CapabilityAssessment,
    DataRealityReport,
    DatasetAudit,
    DatasetContract,
    DatasetProfile,
    JoinAudit,
    JoinContract,
    JoinProfile,
    QualificationState,
)
from ephi.errors import MissingOptionalDependencyError


class DataRealityBackend(Protocol):
    def profile_dataset(self, contract: DatasetContract) -> DatasetProfile | None:
        ...

    def profile_join(self, contract: JoinContract) -> JoinProfile | None:
        ...


@dataclass(frozen=True, slots=True)
class CapabilityRule:
    capability: Capability
    required_datasets: tuple[str, ...]
    optional_datasets: tuple[str, ...] = ()
    required_joins: tuple[str, ...] = ()


DEFAULT_CAPABILITY_RULES: tuple[CapabilityRule, ...] = (
    CapabilityRule(Capability.PROCESS_HISTORY, ("executions",)),
    CapabilityRule(Capability.FDC_SCALAR, ("executions", "signals"), required_joins=("execution_signal",)),
    CapabilityRule(Capability.RAW_TRACE, ("executions", "traces"), required_joins=("execution_trace",)),
    CapabilityRule(Capability.METROLOGY, ("metrology",)),
    CapabilityRule(Capability.SPATIAL_METROLOGY, ("metrology",), optional_datasets=("metrology_sites",)),
    CapabilityRule(Capability.REFERENCE_WAFER, ("metrology",)),
    CapabilityRule(Capability.MAINTENANCE, ("maintenance",)),
    CapabilityRule(Capability.COMPONENT_HISTORY, ("maintenance",), optional_datasets=("components",)),
    CapabilityRule(Capability.GENEALOGY, ("genealogy",)),
    CapabilityRule(Capability.QUALITY_OUTCOME, ("quality",)),
    CapabilityRule(Capability.WIP, ("wip",)),
    CapabilityRule(Capability.WIP_ROUTING, ("wip",)),
    CapabilityRule(Capability.ALTERNATIVE_RESOURCE, ("wip", "asset_qualification")),
    CapabilityRule(Capability.HISTORICAL_CASES, ("historical_cases",)),
    CapabilityRule(Capability.RCA_ROUTE_INDEX, ("executions",), optional_datasets=("genealogy",)),
)


class DataRealityAuditor:
    def __init__(
        self,
        backend: DataRealityBackend,
        *,
        capability_rules: tuple[CapabilityRule, ...] = DEFAULT_CAPABILITY_RULES,
    ) -> None:
        self.backend = backend
        self.capability_rules = capability_rules

    @staticmethod
    def _audit_dataset(contract: DatasetContract, profile: DatasetProfile | None) -> DatasetAudit:
        if profile is None:
            return DatasetAudit(
                contract=contract,
                profile=None,
                state=QualificationState.UNAVAILABLE,
                missing_required_columns=contract.required_columns,
                missing_optional_columns=contract.optional_columns,
                reasons=("dataset unavailable",),
            )

        columns = set(profile.columns)
        missing_required = tuple(column for column in contract.required_columns if column not in columns)
        missing_optional = tuple(column for column in contract.optional_columns if column not in columns)
        reasons: list[str] = []
        if missing_required:
            reasons.append(f"missing required columns: {', '.join(missing_required)}")
            state = QualificationState.FAILED
        elif profile.row_count <= 0:
            reasons.append("dataset contains no rows")
            state = QualificationState.UNAVAILABLE
        elif missing_optional:
            reasons.append(f"optional columns unavailable: {', '.join(missing_optional)}")
            state = QualificationState.PARTIAL
        else:
            state = QualificationState.QUALIFIED

        if contract.available_at_column and contract.available_at_column in columns:
            if profile.available_at_min is None or profile.available_at_max is None:
                state = QualificationState.PARTIAL if state == QualificationState.QUALIFIED else state
                reasons.append("available_at exists but temporal coverage could not be profiled")
        elif contract.available_at_column:
            # Already covered as a missing required column if required. If declared optional,
            # keep the temporal limitation explicit.
            reasons.append("knowledge-availability replay semantics unavailable")
            if state == QualificationState.QUALIFIED:
                state = QualificationState.PROVISIONAL

        return DatasetAudit(
            contract=contract,
            profile=profile,
            state=state,
            missing_required_columns=missing_required,
            missing_optional_columns=missing_optional,
            reasons=tuple(dict.fromkeys(reasons)),
        )

    @staticmethod
    def _audit_join(contract: JoinContract, profile: JoinProfile | None) -> JoinAudit:
        if profile is None:
            return JoinAudit(
                contract=contract,
                profile=None,
                state=QualificationState.UNAVAILABLE,
                reasons=("join not profiled",),
            )
        # Thresholds are intentionally not universal. The audit reports the measured
        # coverage; family certification decides acceptable values. Only impossible or
        # ambiguous-by-construction joins fail automatically.
        reasons: list[str] = []
        if profile.left_rows <= 0:
            state = QualificationState.UNAVAILABLE
            reasons.append("left population is empty")
        elif profile.ambiguous_left_rows > 0:
            state = QualificationState.PROVISIONAL
            reasons.append("ambiguous left-side matches exist; certification threshold required")
        elif profile.matched_left_rows == 0:
            state = QualificationState.FAILED
            reasons.append("zero matched left rows")
        elif profile.matched_left_rows < profile.left_rows:
            state = QualificationState.PROVISIONAL
            reasons.append("join coverage is incomplete; family-specific acceptance threshold required")
        else:
            state = QualificationState.QUALIFIED
        return JoinAudit(contract=contract, profile=profile, state=state, reasons=tuple(reasons))

    @staticmethod
    def _capability_assessment(
        rule: CapabilityRule,
        datasets: Mapping[str, DatasetAudit],
        joins: Mapping[str, JoinAudit],
    ) -> CapabilityAssessment:
        required_dataset_audits = [datasets.get(name) for name in rule.required_datasets]
        required_join_audits = [joins.get(name) for name in rule.required_joins]
        reasons: list[str] = []

        if any(item is None or item.state in {QualificationState.UNAVAILABLE, QualificationState.FAILED} for item in required_dataset_audits):
            missing = [
                name
                for name, item in zip(rule.required_datasets, required_dataset_audits)
                if item is None or item.state in {QualificationState.UNAVAILABLE, QualificationState.FAILED}
            ]
            return CapabilityAssessment(
                capability=rule.capability,
                state=QualificationState.UNAVAILABLE,
                supporting_datasets=rule.required_datasets,
                supporting_joins=rule.required_joins,
                reasons=(f"required dataset(s) unavailable or failed: {', '.join(missing)}",),
            )

        if any(item is None or item.state in {QualificationState.UNAVAILABLE, QualificationState.FAILED} for item in required_join_audits):
            missing = [
                name
                for name, item in zip(rule.required_joins, required_join_audits)
                if item is None or item.state in {QualificationState.UNAVAILABLE, QualificationState.FAILED}
            ]
            return CapabilityAssessment(
                capability=rule.capability,
                state=QualificationState.UNAVAILABLE,
                supporting_datasets=rule.required_datasets,
                supporting_joins=rule.required_joins,
                reasons=(f"required join(s) unavailable or failed: {', '.join(missing)}",),
            )

        states = [item.state for item in required_dataset_audits if item is not None] + [
            item.state for item in required_join_audits if item is not None
        ]
        if any(state == QualificationState.PROVISIONAL for state in states):
            state = QualificationState.PROVISIONAL
            reasons.append("one or more required inputs remain provisional")
        elif any(state == QualificationState.PARTIAL for state in states):
            state = QualificationState.PARTIAL
            reasons.append("one or more required inputs have partial optional coverage")
        else:
            state = QualificationState.QUALIFIED

        optional_missing = [
            name
            for name in rule.optional_datasets
            if name not in datasets or not datasets[name].usable
        ]
        if optional_missing:
            reasons.append(f"optional enrichment unavailable: {', '.join(optional_missing)}")
            if state == QualificationState.QUALIFIED:
                state = QualificationState.PARTIAL

        return CapabilityAssessment(
            capability=rule.capability,
            state=state,
            supporting_datasets=rule.required_datasets + rule.optional_datasets,
            supporting_joins=rule.required_joins,
            reasons=tuple(reasons),
        )

    def run(
        self,
        dataset_contracts: tuple[DatasetContract, ...],
        join_contracts: tuple[JoinContract, ...] = (),
        *,
        config_hash: str | None = None,
    ) -> DataRealityReport:
        dataset_audits = tuple(
            self._audit_dataset(contract, self.backend.profile_dataset(contract))
            for contract in dataset_contracts
        )
        join_audits = tuple(
            self._audit_join(contract, self.backend.profile_join(contract))
            for contract in join_contracts
        )
        datasets = {audit.contract.logical_name: audit for audit in dataset_audits}
        joins = {audit.contract.join_id: audit for audit in join_audits}
        capabilities = tuple(
            self._capability_assessment(rule, datasets, joins)
            for rule in self.capability_rules
        )
        return DataRealityReport(
            datasets=dataset_audits,
            joins=join_audits,
            capabilities=capabilities,
            generated_at=datetime.now(timezone.utc).isoformat(),
            config_hash=config_hash,
        )


class StaticAuditBackend:
    """Deterministic backend for qualification tests and adapter bring-up."""

    def __init__(
        self,
        datasets: Mapping[str, DatasetProfile],
        joins: Mapping[str, JoinProfile] | None = None,
    ) -> None:
        self.datasets = dict(datasets)
        self.joins = dict(joins or {})

    def profile_dataset(self, contract: DatasetContract) -> DatasetProfile | None:
        return self.datasets.get(contract.logical_name)

    def profile_join(self, contract: JoinContract) -> JoinProfile | None:
        return self.joins.get(contract.join_id)


def audit_parquet_root(root: str | Path) -> dict[str, object]:
    """Legacy/local Parquet audit retained for developer convenience.

    Production qualification should use DataRealityAuditor with semantic contracts.
    """
    try:
        import duckdb  # type: ignore
        import pyarrow.parquet as pq  # type: ignore
    except ImportError as exc:
        raise MissingOptionalDependencyError(
            "Data audit requires `pip install -e '.[local]'`"
        ) from exc

    root = Path(root)
    result: dict[str, object] = {"root": str(root), "datasets": {}}
    datasets: dict[str, object] = result["datasets"]  # type: ignore[assignment]
    for path in sorted(root.glob("*.parquet")):
        metadata = pq.read_metadata(path)
        entry: dict[str, object] = {
            "rows": metadata.num_rows,
            "row_groups": metadata.num_row_groups,
            "columns": metadata.schema.names,
            "bytes": path.stat().st_size,
        }
        columns = set(metadata.schema.names)
        if "available_at" in columns:
            con = duckdb.connect()
            try:
                row = con.execute(
                    "SELECT min(available_at), max(available_at) FROM read_parquet(?)", [str(path)]
                ).fetchone()
            finally:
                con.close()
            entry["available_at_min"] = str(row[0]) if row and row[0] is not None else None
            entry["available_at_max"] = str(row[1]) if row and row[1] is not None else None
        datasets[path.stem] = entry
    return result
