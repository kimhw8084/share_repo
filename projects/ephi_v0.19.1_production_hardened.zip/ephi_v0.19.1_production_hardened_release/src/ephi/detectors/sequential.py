from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class SequentialState:
    ewma_fast: float = 0.0
    ewma_slow: float = 0.0
    cusum_pos: float = 0.0
    cusum_neg: float = 0.0
    persistence_count: int = 0


@dataclass(frozen=True, slots=True)
class SequentialConfig:
    lambda_fast: float = 0.30
    lambda_slow: float = 0.08
    cusum_k: float = 0.50
    persistence_z: float = 2.5


def update_sequential(state: SequentialState, z: float, config: SequentialConfig) -> SequentialState:
    state.ewma_fast = config.lambda_fast * z + (1.0 - config.lambda_fast) * state.ewma_fast
    state.ewma_slow = config.lambda_slow * z + (1.0 - config.lambda_slow) * state.ewma_slow
    state.cusum_pos = max(0.0, state.cusum_pos + z - config.cusum_k)
    state.cusum_neg = min(0.0, state.cusum_neg + z + config.cusum_k)
    if abs(z) >= config.persistence_z:
        state.persistence_count += 1
    else:
        state.persistence_count = 0
    return state
