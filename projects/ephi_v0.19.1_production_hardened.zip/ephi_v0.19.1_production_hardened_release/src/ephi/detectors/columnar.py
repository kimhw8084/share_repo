from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from ephi.populations.materialized import ReferenceStateBatch

_EPS = 1e-9


@dataclass(frozen=True, slots=True)
class ScalarColumnarScores:
    self_z: np.ndarray
    anchor_z: np.ndarray
    physical_change: np.ndarray
    data_pipeline_suspect: np.ndarray
    valid_reference: np.ndarray


@dataclass(frozen=True, slots=True)
class PeerColumnarScores:
    peer_center_change: np.ndarray
    peer_change_mad: np.ndarray
    peer_change_z: np.ndarray
    fleet_shift_z: np.ndarray
    peer_count: np.ndarray
    peer_confidence: np.ndarray
    adequate: np.ndarray


def score_scalar_arrays(
    values: np.ndarray,
    reference: "ReferenceStateBatch",
    *,
    unit_jump_ratio: float = 100.0,
) -> ScalarColumnarScores:
    """Vectorized stateless scalar scoring against already materialized references."""

    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 1:
        raise ValueError("values must be one-dimensional")
    if reference.size != values.shape[0]:
        raise ValueError("reference batch size must match values")

    valid = (
        reference.adequate
        & np.isfinite(values)
        & np.isfinite(reference.median)
        & np.isfinite(reference.mad)
        & np.isfinite(reference.anchor_median)
        & np.isfinite(reference.anchor_mad)
    )
    mad = np.maximum(reference.mad, _EPS)
    anchor_mad = np.maximum(reference.anchor_mad, _EPS)
    self_z = np.full(values.shape, np.nan, dtype=np.float64)
    anchor_z = np.full(values.shape, np.nan, dtype=np.float64)
    physical_change = np.full(values.shape, np.nan, dtype=np.float64)
    self_z[valid] = (values[valid] - reference.median[valid]) / mad[valid]
    anchor_z[valid] = (values[valid] - reference.anchor_median[valid]) / anchor_mad[valid]
    physical_change[valid] = values[valid] - reference.anchor_median[valid]

    denominator = np.maximum(
        np.maximum(np.abs(reference.anchor_median), anchor_mad),
        _EPS,
    )
    relative_jump = np.zeros(values.shape, dtype=np.float64)
    relative_jump[valid] = np.abs(values[valid] - reference.anchor_median[valid]) / denominator[valid]
    pipeline = valid & (relative_jump >= (unit_jump_ratio - 1.0))
    return ScalarColumnarScores(
        self_z=self_z,
        anchor_z=anchor_z,
        physical_change=physical_change,
        data_pipeline_suspect=pipeline,
        valid_reference=valid,
    )


def peer_decompose_arrays(
    physical_changes: np.ndarray,
    reference_scales: np.ndarray,
    *,
    min_peer_count: int = 2,
    confidence_full_count: int = 4,
) -> PeerColumnarScores:
    """Bounded peer/fleet decomposition for one concurrent compatible cohort.

    The source-scale dimension is executions; peer cohort size is intentionally
    bounded by manufacturing eligibility. A small per-peer loop avoids an O(n^2)
    temporary matrix while all arithmetic inside each cohort remains NumPy-native.
    """

    changes = np.asarray(physical_changes, dtype=np.float64)
    scales = np.asarray(reference_scales, dtype=np.float64)
    if changes.ndim != 1 or scales.ndim != 1 or changes.shape != scales.shape:
        raise ValueError("physical_changes and reference_scales must be equal 1-D arrays")
    n = changes.size
    center = np.full(n, np.nan, dtype=np.float64)
    spread = np.full(n, np.nan, dtype=np.float64)
    residual = np.full(n, np.nan, dtype=np.float64)
    fleet = np.full(n, np.nan, dtype=np.float64)
    count = np.zeros(n, dtype=np.int32)
    confidence = np.zeros(n, dtype=np.float64)
    adequate = np.zeros(n, dtype=bool)

    finite = np.isfinite(changes) & np.isfinite(scales) & (scales > 0)
    indices = np.flatnonzero(finite)
    small_cohort = indices.size <= 3
    for idx in indices:
        peer_idx = indices[indices != idx]
        peer_count = int(peer_idx.size)
        count[idx] = peer_count
        if peer_count == 0:
            continue
        consensus_idx = indices if small_cohort else peer_idx
        peer_changes = changes[consensus_idx]
        peer_scales = np.maximum(scales[consensus_idx], _EPS)
        peer_center = float(np.median(peer_changes))
        typical_scale = float(np.median(peer_scales))
        raw_mad = 1.4826 * float(np.median(np.abs(peer_changes - peer_center)))
        peer_spread = max(raw_mad, typical_scale, _EPS)
        center[idx] = peer_center
        spread[idx] = peer_spread
        residual[idx] = (changes[idx] - peer_center) / peer_spread
        fleet[idx] = peer_center / max(typical_scale, _EPS)
        confidence[idx] = min(1.0, peer_count / max(confidence_full_count, 1))
        adequate[idx] = peer_count >= min_peer_count

    return PeerColumnarScores(
        peer_center_change=center,
        peer_change_mad=spread,
        peer_change_z=residual,
        fleet_shift_z=fleet,
        peer_count=count,
        peer_confidence=confidence,
        adequate=adequate,
    )


def score_arrow_table(table, *, unit_jump_ratio: float = 100.0):
    """Optional Arrow bridge; imported lazily so the core package stays portable."""

    try:
        import pyarrow as pa
    except ImportError as exc:  # pragma: no cover - optional environment
        raise RuntimeError("pyarrow is required for score_arrow_table") from exc

    required = {
        "value",
        "median",
        "mad",
        "anchor_median",
        "anchor_mad",
        "reference_confidence",
        "reference_adequate",
    }
    missing = required - set(table.column_names)
    if missing:
        raise ValueError(f"Arrow scoring input missing columns: {sorted(missing)}")

    from ephi.populations.materialized import ReferenceStateBatch

    values = table["value"].to_numpy(zero_copy_only=False)
    reference = ReferenceStateBatch(
        median=table["median"].to_numpy(zero_copy_only=False),
        mad=table["mad"].to_numpy(zero_copy_only=False),
        anchor_median=table["anchor_median"].to_numpy(zero_copy_only=False),
        anchor_mad=table["anchor_mad"].to_numpy(zero_copy_only=False),
        confidence=table["reference_confidence"].to_numpy(zero_copy_only=False),
        adequate=table["reference_adequate"].to_numpy(zero_copy_only=False),
    )
    scores = score_scalar_arrays(values, reference, unit_jump_ratio=unit_jump_ratio)
    return table.append_column("self_z", pa.array(scores.self_z)).append_column(
        "anchor_z", pa.array(scores.anchor_z)
    ).append_column(
        "physical_change", pa.array(scores.physical_change)
    ).append_column(
        "data_pipeline_suspect", pa.array(scores.data_pipeline_suspect)
    )




def _leave_one_out_median(matrix: np.ndarray) -> np.ndarray:
    """Exact leave-one-out median for each cell of a dense group matrix."""
    values = np.asarray(matrix, dtype=np.float64)
    if values.ndim != 2 or values.shape[1] <= 1:
        raise ValueError("leave-one-out median requires a 2-D matrix with width > 1")
    groups, width = values.shape
    order = np.argsort(values, axis=1, kind="stable")
    sorted_values = np.take_along_axis(values, order, axis=1)
    ranks = np.argsort(order, axis=1, kind="stable")

    if width % 2 == 0:
        # Removing one element leaves an odd peer count.
        lower = width // 2 - 1
        upper = width // 2
        lower_values = sorted_values[:, lower][:, None]
        upper_values = sorted_values[:, upper][:, None]
        return np.where(ranks <= lower, upper_values, lower_values)

    # Removing one element leaves an even peer count.
    mid = width // 2
    below = 0.5 * (sorted_values[:, mid] + sorted_values[:, mid + 1])
    equal = 0.5 * (sorted_values[:, mid - 1] + sorted_values[:, mid + 1])
    above = 0.5 * (sorted_values[:, mid - 1] + sorted_values[:, mid])
    return np.where(
        ranks < mid,
        below[:, None],
        np.where(ranks == mid, equal[:, None], above[:, None]),
    )


def peer_decompose_grouped_arrays(
    physical_changes: np.ndarray,
    reference_scales: np.ndarray,
    peer_group_ids: np.ndarray,
    *,
    min_peer_count: int = 2,
    confidence_full_count: int = 4,
) -> PeerColumnarScores:
    """Vectorized exact peer decomposition across bounded compatible cohorts.

    Rows are sorted once by ``peer_group_id``. Cohorts with equal finite size are
    processed as dense NumPy matrices. For cohorts larger than three, the target is
    exactly excluded from peer median/scale/MAD. Three-member cohorts preserve the
    qualified all-member robust-consensus rule that resists a single poisoned head.

    Complexity is O(rows * bounded_peer_count), never O(history).
    """

    changes = np.asarray(physical_changes, dtype=np.float64)
    scales = np.asarray(reference_scales, dtype=np.float64)
    groups = np.asarray(peer_group_ids)
    if changes.ndim != 1 or scales.ndim != 1 or groups.ndim != 1:
        raise ValueError("physical_changes, reference_scales and peer_group_ids must be 1-D")
    if not (changes.shape == scales.shape == groups.shape):
        raise ValueError("grouped peer arrays must have equal length")

    n_rows = changes.size
    center = np.full(n_rows, np.nan, dtype=np.float64)
    spread = np.full(n_rows, np.nan, dtype=np.float64)
    residual = np.full(n_rows, np.nan, dtype=np.float64)
    fleet = np.full(n_rows, np.nan, dtype=np.float64)
    count = np.zeros(n_rows, dtype=np.int32)
    confidence = np.zeros(n_rows, dtype=np.float64)
    adequate = np.zeros(n_rows, dtype=bool)
    if n_rows == 0:
        return PeerColumnarScores(center, spread, residual, fleet, count, confidence, adequate)

    finite = np.isfinite(changes) & np.isfinite(scales) & (scales > 0)
    valid_idx = np.flatnonzero(finite)
    if valid_idx.size == 0:
        return PeerColumnarScores(center, spread, residual, fleet, count, confidence, adequate)

    valid_groups = groups[valid_idx]
    if valid_groups.size <= 1 or np.all(valid_groups[1:] >= valid_groups[:-1]):
        sorted_idx = valid_idx
        sorted_groups = valid_groups
    else:
        order = np.argsort(valid_groups, kind="stable")
        sorted_idx = valid_idx[order]
        sorted_groups = valid_groups[order]

    boundaries = np.flatnonzero(
        np.r_[True, sorted_groups[1:] != sorted_groups[:-1], True]
    )
    starts = boundaries[:-1]
    sizes = np.diff(boundaries)

    for width in np.unique(sizes):
        width = int(width)
        selected_starts = starts[sizes == width]
        if width <= 1:
            continue
        positions = selected_starts[:, None] + np.arange(width, dtype=np.int64)[None, :]
        idx = sorted_idx[positions]
        values = changes[idx]
        local_scales = np.maximum(scales[idx], _EPS)
        peer_count = width - 1

        if width <= 3:
            local_center = np.median(values, axis=1)[:, None]
            local_center = np.broadcast_to(local_center, values.shape)
            typical_scale = np.median(local_scales, axis=1)[:, None]
            typical_scale = np.broadcast_to(typical_scale, values.shape)
            raw_mad = 1.4826 * np.median(
                np.abs(values - local_center[:, :1]), axis=1
            )[:, None]
            raw_mad = np.broadcast_to(raw_mad, values.shape)
        else:
            local_center = _leave_one_out_median(values)
            typical_scale = _leave_one_out_median(local_scales)
            distances = np.abs(values[:, None, :] - local_center[:, :, None])
            diagonal = np.arange(width)
            distances[:, diagonal, diagonal] = np.nan
            raw_mad = 1.4826 * np.nanmedian(distances, axis=2)

        local_spread = np.maximum(np.maximum(raw_mad, typical_scale), _EPS)
        local_residual = (values - local_center) / local_spread
        local_fleet = local_center / np.maximum(typical_scale, _EPS)
        local_confidence = min(1.0, peer_count / max(confidence_full_count, 1))

        center[idx] = local_center
        spread[idx] = local_spread
        residual[idx] = local_residual
        fleet[idx] = local_fleet
        count[idx] = peer_count
        confidence[idx] = local_confidence
        adequate[idx] = peer_count >= min_peer_count

    return PeerColumnarScores(
        peer_center_change=center,
        peer_change_mad=spread,
        peer_change_z=residual,
        fleet_shift_z=fleet,
        peer_count=count,
        peer_confidence=confidence,
        adequate=adequate,
    )
