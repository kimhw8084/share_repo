from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from itertools import groupby

from ephi.domain.context import ContextKey
from ephi.domain.detection import DetectorResult
from ephi.domain.features import ScalarFeatureObservation
from ephi.populations.peers import PeerConfig, build_peer_snapshots
from ephi.populations.references import ReferenceConfig, ReferenceManager

from .sequential import SequentialConfig, SequentialState, update_sequential


@dataclass(frozen=True, slots=True)
class BehavioralDetectorConfig:
    reference: ReferenceConfig = ReferenceConfig()
    peers: PeerConfig = PeerConfig()
    sequential: SequentialConfig = SequentialConfig()
    unit_jump_ratio: float = 100.0


@dataclass(slots=True)
class BehavioralDetectorEngine:
    config: BehavioralDetectorConfig = field(default_factory=BehavioralDetectorConfig)
    references: ReferenceManager = field(init=False)
    _sequential: dict[tuple[str, ContextKey, str], SequentialState] = field(default_factory=dict)
    _peer_sequential: dict[tuple[str, ContextKey, str], SequentialState] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.references = ReferenceManager(self.config.reference)

    def _state(self, obs: ScalarFeatureObservation) -> SequentialState:
        key = (obs.asset_id, obs.context, obs.feature_id)
        if key not in self._sequential:
            self._sequential[key] = SequentialState()
        return self._sequential[key]

    def _peer_state(self, obs: ScalarFeatureObservation) -> SequentialState:
        key = (obs.asset_id, obs.context, obs.feature_id)
        if key not in self._peer_sequential:
            self._peer_sequential[key] = SequentialState()
        return self._peer_sequential[key]

    def process_batch(self, observations: list[ScalarFeatureObservation]) -> list[DetectorResult]:
        """Score concurrent observations without allowing current values into references.

        Observations are grouped by event_time + effective context + feature so peer
        comparisons use concurrent, manufacturing-compatible measurements.
        """

        ordered = sorted(
            observations,
            key=lambda o: (o.event_time, o.context, o.feature_id, o.asset_id),
        )
        output: list[DetectorResult] = []
        group_key = lambda o: (o.event_time, o.context, o.feature_id)
        for _, grouped_iter in groupby(ordered, key=group_key):
            group = list(grouped_iter)
            scored: dict[str, tuple[ScalarFeatureObservation, float, float, float, bool, float, float]] = {}

            # Phase A: snapshot + score. No current observation is admitted yet.
            for obs in group:
                snapshot = self.references.snapshot(obs)
                if snapshot is None or not snapshot.adequate:
                    self.references.bootstrap(obs)
                    continue
                self_z, anchor_z = self.references.robust_z(obs, snapshot)
                denominator = max(abs(snapshot.anchor_median), snapshot.anchor_mad, 1e-9)
                data_pipeline_suspect = abs(obs.value - snapshot.anchor_median) / denominator >= (
                    self.config.unit_jump_ratio - 1.0
                )
                scored[obs.asset_id] = (
                    obs,
                    self_z,
                    anchor_z,
                    snapshot.confidence,
                    data_pipeline_suspect,
                    obs.value - snapshot.anchor_median,
                    snapshot.anchor_mad,
                )

            peer_snapshots = build_peer_snapshots(
                {asset_id: (values[5], values[6]) for asset_id, values in scored.items()},
                config=self.config.peers,
            )

            # Phase B: update temporal detector state from the already-scored value.
            for asset_id, (
                obs, self_z, anchor_z, ref_conf, data_pipeline_suspect, physical_change, _reference_mad
            ) in scored.items():
                peer = peer_snapshots.get(asset_id)
                peer_change_z: float | None = None
                peer_ewma: float | None = None
                peer_persistence_count = 0
                fleet_shift_z: float | None = None
                peer_conf = 0.0
                if peer is not None and peer.adequate:
                    peer_change_z = (physical_change - peer.peer_center_change) / peer.peer_change_mad
                    fleet_shift_z = peer.fleet_shift_z
                    peer_conf = peer.confidence
                    peer_state = update_sequential(
                        self._peer_state(obs), peer_change_z, self.config.sequential
                    )
                    peer_ewma = peer_state.ewma_fast
                    peer_persistence_count = peer_state.persistence_count

                state = update_sequential(self._state(obs), self_z, self.config.sequential)
                output.append(
                    DetectorResult(
                        execution_id=obs.execution_id,
                        asset_id=obs.asset_id,
                        context=obs.context,
                        feature_id=obs.feature_id,
                        event_time=obs.event_time,
                        physical_value=obs.value,
                        self_z=self_z,
                        anchor_z=anchor_z,
                        peer_change_z=peer_change_z,
                        peer_ewma=peer_ewma,
                        peer_persistence_count=peer_persistence_count,
                        fleet_shift_z=fleet_shift_z,
                        ewma_fast=state.ewma_fast,
                        ewma_slow=state.ewma_slow,
                        cusum_pos=state.cusum_pos,
                        cusum_neg=state.cusum_neg,
                        persistence_count=state.persistence_count,
                        reference_confidence=ref_conf,
                        peer_confidence=peer_conf,
                        data_pipeline_suspect=data_pipeline_suspect,
                    )
                )

            # Phase C: controlled reference admission only after all current scores exist.
            for obs, self_z, anchor_z, _conf, data_pipeline_suspect, _change, _mad in scored.values():
                self.references.admit_after_score(
                    obs,
                    self_z=self_z,
                    anchor_z=anchor_z,
                    data_pipeline_suspect=data_pipeline_suspect,
                )

        return output
    @staticmethod
    def _export_sequential_map(
        values: dict[tuple[str, ContextKey, str], SequentialState],
    ) -> list[dict[str, object]]:
        return [
            {
                "asset_id": asset_id,
                "context": context.to_dict(),
                "feature_id": feature_id,
                "ewma_fast": state.ewma_fast,
                "ewma_slow": state.ewma_slow,
                "cusum_pos": state.cusum_pos,
                "cusum_neg": state.cusum_neg,
                "persistence_count": state.persistence_count,
            }
            for (asset_id, context, feature_id), state in values.items()
        ]

    @staticmethod
    def _restore_sequential_map(
        records: list[dict[str, object]],
    ) -> dict[tuple[str, ContextKey, str], SequentialState]:
        output: dict[tuple[str, ContextKey, str], SequentialState] = {}
        for record in records:
            context_raw = record["context"]
            if not isinstance(context_raw, dict):
                raise TypeError("detector checkpoint context must be a mapping")
            context = ContextKey.from_dict({str(k): str(v) for k, v in context_raw.items()})
            output[(str(record["asset_id"]), context, str(record["feature_id"]))] = SequentialState(
                ewma_fast=float(record["ewma_fast"]),
                ewma_slow=float(record["ewma_slow"]),
                cusum_pos=float(record["cusum_pos"]),
                cusum_neg=float(record["cusum_neg"]),
                persistence_count=int(record["persistence_count"]),
            )
        return output

    def export_state(self) -> dict[str, object]:
        return {
            "references": self.references.export_state(),
            "sequential": self._export_sequential_map(self._sequential),
            "peer_sequential": self._export_sequential_map(self._peer_sequential),
        }

    def restore_state(self, state: dict[str, object]) -> None:
        refs = state.get("references", [])
        sequential = state.get("sequential", [])
        peer_sequential = state.get("peer_sequential", [])
        if not isinstance(refs, list) or not isinstance(sequential, list) or not isinstance(peer_sequential, list):
            raise TypeError("invalid detector checkpoint payload")
        self.references.restore_state(refs)
        self._sequential = self._restore_sequential_map(sequential)
        self._peer_sequential = self._restore_sequential_map(peer_sequential)

