from __future__ import annotations

from datetime import datetime

from ephi.adapters.base.big_data import BigDataClient, Predicate, PredicateOp, QuerySpec


class ProcessExecutionRepository:
    """Semantic execution repository. Proprietary source names stay in configuration."""

    REQUIRED_COLUMNS = (
        "execution_id",
        "asset_id",
        "event_time",
        "available_at",
        "operation",
        "recipe_id",
        "product_id",
        "technology",
        "material_id",
    )

    def __init__(self, client: BigDataClient, *, dataset: str = "executions") -> None:
        self.client = client
        self.dataset = dataset

    def fetch_incremental(
        self,
        *,
        available_after: datetime,
        available_until: datetime,
    ):
        return self.client.query_arrow(
            QuerySpec(
                dataset=self.dataset,
                columns=self.REQUIRED_COLUMNS,
                predicates=(
                    Predicate("available_at", PredicateOp.GT, available_after),
                    Predicate("available_at", PredicateOp.LTE, available_until),
                ),
                order_by=("available_at", "event_time", "execution_id"),
            )
        )

    def fetch_by_ids(self, execution_ids: list[str], *, as_of: datetime):
        if not execution_ids:
            return self.client.query_arrow(
                QuerySpec(dataset=self.dataset, columns=self.REQUIRED_COLUMNS, limit=0)
            )
        return self.client.query_arrow(
            QuerySpec(
                dataset=self.dataset,
                columns=self.REQUIRED_COLUMNS,
                predicates=(
                    Predicate("execution_id", PredicateOp.IN, tuple(execution_ids)),
                    Predicate("available_at", PredicateOp.LTE, as_of),
                ),
            )
        )
