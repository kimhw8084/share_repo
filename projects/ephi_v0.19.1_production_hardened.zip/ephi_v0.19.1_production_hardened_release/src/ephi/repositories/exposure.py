from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Protocol

from ephi.domain.context import ContextKey
from ephi.domain.exposure import (
    AlternativeAssetCandidate,
    HistoricalExecutionExposure,
    WIPMaterialState,
)


class ExposureSourceRepository(Protocol):
    """Semantic exposure/WIP access boundary.

    Production implementations map these semantics to company Big Data tables. No
    physical dataset/table names belong in the exposure or priority engines.
    """

    def historical_exposures(
        self,
        *,
        asset_id: str,
        operation: str,
        start_time: datetime,
        as_of: datetime,
    ) -> tuple[HistoricalExecutionExposure, ...]:
        ...

    def current_wip(
        self,
        *,
        operation: str,
        as_of: datetime,
    ) -> tuple[WIPMaterialState, ...]:
        ...

    def alternative_assets(
        self,
        *,
        asset_id: str,
        context: ContextKey,
        as_of: datetime,
    ) -> tuple[AlternativeAssetCandidate, ...]:
        ...


@dataclass(slots=True)
class InMemoryExposureSourceRepository:
    history: tuple[HistoricalExecutionExposure, ...] = ()
    wip: tuple[WIPMaterialState, ...] = ()
    alternatives: tuple[AlternativeAssetCandidate, ...] = ()

    def historical_exposures(self, *, asset_id: str, operation: str, start_time: datetime, as_of: datetime) -> tuple[HistoricalExecutionExposure, ...]:
        return tuple(
            item for item in self.history
            if item.asset_id == asset_id and item.operation == operation and start_time <= item.event_time <= as_of
        )

    def current_wip(self, *, operation: str, as_of: datetime) -> tuple[WIPMaterialState, ...]:
        return self.wip

    def alternative_assets(self, *, asset_id: str, context: ContextKey, as_of: datetime) -> tuple[AlternativeAssetCandidate, ...]:
        return self.alternatives
