from __future__ import annotations

from typing import Iterable

from ephi.adapters.base.big_data import BigDataClient, QuerySpec
from ephi.adapters.company.mapping import MappingRegistry, map_query_spec


class MappedBigDataClient:
    """Thin logical-name wrapper around an internal BigDataClient implementation.

    The company port is expected to implement only the physical BigDataClient using
    the approved internal library. This wrapper keeps all EPHI repositories on stable
    logical dataset/column names.
    """

    def __init__(self, physical_client: BigDataClient, mappings: MappingRegistry) -> None:
        self.physical_client = physical_client
        self.mappings = mappings

    @staticmethod
    def _restore_names(table, rename: dict[str, str]):
        # Imported data plane stays Arrow-native; no row materialization.
        names = [rename.get(name, name) for name in table.column_names]
        return table.rename_columns(names)

    def query_arrow(self, query: QuerySpec):
        mapped, rename = map_query_spec(query, self.mappings)
        table = self.physical_client.query_arrow(mapped)
        return self._restore_names(table, rename)

    def stream_arrow(self, query: QuerySpec, *, batch_rows: int = 65_536) -> Iterable:
        mapped, rename = map_query_spec(query, self.mappings)
        for batch in self.physical_client.stream_arrow(mapped, batch_rows=batch_rows):
            names = [rename.get(name, name) for name in batch.schema.names]
            yield batch.rename_columns(names)
