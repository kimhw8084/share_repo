from __future__ import annotations

from ephi.adapters.company.mapping import DatasetMapping, MappingRegistry
from ephi.config import DataConfig


def mapping_registry_from_config(config: DataConfig) -> MappingRegistry:
    return MappingRegistry(
        {
            logical_name: DatasetMapping(
                logical_name=logical_name,
                physical_name=binding.physical_name,
                columns=dict(binding.columns),
            )
            for logical_name, binding in config.datasets.items()
        }
    )
