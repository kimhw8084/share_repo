from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Protocol

from ephi.adapters.base.big_data import Predicate, PredicateOp, QuerySpec
from ephi.audit_contracts import DEFAULT_DATASET_CONTRACTS
from ephi.autopilot.models import SqlBindingManifest, load_sql_binding
from ephi.autopilot.type_firewall import CanonicalTypeFirewall


class SqlArrowExecutor(Protocol):
    """Approved physical SQL execution boundary for AutoPort bindings."""

    def query_sql_arrow(self, sql: str, parameters: Mapping[str, Any]): ...

    def stream_sql_arrow(self, sql: str, parameters: Mapping[str, Any], *, batch_rows: int = 65_536) -> Iterable: ...


@dataclass(frozen=True, slots=True)
class SqlRuntimePolicy:
    max_in_values: int = 10_000
    max_limit: int = 1_000_000
    max_window_days: int = 366
    reject_unbounded_queries: bool = True


@dataclass(frozen=True, slots=True)
class SqlBindingRegistry:
    bindings: Mapping[str, SqlBindingManifest]

    def binding(self, logical_dataset: str) -> SqlBindingManifest:
        try:
            return self.bindings[logical_dataset]
        except KeyError as exc:
            raise KeyError(f"No AutoPort SQL binding for {logical_dataset}") from exc

    @classmethod
    def from_directory(cls, path: str | Path) -> "SqlBindingRegistry":
        root = Path(path)
        bindings: dict[str, SqlBindingManifest] = {}
        if not root.exists():
            return cls({})
        for item in sorted((*root.glob("*.yaml"), *root.glob("*.yml"))):
            binding = load_sql_binding(item)
            if binding.logical_dataset in bindings:
                raise ValueError(f"duplicate AutoPort SQL binding: {binding.logical_dataset}")
            bindings[binding.logical_dataset] = binding
        return cls(bindings)


_SQL_OP = {
    PredicateOp.EQ: "=",
    PredicateOp.NE: "<>",
    PredicateOp.LT: "<",
    PredicateOp.LTE: "<=",
    PredicateOp.GT: ">",
    PredicateOp.GTE: ">=",
    PredicateOp.IN: "IN",
}


def _ident(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value):
        raise ValueError(f"unsafe canonical identifier: {value}")
    return value


def _parse_datetime(value: Any, *, column: str) -> datetime:
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime.combine(value, time.min)
    if not isinstance(value, str):
        raise ValueError(f"temporal predicate {column} requires datetime/date/ISO string, got {type(value).__name__}")
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(text)
    except ValueError as exc:
        raise ValueError(f"temporal predicate {column} is not valid ISO-8601: {value!r}") from exc


def _normalize_temporal(value: Any, *, column: str) -> datetime:
    parsed = _parse_datetime(value, column=column)
    if parsed.tzinfo is not None:
        return parsed.astimezone(timezone.utc)
    return parsed


def _date_partition_bound(dt: datetime, op: PredicateOp, *, upper: bool) -> date:
    d = dt.date()
    if not upper:
        return d
    # For an upper timestamp within a day, `< next_date` is conservative. For an
    # exact midnight with LT, `< that_date` is already correct.
    midnight = dt.time().replace(tzinfo=None) == time.min
    if op == PredicateOp.LT and midnight:
        return d
    return d + timedelta(days=1)


class SqlTemplateBigDataClient:
    """Execute stable EPHI QuerySpecs through validated AutoPort semantic SQL.

    Binding SQL is a canonical projection, not a query-window contract. Exact
    canonical predicates are always applied by this runtime. Optional physical
    partition pruning is additive and conservative, so it can improve cost without
    changing event/knowledge-time semantics or blocking ID-based repository calls.
    """

    def __init__(
        self,
        executor: SqlArrowExecutor,
        registry: SqlBindingRegistry,
        *,
        policy: SqlRuntimePolicy | None = None,
        type_firewall: CanonicalTypeFirewall | None = None,
    ) -> None:
        self.executor = executor
        self.registry = registry
        self.policy = policy or SqlRuntimePolicy()
        self.type_firewall = type_firewall or CanonicalTypeFirewall()
        self._contracts = {c.logical_name: c for c in DEFAULT_DATASET_CONTRACTS}

    def _temporal_columns(self, dataset: str) -> frozenset[str]:
        contract = self._contracts.get(dataset)
        if not contract:
            return frozenset()
        return frozenset(x for x in (contract.event_time_column, contract.available_at_column) if x)

    def _partition_predicates(self, binding: SqlBindingManifest, query: QuerySpec) -> tuple[list[str], dict[str, Any]]:
        if not (binding.partition_column and binding.partition_source_field and binding.partition_granularity):
            return [], {}
        source = binding.partition_source_field
        matching = [p for p in query.predicates if p.column == source and p.op in {PredicateOp.GT, PredicateOp.GTE, PredicateOp.LT, PredicateOp.LTE}]
        if not matching:
            return [], {}
        where: list[str] = []
        params: dict[str, Any] = {}
        for idx, pred in enumerate(matching):
            dt = _normalize_temporal(pred.value, column=pred.column)
            upper = pred.op in {PredicateOp.LT, PredicateOp.LTE}
            if binding.partition_granularity == "date":
                value: Any = _date_partition_bound(dt, pred.op, upper=upper)
            else:
                value = dt
            key = f"partition_{idx}"
            # Conservative partition op: GT/GTE -> >= lower partition; LT/LTE -> < upper partition.
            op = "<" if upper else ">="
            where.append(f"_ephi_partition {op} :{key}")
            params[key] = value
        return where, params

    def _compile(self, query: QuerySpec) -> tuple[str, dict[str, Any]]:
        binding = self.registry.binding(query.dataset)
        base = binding.sql.strip().rstrip(";")
        if self.policy.reject_unbounded_queries and not query.predicates and query.limit is None:
            raise ValueError(f"refusing unbounded AutoPort query for {query.dataset}; add predicates or a limit")
        if query.limit is not None and (query.limit < 0 or query.limit > self.policy.max_limit):
            raise ValueError(f"query limit out of policy range: {query.limit}")

        select = ", ".join(_ident(column) for column in query.columns)
        sql = f"SELECT {select} FROM (\n{base}\n) AS ephi_bound"
        where, parameters = self._partition_predicates(binding, query)
        temporal_columns = self._temporal_columns(query.dataset)
        temporal_bounds: dict[str, dict[str, datetime]] = {}
        for pred in query.predicates:
            if pred.column not in temporal_columns or pred.op not in {PredicateOp.GT, PredicateOp.GTE, PredicateOp.LT, PredicateOp.LTE}:
                continue
            dt = _normalize_temporal(pred.value, column=pred.column)
            side = "upper" if pred.op in {PredicateOp.LT, PredicateOp.LTE} else "lower"
            temporal_bounds.setdefault(pred.column, {})[side] = dt
        for column, bounds in temporal_bounds.items():
            if "lower" in bounds and "upper" in bounds:
                delta = bounds["upper"] - bounds["lower"]
                if delta.total_seconds() < 0:
                    raise ValueError(f"temporal window inverted for {column}")
                if delta > timedelta(days=self.policy.max_window_days):
                    raise ValueError(
                        f"temporal window for {column} exceeds max_window_days={self.policy.max_window_days}; "
                        "use bounded backfill chunks instead"
                    )
        for index, pred in enumerate(query.predicates):
            column = _ident(pred.column)
            key = f"p{index}"
            if pred.op == PredicateOp.IN:
                values = tuple(pred.value)
                if len(values) > self.policy.max_in_values:
                    raise ValueError(f"IN predicate exceeds max_in_values={self.policy.max_in_values}")
                if not values:
                    where.append("1 = 0")
                    continue
                names = []
                for j, value in enumerate(values):
                    item_key = f"{key}_{j}"
                    names.append(f":{item_key}")
                    parameters[item_key] = value
                where.append(f"{column} IN ({', '.join(names)})")
            else:
                value = _normalize_temporal(pred.value, column=pred.column) if pred.column in temporal_columns else pred.value
                where.append(f"{column} {_SQL_OP[pred.op]} :{key}")
                parameters[key] = value
        if where:
            sql += "\nWHERE " + " AND ".join(where)
        if query.order_by:
            sql += "\nORDER BY " + ", ".join(_ident(column) for column in query.order_by)
        if query.limit is not None:
            sql += f"\nLIMIT {int(query.limit)}"
        return sql, parameters

    def query_arrow(self, query: QuerySpec):
        sql, parameters = self._compile(query)
        result = self.executor.query_sql_arrow(sql, parameters)
        firewall = self.type_firewall.validate(query.dataset, result)
        if not firewall.passed:
            raise ValueError("canonical type firewall rejected result: " + "; ".join(firewall.errors))
        return result

    def stream_arrow(self, query: QuerySpec, *, batch_rows: int = 65_536) -> Iterable:
        sql, parameters = self._compile(query)
        yield from self.executor.stream_sql_arrow(sql, parameters, batch_rows=batch_rows)
