from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from ephi.adapters.base.big_data import Predicate, QuerySpec


@dataclass(frozen=True, slots=True)
class ColumnMapping:
    logical_name: str
    physical_name: str


@dataclass(frozen=True, slots=True)
class DatasetMapping:
    logical_name: str
    physical_name: str
    columns: Mapping[str, str]

    def physical_column(self, logical_column: str) -> str:
        try:
            return self.columns[logical_column]
        except KeyError as exc:
            raise KeyError(
                f"No physical column mapping for {self.logical_name}.{logical_column}"
            ) from exc


class MappingRegistry:
    def __init__(self, datasets: Mapping[str, DatasetMapping]) -> None:
        self._datasets = dict(datasets)

    def dataset(self, logical_name: str) -> DatasetMapping:
        try:
            return self._datasets[logical_name]
        except KeyError as exc:
            raise KeyError(f"No physical dataset mapping for {logical_name}") from exc


def map_query_spec(query: QuerySpec, registry: MappingRegistry) -> tuple[QuerySpec, dict[str, str]]:
    """Map a logical repository query to company physical names.

    Returns the mapped QuerySpec and a physical->logical column rename map. The
    company-specific BigDataClient implementation only needs to execute the mapped
    query and restore the logical names on the returned Arrow table.
    """

    dataset = registry.dataset(query.dataset)
    physical_columns = tuple(dataset.physical_column(column) for column in query.columns)
    predicates = tuple(
        Predicate(
            column=dataset.physical_column(predicate.column),
            op=predicate.op,
            value=predicate.value,
        )
        for predicate in query.predicates
    )
    order_by = tuple(dataset.physical_column(column) for column in query.order_by)
    rename = {
        dataset.physical_column(column): column
        for column in query.columns
    }
    return (
        QuerySpec(
            dataset=dataset.physical_name,
            columns=physical_columns,
            predicates=predicates,
            order_by=order_by,
            limit=query.limit,
        ),
        rename,
    )
