from __future__ import annotations

from dataclasses import dataclass

from ephi.config import DataConfig
from ephi.domain.data_reality import DatasetContract, QualificationState


@dataclass(frozen=True, slots=True)
class MappingValidation:
    logical_name: str
    state: QualificationState
    physical_name: str | None
    missing_required_mappings: tuple[str, ...] = ()
    missing_optional_mappings: tuple[str, ...] = ()


def validate_mapping_config(
    config: DataConfig,
    contracts: tuple[DatasetContract, ...],
) -> tuple[MappingValidation, ...]:
    results: list[MappingValidation] = []
    for contract in contracts:
        binding = config.datasets.get(contract.logical_name)
        if binding is None:
            results.append(
                MappingValidation(
                    logical_name=contract.logical_name,
                    state=QualificationState.UNAVAILABLE,
                    physical_name=None,
                    missing_required_mappings=contract.required_columns,
                    missing_optional_mappings=contract.optional_columns,
                )
            )
            continue
        missing_required = tuple(
            column for column in contract.required_columns if column not in binding.columns
        )
        missing_optional = tuple(
            column for column in contract.optional_columns if column not in binding.columns
        )
        if missing_required:
            state = QualificationState.FAILED
        elif missing_optional:
            state = QualificationState.PARTIAL
        else:
            state = QualificationState.QUALIFIED
        results.append(
            MappingValidation(
                logical_name=contract.logical_name,
                state=state,
                physical_name=binding.physical_name,
                missing_required_mappings=missing_required,
                missing_optional_mappings=missing_optional,
            )
        )
    return tuple(results)
