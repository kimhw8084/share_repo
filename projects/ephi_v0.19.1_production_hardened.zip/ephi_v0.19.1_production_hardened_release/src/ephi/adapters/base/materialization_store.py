from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol, Sequence

if TYPE_CHECKING:
    import pyarrow as pa
else:
    pa = Any


class MaterializationStore(Protocol):
    def read(self, name: str, *, columns: Sequence[str] | None = None) -> pa.Table:
        ...

    def append(self, name: str, batch: pa.Table) -> None:
        ...

    def overwrite(self, name: str, batch: pa.Table) -> None:
        ...

    def upsert(self, name: str, batch: pa.Table, *, key_columns: Sequence[str]) -> None:
        ...
