from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol


@dataclass(frozen=True, slots=True)
class StateRecord:
    key: str
    value: bytes
    version: int
    updated_at: datetime


class StateStore(Protocol):
    def get(self, key: str) -> StateRecord | None:
        ...

    def compare_and_set(
        self,
        key: str,
        *,
        expected_version: int | None,
        value: bytes,
    ) -> StateRecord:
        ...

    def delete(self, key: str) -> None:
        ...


class SnapshotStateStore(StateStore, Protocol):
    """State-store extension for consistent disaster-recovery snapshots.

    Implementations must return a point-in-time-consistent view for ``snapshot`` and
    restore the supplied records atomically enough that readers cannot observe a partly
    restored authoritative namespace. Production adapters may map this contract to the
    approved database/backup mechanism rather than copying individual keys.
    """

    def snapshot(
        self,
        *,
        prefixes: tuple[str, ...] = (),
        keys: tuple[str, ...] = (),
    ) -> tuple[StateRecord, ...]:
        ...

    def restore_snapshot(
        self,
        records: tuple[StateRecord, ...],
        *,
        require_empty: bool = True,
    ) -> None:
        ...
