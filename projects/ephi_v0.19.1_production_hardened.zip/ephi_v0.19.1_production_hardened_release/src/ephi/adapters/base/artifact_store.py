from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Protocol


@dataclass(frozen=True, slots=True)
class ArtifactRef:
    artifact_id: str
    content_hash: str
    locator: str


class ArtifactStore(Protocol):
    def put(
        self,
        artifact_id: str,
        local_path: Path,
        *,
        metadata: Mapping[str, object],
    ) -> ArtifactRef:
        ...

    def materialize(self, artifact_ref: ArtifactRef) -> Path:
        ...
