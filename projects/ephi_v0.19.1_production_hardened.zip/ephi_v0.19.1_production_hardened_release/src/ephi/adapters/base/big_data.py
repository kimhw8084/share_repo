from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING, Any, Iterable, Protocol

if TYPE_CHECKING:
    import pyarrow as pa
else:
    pa = Any


class PredicateOp(StrEnum):
    EQ = "eq"
    NE = "ne"
    LT = "lt"
    LTE = "lte"
    GT = "gt"
    GTE = "gte"
    IN = "in"


@dataclass(frozen=True, slots=True)
class Predicate:
    column: str
    op: PredicateOp
    value: Any


@dataclass(frozen=True, slots=True)
class QuerySpec:
    dataset: str
    columns: tuple[str, ...]
    predicates: tuple[Predicate, ...] = ()
    order_by: tuple[str, ...] = ()
    limit: int | None = None


class BigDataClient(Protocol):
    def query_arrow(self, query: QuerySpec) -> pa.Table:
        ...

    def stream_arrow(self, query: QuerySpec, *, batch_rows: int = 65_536) -> Iterable[pa.RecordBatch]:
        ...
