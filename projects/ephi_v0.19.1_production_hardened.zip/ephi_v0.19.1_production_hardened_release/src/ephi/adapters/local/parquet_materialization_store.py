from __future__ import annotations

import shutil
import uuid
from pathlib import Path
from typing import Sequence

from ephi.errors import MissingOptionalDependencyError


def _require_local_deps():
    try:
        import duckdb  # type: ignore
        import pyarrow as pa  # type: ignore
        import pyarrow.dataset as ds  # type: ignore
        import pyarrow.parquet as pq  # type: ignore
    except ImportError as exc:
        raise MissingOptionalDependencyError(
            "Parquet materialization store requires `pip install -e '.[local]'`"
        ) from exc
    return duckdb, pa, ds, pq


class ParquetMaterializationStore:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def _dir(self, name: str) -> Path:
        if not name or "/" in name or ".." in name:
            raise ValueError(f"Invalid materialization name: {name!r}")
        return self.root / name

    def read(self, name: str, *, columns: Sequence[str] | None = None):
        _, pa, ds, _ = _require_local_deps()
        directory = self._dir(name)
        if not directory.exists():
            return pa.table({})
        dataset = ds.dataset(directory, format="parquet")
        return dataset.to_table(columns=list(columns) if columns else None)

    def append(self, name: str, batch) -> None:
        _, _, _, pq = _require_local_deps()
        directory = self._dir(name)
        directory.mkdir(parents=True, exist_ok=True)
        pq.write_table(batch, directory / f"part-{uuid.uuid4().hex}.parquet")

    def overwrite(self, name: str, batch) -> None:
        _, _, _, pq = _require_local_deps()
        directory = self._dir(name)
        tmp = directory.with_name(directory.name + f".tmp-{uuid.uuid4().hex}")
        tmp.mkdir(parents=True, exist_ok=False)
        pq.write_table(batch, tmp / "part-00000.parquet")
        if directory.exists():
            shutil.rmtree(directory)
        tmp.rename(directory)

    def upsert(self, name: str, batch, *, key_columns: Sequence[str]) -> None:
        duckdb, _, _, _ = _require_local_deps()
        if not key_columns:
            raise ValueError("key_columns must not be empty")
        existing = self.read(name)
        if existing.num_rows == 0:
            self.overwrite(name, batch)
            return
        con = duckdb.connect()
        try:
            con.register("existing", existing)
            con.register("incoming", batch)
            join = " AND ".join(f'e."{k}" = i."{k}"' for k in key_columns)
            query = (
                "SELECT e.* FROM existing e "
                f"WHERE NOT EXISTS (SELECT 1 FROM incoming i WHERE {join}) "
                "UNION ALL BY NAME SELECT * FROM incoming"
            )
            merged = con.execute(query).fetch_arrow_table()
        finally:
            con.close()
        self.overwrite(name, merged)
