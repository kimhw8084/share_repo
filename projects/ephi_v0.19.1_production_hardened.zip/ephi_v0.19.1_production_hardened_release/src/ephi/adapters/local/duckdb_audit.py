from __future__ import annotations

import re
from pathlib import Path
from typing import Mapping

from ephi.audit import DataRealityBackend
from ephi.domain.data_reality import DatasetContract, DatasetProfile, JoinContract, JoinProfile
from ephi.errors import MissingOptionalDependencyError

_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _ident(value: str) -> str:
    if not _IDENTIFIER.fullmatch(value):
        raise ValueError(f"unsafe local audit identifier: {value!r}")
    return f'"{value}"'


class DuckDBParquetAuditBackend(DataRealityBackend):
    """Pushdown Data Reality Audit backend for local/reference Parquet datasets."""

    def __init__(self, datasets: Mapping[str, str | Path]) -> None:
        try:
            import duckdb  # type: ignore
        except ImportError as exc:
            raise MissingOptionalDependencyError(
                "DuckDB data audit requires `pip install -e '.[local]'`"
            ) from exc
        self.duckdb = duckdb
        self.datasets = {name: str(Path(path)) for name, path in datasets.items()}

    def _path(self, logical_name: str) -> str | None:
        path = self.datasets.get(logical_name)
        return path if path and Path(path).exists() else None

    def _columns(self, con, path: str) -> tuple[str, ...]:
        result = con.execute("SELECT * FROM read_parquet(?) LIMIT 0", [path])
        return tuple(str(item[0]) for item in result.description)

    def profile_dataset(self, contract: DatasetContract) -> DatasetProfile | None:
        path = self._path(contract.logical_name)
        if path is None:
            return None
        con = self.duckdb.connect()
        try:
            columns = self._columns(con, path)
            column_set = set(columns)
            row_count = int(con.execute("SELECT count(*) FROM read_parquet(?)", [path]).fetchone()[0])

            declared = [column for column in contract.all_declared_columns() if column in column_set]
            null_fraction: dict[str, float] = {}
            if row_count > 0:
                for column in declared:
                    nulls = int(
                        con.execute(
                            f"SELECT count(*) FROM read_parquet(?) WHERE {_ident(column)} IS NULL",
                            [path],
                        ).fetchone()[0]
                    )
                    null_fraction[column] = nulls / row_count

            distinct_count: dict[str, int] = {}
            for column in contract.identity_columns:
                if column in column_set:
                    distinct_count[column] = int(
                        con.execute(
                            f"SELECT count(DISTINCT {_ident(column)}) FROM read_parquet(?)",
                            [path],
                        ).fetchone()[0]
                    )

            def minmax(column: str | None):
                if not column or column not in column_set:
                    return None, None
                row = con.execute(
                    f"SELECT min({_ident(column)}), max({_ident(column)}) FROM read_parquet(?)",
                    [path],
                ).fetchone()
                return (
                    str(row[0]) if row and row[0] is not None else None,
                    str(row[1]) if row and row[1] is not None else None,
                )

            event_min, event_max = minmax(contract.event_time_column)
            available_min, available_max = minmax(contract.available_at_column)

            duplicate_fraction = None
            keys = [column for column in contract.identity_columns if column in column_set]
            if row_count > 0 and keys:
                key_sql = ", ".join(_ident(column) for column in keys)
                duplicate_rows = int(
                    con.execute(
                        f"SELECT coalesce(sum(c - 1), 0) FROM ("
                        f"SELECT count(*) c FROM read_parquet(?) GROUP BY {key_sql} HAVING count(*) > 1"
                        f")",
                        [path],
                    ).fetchone()[0]
                )
                duplicate_fraction = duplicate_rows / row_count

            delay = (None, None, None)
            if (
                contract.event_time_column
                and contract.available_at_column
                and contract.event_time_column in column_set
                and contract.available_at_column in column_set
                and row_count > 0
            ):
                event = _ident(contract.event_time_column)
                available = _ident(contract.available_at_column)
                row = con.execute(
                    "SELECT "
                    f"quantile_cont(epoch({available}) - epoch({event}), 0.50), "
                    f"quantile_cont(epoch({available}) - epoch({event}), 0.95), "
                    f"quantile_cont(epoch({available}) - epoch({event}), 0.99) "
                    "FROM read_parquet(?) "
                    f"WHERE {event} IS NOT NULL AND {available} IS NOT NULL",
                    [path],
                ).fetchone()
                if row:
                    delay = tuple(float(value) if value is not None else None for value in row)

            return DatasetProfile(
                logical_name=contract.logical_name,
                row_count=row_count,
                columns=columns,
                null_fraction=null_fraction,
                distinct_count=distinct_count,
                event_time_min=event_min,
                event_time_max=event_max,
                available_at_min=available_min,
                available_at_max=available_max,
                duplicate_key_fraction=duplicate_fraction,
                availability_delay_p50_seconds=delay[0],
                availability_delay_p95_seconds=delay[1],
                availability_delay_p99_seconds=delay[2],
            )
        finally:
            con.close()

    def profile_join(self, contract: JoinContract) -> JoinProfile | None:
        left_path = self._path(contract.left_dataset)
        right_path = self._path(contract.right_dataset)
        if left_path is None or right_path is None:
            return None
        if len(contract.left_keys) != len(contract.right_keys) or not contract.left_keys:
            raise ValueError("join contracts require equal non-empty key lists")
        con = self.duckdb.connect()
        try:
            left_columns = set(self._columns(con, left_path))
            right_columns = set(self._columns(con, right_path))
            if any(key not in left_columns for key in contract.left_keys):
                return None
            if any(key not in right_columns for key in contract.right_keys):
                return None

            right_group = ", ".join(_ident(key) for key in contract.right_keys)
            select_right = ", ".join(_ident(key) for key in contract.right_keys)
            join_on = " AND ".join(
                f"l.{_ident(left)} = r.{_ident(right)}"
                for left, right in zip(contract.left_keys, contract.right_keys)
            )
            row = con.execute(
                "WITH l AS (SELECT * FROM read_parquet(?)), "
                f"r AS (SELECT {select_right}, count(*) AS _n FROM read_parquet(?) GROUP BY {right_group}) "
                "SELECT count(*) AS left_rows, "
                "sum(CASE WHEN r._n IS NOT NULL THEN 1 ELSE 0 END) AS matched_left_rows, "
                "sum(CASE WHEN r._n > 1 THEN 1 ELSE 0 END) AS ambiguous_left_rows "
                f"FROM l LEFT JOIN r ON {join_on}",
                [left_path, right_path],
            ).fetchone()
            return JoinProfile(
                join_id=contract.join_id,
                left_rows=int(row[0] or 0),
                matched_left_rows=int(row[1] or 0),
                ambiguous_left_rows=int(row[2] or 0),
            )
        finally:
            con.close()
