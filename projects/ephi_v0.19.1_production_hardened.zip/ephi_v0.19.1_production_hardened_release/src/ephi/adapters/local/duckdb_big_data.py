from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

from ephi.adapters.base.big_data import BigDataClient, PredicateOp, QuerySpec
from ephi.errors import DataUnavailableError, MissingOptionalDependencyError

_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _require_duckdb():
    try:
        import duckdb  # type: ignore
    except ImportError as exc:
        raise MissingOptionalDependencyError(
            "DuckDB local adapter requires `pip install -e '.[local]'`"
        ) from exc
    return duckdb


def _quote_identifier(value: str) -> str:
    if not _IDENTIFIER.fullmatch(value):
        raise ValueError(f"Unsafe identifier: {value!r}")
    return f'"{value}"'


class DuckDBBigDataClient(BigDataClient):
    """Local reference adapter over named Parquet datasets."""

    def __init__(self, datasets: dict[str, str | Path]) -> None:
        self.datasets = {name: str(Path(path)) for name, path in datasets.items()}

    def query_arrow(self, query: QuerySpec):
        duckdb = _require_duckdb()
        path = self.datasets.get(query.dataset)
        if path is None:
            raise DataUnavailableError(f"Unknown local dataset: {query.dataset}")

        columns = ", ".join(_quote_identifier(c) for c in query.columns) if query.columns else "*"
        sql = [f"SELECT {columns} FROM read_parquet(?)"]
        params: list[object] = [path]

        clauses: list[str] = []
        op_map = {
            PredicateOp.EQ: "=",
            PredicateOp.NE: "!=",
            PredicateOp.LT: "<",
            PredicateOp.LTE: "<=",
            PredicateOp.GT: ">",
            PredicateOp.GTE: ">=",
        }
        for predicate in query.predicates:
            col = _quote_identifier(predicate.column)
            if predicate.op == PredicateOp.IN:
                values = tuple(predicate.value)
                if not values:
                    clauses.append("1 = 0")
                    continue
                placeholders = ", ".join("?" for _ in values)
                clauses.append(f"{col} IN ({placeholders})")
                params.extend(values)
            else:
                clauses.append(f"{col} {op_map[predicate.op]} ?")
                params.append(predicate.value)

        if clauses:
            sql.append("WHERE " + " AND ".join(clauses))
        if query.order_by:
            sql.append("ORDER BY " + ", ".join(_quote_identifier(c) for c in query.order_by))
        if query.limit is not None:
            if query.limit < 0:
                raise ValueError("limit must be non-negative")
            sql.append("LIMIT ?")
            params.append(query.limit)

        connection = duckdb.connect()
        try:
            return connection.execute(" ".join(sql), params).fetch_arrow_table()
        finally:
            connection.close()

    def stream_arrow(self, query: QuerySpec, *, batch_rows: int = 65_536) -> Iterable[object]:
        table = self.query_arrow(query)
        yield from table.to_batches(max_chunksize=batch_rows)
