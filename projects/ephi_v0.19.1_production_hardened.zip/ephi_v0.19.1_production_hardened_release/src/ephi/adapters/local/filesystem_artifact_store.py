from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path
from typing import Mapping

from ephi.adapters.base.artifact_store import ArtifactRef


class FileSystemArtifactStore:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _sha256(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest()

    def put(
        self,
        artifact_id: str,
        local_path: Path,
        *,
        metadata: Mapping[str, object],
    ) -> ArtifactRef:
        digest = self._sha256(local_path)
        target_dir = self.root / artifact_id / digest
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / local_path.name
        if not target.exists():
            shutil.copy2(local_path, target)
        metadata_path = target_dir / "metadata.json"
        metadata_path.write_text(
            json.dumps(dict(metadata), sort_keys=True, indent=2, default=str), encoding="utf-8"
        )
        return ArtifactRef(artifact_id=artifact_id, content_hash=digest, locator=str(target))

    def materialize(self, artifact_ref: ArtifactRef) -> Path:
        path = Path(artifact_ref.locator)
        if not path.exists():
            raise FileNotFoundError(path)
        if self._sha256(path) != artifact_ref.content_hash:
            raise ValueError(f"Artifact hash mismatch: {artifact_ref.artifact_id}")
        return path
