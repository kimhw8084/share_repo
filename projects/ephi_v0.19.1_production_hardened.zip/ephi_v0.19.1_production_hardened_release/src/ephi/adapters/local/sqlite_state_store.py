from __future__ import annotations

import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path

from ephi.adapters.base.state_store import StateRecord
from ephi.errors import StateConflictError


class SqliteStateStore:
    """Durable local state store with optimistic compare-and-set semantics.

    SQLite is a local/reference backend only. Initialization is lock-aware so multiple
    local processes/services may start against the same database without racing on WAL
    configuration. Multi-pod production deployments must use the company shared store.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=30.0, isolation_level=None)
        connection.execute("PRAGMA busy_timeout=30000")
        connection.execute("PRAGMA synchronous=NORMAL")
        return connection

    def _initialize(self) -> None:
        last_error: sqlite3.OperationalError | None = None
        for attempt in range(50):
            try:
                with self._connect() as connection:
                    # WAL is a database-level setting. Configure it during initialization,
                    # not on every connection, to avoid concurrent startup lock races.
                    connection.execute("PRAGMA journal_mode=WAL")
                    connection.execute(
                        """
                        CREATE TABLE IF NOT EXISTS ephi_state (
                            key TEXT PRIMARY KEY,
                            version INTEGER NOT NULL,
                            value BLOB NOT NULL,
                            updated_at TEXT NOT NULL
                        )
                        """
                    )
                return
            except sqlite3.OperationalError as exc:
                if "locked" not in str(exc).lower() and "busy" not in str(exc).lower():
                    raise
                last_error = exc
                time.sleep(min(0.002 * (attempt + 1), 0.05))
        raise sqlite3.OperationalError(
            f"SQLite state initialization remained locked: {self.path}"
        ) from last_error

    def get(self, key: str) -> StateRecord | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT version, value, updated_at FROM ephi_state WHERE key = ?", (key,)
            ).fetchone()
        if row is None:
            return None
        version, value, updated_at = row
        return StateRecord(
            key=key,
            value=bytes(value),
            version=int(version),
            updated_at=datetime.fromisoformat(updated_at),
        )

    def compare_and_set(
        self,
        key: str,
        *,
        expected_version: int | None,
        value: bytes,
    ) -> StateRecord:
        now = datetime.now(timezone.utc)
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT version FROM ephi_state WHERE key = ?", (key,)
            ).fetchone()
            current_version = int(row[0]) if row is not None else None

            if current_version != expected_version:
                connection.execute("ROLLBACK")
                raise StateConflictError(
                    f"State version conflict for {key!r}: expected {expected_version}, "
                    f"found {current_version}"
                )

            next_version = 1 if current_version is None else current_version + 1
            connection.execute(
                """
                INSERT INTO ephi_state(key, version, value, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    version = excluded.version,
                    value = excluded.value,
                    updated_at = excluded.updated_at
                """,
                (key, next_version, sqlite3.Binary(value), now.isoformat()),
            )
            connection.execute("COMMIT")

        return StateRecord(key=key, value=value, version=next_version, updated_at=now)


    def snapshot(
        self,
        *,
        prefixes: tuple[str, ...] = (),
        keys: tuple[str, ...] = (),
    ) -> tuple[StateRecord, ...]:
        """Return a point-in-time-consistent snapshot of selected state keys.

        An empty selector snapshots all keys. SQLite read transactions provide a stable
        view while concurrent writers continue under WAL mode.
        """
        clauses: list[str] = []
        params: list[str] = []
        if keys:
            placeholders = ",".join("?" for _ in keys)
            clauses.append(f"key IN ({placeholders})")
            params.extend(keys)
        if prefixes:
            clauses.append("(" + " OR ".join("key LIKE ?" for _ in prefixes) + ")")
            params.extend(f"{prefix}%" for prefix in prefixes)
        where = f" WHERE {' OR '.join(clauses)}" if clauses else ""
        with self._connect() as connection:
            connection.execute("BEGIN")
            rows = connection.execute(
                f"SELECT key, version, value, updated_at FROM ephi_state{where} ORDER BY key",
                tuple(params),
            ).fetchall()
            connection.execute("COMMIT")
        return tuple(
            StateRecord(
                key=str(key),
                version=int(version),
                value=bytes(value),
                updated_at=datetime.fromisoformat(updated_at),
            )
            for key, version, value, updated_at in rows
        )

    def restore_snapshot(
        self,
        records: tuple[StateRecord, ...],
        *,
        require_empty: bool = True,
    ) -> None:
        """Restore an exact local/reference snapshot in one write transaction.

        Production restore should normally target a fresh state namespace. ``require_empty``
        is therefore true by default to prevent accidental merge of stale live state with a
        backup. CAS versions and timestamps are preserved for deterministic restart tests.
        """
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            if require_empty:
                count = int(connection.execute("SELECT COUNT(*) FROM ephi_state").fetchone()[0])
                if count:
                    connection.execute("ROLLBACK")
                    raise ValueError("restore target must be empty")
            try:
                for record in records:
                    connection.execute(
                        """
                        INSERT INTO ephi_state(key, version, value, updated_at)
                        VALUES (?, ?, ?, ?)
                        ON CONFLICT(key) DO UPDATE SET
                            version = excluded.version,
                            value = excluded.value,
                            updated_at = excluded.updated_at
                        """,
                        (
                            record.key,
                            record.version,
                            sqlite3.Binary(record.value),
                            record.updated_at.isoformat(),
                        ),
                    )
                connection.execute("COMMIT")
            except Exception:
                connection.execute("ROLLBACK")
                raise

    def delete(self, key: str) -> None:
        with self._connect() as connection:
            connection.execute("DELETE FROM ephi_state WHERE key = ?", (key,))
