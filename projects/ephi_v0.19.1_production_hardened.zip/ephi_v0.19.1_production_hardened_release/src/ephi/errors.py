class EphiError(Exception):
    """Base EPHI exception."""


class MissingOptionalDependencyError(EphiError):
    pass


class SchemaContractError(EphiError):
    pass


class DataUnavailableError(EphiError):
    pass


class StateConflictError(EphiError):
    pass


class InvalidKnowledgeTimeError(EphiError):
    pass
