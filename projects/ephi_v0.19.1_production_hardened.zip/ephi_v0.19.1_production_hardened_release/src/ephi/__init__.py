"""Equipment & Process Unit Health Intelligence (EPHI)."""

from .version import __version__

__all__ = ["__version__"]
