from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True, order=True)
class ContextKey:
    """Manufacturing comparison context used by the first behavioral vertical slice.

    The production context resolver can later relax/group dimensions explicitly; this
    key represents the *effective* hard-match context for a particular score.
    """

    operation: str
    recipe_id: str
    product_id: str
    technology: str

    def stable_key(self) -> str:
        return "|".join((self.operation, self.recipe_id, self.product_id, self.technology))

    def to_dict(self) -> dict[str, str]:
        return {
            "operation": self.operation,
            "recipe_id": self.recipe_id,
            "product_id": self.product_id,
            "technology": self.technology,
        }

    @classmethod
    def from_dict(cls, value: dict[str, str]) -> "ContextKey":
        return cls(
            operation=value["operation"],
            recipe_id=value["recipe_id"],
            product_id=value["product_id"],
            technology=value["technology"],
        )
