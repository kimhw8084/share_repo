from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum

from .context import ContextKey
from .evidence import Hypothesis
from .health import HealthSeverity


class EpisodeState(StrEnum):
    INVESTIGATE = "INVESTIGATE"
    URGENT = "URGENT"
    RECOVERING = "RECOVERING"
    RESOLVED = "RESOLVED"


@dataclass(frozen=True, slots=True)
class HealthEpisode:
    episode_id: str
    asset_id: str
    context: ContextKey
    opened_at: datetime
    last_updated_at: datetime
    state: EpisodeState
    severity: HealthSeverity
    leading_hypothesis: Hypothesis
    peak_behavioral_novelty: float
    consecutive_recovery: int = 0
    closed_at: datetime | None = None


class FleetEpisodeState(StrEnum):
    ACTIVE = "ACTIVE"
    RECOVERING = "RECOVERING"
    RESOLVED = "RESOLVED"


@dataclass(frozen=True, slots=True)
class FleetEpisode:
    episode_id: str
    context: ContextKey
    opened_at: datetime
    last_updated_at: datetime
    state: FleetEpisodeState
    affected_asset_ids: tuple[str, ...]
    leading_hypothesis: Hypothesis
    peak_common_support: float
    consecutive_recovery: int = 0
    closed_at: datetime | None = None
