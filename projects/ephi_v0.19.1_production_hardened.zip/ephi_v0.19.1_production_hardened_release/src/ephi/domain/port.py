from __future__ import annotations

import hashlib
import json
from datetime import datetime
from enum import StrEnum
from typing import TypeAlias

from pydantic import BaseModel, ConfigDict, Field, model_validator

JsonScalar: TypeAlias = str | int | float | bool | None


class StrictFrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class PortStage(StrEnum):
    MAPPING_VALIDATION = "MAPPING_VALIDATION"
    DATA_REALITY = "DATA_REALITY"
    STATE_BOOTSTRAP = "STATE_BOOTSTRAP"
    GOLDEN_REPLAY = "GOLDEN_REPLAY"
    OPERATIONS_QUALIFICATION = "OPERATIONS_QUALIFICATION"
    SHADOW_READINESS = "SHADOW_READINESS"


class PortStageState(StrEnum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    PASSED = "PASSED"
    FAILED = "FAILED"
    BLOCKED = "BLOCKED"


class PortGateEvidence(StrictFrozenModel):
    passed: bool
    summary: str
    artifact: str | None = None
    blockers: tuple[str, ...] = ()
    metrics: dict[str, JsonScalar] = Field(default_factory=dict)

    @model_validator(mode="after")
    def failure_has_reason(self) -> "PortGateEvidence":
        if not self.passed and not self.blockers and not self.summary.strip():
            raise ValueError("failed port gate must explain why it failed")
        return self


class PortStageRecord(StrictFrozenModel):
    stage: PortStage
    state: PortStageState
    started_at: datetime | None = None
    completed_at: datetime | None = None
    evidence: PortGateEvidence | None = None
    error_type: str | None = None

    @model_validator(mode="after")
    def state_consistency(self) -> "PortStageRecord":
        terminal = {PortStageState.PASSED, PortStageState.FAILED, PortStageState.BLOCKED}
        if self.state in terminal and self.completed_at is None:
            raise ValueError("terminal port stage records require completed_at")
        if self.state == PortStageState.PASSED and (self.evidence is None or not self.evidence.passed):
            raise ValueError("passed port stage requires passing evidence")
        if self.state == PortStageState.FAILED and self.evidence is not None and self.evidence.passed:
            raise ValueError("failed port stage cannot carry passing evidence")
        return self


class PortRunIdentity(StrictFrozenModel):
    release_id: str
    package_version: str
    config_hash: str
    family_id: str
    environment: str

    def stable_hash(self) -> str:
        payload = json.dumps(self.model_dump(mode="json"), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class PortBootstrapReport(StrictFrozenModel):
    report_version: str = "1"
    run_id: str
    identity: PortRunIdentity
    started_at: datetime
    completed_at: datetime | None = None
    stages: tuple[PortStageRecord, ...]
    shadow_ready: bool = False
    blockers: tuple[str, ...] = ()

    def stage(self, stage: PortStage) -> PortStageRecord:
        for item in self.stages:
            if item.stage == stage:
                return item
        raise KeyError(stage)

    @property
    def passed_stages(self) -> frozenset[PortStage]:
        return frozenset(item.stage for item in self.stages if item.state == PortStageState.PASSED)
