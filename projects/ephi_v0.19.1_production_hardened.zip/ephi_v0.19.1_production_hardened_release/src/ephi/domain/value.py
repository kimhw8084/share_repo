from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, model_validator


class ValueCategory(StrEnum):
    MATERIAL_ALREADY_EXPOSED = "MATERIAL_ALREADY_EXPOSED"
    MATERIAL_POTENTIALLY_AFFECTED = "MATERIAL_POTENTIALLY_AFFECTED"
    MATERIAL_FUTURE_PREVENTABLE = "MATERIAL_FUTURE_PREVENTABLE"
    WAFERS_PROTECTED = "WAFERS_PROTECTED"
    SCRAP_EXPOSURE_ESTIMATE = "SCRAP_EXPOSURE_ESTIMATE"
    REWORK_EXPOSURE_ESTIMATE = "REWORK_EXPOSURE_ESTIMATE"
    DOWNTIME_AVOIDED = "DOWNTIME_AVOIDED"
    CAPACITY_PROTECTED = "CAPACITY_PROTECTED"
    CYCLE_TIME_REDUCTION = "CYCLE_TIME_REDUCTION"
    ENGINEERING_TIME_SAVED = "ENGINEERING_TIME_SAVED"
    REMEASUREMENT_AVOIDED = "REMEASUREMENT_AVOIDED"
    INVESTIGATION_COST = "INVESTIGATION_COST"
    COMPUTE_COST = "COMPUTE_COST"
    FALSE_ACTIONABLE_EVENT_COST = "FALSE_ACTIONABLE_EVENT_COST"
    MISSED_OPPORTUNITY_EXPOSURE = "MISSED_OPPORTUNITY_EXPOSURE"
    VALIDATED_REALIZED_BENEFIT = "VALIDATED_REALIZED_BENEFIT"


class ValueEvidenceState(StrEnum):
    ESTIMATED = "ESTIMATED"
    OBSERVED = "OBSERVED"
    VALIDATED = "VALIDATED"


class ValueMaturity(StrEnum):
    ESTIMATED_EXPOSURE = "ESTIMATED_EXPOSURE"
    ACTION_RECORDED = "ACTION_RECORDED"
    OUTCOME_PARTIAL = "OUTCOME_PARTIAL"
    OUTCOME_MATURE = "OUTCOME_MATURE"
    FINANCIAL_VALIDATION_PENDING = "FINANCIAL_VALIDATION_PENDING"
    VALIDATED_REALIZED_VALUE = "VALIDATED_REALIZED_VALUE"


class BenefitAttributionRole(StrEnum):
    PRIMARY = "PRIMARY"
    CONTRIBUTORY = "CONTRIBUTORY"
    CONFIRMATORY = "CONFIRMATORY"
    NONE = "NONE"
    UNKNOWN = "UNKNOWN"


class CostModelApproval(StrEnum):
    DRAFT = "DRAFT"
    APPROVED = "APPROVED"
    DEPRECATED = "DEPRECATED"


class MoneyRate(BaseModel):
    model_config = ConfigDict(frozen=True)

    rate_id: str
    amount_per_unit: float = Field(ge=0.0)
    unit: str
    currency: str = Field(min_length=3, max_length=3)
    description: str = ""


class CostModelDefinition(BaseModel):
    model_config = ConfigDict(frozen=True)

    cost_model_id: str
    version: str
    approval_status: CostModelApproval = CostModelApproval.DRAFT
    effective_from: datetime | None = None
    effective_to: datetime | None = None
    source: str
    confidence: float = Field(ge=0.0, le=1.0)
    rates: tuple[MoneyRate, ...] = ()

    @model_validator(mode="after")
    def _validate_effective_window(self) -> "CostModelDefinition":
        if self.effective_from and self.effective_to and self.effective_to < self.effective_from:
            raise ValueError("effective_to must not precede effective_from")
        ids = [item.rate_id for item in self.rates]
        if len(ids) != len(set(ids)):
            raise ValueError("cost model rate_id values must be unique")
        return self

    def rate(self, rate_id: str) -> MoneyRate:
        for item in self.rates:
            if item.rate_id == rate_id:
                return item
        raise KeyError(f"unknown cost-model rate: {rate_id}")

    def is_effective(self, at: datetime) -> bool:
        if self.effective_from and at < self.effective_from:
            return False
        if self.effective_to and at > self.effective_to:
            return False
        return True


class BenefitClaimGroup(BaseModel):
    """A single economic event that may involve one or more EPHI episodes.

    ``economic_event_key`` is the deduplication identity for official realized-value
    aggregation. Multiple episodes can be contributors to the same economic event,
    but the event can have only one active validated-realized-benefit entry per currency.
    """

    model_config = ConfigDict(frozen=True)

    claim_group_id: str
    economic_event_key: str
    episode_ids: tuple[str, ...]
    material_ids: tuple[str, ...] = ()
    description: str
    created_at: datetime

    @model_validator(mode="after")
    def _validate_group(self) -> "BenefitClaimGroup":
        if not self.episode_ids:
            raise ValueError("benefit claim group must reference at least one episode")
        if len(self.episode_ids) != len(set(self.episode_ids)):
            raise ValueError("duplicate episode_id in benefit claim group")
        if len(self.material_ids) != len(set(self.material_ids)):
            raise ValueError("duplicate material_id in benefit claim group")
        return self


class BenefitAttribution(BaseModel):
    model_config = ConfigDict(frozen=True)

    claim_group_id: str
    episode_id: str
    role: BenefitAttributionRole
    attribution_confidence: float = Field(ge=0.0, le=1.0)
    supporting_evidence: tuple[str, ...] = ()
    review_status: str = "UNREVIEWED"


class ValueLedgerEntry(BaseModel):
    model_config = ConfigDict(frozen=True)

    ledger_entry_id: str
    episode_id: str | None = None
    claim_group_id: str | None = None
    category: ValueCategory
    quantity: float = Field(ge=0.0)
    unit: str
    monetary_value: float | None = Field(default=None, ge=0.0)
    currency: str | None = Field(default=None, min_length=3, max_length=3)
    method: str
    cost_model_id: str | None = None
    cost_model_version: str | None = None
    evidence_state: ValueEvidenceState
    maturity: ValueMaturity
    source_references: tuple[str, ...] = ()
    material_ids: tuple[str, ...] = ()
    computed_at: datetime
    observed_at: datetime | None = None
    validated_at: datetime | None = None
    validated_by: str | None = None
    supersedes_entry_id: str | None = None

    @model_validator(mode="after")
    def _validate_semantics(self) -> "ValueLedgerEntry":
        if len(self.material_ids) != len(set(self.material_ids)):
            raise ValueError("ledger entry material_ids must be unique")
        if (self.monetary_value is None) != (self.currency is None):
            raise ValueError("monetary_value and currency must be provided together")
        if (self.cost_model_id is None) != (self.cost_model_version is None):
            raise ValueError("cost_model_id and cost_model_version must be provided together")
        if self.evidence_state == ValueEvidenceState.VALIDATED:
            if not self.validated_at or not self.validated_by:
                raise ValueError("validated entries require validated_at and validated_by")
        else:
            if self.validated_at is not None or self.validated_by is not None:
                raise ValueError("non-validated entries cannot carry validation metadata")
        if self.category == ValueCategory.VALIDATED_REALIZED_BENEFIT:
            if self.evidence_state != ValueEvidenceState.VALIDATED:
                raise ValueError("validated realized benefit must use VALIDATED evidence state")
            if self.maturity != ValueMaturity.VALIDATED_REALIZED_VALUE:
                raise ValueError("validated realized benefit must use VALIDATED_REALIZED_VALUE maturity")
            if self.claim_group_id is None:
                raise ValueError("validated realized benefit requires a claim_group_id")
            if self.monetary_value is None:
                raise ValueError("validated realized benefit requires a monetary value")
        if self.category in {
            ValueCategory.SCRAP_EXPOSURE_ESTIMATE,
            ValueCategory.REWORK_EXPOSURE_ESTIMATE,
        } and self.evidence_state == ValueEvidenceState.VALIDATED:
            raise ValueError("estimated exposure categories cannot be promoted to VALIDATED")
        return self


class EpisodeValueSummary(BaseModel):
    model_config = ConfigDict(frozen=True)

    episode_id: str
    as_of: datetime
    estimated_exposure_value: float = Field(default=0.0, ge=0.0)
    validated_realized_benefit: float = Field(default=0.0, ge=0.0)
    observed_operating_cost: float = Field(default=0.0, ge=0.0)
    currency: str | None = None
    wafers_protected: int = Field(default=0, ge=0)
    engineering_hours_saved: float = Field(default=0.0, ge=0.0)
    maturity: ValueMaturity = ValueMaturity.ESTIMATED_EXPOSURE
    latest_entry_at: datetime | None = None


class ProgramValueSummary(BaseModel):
    model_config = ConfigDict(frozen=True)

    as_of: datetime
    currency: str | None = None
    estimated_exposure_value: float = Field(default=0.0, ge=0.0)
    validated_realized_benefit: float = Field(default=0.0, ge=0.0)
    operating_cost: float = Field(default=0.0, ge=0.0)
    net_validated_value: float = 0.0
    benefit_cost_ratio: float | None = Field(default=None, ge=0.0)
    wafers_protected: int = Field(default=0, ge=0)
    engineering_hours_saved: float = Field(default=0.0, ge=0.0)
    validated_claim_groups: int = Field(default=0, ge=0)
    active_entries: int = Field(default=0, ge=0)


PositiveFloat = Annotated[float, Field(gt=0.0)]


class ProtectionEvidence(BaseModel):
    model_config = ConfigDict(frozen=True)

    episode_id: str
    claim_group_id: str
    material_ids: tuple[str, ...]
    action: str
    routing_evidence: tuple[str, ...]
    observed_at: datetime
    confidence: float = Field(ge=0.0, le=1.0)

    @model_validator(mode="after")
    def _validate_materials(self) -> "ProtectionEvidence":
        if not self.material_ids:
            raise ValueError("protection evidence requires at least one material")
        if len(self.material_ids) != len(set(self.material_ids)):
            raise ValueError("protection evidence material_ids must be unique")
        if not self.routing_evidence:
            raise ValueError("wafers protected requires routing/action evidence")
        return self


class EngineeringTimeEvidence(BaseModel):
    model_config = ConfigDict(frozen=True)

    episode_id: str
    baseline_hours: float = Field(ge=0.0)
    actual_hours: float = Field(ge=0.0)
    method: str
    observed_at: datetime

    @property
    def hours_saved(self) -> float:
        return max(0.0, self.baseline_hours - self.actual_hours)


class ResourceUsage(BaseModel):
    model_config = ConfigDict(frozen=True)

    usage_id: str
    episode_id: str | None = None
    cpu_hours: float = Field(default=0.0, ge=0.0)
    gpu_hours: float = Field(default=0.0, ge=0.0)
    storage_gb_month: float = Field(default=0.0, ge=0.0)
    big_data_tb_scanned: float = Field(default=0.0, ge=0.0)
    observed_at: datetime
    source_reference: str


class ValidatedBenefitEvidence(BaseModel):
    model_config = ConfigDict(frozen=True)

    claim_group_id: str
    amount: PositiveFloat
    currency: str = Field(min_length=3, max_length=3)
    method: str
    validated_at: datetime
    validated_by: str
    source_references: tuple[str, ...]

    @model_validator(mode="after")
    def _require_sources(self) -> "ValidatedBenefitEvidence":
        if not self.source_references:
            raise ValueError("validated realized benefit requires supporting source references")
        return self


class LossEstimateEvidence(BaseModel):
    model_config = ConfigDict(frozen=True)

    episode_id: str
    claim_group_id: str
    category: ValueCategory
    material_count: int = Field(gt=0)
    material_ids: tuple[str, ...] = ()
    risk_probability: float = Field(ge=0.0, le=1.0)
    rate_id: str
    computed_at: datetime
    source_references: tuple[str, ...] = ()

    @model_validator(mode="after")
    def _category(self) -> "LossEstimateEvidence":
        if self.material_ids and len(self.material_ids) != self.material_count:
            raise ValueError("material_ids length must equal material_count when provided")
        if len(self.material_ids) != len(set(self.material_ids)):
            raise ValueError("loss estimate material_ids must be unique")
        if self.category not in {
            ValueCategory.SCRAP_EXPOSURE_ESTIMATE,
            ValueCategory.REWORK_EXPOSURE_ESTIMATE,
        }:
            raise ValueError("loss estimate category must be SCRAP_EXPOSURE_ESTIMATE or REWORK_EXPOSURE_ESTIMATE")
        return self


class EpisodeValueLedgerView(BaseModel):
    model_config = ConfigDict(frozen=True)

    summary: EpisodeValueSummary
    entries: tuple[ValueLedgerEntry, ...]
    claim_groups: tuple[BenefitClaimGroup, ...] = ()
    attributions: tuple[BenefitAttribution, ...] = ()


class ObservedCostEvidence(BaseModel):
    model_config = ConfigDict(frozen=True)

    episode_id: str | None = None
    category: ValueCategory
    quantity: float = Field(gt=0.0)
    unit: str
    rate_id: str
    observed_at: datetime
    source_references: tuple[str, ...]

    @model_validator(mode="after")
    def _category(self) -> "ObservedCostEvidence":
        if self.category not in {
            ValueCategory.INVESTIGATION_COST,
            ValueCategory.FALSE_ACTIONABLE_EVENT_COST,
        }:
            raise ValueError("observed cost category must be INVESTIGATION_COST or FALSE_ACTIONABLE_EVENT_COST")
        if not self.source_references:
            raise ValueError("observed cost requires source references")
        return self


class OperationalBenefitEvidence(BaseModel):
    model_config = ConfigDict(frozen=True)

    episode_id: str
    claim_group_id: str | None = None
    category: ValueCategory
    quantity: float = Field(gt=0.0)
    unit: str
    observed_at: datetime
    source_references: tuple[str, ...]
    rate_id: str | None = None

    @model_validator(mode="after")
    def _category(self) -> "OperationalBenefitEvidence":
        if self.category not in {
            ValueCategory.DOWNTIME_AVOIDED,
            ValueCategory.CAPACITY_PROTECTED,
            ValueCategory.CYCLE_TIME_REDUCTION,
            ValueCategory.REMEASUREMENT_AVOIDED,
        }:
            raise ValueError("unsupported operational benefit category")
        if not self.source_references:
            raise ValueError("operational benefit evidence requires source references")
        return self


class MissedOpportunityEvidence(BaseModel):
    model_config = ConfigDict(frozen=True)

    material_count: int = Field(gt=0)
    material_ids: tuple[str, ...] = ()
    risk_probability: float = Field(ge=0.0, le=1.0)
    rate_id: str
    computed_at: datetime
    source_references: tuple[str, ...]
    episode_id: str | None = None
