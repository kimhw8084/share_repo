from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Mapping

from ephi.domain.capabilities import Capability


class QualificationState(StrEnum):
    QUALIFIED = "QUALIFIED"
    PROVISIONAL = "PROVISIONAL"
    PARTIAL = "PARTIAL"
    UNAVAILABLE = "UNAVAILABLE"
    FAILED = "FAILED"


class DatasetRole(StrEnum):
    ASSET = "ASSET"
    EXECUTION = "EXECUTION"
    SIGNAL = "SIGNAL"
    TRACE = "TRACE"
    METROLOGY = "METROLOGY"
    QUALITY = "QUALITY"
    MAINTENANCE = "MAINTENANCE"
    GENEALOGY = "GENEALOGY"
    WIP = "WIP"
    QUALIFICATION = "QUALIFICATION"
    HISTORICAL_CASE = "HISTORICAL_CASE"


@dataclass(frozen=True, slots=True)
class DatasetContract:
    logical_name: str
    role: DatasetRole
    required_columns: tuple[str, ...]
    optional_columns: tuple[str, ...] = ()
    identity_columns: tuple[str, ...] = ()
    event_time_column: str | None = None
    available_at_column: str | None = None
    revision_column: str | None = None

    def all_declared_columns(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys((*self.required_columns, *self.optional_columns)))


@dataclass(frozen=True, slots=True)
class DatasetProfile:
    logical_name: str
    row_count: int
    columns: tuple[str, ...]
    null_fraction: Mapping[str, float] = field(default_factory=dict)
    distinct_count: Mapping[str, int] = field(default_factory=dict)
    event_time_min: str | None = None
    event_time_max: str | None = None
    available_at_min: str | None = None
    available_at_max: str | None = None
    duplicate_key_fraction: float | None = None
    late_arrival_fraction: float | None = None
    correction_fraction: float | None = None
    availability_delay_p50_seconds: float | None = None
    availability_delay_p95_seconds: float | None = None
    availability_delay_p99_seconds: float | None = None
    bytes_scanned: int | None = None


@dataclass(frozen=True, slots=True)
class DatasetAudit:
    contract: DatasetContract
    profile: DatasetProfile | None
    state: QualificationState
    missing_required_columns: tuple[str, ...] = ()
    missing_optional_columns: tuple[str, ...] = ()
    reasons: tuple[str, ...] = ()

    @property
    def usable(self) -> bool:
        return self.state in {QualificationState.QUALIFIED, QualificationState.PROVISIONAL, QualificationState.PARTIAL}


@dataclass(frozen=True, slots=True)
class JoinContract:
    join_id: str
    left_dataset: str
    right_dataset: str
    left_keys: tuple[str, ...]
    right_keys: tuple[str, ...]
    required_for: tuple[Capability, ...] = ()


@dataclass(frozen=True, slots=True)
class JoinProfile:
    join_id: str
    left_rows: int
    matched_left_rows: int
    matched_right_rows: int | None = None
    ambiguous_left_rows: int = 0
    bytes_scanned: int | None = None

    @property
    def left_match_fraction(self) -> float:
        if self.left_rows <= 0:
            return 0.0
        return self.matched_left_rows / self.left_rows

    @property
    def ambiguity_fraction(self) -> float:
        if self.left_rows <= 0:
            return 0.0
        return self.ambiguous_left_rows / self.left_rows


@dataclass(frozen=True, slots=True)
class JoinAudit:
    contract: JoinContract
    profile: JoinProfile | None
    state: QualificationState
    reasons: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class CapabilityAssessment:
    capability: Capability
    state: QualificationState
    supporting_datasets: tuple[str, ...] = ()
    supporting_joins: tuple[str, ...] = ()
    reasons: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class DataRealityReport:
    datasets: tuple[DatasetAudit, ...]
    joins: tuple[JoinAudit, ...]
    capabilities: tuple[CapabilityAssessment, ...]
    generated_at: str
    config_hash: str | None = None

    def capability(self, capability: Capability) -> CapabilityAssessment | None:
        return next((item for item in self.capabilities if item.capability == capability), None)

    def to_dict(self) -> dict[str, object]:
        return {
            "generated_at": self.generated_at,
            "config_hash": self.config_hash,
            "datasets": [
                {
                    "logical_name": item.contract.logical_name,
                    "role": item.contract.role,
                    "state": item.state,
                    "rows": item.profile.row_count if item.profile else None,
                    "missing_required_columns": list(item.missing_required_columns),
                    "missing_optional_columns": list(item.missing_optional_columns),
                    "reasons": list(item.reasons),
                    "profile": None
                    if item.profile is None
                    else {
                        "columns": list(item.profile.columns),
                        "null_fraction": dict(item.profile.null_fraction),
                        "distinct_count": dict(item.profile.distinct_count),
                        "event_time_min": item.profile.event_time_min,
                        "event_time_max": item.profile.event_time_max,
                        "available_at_min": item.profile.available_at_min,
                        "available_at_max": item.profile.available_at_max,
                        "duplicate_key_fraction": item.profile.duplicate_key_fraction,
                        "late_arrival_fraction": item.profile.late_arrival_fraction,
                        "correction_fraction": item.profile.correction_fraction,
                        "availability_delay_p50_seconds": item.profile.availability_delay_p50_seconds,
                        "availability_delay_p95_seconds": item.profile.availability_delay_p95_seconds,
                        "availability_delay_p99_seconds": item.profile.availability_delay_p99_seconds,
                        "bytes_scanned": item.profile.bytes_scanned,
                    },
                }
                for item in self.datasets
            ],
            "joins": [
                {
                    "join_id": item.contract.join_id,
                    "state": item.state,
                    "left_dataset": item.contract.left_dataset,
                    "right_dataset": item.contract.right_dataset,
                    "left_match_fraction": item.profile.left_match_fraction if item.profile else None,
                    "ambiguity_fraction": item.profile.ambiguity_fraction if item.profile else None,
                    "reasons": list(item.reasons),
                }
                for item in self.joins
            ],
            "capabilities": [
                {
                    "capability": item.capability,
                    "state": item.state,
                    "supporting_datasets": list(item.supporting_datasets),
                    "supporting_joins": list(item.supporting_joins),
                    "reasons": list(item.reasons),
                }
                for item in self.capabilities
            ],
        }
