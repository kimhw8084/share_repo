from __future__ import annotations
from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, ConfigDict, Field
class OperationalPriority(StrEnum): P1="P1"; P2="P2"; P3="P3"; P4="P4"
class HarmfulnessBand(StrEnum): STRONG="STRONG"; SUPPORTED="SUPPORTED"; WEAK="WEAK"; NONE="NONE"; PENDING="PENDING"; CONTRADICTED="CONTRADICTED"
class OperationalPriorityAssessment(BaseModel):
    model_config=ConfigDict(frozen=True)
    episode_id:str; as_of:datetime; policy_version:str; overall_priority:OperationalPriority; containment_priority:OperationalPriority; disposition_priority:OperationalPriority; rca_priority:OperationalPriority; harmfulness:HarmfulnessBand; time_to_earliest_exposure_minutes:float|None=Field(default=None,ge=0); reasons:tuple[str,...]=()
