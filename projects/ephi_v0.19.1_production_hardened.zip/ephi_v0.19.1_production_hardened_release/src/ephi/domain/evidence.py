from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum


class EvidenceEffect(StrEnum):
    SUPPORTS = "SUPPORTS"
    CONTRADICTS = "CONTRADICTS"
    NEUTRAL = "NEUTRAL"
    UNAVAILABLE = "UNAVAILABLE"


class Hypothesis(StrEnum):
    LOCAL_ASSET_DEGRADATION = "LOCAL_ASSET_DEGRADATION"
    COMMON_MODE_PROCESS_CHANGE = "COMMON_MODE_PROCESS_CHANGE"
    METROLOGY_SYSTEM_SHIFT = "METROLOGY_SYSTEM_SHIFT"
    RECIPE_OR_PROCESS_REGIME_CHANGE = "RECIPE_OR_PROCESS_REGIME_CHANGE"
    UPSTREAM_ROUTE_CONFOUNDING = "UPSTREAM_ROUTE_CONFOUNDING"
    MAINTENANCE_TRANSITION = "MAINTENANCE_TRANSITION"
    DATA_PIPELINE_OR_SCHEMA_CHANGE = "DATA_PIPELINE_OR_SCHEMA_CHANGE"
    BENIGN_NOVELTY = "BENIGN_NOVELTY"
    INSUFFICIENT_INFORMATION = "INSUFFICIENT_INFORMATION"


class EvidenceChannel(StrEnum):
    SELF_HEALTH = "SELF_HEALTH"
    PEER_RELATIVE_HEALTH = "PEER_RELATIVE_HEALTH"
    FLEET_COMMON_MODE = "FLEET_COMMON_MODE"
    TEMPORAL_STATE = "TEMPORAL_STATE"
    DATA_PIPELINE_HEALTH = "DATA_PIPELINE_HEALTH"
    MEASUREMENT_SYSTEM_HEALTH = "MEASUREMENT_SYSTEM_HEALTH"
    CROSS_TOOL_MATCHING = "CROSS_TOOL_MATCHING"
    REPEATABILITY = "REPEATABILITY"
    SPATIAL_STABILITY = "SPATIAL_STABILITY"
    PRODUCTION_METROLOGY = "PRODUCTION_METROLOGY"
    QUALITY_HARMFULNESS = "QUALITY_HARMFULNESS"


@dataclass(frozen=True, slots=True)
class HypothesisEffect:
    hypothesis: Hypothesis
    effect: EvidenceEffect
    strength: float
    reason_code: str


@dataclass(frozen=True, slots=True)
class EvidenceItem:
    evidence_id: str
    asset_id: str
    execution_id: str
    event_time: datetime
    channel: EvidenceChannel
    evidence_type: str
    observation: str
    strength: float
    confidence: float
    dependency_group: str
    effects: tuple[HypothesisEffect, ...]
