from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum, StrEnum

from .context import ContextKey
from .evidence import EvidenceItem, Hypothesis


class HealthSeverity(IntEnum):
    UNKNOWN = 0
    NORMAL = 1
    OBSERVE = 2
    MONITOR = 3
    INVESTIGATE = 4
    URGENT = 5


class AssessmentMaturity(StrEnum):
    BEHAVIOR_ONLY = "BEHAVIOR_ONLY"
    EARLY_QUALITY_PENDING = "EARLY_QUALITY_PENDING"
    INLINE_QUALITY_AVAILABLE = "INLINE_QUALITY_AVAILABLE"
    MATURE_QUALITY_PARTIAL = "MATURE_QUALITY_PARTIAL"
    MATURE_QUALITY_AVAILABLE = "MATURE_QUALITY_AVAILABLE"
    INVESTIGATION_CONFIRMED = "INVESTIGATION_CONFIRMED"


@dataclass(frozen=True, slots=True)
class HypothesisSupport:
    hypothesis: Hypothesis
    support: float
    contradiction: float

    @property
    def net(self) -> float:
        return self.support - self.contradiction


@dataclass(frozen=True, slots=True)
class HealthAssessment:
    assessment_id: str
    execution_id: str
    asset_id: str
    context: ContextKey
    event_time: datetime
    severity: HealthSeverity
    confidence: float
    behavioral_novelty: float
    leading_hypothesis: Hypothesis
    hypothesis_support: tuple[HypothesisSupport, ...]
    evidence: tuple[EvidenceItem, ...]
    maturity: AssessmentMaturity = AssessmentMaturity.BEHAVIOR_ONLY
