from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ephi.domain.capabilities import Capability
from ephi.domain.operations import CertificationState, GateResult, QualificationPlane


class StrictFrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class LaunchEvidenceKind(StrEnum):
    DATA_REALITY = "DATA_REALITY"
    INTERNAL_GOLDEN_REPLAY = "INTERNAL_GOLDEN_REPLAY"
    PRODUCTION_REPLAY_SCALE = "PRODUCTION_REPLAY_SCALE"
    RELIABILITY_DR_DRILL = "RELIABILITY_DR_DRILL"
    SHADOW_RUNTIME = "SHADOW_RUNTIME"
    ENGINEER_SHADOW = "ENGINEER_SHADOW"


class EvidenceProvenance(StrEnum):
    PORTABLE_REFERENCE = "PORTABLE_REFERENCE"
    SIMULATED_INTERNAL = "SIMULATED_INTERNAL"
    INTERNAL_MEASURED = "INTERNAL_MEASURED"


class EvidenceDecision(StrEnum):
    PASS = "PASS"
    FAIL = "FAIL"
    INCONCLUSIVE = "INCONCLUSIVE"


class LaunchArtifactReference(StrictFrozenModel):
    artifact_id: str
    content_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    locator: str


class SourceSnapshotLineage(StrictFrozenModel):
    snapshot_id: str
    family_id: str
    release_id: str
    config_hash: str
    captured_at: datetime
    as_of: datetime
    parent_snapshot_id: str | None = None
    scope: str
    dataset_revisions: dict[str, str] = Field(default_factory=dict)
    notes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_snapshot_window(self) -> "SourceSnapshotLineage":
        if self.as_of > self.captured_at:
            raise ValueError("source snapshot as_of cannot be after captured_at")
        if self.parent_snapshot_id == self.snapshot_id:
            raise ValueError("source snapshot cannot parent itself")
        return self


class CampaignStage(StrEnum):
    DATA_REALITY = "DATA_REALITY"
    INTERNAL_GOLDEN_REPLAY = "INTERNAL_GOLDEN_REPLAY"
    PRODUCTION_REPLAY_SCALE = "PRODUCTION_REPLAY_SCALE"
    RELIABILITY_DR_DRILL = "RELIABILITY_DR_DRILL"
    SHADOW_RUNTIME = "SHADOW_RUNTIME"
    ENGINEER_SHADOW = "ENGINEER_SHADOW"


class LaunchEvidenceAdapterDescriptor(StrictFrozenModel):
    contract_version: str = "1"
    adapter_id: str
    adapter_version: str
    supported_stages: tuple[CampaignStage, ...]
    idempotent_stages: tuple[CampaignStage, ...]
    immutable_artifact_publishing: bool = True
    notes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_adapter(self) -> "LaunchEvidenceAdapterDescriptor":
        supported = set(self.supported_stages)
        if len(supported) != len(self.supported_stages):
            raise ValueError("supported_stages must be unique")
        if not set(self.idempotent_stages).issuperset(supported):
            raise ValueError("all supported campaign stages must be idempotent")
        return self


class LaunchCollectionContext(StrictFrozenModel):
    campaign_id: str
    family_id: str
    release_id: str
    config_hash: str
    stage: CampaignStage
    attempt: int = Field(ge=1)
    idempotency_key: str


class CampaignStageStatus(StrEnum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    PASSED = "PASSED"
    FAILED = "FAILED"


class CampaignStageAttempt(StrictFrozenModel):
    attempt_id: str
    campaign_id: str
    stage: CampaignStage
    attempt: int = Field(ge=1)
    idempotency_key: str
    status: CampaignStageStatus
    started_at: datetime
    completed_at: datetime | None = None
    evidence_ids: tuple[str, ...] = ()
    replay_ids: tuple[str, ...] = ()
    source_snapshot_ids: tuple[str, ...] = ()
    error: str | None = None


class CampaignExecutionRecord(StrictFrozenModel):
    campaign_id: str
    family_id: str
    release_id: str
    config_hash: str
    created_at: datetime
    updated_at: datetime
    target_state: CertificationState
    attempts: tuple[CampaignStageAttempt, ...] = ()

    def latest_attempt(self, stage: CampaignStage) -> CampaignStageAttempt | None:
        candidates = [item for item in self.attempts if item.stage == stage]
        return max(candidates, key=lambda item: item.attempt) if candidates else None

    def stage_passed(self, stage: CampaignStage) -> bool:
        latest = self.latest_attempt(stage)
        return latest is not None and latest.status == CampaignStageStatus.PASSED


class LaunchEvidenceReceipt(StrictFrozenModel):
    evidence_id: str
    family_id: str
    release_id: str
    config_hash: str
    kind: LaunchEvidenceKind
    provenance: EvidenceProvenance
    decision: EvidenceDecision
    artifact: str
    artifact_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    artifact_ref: LaunchArtifactReference | None = None
    observed_at: datetime
    valid_until: datetime | None = None
    validator: str | None = None
    source_snapshot_id: str | None = None
    metrics: dict[str, Any] = Field(default_factory=dict)
    limitations: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validity_range(self) -> "LaunchEvidenceReceipt":
        if self.valid_until is not None and self.valid_until <= self.observed_at:
            raise ValueError("valid_until must be after observed_at")
        if self.artifact_ref is not None:
            if self.artifact_ref.content_hash != self.artifact_sha256:
                raise ValueError("artifact_ref content_hash must match artifact_sha256")
            if self.artifact_ref.locator != self.artifact:
                raise ValueError("artifact_ref locator must match artifact")
        return self

    def valid_as_of(self, as_of: datetime) -> bool:
        return self.valid_until is None or as_of <= self.valid_until


class ReplayPartition(StrictFrozenModel):
    partition_id: str
    start_time: datetime
    end_time: datetime
    scope: str
    estimated_rows: int | None = Field(default=None, ge=0)

    @model_validator(mode="after")
    def valid_window(self) -> "ReplayPartition":
        if self.end_time <= self.start_time:
            raise ValueError("replay partition end_time must be after start_time")
        return self


class ProductionReplayManifest(StrictFrozenModel):
    manifest_version: str = "1"
    replay_id: str
    family_id: str
    release_id: str
    config_hash: str
    replay_as_of: datetime
    strict_available_at: bool = True
    source_snapshot_id: str | None = None
    partitions: tuple[ReplayPartition, ...]
    expected_total_rows: int | None = Field(default=None, ge=0)
    notes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def strict_knowledge_time(self) -> "ProductionReplayManifest":
        if not self.strict_available_at:
            raise ValueError("production qualification replay must enforce available_at <= replay_as_of")
        ids = [item.partition_id for item in self.partitions]
        if len(ids) != len(set(ids)):
            raise ValueError("replay partition_id values must be unique")
        return self


class CapabilityLaunchAssessment(StrictFrozenModel):
    capability: Capability
    required: bool
    state: str
    reasons: tuple[str, ...] = ()


class InternalGoldenReplayManifest(StrictFrozenModel):
    manifest_version: str = "1"
    family_id: str
    release_id: str
    config_hash: str
    corpus_id: str
    corpus_version: str
    corpus_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_snapshot_id: str
    accepted_case_ids: tuple[str, ...]
    case_type_counts: dict[str, int]
    confidence_counts: dict[str, int]
    replay_as_of: datetime
    strict_available_at: bool = True

    @model_validator(mode="after")
    def validate_internal_manifest(self) -> "InternalGoldenReplayManifest":
        if not self.accepted_case_ids:
            raise ValueError("internal Golden replay manifest requires accepted cases")
        if not self.strict_available_at:
            raise ValueError("internal Golden replay must enforce strict available_at knowledge time")
        return self


class ProductionScaleMeasurement(StrictFrozenModel):
    measurement_version: str = "1"
    family_id: str
    release_id: str
    config_hash: str
    source_snapshot_id: str
    observed_at: datetime
    rows_processed: int = Field(ge=0)
    elapsed_seconds: float = Field(gt=0)
    peak_memory_bytes: int | None = Field(default=None, ge=0)
    source_bytes_read: int | None = Field(default=None, ge=0)
    correction_replay_seconds: float | None = Field(default=None, ge=0)
    restart_recovery_seconds: float | None = Field(default=None, ge=0)
    measured_environment: str
    passed_internal_slo: bool
    limitations: tuple[str, ...] = ()

    @property
    def rows_per_second(self) -> float:
        return self.rows_processed / self.elapsed_seconds


class ReliabilityDrillMeasurement(StrictFrozenModel):
    measurement_version: str = "1"
    family_id: str
    release_id: str
    config_hash: str
    backup_id: str
    observed_at: datetime
    observed_rpo_seconds: float = Field(ge=0)
    observed_rto_seconds: float = Field(ge=0)
    target_rpo_seconds: float = Field(gt=0)
    target_rto_seconds: float = Field(gt=0)
    authoritative_restore_exact: bool
    rebuildable_state_recovered: bool
    rollback_or_migration_drill_passed: bool
    passed_internal_dr_policy: bool
    limitations: tuple[str, ...] = ()


class ShadowRuntimeMeasurement(StrictFrozenModel):
    measurement_version: str = "1"
    family_id: str
    release_id: str
    config_hash: str
    observed_at: datetime
    observation_hours: float = Field(gt=0)
    scored_executions: int = Field(ge=0)
    generated_episodes: int = Field(ge=0)
    freshness_block_minutes: float = Field(default=0, ge=0)
    source_unavailable_minutes: float = Field(default=0, ge=0)
    notifications_suppressed: bool = True
    passed_internal_shadow_slo: bool
    limitations: tuple[str, ...] = ()


class LaunchRequirement(StrictFrozenModel):
    kind: LaunchEvidenceKind
    plane: QualificationPlane | None = None
    required_for: tuple[CertificationState, ...]
    require_internal_measured: bool = True
    description: str


class MetrologyShadowLaunchPolicy(StrictFrozenModel):
    policy_version: str = "1"
    family_id: str
    required_capabilities: tuple[Capability, ...]
    optional_capabilities: tuple[Capability, ...] = ()
    requirements: tuple[LaunchRequirement, ...]


class RequirementStatus(StrEnum):
    SATISFIED = "SATISFIED"
    BLOCKED = "BLOCKED"
    FAILED = "FAILED"
    EXPIRED = "EXPIRED"


class LaunchRequirementAssessment(StrictFrozenModel):
    kind: LaunchEvidenceKind
    status: RequirementStatus
    evidence_id: str | None = None
    blocker: str | None = None


class MetrologyShadowLaunchPlan(StrictFrozenModel):
    plan_version: str = "1"
    family_id: str
    release_id: str
    config_hash: str
    current_state: CertificationState
    target_state: CertificationState
    generated_at: datetime
    required_capabilities: tuple[Capability, ...]
    optional_capabilities: tuple[Capability, ...]
    capability_assessments: tuple[CapabilityLaunchAssessment, ...] = ()
    requirements: tuple[LaunchRequirement, ...]
    assessments: tuple[LaunchRequirementAssessment, ...]
    gate_results: tuple[GateResult, ...] = ()
    blockers: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()

    @property
    def ready(self) -> bool:
        return not self.blockers and all(item.status == RequirementStatus.SATISFIED for item in self.assessments)


class ShadowLaunchDossier(StrictFrozenModel):
    dossier_version: str = "2"
    family_id: str
    release_id: str
    config_hash: str
    current_state: CertificationState
    target_state: CertificationState
    generated_at: datetime
    plan: MetrologyShadowLaunchPlan
    evidence: tuple[LaunchEvidenceReceipt, ...]
    replay_manifests: tuple[ProductionReplayManifest, ...] = ()
    source_snapshots: tuple[SourceSnapshotLineage, ...] = ()
    campaign_id: str | None = None
    gate_results: tuple[GateResult, ...] = ()
    blockers: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()
    promotion_ready: bool = False


class LaunchAuditEvent(StrictFrozenModel):
    event_id: str
    family_id: str
    action: str
    actor: str
    at: datetime
    entity_id: str
    detail: str | None = None


class ShadowLaunchWorkspace(StrictFrozenModel):
    workspace_version: str = "2"
    family_id: str
    release_id: str | None = None
    config_hash: str | None = None
    evidence: tuple[LaunchEvidenceReceipt, ...] = ()
    replay_manifests: tuple[ProductionReplayManifest, ...] = ()
    source_snapshots: tuple[SourceSnapshotLineage, ...] = ()
    campaigns: tuple[CampaignExecutionRecord, ...] = ()
    audit: tuple[LaunchAuditEvent, ...] = ()
    updated_at: datetime | None = None
