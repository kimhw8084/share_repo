from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Provenance:
    source_domain: str
    source_dataset: str
    source_key: str
    adapter_version: str
    source_revision: str | None = None
