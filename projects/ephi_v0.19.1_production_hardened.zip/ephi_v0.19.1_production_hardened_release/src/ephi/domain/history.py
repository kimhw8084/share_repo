from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from math import sqrt
from pydantic import BaseModel, ConfigDict, Field, model_validator

from .evidence import Hypothesis


class HistoricalCaseCuration(StrEnum):
    UNREVIEWED = "UNREVIEWED"
    PARTIALLY_STRUCTURED = "PARTIALLY_STRUCTURED"
    ENGINEER_REVIEWED = "ENGINEER_REVIEWED"
    ROOT_CAUSE_CONFIRMED = "ROOT_CAUSE_CONFIRMED"
    ROOT_CAUSE_DISPUTED = "ROOT_CAUSE_DISPUTED"
    INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"


class HistoricalActionResult(StrEnum):
    UNKNOWN = "UNKNOWN"
    NO_CHANGE = "NO_CHANGE"
    PARTIAL_IMPROVEMENT = "PARTIAL_IMPROVEMENT"
    RESOLVED = "RESOLVED"
    WORSENED = "WORSENED"


class FingerprintDomain(StrEnum):
    CONTEXT = "CONTEXT"
    BEHAVIOR = "BEHAVIOR"
    TEMPORAL = "TEMPORAL"
    MEASUREMENT_SYSTEM = "MEASUREMENT_SYSTEM"
    QUALITY = "QUALITY"
    SPATIAL = "SPATIAL"
    MAINTENANCE = "MAINTENANCE"
    ROUTE = "ROUTE"


class FingerprintComponent(BaseModel):
    model_config = ConfigDict(frozen=True)
    domain: FingerprintDomain
    values: tuple[float, ...] = ()
    labels: tuple[str, ...] = ()
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)

    @model_validator(mode="after")
    def _shape(self):
        if self.labels and len(self.labels) != len(self.values):
            raise ValueError("fingerprint labels must match values")
        return self


class EpisodeFingerprint(BaseModel):
    model_config = ConfigDict(frozen=True)
    fingerprint_id: str
    episode_id: str
    asset_id: str
    equipment_family: str
    operation: str
    recipe_id: str
    product_id: str
    technology: str
    created_at: datetime
    version: str = "fingerprint-v1"
    components: tuple[FingerprintComponent, ...]

    def component(self, domain: FingerprintDomain) -> FingerprintComponent | None:
        return next((x for x in self.components if x.domain is domain), None)


class SimilarityDomainResult(BaseModel):
    model_config = ConfigDict(frozen=True)
    domain: FingerprintDomain
    similarity: float = Field(ge=0.0, le=1.0)
    weight: float = Field(ge=0.0)
    confidence: float = Field(ge=0.0, le=1.0)
    shared: bool = True


class SimilarityResult(BaseModel):
    model_config = ConfigDict(frozen=True)
    case_id: str
    fingerprint_id: str
    similarity: float = Field(ge=0.0, le=1.0)
    similarity_confidence: float = Field(ge=0.0, le=1.0)
    case_confidence: float = Field(ge=0.0, le=1.0)
    domain_results: tuple[SimilarityDomainResult, ...]
    shared_context: tuple[str, ...] = ()
    important_differences: tuple[str, ...] = ()


class HistoricalAction(BaseModel):
    model_config = ConfigDict(frozen=True)
    action_type: str
    at: datetime | None = None
    target: str | None = None
    rationale: str | None = None
    result: HistoricalActionResult = HistoricalActionResult.UNKNOWN


class HistoricalCase(BaseModel):
    model_config = ConfigDict(frozen=True)
    case_id: str
    source_episode_id: str | None = None
    asset_id: str
    equipment_family: str
    opened_at: datetime
    available_at: datetime
    fingerprint: EpisodeFingerprint
    curation: HistoricalCaseCuration = HistoricalCaseCuration.UNREVIEWED
    root_cause_category: str | None = None
    root_cause_confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    resolution_summary: str | None = None
    actions: tuple[HistoricalAction, ...] = ()
    leading_hypothesis: Hypothesis | None = None
    benign: bool = False
    data_completeness: float = Field(default=1.0, ge=0.0, le=1.0)
    tags: tuple[str, ...] = ()

    @property
    def case_confidence(self) -> float:
        curation_factor = {
            HistoricalCaseCuration.UNREVIEWED: 0.25,
            HistoricalCaseCuration.PARTIALLY_STRUCTURED: 0.45,
            HistoricalCaseCuration.ENGINEER_REVIEWED: 0.7,
            HistoricalCaseCuration.ROOT_CAUSE_CONFIRMED: 1.0,
            HistoricalCaseCuration.ROOT_CAUSE_DISPUTED: 0.35,
            HistoricalCaseCuration.INSUFFICIENT_EVIDENCE: 0.2,
        }[self.curation]
        root = self.root_cause_confidence if self.root_cause_category else 0.5
        return max(0.0, min(1.0, 0.45 * curation_factor + 0.35 * root + 0.20 * self.data_completeness))


class HistoricalAnalogue(BaseModel):
    model_config = ConfigDict(frozen=True)
    case_id: str
    similarity: float = Field(ge=0.0, le=1.0)
    similarity_confidence: float = Field(ge=0.0, le=1.0)
    case_confidence: float = Field(ge=0.0, le=1.0)
    domain_results: tuple[SimilarityDomainResult, ...]
    shared_context: tuple[str, ...] = ()
    important_differences: tuple[str, ...] = ()
    curation: HistoricalCaseCuration
    root_cause_category: str | None = None
    root_cause_confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    resolution_summary: str | None = None
    actions: tuple[HistoricalAction, ...] = ()
    benign: bool = False

