from __future__ import annotations

import hashlib
import json
from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .evidence import Hypothesis


class BenchmarkFamily(StrEnum):
    BEHAVIORAL = "BEHAVIORAL"
    METROLOGY = "METROLOGY"


class BenchmarkCaseType(StrEnum):
    HEALTHY = "HEALTHY"
    LOCAL_ASSET_EXCURSION = "LOCAL_ASSET_EXCURSION"
    COMMON_MODE_PROCESS_CHANGE = "COMMON_MODE_PROCESS_CHANGE"
    METROLOGY_SYSTEM_SHIFT = "METROLOGY_SYSTEM_SHIFT"
    DATA_PIPELINE_CHANGE = "DATA_PIPELINE_CHANGE"
    BENIGN_NOVELTY = "BENIGN_NOVELTY"
    MAINTENANCE_TRANSITION = "MAINTENANCE_TRANSITION"
    UPSTREAM_ROUTE_CONFOUNDING = "UPSTREAM_ROUTE_CONFOUNDING"
    AMBIGUOUS = "AMBIGUOUS"


class BenchmarkLabelConfidence(StrEnum):
    CONFIRMED = "CONFIRMED"
    HIGH_CONFIDENCE = "HIGH_CONFIDENCE"
    MODERATE_CONFIDENCE = "MODERATE_CONFIDENCE"
    AMBIGUOUS = "AMBIGUOUS"


class BenchmarkSourceKind(StrEnum):
    SYNTHETIC_SCALAR = "SYNTHETIC_SCALAR"
    SYNTHETIC_METROLOGY = "SYNTHETIC_METROLOGY"
    INTERNAL_HISTORY = "INTERNAL_HISTORY"


class BenchmarkCase(BaseModel):
    """Versioned case truth used by replay qualification.

    The case stores *labels and replay scope*, never future analytical outputs. For
    internal history, source_locator can reference an approved case/materialization.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    case_id: str
    family: BenchmarkFamily
    case_type: BenchmarkCaseType
    source_kind: BenchmarkSourceKind
    scenario: str | None = None
    generator_config: dict[str, Any] = Field(default_factory=dict)
    source_locator: str | None = None

    label_confidence: BenchmarkLabelConfidence = BenchmarkLabelConfidence.CONFIRMED
    expected_hypothesis: Hypothesis | None = None
    expected_local_actionable: bool = False
    expected_fleet_actionable: bool = False
    expected_asset_ids: tuple[str, ...] = ()

    onset_event_time: datetime | None = None
    onset_low: datetime | None = None
    onset_high: datetime | None = None
    external_detection_time: datetime | None = None
    scope_start: datetime | None = None
    scope_end: datetime | None = None
    asset_count: int = 1
    quality_impact: str | None = None
    root_cause_label: str | None = None
    resolution_label: str | None = None
    actions: tuple[str, ...] = ()
    evaluation_exclusions: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()
    notes: str | None = None

    @model_validator(mode="after")
    def _validate_case(self) -> "BenchmarkCase":
        if self.asset_count < 1:
            raise ValueError("asset_count must be positive")
        if self.scope_start and self.scope_end and self.scope_end < self.scope_start:
            raise ValueError("scope_end cannot precede scope_start")
        if self.onset_low and self.onset_event_time and self.onset_event_time < self.onset_low:
            raise ValueError("onset_event_time cannot precede onset_low")
        if self.onset_high and self.onset_event_time and self.onset_event_time > self.onset_high:
            raise ValueError("onset_event_time cannot exceed onset_high")
        if self.onset_low and self.onset_high and self.onset_high < self.onset_low:
            raise ValueError("onset_high cannot precede onset_low")
        if self.external_detection_time and self.onset_event_time:
            if self.external_detection_time < self.onset_event_time:
                raise ValueError("external_detection_time cannot precede onset_event_time")
        if self.expected_local_actionable and not self.expected_asset_ids:
            raise ValueError("local-actionable cases require expected_asset_ids")
        if self.source_kind != BenchmarkSourceKind.INTERNAL_HISTORY and not self.scenario:
            raise ValueError("synthetic benchmark cases require a scenario")
        return self


class BenchmarkCorpus(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    corpus_id: str
    version: str
    created_at: datetime
    description: str
    cases: tuple[BenchmarkCase, ...]

    @model_validator(mode="after")
    def _unique_ids(self) -> "BenchmarkCorpus":
        case_ids = [case.case_id for case in self.cases]
        if len(case_ids) != len(set(case_ids)):
            raise ValueError("benchmark case IDs must be unique")
        return self

    def stable_hash(self) -> str:
        payload = self.model_dump(mode="json")
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()
