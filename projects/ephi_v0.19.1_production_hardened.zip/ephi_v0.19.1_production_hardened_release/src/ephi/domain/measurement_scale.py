from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from math import isfinite
from typing import Iterable

import numpy as np

from ephi.domain.data_reality import QualificationState


class ScaleEvidenceSource(StrEnum):
    CONFIGURED_RESOLUTION = "CONFIGURED_RESOLUTION"
    CONFIGURED_UNCERTAINTY = "CONFIGURED_UNCERTAINTY"
    OBSERVED_QUANTIZATION = "OBSERVED_QUANTIZATION"
    HEALTHY_DISPERSION = "HEALTHY_DISPERSION"


@dataclass(frozen=True, slots=True)
class MeasurementScalePolicy:
    characteristic_id: str
    robust_scale_floor: float
    practical_effect_floor: float
    state: QualificationState
    sources: tuple[ScaleEvidenceSource, ...]
    observed_quantization: float | None = None
    healthy_mad: float | None = None
    configured_resolution: float | None = None
    configured_uncertainty: float | None = None


def robust_mad(values: Iterable[float]) -> float | None:
    array = np.asarray(list(values), dtype=np.float64)
    array = array[np.isfinite(array)]
    if array.size < 3:
        return None
    center = float(np.median(array))
    return 1.4826 * float(np.median(np.abs(array - center)))


def observed_quantization_step(values: Iterable[float]) -> float | None:
    """Return a conservative observed quantization candidate, not instrument truth.

    The estimate uses the median of the lower quartile of positive unique-value
    increments. It is deliberately labelled PROVISIONAL unless corroborated by a
    configured instrument resolution or uncertainty.
    """

    array = np.asarray(list(values), dtype=np.float64)
    array = np.unique(array[np.isfinite(array)])
    if array.size < 5:
        return None
    diffs = np.diff(np.sort(array))
    diffs = diffs[diffs > 0]
    if diffs.size < 3:
        return None
    cutoff = float(np.quantile(diffs, 0.25))
    lower = diffs[diffs <= cutoff]
    candidate = float(np.median(lower if lower.size else diffs))
    return candidate if isfinite(candidate) and candidate > 0 else None


def derive_measurement_scale_policy(
    characteristic_id: str,
    healthy_values: Iterable[float],
    *,
    configured_resolution: float | None = None,
    configured_uncertainty: float | None = None,
    minimum_absolute_floor: float = 1e-12,
) -> MeasurementScalePolicy:
    values = list(healthy_values)
    healthy_scale = robust_mad(values)
    quantization = observed_quantization_step(values)

    configured = [
        value
        for value in (configured_resolution, configured_uncertainty)
        if value is not None and isfinite(value) and value > 0
    ]
    observed = [
        value
        for value in (healthy_scale, quantization)
        if value is not None and isfinite(value) and value > 0
    ]

    scale_floor = max([minimum_absolute_floor, *configured, *(observed[:1])])
    practical_floor = max([minimum_absolute_floor, *configured, *([quantization] if quantization else [])])

    sources: list[ScaleEvidenceSource] = []
    if configured_resolution is not None and configured_resolution > 0:
        sources.append(ScaleEvidenceSource.CONFIGURED_RESOLUTION)
    if configured_uncertainty is not None and configured_uncertainty > 0:
        sources.append(ScaleEvidenceSource.CONFIGURED_UNCERTAINTY)
    if quantization is not None:
        sources.append(ScaleEvidenceSource.OBSERVED_QUANTIZATION)
    if healthy_scale is not None:
        sources.append(ScaleEvidenceSource.HEALTHY_DISPERSION)

    if configured:
        state = QualificationState.QUALIFIED
    elif observed:
        state = QualificationState.PROVISIONAL
    else:
        state = QualificationState.UNAVAILABLE

    return MeasurementScalePolicy(
        characteristic_id=characteristic_id,
        robust_scale_floor=scale_floor,
        practical_effect_floor=practical_floor,
        state=state,
        sources=tuple(sources),
        observed_quantization=quantization,
        healthy_mad=healthy_scale,
        configured_resolution=configured_resolution,
        configured_uncertainty=configured_uncertainty,
    )
