from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from .context import ContextKey


@dataclass(frozen=True, slots=True)
class DetectorResult:
    execution_id: str
    asset_id: str
    context: ContextKey
    feature_id: str
    event_time: datetime
    physical_value: float
    self_z: float
    anchor_z: float
    peer_change_z: float | None
    peer_ewma: float | None
    peer_persistence_count: int
    fleet_shift_z: float | None
    ewma_fast: float
    ewma_slow: float
    cusum_pos: float
    cusum_neg: float
    persistence_count: int
    reference_confidence: float
    peer_confidence: float
    data_pipeline_suspect: bool = False
