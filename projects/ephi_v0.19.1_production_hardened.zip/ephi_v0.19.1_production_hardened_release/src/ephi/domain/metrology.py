from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from .context import ContextKey


@dataclass(frozen=True, slots=True)
class MetrologyObservation:
    """Site-level metrology observation preserving measurement-system semantics."""

    measurement_id: str
    material_id: str
    asset_id: str
    process_unit_id: str | None
    context: ContextKey
    characteristic_id: str
    value: float
    event_time: datetime
    available_at: datetime
    site_x: float | None = None
    site_y: float | None = None
    is_reference_material: bool = False
    remeasure_group_id: str | None = None
    attempt_index: int = 0
    valid: bool = True

    def __post_init__(self) -> None:
        if self.available_at < self.event_time:
            raise ValueError("available_at cannot precede event_time")
        if self.attempt_index < 0:
            raise ValueError("attempt_index must be non-negative")

    @property
    def subject_id(self) -> str:
        if self.process_unit_id:
            return f"{self.asset_id}/{self.process_unit_id}"
        return self.asset_id


@dataclass(frozen=True, slots=True)
class MetrologyMeasurementSummary:
    measurement_id: str
    material_id: str
    asset_id: str
    process_unit_id: str | None
    context: ContextKey
    characteristic_id: str
    event_time: datetime
    available_at: datetime
    mean: float
    median: float
    mad: float
    site_count: int
    center_edge: float | None
    radial_slope: float | None
    x_slope: float | None
    y_slope: float | None
    spatial_confidence: float
    is_reference_material: bool
    remeasure_group_id: str | None
    attempt_index: int

    @property
    def subject_id(self) -> str:
        if self.process_unit_id:
            return f"{self.asset_id}/{self.process_unit_id}"
        return self.asset_id


@dataclass(frozen=True, slots=True)
class MeasurementSystemResult:
    measurement_id: str
    subject_id: str
    context: ContextKey
    characteristic_id: str
    event_time: datetime
    production_z: float | None
    production_anchor_z: float | None
    production_fleet_shift_z: float | None
    production_peer_residual_z: float | None
    reference_z: float | None
    cross_tool_z: float | None
    repeatability_z: float | None
    repeatability_peer_z: float | None
    repeatability_distribution_z: float | None
    spatial_z: float | None
    spatial_peer_z: float | None
    reference_persistence: int
    cross_tool_persistence: int
    repeatability_persistence: int
    repeatability_peer_persistence: int
    spatial_persistence: int
    spatial_peer_persistence: int
    reference_ewma: float | None
    cross_tool_ewma: float | None
    repeatability_ewma: float | None
    repeatability_peer_ewma: float | None
    spatial_ewma: float | None
    spatial_peer_ewma: float | None
    is_reference_material: bool
    reference_confidence: float
    matching_confidence: float
    repeatability_confidence: float
    spatial_confidence: float
