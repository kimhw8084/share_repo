from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field

from ephi.domain.onboarding import (
    FamilyOnboardingPlan,
    GoldenCaseIntake,
    PromotionEvidencePackage,
    ShadowReviewCandidate,
    ShadowReviewQueueItem,
)
from ephi.domain.operations import EngineerShadowReview, FamilyQualificationManifest, GateResult


class StrictFrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class QualificationAction(StrEnum):
    PLAN_REGISTERED = "PLAN_REGISTERED"
    GOLDEN_SUBMITTED = "GOLDEN_SUBMITTED"
    GOLDEN_REVIEWED = "GOLDEN_REVIEWED"
    SHADOW_ENQUEUED = "SHADOW_ENQUEUED"
    SHADOW_CLAIMED = "SHADOW_CLAIMED"
    SHADOW_REVIEWED = "SHADOW_REVIEWED"
    GATE_RECORDED = "GATE_RECORDED"
    PROMOTION_GENERATED = "PROMOTION_GENERATED"
    PROMOTION_APPROVED = "PROMOTION_APPROVED"


class QualificationAuditEvent(StrictFrozenModel):
    event_id: str
    family_id: str
    action: QualificationAction
    actor: str
    occurred_at: datetime
    entity_type: str
    entity_id: str
    command_id: str
    detail: str | None = None


class QualificationCommandReceipt(StrictFrozenModel):
    command_id: str
    action: QualificationAction
    actor: str
    occurred_at: datetime
    result_id: str


class QualificationGateRecord(StrictFrozenModel):
    record_id: str
    family_id: str
    release_id: str
    capability_id: str
    result: GateResult
    recorded_by: str
    recorded_at: datetime


class PromotionEvidenceRecord(StrictFrozenModel):
    package_id: str
    package: PromotionEvidencePackage
    generated_by: str
    generated_at: datetime


class FamilyQualificationWorkspace(StrictFrozenModel):
    schema_version: str = "1"
    family_id: str
    onboarding_plan: FamilyOnboardingPlan | None = None
    golden_history: tuple[GoldenCaseIntake, ...] = ()
    shadow_candidates: tuple[ShadowReviewCandidate, ...] = ()
    shadow_queue: tuple[ShadowReviewQueueItem, ...] = ()
    shadow_reviews: tuple[EngineerShadowReview, ...] = ()
    gate_records: tuple[QualificationGateRecord, ...] = ()
    promotion_records: tuple[PromotionEvidenceRecord, ...] = ()
    family_manifests: tuple[FamilyQualificationManifest, ...] = ()
    audit_events: tuple[QualificationAuditEvent, ...] = ()
    command_receipts: tuple[QualificationCommandReceipt, ...] = ()
    updated_at: datetime | None = None


class QualificationWorkspaceSummary(StrictFrozenModel):
    family_id: str
    release_id: str | None = None
    current_state: str
    onboarding_ready: bool
    golden_intakes: int = Field(ge=0)
    accepted_golden_cases: int = Field(ge=0)
    shadow_candidates: int = Field(ge=0)
    pending_shadow_reviews: int = Field(ge=0)
    completed_shadow_reviews: int = Field(ge=0)
    gate_records: int = Field(ge=0)
    promotion_packages: int = Field(ge=0)
    qualification_manifests: int = Field(ge=0)
    blockers: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()


class QualificationWorkspaceExport(StrictFrozenModel):
    export_version: str = "1"
    generated_at: datetime
    summary: QualificationWorkspaceSummary
    onboarding_plan: FamilyOnboardingPlan | None = None
    golden_history: tuple[GoldenCaseIntake, ...] = ()
    shadow_queue: tuple[ShadowReviewQueueItem, ...] = ()
    shadow_reviews: tuple[EngineerShadowReview, ...] = ()
    gate_records: tuple[QualificationGateRecord, ...] = ()
    promotion_records: tuple[PromotionEvidenceRecord, ...] = ()
    family_manifests: tuple[FamilyQualificationManifest, ...] = ()
    audit_events: tuple[QualificationAuditEvent, ...] = ()
