from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from .context import ContextKey


@dataclass(frozen=True, slots=True)
class ScalarFeatureObservation:
    execution_id: str
    asset_id: str
    context: ContextKey
    feature_id: str
    value: float
    event_time: datetime
    available_at: datetime
    valid: bool = True

    def __post_init__(self) -> None:
        if self.available_at < self.event_time:
            raise ValueError("available_at cannot precede event_time")
