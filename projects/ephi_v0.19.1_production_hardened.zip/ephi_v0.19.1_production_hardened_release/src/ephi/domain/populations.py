from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ReferenceSnapshot:
    median: float
    mad: float
    n: int
    anchor_median: float
    anchor_mad: float
    anchor_n: int
    adequate: bool
    confidence: float


@dataclass(frozen=True, slots=True)
class PeerSnapshot:
    peer_asset_ids: tuple[str, ...]
    peer_center_change: float
    peer_change_mad: float
    fleet_shift_z: float
    peer_count: int
    adequate: bool
    confidence: float


@dataclass(frozen=True, slots=True)
class MaterializedReferenceState:
    asset_id: str
    context_key: str
    feature_id: str
    median: float
    mad: float
    n: int
    anchor_median: float
    anchor_mad: float
    anchor_n: int
    adequate: bool
    confidence: float
    scale_floor: float = 1e-9
    practical_effect_floor: float = 0.0

    @property
    def key(self) -> tuple[str, str, str]:
        return self.asset_id, self.context_key, self.feature_id
