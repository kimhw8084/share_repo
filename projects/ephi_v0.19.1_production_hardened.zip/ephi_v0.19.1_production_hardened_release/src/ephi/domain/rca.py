from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, ConfigDict, Field

from .evidence import Hypothesis


class AffectedMembership(StrEnum):
    DEFINITE = "DEFINITE"
    PROBABLE = "PROBABLE"
    POSSIBLE = "POSSIBLE"


class CandidateConfidence(StrEnum):
    HIGH = "HIGH"
    MODERATE = "MODERATE"
    WEAK = "WEAK"
    INSUFFICIENT = "INSUFFICIENT"
    CONTRADICTED = "CONTRADICTED"


class TemporalPlausibility(StrEnum):
    SUPPORTS = "SUPPORTS"
    UNCERTAIN = "UNCERTAIN"
    CONTRADICTS = "CONTRADICTS"


class RouteToken(BaseModel):
    model_config = ConfigDict(frozen=True)
    material_id: str
    sequence: int = Field(ge=0)
    operation: str
    asset_id: str
    event_time: datetime
    recipe_id: str | None = None
    asset_epoch: str | None = None
    process_regime: str | None = None
    health_episode_id: str | None = None
    health_strength: float = Field(default=0.0, ge=0.0)

    @property
    def factor_keys(self) -> tuple[str, ...]:
        keys = [
            f"ASSET:{self.asset_id}",
            f"OPERATION:{self.operation}",
            f"ASSET_OPERATION:{self.asset_id}|{self.operation}",
        ]
        if self.recipe_id:
            keys.extend((f"RECIPE:{self.recipe_id}", f"ASSET_RECIPE:{self.asset_id}|{self.recipe_id}"))
        if self.asset_epoch:
            keys.append(f"ASSET_EPOCH:{self.asset_epoch}")
        if self.process_regime:
            keys.append(f"PROCESS_REGIME:{self.process_regime}")
        if self.health_episode_id:
            keys.append(f"HEALTH_EPISODE:{self.health_episode_id}")
        return tuple(keys)


class AffectedMaterial(BaseModel):
    model_config = ConfigDict(frozen=True)
    material_id: str
    membership: AffectedMembership
    severity_weight: float = Field(default=1.0, ge=0.0)
    outcome_time: datetime | None = None


class ControlPopulation(BaseModel):
    model_config = ConfigDict(frozen=True)
    control_set_id: str
    material_ids: tuple[str, ...]
    policy: str
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)


class InvestigationSeed(BaseModel):
    model_config = ConfigDict(frozen=True)
    seed_id: str
    episode_id: str
    asset_id: str
    context: dict[str, str]
    onset_low: datetime
    onset_best: datetime
    onset_high: datetime
    affected_material_ids: tuple[str, ...]
    control_set_ids: tuple[str, ...]
    leading_hypotheses: tuple[Hypothesis, ...]
    top_historical_case_ids: tuple[str, ...] = ()
    lookback_operations: int = Field(default=5, ge=1)
    version: str = "investigation-seed-v1"


class CommonalityEvidence(BaseModel):
    model_config = ConfigDict(frozen=True)
    factor: str
    affected_count: int = Field(ge=0)
    affected_total: int = Field(ge=0)
    control_count: int = Field(ge=0)
    control_total: int = Field(ge=0)
    affected_prevalence: float = Field(ge=0.0, le=1.0)
    control_prevalence: float = Field(ge=0.0, le=1.0)
    prevalence_difference: float
    relative_risk: float = Field(ge=0.0)
    odds_ratio: float = Field(ge=0.0)
    severity_association: float = 0.0
    temporal_plausibility: TemporalPlausibility = TemporalPlausibility.UNCERTAIN
    temporal_support: float = Field(default=0.0, ge=0.0, le=1.0)
    health_support: float = Field(default=0.0, ge=0.0)
    control_robustness: float = Field(default=1.0, ge=0.0, le=1.0)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)


class RCACandidate(BaseModel):
    model_config = ConfigDict(frozen=True)
    candidate_id: str
    factor: str
    rank: int = Field(ge=1)
    enrichment: CommonalityEvidence
    historical_support: float = Field(default=0.0, ge=0.0, le=1.0)
    contradiction_reasons: tuple[str, ...] = ()
    evidence_score: float = Field(ge=0.0)
    confidence_band: CandidateConfidence
    recommended_check: str
