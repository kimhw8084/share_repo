from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictFrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class CertificationState(StrEnum):
    RESEARCH = "RESEARCH"
    OFFLINE_QUALIFIED = "OFFLINE_QUALIFIED"
    SHADOW = "SHADOW"
    SHADOW_QUALIFIED = "SHADOW_QUALIFIED"
    ADVISORY_PILOT = "ADVISORY_PILOT"
    PRODUCTION_ADVISORY = "PRODUCTION_ADVISORY"
    DEPRECATED = "DEPRECATED"


class QualificationPlane(StrEnum):
    DATA_REALITY = "DATA_REALITY"
    BEHAVIORAL_METROLOGY = "BEHAVIORAL_METROLOGY"
    QUALITY_HARMFULNESS = "QUALITY_HARMFULNESS"
    EXPOSURE_PRIORITY = "EXPOSURE_PRIORITY"
    HISTORY_RCA = "HISTORY_RCA"
    VALUE_ROI = "VALUE_ROI"
    RUNTIME_SCALE = "RUNTIME_SCALE"
    RELIABILITY_DR = "RELIABILITY_DR"
    ENGINEER_SHADOW = "ENGINEER_SHADOW"


class GateResult(StrictFrozenModel):
    plane: QualificationPlane
    passed: bool
    artifact: str | None = None
    summary: str | None = None


class CapabilityCertification(StrictFrozenModel):
    capability_id: str
    state: CertificationState
    gate_results: tuple[GateResult, ...] = ()
    limitations: tuple[str, ...] = ()
    qualified_at: datetime | None = None

    @property
    def passed_planes(self) -> frozenset[QualificationPlane]:
        return frozenset(result.plane for result in self.gate_results if result.passed)


class FamilyQualificationManifest(StrictFrozenModel):
    manifest_version: str = "1"
    family_id: str
    release_id: str
    state: CertificationState
    capabilities: tuple[CapabilityCertification, ...]
    created_at: datetime
    approved_by: str | None = None
    notes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def unique_capabilities(self) -> "FamilyQualificationManifest":
        ids = [item.capability_id for item in self.capabilities]
        if len(ids) != len(set(ids)):
            raise ValueError("capability_id values must be unique within a family manifest")
        return self


class RuntimeRole(StrEnum):
    API = "API"
    INCREMENTAL_WORKER = "INCREMENTAL_WORKER"
    BATCH_WORKER = "BATCH_WORKER"
    GPU_WORKER = "GPU_WORKER"
    REPLAY_WORKER = "REPLAY_WORKER"
    COORDINATOR = "COORDINATOR"


class RuntimeRoleProfile(StrictFrozenModel):
    role: RuntimeRole
    replicas: int = Field(default=1, ge=0)
    cpu_request: str
    memory_request: str
    cpu_limit: str | None = None
    memory_limit: str | None = None
    gpu_count: int = Field(default=0, ge=0)
    command: tuple[str, ...]
    qualification: str = "PROVISIONAL"

    @model_validator(mode="after")
    def gpu_role_consistency(self) -> "RuntimeRoleProfile":
        if self.role != RuntimeRole.GPU_WORKER and self.gpu_count:
            raise ValueError("GPU requests are only valid for GPU_WORKER reference profiles")
        return self


class DeploymentPlan(StrictFrozenModel):
    plan_version: str = "1"
    name: str
    namespace: str
    image: str
    roles: tuple[RuntimeRoleProfile, ...]
    service_account_name: str | None = None
    notes: tuple[str, ...] = ()


class ControlKind(StrEnum):
    NOTIFICATIONS = "NOTIFICATIONS"
    CAPABILITY = "CAPABILITY"
    DETECTOR = "DETECTOR"
    MODEL = "MODEL"
    SOURCE = "SOURCE"


class ControlScope(StrEnum):
    GLOBAL = "GLOBAL"
    FAMILY = "FAMILY"
    COMPONENT = "COMPONENT"


class OperationalControl(StrictFrozenModel):
    control_id: str
    kind: ControlKind
    scope: ControlScope
    target: str
    reason: str
    actor: str
    activated_at: datetime
    expires_at: datetime | None = None
    deactivated_at: datetime | None = None
    deactivated_by: str | None = None

    @property
    def active(self) -> bool:
        return self.deactivated_at is None


class FreshnessState(StrEnum):
    CURRENT = "CURRENT"
    DEGRADED = "DEGRADED"
    STALE = "STALE"
    UNKNOWN = "UNKNOWN"


class FreshnessObservation(StrictFrozenModel):
    metric: str
    observed_lag_seconds: float | None = Field(default=None, ge=0)
    target_lag_seconds: float = Field(gt=0)
    hard_limit_seconds: float = Field(gt=0)
    state: FreshnessState
    observed_at: datetime


class OperationalSLOReport(StrictFrozenModel):
    as_of: datetime
    observations: tuple[FreshnessObservation, ...]
    overall_state: FreshnessState
    blockers: tuple[str, ...] = ()


class CandidateRole(StrEnum):
    CHAMPION = "CHAMPION"
    CHALLENGER = "CHALLENGER"


class ShadowResult(StrictFrozenModel):
    candidate_id: str
    role: CandidateRole
    output_fingerprint: str
    actionable: bool
    latency_ms: float = Field(ge=0)
    error: str | None = None


class ShadowComparison(StrictFrozenModel):
    subject_id: str
    as_of: datetime
    champion: ShadowResult
    challengers: tuple[ShadowResult, ...]
    production_output_changed: bool = False


class BootstrapPhase(StrEnum):
    CANONICAL_HISTORY = "CANONICAL_HISTORY"
    MATERIAL_EXPOSURE = "MATERIAL_EXPOSURE"
    CORE_FEATURES = "CORE_FEATURES"
    MAINTENANCE_STATE = "MAINTENANCE_STATE"
    REFERENCES = "REFERENCES"
    PEERS = "PEERS"
    HISTORICAL_REPLAY = "HISTORICAL_REPLAY"
    QUALITY = "QUALITY"
    HISTORY_INDEX = "HISTORY_INDEX"


class BackfillPriority(StrEnum):
    LIVE = "LIVE"
    RECENT_CORRECTION = "RECENT_CORRECTION"
    HISTORICAL_BACKFILL = "HISTORICAL_BACKFILL"


class BackfillChunk(StrictFrozenModel):
    chunk_id: str
    phase: BootstrapPhase
    scope: str
    start_time: datetime
    end_time: datetime
    priority: BackfillPriority = BackfillPriority.HISTORICAL_BACKFILL

    @model_validator(mode="after")
    def valid_range(self) -> "BackfillChunk":
        if self.end_time <= self.start_time:
            raise ValueError("backfill end_time must be after start_time")
        return self


class BackfillStatus(StrEnum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"


class BackfillProgress(StrictFrozenModel):
    chunk: BackfillChunk
    status: BackfillStatus
    attempts: int = Field(default=0, ge=0)
    updated_at: datetime
    error: str | None = None


class ReleaseCompatibilityState(StrEnum):
    COMPATIBLE = "COMPATIBLE"
    REQUIRES_MIGRATION = "REQUIRES_MIGRATION"
    REQUIRES_REBUILD = "REQUIRES_REBUILD"
    INCOMPATIBLE = "INCOMPATIBLE"


class ReleaseCompatibility(StrictFrozenModel):
    from_release_id: str
    to_release_id: str
    state: ReleaseCompatibilityState
    reasons: tuple[str, ...] = ()
    rollback_allowed: bool
    required_rebuilds: tuple[str, ...] = ()


class ShadowReviewDisposition(StrEnum):
    WANT_EVENT = "WANT_EVENT"
    PARTIALLY_USEFUL = "PARTIALLY_USEFUL"
    NOT_USEFUL = "NOT_USEFUL"
    MISLEADING = "MISLEADING"


class EngineerShadowReview(StrictFrozenModel):
    review_id: str
    episode_id: str
    reviewer: str
    disposition: ShadowReviewDisposition
    comparison_valid: bool
    hypothesis_reasonable: bool
    verification_useful: bool
    reviewed_at: datetime
    false_event_reason: str | None = None
    notes: str | None = None


class EngineerShadowSummary(StrictFrozenModel):
    reviews: int = Field(ge=0)
    want_or_partial: int = Field(ge=0)
    misleading: int = Field(ge=0)
    invalid_comparison: int = Field(ge=0)
    verification_useful: int = Field(ge=0)
    useful_rate: float = Field(ge=0, le=1)
    misleading_rate: float = Field(ge=0, le=1)
    invalid_comparison_rate: float = Field(ge=0, le=1)
    verification_useful_rate: float = Field(ge=0, le=1)


class ShadowGateDecision(StrictFrozenModel):
    passed: bool
    reasons: tuple[str, ...] = ()
    summary: EngineerShadowSummary


class ChallengerShadowSummary(StrictFrozenModel):
    challenger_id: str
    observations: int = Field(ge=0)
    actionable_disagreements: int = Field(ge=0)
    errors: int = Field(ge=0)
    actionable_disagreement_rate: float = Field(ge=0, le=1)
    error_rate: float = Field(ge=0, le=1)
    mean_latency_delta_ms: float


class FreshnessChannel(StrEnum):
    SOURCE = "source"
    CANONICAL = "canonical"
    FEATURE = "feature"
    REFERENCE = "reference"
    PEER = "peer"
    ASSESSMENT = "assessment"
    WIP = "wip"
    QUALITY_MODEL = "quality_model"
    HISTORICAL_INDEX = "historical_index"
    VALUE_RECONCILIATION = "value_reconciliation"


class FreshnessHeartbeat(StrictFrozenModel):
    channel: FreshnessChannel
    refreshed_at: datetime
    source_as_of: datetime | None = None
    version: str | None = None
