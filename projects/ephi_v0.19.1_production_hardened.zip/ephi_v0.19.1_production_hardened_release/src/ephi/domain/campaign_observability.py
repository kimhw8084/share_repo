from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ephi.domain.launch import CampaignExecutionRecord, CampaignStage, LaunchArtifactReference, ShadowLaunchDossier


class StrictFrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class CampaignFailureCategory(StrEnum):
    NONE = "NONE"
    ADAPTER_CONTRACT = "ADAPTER_CONTRACT"
    SOURCE_UNAVAILABLE = "SOURCE_UNAVAILABLE"
    SOURCE_IDENTITY = "SOURCE_IDENTITY"
    ARTIFACT_INTEGRITY = "ARTIFACT_INTEGRITY"
    EVIDENCE_REJECTED = "EVIDENCE_REJECTED"
    RETRY_EXHAUSTED = "RETRY_EXHAUSTED"
    CONTROL_PLANE_HANDOFF = "CONTROL_PLANE_HANDOFF"
    CONFIGURATION = "CONFIGURATION"
    UNKNOWN = "UNKNOWN"


class CampaignReadinessState(StrEnum):
    IN_PROGRESS = "IN_PROGRESS"
    BLOCKED = "BLOCKED"
    FAILED = "FAILED"
    READY_FOR_HANDOFF = "READY_FOR_HANDOFF"
    HANDED_OFF = "HANDED_OFF"


class ReconciliationStatus(StrEnum):
    CONSISTENT = "CONSISTENT"
    WARNING = "WARNING"
    BLOCKED = "BLOCKED"


class EvidenceComparisonState(StrEnum):
    IDENTICAL = "IDENTICAL"
    SOURCE_CHANGED = "SOURCE_CHANGED"
    EVIDENCE_CHANGED = "EVIDENCE_CHANGED"
    EXECUTION_CHANGED = "EXECUTION_CHANGED"
    TARGET_CHANGED = "TARGET_CHANGED"


class RetentionDisposition(StrEnum):
    HOLD = "HOLD"
    KEEP_REQUIRED = "KEEP_REQUIRED"
    ELIGIBLE_AFTER = "ELIGIBLE_AFTER"


class CampaignEventView(StrictFrozenModel):
    event_id: str
    campaign_id: str
    at: datetime
    event_type: str
    stage: CampaignStage | None = None
    attempt: int | None = Field(default=None, ge=1)
    status: str | None = None
    actor: str | None = None
    entity_id: str | None = None
    detail: str | None = None
    failure_category: CampaignFailureCategory = CampaignFailureCategory.NONE


class CampaignStageView(StrictFrozenModel):
    stage: CampaignStage
    status: str
    attempts: int = Field(ge=0)
    retries: int = Field(ge=0)
    elapsed_seconds: float | None = Field(default=None, ge=0)
    evidence_ids: tuple[str, ...] = ()
    replay_ids: tuple[str, ...] = ()
    source_snapshot_ids: tuple[str, ...] = ()
    failure_category: CampaignFailureCategory = CampaignFailureCategory.NONE
    last_error: str | None = None


class EvidenceSetFingerprint(StrictFrozenModel):
    fingerprint_version: str = "1"
    family_id: str
    release_id: str
    config_hash: str
    campaign_id: str
    evidence_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    execution_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    evidence_count: int = Field(ge=0)
    replay_count: int = Field(ge=0)
    snapshot_count: int = Field(ge=0)
    evidence_ids: tuple[str, ...] = ()
    replay_ids: tuple[str, ...] = ()
    snapshot_ids: tuple[str, ...] = ()


class CrossStageReconciliation(StrictFrozenModel):
    reconciliation_version: str = "1"
    status: ReconciliationStatus
    identity_consistent: bool
    artifact_integrity_passed: bool
    source_lineage_consistent: bool
    replay_snapshot_consistent: bool
    required_stage_coverage: bool
    evidence_fingerprint: EvidenceSetFingerprint
    stage_snapshot_ids: dict[str, tuple[str, ...]] = Field(default_factory=dict)
    blockers: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()


class CampaignStageSLO(StrictFrozenModel):
    stage: CampaignStage
    elapsed_seconds: float | None = Field(default=None, ge=0)
    max_elapsed_seconds: float | None = Field(default=None, gt=0)
    retries: int = Field(ge=0)
    max_retries: int = Field(ge=0)
    passed: bool
    reasons: tuple[str, ...] = ()


class CampaignSLOPolicy(StrictFrozenModel):
    policy_version: str = "1"
    max_campaign_elapsed_seconds: float = Field(gt=0)
    max_retries_per_stage: int = Field(default=2, ge=0)
    max_running_age_seconds: float = Field(default=3600.0, gt=0)
    stage_max_elapsed_seconds: dict[str, float] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_stage_limits(self) -> "CampaignSLOPolicy":
        for stage, value in self.stage_max_elapsed_seconds.items():
            CampaignStage(stage)
            if value <= 0:
                raise ValueError(f"stage SLO must be positive: {stage}")
        return self


class CampaignSLOReport(StrictFrozenModel):
    report_version: str = "1"
    passed: bool
    campaign_elapsed_seconds: float = Field(ge=0)
    max_campaign_elapsed_seconds: float = Field(gt=0)
    total_retries: int = Field(ge=0)
    running_attempts: int = Field(ge=0)
    stage_reports: tuple[CampaignStageSLO, ...]
    blockers: tuple[str, ...] = ()


class CampaignRetentionPolicy(StrictFrozenModel):
    policy_version: str = "1"
    authoritative_retention_days: int = Field(default=2555, ge=1)
    failed_attempt_retention_days: int = Field(default=365, ge=1)
    source_lineage_retention_days: int = Field(default=2555, ge=1)
    require_immutable_evidence: bool = True


class RetentionItemAssessment(StrictFrozenModel):
    item_type: str
    item_id: str
    disposition: RetentionDisposition
    retain_until: datetime | None = None
    reason: str


class CampaignRetentionAssessment(StrictFrozenModel):
    assessment_version: str = "1"
    policy_version: str
    generated_at: datetime
    items: tuple[RetentionItemAssessment, ...]
    blockers: tuple[str, ...] = ()


class CampaignEvidenceComparison(StrictFrozenModel):
    comparison_version: str = "1"
    baseline_campaign_id: str
    candidate_campaign_id: str
    state: EvidenceComparisonState
    baseline_fingerprint: str
    candidate_fingerprint: str
    source_snapshot_changed: bool
    target_state_changed: bool
    execution_shape_changed: bool
    details: tuple[str, ...] = ()


class CampaignReadinessView(StrictFrozenModel):
    view_version: str = "1"
    family_id: str
    release_id: str
    config_hash: str
    campaign_id: str
    target_state: str
    generated_at: datetime
    state: CampaignReadinessState
    campaign: CampaignExecutionRecord
    stages: tuple[CampaignStageView, ...]
    reconciliation: CrossStageReconciliation
    slo: CampaignSLOReport
    dossier_promotion_ready: bool
    handoff_package_id: str | None = None
    blockers: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()


class CampaignQualificationExport(StrictFrozenModel):
    export_version: str = "1"
    family_id: str
    release_id: str
    config_hash: str
    campaign_id: str
    generated_at: datetime
    readiness: CampaignReadinessView
    dossier: ShadowLaunchDossier
    events: tuple[CampaignEventView, ...]
    retention: CampaignRetentionAssessment
    export_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    metadata: dict[str, Any] = Field(default_factory=dict)


class CampaignQualificationArtifact(StrictFrozenModel):
    artifact_version: str = "1"
    family_id: str
    campaign_id: str
    export_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    artifact: LaunchArtifactReference
    published_at: datetime
