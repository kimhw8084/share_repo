from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ephi.domain.benchmark import BenchmarkCaseType, BenchmarkFamily, BenchmarkLabelConfidence
from ephi.domain.capabilities import Capability
from ephi.domain.data_reality import QualificationState
from ephi.domain.evidence import Hypothesis
from ephi.domain.operations import CertificationState, GateResult, EngineerShadowSummary


class StrictFrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class CapabilityRequirement(StrEnum):
    REQUIRED = "REQUIRED"
    OPTIONAL = "OPTIONAL"


class GapSeverity(StrEnum):
    BLOCKER = "BLOCKER"
    LIMITATION = "LIMITATION"
    INFORMATION = "INFORMATION"


class OnboardingActionKind(StrEnum):
    COMPLETE_MAPPING = "COMPLETE_MAPPING"
    QUALIFY_DATA_REALITY = "QUALIFY_DATA_REALITY"
    CURATE_GOLDEN_CASES = "CURATE_GOLDEN_CASES"
    RUN_GOLDEN_REPLAY = "RUN_GOLDEN_REPLAY"
    RUN_RUNTIME_SCALE = "RUN_RUNTIME_SCALE"
    START_SHADOW = "START_SHADOW"
    COLLECT_ENGINEER_REVIEWS = "COLLECT_ENGINEER_REVIEWS"
    RESOLVE_MISSED_EVENTS = "RESOLVE_MISSED_EVENTS"
    REVIEW_LIMITATION = "REVIEW_LIMITATION"


class OnboardingAction(StrictFrozenModel):
    action_id: str
    kind: OnboardingActionKind
    description: str
    capability: Capability | None = None
    blocking: bool = True
    evidence_required: tuple[str, ...] = ()


class CapabilityGap(StrictFrozenModel):
    capability: Capability
    requirement: CapabilityRequirement
    observed_state: QualificationState
    severity: GapSeverity
    reasons: tuple[str, ...] = ()
    supporting_datasets: tuple[str, ...] = ()
    supporting_joins: tuple[str, ...] = ()
    actions: tuple[OnboardingAction, ...] = ()


class FamilyOnboardingPlan(StrictFrozenModel):
    plan_version: str = "1"
    family_id: str
    release_id: str
    generated_at: datetime
    current_state: CertificationState
    target_state: CertificationState
    required_capabilities: tuple[Capability, ...]
    optional_capabilities: tuple[Capability, ...] = ()
    gaps: tuple[CapabilityGap, ...]
    actions: tuple[OnboardingAction, ...]
    blockers: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()

    @property
    def ready_for_target(self) -> bool:
        return not self.blockers


class GoldenCurationState(StrEnum):
    DRAFT = "DRAFT"
    PENDING_REVIEW = "PENDING_REVIEW"
    NEEDS_INFO = "NEEDS_INFO"
    ACCEPTED = "ACCEPTED"
    REJECTED = "REJECTED"


class GoldenCaseIntake(StrictFrozenModel):
    intake_id: str
    family: BenchmarkFamily
    case_type: BenchmarkCaseType
    source_locator: str
    submitted_by: str
    submitted_at: datetime
    scope_start: datetime
    scope_end: datetime
    label_confidence: BenchmarkLabelConfidence
    expected_hypothesis: Hypothesis | None = None
    expected_local_actionable: bool = False
    expected_fleet_actionable: bool = False
    expected_asset_ids: tuple[str, ...] = ()
    onset_event_time: datetime | None = None
    onset_low: datetime | None = None
    onset_high: datetime | None = None
    external_detection_time: datetime | None = None
    asset_count: int = Field(default=1, ge=1)
    quality_impact: str | None = None
    root_cause_label: str | None = None
    resolution_label: str | None = None
    actions: tuple[str, ...] = ()
    evidence_refs: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()
    notes: str | None = None
    state: GoldenCurationState = GoldenCurationState.DRAFT
    reviewed_by: str | None = None
    reviewed_at: datetime | None = None
    review_note: str | None = None
    revision: int = Field(default=1, ge=1)

    @model_validator(mode="after")
    def validate_intake(self) -> "GoldenCaseIntake":
        if not self.source_locator.strip():
            raise ValueError("source_locator cannot be blank")
        if not self.submitted_by.strip():
            raise ValueError("submitted_by cannot be blank")
        if self.scope_end < self.scope_start:
            raise ValueError("scope_end cannot precede scope_start")
        if self.expected_local_actionable and not self.expected_asset_ids:
            raise ValueError("local actionable intake requires expected_asset_ids")
        if self.state == GoldenCurationState.ACCEPTED:
            if not self.reviewed_by or not self.reviewed_at:
                raise ValueError("accepted Golden intake requires reviewer and review time")
            if self.reviewed_by == self.submitted_by:
                raise ValueError("Golden intake submitter cannot self-approve")
            if not self.evidence_refs:
                raise ValueError("accepted Golden intake requires at least one evidence reference")
        return self


class ShadowSamplingReason(StrEnum):
    HIGH_PRIORITY = "HIGH_PRIORITY"
    HIGH_SEVERITY = "HIGH_SEVERITY"
    HYPOTHESIS_COVERAGE = "HYPOTHESIS_COVERAGE"
    LOW_CONFIDENCE = "LOW_CONFIDENCE"
    NOVEL_HYPOTHESIS = "NOVEL_HYPOTHESIS"
    RANDOM_AUDIT = "RANDOM_AUDIT"


class ShadowReviewCandidate(StrictFrozenModel):
    episode_id: str
    family_id: str
    asset_id: str
    technical_severity: str
    operational_priority: str
    leading_hypothesis: Hypothesis
    confidence: float = Field(ge=0, le=1)
    opened_at: datetime
    reasons: tuple[ShadowSamplingReason, ...] = ()
    sample_score: float = Field(default=0.0, ge=0.0)


class ReviewQueueState(StrEnum):
    PENDING = "PENDING"
    CLAIMED = "CLAIMED"
    COMPLETED = "COMPLETED"
    SKIPPED = "SKIPPED"


class ShadowReviewQueueItem(StrictFrozenModel):
    candidate: ShadowReviewCandidate
    state: ReviewQueueState
    enqueued_at: datetime
    claimed_by: str | None = None
    claimed_at: datetime | None = None
    claimed_until: datetime | None = None
    completed_review_id: str | None = None


class ShadowQualificationMetrics(StrictFrozenModel):
    generated_at: datetime
    review_summary: EngineerShadowSummary
    sampled_candidates: int = Field(ge=0)
    completed_reviews: int = Field(ge=0)
    review_completion_rate: float = Field(ge=0, le=1)
    not_useful_or_misleading: int = Field(ge=0)
    false_or_low_value_rate: float = Field(ge=0, le=1)
    missed_event_reports: int = Field(ge=0)
    missed_reports_per_100_reviews: float = Field(ge=0)
    hypotheses_sampled: tuple[Hypothesis, ...] = ()
    hypotheses_reviewed: tuple[Hypothesis, ...] = ()
    unreviewed_hypotheses: tuple[Hypothesis, ...] = ()
    backlog: int = Field(ge=0)


class PromotionDecision(StrEnum):
    READY = "READY"
    BLOCKED = "BLOCKED"


class PromotionEvidencePackage(StrictFrozenModel):
    package_version: str = "1"
    family_id: str
    release_id: str
    capability_id: str
    generated_at: datetime
    from_state: CertificationState
    target_state: CertificationState
    decision: PromotionDecision
    gate_results: tuple[GateResult, ...]
    blockers: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()
    golden_case_count: int = Field(default=0, ge=0)
    golden_case_confidence: dict[str, int] = Field(default_factory=dict)
    shadow_metrics: ShadowQualificationMetrics | None = None
    evidence_artifacts: tuple[str, ...] = ()
