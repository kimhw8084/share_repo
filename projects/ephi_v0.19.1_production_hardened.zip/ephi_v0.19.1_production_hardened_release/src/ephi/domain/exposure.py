from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, ConfigDict, Field, model_validator
from .health import HealthSeverity

class MaterialExposureClass(StrEnum):
    DEFINITE_PAST_EXPOSURE="DEFINITE_PAST_EXPOSURE"; POSSIBLE_PAST_EXPOSURE="POSSIBLE_PAST_EXPOSURE"; CURRENTLY_COMMITTED_EXPOSURE="CURRENTLY_COMMITTED_EXPOSURE"; FUTURE_POSSIBLE_EXPOSURE="FUTURE_POSSIBLE_EXPOSURE"; FUTURE_LIKELY_EXPOSURE="FUTURE_LIKELY_EXPOSURE"; FUTURE_PREVENTABLE_EXPOSURE="FUTURE_PREVENTABLE_EXPOSURE"
class PreventabilityState(StrEnum):
    NOT_APPLICABLE="NOT_APPLICABLE"; UNKNOWN="UNKNOWN"; LOW="LOW"; MODERATE="MODERATE"; HIGH="HIGH"; ALREADY_COMMITTED="ALREADY_COMMITTED"; NO_QUALIFIED_ALTERNATIVE="NO_QUALIFIED_ALTERNATIVE"
class RouteExposureLikelihood(StrEnum): POSSIBLE="POSSIBLE"; LIKELY="LIKELY"; COMMITTED="COMMITTED"
class AssetAvailability(StrEnum): AVAILABLE="AVAILABLE"; UNKNOWN="UNKNOWN"; UNAVAILABLE="UNAVAILABLE"

@dataclass(frozen=True, slots=True)
class EpisodeOnsetWindow:
    low: datetime; best: datetime; high: datetime; confidence: float=1.0
    def __post_init__(self):
        if not self.low <= self.best <= self.high: raise ValueError("onset window must satisfy low <= best <= high")
        if not 0.0 <= self.confidence <= 1.0: raise ValueError("onset confidence must be within [0, 1]")
@dataclass(frozen=True, slots=True)
class HistoricalExecutionExposure:
    material_id:str; execution_id:str; asset_id:str; operation:str; event_time:datetime; exposure_end:datetime|None=None; route_position:str|None=None; quality_state:str|None=None
@dataclass(frozen=True, slots=True)
class FutureRouteStep:
    material_id:str; sequence:int; operation:str; eligible_asset_ids:tuple[str,...]; eta:datetime|None=None; likely_asset_id:str|None=None; committed_asset_id:str|None=None; route_position:str|None=None
@dataclass(frozen=True, slots=True)
class WIPMaterialState:
    material_id:str; current_sequence:int; future_steps:tuple[FutureRouteStep,...]; held:bool=False
@dataclass(frozen=True, slots=True)
class AlternativeAssetCandidate:
    asset_id:str; qualified:bool; availability:AssetAvailability; health_severity:HealthSeverity; health_confidence:float; compatibility:float=1.0
    def __post_init__(self):
        if not 0<=self.health_confidence<=1: raise ValueError("health_confidence must be within [0, 1]")
        if not 0<=self.compatibility<=1: raise ValueError("compatibility must be within [0, 1]")
class AlternativeAssetAssessment(BaseModel):
    model_config=ConfigDict(frozen=True)
    asset_id:str; qualified:bool; availability:AssetAvailability; health_severity:str; health_confidence:float=Field(ge=0,le=1); compatibility:float=Field(ge=0,le=1); preferred:bool=False; reason:str
class MaterialExposureAssessment(BaseModel):
    model_config=ConfigDict(frozen=True)
    material_id:str; exposure_class:MaterialExposureClass; exposure_start:datetime|None=None; exposure_end:datetime|None=None; exposure_confidence:float=Field(ge=0,le=1); suspect_execution_id:str|None=None; suspect_execution_ids:tuple[str,...]=(); route_position:str|None=None; quality_state:str|None=None; preventability:PreventabilityState=PreventabilityState.UNKNOWN; route_likelihood:RouteExposureLikelihood|None=None; eta:datetime|None=None; alternatives:tuple[AlternativeAssetAssessment,...]=(); reason_codes:tuple[str,...]=()
class ExposureSnapshot(BaseModel):
    model_config=ConfigDict(frozen=True)
    snapshot_id:str; episode_id:str; asset_id:str; operation:str; as_of:datetime; onset_low:datetime; onset_best:datetime; onset_high:datetime; onset_confidence:float=Field(ge=0,le=1); items:tuple[MaterialExposureAssessment,...]=(); definitely_exposed:int=Field(default=0,ge=0); possibly_exposed:int=Field(default=0,ge=0); currently_committed:int=Field(default=0,ge=0); future_possible:int=Field(default=0,ge=0); future_likely:int=Field(default=0,ge=0); future_preventable:int=Field(default=0,ge=0); no_qualified_alternative:int=Field(default=0,ge=0); quality_mature:int=Field(default=0,ge=0); quality_pending:int=Field(default=0,ge=0); earliest_future_eta:datetime|None=None; confidence:float=Field(default=1,ge=0,le=1); source_version:str="exposure-v1"
    @model_validator(mode="after")
    def _counts(self):
        mapping={MaterialExposureClass.DEFINITE_PAST_EXPOSURE:self.definitely_exposed,MaterialExposureClass.POSSIBLE_PAST_EXPOSURE:self.possibly_exposed,MaterialExposureClass.CURRENTLY_COMMITTED_EXPOSURE:self.currently_committed,MaterialExposureClass.FUTURE_POSSIBLE_EXPOSURE:self.future_possible,MaterialExposureClass.FUTURE_LIKELY_EXPOSURE:self.future_likely,MaterialExposureClass.FUTURE_PREVENTABLE_EXPOSURE:self.future_preventable}
        actual={k:0 for k in mapping}
        for i in self.items: actual[i.exposure_class]+=1
        if any(actual[k]!=v for k,v in mapping.items()): raise ValueError("exposure summary counts do not match material items")
        return self
