from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from ephi.errors import InvalidKnowledgeTimeError


@dataclass(frozen=True, slots=True)
class KnowledgeTime:
    event_time: datetime
    available_at: datetime

    def __post_init__(self) -> None:
        if self.available_at < self.event_time:
            raise InvalidKnowledgeTimeError(
                "available_at cannot precede event_time for a canonical manufacturing fact"
            )

    def visible_as_of(self, as_of: datetime) -> bool:
        return self.available_at <= as_of
