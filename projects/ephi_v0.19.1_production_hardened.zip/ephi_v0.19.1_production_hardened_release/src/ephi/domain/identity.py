from typing import NewType

AssetId = NewType("AssetId", str)
ExecutionId = NewType("ExecutionId", str)
MaterialId = NewType("MaterialId", str)
EpisodeId = NewType("EpisodeId", str)
