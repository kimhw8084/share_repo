from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .context import ContextKey


class QualityTargetType(StrEnum):
    CONTINUOUS = "CONTINUOUS"
    BINARY = "BINARY"


class QualityStage(StrEnum):
    INLINE_METROLOGY = "INLINE_METROLOGY"
    INSPECTION = "INSPECTION"
    ELECTRICAL = "ELECTRICAL"
    YIELD = "YIELD"
    FINAL = "FINAL"
    MEASUREMENT_SYSTEM = "MEASUREMENT_SYSTEM"


class PredictionTime(StrEnum):
    POST_PROCESS = "POST_PROCESS"
    POST_INLINE_METROLOGY = "POST_INLINE_METROLOGY"
    POST_INSPECTION = "POST_INSPECTION"


class OutcomeMaturityState(StrEnum):
    NOT_YET_MATURE = "NOT_YET_MATURE"
    MATURE_AVAILABLE = "MATURE_AVAILABLE"
    HELD = "HELD"
    SCRAPPED_BEFORE_OUTCOME = "SCRAPPED_BEFORE_OUTCOME"
    REROUTED = "REROUTED"
    REWORKED = "REWORKED"
    LOST_TO_FOLLOWUP = "LOST_TO_FOLLOWUP"


class QualityEvidenceState(StrEnum):
    UNAVAILABLE = "UNAVAILABLE"
    NOT_YET_MATURE = "NOT_YET_MATURE"
    NO_OBSERVED_ASSOCIATION = "NO_OBSERVED_ASSOCIATION"
    WEAK_ASSOCIATION = "WEAK_ASSOCIATION"
    SUPPORTED_ASSOCIATION = "SUPPORTED_ASSOCIATION"
    STRONG_ASSOCIATION = "STRONG_ASSOCIATION"
    CONTRADICTED = "CONTRADICTED"


class QualityTargetDefinition(BaseModel):
    model_config = ConfigDict(frozen=True)

    target_id: str
    version: str
    target_type: QualityTargetType
    stage: QualityStage
    prediction_time: PredictionTime
    value_unit: str | None = None
    harmful_direction: str = Field(default="TWO_SIDED", pattern="^(UPPER|LOWER|TWO_SIDED)$")
    minimum_practical_effect: float = 0.0
    measurement_system_sensitive: bool = False
    description: str = ""


@dataclass(frozen=True, slots=True)
class QualityOutcomeObservation:
    material_id: str
    execution_id: str
    asset_id: str
    context: ContextKey
    target_id: str
    value: float
    event_time: datetime
    available_at: datetime
    maturity: OutcomeMaturityState
    sampled: bool = True
    sampling_reason: str | None = None

    def __post_init__(self) -> None:
        if self.available_at < self.event_time:
            raise ValueError("quality available_at cannot precede event_time")


@dataclass(frozen=True, slots=True)
class EquipmentStateVector:
    execution_id: str
    material_id: str
    asset_id: str
    context: ContextKey
    event_time: datetime
    known_at: datetime
    behavioral_novelty: float
    health_confidence: float
    local_support: float
    common_mode_support: float
    measurement_system_support: float

    def __post_init__(self) -> None:
        if self.known_at < self.event_time:
            raise ValueError("equipment-state known_at cannot precede event_time")


@dataclass(frozen=True, slots=True)
class QualityTrainingRow:
    material_id: str
    execution_id: str
    asset_id: str
    context: ContextKey
    prediction_cutoff: datetime
    equipment_known_at: datetime
    outcome_available_at: datetime
    outcome_maturity: OutcomeMaturityState
    outcome_value: float
    behavioral_novelty: float
    health_confidence: float
    local_support: float
    common_mode_support: float
    measurement_system_support: float
    measurement_integrity_confidence: float
    sampling_reason: str | None = None

    def __post_init__(self) -> None:
        if self.equipment_known_at > self.prediction_cutoff:
            raise ValueError("equipment state is not available by prediction cutoff")
        if self.outcome_available_at <= self.prediction_cutoff:
            raise ValueError("outcome is already available at prediction cutoff (label leakage)")
        if self.outcome_maturity is not OutcomeMaturityState.MATURE_AVAILABLE:
            raise ValueError("training rows require mature available outcomes")
        if not 0.0 <= self.measurement_integrity_confidence <= 1.0:
            raise ValueError("measurement_integrity_confidence must be within [0, 1]")


class QualityDatasetManifest(BaseModel):
    model_config = ConfigDict(frozen=True)

    dataset_id: str
    target_id: str
    target_version: str
    created_at: datetime
    knowledge_cutoff: datetime
    row_count: int
    excluded_not_mature: int = 0
    excluded_intervention_censored: int = 0
    excluded_leakage: int = 0
    excluded_missing_state: int = 0
    context_fields: tuple[str, ...] = ("operation", "recipe_id", "product_id", "technology")
    equipment_fields: tuple[str, ...] = (
        "behavioral_novelty",
        "health_confidence",
        "local_support",
        "common_mode_support",
        "measurement_system_support",
    )


class QualityModelMetrics(BaseModel):
    model_config = ConfigDict(frozen=True)

    target_id: str
    model_role: str
    target_type: QualityTargetType
    n_train: int
    n_test: int
    rmse: float | None = None
    mae: float | None = None
    r2: float | None = None
    brier: float | None = None
    log_loss: float | None = None
    average_precision: float | None = None
    calibration_error: float | None = None


class QualityModelComparison(BaseModel):
    model_config = ConfigDict(frozen=True)

    target_id: str
    target_version: str
    target_type: QualityTargetType
    m0: QualityModelMetrics
    m1: QualityModelMetrics
    equipment_state_increment: float
    equipment_state_useful: bool
    chronological_split_time: datetime
    calibration_method: str
    uncertainty_method: str | None = None


class ApplicabilityAssessment(BaseModel):
    model_config = ConfigDict(frozen=True)

    applicable: bool
    confidence: float = Field(ge=0.0, le=1.0)
    context_supported: bool
    product_supported: bool
    recipe_supported: bool
    reason_codes: tuple[str, ...] = ()


class QualityModelResult(BaseModel):
    model_config = ConfigDict(frozen=True)

    target_id: str
    target_version: str
    execution_id: str
    predicted_value_or_risk: float
    m0_prediction: float
    m1_prediction: float
    predictive_increment: float
    applicability: ApplicabilityAssessment
    measurement_integrity_confidence: float = Field(ge=0.0, le=1.0)
    model_confidence: float = Field(ge=0.0, le=1.0)
    interval_lower: float | None = None
    interval_upper: float | None = None


class QualityAssociationEvidence(BaseModel):
    model_config = ConfigDict(frozen=True)

    target_id: str
    target_version: str
    stage: QualityStage
    evidence_state: QualityEvidenceState
    exposed_count: int
    control_count: int
    exposed_mean: float | None = None
    control_mean: float | None = None
    adjusted_effect: float | None = None
    effect_standard_error: float | None = None
    predictive_increment: float | None = None
    temporal_consistency: float = Field(ge=0.0, le=1.0)
    control_robustness: float = Field(ge=0.0, le=1.0)
    sampling_confidence: float = Field(ge=0.0, le=1.0)
    measurement_integrity_confidence: float = Field(ge=0.0, le=1.0)
    maturity_confidence: float = Field(ge=0.0, le=1.0)
    association_confidence: float = Field(ge=0.0, le=1.0)
    contradictions: tuple[str, ...] = ()
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _counts_are_nonnegative(self) -> "QualityAssociationEvidence":
        if self.exposed_count < 0 or self.control_count < 0:
            raise ValueError("cohort counts must be non-negative")
        return self
