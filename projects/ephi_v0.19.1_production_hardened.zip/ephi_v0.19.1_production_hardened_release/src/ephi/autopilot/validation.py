from __future__ import annotations

from dataclasses import dataclass
import re

from ephi.audit_contracts import DEFAULT_DATASET_CONTRACTS
from ephi.autopilot.models import SqlBindingManifest


@dataclass(frozen=True, slots=True)
class BindingValidationResult:
    logical_dataset: str
    passed: bool
    errors: tuple[str, ...]
    warnings: tuple[str, ...]
    checks: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "logical_dataset": self.logical_dataset,
            "passed": self.passed,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "checks": list(self.checks),
        }


def validate_sql_binding(binding: SqlBindingManifest) -> BindingValidationResult:
    contracts = {c.logical_name: c for c in DEFAULT_DATASET_CONTRACTS}
    if binding.logical_dataset not in contracts:
        return BindingValidationResult(binding.logical_dataset, False, ("unknown logical dataset",), (), ())
    contract = contracts[binding.logical_dataset]
    errors: list[str] = []
    warnings: list[str] = []
    checks: list[str] = []

    # `columns` means genuinely mapped source semantics. Required fields may not be
    # satisfied by a NULL placeholder, while optional fields may be.
    missing = [c for c in contract.required_columns if c not in binding.columns]
    if missing:
        errors.append(f"missing required canonical mappings: {missing}")
    else:
        checks.append("required mappings present")

    sql_lower = binding.sql.lower().strip()
    if not sql_lower.startswith("select"):
        errors.append("binding SQL must be a SELECT query")
    forbidden = (" insert ", " update ", " delete ", " drop ", " alter ", " create ", " merge ", " truncate ")
    padded = " " + re.sub(r"\s+", " ", sql_lower) + " "
    if any(token in padded for token in forbidden):
        errors.append("binding SQL must be read-only")
    if re.search(r"select\s+\*", sql_lower):
        errors.append("SELECT * is forbidden")
    else:
        checks.append("explicit column projection")
    if ";" in binding.sql.strip().rstrip(";"):
        errors.append("multiple SQL statements are forbidden")

    full_schema = (*contract.required_columns, *contract.optional_columns)
    for logical in full_schema:
        if not re.search(rf"\bas\s+[\"`]?{re.escape(logical.lower())}[\"`]?\b", sql_lower):
            errors.append(f"SQL projection does not expose canonical field: {logical}")
    if not any(error.startswith("SQL projection") for error in errors):
        checks.append("full canonical SQL schema exposed")

    if contract.available_at_column and not binding.knowledge_time_column:
        errors.append("knowledge-time source mapping required")
    elif contract.available_at_column:
        checks.append("knowledge-time mapping declared")

    if binding.partition_column:
        if "_ephi_partition" not in sql_lower:
            errors.append("partition column must be projected as _ephi_partition")
        if binding.partition_source_field is None:
            warnings.append("partition source semantics unresolved; partition pruning disabled until confirmed")
        elif binding.partition_source_field not in {contract.event_time_column, contract.available_at_column}:
            errors.append("partition_source_field must match canonical event_time or available_at semantics")
        if binding.partition_granularity is None:
            warnings.append("partition granularity unresolved; partition pruning disabled until confirmed")
        elif binding.partition_granularity not in {"date", "timestamp"}:
            errors.append("partition_granularity must be date or timestamp")
        if binding.partition_source_field and binding.partition_granularity:
            checks.append("partition semantics declared")
    elif binding.partition_source_field or binding.partition_granularity:
        errors.append("partition semantics declared without partition_column")
    else:
        warnings.append("partition column not declared; production-scale scan efficiency must be proven")

    if binding.watermark_column:
        if contract.available_at_column not in binding.columns:
            errors.append("watermark declared but canonical available_at is not mapped")
        else:
            checks.append("incremental watermark declared")
    if binding.confidence < 0.75:
        warnings.append("binding confidence below 0.75")
    if not binding.source_schema_fingerprint:
        warnings.append("source schema fingerprint missing; startup schema-drift detection unavailable")
    else:
        checks.append("source schema fingerprint declared")
    return BindingValidationResult(binding.logical_dataset, not errors, tuple(errors), tuple(warnings), tuple(checks))
