from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ChangeAudit:
    classification: dict[str, tuple[str, ...]]
    portability_passed: bool
    reasons: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return {"classification": {k: list(v) for k, v in self.classification.items()}, "portability_passed": self.portability_passed, "reasons": list(self.reasons)}


def classify_changes(paths: tuple[str, ...]) -> ChangeAudit:
    buckets: dict[str, list[str]] = {"CONFIG": [], "COMPANY_BINDING": [], "COMPANY_ADAPTER": [], "FAMILY_PLUGIN": [], "POLICY": [], "CORE": [], "OTHER": []}
    for path in paths:
        p = path.replace("\\", "/")
        if p.startswith("company_bindings/"):
            bucket = "COMPANY_BINDING"
        elif p.startswith("company_port/"):
            bucket = "COMPANY_ADAPTER"
        elif p.startswith("configs/"):
            bucket = "POLICY" if "/policy" in p or "/qualification" in p else "CONFIG"
        elif p.startswith("extensions/") or p.startswith("families/"):
            bucket = "FAMILY_PLUGIN"
        elif p.startswith("src/ephi/"):
            bucket = "CORE"
        else:
            bucket = "OTHER"
        buckets[bucket].append(path)
    core = tuple(buckets["CORE"])
    reasons = ("generic EPHI core changed during port",) if core else ()
    return ChangeAudit({k: tuple(v) for k, v in buckets.items() if v}, not core, reasons)
