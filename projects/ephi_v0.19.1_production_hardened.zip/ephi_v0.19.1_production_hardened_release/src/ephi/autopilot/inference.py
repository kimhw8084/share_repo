from __future__ import annotations

import re
from datetime import datetime, timezone
from difflib import SequenceMatcher

from ephi.audit_contracts import DEFAULT_DATASET_CONTRACTS
from ephi.autopilot.catalog import Criticality, requirement
from ephi.autopilot.models import (
    DatasetMappingProposal,
    FieldMappingProposal,
    MappingDisposition,
    PhysicalColumnProfile,
    PhysicalTableProfile,
    SqlBindingManifest,
)


def _norm(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", value.lower())


def _tokens(value: str) -> set[str]:
    return {x for x in re.split(r"[^a-z0-9]+", value.lower()) if x}


def _name_score(logical: str, aliases: tuple[str, ...], physical: str) -> float:
    p = _norm(physical)
    physical_tokens = _tokens(physical)
    if logical == "x" and "y" in physical_tokens and "x" not in physical_tokens:
        return 0.0
    if logical == "y" and "x" in physical_tokens and "y" not in physical_tokens:
        return 0.0
    candidates = (logical, *aliases)
    best = 0.0
    for candidate in candidates:
        c = _norm(candidate)
        if p == c:
            return 1.0
        pt, ct = _tokens(physical), _tokens(candidate)
        overlap = len(pt & ct) / max(1, len(pt | ct))
        seq = SequenceMatcher(None, p, c).ratio()
        # Single-letter aliases such as x/y are useful only as exact tokens. Treating
        # them as substrings made `Y` steal REF_YN in v0.19.
        contains = 0.0
        if len(c) >= 3 and (c in p or p in c):
            contains = 0.88
        elif c in pt or p in ct:
            contains = 0.88
        best = max(best, overlap * 0.94, seq * 0.78, contains)
    return min(best, 1.0)


def _type_score(expected: str | None, actual: str) -> float:
    if expected is None:
        return 0.7
    a = actual.lower()
    groups = {
        "string": ("char", "text", "string", "varchar", "object"),
        "number": ("int", "float", "double", "decimal", "numeric", "real", "number"),
        "integer": ("int", "long", "bigint", "smallint"),
        "timestamp": ("time", "date", "timestamp", "datetime"),
        "boolean": ("bool", "bit", "int", "char", "string", "text"),
    }
    return 1.0 if any(token in a for token in groups.get(expected, (expected,))) else 0.35


def _parse_datetime(value) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(text)
    except ValueError:
        return None


def _value_score(logical: str, col: PhysicalColumnProfile, *, row_count: int | None = None) -> float:
    values = [str(v).strip().lower() for v in col.sample_values if v is not None]
    if not values:
        return 0.5
    if logical in {"is_reference_material", "qualified", "valid"}:
        known = {"y", "n", "yes", "no", "true", "false", "0", "1", "ref", "prod", "reference", "production", "qualified", "unqualified"}
        return 0.95 if set(values[:20]) <= known else 0.45
    if logical in {"event_time", "available_at", "opened_at", "sample_time"}:
        parsed = sum(_parse_datetime(v) is not None for v in col.sample_values[:10] if v is not None)
        return 0.98 if parsed else 0.30
    if logical in {"execution_id", "measurement_id", "maintenance_event_id", "case_id"}:
        if row_count and col.distinct_count is not None:
            ratio = col.distinct_count / max(1, row_count)
            if ratio >= 0.98:
                return 1.0
            if ratio >= 0.90:
                return 0.85
            if ratio < 0.20:
                return 0.15
    if logical == "material_id" and col.distinct_count is not None and col.distinct_count <= 25:
        return 0.2
    return 0.65


def _boolean_normalization(col: PhysicalColumnProfile) -> str | None:
    values = {str(v).strip().lower() for v in col.sample_values if v is not None}
    if not values:
        return None
    true_tokens = {"y", "yes", "true", "1", "ref", "reference", "qualified"}
    false_tokens = {"n", "no", "false", "0", "prod", "production", "unqualified"}
    if values <= true_tokens | false_tokens:
        return "BOOLEAN_TOKENS"
    return None


def _disposition(score: float, *, critical: bool) -> MappingDisposition:
    if score >= 0.85 and not critical:
        return MappingDisposition.AUTO_CONFIRMED
    if score >= 0.88 and critical:
        return MappingDisposition.REVIEW_RECOMMENDED
    if score >= 0.75:
        return MappingDisposition.REVIEW_RECOMMENDED
    if score >= 0.50:
        return MappingDisposition.REVIEW_REQUIRED
    return MappingDisposition.UNRESOLVED


def infer_dataset_mapping(logical_dataset: str, profile: PhysicalTableProfile) -> DatasetMappingProposal:
    req = requirement(logical_dataset)
    proposals: list[FieldMappingProposal] = []
    missing: list[str] = []
    review: list[str] = []
    used: set[str] = set()
    for field in req.fields:
        candidates: list[tuple[float, PhysicalColumnProfile, tuple[str, ...]]] = []
        for col in profile.columns:
            if col.name in used:
                continue
            ns = _name_score(field.name, field.aliases, col.name)
            ts = _type_score(field.type_family, col.type_name)
            vs = _value_score(field.name, col, row_count=profile.row_count)
            score = 0.68 * ns + 0.20 * ts + 0.12 * vs
            reasons = (f"name={ns:.3f}", f"type={ts:.3f}", f"values={vs:.3f}")
            candidates.append((score, col, reasons))
        candidates.sort(key=lambda x: x[0], reverse=True)
        minimum_score = 0.50 if field.criticality == Criticality.REQUIRED else 0.60
        if not candidates or candidates[0][0] < minimum_score:
            proposals.append(FieldMappingProposal(field.name, None, 0.0, MappingDisposition.UNRESOLVED, ("no credible column candidate",)))
            if field.criticality == Criticality.REQUIRED:
                missing.append(field.name)
            continue
        score, col, reasons = candidates[0]
        critical_semantics = field.name in {"material_id", "available_at", "is_reference_material", "qualified", "valid"}
        disp = _disposition(score, critical=critical_semantics)
        normalization = _boolean_normalization(col) if field.type_family == "boolean" else None
        used.add(col.name)
        proposals.append(FieldMappingProposal(field.name, col.name, score, disp, reasons, normalization))
        if disp in {MappingDisposition.REVIEW_REQUIRED, MappingDisposition.REVIEW_RECOMMENDED}:
            review.append(f"confirm {field.name} -> {col.name} ({score:.2f})")

    mapped = {p.logical_field: p.physical_expression for p in proposals if p.physical_expression}
    if profile.sample_records and mapped.get("event_time") and mapped.get("available_at"):
        event_col, available_col = mapped["event_time"], mapped["available_at"]
        comparable = 0
        violations = 0
        unparsable = 0
        for row in profile.sample_records:
            event_value = _parse_datetime(row.get(event_col))
            available_value = _parse_datetime(row.get(available_col))
            if row.get(event_col) is None or row.get(available_col) is None:
                continue
            if event_value is None or available_value is None:
                unparsable += 1
                continue
            # Normalize aware datetimes to UTC, while preserving naive-vs-naive
            # comparison. Mixed aware/naive values are review-worthy.
            if (event_value.tzinfo is None) != (available_value.tzinfo is None):
                unparsable += 1
                continue
            if event_value.tzinfo is not None:
                event_value = event_value.astimezone(timezone.utc)
                available_value = available_value.astimezone(timezone.utc)
            comparable += 1
            if available_value < event_value:
                violations += 1
        if unparsable:
            review.append(f"confirm timestamp normalization; {unparsable} sampled event/knowledge pairs were not comparable")
        if comparable and violations / comparable > 0.05:
            review.append(f"knowledge-time ordering violation: available_at precedes event_time in {violations}/{comparable} sampled rows")
        elif comparable and violations == 0:
            upgraded: list[FieldMappingProposal] = []
            for item in proposals:
                if item.logical_field == "available_at" and item.confidence >= 0.85:
                    upgraded.append(FieldMappingProposal(item.logical_field, item.physical_expression, item.confidence, MappingDisposition.AUTO_CONFIRMED, (*item.reasons, f"knowledge_time_ordering=0/{comparable}_violations"), item.normalization))
                    review = [r for r in review if not r.startswith("confirm available_at ->")]
                else:
                    upgraded.append(item)
            proposals = upgraded
    required_scores = [p.confidence for p in proposals if req.field(p.logical_field).criticality == Criticality.REQUIRED and p.physical_expression]
    confidence = min(required_scores) if required_scores and not missing else 0.0
    if any(item.startswith("knowledge-time ordering violation") for item in review):
        confidence = min(confidence, 0.49)
    return DatasetMappingProposal(
        logical_dataset,
        profile.table_name,
        tuple(proposals),
        confidence,
        tuple(missing),
        tuple(dict.fromkeys(review)),
        source_schema_fingerprint=profile.schema_fingerprint(),
        source_column_types={c.name: c.type_name for c in profile.columns},
    )


def _canonical_expression(item: FieldMappingProposal) -> str:
    assert item.physical_expression
    expr = item.physical_expression
    if item.normalization == "BOOLEAN_TOKENS":
        # SQL92-compatible CASE; company dialect qualification verifies support.
        return (
            f"CASE WHEN LOWER(TRIM(CAST({expr} AS VARCHAR))) IN "
            "('y','yes','true','1','ref','reference','qualified') THEN 1 "
            f"WHEN LOWER(TRIM(CAST({expr} AS VARCHAR))) IN "
            "('n','no','false','0','prod','production','unqualified') THEN 0 ELSE NULL END"
        )
    return expr


def proposal_to_sql_binding(
    proposal: DatasetMappingProposal,
    *,
    partition_column: str | None = None,
    partition_source_field: str | None = None,
    partition_granularity: str | None = None,
    watermark_column: str | None = None,
) -> SqlBindingManifest:
    if proposal.missing_required:
        raise ValueError(f"Cannot build SQL with unresolved required fields: {proposal.missing_required}")
    contracts = {c.logical_name: c for c in DEFAULT_DATASET_CONTRACTS}
    contract = contracts[proposal.logical_dataset]
    mapped_items = {f.logical_field: f for f in proposal.fields if f.physical_expression}
    real_mapping: dict[str, str] = {}
    projection: list[str] = []
    for logical in (*contract.required_columns, *contract.optional_columns):
        item = mapped_items.get(logical)
        if item is None:
            projection.append(f"NULL AS {logical}")
            continue
        expr = _canonical_expression(item)
        projection.append(f"{expr} AS {logical}")
        real_mapping[logical] = expr
    review = list(proposal.review_items)
    if partition_column:
        projection.append(f"{partition_column} AS _ephi_partition")
        if partition_source_field not in {None, contract.event_time_column, contract.available_at_column}:
            raise ValueError(
                f"partition_source_field must be event/available time for {proposal.logical_dataset}: {partition_source_field}"
            )
        if partition_source_field is None:
            review.append(
                f"confirm partition semantics: physical {partition_column} corresponds to event_time or available_at"
            )
        if partition_granularity not in {None, "date", "timestamp"}:
            raise ValueError("partition_granularity must be date or timestamp")
        if partition_granularity is None:
            review.append(f"confirm partition granularity for {partition_column}: date or timestamp")
    sql = f"SELECT\n    " + ",\n    ".join(projection) + f"\nFROM {proposal.physical_table}\n"
    return SqlBindingManifest(
        logical_dataset=proposal.logical_dataset,
        physical_table=proposal.physical_table,
        sql=sql,
        columns=real_mapping,
        partition_column=partition_column,
        partition_source_field=partition_source_field,
        partition_granularity=partition_granularity,
        watermark_column=watermark_column,
        knowledge_time_column=real_mapping.get("available_at"),
        confidence=proposal.confidence,
        review_items=tuple(dict.fromkeys(review)),
        source_schema_fingerprint=proposal.source_schema_fingerprint,
    )


def rank_dataset_candidates(logical_dataset: str, profiles: tuple[PhysicalTableProfile, ...]) -> tuple[DatasetMappingProposal, ...]:
    proposals = [infer_dataset_mapping(logical_dataset, profile) for profile in profiles]
    proposals.sort(key=lambda p: (not bool(p.missing_required), p.confidence, -len(p.review_items)), reverse=True)
    return tuple(proposals)
