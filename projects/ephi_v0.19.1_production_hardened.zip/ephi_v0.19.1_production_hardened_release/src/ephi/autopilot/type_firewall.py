from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Any, Iterable, Mapping

from ephi.autopilot.catalog import DEFAULT_REQUIREMENTS


@dataclass(frozen=True, slots=True)
class TypeFirewallResult:
    passed: bool
    errors: tuple[str, ...]
    checked_rows: int

    def to_dict(self) -> dict[str, object]:
        return {"passed": self.passed, "errors": list(self.errors), "checked_rows": self.checked_rows}


def _rows_from_result(result: Any) -> list[Mapping[str, Any]] | None:
    if isinstance(result, list) and (not result or isinstance(result[0], Mapping)):
        return result
    if isinstance(result, tuple) and (not result or isinstance(result[0], Mapping)):
        return list(result)
    if isinstance(result, Mapping) and isinstance(result.get("rows"), list):
        rows = result["rows"]
        return rows if not rows or isinstance(rows[0], Mapping) else None
    if hasattr(result, "to_pylist"):
        rows = result.to_pylist()
        if isinstance(rows, list) and (not rows or isinstance(rows[0], Mapping)):
            return rows
    return None


def _is_timestamp(value: Any) -> bool:
    if isinstance(value, datetime):
        return True
    if isinstance(value, str):
        text = value.strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        try:
            datetime.fromisoformat(text)
            return True
        except ValueError:
            return False
    return False


def _valid_type(type_family: str | None, value: Any) -> bool:
    if value is None or type_family is None:
        return True
    if type_family == "string":
        return isinstance(value, str)
    if type_family == "number":
        return isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)
    if type_family == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if type_family == "boolean":
        return isinstance(value, bool) or (isinstance(value, int) and value in {0, 1})
    if type_family == "timestamp":
        return _is_timestamp(value)
    return True


class CanonicalTypeFirewall:
    def __init__(self, *, max_rows: int = 100) -> None:
        self.max_rows = max_rows
        self._requirements = {r.logical_name: r for r in DEFAULT_REQUIREMENTS}

    def validate(self, dataset: str, result: Any) -> TypeFirewallResult:
        rows = _rows_from_result(result)
        if rows is None:
            # Opaque company Arrow objects are accepted here; company adapter acceptance
            # must separately verify Arrow schema conversion. Portable tests exercise rows.
            return TypeFirewallResult(True, (), 0)
        requirement = self._requirements.get(dataset)
        if requirement is None:
            return TypeFirewallResult(True, (), 0)
        fields = {f.name: f for f in requirement.fields}
        errors: list[str] = []
        checked = 0
        for row_idx, row in enumerate(rows[: self.max_rows]):
            checked += 1
            for name, field in fields.items():
                if name not in row:
                    continue
                value = row[name]
                if not _valid_type(field.type_family, value):
                    errors.append(
                        f"row {row_idx} canonical {name} expected {field.type_family}, got {type(value).__name__}: {value!r}"
                    )
                    if len(errors) >= 20:
                        return TypeFirewallResult(False, tuple(errors), checked)
        return TypeFirewallResult(not errors, tuple(errors), checked)
