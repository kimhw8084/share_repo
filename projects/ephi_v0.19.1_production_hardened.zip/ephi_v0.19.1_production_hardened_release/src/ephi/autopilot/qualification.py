from __future__ import annotations

import json
import sqlite3
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory

from ephi.adapters.base.big_data import Predicate, PredicateOp, QuerySpec
from ephi.adapters.company.sql_bound_client import SqlBindingRegistry, SqlTemplateBigDataClient
from ephi.autopilot.catalog import assert_catalog_matches_contracts
from ephi.autopilot.change_audit import classify_changes
from ephi.autopilot.dialect import qualify_sql_executor
from ephi.autopilot.inference import infer_dataset_mapping, proposal_to_sql_binding
from ephi.autopilot.inspect import SqliteTableInspector
from ephi.autopilot.models import load_sql_binding
from ephi.autopilot.sqlite_runtime import SqliteSqlExecutor
from ephi.autopilot.synthesis import synthesize_port
from ephi.autopilot.validation import validate_sql_binding
from ephi.repositories.executions import ProcessExecutionRepository


@dataclass(frozen=True, slots=True)
class AutoPortQualificationReport:
    passed: bool
    catalog_contract_alignment: bool
    execution_candidate_identified: bool
    metrology_candidate_identified: bool
    wrong_candidate_rejected: bool
    execution_binding_valid: bool
    metrology_binding_valid: bool
    runtime_repository_execution: bool
    boolean_normalization: bool
    binding_integrity_enforced: bool
    sql_capability_probe: bool
    zero_core_changes: bool
    autoconfiguration_coverage: float
    manual_decision_count: int
    generated_dataset_count: int
    details: dict[str, object]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _build_hostile_db(path: Path) -> None:
    con = sqlite3.connect(path)
    try:
        con.executescript("""
        CREATE TABLE FAB_FLOW_ARCHIVE_X7 (
            RUN_KEY TEXT PRIMARY KEY,
            TOOL_ID TEXT NOT NULL,
            MODULE_ID TEXT,
            FINISH_TS TEXT NOT NULL,
            LOAD_DTTM TEXT NOT NULL,
            OPER_ID TEXT,
            RCP_ID TEXT,
            PROD_ID TEXT,
            TECH_CODE TEXT,
            WAFER_KEY TEXT,
            PROC_DATE TEXT NOT NULL
        );
        CREATE INDEX IX_FLOW_LOAD ON FAB_FLOW_ARCHIVE_X7(LOAD_DTTM);
        CREATE INDEX IX_FLOW_DATE ON FAB_FLOW_ARCHIVE_X7(PROC_DATE);
        CREATE TABLE MEASUREMENT_VAULT_Q (
            RESULT_ID TEXT PRIMARY KEY,
            WAFER_KEY TEXT NOT NULL,
            TOOL_ID TEXT NOT NULL,
            ITEM_CD TEXT NOT NULL,
            MEAS_VAL REAL NOT NULL,
            MEAS_TIME TEXT NOT NULL,
            LOAD_DTTM TEXT NOT NULL,
            RCP_ID TEXT,
            X_POS REAL,
            Y_POS REAL,
            REF_YN TEXT,
            REPEAT_GROUP TEXT,
            MEAS_DATE TEXT NOT NULL
        );
        CREATE INDEX IX_MEAS_LOAD ON MEASUREMENT_VAULT_Q(LOAD_DTTM);
        CREATE INDEX IX_MEAS_DATE ON MEASUREMENT_VAULT_Q(MEAS_DATE);
        CREATE TABLE EQP_DAILY_SUMMARY_WRONG (
            TOOL_ID TEXT,
            DAY TEXT,
            AVAILABILITY REAL,
            STATE TEXT
        );
        """)
        for i in range(80):
            wafer = f"LOT{i//20:03d}:W{i%20+1:02d}" if i != 79 else None
            tool = f"METRO{i%3+1:02d}"
            module = f"H{i%2+1}"
            day = (i % 28) + 1
            minute = i % 55
            finish = f"2026-01-{day:02d} 10:{minute:02d}:00"
            load = f"2026-01-{day:02d} 10:{minute+2:02d}:30"
            con.execute("INSERT INTO FAB_FLOW_ARCHIVE_X7 VALUES (?,?,?,?,?,?,?,?,?,?,?)", (
                f"RUN-{i:05d}", tool, module, finish, load, "OP420", "RCP_A", "DEV_X", "N3", wafer, finish[:10]
            ))
            con.execute("INSERT INTO MEASUREMENT_VAULT_Q VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                f"M-{i:06d}", f"LOT{i//20:03d}:W{i%20+1:02d}", tool, "CD_TOP" if i%2==0 else "CD_BOT", 40.0 + (i%7)*0.02,
                finish, load, "MRCP_9", float(i%10), float((i*3)%10), "Y" if i%17==0 else "N",
                f"RG-{i//2:04d}" if i%11==0 else None, finish[:10]
            ))
        for i in range(10):
            con.execute("INSERT INTO EQP_DAILY_SUMMARY_WRONG VALUES (?,?,?,?)", (f"METRO{i%3+1:02d}", "2026-01-01", 0.99, "UP"))
        con.commit()
    finally:
        con.close()


def run_autopilot_qualification() -> AutoPortQualificationReport:
    assert_catalog_matches_contracts()
    with TemporaryDirectory() as td:
        root = Path(td)
        db = root / "hostile.sqlite3"
        _build_hostile_db(db)
        inspector = SqliteTableInspector(db)
        exec_profile = inspector.profile("FAB_FLOW_ARCHIVE_X7")
        metro_profile = inspector.profile("MEASUREMENT_VAULT_Q")
        wrong_profile = inspector.profile("EQP_DAILY_SUMMARY_WRONG")
        exec_prop = infer_dataset_mapping("executions", exec_profile)
        metro_prop = infer_dataset_mapping("metrology", metro_profile)
        wrong_prop = infer_dataset_mapping("metrology", wrong_profile)
        exec_binding = proposal_to_sql_binding(
            exec_prop, partition_column="PROC_DATE", partition_source_field="event_time",
            partition_granularity="date", watermark_column="LOAD_DTTM"
        )
        metro_binding = proposal_to_sql_binding(
            metro_prop, partition_column="MEAS_DATE", partition_source_field="event_time",
            partition_granularity="date", watermark_column="LOAD_DTTM"
        )
        exec_valid = validate_sql_binding(exec_binding)
        metro_valid = validate_sql_binding(metro_binding)
        synth = synthesize_port((exec_binding, metro_binding))
        audit = classify_changes(("company_bindings/executions.yaml", "company_bindings/metrology.yaml", "configs/company/generated.yaml"))

        # Saved/loaded manifests are the actual runtime source of truth.
        binding_dir = root / "bindings"
        binding_dir.mkdir()
        exec_path = binding_dir / "executions.yaml"
        metro_path = binding_dir / "metrology.yaml"
        exec_binding.save(exec_path)
        metro_binding.save(metro_path)
        registry = SqlBindingRegistry.from_directory(binding_dir)
        executor = SqliteSqlExecutor(db)
        dialect = qualify_sql_executor(executor)
        client = SqlTemplateBigDataClient(executor, registry)
        repo = ProcessExecutionRepository(client)
        incremental = repo.fetch_incremental(
            available_after=datetime(2026, 1, 1, 0, 0),
            available_until=datetime(2026, 1, 29, 23, 59),
        )
        by_ids = repo.fetch_by_ids(["RUN-00001", "RUN-00002"], as_of=datetime(2026, 2, 1))
        runtime_repository_execution = bool(incremental) and len(by_ids) == 2

        flags = client.query_arrow(QuerySpec(
            dataset="metrology",
            columns=("is_reference_material",),
            predicates=(Predicate("measurement_id", PredicateOp.IN, ("M-000000", "M-000001")),),
        ))
        flag_values = {row["is_reference_material"] for row in flags}
        boolean_normalization = flag_values == {0, 1}

        # Manifest edit without resealing must be rejected.
        payload = metro_path.read_text(encoding="utf-8").replace("MEAS_VAL", "MEAS_VAL + 0")
        metro_path.write_text(payload, encoding="utf-8")
        try:
            load_sql_binding(metro_path)
            integrity_enforced = False
        except ValueError as exc:
            integrity_enforced = "binding_hash mismatch" in str(exc)

        checks = {
            "catalog_contract_alignment": True,
            "execution_candidate_identified": not exec_prop.missing_required and exec_prop.confidence >= 0.50,
            "metrology_candidate_identified": not metro_prop.missing_required and metro_prop.confidence >= 0.50,
            "wrong_candidate_rejected": bool(wrong_prop.missing_required) or wrong_prop.confidence < 0.50,
            "execution_binding_valid": exec_valid.passed,
            "metrology_binding_valid": metro_valid.passed,
            "runtime_repository_execution": runtime_repository_execution,
            "boolean_normalization": boolean_normalization,
            "binding_integrity_enforced": integrity_enforced,
            "sql_capability_probe": dialect.passed,
            "zero_core_changes": audit.portability_passed,
            "autoconfiguration_target": synth.autoconfiguration_coverage >= 0.80,
            "manual_decision_target": len(synth.manual_decisions) <= 15,
        }
        passed = all(checks.values())
        return AutoPortQualificationReport(
            passed=passed,
            catalog_contract_alignment=True,
            execution_candidate_identified=checks["execution_candidate_identified"],
            metrology_candidate_identified=checks["metrology_candidate_identified"],
            wrong_candidate_rejected=checks["wrong_candidate_rejected"],
            execution_binding_valid=exec_valid.passed,
            metrology_binding_valid=metro_valid.passed,
            runtime_repository_execution=runtime_repository_execution,
            boolean_normalization=boolean_normalization,
            binding_integrity_enforced=integrity_enforced,
            sql_capability_probe=dialect.passed,
            zero_core_changes=audit.portability_passed,
            autoconfiguration_coverage=synth.autoconfiguration_coverage,
            manual_decision_count=len(synth.manual_decisions),
            generated_dataset_count=len(synth.accepted_datasets),
            details={
                "checks": checks,
                "execution_proposal": exec_prop.to_dict(),
                "metrology_proposal": metro_prop.to_dict(),
                "wrong_candidate": wrong_prop.to_dict(),
                "synthesis": synth.to_dict(),
                "dialect": dialect.to_dict(),
                "runtime_rows": {"incremental": len(incremental), "by_ids": len(by_ids)},
                "boolean_values": sorted(flag_values),
            },
        )


def write_qualification(path: str | Path) -> AutoPortQualificationReport:
    report = run_autopilot_qualification()
    Path(path).write_text(json.dumps(report.to_dict(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return report
