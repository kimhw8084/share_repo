from __future__ import annotations

import sqlite3
from pathlib import Path

from ephi.autopilot.models import PhysicalColumnProfile, PhysicalTableProfile


class SqliteTableInspector:
    """Portable bounded profiler used by the hostile AutoPort qualification.

    Company/OpenCode integrations can produce the same PhysicalTableProfile from the
    approved Big Data metadata/statistics APIs without using SQLite.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = str(path)

    def find_tables(self, hint: str | None = None, *, limit: int = 20) -> tuple[str, ...]:
        con = sqlite3.connect(self.path)
        try:
            names = [row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()]
        finally:
            con.close()
        if hint:
            tokens = [t.lower() for t in hint.replace("_", " ").split() if t]
            names.sort(key=lambda name: sum(1 for t in tokens if t in name.lower()), reverse=True)
        return tuple(names[:limit])

    def profile(self, table_name: str, *, sample_rows: int = 50) -> PhysicalTableProfile:
        if not table_name.replace("_", "").isalnum():
            raise ValueError("unsafe SQLite table name")
        con = sqlite3.connect(self.path)
        try:
            info = con.execute(f'PRAGMA table_info("{table_name}")').fetchall()
            if not info:
                raise KeyError(f"table not found: {table_name}")
            row_count = int(con.execute(f'SELECT COUNT(*) FROM "{table_name}"').fetchone()[0])
            sample = con.execute(f'SELECT * FROM "{table_name}" LIMIT ?', (sample_rows,)).fetchall()
            column_names = [row[1] for row in info]
            sample_records = tuple(dict(zip(column_names, row)) for row in sample)
            columns: list[PhysicalColumnProfile] = []
            for idx, (_, name, type_name, *_rest) in enumerate(info):
                nulls = int(con.execute(f'SELECT COUNT(*) FROM "{table_name}" WHERE "{name}" IS NULL').fetchone()[0])
                distinct = int(con.execute(f'SELECT COUNT(DISTINCT "{name}") FROM "{table_name}"').fetchone()[0])
                vals = tuple(row[idx] for row in sample[:20])
                columns.append(PhysicalColumnProfile(name, type_name or "UNKNOWN", nulls / row_count if row_count else 0.0, distinct, vals))
            return PhysicalTableProfile(table_name, tuple(columns), row_count=row_count, sampled_rows=min(row_count, sample_rows), sample_records=sample_records)
        finally:
            con.close()
