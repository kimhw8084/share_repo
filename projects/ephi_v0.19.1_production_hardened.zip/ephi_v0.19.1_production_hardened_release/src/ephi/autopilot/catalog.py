from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from ephi.audit_contracts import DEFAULT_DATASET_CONTRACTS


class Criticality(StrEnum):
    REQUIRED = "REQUIRED"
    HIGH_VALUE = "HIGH_VALUE"
    OPTIONAL = "OPTIONAL"


@dataclass(frozen=True, slots=True)
class SemanticFieldSpec:
    name: str
    meaning: str
    aliases: tuple[str, ...] = ()
    type_family: str | None = None
    criticality: Criticality = Criticality.OPTIONAL
    recognition_hints: tuple[str, ...] = ()
    validation_hints: tuple[str, ...] = ()
    warning_signs: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class DatasetRequirement:
    logical_name: str
    purpose: tuple[str, ...]
    fields: tuple[SemanticFieldSpec, ...]
    tier: str
    capability_when_missing: str

    def field(self, name: str) -> SemanticFieldSpec:
        return next(item for item in self.fields if item.name == name)


def _field(name: str, meaning: str, *, aliases: tuple[str, ...] = (), type_family: str | None = None,
           required: bool = False, high_value: bool = False, recognition: tuple[str, ...] = (),
           validation: tuple[str, ...] = (), warnings: tuple[str, ...] = ()) -> SemanticFieldSpec:
    criticality = Criticality.REQUIRED if required else Criticality.HIGH_VALUE if high_value else Criticality.OPTIONAL
    return SemanticFieldSpec(name, meaning, aliases, type_family, criticality, recognition, validation, warnings)


_COMMON: dict[str, SemanticFieldSpec] = {
    "asset_id": _field("asset_id", "stable equipment identity", aliases=("eqp_id", "equipment_id", "tool_id", "machine_id", "mch_id"), type_family="string", required=True, validation=("moderate cardinality", "stable across time")),
    "process_unit_id": _field("process_unit_id", "optional process/measurement unit below equipment", aliases=("chamber_id", "unit_id", "head_id", "module_id"), type_family="string", high_value=True, validation=("few stable values per asset",), warnings=("do not invent a chamber where equipment has no sub-unit",)),
    "material_id": _field("material_id", "globally stable wafer/material identity", aliases=("wafer_id", "material_id", "substrate_id", "wafer_key"), type_family="string", required=True, validation=("joins across process and measurement history", "high cardinality"), warnings=("wafer number 1-25 usually requires lot + wafer composite",)),
    "event_time": _field("event_time", "physical event or measurement time", aliases=("event_time", "start_time", "end_time", "finish_ts", "finish_time", "end_ts", "meas_time", "measure_time", "proc_time"), type_family="timestamp", required=True, validation=("must not be inferred from warehouse load time when physical time exists",)),
    "available_at": _field("available_at", "time record became knowable to EPHI", aliases=("available_at", "load_dttm", "ingest_time", "create_dttm", "update_time"), type_family="timestamp", required=True, validation=("normally >= event_time", "required for strict historical replay")),
}


def _req(logical: str, purpose: tuple[str, ...], tier: str, missing: str, fields: list[SemanticFieldSpec]) -> DatasetRequirement:
    return DatasetRequirement(logical, purpose, tuple(fields), tier, missing)


DEFAULT_REQUIREMENTS: tuple[DatasetRequirement, ...] = (
    _req("assets", ("resolve equipment identity and hierarchy",), "A", "EPHI can infer assets from executions provisionally", [
        _COMMON["asset_id"],
        _field("family_id", "equipment family", aliases=("family_id", "eqp_type", "model", "family"), type_family="string", high_value=True),
        _field("asset_type", "asset semantic type", aliases=("asset_type", "eqp_type", "type"), type_family="string"),
        _field("parent_asset_id", "parent in asset hierarchy", aliases=("parent_id", "parent_asset_id", "eqp_id"), type_family="string"),
    ]),
    _req("executions", ("anchor process history", "attach signals, material, route and context"), "A", "behavioral analysis is unavailable", [
        _field("execution_id", "unique process-execution identity", aliases=("execution_id", "hist_id", "run_id", "run_key", "proc_id", "event_id"), type_family="string", required=True, validation=("near-unique at execution grain",)),
        _COMMON["asset_id"], _COMMON["process_unit_id"], _COMMON["event_time"], _COMMON["available_at"],
        _field("operation", "manufacturing operation", aliases=("oper_id", "operation", "step", "operation_id"), type_family="string", high_value=True),
        _field("recipe_id", "recipe/process program", aliases=("recipe_id", "rcp_id", "recipe", "program_id"), type_family="string", high_value=True),
        _field("product_id", "product/device", aliases=("product_id", "prod_id", "device_id", "product"), type_family="string", high_value=True),
        _field("technology", "technology/process node", aliases=("technology", "tech_id", "tech"), type_family="string"),
        _field("material_id", "globally stable wafer/material identity", aliases=("wafer_id", "material_id", "substrate_id", "wafer_key"), type_family="string", high_value=True, validation=("joins across process and measurement history", "high cardinality"), warnings=("wafer number 1-25 usually requires lot + wafer composite",)),
        _field("source_revision", "source correction/revision identity", aliases=("source_revision", "revision", "version", "update_seq"), type_family="string"),
    ]),
    _req("signals", ("FDC scalar behavioral health",), "A", "FDC scalar capability unavailable", [
        _field("execution_id", "execution foreign key", aliases=("execution_id", "hist_id", "run_id", "proc_id"), type_family="string", required=True),
        _field("signal_id", "FDC parameter/signal identity", aliases=("signal_id", "param_id", "parameter", "tag_name", "sensor_id"), type_family="string", required=True),
        _field("value", "numeric signal summary", aliases=("value", "param_value", "mean_value", "avg_value", "result"), type_family="number", required=True),
        _COMMON["available_at"], _COMMON["event_time"], _COMMON["asset_id"],
        _field("step_id", "recipe step", aliases=("step_id", "step", "phase_id"), type_family="string", high_value=True),
        _field("unit", "engineering unit", aliases=("unit", "uom", "eng_unit"), type_family="string", high_value=True),
    ]),
    _req("traces", ("selective raw-trace escalation",), "D", "raw trace analysis unavailable; scalar path continues", [
        _field("execution_id", "execution foreign key", aliases=("execution_id", "hist_id", "run_id"), type_family="string", required=True),
        _field("signal_id", "trace signal identity", aliases=("signal_id", "param_id", "tag_name"), type_family="string", required=True),
        _COMMON["available_at"],
        _field("sample_time", "trace sample time", aliases=("sample_time", "timestamp", "trace_time"), type_family="timestamp", high_value=True),
        _field("sample_index", "trace sample order", aliases=("sample_index", "sample_no", "idx"), type_family="integer", high_value=True),
        _field("value", "trace value", aliases=("value", "sample_value"), type_family="number", high_value=True),
    ]),
    _req("metrology", ("metrology health", "process-vs-measurement-system discrimination", "spatial signatures"), "A", "metrology flagship unavailable", [
        _field("measurement_id", "unique measurement-row identity", aliases=("measurement_id", "meas_id", "result_id", "hist_id"), type_family="string", required=True),
        _COMMON["material_id"],
        _field("subject_id", "measurement equipment/head producing result", aliases=("subject_id", "eqp_id", "tool_id", "head_id", "module_id"), type_family="string", required=True),
        _field("characteristic_id", "measured characteristic", aliases=("characteristic_id", "item_id", "item_cd", "parameter", "measure_item"), type_family="string", required=True),
        _field("value", "numeric measurement value", aliases=("value", "meas_val", "result_value", "measurement"), type_family="number", required=True),
        _COMMON["event_time"], _COMMON["available_at"],
        _field("x", "wafer X coordinate", aliases=("x", "x_pos", "x_coord"), type_family="number", high_value=True),
        _field("y", "wafer Y coordinate", aliases=("y", "y_pos", "y_coord"), type_family="number", high_value=True),
        _field("site_id", "measurement site identity", aliases=("site_id", "site", "point_id"), type_family="string", high_value=True),
        _field("is_reference_material", "reference/control wafer flag", aliases=("is_reference_material", "ref_yn", "reference_flag", "wafer_type"), type_family="boolean", high_value=True, recognition=("values often Y/N, REF/PROD, 0/1",)),
        _field("remeasure_group_id", "links repeated measurements of same target", aliases=("remeasure_group_id", "remeas_id", "repeat_group"), type_family="string", high_value=True),
        _field("attempt_index", "remeasure attempt order", aliases=("attempt_index", "attempt_no", "remeas_seq"), type_family="integer"),
        _field("recipe_id", "measurement recipe/method", aliases=("recipe_id", "rcp_id", "method_id"), type_family="string", high_value=True),
    ]),
    _req("quality", ("estimate whether equipment state is harmful",), "B", "health detection continues without quality harmfulness", [
        _COMMON["material_id"],
        _field("characteristic", "quality/yield target", aliases=("characteristic", "item_id", "metric", "test_name"), type_family="string", required=True),
        _field("value", "quality result", aliases=("value", "result", "metric_value"), type_family="number", required=True),
        _COMMON["event_time"], _COMMON["available_at"],
        _field("spec_low", "lower specification limit", aliases=("spec_low", "lsl", "lower_limit"), type_family="number", high_value=True),
        _field("spec_high", "upper specification limit", aliases=("spec_high", "usl", "upper_limit"), type_family="number", high_value=True),
    ]),
    _req("maintenance", ("separate maintenance transitions", "build asset epochs"), "B", "maintenance hypotheses are reduced", [
        _field("maintenance_event_id", "unique maintenance identity", aliases=("maintenance_event_id", "pm_id", "work_order_id", "event_id"), type_family="string", required=True),
        _COMMON["asset_id"],
        _field("event_type", "PM/calibration/repair/replacement classification", aliases=("event_type", "pm_type", "maint_type", "action_type"), type_family="string", required=True),
        _COMMON["event_time"], _COMMON["available_at"],
        _COMMON["process_unit_id"],
        _field("component_id", "replaced/serviced component", aliases=("component_id", "part_id", "component"), type_family="string", high_value=True),
        _field("action", "maintenance action text/code", aliases=("action", "work_desc", "action_code"), type_family="string", high_value=True),
    ]),
    _req("genealogy", ("trace upstream/downstream material commonality",), "C", "genealogy RCA unavailable", [
        _field("parent_material_id", "upstream material identity", aliases=("parent_material_id", "parent_id", "source_wafer_id"), type_family="string", required=True),
        _field("child_material_id", "downstream material identity", aliases=("child_material_id", "child_id", "target_wafer_id"), type_family="string", required=True),
        _COMMON["available_at"],
        _field("relation_type", "genealogy relationship", aliases=("relation_type", "relation", "link_type"), type_family="string", high_value=True),
    ]),
    _req("wip", ("current/future exposure and preventability",), "C", "WIP priority/preventability unavailable", [
        _COMMON["material_id"], _COMMON["available_at"],
        _field("operation", "current/next operation", aliases=("operation", "oper_id", "current_oper"), type_family="string", high_value=True),
        _field("queued_asset_id", "committed/queued equipment", aliases=("queued_asset_id", "eqp_id", "assigned_tool"), type_family="string", high_value=True),
        _field("eligible_asset_ids", "qualified alternatives", aliases=("eligible_asset_ids", "candidate_tools", "qualified_eqps"), type_family="string", high_value=True),
    ]),
    _req("asset_qualification", ("validate alternative-resource eligibility",), "C", "preventable-routing recommendations unavailable", [
        _COMMON["asset_id"],
        _field("operation", "operation qualification", aliases=("operation", "oper_id"), type_family="string", required=True),
        _COMMON["available_at"],
        _field("qualified", "whether asset is qualified", aliases=("qualified", "qual_yn", "status"), type_family="boolean", high_value=True),
    ]),
    _req("historical_cases", ("historical analogue and RCA memory",), "C", "historical intelligence unavailable", [
        _field("case_id", "investigation/case identity", aliases=("case_id", "rca_id", "ticket_id", "issue_id"), type_family="string", required=True),
        _field("opened_at", "case opening/event time", aliases=("opened_at", "open_time", "created_at"), type_family="timestamp", required=True),
        _COMMON["available_at"],
        _COMMON["asset_id"],
        _field("root_cause_category", "curated root-cause category", aliases=("root_cause_category", "cause_code", "rca_category"), type_family="string", high_value=True),
        _field("resolution_summary", "resolution/action summary", aliases=("resolution_summary", "resolution", "close_comment"), type_family="string", high_value=True),
    ]),
)


def requirement(logical_name: str) -> DatasetRequirement:
    try:
        return next(item for item in DEFAULT_REQUIREMENTS if item.logical_name == logical_name)
    except StopIteration as exc:
        raise KeyError(logical_name) from exc


def assert_catalog_matches_contracts() -> None:
    catalog = {item.logical_name: item for item in DEFAULT_REQUIREMENTS}
    for contract in DEFAULT_DATASET_CONTRACTS:
        req = catalog[contract.logical_name]
        names = {field.name for field in req.fields}
        missing = set(contract.required_columns) - names
        if missing:
            raise AssertionError(f"AutoPort catalog missing {contract.logical_name}: {sorted(missing)}")
