from __future__ import annotations

import sqlite3
from datetime import date, datetime
from pathlib import Path
from typing import Any, Iterable, Mapping


def _sqlite_value(value: Any) -> Any:
    if isinstance(value, datetime):
        # Stable lexicographic representation for reference runtime tests.
        return value.isoformat(sep=" ")
    if isinstance(value, date):
        return value.isoformat()
    return value


class SqliteSqlExecutor:
    """Portable reference SQL executor for runtime/qualification tests only."""

    def __init__(self, path: str | Path) -> None:
        self.path = str(path)

    def query_sql_arrow(self, sql: str, parameters: Mapping[str, Any]):
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        try:
            cur = con.execute(sql, {k: _sqlite_value(v) for k, v in parameters.items()})
            return [dict(row) for row in cur.fetchall()]
        finally:
            con.close()

    def stream_sql_arrow(self, sql: str, parameters: Mapping[str, Any], *, batch_rows: int = 65_536) -> Iterable:
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        try:
            cur = con.execute(sql, {k: _sqlite_value(v) for k, v in parameters.items()})
            while True:
                rows = cur.fetchmany(batch_rows)
                if not rows:
                    break
                yield [dict(row) for row in rows]
        finally:
            con.close()
