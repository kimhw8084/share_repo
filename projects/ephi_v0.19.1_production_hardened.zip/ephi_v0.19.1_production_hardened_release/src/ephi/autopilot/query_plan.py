from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class QueryPlanAssessment:
    passed: bool
    blockers: tuple[str, ...]
    observations: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return {"passed": self.passed, "blockers": list(self.blockers), "observations": list(self.observations)}


def assess_query_plan(plan_text: str, *, allow_full_scan: bool = False) -> QueryPlanAssessment:
    text = plan_text.lower()
    blockers: list[str] = []
    observations: list[str] = []
    full_scan_tokens = ("full table scan", "table scan", "seq scan")
    if any(token in text for token in full_scan_tokens):
        observations.append("plan reports table/sequence scan")
        if not allow_full_scan:
            blockers.append("unbounded/full table scan detected in query plan")
    if any(token in text for token in ("index", "partition", "predicate", "filter")):
        observations.append("plan contains pushdown/index/partition evidence")
    return QueryPlanAssessment(not blockers, tuple(blockers), tuple(observations))
