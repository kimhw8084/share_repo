from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Any, Mapping

import yaml


class MappingDisposition(StrEnum):
    AUTO_CONFIRMED = "AUTO_CONFIRMED"
    REVIEW_RECOMMENDED = "REVIEW_RECOMMENDED"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"
    UNRESOLVED = "UNRESOLVED"


@dataclass(frozen=True, slots=True)
class PhysicalColumnProfile:
    name: str
    type_name: str
    null_fraction: float | None = None
    distinct_count: int | None = None
    sample_values: tuple[Any, ...] = ()


@dataclass(frozen=True, slots=True)
class PhysicalTableProfile:
    table_name: str
    columns: tuple[PhysicalColumnProfile, ...]
    row_count: int | None = None
    sampled_rows: int = 0
    source_hint: str | None = None
    sample_records: tuple[Mapping[str, Any], ...] = ()

    def schema_fingerprint(self) -> str:
        payload = json.dumps(
            [(c.name, c.type_name) for c in self.columns],
            sort_keys=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class FieldMappingProposal:
    logical_field: str
    physical_expression: str | None
    confidence: float
    disposition: MappingDisposition
    reasons: tuple[str, ...] = ()
    normalization: str | None = None


@dataclass(frozen=True, slots=True)
class DatasetMappingProposal:
    logical_dataset: str
    physical_table: str
    fields: tuple[FieldMappingProposal, ...]
    confidence: float
    missing_required: tuple[str, ...] = ()
    review_items: tuple[str, ...] = ()
    source_schema_fingerprint: str | None = None
    source_column_types: Mapping[str, str] = field(default_factory=dict)

    def mapping(self) -> dict[str, str]:
        return {
            item.logical_field: item.physical_expression
            for item in self.fields
            if item.physical_expression
        }

    def field(self, name: str) -> FieldMappingProposal | None:
        return next((x for x in self.fields if x.logical_field == name), None)

    def to_dict(self) -> dict[str, object]:
        return {
            "logical_dataset": self.logical_dataset,
            "physical_table": self.physical_table,
            "confidence": self.confidence,
            "missing_required": list(self.missing_required),
            "review_items": list(self.review_items),
            "source_schema_fingerprint": self.source_schema_fingerprint,
            "fields": [
                {
                    "logical_field": f.logical_field,
                    "physical_expression": f.physical_expression,
                    "confidence": f.confidence,
                    "disposition": f.disposition,
                    "reasons": list(f.reasons),
                    "normalization": f.normalization,
                }
                for f in self.fields
            ],
        }


@dataclass(frozen=True, slots=True)
class SqlBindingManifest:
    logical_dataset: str
    physical_table: str
    sql: str
    columns: Mapping[str, str]
    partition_column: str | None = None
    partition_source_field: str | None = None
    partition_granularity: str | None = None
    watermark_column: str | None = None
    knowledge_time_column: str | None = None
    confidence: float = 0.0
    review_items: tuple[str, ...] = ()
    source_schema_fingerprint: str | None = None
    # Kept for backward compatibility with v0.19 manifests; new runtime compilation
    # does not require source predicates to exist inside binding SQL.
    parameter_sources: Mapping[str, tuple[str, str]] = field(default_factory=dict)

    def stable_hash(self) -> str:
        payload = json.dumps(
            {
                "logical_dataset": self.logical_dataset,
                "physical_table": self.physical_table,
                "sql": self.sql,
                "columns": dict(self.columns),
                "partition_column": self.partition_column,
                "partition_source_field": self.partition_source_field,
                "partition_granularity": self.partition_granularity,
                "watermark_column": self.watermark_column,
                "knowledge_time_column": self.knowledge_time_column,
                "confidence": self.confidence,
                "review_items": list(self.review_items),
                "source_schema_fingerprint": self.source_schema_fingerprint,
                "parameter_sources": {k: list(v) for k, v in self.parameter_sources.items()},
            },
            sort_keys=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(payload.encode()).hexdigest()

    def to_dict(self) -> dict[str, object]:
        return {
            "logical_dataset": self.logical_dataset,
            "physical_table": self.physical_table,
            "sql": self.sql,
            "columns": dict(self.columns),
            "partition_column": self.partition_column,
            "partition_source_field": self.partition_source_field,
            "partition_granularity": self.partition_granularity,
            "watermark_column": self.watermark_column,
            "knowledge_time_column": self.knowledge_time_column,
            "confidence": self.confidence,
            "review_items": list(self.review_items),
            "source_schema_fingerprint": self.source_schema_fingerprint,
            "parameter_sources": {k: list(v) for k, v in self.parameter_sources.items()},
            "binding_hash": self.stable_hash(),
        }

    def save(self, path: str | Path) -> None:
        Path(path).write_text(yaml.safe_dump(self.to_dict(), sort_keys=False), encoding="utf-8")


@dataclass(frozen=True, slots=True)
class AutoPortSynthesis:
    accepted_datasets: tuple[str, ...]
    unavailable_datasets: tuple[str, ...]
    generated_config: Mapping[str, object]
    manual_decisions: tuple[str, ...]
    autoconfiguration_coverage: float
    core_changes_required: int = 0

    def to_dict(self) -> dict[str, object]:
        return {
            "accepted_datasets": list(self.accepted_datasets),
            "unavailable_datasets": list(self.unavailable_datasets),
            "generated_config": dict(self.generated_config),
            "manual_decisions": list(self.manual_decisions),
            "manual_decision_count": len(self.manual_decisions),
            "autoconfiguration_coverage": self.autoconfiguration_coverage,
            "core_changes_required": self.core_changes_required,
        }


_BINDING_KEYS = {
    "logical_dataset",
    "physical_table",
    "sql",
    "columns",
    "partition_column",
    "partition_source_field",
    "partition_granularity",
    "watermark_column",
    "knowledge_time_column",
    "confidence",
    "review_items",
    "source_schema_fingerprint",
    "parameter_sources",
    "binding_hash",
}
_REQUIRED_BINDING_KEYS = {"logical_dataset", "physical_table", "sql", "columns"}


def load_sql_binding(path: str | Path, *, verify_hash: bool = True) -> SqlBindingManifest:
    path = Path(path)
    try:
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"binding file not found: {path}") from exc
    except yaml.YAMLError as exc:
        raise ValueError(f"invalid binding YAML {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError(f"binding root must be a mapping: {path}")
    unknown = sorted(set(payload) - _BINDING_KEYS)
    if unknown:
        raise ValueError(f"unknown binding keys in {path}: {', '.join(unknown)}")
    missing = sorted(_REQUIRED_BINDING_KEYS - set(payload))
    if missing:
        raise ValueError(f"missing binding keys in {path}: {', '.join(missing)}")
    if not isinstance(payload.get("columns"), dict):
        raise ValueError(f"binding columns must be a mapping: {path}")
    raw_parameter_sources = payload.get("parameter_sources") or {}
    if not isinstance(raw_parameter_sources, dict):
        raise ValueError(f"parameter_sources must be a mapping: {path}")
    try:
        binding = SqlBindingManifest(
            logical_dataset=str(payload["logical_dataset"]),
            physical_table=str(payload["physical_table"]),
            sql=str(payload["sql"]),
            columns={str(k): str(v) for k, v in payload["columns"].items()},
            partition_column=payload.get("partition_column"),
            partition_source_field=payload.get("partition_source_field"),
            partition_granularity=payload.get("partition_granularity"),
            watermark_column=payload.get("watermark_column"),
            knowledge_time_column=payload.get("knowledge_time_column"),
            confidence=float(payload.get("confidence", 0.0)),
            review_items=tuple(str(x) for x in (payload.get("review_items") or ())),
            source_schema_fingerprint=payload.get("source_schema_fingerprint"),
            parameter_sources={str(k): tuple(str(x) for x in v) for k, v in raw_parameter_sources.items()},
        )
    except (TypeError, ValueError) as exc:
        raise ValueError(f"invalid binding values in {path}: {exc}") from exc
    if verify_hash:
        expected = payload.get("binding_hash")
        if not expected:
            raise ValueError(f"binding_hash missing from {path}; run `ephi autopilot seal-binding`")
        actual = binding.stable_hash()
        if str(expected) != actual:
            raise ValueError(
                f"binding_hash mismatch for {path}; expected {expected}, computed {actual}. "
                "Review the edit, then run `ephi autopilot seal-binding`."
            )
    return binding
