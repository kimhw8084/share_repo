from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping


@dataclass(frozen=True, slots=True)
class DatasetSemanticMetrics:
    row_count: int
    critical_null_fraction: Mapping[str, float] = field(default_factory=dict)
    identity_duplicate_fraction: float = 0.0
    knowledge_time_violation_fraction: float = 0.0
    applicable_join_coverage: Mapping[str, float] = field(default_factory=dict)
    join_multiplication: Mapping[str, float] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class SemanticAcceptancePolicy:
    max_critical_null_fraction: float = 0.01
    max_identity_duplicate_fraction: float = 0.001
    max_knowledge_time_violation_fraction: float = 0.0
    min_join_coverage: float = 0.95
    max_join_multiplication: float = 5.0


@dataclass(frozen=True, slots=True)
class SemanticAcceptanceReport:
    passed: bool
    blockers: tuple[str, ...]
    warnings: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return {"passed": self.passed, "blockers": list(self.blockers), "warnings": list(self.warnings)}


def assess_semantic_metrics(metrics: DatasetSemanticMetrics, policy: SemanticAcceptancePolicy | None = None) -> SemanticAcceptanceReport:
    policy = policy or SemanticAcceptancePolicy()
    blockers: list[str] = []
    warnings: list[str] = []
    if metrics.row_count <= 0:
        blockers.append("dataset has no rows in qualification scope")
    for column, fraction in metrics.critical_null_fraction.items():
        if fraction > policy.max_critical_null_fraction:
            blockers.append(f"critical null fraction too high for {column}: {fraction:.6f}")
    if metrics.identity_duplicate_fraction > policy.max_identity_duplicate_fraction:
        blockers.append(f"identity duplicate fraction too high: {metrics.identity_duplicate_fraction:.6f}")
    if metrics.knowledge_time_violation_fraction > policy.max_knowledge_time_violation_fraction:
        blockers.append(f"knowledge-time violations present: {metrics.knowledge_time_violation_fraction:.6f}")
    for join_id, coverage in metrics.applicable_join_coverage.items():
        if coverage < policy.min_join_coverage:
            blockers.append(f"applicable join coverage too low for {join_id}: {coverage:.4f}")
    for join_id, factor in metrics.join_multiplication.items():
        if factor > policy.max_join_multiplication:
            blockers.append(f"join multiplication too high for {join_id}: {factor:.3f}x")
    return SemanticAcceptanceReport(not blockers, tuple(blockers), tuple(warnings))
