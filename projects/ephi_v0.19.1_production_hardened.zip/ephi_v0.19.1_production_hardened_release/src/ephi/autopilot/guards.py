from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class JoinExplosionAssessment:
    passed: bool
    left_rows: int
    right_rows: int
    joined_rows: int
    multiplication_factor: float
    max_factor: float
    reason: str

    def to_dict(self) -> dict[str, object]:
        return {
            "passed": self.passed,
            "left_rows": self.left_rows,
            "right_rows": self.right_rows,
            "joined_rows": self.joined_rows,
            "multiplication_factor": self.multiplication_factor,
            "max_factor": self.max_factor,
            "reason": self.reason,
        }


def assess_join_explosion(left_rows: int, right_rows: int, joined_rows: int, *, max_factor: float = 5.0) -> JoinExplosionAssessment:
    if min(left_rows, right_rows, joined_rows) < 0:
        raise ValueError("join row counts cannot be negative")
    baseline = max(1, min(left_rows or 1, right_rows or 1))
    factor = joined_rows / baseline
    passed = factor <= max_factor
    reason = "join multiplication within policy" if passed else "probable incomplete/non-unique join key; row multiplication exceeds policy"
    return JoinExplosionAssessment(passed, left_rows, right_rows, joined_rows, factor, max_factor, reason)


@dataclass(frozen=True, slots=True)
class QueryBudget:
    max_rows_returned: int = 1_000_000
    max_in_values: int = 10_000
    max_window_days: int = 366

    def validate(self) -> None:
        if min(self.max_rows_returned, self.max_in_values, self.max_window_days) <= 0:
            raise ValueError("query budget values must be positive")
