from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Mapping, Protocol


class SqlProbeExecutor(Protocol):
    def query_sql_arrow(self, sql: str, parameters: Mapping[str, Any]): ...


@dataclass(frozen=True, slots=True)
class SqlCapabilityCheck:
    name: str
    passed: bool
    error: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {"name": self.name, "passed": self.passed, "error": self.error}


@dataclass(frozen=True, slots=True)
class SqlCapabilityReport:
    passed: bool
    checks: tuple[SqlCapabilityCheck, ...]

    def to_dict(self) -> dict[str, object]:
        return {"passed": self.passed, "checks": [c.to_dict() for c in self.checks]}


def qualify_sql_executor(executor: SqlProbeExecutor) -> SqlCapabilityReport:
    probes = (
        ("basic_select", "SELECT 1 AS ephi_probe", {}),
        ("named_parameter", "SELECT :probe AS ephi_probe", {"probe": 7}),
        ("subquery", "SELECT ephi_probe FROM (SELECT 1 AS ephi_probe) AS q", {}),
        ("case_expression", "SELECT CASE WHEN 1 = 1 THEN 1 ELSE 0 END AS ephi_probe", {}),
        ("string_cast", "SELECT CAST(1 AS VARCHAR) AS ephi_probe", {}),
        ("null_projection", "SELECT CAST(NULL AS VARCHAR) AS ephi_probe", {}),
        ("timestamp_parameter", "SELECT :ts AS ephi_probe", {"ts": datetime(2026, 1, 1, 0, 0)}),
        ("limit_zero", "SELECT 1 AS ephi_probe LIMIT 0", {}),
    )
    checks: list[SqlCapabilityCheck] = []
    for name, sql, params in probes:
        try:
            executor.query_sql_arrow(sql, params)
            checks.append(SqlCapabilityCheck(name, True))
        except Exception as exc:
            checks.append(SqlCapabilityCheck(name, False, f"{type(exc).__name__}: {exc}"))
    return SqlCapabilityReport(all(c.passed for c in checks), tuple(checks))
