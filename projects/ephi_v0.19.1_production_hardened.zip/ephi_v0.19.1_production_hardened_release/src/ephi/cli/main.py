from __future__ import annotations

import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from ephi.audit import DataRealityAuditor, audit_parquet_root
from ephi.audit_contracts import DEFAULT_DATASET_CONTRACTS, DEFAULT_JOIN_CONTRACTS
from ephi.config import EphiConfig, load_config
from ephi.adapters.company.validation import validate_mapping_config
from ephi.runtime.replay import run_metrology_replay, run_synthetic_replay
from ephi.registry.releases import build_release_manifest
from ephi.qualification.bakeoff import run_bakeoff
from ephi.qualification.corpus import build_synthetic_golden_corpus, load_corpus, save_corpus
from ephi.qualification.evaluate import evaluate_corpus
from ephi.qualification.gates import QualificationGatePolicy, apply_gate_policy, load_gate_policy
from ephi.qualification.methods import builtin_methods
from ephi.qualification.stress import run_peer_poisoning_stress, run_reference_contamination_stress
from ephi.synthetic.factory import SyntheticConfig, generate_dataset
from ephi.synthetic.metrology import MetrologyScenarioConfig
from ephi.synthetic.scalar import ScalarScenarioConfig
from ephi.version import __version__
from ephi.quality.qualification import run_quality_qualification
from ephi.quality.targets import load_quality_target
from ephi.quality.gates import apply_quality_gate, load_quality_gate_policy
from ephi.exposure.qualification import run_exposure_priority_qualification
from ephi.history.qualification import run_history_rca_qualification
from ephi.value.costs import load_cost_model
from ephi.value.qualification import run_value_qualification
from ephi.operations.qualification import run_operations_qualification
from ephi.operations.deployment import load_deployment_plan, render_kubernetes_yaml
from ephi.operations.controls import OperationalControlService
from ephi.operations.certification import CertificationService
from ephi.operations.release import assess_release_compatibility
from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.operations import (
    ControlKind, ControlScope, FamilyQualificationManifest, RuntimeRole,
)
from ephi.registry.releases import ReleaseManifest
from ephi.domain.port import PortRunIdentity
from ephi.port.contract import REQUIRED_RUNTIME_FUNCTIONS, REQUIRED_RUNTIME_METHODS, validate_port_module
from ephi.port.orchestrator import PortBootstrapOrchestrator
from ephi.port.qualification import run_port_kit_qualification
from ephi.port.configuration import load_runtime_config
from ephi.onboarding.policy import load_onboarding_policy
from ephi.onboarding.planner import build_family_onboarding_plan, capability_report_from_payload
from ephi.onboarding.golden import GoldenCaseRegistry
from ephi.onboarding.promotion import PromotionEvidenceBuilder, family_manifest_from_packages
from ephi.onboarding.qualification import run_family_onboarding_qualification
from ephi.onboarding.control_qualification import run_qualification_control_plane_qualification
from ephi.domain.onboarding import GoldenCaseIntake, GoldenCurationState, FamilyOnboardingPlan, ShadowQualificationMetrics
from ephi.domain.benchmark import BenchmarkCorpus
from ephi.domain.operations import GateResult, CertificationState
from ephi.reliability.qualification import run_reliability_qualification
from ephi.reliability.policy import load_reliability_policy
from ephi.reliability.snapshot import (
    build_backup_bundle, load_backup_bundle, restore_backup_bundle, write_backup_bundle,
)
from ephi.domain.launch import (
    CampaignStage, EvidenceDecision, EvidenceProvenance, LaunchEvidenceKind, LaunchEvidenceReceipt,
    ProductionReplayManifest, ShadowLaunchDossier,
)
from ephi.launch.evidence import receipt_from_artifact
from ephi.launch.policy import load_launch_policy
from ephi.launch.dossier import build_shadow_launch_dossier
from ephi.launch.planner import build_metrology_shadow_launch_plan
from ephi.launch.golden import build_internal_golden_replay_manifest
from ephi.launch.qualification import run_launch_qualification
from ephi.launch.contract import validate_launch_module
from ephi.launch.execution import CampaignExecutionController
from ephi.launch.registry import ShadowLaunchWorkspaceRepository
from ephi.launch.reference_executor import ReferenceLaunchEvidenceExecutor
from ephi.launch.handoff import handoff_launch_dossier
from ephi.launch.execution_qualification import run_campaign_execution_qualification
from ephi.launch.observability import CampaignObservabilityService
from ephi.launch.observability_qualification import run_campaign_observability_qualification
from ephi.adapters.local.filesystem_artifact_store import FileSystemArtifactStore


def _config_from_args(paths: list[str] | None) -> EphiConfig:
    return load_runtime_config(paths)


def _cmd_version(_: argparse.Namespace) -> int:
    print(__version__)
    return 0


def _cmd_config_validate(args: argparse.Namespace) -> int:
    config = _config_from_args(args.config)
    print(json.dumps({"valid": True, "config_hash": config.stable_hash()}, indent=2))
    return 0


def _cmd_synthetic_generate(args: argparse.Namespace) -> int:
    outputs = generate_dataset(
        args.output,
        SyntheticConfig(
            n_assets=args.assets,
            executions_per_asset=args.executions_per_asset,
            seed=args.seed,
            scenario=args.scenario,
        ),
    )
    print(json.dumps({name: str(path) for name, path in outputs.items()}, indent=2))
    return 0


def _cmd_data_audit(args: argparse.Namespace) -> int:
    if args.semantic:
        from ephi.adapters.local.duckdb_audit import DuckDBParquetAuditBackend

        root = Path(args.root)
        datasets = {path.stem: path for path in root.glob("*.parquet")}
        report = DataRealityAuditor(DuckDBParquetAuditBackend(datasets)).run(
            DEFAULT_DATASET_CONTRACTS,
            DEFAULT_JOIN_CONTRACTS,
        )
        print(json.dumps(report.to_dict(), indent=2, default=str))
    else:
        print(json.dumps(audit_parquet_root(args.root), indent=2, default=str))
    return 0


def _cmd_data_contracts(_: argparse.Namespace) -> int:
    payload = {
        "datasets": [
            {
                "logical_name": item.logical_name,
                "role": item.role,
                "required_columns": list(item.required_columns),
                "optional_columns": list(item.optional_columns),
                "identity_columns": list(item.identity_columns),
                "event_time_column": item.event_time_column,
                "available_at_column": item.available_at_column,
                "revision_column": item.revision_column,
            }
            for item in DEFAULT_DATASET_CONTRACTS
        ],
        "joins": [
            {
                "join_id": item.join_id,
                "left_dataset": item.left_dataset,
                "right_dataset": item.right_dataset,
                "left_keys": list(item.left_keys),
                "right_keys": list(item.right_keys),
                "required_for": [str(capability) for capability in item.required_for],
            }
            for item in DEFAULT_JOIN_CONTRACTS
        ],
    }
    print(json.dumps(payload, indent=2, default=str))
    return 0


def _cmd_data_mapping_validate(args: argparse.Namespace) -> int:
    config = _config_from_args(args.config)
    results = validate_mapping_config(config.data, DEFAULT_DATASET_CONTRACTS)
    payload = {
        "config_hash": config.stable_hash(),
        "datasets": [
            {
                "logical_name": item.logical_name,
                "state": item.state,
                "physical_name": item.physical_name,
                "missing_required_mappings": list(item.missing_required_mappings),
                "missing_optional_mappings": list(item.missing_optional_mappings),
            }
            for item in results
        ],
    }
    print(json.dumps(payload, indent=2, default=str))
    return 0




def _cmd_autopilot_catalog(args: argparse.Namespace) -> int:
    from ephi.autopilot.catalog import DEFAULT_REQUIREMENTS
    payload = {"datasets": [
        {"logical_name": r.logical_name, "tier": r.tier, "purpose": list(r.purpose),
         "capability_when_missing": r.capability_when_missing,
         "fields": [{"name": f.name, "meaning": f.meaning, "aliases": list(f.aliases),
                     "type_family": f.type_family, "criticality": f.criticality,
                     "recognition_hints": list(f.recognition_hints),
                     "validation_hints": list(f.validation_hints),
                     "warning_signs": list(f.warning_signs)} for f in r.fields]}
        for r in DEFAULT_REQUIREMENTS]}
    text = json.dumps(payload, indent=2, default=str)
    if args.output:
        Path(args.output).write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0


def _profile_to_payload(profile) -> dict[str, object]:
    return {"table_name": profile.table_name, "row_count": profile.row_count, "sampled_rows": profile.sampled_rows,
            "source_hint": profile.source_hint, "sample_records": list(profile.sample_records),
            "columns": [{"name": c.name, "type_name": c.type_name, "null_fraction": c.null_fraction,
                         "distinct_count": c.distinct_count, "sample_values": list(c.sample_values)} for c in profile.columns]}


def _profile_from_payload(payload):
    from ephi.autopilot.models import PhysicalColumnProfile, PhysicalTableProfile
    return PhysicalTableProfile(
        table_name=str(payload["table_name"]), row_count=payload.get("row_count"),
        sampled_rows=int(payload.get("sampled_rows", 0)), source_hint=payload.get("source_hint"),
        sample_records=tuple(payload.get("sample_records") or ()),
        columns=tuple(PhysicalColumnProfile(
            name=str(c["name"]), type_name=str(c.get("type_name", "UNKNOWN")),
            null_fraction=c.get("null_fraction"), distinct_count=c.get("distinct_count"),
            sample_values=tuple(c.get("sample_values") or ()),
        ) for c in payload.get("columns", [])),
    )


def _cmd_autopilot_inspect(args: argparse.Namespace) -> int:
    from ephi.autopilot.inspect import SqliteTableInspector
    profile = SqliteTableInspector(args.sqlite_db).profile(args.table, sample_rows=args.sample_rows)
    text = json.dumps(_profile_to_payload(profile), indent=2, default=str)
    if args.output:
        Path(args.output).write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0


def _build_autopilot_inspector(args):
    if getattr(args, "sqlite_db", None):
        from ephi.autopilot.inspect import SqliteTableInspector
        return SqliteTableInspector(args.sqlite_db)
    import importlib
    module = importlib.import_module(args.inspector_module)
    if not hasattr(module, "build_schema_inspector"):
        raise SystemExit("inspector module must expose build_schema_inspector(config)")
    return module.build_schema_inspector(_config_from_args(args.config))


def _cmd_autopilot_discover(args: argparse.Namespace) -> int:
    from ephi.autopilot.inference import rank_dataset_candidates
    inspector = _build_autopilot_inspector(args)
    if not hasattr(inspector, "find_tables"):
        raise SystemExit("schema inspector must implement find_tables(hint, limit)")
    names = inspector.find_tables(args.hint, limit=args.limit)
    profiles = tuple(inspector.profile(name, sample_rows=args.sample_rows) if hasattr(inspector, "profile") else inspector.profile_table(name, sample_rows=args.sample_rows) for name in names)
    ranked = rank_dataset_candidates(args.dataset, profiles)
    payload = {"dataset": args.dataset, "hint": args.hint, "candidates": [p.to_dict() for p in ranked]}
    text = json.dumps(payload, indent=2, default=str)
    if args.output:
        Path(args.output).write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if ranked and not ranked[0].missing_required else 2


def _cmd_autopilot_candidate(args: argparse.Namespace) -> int:
    from ephi.autopilot.inference import infer_dataset_mapping, proposal_to_sql_binding
    inspector = _build_autopilot_inspector(args)
    profile = inspector.profile(args.table, sample_rows=args.sample_rows) if hasattr(inspector, "profile") else inspector.profile_table(args.table, sample_rows=args.sample_rows)
    proposal = infer_dataset_mapping(args.dataset, profile)
    payload: dict[str, object] = {"profile": _profile_to_payload(profile), "proposal": proposal.to_dict()}
    if not proposal.missing_required:
        binding = proposal_to_sql_binding(
            proposal, partition_column=args.partition_column,
            partition_source_field=args.partition_source_field,
            partition_granularity=args.partition_granularity,
            watermark_column=args.watermark_column,
        )
        from ephi.autopilot.validation import validate_sql_binding
        validation = validate_sql_binding(binding)
        payload["binding"] = binding.to_dict()
        payload["validation"] = validation.to_dict()
        if args.output_binding:
            binding.save(args.output_binding)
    text = json.dumps(payload, indent=2, default=str)
    if args.output:
        Path(args.output).write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if not proposal.missing_required and payload.get("validation", {}).get("passed", True) else 2


def _cmd_autopilot_propose(args: argparse.Namespace) -> int:
    from ephi.autopilot.inference import infer_dataset_mapping, proposal_to_sql_binding
    payload = json.loads(Path(args.profile).read_text(encoding="utf-8"))
    proposal = infer_dataset_mapping(args.dataset, _profile_from_payload(payload))
    out = {"proposal": proposal.to_dict()}
    if not proposal.missing_required:
        binding = proposal_to_sql_binding(
            proposal, partition_column=args.partition_column,
            partition_source_field=args.partition_source_field,
            partition_granularity=args.partition_granularity,
            watermark_column=args.watermark_column,
        )
        from ephi.autopilot.validation import validate_sql_binding
        validation = validate_sql_binding(binding)
        out["binding"] = binding.to_dict()
        out["validation"] = validation.to_dict()
        if args.output_binding:
            binding.save(args.output_binding)
    text = json.dumps(out, indent=2, default=str)
    if args.output:
        Path(args.output).write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if not proposal.missing_required and out.get("validation", {}).get("passed", True) else 2


def _cmd_autopilot_validate_binding(args: argparse.Namespace) -> int:
    from ephi.autopilot.models import load_sql_binding
    from ephi.autopilot.validation import validate_sql_binding
    result = validate_sql_binding(load_sql_binding(args.binding))
    print(json.dumps(result.to_dict(), indent=2))
    return 0 if result.passed else 2



def _cmd_autopilot_seal_binding(args: argparse.Namespace) -> int:
    from dataclasses import replace
    from ephi.autopilot.models import load_sql_binding
    from ephi.autopilot.validation import validate_sql_binding

    binding = load_sql_binding(args.binding, verify_hash=False)
    resolved = set(args.resolve_review or ())
    unknown = sorted(resolved - set(binding.review_items))
    if unknown:
        raise ValueError("review acknowledgement not present in binding: " + "; ".join(unknown))
    if resolved:
        binding = replace(binding, review_items=tuple(x for x in binding.review_items if x not in resolved))
    result = validate_sql_binding(binding)
    if not result.passed:
        print(json.dumps(result.to_dict(), indent=2))
        return 2
    binding.save(args.binding)
    payload = {"sealed": True, "binding": str(args.binding), "binding_hash": binding.stable_hash(), "remaining_review_items": list(binding.review_items), "validation": result.to_dict()}
    print(json.dumps(payload, indent=2))
    return 0

def _cmd_autopilot_synthesize(args: argparse.Namespace) -> int:
    import yaml
    from ephi.autopilot.models import load_sql_binding
    from ephi.autopilot.synthesis import synthesize_port
    result = synthesize_port(tuple(load_sql_binding(path) for path in args.binding))
    payload = result.to_dict()
    if args.output_config:
        Path(args.output_config).write_text(yaml.safe_dump(payload["generated_config"], sort_keys=False), encoding="utf-8")
    text = json.dumps(payload, indent=2, default=str)
    if args.output:
        Path(args.output).write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if result.core_changes_required == 0 else 2


def _cmd_autopilot_bootstrap(args: argparse.Namespace) -> int:
    import yaml
    from types import SimpleNamespace
    from ephi.autopilot.models import load_sql_binding
    from ephi.autopilot.synthesis import synthesize_port
    from ephi.config import load_config
    bindings = tuple(load_sql_binding(path) for path in args.binding)
    result = synthesize_port(bindings)
    if result.core_changes_required:
        raise SystemExit("AutoPort bootstrap refuses a port requiring generic core edits")
    Path(args.output_config).write_text(yaml.safe_dump(result.generated_config, sort_keys=False), encoding="utf-8")
    config_paths = [*(args.base_config or []), args.output_config]
    config = load_config(config_paths)
    minimum = {"executions", "metrology"}.issubset(set(result.accepted_datasets))
    payload: dict[str, object] = {
        "status": "READY_FOR_PORT_BOOTSTRAP" if minimum else "PARTIAL",
        "minimum_metrology_ready": minimum,
        "config_hash": config.stable_hash(),
        "generated_config": str(args.output_config),
        "synthesis": result.to_dict(),
        "next_command": "EPHI_CONFIG_PATHS=" + ",".join(str(p) for p in config_paths) + " ephi port bootstrap --runtime-module ephi_company.bootstrap --release-manifest RELEASE_MANIFEST.json",
    }
    if args.run_port:
        if not args.release_manifest:
            raise SystemExit("--release-manifest is required with --run-port")
        port_args = SimpleNamespace(
            config=[str(p) for p in config_paths], release_manifest=args.release_manifest, runtime_module=args.runtime_module,
            local_state_db=args.local_state_db, family_id=args.family_id, environment=args.environment,
            restart=args.restart, raise_on_error=args.raise_on_error, output=args.port_output,
        )
        rc = _cmd_port_bootstrap(port_args)
        payload["port_bootstrap_exit_code"] = rc
        if rc != 0:
            payload["status"] = "PORT_BOOTSTRAP_BLOCKED"
    text = json.dumps(payload, indent=2, default=str)
    if args.output:
        Path(args.output).write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if minimum and payload.get("port_bootstrap_exit_code", 0) == 0 else 2


def _cmd_autopilot_change_audit(args: argparse.Namespace) -> int:
    from ephi.autopilot.change_audit import classify_changes
    result = classify_changes(tuple(args.changed_path))
    print(json.dumps(result.to_dict(), indent=2))
    return 0 if result.portability_passed else 2


def _cmd_autopilot_qualification(args: argparse.Namespace) -> int:
    from ephi.autopilot.qualification import run_autopilot_qualification
    report = run_autopilot_qualification()
    payload = report.to_dict()
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True, default=str))
    return 0 if report.passed else 2


def _cmd_replay_synthetic(args: argparse.Namespace) -> int:
    summary = run_synthetic_replay(
        ScalarScenarioConfig(
            n_assets=args.assets,
            executions_per_asset=args.executions_per_asset,
            seed=args.seed,
            scenario=args.scenario,
        )
    )
    print(json.dumps(summary.to_dict(), indent=2, default=str))
    return 0



def _cmd_replay_metrology(args: argparse.Namespace) -> int:
    summary = run_metrology_replay(
        MetrologyScenarioConfig(
            n_heads=args.heads,
            measurements_per_head=args.measurements_per_head,
            seed=args.seed,
            scenario=args.scenario,
        )
    )
    print(json.dumps(summary.to_dict(), indent=2, default=str))
    return 0



def _cmd_release_build(args: argparse.Namespace) -> int:
    config = _config_from_args(args.config)
    root = Path(args.root)
    manifest = build_release_manifest(
        root,
        config,
        benchmark_files=tuple(args.benchmark or ()),
        qualification_files=tuple(args.qualification or ()),
        deployment_files=tuple(args.deployment or ()),
        state_schema_version=args.state_schema_version,
    )
    payload = manifest.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _cmd_benchmark_corpus_build(args: argparse.Namespace) -> int:
    corpus = build_synthetic_golden_corpus(version=args.version)
    save_corpus(corpus, args.output)
    print(json.dumps({
        "corpus_id": corpus.corpus_id,
        "version": corpus.version,
        "cases": len(corpus.cases),
        "corpus_hash": corpus.stable_hash(),
        "output": str(args.output),
    }, indent=2))
    return 0


def _cmd_benchmark_run(args: argparse.Namespace) -> int:
    corpus = load_corpus(args.corpus)
    methods = builtin_methods()
    try:
        method = methods[args.method]
    except KeyError as exc:
        raise SystemExit(f"Unknown qualification method: {args.method}") from exc
    report = evaluate_corpus(corpus, method=method)
    if args.gate_policy:
        policy = load_gate_policy(args.gate_policy)
    else:
        policy = QualificationGatePolicy.synthetic_regression() if args.synthetic_gate else None
    payload = report.to_dict()
    if policy is not None:
        payload["gate_decision"] = apply_gate_policy(report, policy).to_dict()
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _cmd_benchmark_bakeoff(args: argparse.Namespace) -> int:
    corpus = load_corpus(args.corpus)
    registry = builtin_methods()
    names = args.method or ["baseline-v0.5", "strict-reference-challenger", "sensitive-sequential-challenger"]
    methods = []
    for name in names:
        if name not in registry:
            raise SystemExit(f"Unknown qualification method: {name}")
        methods.append(registry[name])
    report, _ = run_bakeoff(corpus, methods)
    payload = report.to_dict()
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _cmd_benchmark_stress(_: argparse.Namespace) -> int:
    payload = {
        "reference_contamination": run_reference_contamination_stress().to_dict(),
        "peer_poisoning": run_peer_poisoning_stress().to_dict(),
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0



def _cmd_quality_target_validate(args: argparse.Namespace) -> int:
    target = load_quality_target(args.target)
    print(json.dumps(target.model_dump(mode="json"), indent=2, sort_keys=True))
    return 0


def _cmd_quality_benchmark(args: argparse.Namespace) -> int:
    report = run_quality_qualification()
    payload = report.to_dict()
    if args.gate_policy:
        payload["gate_decision"] = apply_quality_gate(report, load_quality_gate_policy(args.gate_policy)).to_dict()
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _cmd_advisory_demo(args: argparse.Namespace) -> int:
    from ephi.advisory.demo import build_demo_advisory_service

    service = build_demo_advisory_service()
    episode_id = service.list_attention()[0].episode_id
    payload = service.get_view(episode_id).model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _cmd_exposure_benchmark(args: argparse.Namespace) -> int:
    report = run_exposure_priority_qualification(performance_materials=args.materials)
    payload = report.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2


def _cmd_history_benchmark(args: argparse.Namespace) -> int:
    report = run_history_rca_qualification(case_count=args.cases, affected_count=args.affected)
    payload = report.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2

def _cmd_value_cost_model_validate(args: argparse.Namespace) -> int:
    model = load_cost_model(args.model)
    print(json.dumps(model.model_dump(mode="json"), indent=2, sort_keys=True))
    return 0


def _cmd_value_benchmark(args: argparse.Namespace) -> int:
    report = run_value_qualification(str(args.cost_model))
    payload = report.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2



def _cmd_operations_benchmark(args: argparse.Namespace) -> int:
    report = run_operations_qualification(args.deployment)
    payload = report.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2


def _cmd_operations_deployment_validate(args: argparse.Namespace) -> int:
    plan = load_deployment_plan(args.plan)
    print(json.dumps(plan.model_dump(mode="json"), indent=2, sort_keys=True))
    return 0


def _cmd_operations_deployment_render(args: argparse.Namespace) -> int:
    plan = load_deployment_plan(args.plan)
    rendered = render_kubernetes_yaml(plan)
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
    print(rendered)
    return 0


def _cmd_operations_family_manifest_validate(args: argparse.Namespace) -> int:
    payload = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
    manifest = FamilyQualificationManifest.model_validate(payload)
    CertificationService().validate_family_manifest(manifest)
    print(json.dumps({"valid": True, "family_id": manifest.family_id, "state": manifest.state.value}, indent=2))
    return 0


def _cmd_operations_control_activate(args: argparse.Namespace) -> int:
    store = SqliteStateStore(args.state_db)
    service = OperationalControlService(store)
    control = service.activate(
        kind=ControlKind(args.kind),
        scope=ControlScope(args.scope),
        target=args.target,
        reason=args.reason,
        actor=args.actor,
    )
    print(json.dumps(control.model_dump(mode="json"), indent=2, sort_keys=True))
    return 0


def _cmd_operations_control_deactivate(args: argparse.Namespace) -> int:
    store = SqliteStateStore(args.state_db)
    service = OperationalControlService(store)
    control = service.deactivate(args.control_id, actor=args.actor)
    print(json.dumps(control.model_dump(mode="json"), indent=2, sort_keys=True))
    return 0


def _cmd_operations_control_list(args: argparse.Namespace) -> int:
    store = SqliteStateStore(args.state_db)
    service = OperationalControlService(store)
    items = service.active_controls() if args.active else service.history()
    print(json.dumps([item.model_dump(mode="json") for item in items], indent=2, sort_keys=True))
    return 0


def _cmd_operations_release_compatibility(args: argparse.Namespace) -> int:
    source = ReleaseManifest.model_validate_json(Path(args.source).read_text(encoding="utf-8"))
    target = ReleaseManifest.model_validate_json(Path(args.target).read_text(encoding="utf-8"))
    result = assess_release_compatibility(
        source, target,
        source_state_schema_version=args.source_state_schema or source.state_schema_version,
        target_state_schema_version=args.target_state_schema or target.state_schema_version,
        destructive_migration=args.destructive_migration,
        migration_available=args.migration_available,
        migration_reversible=args.migration_reversible,
    )
    print(json.dumps(result.model_dump(mode="json"), indent=2, sort_keys=True))
    return 0 if result.rollback_allowed else 2


def _cmd_operations_worker(args: argparse.Namespace) -> int:
    import importlib
    import time
    from ephi.runtime.idempotency import AppliedWorkLedger
    from ephi.runtime.queue import DurableWorkQueue
    from ephi.operations.worker import WorkerHost

    role = RuntimeRole(args.role)
    applied_work = None
    if args.runtime_module:
        module = importlib.import_module(args.runtime_module)
        if not hasattr(module, "build_handlers") or not hasattr(module, "build_queue"):
            raise SystemExit("runtime module must expose build_handlers(role) and build_queue(role)")
        handlers = module.build_handlers(role)
        queue = module.build_queue(role)
        if hasattr(module, "build_applied_work_ledger"):
            applied_work = module.build_applied_work_ledger(role)
    else:
        if args.handler_module is None or args.state_db is None:
            raise SystemExit("local worker mode requires --handler-module and --state-db, or use --runtime-module")
        module = importlib.import_module(args.handler_module)
        if not hasattr(module, "build_handlers"):
            raise SystemExit("handler module must expose build_handlers(role: RuntimeRole)")
        handlers = module.build_handlers(role)
        local_store = SqliteStateStore(args.state_db)
        queue = DurableWorkQueue(local_store)
        applied_work = AppliedWorkLedger(local_store)
    host = WorkerHost(
        worker_id=args.worker_id, queue=queue, handlers=handlers,
        lease_seconds=args.lease_seconds, applied_work=applied_work,
    )
    if args.once:
        item = host.run_once()
        print(json.dumps({"role": role.value, "processed": item.work_id if item else None}, indent=2))
        return 0
    while True:
        item = host.run_once()
        if item is None:
            time.sleep(args.idle_sleep_seconds)




def _cmd_reliability_benchmark(args: argparse.Namespace) -> int:
    report = run_reliability_qualification()
    payload = report.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2


def _cmd_reliability_backup(args: argparse.Namespace) -> int:
    store = SqliteStateStore(args.state_db)
    policy = load_reliability_policy(args.policy)
    bundle = build_backup_bundle(
        store,
        policies=policy.policies,
        source_release_id=args.release_id,
        state_schema_version=args.state_schema_version or policy.state_schema_version,
        fail_on_unclassified=policy.fail_on_unclassified_state,
    )
    write_backup_bundle(bundle, args.output)
    print(json.dumps({
        "bundle_id": bundle.bundle_id,
        "records": len(bundle.records),
        "content_sha256": bundle.content_sha256,
        "output": str(args.output),
    }, indent=2, sort_keys=True))
    return 0


def _cmd_reliability_backup_inspect(args: argparse.Namespace) -> int:
    bundle = load_backup_bundle(args.bundle)
    print(json.dumps({
        "valid": True,
        "bundle_id": bundle.bundle_id,
        "source_release_id": bundle.source_release_id,
        "state_schema_version": bundle.state_schema_version,
        "created_at": bundle.created_at.isoformat(),
        "records": len(bundle.records),
        "content_sha256": bundle.content_sha256,
    }, indent=2, sort_keys=True))
    return 0


def _cmd_reliability_restore(args: argparse.Namespace) -> int:
    if not args.confirm_empty_target:
        raise SystemExit("restore requires --confirm-empty-target")
    bundle = load_backup_bundle(args.bundle)
    store = SqliteStateStore(args.state_db)
    restore_backup_bundle(store, bundle, require_empty=True)
    print(json.dumps({
        "restored": True,
        "bundle_id": bundle.bundle_id,
        "records": len(bundle.records),
        "state_db": str(args.state_db),
    }, indent=2, sort_keys=True))
    return 0



def _cmd_port_contract(_: argparse.Namespace) -> int:
    print(json.dumps({
        "runtime_module_functions": list(REQUIRED_RUNTIME_FUNCTIONS),
        "runtime_methods": list(REQUIRED_RUNTIME_METHODS),
        "stage_order": [item.value for item in PortBootstrapOrchestrator.stage_order()],
        "company_scaffold": "company_port/src/ephi_company",
        "rule": "company-specific physical integration stays outside src/ephi",
    }, indent=2, sort_keys=True))
    return 0


def _cmd_port_module_validate(args: argparse.Namespace) -> int:
    import importlib

    config = _config_from_args(args.config)
    manifest = ReleaseManifest.model_validate_json(Path(args.release_manifest).read_text(encoding="utf-8"))
    module = importlib.import_module(args.runtime_module)
    base = validate_port_module(module)
    runtime = None
    if not base.missing_functions and hasattr(module, "build_port_runtime"):
        runtime = module.build_port_runtime(config, manifest)
    result = validate_port_module(module, runtime=runtime)
    payload = {
        "valid": result.valid,
        "missing_functions": list(result.missing_functions),
        "missing_runtime_methods": list(result.missing_runtime_methods),
        "runtime_module": args.runtime_module,
        "config_hash": config.stable_hash(),
        "release_id": manifest.release_id,
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if result.valid else 2


def _cmd_port_bootstrap(args: argparse.Namespace) -> int:
    import importlib

    config = _config_from_args(args.config)
    manifest = ReleaseManifest.model_validate_json(Path(args.release_manifest).read_text(encoding="utf-8"))
    module = importlib.import_module(args.runtime_module)
    contract = validate_port_module(module)
    if not contract.valid:
        raise SystemExit(
            f"invalid port runtime module; missing functions: {', '.join(contract.missing_functions)}"
        )
    runtime = module.build_port_runtime(config, manifest)
    runtime_contract = validate_port_module(module, runtime=runtime)
    if not runtime_contract.valid:
        raise SystemExit(
            "invalid port runtime object; missing methods: "
            + ", ".join(runtime_contract.missing_runtime_methods)
        )
    if args.local_state_db is not None:
        state_store = SqliteStateStore(args.local_state_db)
    else:
        state_store = module.build_port_state_store(config)
    identity = PortRunIdentity(
        release_id=manifest.release_id,
        package_version=manifest.package_version,
        config_hash=config.stable_hash(),
        family_id=args.family_id or config.operations.family_id,
        environment=args.environment or config.app.environment,
    )
    orchestrator = PortBootstrapOrchestrator(
        runtime=runtime,
        identity=identity,
        state_store=state_store,
    )
    report = orchestrator.run(
        resume=not args.restart,
        raise_on_error=args.raise_on_error,
    )
    payload = report.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.shadow_ready else 2


def _cmd_port_qualification(args: argparse.Namespace) -> int:
    report = run_port_kit_qualification(args.root)
    payload = report.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2




def _cmd_port_production_preflight(args: argparse.Namespace) -> int:
    from ephi.operations.deployment import load_deployment_plan
    from ephi.port.production_preflight import run_production_preflight_module

    config = _config_from_args(args.config)
    manifest = ReleaseManifest.model_validate_json(Path(args.release_manifest).read_text(encoding="utf-8"))
    deployment = load_deployment_plan(args.deployment_plan)
    report = run_production_preflight_module(args.preflight_module, config, deployment, manifest)
    payload = report.to_dict()
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2


def _cmd_port_production_qualification(args: argparse.Namespace) -> int:
    from ephi.port.production_qualification import run_production_smoke_qualification

    report = run_production_smoke_qualification(
        args.root, deployment_plan=args.deployment_plan, release_manifest=args.release_manifest
    )
    payload = report.to_dict()
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2


def _cmd_autopilot_db_qualify(args: argparse.Namespace) -> int:
    import importlib
    from ephi.autopilot.dialect import qualify_sql_executor

    config = _config_from_args(args.config)
    module = importlib.import_module(args.executor_module)
    builder = getattr(module, "build_approved_sql_executor", None)
    if not callable(builder):
        raise ValueError(f"executor module {args.executor_module} must expose build_approved_sql_executor(config)")
    report = qualify_sql_executor(builder(config))
    payload = report.to_dict()
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2

def _cmd_onboarding_plan(args: argparse.Namespace) -> int:
    policy = load_onboarding_policy(args.policy)
    reality = capability_report_from_payload(json.loads(Path(args.data_reality).read_text(encoding="utf-8")))
    release_manifest = ReleaseManifest.model_validate_json(Path(args.release_manifest).read_text(encoding="utf-8"))
    current = None
    if args.current_manifest:
        current = FamilyQualificationManifest.model_validate_json(Path(args.current_manifest).read_text(encoding="utf-8"))
    plan = build_family_onboarding_plan(
        family_id=policy.family_id,
        release_id=release_manifest.release_id,
        report=reality,
        required_capabilities=policy.required_capabilities,
        optional_capabilities=policy.optional_capabilities,
        current_manifest=current,
        target_state=policy.target_state,
    )
    payload = plan.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if plan.ready_for_target else 2


def _cmd_onboarding_golden_submit(args: argparse.Namespace) -> int:
    store = SqliteStateStore(args.state_db)
    registry = GoldenCaseRegistry(store)
    intake = GoldenCaseIntake.model_validate_json(Path(args.intake).read_text(encoding="utf-8"))
    item = registry.submit(intake)
    print(json.dumps(item.model_dump(mode="json"), indent=2, sort_keys=True))
    return 0


def _cmd_onboarding_golden_review(args: argparse.Namespace) -> int:
    from datetime import datetime, timezone
    store = SqliteStateStore(args.state_db)
    registry = GoldenCaseRegistry(store)
    item = registry.revise(
        args.intake_id,
        state=GoldenCurationState(args.state),
        reviewer=args.reviewer,
        reviewed_at=datetime.now(timezone.utc),
        note=args.note,
    )
    print(json.dumps(item.model_dump(mode="json"), indent=2, sort_keys=True))
    return 0


def _cmd_onboarding_golden_export(args: argparse.Namespace) -> int:
    from datetime import datetime, timezone
    store = SqliteStateStore(args.state_db)
    cases = GoldenCaseRegistry(store).accepted_cases()
    corpus = BenchmarkCorpus(
        corpus_id=args.corpus_id,
        version=args.version,
        created_at=datetime.now(timezone.utc),
        description=args.description,
        cases=cases,
    )
    Path(args.output).write_text(json.dumps(corpus.model_dump(mode="json"), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"corpus_id": corpus.corpus_id, "cases": len(cases), "corpus_hash": corpus.stable_hash(), "output": str(args.output)}, indent=2))
    return 0 if cases else 2


def _load_gate_results(path: Path) -> tuple[GateResult, ...]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    raw = payload.get("gate_results", payload) if isinstance(payload, dict) else payload
    if not isinstance(raw, list):
        raise SystemExit("gate result input must be a list or {'gate_results': [...]} object")
    return tuple(GateResult.model_validate(item) for item in raw)


def _cmd_onboarding_promotion_package(args: argparse.Namespace) -> int:
    policy = load_onboarding_policy(args.policy)
    plan = FamilyOnboardingPlan.model_validate_json(Path(args.plan).read_text(encoding="utf-8"))
    corpus = BenchmarkCorpus.model_validate_json(Path(args.corpus).read_text(encoding="utf-8"))
    shadow_metrics = None
    if args.shadow_metrics:
        shadow_metrics = ShadowQualificationMetrics.model_validate_json(Path(args.shadow_metrics).read_text(encoding="utf-8"))
    builder = PromotionEvidenceBuilder(golden_policy=policy.golden)
    package = builder.build(
        family_id=policy.family_id,
        release_id=plan.release_id,
        from_state=CertificationState(args.from_state),
        target_state=CertificationState(args.target_state or policy.target_state.value),
        gate_results=_load_gate_results(args.gates),
        onboarding_plan=plan,
        golden_cases=corpus.cases,
        shadow_metrics=shadow_metrics,
        evidence_artifacts=tuple(args.artifact or ()),
    )
    payload = package.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if package.decision.value == "READY" else 2



def _cmd_onboarding_family_manifest(args: argparse.Namespace) -> int:
    from ephi.domain.onboarding import PromotionEvidencePackage
    packages = tuple(
        PromotionEvidencePackage.model_validate_json(Path(path).read_text(encoding="utf-8"))
        for path in args.package
    )
    manifest = family_manifest_from_packages(
        packages,
        approved_by=args.approved_by,
        notes=tuple(args.note or ()),
    )
    payload = manifest.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _cmd_onboarding_benchmark(args: argparse.Namespace) -> int:
    report = run_family_onboarding_qualification()
    payload = report.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2


def _cmd_onboarding_control_benchmark(args: argparse.Namespace) -> int:
    report = run_qualification_control_plane_qualification()
    payload = report.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2




def _cmd_launch_plan(args: argparse.Namespace) -> int:
    manifest = ReleaseManifest.model_validate_json(Path(args.release_manifest).read_text(encoding="utf-8"))
    policy = load_launch_policy(args.policy)
    evidence = tuple(LaunchEvidenceReceipt.model_validate_json(Path(path).read_text(encoding="utf-8")) for path in (args.evidence or ()))
    data_reality = None
    if args.data_reality:
        data_reality = capability_report_from_payload(json.loads(Path(args.data_reality).read_text(encoding="utf-8")))
    plan = build_metrology_shadow_launch_plan(
        family_id=args.family_id or policy.family_id, release_id=manifest.release_id,
        config_hash=manifest.config_sha256, current_state=CertificationState(args.current_state),
        target_state=CertificationState(args.target_state), policy=policy, evidence=evidence,
        data_reality=data_reality,
    )
    payload = plan.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if plan.ready else 2


def _cmd_launch_golden_manifest(args: argparse.Namespace) -> int:
    manifest = ReleaseManifest.model_validate_json(Path(args.release_manifest).read_text(encoding="utf-8"))
    corpus = BenchmarkCorpus.model_validate_json(Path(args.corpus).read_text(encoding="utf-8"))
    replay_as_of = __import__("datetime").datetime.fromisoformat(args.replay_as_of.replace("Z", "+00:00"))
    result = build_internal_golden_replay_manifest(
        corpus=corpus, family_id=args.family_id, release_id=manifest.release_id,
        config_hash=manifest.config_sha256, source_snapshot_id=args.source_snapshot_id,
        replay_as_of=replay_as_of,
    )
    payload = result.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _cmd_launch_collect(args: argparse.Namespace) -> int:
    import importlib
    config = _config_from_args(args.config)
    manifest = ReleaseManifest.model_validate_json(Path(args.release_manifest).read_text(encoding="utf-8"))
    module = importlib.import_module(args.module)
    shell = validate_launch_module(module)
    if not shell.valid:
        raise SystemExit("invalid launch module: " + ", ".join(shell.missing_functions))
    executor = module.build_launch_evidence_executor(config, manifest)
    contract = validate_launch_module(module, executor=executor)
    if not contract.valid:
        raise SystemExit("invalid launch executor methods: " + ", ".join(contract.missing_executor_methods))
    methods = {
        "data-reality": "collect_data_reality",
        "golden": "collect_internal_golden_replay",
        "scale": "collect_production_replay_scale",
        "dr": "collect_reliability_dr_drill",
        "shadow-runtime": "collect_shadow_runtime",
        "engineer-shadow": "collect_engineer_shadow",
    }
    result = getattr(executor, methods[args.stage])()
    items = result if isinstance(result, tuple) else (result,)
    payload = [item.model_dump(mode="json") for item in items]
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0

def _cmd_launch_receipt(args: argparse.Namespace) -> int:
    manifest = ReleaseManifest.model_validate_json(Path(args.release_manifest).read_text(encoding="utf-8"))
    receipt = receipt_from_artifact(
        evidence_id=args.evidence_id, family_id=args.family_id, release_id=manifest.release_id,
        config_hash=manifest.config_sha256, kind=LaunchEvidenceKind(args.kind),
        provenance=EvidenceProvenance(args.provenance), decision=EvidenceDecision(args.decision),
        artifact=args.artifact, validator=args.validator, source_snapshot_id=args.source_snapshot_id,
    )
    payload = receipt.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _cmd_launch_dossier(args: argparse.Namespace) -> int:
    manifest = ReleaseManifest.model_validate_json(Path(args.release_manifest).read_text(encoding="utf-8"))
    policy = load_launch_policy(args.policy)
    evidence = tuple(LaunchEvidenceReceipt.model_validate_json(Path(path).read_text(encoding="utf-8")) for path in args.evidence)
    replay_manifests = tuple(ProductionReplayManifest.model_validate_json(Path(path).read_text(encoding="utf-8")) for path in (args.replay_manifest or ()))
    data_reality = None
    if args.data_reality:
        data_reality = capability_report_from_payload(json.loads(Path(args.data_reality).read_text(encoding="utf-8")))
    dossier = build_shadow_launch_dossier(
        family_id=args.family_id or policy.family_id, release_id=manifest.release_id,
        config_hash=manifest.config_sha256, current_state=CertificationState(args.current_state),
        target_state=CertificationState(args.target_state), policy=policy, evidence=evidence,
        data_reality=data_reality, replay_manifests=replay_manifests,
    )
    payload = dossier.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if dossier.promotion_ready else 2


def _cmd_launch_module_validate(args: argparse.Namespace) -> int:
    import importlib
    module = importlib.import_module(args.module)
    result = validate_launch_module(module)
    payload = {
        "valid": result.valid,
        "missing_functions": list(result.missing_functions),
        "missing_executor_methods": list(result.missing_executor_methods),
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if result.valid else 2


def _cmd_launch_qualification(args: argparse.Namespace) -> int:
    report = run_launch_qualification(args.policy)
    payload = report.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2

def _cmd_launch_adapter_validate(args: argparse.Namespace) -> int:
    import importlib
    config = _config_from_args(args.config)
    manifest = ReleaseManifest.model_validate_json(Path(args.release_manifest).read_text(encoding="utf-8"))
    module = importlib.import_module(args.module)
    shell = validate_launch_module(module)
    if not shell.valid:
        payload = {"valid": False, "missing_functions": list(shell.missing_functions)}
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 2
    try:
        executor = module.build_launch_evidence_executor(config, manifest)
        result = validate_launch_module(module, executor=executor)
        descriptor = executor.describe_adapter() if result.valid else None
        payload = {
            "valid": result.valid,
            "missing_functions": list(result.missing_functions),
            "missing_executor_methods": list(result.missing_executor_methods),
            "descriptor_errors": list(result.descriptor_errors),
            "descriptor": None if descriptor is None else descriptor.model_dump(mode="json"),
        }
    except Exception as exc:
        payload = {"valid": False, "error": f"{type(exc).__name__}: {exc}"}
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if payload.get("valid") else 2


def _cmd_launch_campaign_run(args: argparse.Namespace) -> int:
    import importlib
    config = _config_from_args(args.config)
    manifest = ReleaseManifest.model_validate_json(Path(args.release_manifest).read_text(encoding="utf-8"))
    launch_module = importlib.import_module(args.launch_module)
    state_module = importlib.import_module(args.state_module)
    executor = launch_module.build_launch_evidence_executor(config, manifest)
    state_store = state_module.build_state_store(config)
    artifact_store = state_module.build_artifact_store(config)
    family_id = args.family_id or load_launch_policy(args.policy).family_id
    controller = CampaignExecutionController(
        family_id=family_id,
        release_id=manifest.release_id,
        config_hash=manifest.config_sha256,
        executor=executor,
        repository=ShadowLaunchWorkspaceRepository(state_store),
        artifact_store=artifact_store,
        max_attempts_per_stage=args.max_attempts,
    )
    stages = tuple(CampaignStage(item) for item in (args.stage or ())) or None
    campaign = controller.run(
        campaign_id=args.campaign_id,
        target_state=CertificationState(args.target_state),
        actor=args.actor,
        stages=stages,
    )
    dossier = controller.build_dossier(
        campaign_id=args.campaign_id,
        current_state=CertificationState(args.current_state),
        target_state=CertificationState(args.target_state),
        policy=load_launch_policy(args.policy),
    )
    payload = {"campaign": campaign.model_dump(mode="json"), "dossier": dossier.model_dump(mode="json")}
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if args.dossier_output:
        Path(args.dossier_output).write_text(json.dumps(dossier.model_dump(mode="json"), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if args.workspace_output:
        Path(args.workspace_output).write_text(json.dumps(controller.export_workspace(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if dossier.promotion_ready else 2


def _cmd_launch_campaign_status(args: argparse.Namespace) -> int:
    import importlib
    config = _config_from_args(args.config)
    state_module = importlib.import_module(args.state_module)
    repo = ShadowLaunchWorkspaceRepository(state_module.build_state_store(config))
    workspace = repo.load(args.family_id)
    campaign = repo.campaign(args.family_id, args.campaign_id)
    if campaign is None:
        raise SystemExit(f"campaign not found: {args.campaign_id}")
    payload = {
        "campaign": campaign.model_dump(mode="json"),
        "evidence": [item.model_dump(mode="json") for item in workspace.evidence],
        "replay_manifests": [item.model_dump(mode="json") for item in workspace.replay_manifests],
        "source_snapshots": [item.model_dump(mode="json") for item in workspace.source_snapshots],
    }
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _campaign_observability_from_args(args: argparse.Namespace) -> CampaignObservabilityService:
    import importlib
    config = _config_from_args(args.config)
    state_module = importlib.import_module(args.state_module)
    qualification_service = None
    services_module_name = getattr(args, "services_module", None)
    if services_module_name:
        services = importlib.import_module(services_module_name).build_services(config)
        qualification_service = services.qualification
    return CampaignObservabilityService(
        ShadowLaunchWorkspaceRepository(state_module.build_state_store(config)),
        artifact_store=state_module.build_artifact_store(config),
        launch_policy_path=args.policy,
        slo_policy_path=args.slo_policy,
        retention_policy_path=args.retention_policy,
        qualification_service=qualification_service,
    )


def _cmd_launch_campaign_readiness(args: argparse.Namespace) -> int:
    service = _campaign_observability_from_args(args)
    current = CertificationState(args.current_state) if args.current_state else None
    view = service.readiness(args.family_id, args.campaign_id, current_state=current)
    payload = view.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if view.state.value in {"READY_FOR_HANDOFF", "HANDED_OFF"} else 2


def _cmd_launch_campaign_events(args: argparse.Namespace) -> int:
    service = _campaign_observability_from_args(args)
    payload = [item.model_dump(mode="json") for item in service.events(args.family_id, args.campaign_id)]
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _cmd_launch_campaign_compare(args: argparse.Namespace) -> int:
    service = _campaign_observability_from_args(args)
    result = service.compare(args.family_id, args.baseline_campaign_id, args.candidate_campaign_id)
    payload = result.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _cmd_launch_campaign_export(args: argparse.Namespace) -> int:
    service = _campaign_observability_from_args(args)
    current = CertificationState(args.current_state) if args.current_state else None
    export = service.export(args.family_id, args.campaign_id, current_state=current)
    payload: dict[str, object] = {"export": export.model_dump(mode="json")}
    if args.publish:
        payload["published"] = service.publish_export(
            args.family_id, args.campaign_id, current_state=current
        ).model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _cmd_launch_observability_qualification(args: argparse.Namespace) -> int:
    report = run_campaign_observability_qualification()
    payload = report.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2


def _cmd_launch_handoff(args: argparse.Namespace) -> int:
    import importlib
    config = _config_from_args(args.config)
    dossier = ShadowLaunchDossier.model_validate_json(Path(args.dossier).read_text(encoding="utf-8"))
    services_module = importlib.import_module(args.services_module)
    services = services_module.build_services(config)
    result = handoff_launch_dossier(
        dossier=dossier,
        control_plane=services.qualification,
        actor=args.actor,
        capability_id=args.capability_id,
        command_prefix=args.command_prefix,
    )
    payload = {
        "family_id": result.family_id,
        "package_id": result.package_id,
        "recorded_planes": list(result.recorded_planes),
        "reused_commands": list(result.reused_commands),
    }
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _cmd_launch_execution_qualification(args: argparse.Namespace) -> int:
    report = run_campaign_execution_qualification(args.policy)
    payload = report.model_dump(mode="json")
    if args.output:
        Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 2


def _cmd_launch_dry_run(args: argparse.Namespace) -> int:
    manifest = ReleaseManifest.model_validate_json(Path(args.release_manifest).read_text(encoding="utf-8"))
    policy = load_launch_policy(args.policy)
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        executor = ReferenceLaunchEvidenceExecutor(
            root / "collected", family_id=policy.family_id, release_id=manifest.release_id,
            config_hash=manifest.config_sha256,
            fail_once=frozenset({CampaignStage.PRODUCTION_REPLAY_SCALE}) if args.inject_retry else frozenset(),
        )
        controller = CampaignExecutionController(
            family_id=policy.family_id, release_id=manifest.release_id, config_hash=manifest.config_sha256,
            executor=executor, repository=ShadowLaunchWorkspaceRepository(SqliteStateStore(root / "state.sqlite3")),
            artifact_store=FileSystemArtifactStore(root / "artifacts"), max_attempts_per_stage=3,
            required_provenance=EvidenceProvenance.SIMULATED_INTERNAL,
        )
        try:
            campaign = controller.run(
                campaign_id="REFERENCE-DRY-RUN", target_state=CertificationState.SHADOW_QUALIFIED, actor="reference-dry-run",
            )
        except RuntimeError:
            if not args.inject_retry:
                raise
            campaign = controller.run(
                campaign_id="REFERENCE-DRY-RUN", target_state=CertificationState.SHADOW_QUALIFIED, actor="reference-dry-run",
            )
        dossier = controller.build_dossier(
            campaign_id=campaign.campaign_id, current_state=CertificationState.SHADOW,
            target_state=CertificationState.SHADOW_QUALIFIED, policy=policy,
            limitations=("reference dry run uses SIMULATED_INTERNAL evidence",),
        )
        workspace = controller.export_workspace()
        stage_pass = all(campaign.stage_passed(stage) for stage in CampaignStage)
        payload = {
            "mechanism_passed": stage_pass,
            "promotion_ready": dossier.promotion_ready,
            "expected_blocked_on_provenance": (not dossier.promotion_ready and any("INTERNAL_MEASURED" in b for b in dossier.blockers)),
            "campaign": campaign.model_dump(mode="json"),
            "dossier": dossier.model_dump(mode="json"),
            "workspace": workspace,
        }
        if args.output:
            Path(args.output).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 0 if payload["mechanism_passed"] and payload["expected_blocked_on_provenance"] else 2

def _cmd_api_serve(args: argparse.Namespace) -> int:
    import importlib
    import uvicorn

    config = _config_from_args(args.config)
    if args.app_factory_module:
        module = importlib.import_module(args.app_factory_module)
        if not hasattr(module, "create_app"):
            raise SystemExit("app factory module must expose create_app(config)")
        app = module.create_app(config)
    else:
        from ephi.api.app import create_app
        app = create_app(config)

    uvicorn.run(app, host=args.host, port=args.port)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ephi")
    sub = parser.add_subparsers(dest="command", required=True)

    version = sub.add_parser("version")
    version.set_defaults(func=_cmd_version)

    config = sub.add_parser("config")
    config_sub = config.add_subparsers(dest="config_command", required=True)
    validate = config_sub.add_parser("validate")
    validate.add_argument("--config", action="append", required=True)
    validate.set_defaults(func=_cmd_config_validate)

    synthetic = sub.add_parser("synthetic")
    synthetic_sub = synthetic.add_subparsers(dest="synthetic_command", required=True)
    generate = synthetic_sub.add_parser("generate")
    generate.add_argument("--output", type=Path, required=True)
    generate.add_argument(
        "--scenario",
        choices=("healthy", "local-drift", "common-mode", "unit-scale-change"),
        default="healthy",
    )
    generate.add_argument("--assets", type=int, default=4)
    generate.add_argument("--executions-per-asset", type=int, default=1000)
    generate.add_argument("--seed", type=int, default=7)
    generate.set_defaults(func=_cmd_synthetic_generate)

    data = sub.add_parser("data")
    data_sub = data.add_subparsers(dest="data_command", required=True)
    audit = data_sub.add_parser("audit")
    audit.add_argument("--root", type=Path, required=True)
    audit.add_argument("--semantic", action="store_true", help="run the semantic Data Reality Audit")
    audit.set_defaults(func=_cmd_data_audit)

    contracts = data_sub.add_parser("contracts")
    contracts.set_defaults(func=_cmd_data_contracts)

    mapping_validate = data_sub.add_parser("mapping-validate")
    mapping_validate.add_argument("--config", action="append", required=True)
    mapping_validate.set_defaults(func=_cmd_data_mapping_validate)


    autopilot = sub.add_parser("autopilot")
    autopilot_sub = autopilot.add_subparsers(dest="autopilot_command", required=True)

    autopilot_catalog = autopilot_sub.add_parser("catalog")
    autopilot_catalog.add_argument("--output", type=Path)
    autopilot_catalog.set_defaults(func=_cmd_autopilot_catalog)

    autopilot_db = autopilot_sub.add_parser("db-qualify")
    autopilot_db.add_argument("--executor-module", default="ephi_company.big_data")
    autopilot_db.add_argument("--config", action="append")
    autopilot_db.add_argument("--output", type=Path)
    autopilot_db.set_defaults(func=_cmd_autopilot_db_qualify)

    autopilot_inspect = autopilot_sub.add_parser("inspect")
    autopilot_inspect.add_argument("--sqlite-db", type=Path, required=True, help="portable reference inspector; company agent should emit the same profile JSON")
    autopilot_inspect.add_argument("--table", required=True)
    autopilot_inspect.add_argument("--sample-rows", type=int, default=50)
    autopilot_inspect.add_argument("--output", type=Path)
    autopilot_inspect.set_defaults(func=_cmd_autopilot_inspect)

    autopilot_discover = autopilot_sub.add_parser("discover")
    autopilot_discover.add_argument("--dataset", required=True)
    autopilot_discover.add_argument("--hint")
    srcgrp = autopilot_discover.add_mutually_exclusive_group(required=True)
    srcgrp.add_argument("--sqlite-db", type=Path)
    srcgrp.add_argument("--inspector-module")
    autopilot_discover.add_argument("--config", action="append")
    autopilot_discover.add_argument("--sample-rows", type=int, default=50)
    autopilot_discover.add_argument("--limit", type=int, default=20)
    autopilot_discover.add_argument("--output", type=Path)
    autopilot_discover.set_defaults(func=_cmd_autopilot_discover)

    autopilot_candidate = autopilot_sub.add_parser("candidate")
    autopilot_candidate.add_argument("--dataset", required=True)
    autopilot_candidate.add_argument("--table", required=True)
    source = autopilot_candidate.add_mutually_exclusive_group(required=True)
    source.add_argument("--sqlite-db", type=Path)
    source.add_argument("--inspector-module")
    autopilot_candidate.add_argument("--config", action="append")
    autopilot_candidate.add_argument("--sample-rows", type=int, default=50)
    autopilot_candidate.add_argument("--partition-column")
    autopilot_candidate.add_argument("--partition-source-field", choices=("event_time", "available_at"))
    autopilot_candidate.add_argument("--partition-granularity", choices=("date", "timestamp"))
    autopilot_candidate.add_argument("--watermark-column")
    autopilot_candidate.add_argument("--output-binding", type=Path)
    autopilot_candidate.add_argument("--output", type=Path)
    autopilot_candidate.set_defaults(func=_cmd_autopilot_candidate)

    autopilot_propose = autopilot_sub.add_parser("propose")
    autopilot_propose.add_argument("--dataset", required=True)
    autopilot_propose.add_argument("--profile", type=Path, required=True)
    autopilot_propose.add_argument("--partition-column")
    autopilot_propose.add_argument("--partition-source-field", choices=("event_time", "available_at"))
    autopilot_propose.add_argument("--partition-granularity", choices=("date", "timestamp"))
    autopilot_propose.add_argument("--watermark-column")
    autopilot_propose.add_argument("--output-binding", type=Path)
    autopilot_propose.add_argument("--output", type=Path)
    autopilot_propose.set_defaults(func=_cmd_autopilot_propose)

    autopilot_validate = autopilot_sub.add_parser("validate-binding")
    autopilot_validate.add_argument("--binding", type=Path, required=True)
    autopilot_validate.set_defaults(func=_cmd_autopilot_validate_binding)

    autopilot_seal = autopilot_sub.add_parser("seal-binding")
    autopilot_seal.add_argument("--binding", type=Path, required=True)
    autopilot_seal.add_argument("--resolve-review", action="append", help="exact review item being explicitly acknowledged")
    autopilot_seal.set_defaults(func=_cmd_autopilot_seal_binding)

    autopilot_synth = autopilot_sub.add_parser("synthesize")
    autopilot_synth.add_argument("--binding", type=Path, action="append", required=True)
    autopilot_synth.add_argument("--output-config", type=Path)
    autopilot_synth.add_argument("--output", type=Path)
    autopilot_synth.set_defaults(func=_cmd_autopilot_synthesize)

    autopilot_bootstrap = autopilot_sub.add_parser("bootstrap")
    autopilot_bootstrap.add_argument("--binding", type=Path, action="append", required=True)
    autopilot_bootstrap.add_argument("--base-config", type=Path, action="append")
    autopilot_bootstrap.add_argument("--output-config", type=Path, required=True)
    autopilot_bootstrap.add_argument("--output", type=Path)
    autopilot_bootstrap.add_argument("--run-port", action="store_true")
    autopilot_bootstrap.add_argument("--runtime-module", default="ephi_company.bootstrap")
    autopilot_bootstrap.add_argument("--release-manifest", type=Path)
    autopilot_bootstrap.add_argument("--family-id")
    autopilot_bootstrap.add_argument("--environment")
    autopilot_bootstrap.add_argument("--local-state-db", type=Path)
    autopilot_bootstrap.add_argument("--restart", action="store_true")
    autopilot_bootstrap.add_argument("--raise-on-error", action="store_true")
    autopilot_bootstrap.add_argument("--port-output", type=Path)
    autopilot_bootstrap.set_defaults(func=_cmd_autopilot_bootstrap)

    autopilot_audit = autopilot_sub.add_parser("change-audit")
    autopilot_audit.add_argument("--changed-path", action="append", required=True)
    autopilot_audit.set_defaults(func=_cmd_autopilot_change_audit)

    autopilot_qual = autopilot_sub.add_parser("qualification")
    autopilot_qual.add_argument("--output", type=Path)
    autopilot_qual.set_defaults(func=_cmd_autopilot_qualification)


    replay = sub.add_parser("replay")
    replay_sub = replay.add_subparsers(dest="replay_command", required=True)
    replay_synthetic = replay_sub.add_parser("synthetic")
    replay_synthetic.add_argument(
        "--scenario",
        choices=("healthy", "local-drift", "common-mode", "unit-scale-change"),
        default="local-drift",
    )
    replay_synthetic.add_argument("--assets", type=int, default=4)
    replay_synthetic.add_argument("--executions-per-asset", type=int, default=1000)
    replay_synthetic.add_argument("--seed", type=int, default=7)
    replay_synthetic.set_defaults(func=_cmd_replay_synthetic)

    replay_metrology = replay_sub.add_parser("metrology")
    replay_metrology.add_argument(
        "--scenario",
        choices=(
            "healthy",
            "measurement-head-drift",
            "process-shift",
            "remeasure-instability",
            "spatial-head-drift",
        ),
        default="measurement-head-drift",
    )
    replay_metrology.add_argument("--heads", type=int, default=3)
    replay_metrology.add_argument("--measurements-per-head", type=int, default=900)
    replay_metrology.add_argument("--seed", type=int, default=17)
    replay_metrology.set_defaults(func=_cmd_replay_metrology)

    benchmark = sub.add_parser("benchmark")
    benchmark_sub = benchmark.add_subparsers(dest="benchmark_command", required=True)

    corpus_build = benchmark_sub.add_parser("corpus-build")
    corpus_build.add_argument("--output", type=Path, required=True)
    corpus_build.add_argument("--version", default="1.0.0")
    corpus_build.set_defaults(func=_cmd_benchmark_corpus_build)

    benchmark_run = benchmark_sub.add_parser("run")
    benchmark_run.add_argument("--corpus", type=Path, required=True)
    benchmark_run.add_argument("--method", default="baseline-v0.5", choices=tuple(builtin_methods()))
    benchmark_run.add_argument("--synthetic-gate", action="store_true")
    benchmark_run.add_argument("--gate-policy", type=Path)
    benchmark_run.add_argument("--output", type=Path)
    benchmark_run.set_defaults(func=_cmd_benchmark_run)

    bakeoff = benchmark_sub.add_parser("bakeoff")
    bakeoff.add_argument("--corpus", type=Path, required=True)
    bakeoff.add_argument("--method", action="append", choices=tuple(builtin_methods()))
    bakeoff.add_argument("--output", type=Path)
    bakeoff.set_defaults(func=_cmd_benchmark_bakeoff)

    stress = benchmark_sub.add_parser("stress")
    stress.set_defaults(func=_cmd_benchmark_stress)

    quality = sub.add_parser("quality")
    quality_sub = quality.add_subparsers(dest="quality_command", required=True)
    target_validate = quality_sub.add_parser("target-validate")
    target_validate.add_argument("--target", type=Path, required=True)
    target_validate.set_defaults(func=_cmd_quality_target_validate)
    quality_benchmark = quality_sub.add_parser("benchmark")
    quality_benchmark.add_argument("--output", type=Path)
    quality_benchmark.add_argument("--gate-policy", type=Path)
    quality_benchmark.set_defaults(func=_cmd_quality_benchmark)

    release = sub.add_parser("release")
    release_sub = release.add_subparsers(dest="release_command", required=True)
    release_build = release_sub.add_parser("build")
    release_build.add_argument("--root", type=Path, default=Path("."))
    release_build.add_argument("--config", action="append")
    release_build.add_argument("--benchmark", action="append")
    release_build.add_argument("--qualification", action="append")
    release_build.add_argument("--deployment", action="append")
    release_build.add_argument("--state-schema-version", default="2")
    release_build.add_argument("--output", type=Path)
    release_build.set_defaults(func=_cmd_release_build)


    exposure = sub.add_parser("exposure")
    exposure_sub = exposure.add_subparsers(dest="exposure_command", required=True)
    exposure_benchmark = exposure_sub.add_parser("benchmark")
    exposure_benchmark.add_argument("--materials", type=int, default=10000)
    exposure_benchmark.add_argument("--output", type=Path)
    exposure_benchmark.set_defaults(func=_cmd_exposure_benchmark)

    history = sub.add_parser("history")
    history_sub = history.add_subparsers(dest="history_command", required=True)
    history_benchmark = history_sub.add_parser("benchmark")
    history_benchmark.add_argument("--cases", type=int, default=2000)
    history_benchmark.add_argument("--affected", type=int, default=100)
    history_benchmark.add_argument("--output", type=Path)
    history_benchmark.set_defaults(func=_cmd_history_benchmark)

    value = sub.add_parser("value")
    value_sub = value.add_subparsers(dest="value_command", required=True)
    value_cost_model = value_sub.add_parser("cost-model-validate")
    value_cost_model.add_argument("--model", type=Path, required=True)
    value_cost_model.set_defaults(func=_cmd_value_cost_model_validate)
    value_benchmark = value_sub.add_parser("benchmark")
    value_benchmark.add_argument("--cost-model", type=Path, default=Path("configs/value/synthetic_reference.yaml"))
    value_benchmark.add_argument("--output", type=Path)
    value_benchmark.set_defaults(func=_cmd_value_benchmark)

    operations = sub.add_parser("operations")
    operations_sub = operations.add_subparsers(dest="operations_command", required=True)

    operations_benchmark = operations_sub.add_parser("benchmark")
    operations_benchmark.add_argument("--deployment", type=Path, default=Path("configs/deployment/shadow-reference.yaml"))
    operations_benchmark.add_argument("--output", type=Path)
    operations_benchmark.set_defaults(func=_cmd_operations_benchmark)

    deployment_validate = operations_sub.add_parser("deployment-validate")
    deployment_validate.add_argument("--plan", type=Path, required=True)
    deployment_validate.set_defaults(func=_cmd_operations_deployment_validate)

    deployment_render = operations_sub.add_parser("deployment-render")
    deployment_render.add_argument("--plan", type=Path, required=True)
    deployment_render.add_argument("--output", type=Path)
    deployment_render.set_defaults(func=_cmd_operations_deployment_render)

    family_validate = operations_sub.add_parser("family-manifest-validate")
    family_validate.add_argument("--manifest", type=Path, required=True)
    family_validate.set_defaults(func=_cmd_operations_family_manifest_validate)

    control_activate = operations_sub.add_parser("control-activate")
    control_activate.add_argument("--state-db", type=Path, required=True)
    control_activate.add_argument("--kind", choices=[item.value for item in ControlKind], required=True)
    control_activate.add_argument("--scope", choices=[item.value for item in ControlScope], required=True)
    control_activate.add_argument("--target", required=True)
    control_activate.add_argument("--reason", required=True)
    control_activate.add_argument("--actor", required=True)
    control_activate.set_defaults(func=_cmd_operations_control_activate)

    control_deactivate = operations_sub.add_parser("control-deactivate")
    control_deactivate.add_argument("--state-db", type=Path, required=True)
    control_deactivate.add_argument("--control-id", required=True)
    control_deactivate.add_argument("--actor", required=True)
    control_deactivate.set_defaults(func=_cmd_operations_control_deactivate)

    control_list = operations_sub.add_parser("control-list")
    control_list.add_argument("--state-db", type=Path, required=True)
    control_list.add_argument("--active", action="store_true")
    control_list.set_defaults(func=_cmd_operations_control_list)

    rollback = operations_sub.add_parser("release-compatibility")
    rollback.add_argument("--source", type=Path, required=True)
    rollback.add_argument("--target", type=Path, required=True)
    rollback.add_argument("--source-state-schema")
    rollback.add_argument("--target-state-schema")
    rollback.add_argument("--destructive-migration", action="store_true")
    rollback.add_argument("--migration-available", action="store_true")
    rollback.add_argument("--migration-reversible", action="store_true")
    rollback.set_defaults(func=_cmd_operations_release_compatibility)

    worker = operations_sub.add_parser("worker")
    worker.add_argument("--role", choices=[item.value for item in RuntimeRole], required=True)
    worker.add_argument("--runtime-module")
    worker.add_argument("--state-db", type=Path)
    worker.add_argument("--handler-module")
    worker.add_argument("--worker-id", default="ephi-worker")
    worker.add_argument("--lease-seconds", type=int, default=300)
    worker.add_argument("--idle-sleep-seconds", type=float, default=1.0)
    worker.add_argument("--once", action="store_true")
    worker.set_defaults(func=_cmd_operations_worker)


    reliability = sub.add_parser("reliability")
    reliability_sub = reliability.add_subparsers(dest="reliability_command", required=True)

    reliability_benchmark = reliability_sub.add_parser("benchmark")
    reliability_benchmark.add_argument("--output", type=Path)
    reliability_benchmark.set_defaults(func=_cmd_reliability_benchmark)

    reliability_backup = reliability_sub.add_parser("backup")
    reliability_backup.add_argument("--state-db", type=Path, required=True)
    reliability_backup.add_argument("--release-id", required=True)
    reliability_backup.add_argument("--state-schema-version")
    reliability_backup.add_argument("--policy", type=Path, default=Path("configs/reliability/reference.yaml"))
    reliability_backup.add_argument("--output", type=Path, required=True)
    reliability_backup.set_defaults(func=_cmd_reliability_backup)

    reliability_inspect = reliability_sub.add_parser("backup-inspect")
    reliability_inspect.add_argument("--bundle", type=Path, required=True)
    reliability_inspect.set_defaults(func=_cmd_reliability_backup_inspect)

    reliability_restore = reliability_sub.add_parser("restore")
    reliability_restore.add_argument("--bundle", type=Path, required=True)
    reliability_restore.add_argument("--state-db", type=Path, required=True)
    reliability_restore.add_argument("--confirm-empty-target", action="store_true")
    reliability_restore.set_defaults(func=_cmd_reliability_restore)


    port = sub.add_parser("port")
    port_sub = port.add_subparsers(dest="port_command", required=True)

    port_contract = port_sub.add_parser("contract")
    port_contract.set_defaults(func=_cmd_port_contract)

    port_validate = port_sub.add_parser("module-validate")
    port_validate.add_argument("--runtime-module", default="ephi_company.bootstrap")
    port_validate.add_argument("--config", action="append")
    port_validate.add_argument("--release-manifest", type=Path, required=True)
    port_validate.set_defaults(func=_cmd_port_module_validate)

    port_bootstrap = port_sub.add_parser("bootstrap")
    port_bootstrap.add_argument("--runtime-module", default="ephi_company.bootstrap")
    port_bootstrap.add_argument("--config", action="append")
    port_bootstrap.add_argument("--release-manifest", type=Path, required=True)
    port_bootstrap.add_argument("--family-id")
    port_bootstrap.add_argument("--environment")
    port_bootstrap.add_argument(
        "--local-state-db", type=Path,
        help="local/scaffold testing only; company shadow should use build_port_state_store(config)",
    )
    port_bootstrap.add_argument("--restart", action="store_true")
    port_bootstrap.add_argument("--raise-on-error", action="store_true")
    port_bootstrap.add_argument("--output", type=Path)
    port_bootstrap.set_defaults(func=_cmd_port_bootstrap)

    port_qualification = port_sub.add_parser("qualification")
    port_qualification.add_argument("--root", type=Path, default=Path("."))
    port_qualification.add_argument("--output", type=Path)
    port_qualification.set_defaults(func=_cmd_port_qualification)

    port_preflight = port_sub.add_parser("production-preflight")
    port_preflight.add_argument("--preflight-module", default="ephi_company.production_preflight")
    port_preflight.add_argument("--config", action="append")
    port_preflight.add_argument("--deployment-plan", type=Path, default=Path("configs/deployment/shadow-reference.yaml"))
    port_preflight.add_argument("--release-manifest", type=Path, default=Path("RELEASE_MANIFEST.json"))
    port_preflight.add_argument("--output", type=Path)
    port_preflight.set_defaults(func=_cmd_port_production_preflight)

    port_prod_q = port_sub.add_parser("production-qualification")
    port_prod_q.add_argument("--root", type=Path, default=Path("."))
    port_prod_q.add_argument("--deployment-plan", type=Path, default=Path("configs/deployment/shadow-reference.yaml"))
    port_prod_q.add_argument("--release-manifest", type=Path, default=Path("RELEASE_MANIFEST.json"))
    port_prod_q.add_argument("--output", type=Path)
    port_prod_q.set_defaults(func=_cmd_port_production_qualification)

    onboarding = sub.add_parser("onboarding")
    onboarding_sub = onboarding.add_subparsers(dest="onboarding_command", required=True)

    onboarding_plan = onboarding_sub.add_parser("plan")
    onboarding_plan.add_argument("--data-reality", type=Path, required=True)
    onboarding_plan.add_argument("--policy", type=Path, required=True)
    onboarding_plan.add_argument("--release-manifest", type=Path, required=True)
    onboarding_plan.add_argument("--current-manifest", type=Path)
    onboarding_plan.add_argument("--output", type=Path)
    onboarding_plan.set_defaults(func=_cmd_onboarding_plan)

    golden_submit = onboarding_sub.add_parser("golden-submit")
    golden_submit.add_argument("--state-db", type=Path, required=True, help="local/reference curation store")
    golden_submit.add_argument("--intake", type=Path, required=True)
    golden_submit.set_defaults(func=_cmd_onboarding_golden_submit)

    golden_review = onboarding_sub.add_parser("golden-review")
    golden_review.add_argument("--state-db", type=Path, required=True, help="local/reference curation store")
    golden_review.add_argument("--intake-id", required=True)
    golden_review.add_argument("--state", choices=[item.value for item in GoldenCurationState], required=True)
    golden_review.add_argument("--reviewer", required=True)
    golden_review.add_argument("--note")
    golden_review.set_defaults(func=_cmd_onboarding_golden_review)

    golden_export = onboarding_sub.add_parser("golden-export")
    golden_export.add_argument("--state-db", type=Path, required=True, help="local/reference curation store")
    golden_export.add_argument("--corpus-id", required=True)
    golden_export.add_argument("--version", required=True)
    golden_export.add_argument("--description", required=True)
    golden_export.add_argument("--output", type=Path, required=True)
    golden_export.set_defaults(func=_cmd_onboarding_golden_export)

    promotion_package = onboarding_sub.add_parser("promotion-package")
    promotion_package.add_argument("--policy", type=Path, required=True)
    promotion_package.add_argument("--plan", type=Path, required=True)
    promotion_package.add_argument("--corpus", type=Path, required=True)
    promotion_package.add_argument("--gates", type=Path, required=True)
    promotion_package.add_argument("--from-state", choices=[item.value for item in CertificationState], required=True)
    promotion_package.add_argument("--target-state", choices=[item.value for item in CertificationState])
    promotion_package.add_argument("--shadow-metrics", type=Path)
    promotion_package.add_argument("--artifact", action="append")
    promotion_package.add_argument("--output", type=Path)
    promotion_package.set_defaults(func=_cmd_onboarding_promotion_package)

    family_manifest = onboarding_sub.add_parser("family-manifest")
    family_manifest.add_argument("--package", type=Path, action="append", required=True)
    family_manifest.add_argument("--approved-by")
    family_manifest.add_argument("--note", action="append")
    family_manifest.add_argument("--output", type=Path)
    family_manifest.set_defaults(func=_cmd_onboarding_family_manifest)

    onboarding_benchmark = onboarding_sub.add_parser("benchmark")
    onboarding_benchmark.add_argument("--output", type=Path)
    onboarding_benchmark.set_defaults(func=_cmd_onboarding_benchmark)

    onboarding_control = onboarding_sub.add_parser("control-benchmark")
    onboarding_control.add_argument("--output", type=Path)
    onboarding_control.set_defaults(func=_cmd_onboarding_control_benchmark)

    launch = sub.add_parser("launch")
    launch_sub = launch.add_subparsers(dest="launch_command", required=True)

    launch_plan = launch_sub.add_parser("plan")
    launch_plan.add_argument("--release-manifest", type=Path, required=True)
    launch_plan.add_argument("--policy", type=Path, default=Path("configs/launch/metrology_reference.yaml"))
    launch_plan.add_argument("--family-id")
    launch_plan.add_argument("--current-state", choices=[item.value for item in CertificationState], required=True)
    launch_plan.add_argument("--target-state", choices=[item.value for item in CertificationState], required=True)
    launch_plan.add_argument("--data-reality", type=Path)
    launch_plan.add_argument("--evidence", type=Path, action="append")
    launch_plan.add_argument("--output", type=Path)
    launch_plan.set_defaults(func=_cmd_launch_plan)

    launch_golden = launch_sub.add_parser("golden-manifest")
    launch_golden.add_argument("--release-manifest", type=Path, required=True)
    launch_golden.add_argument("--corpus", type=Path, required=True)
    launch_golden.add_argument("--family-id", required=True)
    launch_golden.add_argument("--source-snapshot-id", required=True)
    launch_golden.add_argument("--replay-as-of", required=True)
    launch_golden.add_argument("--output", type=Path)
    launch_golden.set_defaults(func=_cmd_launch_golden_manifest)

    launch_collect = launch_sub.add_parser("collect")
    launch_collect.add_argument("--module", default="ephi_company.launch")
    launch_collect.add_argument("--config", action="append")
    launch_collect.add_argument("--release-manifest", type=Path, required=True)
    launch_collect.add_argument("--stage", choices=["data-reality", "golden", "scale", "dr", "shadow-runtime", "engineer-shadow"], required=True)
    launch_collect.add_argument("--output", type=Path)
    launch_collect.set_defaults(func=_cmd_launch_collect)

    launch_receipt = launch_sub.add_parser("receipt")
    launch_receipt.add_argument("--release-manifest", type=Path, required=True)
    launch_receipt.add_argument("--family-id", required=True)
    launch_receipt.add_argument("--evidence-id", required=True)
    launch_receipt.add_argument("--kind", choices=[item.value for item in LaunchEvidenceKind], required=True)
    launch_receipt.add_argument("--provenance", choices=[item.value for item in EvidenceProvenance], required=True)
    launch_receipt.add_argument("--decision", choices=[item.value for item in EvidenceDecision], required=True)
    launch_receipt.add_argument("--artifact", type=Path, required=True)
    launch_receipt.add_argument("--validator")
    launch_receipt.add_argument("--source-snapshot-id")
    launch_receipt.add_argument("--output", type=Path)
    launch_receipt.set_defaults(func=_cmd_launch_receipt)

    launch_dossier = launch_sub.add_parser("dossier")
    launch_dossier.add_argument("--release-manifest", type=Path, required=True)
    launch_dossier.add_argument("--policy", type=Path, default=Path("configs/launch/metrology_reference.yaml"))
    launch_dossier.add_argument("--family-id")
    launch_dossier.add_argument("--current-state", choices=[item.value for item in CertificationState], required=True)
    launch_dossier.add_argument("--target-state", choices=[item.value for item in CertificationState], required=True)
    launch_dossier.add_argument("--evidence", type=Path, action="append", required=True)
    launch_dossier.add_argument("--data-reality", type=Path)
    launch_dossier.add_argument("--replay-manifest", type=Path, action="append")
    launch_dossier.add_argument("--output", type=Path)
    launch_dossier.set_defaults(func=_cmd_launch_dossier)

    launch_module = launch_sub.add_parser("module-validate")
    launch_module.add_argument("--module", default="ephi_company.launch")
    launch_module.set_defaults(func=_cmd_launch_module_validate)

    launch_qualification = launch_sub.add_parser("qualification")
    launch_qualification.add_argument("--policy", type=Path, default=Path("configs/launch/metrology_reference.yaml"))
    launch_qualification.add_argument("--output", type=Path)
    launch_qualification.set_defaults(func=_cmd_launch_qualification)

    launch_adapter = launch_sub.add_parser("adapter-validate")
    launch_adapter.add_argument("--module", default="ephi_company.launch")
    launch_adapter.add_argument("--config", action="append")
    launch_adapter.add_argument("--release-manifest", type=Path, required=True)
    launch_adapter.set_defaults(func=_cmd_launch_adapter_validate)

    launch_campaign = launch_sub.add_parser("campaign-run")
    launch_campaign.add_argument("--launch-module", default="ephi_company.launch")
    launch_campaign.add_argument("--state-module", default="ephi_company.state")
    launch_campaign.add_argument("--config", action="append")
    launch_campaign.add_argument("--release-manifest", type=Path, required=True)
    launch_campaign.add_argument("--policy", type=Path, default=Path("configs/launch/metrology_reference.yaml"))
    launch_campaign.add_argument("--family-id")
    launch_campaign.add_argument("--campaign-id", required=True)
    launch_campaign.add_argument("--current-state", choices=[item.value for item in CertificationState], required=True)
    launch_campaign.add_argument("--target-state", choices=[item.value for item in CertificationState], required=True)
    launch_campaign.add_argument("--stage", action="append", choices=[item.value for item in CampaignStage])
    launch_campaign.add_argument("--actor", required=True)
    launch_campaign.add_argument("--max-attempts", type=int, default=3)
    launch_campaign.add_argument("--output", type=Path)
    launch_campaign.add_argument("--dossier-output", type=Path)
    launch_campaign.add_argument("--workspace-output", type=Path)
    launch_campaign.set_defaults(func=_cmd_launch_campaign_run)

    launch_status = launch_sub.add_parser("campaign-status")
    launch_status.add_argument("--state-module", default="ephi_company.state")
    launch_status.add_argument("--config", action="append")
    launch_status.add_argument("--family-id", required=True)
    launch_status.add_argument("--campaign-id", required=True)
    launch_status.add_argument("--output", type=Path)
    launch_status.set_defaults(func=_cmd_launch_campaign_status)

    def _add_campaign_observability_args(parser):
        parser.add_argument("--state-module", default="ephi_company.state")
        parser.add_argument("--services-module")
        parser.add_argument("--config", action="append")
        parser.add_argument("--family-id", required=True)
        parser.add_argument("--policy", type=Path, default=Path("configs/launch/metrology_reference.yaml"))
        parser.add_argument("--slo-policy", type=Path, default=Path("configs/campaign/metrology_reference.yaml"))
        parser.add_argument("--retention-policy", type=Path, default=Path("configs/campaign/retention_reference.yaml"))

    launch_readiness = launch_sub.add_parser("campaign-readiness")
    _add_campaign_observability_args(launch_readiness)
    launch_readiness.add_argument("--campaign-id", required=True)
    launch_readiness.add_argument("--current-state", choices=[item.value for item in CertificationState])
    launch_readiness.add_argument("--output", type=Path)
    launch_readiness.set_defaults(func=_cmd_launch_campaign_readiness)

    launch_events = launch_sub.add_parser("campaign-events")
    _add_campaign_observability_args(launch_events)
    launch_events.add_argument("--campaign-id", required=True)
    launch_events.add_argument("--output", type=Path)
    launch_events.set_defaults(func=_cmd_launch_campaign_events)

    launch_compare = launch_sub.add_parser("campaign-compare")
    _add_campaign_observability_args(launch_compare)
    launch_compare.add_argument("--baseline-campaign-id", required=True)
    launch_compare.add_argument("--candidate-campaign-id", required=True)
    launch_compare.add_argument("--output", type=Path)
    launch_compare.set_defaults(func=_cmd_launch_campaign_compare)

    launch_export = launch_sub.add_parser("campaign-export")
    _add_campaign_observability_args(launch_export)
    launch_export.add_argument("--campaign-id", required=True)
    launch_export.add_argument("--current-state", choices=[item.value for item in CertificationState])
    launch_export.add_argument("--publish", action="store_true")
    launch_export.add_argument("--output", type=Path)
    launch_export.set_defaults(func=_cmd_launch_campaign_export)

    launch_obs_q = launch_sub.add_parser("observability-qualification")
    launch_obs_q.add_argument("--output", type=Path)
    launch_obs_q.set_defaults(func=_cmd_launch_observability_qualification)

    launch_handoff = launch_sub.add_parser("handoff")
    launch_handoff.add_argument("--services-module", default="ephi_company.services")
    launch_handoff.add_argument("--config", action="append")
    launch_handoff.add_argument("--dossier", type=Path, required=True)
    launch_handoff.add_argument("--actor", required=True)
    launch_handoff.add_argument("--capability-id", default="behavioral-health")
    launch_handoff.add_argument("--command-prefix")
    launch_handoff.add_argument("--output", type=Path)
    launch_handoff.set_defaults(func=_cmd_launch_handoff)

    launch_execution_q = launch_sub.add_parser("execution-qualification")
    launch_execution_q.add_argument("--policy", type=Path, default=Path("configs/launch/metrology_reference.yaml"))
    launch_execution_q.add_argument("--output", type=Path)
    launch_execution_q.set_defaults(func=_cmd_launch_execution_qualification)

    launch_dry = launch_sub.add_parser("dry-run")
    launch_dry.add_argument("--release-manifest", type=Path, required=True)
    launch_dry.add_argument("--policy", type=Path, default=Path("configs/launch/metrology_reference.yaml"))
    launch_dry.add_argument("--inject-retry", action="store_true")
    launch_dry.add_argument("--output", type=Path)
    launch_dry.set_defaults(func=_cmd_launch_dry_run)

    advisory = sub.add_parser("advisory")
    advisory_sub = advisory.add_subparsers(dest="advisory_command", required=True)
    advisory_demo = advisory_sub.add_parser("demo")
    advisory_demo.add_argument("--output", type=Path)
    advisory_demo.set_defaults(func=_cmd_advisory_demo)

    api = sub.add_parser("api")
    api_sub = api.add_subparsers(dest="api_command", required=True)
    serve = api_sub.add_parser("serve")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8000)
    serve.add_argument("--config", action="append")
    serve.add_argument("--app-factory-module")
    serve.set_defaults(func=_cmd_api_serve)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except (ValueError, FileNotFoundError, KeyError) as exc:
        print(f"ERROR: {exc}", file=__import__("sys").stderr)
        return 2
    except Exception as exc:
        # CompanyPortNotConfiguredError intentionally lives outside generic core.
        # Recognize it by type name so expected porting gaps are concise while real
        # programming/runtime exceptions still retain full tracebacks.
        if exc.__class__.__name__ == "CompanyPortNotConfiguredError":
            print(f"ERROR: {exc}", file=__import__("sys").stderr)
            return 2
        raise


if __name__ == "__main__":
    raise SystemExit(main())
