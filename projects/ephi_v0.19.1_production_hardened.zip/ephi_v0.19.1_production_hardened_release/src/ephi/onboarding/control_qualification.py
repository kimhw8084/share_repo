from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory

from pydantic import BaseModel, ConfigDict

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.domain.benchmark import BenchmarkCaseType, BenchmarkFamily, BenchmarkLabelConfidence
from ephi.domain.capabilities import Capability
from ephi.domain.data_reality import CapabilityAssessment, DataRealityReport, QualificationState
from ephi.domain.evidence import Hypothesis
from ephi.domain.onboarding import GoldenCaseIntake, GoldenCurationState, ShadowReviewCandidate
from ephi.domain.operations import (
    CertificationState,
    EngineerShadowReview,
    GateResult,
    QualificationPlane,
    ShadowReviewDisposition,
)
from ephi.onboarding.control_plane import QualificationControlPlaneService
from ephi.onboarding.control_repository import QualificationWorkspaceRepository
from ephi.onboarding.planner import build_family_onboarding_plan
from ephi.onboarding.policy import FamilyOnboardingPolicy, GoldenCoveragePolicy, ShadowSamplingPolicy


class QualificationControlPlaneReport(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    passed: bool
    concurrent_writes_preserved: bool
    concurrent_shadow_claim_single_winner: bool
    concurrent_promotion_approval_single_winner: bool
    authenticated_golden_identity: bool
    independent_golden_review: bool
    shadow_claim_exclusive: bool
    shadow_completion_atomic: bool
    promotion_evidence_ready: bool
    promotion_manifest_persisted: bool
    stale_promotion_blocked: bool
    restart_history_preserved: bool
    audit_lineage_complete: bool
    export_complete: bool
    concurrent_commands: int
    audit_events: int


def _policy(_: str) -> FamilyOnboardingPolicy:
    return FamilyOnboardingPolicy(
        family_id="MET",
        required_capabilities=(Capability.METROLOGY,),
        golden=GoldenCoveragePolicy(
            min_cases=1,
            min_high_confidence_cases=1,
            required_case_types=(BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT,),
            require_internal_history=True,
        ),
        shadow_sampling=ShadowSamplingPolicy(),
    )


def _service(path: Path) -> QualificationControlPlaneService:
    return QualificationControlPlaneService(
        QualificationWorkspaceRepository(SqliteStateStore(path)), policy_resolver=_policy
    )


def _intake(case_id: str, now: datetime) -> GoldenCaseIntake:
    return GoldenCaseIntake(
        intake_id=case_id,
        family=BenchmarkFamily.METROLOGY,
        case_type=BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT,
        source_locator=f"materialization://qualification/{case_id}",
        submitted_by="untrusted-body",
        submitted_at=now - timedelta(hours=1),
        scope_start=now - timedelta(days=2),
        scope_end=now - timedelta(days=1),
        label_confidence=BenchmarkLabelConfidence.HIGH_CONFIDENCE,
        expected_hypothesis=Hypothesis.METROLOGY_SYSTEM_SHIFT,
        expected_local_actionable=True,
        expected_asset_ids=("HEAD-A",),
        evidence_refs=(f"internal-case-review://{case_id}",),
        state=GoldenCurationState.DRAFT,
    )


def _plan(now: datetime):
    report = DataRealityReport(
        datasets=(), joins=(), generated_at=now.isoformat(),
        capabilities=(CapabilityAssessment(capability=Capability.METROLOGY, state=QualificationState.QUALIFIED),),
    )
    return build_family_onboarding_plan(
        family_id="MET", release_id="R14", report=report,
        required_capabilities=(Capability.METROLOGY,),
        target_state=CertificationState.OFFLINE_QUALIFIED,
        generated_at=now,
    )


def run_qualification_control_plane_qualification() -> QualificationControlPlaneReport:
    now = datetime(2026, 8, 19, 18, 30, tzinfo=timezone.utc)
    with TemporaryDirectory() as temp:
        db = Path(temp) / "qualification.sqlite3"

        def submit(index: int) -> None:
            _service(db).submit_golden(
                "MET", _intake(f"CONCURRENT-{index:02d}", now),
                actor=f"engineer-{index:02d}", command_id=f"CC-{index:02d}",
                at=now + timedelta(seconds=index),
            )

        with ThreadPoolExecutor(max_workers=6) as pool:
            list(pool.map(submit, range(12)))
        service = _service(db)
        concurrent_writes_preserved = len(service.latest_golden_intakes("MET")) == 12

        submitted = service.submit_golden(
            "MET", _intake("CASE-MAIN", now), actor="alice", command_id="SUB-MAIN", at=now
        )
        authenticated_golden_identity = submitted.submitted_by == "alice"
        try:
            service.review_golden(
                "MET", "CASE-MAIN", state=GoldenCurationState.ACCEPTED,
                actor="alice", command_id="SELF", at=now + timedelta(minutes=1),
            )
            independent_golden_review = False
        except ValueError:
            independent_golden_review = True
        service.review_golden(
            "MET", "CASE-MAIN", state=GoldenCurationState.ACCEPTED,
            actor="bob", command_id="REVIEW", at=now + timedelta(minutes=2),
        )

        candidate = ShadowReviewCandidate(
            episode_id="EP-Q14", family_id="MET", asset_id="HEAD-A",
            technical_severity="INVESTIGATE", operational_priority="P1",
            leading_hypothesis=Hypothesis.METROLOGY_SYSTEM_SHIFT,
            confidence=0.82, opened_at=now,
        )
        service.enqueue_shadow_candidates(
            "MET", (candidate,), max_items=1, actor="system", command_id="ENQ", at=now
        )
        claim = service.claim_shadow_review("MET", actor="reviewer-a", command_id="CLAIM-A", at=now)
        second = service.claim_shadow_review(
            "MET", actor="reviewer-b", command_id="CLAIM-B", at=now + timedelta(minutes=1)
        )
        shadow_claim_exclusive = claim is not None and second is None
        review = EngineerShadowReview(
            review_id="REV-Q14", episode_id="forged", reviewer="forged",
            disposition=ShadowReviewDisposition.WANT_EVENT,
            comparison_valid=True, hypothesis_reasonable=True, verification_useful=True,
            reviewed_at=now - timedelta(days=1),
        )
        completed = service.complete_shadow_review(
            "MET", "EP-Q14", review, actor="reviewer-a", command_id="COMPLETE",
            at=now + timedelta(minutes=2),
        )
        shadow_completion_atomic = (
            completed.reviewer == "reviewer-a"
            and completed.episode_id == "EP-Q14"
            and service.summary("MET").completed_shadow_reviews == 1
        )

        service.register_plan(_plan(now), actor="qual-admin", command_id="PLAN", at=now)
        for index, plane in enumerate((
            QualificationPlane.DATA_REALITY,
            QualificationPlane.BEHAVIORAL_METROLOGY,
            QualificationPlane.RUNTIME_SCALE,
        )):
            service.record_gate(
                "MET", release_id="R14", capability_id="behavioral-health",
                result=GateResult(plane=plane, passed=True, artifact=f"{plane.value}.json"),
                actor="qual-admin", command_id=f"GATE-{index}",
                at=now + timedelta(minutes=3 + index),
            )
        package = service.generate_promotion(
            "MET", capability_id="behavioral-health",
            target_state=CertificationState.OFFLINE_QUALIFIED,
            actor="qual-admin", command_id="GENERATE", at=now + timedelta(minutes=8),
        )
        promotion_evidence_ready = package.package.decision.value == "READY"
        manifest = service.approve_promotion(
            "MET", package_ids=(package.package_id,), actor="approver",
            command_id="APPROVE", at=now + timedelta(minutes=9),
        )
        promotion_manifest_persisted = (
            manifest.state == CertificationState.OFFLINE_QUALIFIED
            and _service(db).current_manifest("MET") == manifest
        )

        # A package generated from RESEARCH must not remain approvable after the state moves.
        # The existing approved package is deliberately reused under a new command path.
        try:
            service.approve_promotion(
                "MET", package_ids=(package.package_id,), actor="approver-2",
                command_id="STALE-APPROVE", at=now + timedelta(minutes=10),
            )
            stale_promotion_blocked = False
        except ValueError:
            stale_promotion_blocked = True

        race_db = Path(temp) / "qualification-race.sqlite3"
        race_service = _service(race_db)
        race_candidate = candidate.model_copy(update={"episode_id": "EP-RACE"})
        race_service.enqueue_shadow_candidates(
            "MET", (race_candidate,), max_items=1, actor="system", command_id="RACE-ENQ", at=now
        )
        def race_claim(actor: str):
            return _service(race_db).claim_shadow_review(
                "MET", actor=actor, command_id=f"RACE-CLAIM-{actor}", at=now + timedelta(seconds=1)
            )
        with ThreadPoolExecutor(max_workers=2) as pool:
            race_claims = list(pool.map(race_claim, ("reviewer-x", "reviewer-y")))
        concurrent_shadow_claim_single_winner = sum(item is not None for item in race_claims) == 1

        approval_db = Path(temp) / "qualification-approval-race.sqlite3"
        approval_service = _service(approval_db)
        approval_service.register_plan(_plan(now), actor="admin", command_id="A-PLAN", at=now)
        approval_service.submit_golden("MET", _intake("A-CASE", now), actor="alice", command_id="A-SUB", at=now)
        approval_service.review_golden(
            "MET", "A-CASE", state=GoldenCurationState.ACCEPTED, actor="bob",
            command_id="A-REV", at=now + timedelta(minutes=1),
        )
        for index, plane in enumerate((QualificationPlane.DATA_REALITY, QualificationPlane.BEHAVIORAL_METROLOGY, QualificationPlane.RUNTIME_SCALE)):
            approval_service.record_gate(
                "MET", release_id="R14", capability_id="behavioral-health",
                result=GateResult(plane=plane, passed=True), actor="admin",
                command_id=f"A-GATE-{index}", at=now + timedelta(minutes=2 + index),
            )
        approval_package = approval_service.generate_promotion(
            "MET", capability_id="behavioral-health", target_state=CertificationState.OFFLINE_QUALIFIED,
            actor="admin", command_id="A-GEN", at=now + timedelta(minutes=8),
        )
        def race_approve(actor: str):
            try:
                return _service(approval_db).approve_promotion(
                    "MET", package_ids=(approval_package.package_id,), actor=actor,
                    command_id=f"A-APPROVE-{actor}", at=now + timedelta(minutes=9),
                )
            except ValueError:
                return None
        with ThreadPoolExecutor(max_workers=2) as pool:
            approval_results = list(pool.map(race_approve, ("approver-x", "approver-y")))
        concurrent_promotion_approval_single_winner = (
            sum(item is not None for item in approval_results) == 1
            and len(_service(approval_db).manifest_history("MET")) == 1
        )

        restored = _service(db)
        restart_history_preserved = (
            len(restored.manifest_history("MET")) == 1
            and len(restored.golden_history("MET", "CASE-MAIN")) == 2
            and len(restored.workspace("MET").shadow_reviews) == 1
        )
        audit = restored.audit("MET")
        audit_lineage_complete = (
            len(audit) >= 24
            and {"alice", "bob", "reviewer-a", "qual-admin", "approver"}.issubset({item.actor for item in audit})
        )
        exported = restored.export_workspace("MET", at=now + timedelta(minutes=11))
        export_complete = (
            exported.summary.accepted_golden_cases == 1
            and len(exported.family_manifests) == 1
            and len(exported.gate_records) == 3
            and len(exported.audit_events) == len(audit)
        )

    checks = {
        "concurrent_writes_preserved": concurrent_writes_preserved,
        "concurrent_shadow_claim_single_winner": concurrent_shadow_claim_single_winner,
        "concurrent_promotion_approval_single_winner": concurrent_promotion_approval_single_winner,
        "authenticated_golden_identity": authenticated_golden_identity,
        "independent_golden_review": independent_golden_review,
        "shadow_claim_exclusive": shadow_claim_exclusive,
        "shadow_completion_atomic": shadow_completion_atomic,
        "promotion_evidence_ready": promotion_evidence_ready,
        "promotion_manifest_persisted": promotion_manifest_persisted,
        "stale_promotion_blocked": stale_promotion_blocked,
        "restart_history_preserved": restart_history_preserved,
        "audit_lineage_complete": audit_lineage_complete,
        "export_complete": export_complete,
    }
    return QualificationControlPlaneReport(
        passed=all(checks.values()),
        concurrent_commands=12,
        audit_events=len(audit),
        **checks,
    )
