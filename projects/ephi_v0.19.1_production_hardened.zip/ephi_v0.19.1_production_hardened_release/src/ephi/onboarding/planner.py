from __future__ import annotations

from datetime import datetime, timezone

from ephi.domain.capabilities import Capability
from ephi.domain.data_reality import DataRealityReport, QualificationState
from ephi.domain.onboarding import (
    CapabilityGap,
    CapabilityRequirement,
    FamilyOnboardingPlan,
    GapSeverity,
    OnboardingAction,
    OnboardingActionKind,
)
from ephi.domain.operations import CertificationState, FamilyQualificationManifest


_ACCEPTABLE = {QualificationState.QUALIFIED}


def _action_id(kind: OnboardingActionKind, capability: Capability | None, index: int) -> str:
    suffix = capability.value if capability else "FAMILY"
    return f"{kind.value}:{suffix}:{index:02d}"


def _gap_actions(capability: Capability, state: QualificationState) -> tuple[OnboardingAction, ...]:
    actions: list[OnboardingAction] = []
    if state in {QualificationState.UNAVAILABLE, QualificationState.FAILED}:
        actions.append(OnboardingAction(
            action_id=_action_id(OnboardingActionKind.COMPLETE_MAPPING, capability, 1),
            kind=OnboardingActionKind.COMPLETE_MAPPING,
            capability=capability,
            description=f"Map and validate physical sources required for {capability.value}",
            evidence_required=("mapping validation", "dataset audit"),
        ))
    if state != QualificationState.QUALIFIED:
        actions.append(OnboardingAction(
            action_id=_action_id(OnboardingActionKind.QUALIFY_DATA_REALITY, capability, 2),
            kind=OnboardingActionKind.QUALIFY_DATA_REALITY,
            capability=capability,
            description=f"Resolve Data Reality limitations until {capability.value} is QUALIFIED",
            evidence_required=("Data Reality capability assessment",),
        ))
    return tuple(actions)


def build_family_onboarding_plan(
    *,
    family_id: str,
    release_id: str,
    report: DataRealityReport,
    required_capabilities: tuple[Capability, ...],
    optional_capabilities: tuple[Capability, ...] = (),
    current_manifest: FamilyQualificationManifest | None = None,
    target_state: CertificationState = CertificationState.OFFLINE_QUALIFIED,
    generated_at: datetime | None = None,
) -> FamilyOnboardingPlan:
    generated_at = generated_at or datetime.now(timezone.utc)
    current_state = current_manifest.state if current_manifest else CertificationState.RESEARCH
    gaps: list[CapabilityGap] = []
    actions: list[OnboardingAction] = []
    blockers: list[str] = []
    limitations: list[str] = []

    for requirement, capabilities in (
        (CapabilityRequirement.REQUIRED, required_capabilities),
        (CapabilityRequirement.OPTIONAL, optional_capabilities),
    ):
        for capability in capabilities:
            assessment = report.capability(capability)
            state = assessment.state if assessment else QualificationState.UNAVAILABLE
            reasons = assessment.reasons if assessment else ("capability missing from Data Reality report",)
            if state == QualificationState.QUALIFIED:
                severity = GapSeverity.INFORMATION
                gap_actions: tuple[OnboardingAction, ...] = ()
            elif requirement == CapabilityRequirement.REQUIRED:
                severity = GapSeverity.BLOCKER
                gap_actions = _gap_actions(capability, state)
                blockers.append(f"required capability {capability.value} is {state.value}")
            else:
                severity = GapSeverity.LIMITATION
                gap_actions = _gap_actions(capability, state)
                limitations.append(f"optional capability {capability.value} is {state.value}")
                gap_actions = tuple(item.model_copy(update={"blocking": False}) for item in gap_actions)
            gaps.append(CapabilityGap(
                capability=capability,
                requirement=requirement,
                observed_state=state,
                severity=severity,
                reasons=tuple(reasons),
                supporting_datasets=assessment.supporting_datasets if assessment else (),
                supporting_joins=assessment.supporting_joins if assessment else (),
                actions=gap_actions,
            ))
            actions.extend(gap_actions)

    # Qualification work is explicit even when Data Reality is already green.
    if target_state != CertificationState.RESEARCH:
        actions.extend((
            OnboardingAction(
                action_id="CURATE_GOLDEN_CASES:FAMILY:01",
                kind=OnboardingActionKind.CURATE_GOLDEN_CASES,
                description="Curate representative healthy, excursion, benign, common-mode, and ambiguous historical cases",
                evidence_required=("accepted Golden case registry",),
            ),
            OnboardingAction(
                action_id="RUN_GOLDEN_REPLAY:FAMILY:02",
                kind=OnboardingActionKind.RUN_GOLDEN_REPLAY,
                description="Run strict knowledge-time Golden replay under the exact release/config",
                evidence_required=("Golden qualification report",),
            ),
            OnboardingAction(
                action_id="RUN_RUNTIME_SCALE:FAMILY:03",
                kind=OnboardingActionKind.RUN_RUNTIME_SCALE,
                description="Measure steady-state runtime, correction, restart, and source-read behavior",
                evidence_required=("runtime/scale qualification report",),
            ),
        ))
    if target_state in {CertificationState.SHADOW, CertificationState.SHADOW_QUALIFIED}:
        actions.append(OnboardingAction(
            action_id="START_SHADOW:FAMILY:04",
            kind=OnboardingActionKind.START_SHADOW,
            description="Start notification-suppressed shadow execution after offline gates pass",
            evidence_required=("shadow run identity", "freshness/SLO report"),
        ))
    if target_state == CertificationState.SHADOW_QUALIFIED:
        actions.append(OnboardingAction(
            action_id="COLLECT_ENGINEER_REVIEWS:FAMILY:05",
            kind=OnboardingActionKind.COLLECT_ENGINEER_REVIEWS,
            description="Collect stratified engineer reviews and missed-event reports until shadow gate is satisfied",
            evidence_required=("engineer shadow summary", "review coverage report"),
        ))

    # Stable deterministic ordering, no duplicate actions.
    unique = {item.action_id: item for item in actions}
    return FamilyOnboardingPlan(
        family_id=family_id,
        release_id=release_id,
        generated_at=generated_at,
        current_state=current_state,
        target_state=target_state,
        required_capabilities=required_capabilities,
        optional_capabilities=optional_capabilities,
        gaps=tuple(gaps),
        actions=tuple(unique[key] for key in sorted(unique)),
        blockers=tuple(blockers),
        limitations=tuple(limitations),
    )


def capability_report_from_payload(payload: dict[str, object]) -> DataRealityReport:
    """Rehydrate the capability portion of a persisted Data Reality JSON report.

    Family planning needs capability states/reasons, not physical dataset profiles. This
    deliberately avoids inventing DatasetContract objects from flattened audit JSON.
    """
    raw = payload.get("capabilities", [])
    if not isinstance(raw, list):
        raise TypeError("Data Reality payload capabilities must be a list")
    from ephi.domain.data_reality import CapabilityAssessment
    assessments = []
    for item in raw:
        if not isinstance(item, dict):
            raise TypeError("Data Reality capability entries must be objects")
        assessments.append(CapabilityAssessment(
            capability=Capability(str(item["capability"])),
            state=QualificationState(str(item["state"])),
            supporting_datasets=tuple(str(x) for x in item.get("supporting_datasets", [])),
            supporting_joins=tuple(str(x) for x in item.get("supporting_joins", [])),
            reasons=tuple(str(x) for x in item.get("reasons", [])),
        ))
    return DataRealityReport(
        datasets=(), joins=(), capabilities=tuple(assessments),
        generated_at=str(payload.get("generated_at", "unknown")),
        config_hash=str(payload["config_hash"]) if payload.get("config_hash") is not None else None,
    )
