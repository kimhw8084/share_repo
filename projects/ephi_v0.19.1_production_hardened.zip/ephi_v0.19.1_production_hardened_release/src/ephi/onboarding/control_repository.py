from __future__ import annotations

import json
import time
from collections.abc import Callable
from datetime import datetime, timezone

from ephi.adapters.base.state_store import StateStore
from ephi.domain.qualification_control import FamilyQualificationWorkspace
from ephi.errors import StateConflictError


class QualificationWorkspaceRepository:
    """Family-partitioned durable workspace with optimistic-CAS conflict retries.

    The repository intentionally has no mutable process-local cache. Every mutation
    re-reads the latest family workspace, reapplies the command, and commits with CAS.
    This keeps multi-user qualification writes safe on any shared CAS-capable backend.
    """

    def __init__(self, state_store: StateStore, *, max_conflict_retries: int = 64) -> None:
        if max_conflict_retries < 1:
            raise ValueError("max_conflict_retries must be positive")
        self.state_store = state_store
        self.max_conflict_retries = max_conflict_retries

    @staticmethod
    def key(family_id: str) -> str:
        normalized = family_id.strip()
        if not normalized:
            raise ValueError("family_id cannot be blank")
        return f"onboarding:qualification-control:{normalized}:v1"

    def load(self, family_id: str) -> FamilyQualificationWorkspace:
        record = self.state_store.get(self.key(family_id))
        if record is None:
            return FamilyQualificationWorkspace(family_id=family_id)
        return FamilyQualificationWorkspace.model_validate_json(record.value)

    def mutate(
        self,
        family_id: str,
        mutator: Callable[[FamilyQualificationWorkspace], FamilyQualificationWorkspace],
    ) -> FamilyQualificationWorkspace:
        key = self.key(family_id)
        last_error: StateConflictError | None = None
        for attempt in range(self.max_conflict_retries):
            record = self.state_store.get(key)
            current = (
                FamilyQualificationWorkspace(family_id=family_id)
                if record is None
                else FamilyQualificationWorkspace.model_validate_json(record.value)
            )
            updated = mutator(current)
            if updated.family_id != family_id:
                raise ValueError("workspace mutator cannot change family_id")
            if updated.updated_at is None:
                updated = updated.model_copy(update={"updated_at": datetime.now(timezone.utc)})
            payload = json.dumps(
                updated.model_dump(mode="json"), sort_keys=True, separators=(",", ":")
            ).encode("utf-8")
            try:
                self.state_store.compare_and_set(
                    key,
                    expected_version=None if record is None else record.version,
                    value=payload,
                )
                return updated
            except StateConflictError as exc:
                last_error = exc
                # Bounded contention backoff. Shared production stores may have their own
                # transaction scheduler; this merely prevents hot CAS spinning in the
                # portable reference implementation.
                time.sleep(min(0.0005 * (2 ** min(attempt, 6)), 0.02))
                continue
        raise StateConflictError(
            f"qualification workspace conflict retry budget exhausted for {family_id}"
        ) from last_error
