from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone

from ephi.domain.benchmark import BenchmarkCase, BenchmarkSourceKind
from ephi.domain.onboarding import (
    FamilyOnboardingPlan,
    PromotionDecision,
    PromotionEvidencePackage,
    ShadowQualificationMetrics,
)
from ephi.domain.operations import (
    CapabilityCertification,
    CertificationState,
    FamilyQualificationManifest,
    GateResult,
    QualificationPlane,
)
from ephi.operations.certification import CertificationPolicy, CertificationService
from ephi.operations.shadow_review import ShadowGatePolicy
from ephi.onboarding.policy import GoldenCoveragePolicy


class PromotionEvidenceBuilder:
    def __init__(
        self,
        *,
        certification_policy: CertificationPolicy | None = None,
        shadow_policy: ShadowGatePolicy | None = None,
        golden_policy: GoldenCoveragePolicy | None = None,
    ) -> None:
        self.certification_policy = certification_policy or CertificationPolicy.reference()
        self.shadow_policy = shadow_policy or ShadowGatePolicy()
        self.golden_policy = golden_policy

    def build(
        self,
        *,
        family_id: str,
        release_id: str,
        from_state: CertificationState,
        target_state: CertificationState,
        gate_results: tuple[GateResult, ...],
        onboarding_plan: FamilyOnboardingPlan,
        golden_cases: tuple[BenchmarkCase, ...],
        shadow_metrics: ShadowQualificationMetrics | None = None,
        evidence_artifacts: tuple[str, ...] = (),
        generated_at: datetime | None = None,
        capability_id: str = "behavioral-health",
    ) -> PromotionEvidencePackage:
        generated_at = generated_at or datetime.now(timezone.utc)
        blockers = list(onboarding_plan.blockers)
        transition_shell = CapabilityCertification(
            capability_id=capability_id, state=from_state, gate_results=gate_results
        )
        try:
            CertificationService(self.certification_policy).validate_transition(transition_shell, target_state)
        except ValueError as exc:
            blockers.append(str(exc))
        passed = frozenset(item.plane for item in gate_results if item.passed)
        required = self.certification_policy.required_planes(target_state, capability_id)
        missing = required - passed
        blockers.extend(f"missing qualification plane: {item.value}" for item in sorted(missing, key=lambda item: item.value))

        if target_state != CertificationState.RESEARCH and not golden_cases:
            blockers.append("no accepted Golden historical cases")
        if target_state != CertificationState.RESEARCH and self.golden_policy is not None:
            eligible = [
                case for case in golden_cases
                if case.label_confidence in self.golden_policy.accepted_confidences
                and (not self.golden_policy.require_internal_history or case.source_kind == BenchmarkSourceKind.INTERNAL_HISTORY)
            ]
            if len(eligible) < self.golden_policy.min_cases:
                blockers.append(f"eligible Golden case count {len(eligible)} < {self.golden_policy.min_cases}")
            high = sum(case.label_confidence.value in {"CONFIRMED", "HIGH_CONFIDENCE"} for case in eligible)
            if high < self.golden_policy.min_high_confidence_cases:
                blockers.append(
                    f"high-confidence Golden case count {high} < {self.golden_policy.min_high_confidence_cases}"
                )
            present = {case.case_type for case in eligible}
            for case_type in self.golden_policy.required_case_types:
                if case_type not in present:
                    blockers.append(f"missing required Golden case type: {case_type.value}")
        if target_state == CertificationState.SHADOW_QUALIFIED:
            if shadow_metrics is None:
                blockers.append("shadow qualification metrics missing")
            else:
                summary = shadow_metrics.review_summary
                if shadow_metrics.completed_reviews < self.shadow_policy.min_reviews:
                    blockers.append(
                        f"unique reviewed episode count {shadow_metrics.completed_reviews} < {self.shadow_policy.min_reviews}"
                    )
                if summary.useful_rate < self.shadow_policy.min_useful_rate:
                    blockers.append("engineer useful-rate gate failed")
                if summary.misleading_rate > self.shadow_policy.max_misleading_rate:
                    blockers.append("engineer misleading-rate gate failed")
                if shadow_metrics.unreviewed_hypotheses:
                    blockers.append("shadow review hypothesis coverage incomplete")

        confidence_counts = Counter(case.label_confidence.value for case in golden_cases)
        return PromotionEvidencePackage(
            family_id=family_id,
            release_id=release_id,
            capability_id=capability_id,
            generated_at=generated_at,
            from_state=from_state,
            target_state=target_state,
            decision=PromotionDecision.READY if not blockers else PromotionDecision.BLOCKED,
            gate_results=gate_results,
            blockers=tuple(blockers),
            limitations=onboarding_plan.limitations,
            golden_case_count=len(golden_cases),
            golden_case_confidence=dict(sorted(confidence_counts.items())),
            shadow_metrics=shadow_metrics,
            evidence_artifacts=evidence_artifacts,
        )


def capability_from_package(
    package: PromotionEvidencePackage,
    *,
    capability_id: str | None = None,
) -> CapabilityCertification:
    if package.decision != PromotionDecision.READY:
        raise ValueError("blocked promotion package cannot create a certified capability")
    return CapabilityCertification(
        capability_id=capability_id or package.capability_id,
        state=package.target_state,
        gate_results=package.gate_results,
        limitations=package.limitations,
        qualified_at=package.generated_at,
    )


def family_manifest_from_packages(
    packages: tuple[PromotionEvidencePackage, ...],
    *,
    approved_by: str | None = None,
    notes: tuple[str, ...] = (),
) -> FamilyQualificationManifest:
    if not packages:
        raise ValueError("at least one promotion package is required")
    family_ids = {item.family_id for item in packages}
    release_ids = {item.release_id for item in packages}
    target_states = {item.target_state for item in packages}
    if len(family_ids) != 1 or len(release_ids) != 1 or len(target_states) != 1:
        raise ValueError("promotion packages must share family, release, and target state")
    blocked = [item.capability_id for item in packages if item.decision != PromotionDecision.READY]
    if blocked:
        raise ValueError("blocked promotion packages cannot generate family manifest: " + ", ".join(sorted(blocked)))
    created_at = max(item.generated_at for item in packages)
    manifest = FamilyQualificationManifest(
        family_id=next(iter(family_ids)),
        release_id=next(iter(release_ids)),
        state=next(iter(target_states)),
        capabilities=tuple(capability_from_package(item) for item in packages),
        created_at=created_at,
        approved_by=approved_by,
        notes=notes,
    )
    CertificationService().validate_family_manifest(manifest)
    return manifest
