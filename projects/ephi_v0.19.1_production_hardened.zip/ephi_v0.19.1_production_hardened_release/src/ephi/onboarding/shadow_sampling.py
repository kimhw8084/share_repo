from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta

from ephi.adapters.base.state_store import StateStore
from ephi.advisory.models import MissedEventReport
from ephi.domain.evidence import Hypothesis
from ephi.domain.onboarding import (
    ReviewQueueState,
    ShadowQualificationMetrics,
    ShadowReviewCandidate,
    ShadowReviewQueueItem,
    ShadowSamplingReason,
)
from ephi.domain.operations import EngineerShadowReview, ShadowReviewDisposition
from ephi.operations.shadow_review import summarize_shadow_reviews
from ephi.onboarding.policy import ShadowSamplingPolicy

_STATE_KEY = "onboarding:shadow-review-queue:v1"


def _stable_jitter(episode_id: str) -> float:
    raw = hashlib.sha256(episode_id.encode("utf-8")).digest()
    return int.from_bytes(raw[:4], "big") / 2**32


def score_candidate(candidate: ShadowReviewCandidate, policy: ShadowSamplingPolicy | None = None) -> ShadowReviewCandidate:
    policy = policy or ShadowSamplingPolicy()
    reasons: list[ShadowSamplingReason] = list(candidate.reasons)
    score = float(policy.priority_weights.get(candidate.operational_priority, 0.0) + policy.severity_weights.get(candidate.technical_severity, 0.0))
    if candidate.operational_priority in {"P1", "P2"}:
        reasons.append(ShadowSamplingReason.HIGH_PRIORITY)
    if candidate.technical_severity in {"URGENT", "INVESTIGATE"}:
        reasons.append(ShadowSamplingReason.HIGH_SEVERITY)
    if candidate.confidence < policy.low_confidence_threshold:
        score += policy.low_confidence_bonus
        reasons.append(ShadowSamplingReason.LOW_CONFIDENCE)
    score += _stable_jitter(candidate.episode_id)
    return candidate.model_copy(update={"reasons": tuple(dict.fromkeys(reasons)), "sample_score": score})


def build_review_sample(
    candidates: tuple[ShadowReviewCandidate, ...],
    *,
    max_items: int,
    reviewed_episode_ids: frozenset[str] = frozenset(),
    policy: ShadowSamplingPolicy | None = None,
) -> tuple[ShadowReviewCandidate, ...]:
    policy = policy or ShadowSamplingPolicy()
    if max_items <= 0:
        return ()
    scored = [score_candidate(item, policy) for item in candidates if item.episode_id not in reviewed_episode_ids]
    if not scored:
        return ()

    selected: list[ShadowReviewCandidate] = []
    # First guarantee hypothesis coverage when the family policy requests it.
    if policy.guarantee_hypothesis_coverage:
        by_hypothesis: dict[Hypothesis, list[ShadowReviewCandidate]] = {}
        for item in scored:
            by_hypothesis.setdefault(item.leading_hypothesis, []).append(item)
        for hypothesis in sorted(by_hypothesis, key=lambda item: item.value):
            best = max(by_hypothesis[hypothesis], key=lambda item: (item.sample_score, item.episode_id))
            selected.append(best.model_copy(update={
                "reasons": tuple(dict.fromkeys((*best.reasons, ShadowSamplingReason.HYPOTHESIS_COVERAGE)))
            }))
            if len(selected) >= max_items:
                return tuple(selected)

    selected_ids = {item.episode_id for item in selected}
    remainder = sorted(
        (item for item in scored if item.episode_id not in selected_ids),
        key=lambda item: (-item.sample_score, item.episode_id),
    )
    for item in remainder:
        if len(selected) >= max_items:
            break
        selected.append(item)
    return tuple(selected)


class ShadowReviewQueue:
    def __init__(self, state_store: StateStore | None = None) -> None:
        self.state_store = state_store
        self._items: dict[str, ShadowReviewQueueItem] = {}
        self._state_version: int | None = None
        if state_store is not None:
            self.restore()

    def enqueue(self, candidates: tuple[ShadowReviewCandidate, ...], *, at: datetime) -> tuple[ShadowReviewQueueItem, ...]:
        created: list[ShadowReviewQueueItem] = []
        for candidate in candidates:
            if candidate.episode_id in self._items:
                continue
            item = ShadowReviewQueueItem(candidate=candidate, state=ReviewQueueState.PENDING, enqueued_at=at)
            self._items[candidate.episode_id] = item
            created.append(item)
        self.checkpoint()
        return tuple(created)

    def claim(self, reviewer: str, *, at: datetime, lease_seconds: int = 1800) -> ShadowReviewQueueItem | None:
        if lease_seconds <= 0:
            raise ValueError("review lease_seconds must be positive")
        eligible = [
            item for item in self._items.values()
            if item.state == ReviewQueueState.PENDING
            or (item.state == ReviewQueueState.CLAIMED and item.claimed_until is not None and item.claimed_until <= at)
        ]
        if not eligible:
            return None
        current = max(eligible, key=lambda item: (item.candidate.sample_score, item.candidate.episode_id))
        claimed = current.model_copy(update={
            "state": ReviewQueueState.CLAIMED,
            "claimed_by": reviewer,
            "claimed_at": at,
            "claimed_until": at + timedelta(seconds=lease_seconds),
        })
        self._items[current.candidate.episode_id] = claimed
        self.checkpoint()
        return claimed

    def complete(self, episode_id: str, review_id: str, *, reviewer: str) -> ShadowReviewQueueItem:
        current = self._items[episode_id]
        if current.state != ReviewQueueState.CLAIMED or current.claimed_by != reviewer:
            raise ValueError("review queue item must be claimed by the completing reviewer")
        completed = current.model_copy(update={"state": ReviewQueueState.COMPLETED, "completed_review_id": review_id})
        self._items[episode_id] = completed
        self.checkpoint()
        return completed

    def items(self) -> tuple[ShadowReviewQueueItem, ...]:
        return tuple(sorted(self._items.values(), key=lambda item: (-item.candidate.sample_score, item.candidate.episode_id)))

    def checkpoint(self) -> None:
        if self.state_store is None:
            return
        payload = json.dumps([item.model_dump(mode="json") for item in self.items()], sort_keys=True, separators=(",", ":")).encode("utf-8")
        record = self.state_store.compare_and_set(_STATE_KEY, expected_version=self._state_version, value=payload)
        self._state_version = record.version

    def restore(self) -> None:
        if self.state_store is None:
            return
        record = self.state_store.get(_STATE_KEY)
        if record is None:
            return
        items = [ShadowReviewQueueItem.model_validate(item) for item in json.loads(record.value.decode("utf-8"))]
        self._items = {item.candidate.episode_id: item for item in items}
        self._state_version = record.version


def build_shadow_metrics(
    *,
    candidates: tuple[ShadowReviewCandidate, ...],
    reviews: tuple[EngineerShadowReview, ...],
    missed_reports: tuple[MissedEventReport, ...],
    queue_items: tuple[ShadowReviewQueueItem, ...] = (),
    generated_at: datetime,
) -> ShadowQualificationMetrics:
    summary = summarize_shadow_reviews(reviews)
    completed = len({review.episode_id for review in reviews})
    sampled = len({candidate.episode_id for candidate in candidates})
    low_value = sum(review.disposition in {ShadowReviewDisposition.NOT_USEFUL, ShadowReviewDisposition.MISLEADING} for review in reviews)
    review_denominator = len(reviews) or 1
    sampled_hypotheses = tuple(sorted({item.leading_hypothesis for item in candidates}, key=lambda item: item.value))
    review_episode_ids = {review.episode_id for review in reviews}
    reviewed_hypotheses = tuple(sorted({item.leading_hypothesis for item in candidates if item.episode_id in review_episode_ids}, key=lambda item: item.value))
    unreviewed = tuple(item for item in sampled_hypotheses if item not in set(reviewed_hypotheses))
    backlog = sum(item.state in {ReviewQueueState.PENDING, ReviewQueueState.CLAIMED} for item in queue_items)
    return ShadowQualificationMetrics(
        generated_at=generated_at,
        review_summary=summary,
        sampled_candidates=sampled,
        completed_reviews=completed,
        review_completion_rate=(completed / sampled) if sampled else 0.0,
        not_useful_or_misleading=low_value,
        false_or_low_value_rate=low_value / review_denominator,
        missed_event_reports=len(missed_reports),
        missed_reports_per_100_reviews=100.0 * len(missed_reports) / review_denominator,
        hypotheses_sampled=sampled_hypotheses,
        hypotheses_reviewed=reviewed_hypotheses,
        unreviewed_hypotheses=unreviewed,
        backlog=backlog,
    )
