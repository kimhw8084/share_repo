from __future__ import annotations

import hashlib
from collections.abc import Callable
from datetime import datetime, timedelta, timezone

from ephi.advisory.models import MissedEventReport
from ephi.domain.benchmark import BenchmarkCase
from ephi.domain.onboarding import (
    GoldenCaseIntake,
    GoldenCurationState,
    PromotionDecision,
    ReviewQueueState,
    ShadowQualificationMetrics,
    ShadowReviewCandidate,
    ShadowReviewQueueItem,
)
from ephi.domain.operations import (
    CertificationState,
    EngineerShadowReview,
    FamilyQualificationManifest,
    GateResult,
)
from ephi.domain.qualification_control import (
    FamilyQualificationWorkspace,
    PromotionEvidenceRecord,
    QualificationAction,
    QualificationAuditEvent,
    QualificationCommandReceipt,
    QualificationGateRecord,
    QualificationWorkspaceSummary, QualificationWorkspaceExport,
)
from ephi.onboarding.control_repository import QualificationWorkspaceRepository
from ephi.onboarding.golden import intake_to_benchmark_case
from ephi.onboarding.policy import FamilyOnboardingPolicy
from ephi.onboarding.promotion import PromotionEvidenceBuilder, family_manifest_from_packages
from ephi.onboarding.shadow_sampling import build_review_sample, build_shadow_metrics


PolicyResolver = Callable[[str], FamilyOnboardingPolicy]
MissedEventProvider = Callable[[str], tuple[MissedEventReport, ...]]


def _now(value: datetime | None = None) -> datetime:
    return value or datetime.now(timezone.utc)


def _stable_id(prefix: str, *parts: str) -> str:
    digest = hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[:16]
    return f"{prefix}-{digest}"


class QualificationControlPlaneService:
    """Authoritative collaborative qualification workflow.

    Scientific gates are consumed as evidence; this service does not run detectors,
    quality models, RCA, or value logic. All mutations are committed atomically through
    the family workspace repository and carry authenticated actor/audit identity.
    """

    def __init__(
        self,
        repository: QualificationWorkspaceRepository,
        *,
        policy_resolver: PolicyResolver,
        missed_event_provider: MissedEventProvider | None = None,
    ) -> None:
        self.repository = repository
        self.policy_resolver = policy_resolver
        self.missed_event_provider = missed_event_provider or (lambda family_id: ())

    @staticmethod
    def _receipt(workspace: FamilyQualificationWorkspace, command_id: str):
        return next((item for item in workspace.command_receipts if item.command_id == command_id), None)

    @staticmethod
    def _append_audit(
        workspace: FamilyQualificationWorkspace,
        *,
        action: QualificationAction,
        actor: str,
        at: datetime,
        entity_type: str,
        entity_id: str,
        command_id: str,
        detail: str | None = None,
    ) -> dict:
        event_id = f"QAUD-{len(workspace.audit_events) + 1:06d}"
        event = QualificationAuditEvent(
            event_id=event_id,
            family_id=workspace.family_id,
            action=action,
            actor=actor,
            occurred_at=at,
            entity_type=entity_type,
            entity_id=entity_id,
            command_id=command_id,
            detail=detail,
        )
        receipt = QualificationCommandReceipt(
            command_id=command_id,
            action=action,
            actor=actor,
            occurred_at=at,
            result_id=entity_id,
        )
        return {
            "audit_events": (*workspace.audit_events, event),
            "command_receipts": (*workspace.command_receipts, receipt),
            "updated_at": at,
        }

    @staticmethod
    def _require_new_command(workspace: FamilyQualificationWorkspace, command_id: str) -> None:
        if not command_id.strip():
            raise ValueError("command_id cannot be blank")
        if QualificationControlPlaneService._receipt(workspace, command_id) is not None:
            raise ValueError(f"command already applied: {command_id}")

    def workspace(self, family_id: str) -> FamilyQualificationWorkspace:
        return self.repository.load(family_id)

    def summary(self, family_id: str) -> QualificationWorkspaceSummary:
        workspace = self.workspace(family_id)
        latest_golden = self.latest_golden_intakes(family_id)
        latest_manifest = self.current_manifest(family_id)
        pending = sum(item.state in {ReviewQueueState.PENDING, ReviewQueueState.CLAIMED} for item in workspace.shadow_queue)
        state = latest_manifest.state.value if latest_manifest else (
            workspace.onboarding_plan.current_state.value if workspace.onboarding_plan else CertificationState.RESEARCH.value
        )
        plan = workspace.onboarding_plan
        return QualificationWorkspaceSummary(
            family_id=family_id,
            release_id=plan.release_id if plan else (latest_manifest.release_id if latest_manifest else None),
            current_state=state,
            onboarding_ready=bool(plan and plan.ready_for_target),
            golden_intakes=len(latest_golden),
            accepted_golden_cases=sum(item.state == GoldenCurationState.ACCEPTED for item in latest_golden),
            shadow_candidates=len({item.episode_id for item in workspace.shadow_candidates}),
            pending_shadow_reviews=pending,
            completed_shadow_reviews=len({item.episode_id for item in workspace.shadow_reviews}),
            gate_records=len(workspace.gate_records),
            promotion_packages=len(workspace.promotion_records),
            qualification_manifests=len(workspace.family_manifests),
            blockers=plan.blockers if plan else ("onboarding plan not registered",),
            limitations=plan.limitations if plan else (),
        )

    def register_plan(self, plan, *, actor: str, command_id: str, at: datetime | None = None):
        at = _now(at)

        def mutate(workspace: FamilyQualificationWorkspace):
            self._require_new_command(workspace, command_id)
            if workspace.family_id != plan.family_id:
                raise ValueError("plan family does not match workspace")
            audit = self._append_audit(
                workspace, action=QualificationAction.PLAN_REGISTERED, actor=actor, at=at,
                entity_type="FamilyOnboardingPlan", entity_id=f"{plan.family_id}:{plan.release_id}",
                command_id=command_id,
            )
            return workspace.model_copy(update={"onboarding_plan": plan, **audit})

        return self.repository.mutate(plan.family_id, mutate).onboarding_plan

    def submit_golden(
        self,
        family_id: str,
        intake: GoldenCaseIntake,
        *,
        actor: str,
        command_id: str,
        at: datetime | None = None,
    ) -> GoldenCaseIntake:
        at = _now(at)
        normalized = intake.model_copy(update={
            "submitted_by": actor,
            "submitted_at": at,
            "state": GoldenCurationState.PENDING_REVIEW,
            "reviewed_by": None,
            "reviewed_at": None,
            "review_note": None,
            "revision": 1,
        })
        normalized = GoldenCaseIntake.model_validate(normalized.model_dump(mode="python"))

        def mutate(workspace: FamilyQualificationWorkspace):
            self._require_new_command(workspace, command_id)
            if any(item.intake_id == normalized.intake_id for item in workspace.golden_history):
                raise ValueError("Golden intake already exists")
            audit = self._append_audit(
                workspace, action=QualificationAction.GOLDEN_SUBMITTED, actor=actor, at=at,
                entity_type="GoldenCaseIntake", entity_id=normalized.intake_id, command_id=command_id,
            )
            return workspace.model_copy(update={
                "golden_history": (*workspace.golden_history, normalized), **audit,
            })

        self.repository.mutate(family_id, mutate)
        return normalized

    def latest_golden_intakes(self, family_id: str) -> tuple[GoldenCaseIntake, ...]:
        history = self.workspace(family_id).golden_history
        latest: dict[str, GoldenCaseIntake] = {}
        for item in history:
            previous = latest.get(item.intake_id)
            if previous is None or item.revision > previous.revision:
                latest[item.intake_id] = item
        return tuple(sorted(latest.values(), key=lambda item: item.intake_id))

    def golden_history(self, family_id: str, intake_id: str | None = None) -> tuple[GoldenCaseIntake, ...]:
        items = self.workspace(family_id).golden_history
        if intake_id is not None:
            items = tuple(item for item in items if item.intake_id == intake_id)
        return tuple(sorted(items, key=lambda item: (item.intake_id, item.revision)))

    def review_golden(
        self,
        family_id: str,
        intake_id: str,
        *,
        state: GoldenCurationState,
        actor: str,
        command_id: str,
        note: str | None = None,
        at: datetime | None = None,
    ) -> GoldenCaseIntake:
        at = _now(at)
        allowed = {GoldenCurationState.NEEDS_INFO, GoldenCurationState.ACCEPTED, GoldenCurationState.REJECTED}
        if state not in allowed:
            raise ValueError("review state must be NEEDS_INFO, ACCEPTED, or REJECTED")
        result: list[GoldenCaseIntake] = []

        def mutate(workspace: FamilyQualificationWorkspace):
            self._require_new_command(workspace, command_id)
            matches = [item for item in workspace.golden_history if item.intake_id == intake_id]
            if not matches:
                raise KeyError(intake_id)
            current = max(matches, key=lambda item: item.revision)
            if current.state in {GoldenCurationState.ACCEPTED, GoldenCurationState.REJECTED}:
                raise ValueError("terminal Golden intake cannot be reviewed again")
            updated = current.model_copy(update={
                "state": state,
                "reviewed_by": actor,
                "reviewed_at": at,
                "review_note": note,
                "revision": current.revision + 1,
            })
            updated = GoldenCaseIntake.model_validate(updated.model_dump(mode="python"))
            result.append(updated)
            audit = self._append_audit(
                workspace, action=QualificationAction.GOLDEN_REVIEWED, actor=actor, at=at,
                entity_type="GoldenCaseIntake", entity_id=intake_id, command_id=command_id,
                detail=state.value,
            )
            return workspace.model_copy(update={
                "golden_history": (*workspace.golden_history, updated), **audit,
            })

        self.repository.mutate(family_id, mutate)
        return result[-1]

    def accepted_golden_cases(self, family_id: str) -> tuple[BenchmarkCase, ...]:
        return tuple(
            intake_to_benchmark_case(item)
            for item in self.latest_golden_intakes(family_id)
            if item.state == GoldenCurationState.ACCEPTED
        )

    def enqueue_shadow_candidates(
        self,
        family_id: str,
        candidates: tuple[ShadowReviewCandidate, ...],
        *,
        max_items: int,
        actor: str,
        command_id: str,
        at: datetime | None = None,
    ) -> tuple[ShadowReviewQueueItem, ...]:
        at = _now(at)
        result: list[tuple[ShadowReviewQueueItem, ...]] = []

        def mutate(workspace: FamilyQualificationWorkspace):
            self._require_new_command(workspace, command_id)
            reviewed_ids = frozenset(item.episode_id for item in workspace.shadow_reviews)
            existing_ids = {item.candidate.episode_id for item in workspace.shadow_queue}
            selected = build_review_sample(
                candidates,
                max_items=max_items,
                reviewed_episode_ids=reviewed_ids | frozenset(existing_ids),
                policy=self.policy_resolver(family_id).shadow_sampling,
            )
            created = tuple(
                ShadowReviewQueueItem(candidate=item, state=ReviewQueueState.PENDING, enqueued_at=at)
                for item in selected
            )
            result.append(created)
            dedup_candidates = {item.episode_id: item for item in workspace.shadow_candidates}
            for item in candidates:
                dedup_candidates.setdefault(item.episode_id, item)
            audit = self._append_audit(
                workspace, action=QualificationAction.SHADOW_ENQUEUED, actor=actor, at=at,
                entity_type="ShadowReviewQueue", entity_id=f"batch:{command_id}", command_id=command_id,
                detail=f"created={len(created)}",
            )
            return workspace.model_copy(update={
                "shadow_candidates": tuple(sorted(dedup_candidates.values(), key=lambda item: item.episode_id)),
                "shadow_queue": (*workspace.shadow_queue, *created),
                **audit,
            })

        self.repository.mutate(family_id, mutate)
        return result[-1]

    def shadow_queue(self, family_id: str) -> tuple[ShadowReviewQueueItem, ...]:
        return tuple(sorted(
            self.workspace(family_id).shadow_queue,
            key=lambda item: (-item.candidate.sample_score, item.candidate.episode_id),
        ))

    def claim_shadow_review(
        self,
        family_id: str,
        *,
        actor: str,
        command_id: str,
        lease_seconds: int = 1800,
        at: datetime | None = None,
    ) -> ShadowReviewQueueItem | None:
        if lease_seconds <= 0:
            raise ValueError("lease_seconds must be positive")
        at = _now(at)
        result: list[ShadowReviewQueueItem | None] = []

        def mutate(workspace: FamilyQualificationWorkspace):
            self._require_new_command(workspace, command_id)
            eligible = [
                item for item in workspace.shadow_queue
                if item.state == ReviewQueueState.PENDING
                or (
                    item.state == ReviewQueueState.CLAIMED
                    and item.claimed_until is not None
                    and item.claimed_until <= at
                )
            ]
            if not eligible:
                result.append(None)
                audit = self._append_audit(
                    workspace, action=QualificationAction.SHADOW_CLAIMED, actor=actor, at=at,
                    entity_type="ShadowReviewQueue", entity_id="NONE", command_id=command_id,
                    detail="no eligible review",
                )
                return workspace.model_copy(update=audit)
            current = max(eligible, key=lambda item: (item.candidate.sample_score, item.candidate.episode_id))
            claimed = current.model_copy(update={
                "state": ReviewQueueState.CLAIMED,
                "claimed_by": actor,
                "claimed_at": at,
                "claimed_until": at + timedelta(seconds=lease_seconds),
            })
            queue = tuple(claimed if item.candidate.episode_id == current.candidate.episode_id else item for item in workspace.shadow_queue)
            result.append(claimed)
            audit = self._append_audit(
                workspace, action=QualificationAction.SHADOW_CLAIMED, actor=actor, at=at,
                entity_type="ShadowReviewQueueItem", entity_id=current.candidate.episode_id,
                command_id=command_id,
            )
            return workspace.model_copy(update={"shadow_queue": queue, **audit})

        self.repository.mutate(family_id, mutate)
        return result[-1]

    def complete_shadow_review(
        self,
        family_id: str,
        episode_id: str,
        review: EngineerShadowReview,
        *,
        actor: str,
        command_id: str,
        at: datetime | None = None,
    ) -> EngineerShadowReview:
        at = _now(at)
        result: list[EngineerShadowReview] = []

        def mutate(workspace: FamilyQualificationWorkspace):
            self._require_new_command(workspace, command_id)
            matches = [item for item in workspace.shadow_queue if item.candidate.episode_id == episode_id]
            if not matches:
                raise KeyError(episode_id)
            if any(item.episode_id == episode_id for item in workspace.shadow_reviews):
                raise ValueError("episode already has a completed qualification review")
            current = matches[-1]
            if current.state != ReviewQueueState.CLAIMED or current.claimed_by != actor:
                raise ValueError("shadow review must be claimed by the completing reviewer")
            if current.claimed_until is not None and current.claimed_until < at:
                raise ValueError("shadow review lease expired")
            normalized = review.model_copy(update={"episode_id": episode_id, "reviewer": actor, "reviewed_at": at})
            normalized = EngineerShadowReview.model_validate(normalized.model_dump(mode="python"))
            completed = current.model_copy(update={
                "state": ReviewQueueState.COMPLETED,
                "completed_review_id": normalized.review_id,
                "claimed_until": None,
            })
            queue = tuple(completed if item.candidate.episode_id == episode_id else item for item in workspace.shadow_queue)
            result.append(normalized)
            audit = self._append_audit(
                workspace, action=QualificationAction.SHADOW_REVIEWED, actor=actor, at=at,
                entity_type="EngineerShadowReview", entity_id=normalized.review_id, command_id=command_id,
                detail=normalized.disposition.value,
            )
            return workspace.model_copy(update={
                "shadow_queue": queue,
                "shadow_reviews": (*workspace.shadow_reviews, normalized),
                **audit,
            })

        self.repository.mutate(family_id, mutate)
        return result[-1]

    def shadow_metrics(self, family_id: str, *, at: datetime | None = None) -> ShadowQualificationMetrics:
        workspace = self.workspace(family_id)
        return build_shadow_metrics(
            candidates=workspace.shadow_candidates,
            reviews=workspace.shadow_reviews,
            missed_reports=self.missed_event_provider(family_id),
            queue_items=workspace.shadow_queue,
            generated_at=_now(at),
        )

    def record_gate(
        self,
        family_id: str,
        *,
        release_id: str,
        capability_id: str,
        result: GateResult,
        actor: str,
        command_id: str,
        at: datetime | None = None,
    ) -> QualificationGateRecord:
        at = _now(at)
        record = QualificationGateRecord(
            record_id=_stable_id("QGATE", family_id, release_id, capability_id, result.plane.value, command_id),
            family_id=family_id,
            release_id=release_id,
            capability_id=capability_id,
            result=result,
            recorded_by=actor,
            recorded_at=at,
        )

        def mutate(workspace: FamilyQualificationWorkspace):
            self._require_new_command(workspace, command_id)
            audit = self._append_audit(
                workspace, action=QualificationAction.GATE_RECORDED, actor=actor, at=at,
                entity_type="QualificationGateRecord", entity_id=record.record_id,
                command_id=command_id, detail=f"{result.plane.value}:{result.passed}",
            )
            return workspace.model_copy(update={"gate_records": (*workspace.gate_records, record), **audit})

        self.repository.mutate(family_id, mutate)
        return record

    def latest_gate_results(self, family_id: str, capability_id: str, release_id: str) -> tuple[GateResult, ...]:
        records = [
            item for item in self.workspace(family_id).gate_records
            if item.capability_id == capability_id and item.release_id == release_id
        ]
        latest = {}
        for item in records:
            previous = latest.get(item.result.plane)
            if previous is None or item.recorded_at > previous.recorded_at:
                latest[item.result.plane] = item
        return tuple(latest[key].result for key in sorted(latest, key=lambda item: item.value))

    def generate_promotion(
        self,
        family_id: str,
        *,
        capability_id: str,
        target_state: CertificationState,
        actor: str,
        command_id: str,
        evidence_artifacts: tuple[str, ...] = (),
        at: datetime | None = None,
    ) -> PromotionEvidenceRecord:
        at = _now(at)
        workspace = self.workspace(family_id)
        if workspace.onboarding_plan is None:
            raise ValueError("onboarding plan is required before promotion evidence")
        plan = workspace.onboarding_plan
        if plan.target_state != target_state:
            raise ValueError(
                f"onboarding plan targets {plan.target_state.value}, not requested {target_state.value}"
            )
        current = self.current_manifest(family_id)
        from_state = current.state if current else plan.current_state
        gates = self.latest_gate_results(family_id, capability_id, plan.release_id)
        policy = self.policy_resolver(family_id)
        builder = PromotionEvidenceBuilder(golden_policy=policy.golden)
        metrics = self.shadow_metrics(family_id, at=at) if target_state == CertificationState.SHADOW_QUALIFIED else None
        package = builder.build(
            family_id=family_id,
            release_id=plan.release_id,
            from_state=from_state,
            target_state=target_state,
            gate_results=gates,
            onboarding_plan=plan,
            golden_cases=self.accepted_golden_cases(family_id),
            shadow_metrics=metrics,
            evidence_artifacts=evidence_artifacts,
            generated_at=at,
            capability_id=capability_id,
        )
        record = PromotionEvidenceRecord(
            package_id=_stable_id("QPROM", family_id, plan.release_id, capability_id, target_state.value, command_id),
            package=package,
            generated_by=actor,
            generated_at=at,
        )

        def mutate(current_workspace: FamilyQualificationWorkspace):
            self._require_new_command(current_workspace, command_id)
            audit = self._append_audit(
                current_workspace, action=QualificationAction.PROMOTION_GENERATED, actor=actor, at=at,
                entity_type="PromotionEvidencePackage", entity_id=record.package_id,
                command_id=command_id, detail=package.decision.value,
            )
            return current_workspace.model_copy(update={
                "promotion_records": (*current_workspace.promotion_records, record), **audit,
            })

        self.repository.mutate(family_id, mutate)
        return record

    def promotion_records(self, family_id: str) -> tuple[PromotionEvidenceRecord, ...]:
        return self.workspace(family_id).promotion_records

    def approve_promotion(
        self,
        family_id: str,
        *,
        package_ids: tuple[str, ...],
        actor: str,
        command_id: str,
        notes: tuple[str, ...] = (),
        at: datetime | None = None,
    ) -> FamilyQualificationManifest:
        at = _now(at)
        result: list[FamilyQualificationManifest] = []

        def mutate(workspace: FamilyQualificationWorkspace):
            self._require_new_command(workspace, command_id)
            by_id = {item.package_id: item for item in workspace.promotion_records}
            missing = [item for item in package_ids if item not in by_id]
            if missing:
                raise KeyError(",".join(missing))
            records = tuple(by_id[item] for item in package_ids)
            if not records:
                raise ValueError("at least one promotion package is required")
            if any(item.package.decision != PromotionDecision.READY for item in records):
                raise ValueError("BLOCKED promotion package cannot be approved")
            current_manifest = max(workspace.family_manifests, key=lambda item: item.created_at) if workspace.family_manifests else None
            current_state = current_manifest.state if current_manifest is not None else (
                workspace.onboarding_plan.current_state if workspace.onboarding_plan is not None else CertificationState.RESEARCH
            )
            if any(item.package.from_state != current_state for item in records):
                raise ValueError("stale promotion package: family certification state changed after generation")
            if workspace.onboarding_plan is not None and any(
                item.package.release_id != workspace.onboarding_plan.release_id for item in records
            ):
                raise ValueError("stale promotion package: onboarding release changed after generation")
            manifest = family_manifest_from_packages(
                tuple(item.package for item in records), approved_by=actor, notes=notes
            )
            # Preserve approval time as the immutable registry event time while keeping
            # package evidence timestamps inside the capability records.
            manifest = manifest.model_copy(update={"created_at": at})
            result.append(manifest)
            audit = self._append_audit(
                workspace, action=QualificationAction.PROMOTION_APPROVED, actor=actor, at=at,
                entity_type="FamilyQualificationManifest", entity_id=f"{manifest.release_id}:{manifest.state.value}",
                command_id=command_id,
            )
            return workspace.model_copy(update={
                "family_manifests": (*workspace.family_manifests, manifest), **audit,
            })

        self.repository.mutate(family_id, mutate)
        return result[-1]

    def current_manifest(self, family_id: str) -> FamilyQualificationManifest | None:
        manifests = self.workspace(family_id).family_manifests
        return max(manifests, key=lambda item: item.created_at) if manifests else None

    def manifest_history(self, family_id: str) -> tuple[FamilyQualificationManifest, ...]:
        return tuple(sorted(self.workspace(family_id).family_manifests, key=lambda item: item.created_at))

    def export_workspace(self, family_id: str, *, at: datetime | None = None) -> QualificationWorkspaceExport:
        workspace = self.workspace(family_id)
        return QualificationWorkspaceExport(
            generated_at=_now(at),
            summary=self.summary(family_id),
            onboarding_plan=workspace.onboarding_plan,
            golden_history=workspace.golden_history,
            shadow_queue=workspace.shadow_queue,
            shadow_reviews=workspace.shadow_reviews,
            gate_records=workspace.gate_records,
            promotion_records=workspace.promotion_records,
            family_manifests=workspace.family_manifests,
            audit_events=workspace.audit_events,
        )

    def audit(self, family_id: str) -> tuple[QualificationAuditEvent, ...]:
        return self.workspace(family_id).audit_events
