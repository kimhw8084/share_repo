from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator

from ephi.domain.benchmark import BenchmarkCaseType, BenchmarkLabelConfidence
from ephi.domain.capabilities import Capability
from ephi.domain.operations import CertificationState


class GoldenCoveragePolicy(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    min_cases: int = Field(default=5, ge=1)
    min_high_confidence_cases: int = Field(default=3, ge=0)
    required_case_types: tuple[BenchmarkCaseType, ...] = ()
    require_internal_history: bool = True
    accepted_confidences: tuple[BenchmarkLabelConfidence, ...] = (
        BenchmarkLabelConfidence.CONFIRMED,
        BenchmarkLabelConfidence.HIGH_CONFIDENCE,
        BenchmarkLabelConfidence.MODERATE_CONFIDENCE,
    )




class ShadowSamplingPolicy(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    priority_weights: dict[str, float] = Field(default_factory=lambda: {"P1": 12.0, "P2": 9.0, "P3": 6.0, "P4": 3.0})
    severity_weights: dict[str, float] = Field(default_factory=lambda: {
        "URGENT": 10.0, "INVESTIGATE": 8.0, "MONITOR": 6.0, "OBSERVE": 4.0, "NORMAL": 2.0, "UNKNOWN": 0.0
    })
    low_confidence_threshold: float = Field(default=0.55, ge=0.0, le=1.0)
    low_confidence_bonus: float = Field(default=2.5, ge=0.0)
    guarantee_hypothesis_coverage: bool = True
    review_lease_seconds: int = Field(default=1800, gt=0)

class FamilyOnboardingPolicy(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    policy_version: str = "1"
    family_id: str
    target_state: CertificationState = CertificationState.OFFLINE_QUALIFIED
    required_capabilities: tuple[Capability, ...]
    optional_capabilities: tuple[Capability, ...] = ()
    golden: GoldenCoveragePolicy = Field(default_factory=GoldenCoveragePolicy)
    shadow_sampling: ShadowSamplingPolicy = Field(default_factory=ShadowSamplingPolicy)


def load_onboarding_policy(path: str | Path) -> FamilyOnboardingPolicy:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    return FamilyOnboardingPolicy.model_validate(payload)
