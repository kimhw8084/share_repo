from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory

from pydantic import BaseModel, ConfigDict

from ephi.adapters.local.sqlite_state_store import SqliteStateStore
from ephi.advisory.models import MissedEventReport
from ephi.domain.benchmark import BenchmarkCaseType, BenchmarkFamily, BenchmarkLabelConfidence
from ephi.domain.capabilities import Capability
from ephi.domain.data_reality import CapabilityAssessment, DataRealityReport, QualificationState
from ephi.domain.evidence import Hypothesis
from ephi.domain.onboarding import (
    GoldenCaseIntake,
    GoldenCurationState,
    PromotionDecision,
    ShadowReviewCandidate,
)
from ephi.domain.operations import (
    CertificationState,
    EngineerShadowReview,
    GateResult,
    QualificationPlane,
    ShadowReviewDisposition,
)
from ephi.onboarding.golden import GoldenCaseRegistry
from ephi.onboarding.planner import build_family_onboarding_plan
from ephi.onboarding.promotion import PromotionEvidenceBuilder, family_manifest_from_packages
from ephi.onboarding.policy import GoldenCoveragePolicy
from ephi.onboarding.shadow_sampling import ShadowReviewQueue, build_review_sample, build_shadow_metrics
from ephi.operations.certification import CertificationService


class FamilyOnboardingQualificationReport(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    passed: bool
    required_capability_blocked: bool
    optional_capability_limited: bool
    qualified_plan_unblocked: bool
    self_approval_blocked: bool
    accepted_case_converts: bool
    registry_restart_persisted: bool
    stratified_sampling: bool
    review_queue_idempotent: bool
    review_queue_restart_persisted: bool
    metrics_surface_missed_and_low_value: bool
    offline_package_ready: bool
    shadow_qualified_requires_engineer_gate: bool
    shadow_package_blocks_unreviewed_hypothesis: bool
    review_lease_recovery: bool
    golden_coverage_policy_blocks_missing_strata: bool
    ready_package_generates_family_manifest: bool


def _report(*, metro: QualificationState, ref: QualificationState, spatial: QualificationState) -> DataRealityReport:
    now = datetime(2026, 8, 19, 12, 0, tzinfo=timezone.utc)
    capabilities = tuple(
        CapabilityAssessment(capability=cap, state=state, reasons=(() if state == QualificationState.QUALIFIED else ("qualification evidence incomplete",)))
        for cap, state in (
            (Capability.METROLOGY, metro),
            (Capability.REFERENCE_WAFER, ref),
            (Capability.SPATIAL_METROLOGY, spatial),
        )
    )
    return DataRealityReport(datasets=(), joins=(), capabilities=capabilities, generated_at=now.isoformat())


def run_family_onboarding_qualification() -> FamilyOnboardingQualificationReport:
    now = datetime(2026, 8, 19, 12, 0, tzinfo=timezone.utc)
    blocked_plan = build_family_onboarding_plan(
        family_id="METROLOGY",
        release_id="R13",
        report=_report(metro=QualificationState.QUALIFIED, ref=QualificationState.PARTIAL, spatial=QualificationState.UNAVAILABLE),
        required_capabilities=(Capability.METROLOGY, Capability.REFERENCE_WAFER),
        optional_capabilities=(Capability.SPATIAL_METROLOGY,),
        target_state=CertificationState.OFFLINE_QUALIFIED,
        generated_at=now,
    )
    required_capability_blocked = any("REFERENCE_WAFER" in item for item in blocked_plan.blockers)
    optional_capability_limited = any("SPATIAL_METROLOGY" in item for item in blocked_plan.limitations)
    qualified_plan = build_family_onboarding_plan(
        family_id="METROLOGY",
        release_id="R13",
        report=_report(metro=QualificationState.QUALIFIED, ref=QualificationState.QUALIFIED, spatial=QualificationState.PARTIAL),
        required_capabilities=(Capability.METROLOGY, Capability.REFERENCE_WAFER),
        optional_capabilities=(Capability.SPATIAL_METROLOGY,),
        target_state=CertificationState.OFFLINE_QUALIFIED,
        generated_at=now,
    )
    qualified_plan_unblocked = qualified_plan.ready_for_target and bool(qualified_plan.limitations)

    base_intake = GoldenCaseIntake(
        intake_id="INT-MET-001",
        family=BenchmarkFamily.METROLOGY,
        case_type=BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT,
        source_locator="materialization://golden/metrology/001",
        submitted_by="engineer-a",
        submitted_at=now,
        scope_start=now - timedelta(days=2),
        scope_end=now - timedelta(days=1),
        label_confidence=BenchmarkLabelConfidence.HIGH_CONFIDENCE,
        expected_hypothesis=Hypothesis.METROLOGY_SYSTEM_SHIFT,
        expected_local_actionable=True,
        expected_asset_ids=("METRO/HEAD_A",),
        onset_event_time=now - timedelta(days=1, hours=12),
        evidence_refs=("case-review://CR-001",),
        tags=("measurement-head",),
        state=GoldenCurationState.PENDING_REVIEW,
    )
    with TemporaryDirectory() as temp:
        store = SqliteStateStore(Path(temp) / "onboarding.sqlite3")
        registry = GoldenCaseRegistry(store)
        registry.submit(base_intake)
        try:
            registry.revise(base_intake.intake_id, state=GoldenCurationState.ACCEPTED, reviewer="engineer-a", reviewed_at=now)
            self_approval_blocked = False
        except ValueError:
            self_approval_blocked = True
        accepted = registry.revise(base_intake.intake_id, state=GoldenCurationState.ACCEPTED, reviewer="engineer-b", reviewed_at=now)
        accepted_case_converts = registry.accepted_cases()[0].source_locator == accepted.source_locator
        registry_restart_persisted = GoldenCaseRegistry(store).latest(base_intake.intake_id) == accepted

        candidates = tuple(
            ShadowReviewCandidate(
                episode_id=f"EP-{idx}", family_id="METROLOGY", asset_id=f"HEAD-{idx%3}",
                technical_severity="INVESTIGATE" if idx < 3 else "MONITOR",
                operational_priority="P1" if idx == 0 else "P3",
                leading_hypothesis=hypothesis,
                confidence=0.45 if idx == 4 else 0.85,
                opened_at=now + timedelta(minutes=idx),
            )
            for idx, hypothesis in enumerate((
                Hypothesis.METROLOGY_SYSTEM_SHIFT,
                Hypothesis.COMMON_MODE_PROCESS_CHANGE,
                Hypothesis.LOCAL_ASSET_DEGRADATION,
                Hypothesis.METROLOGY_SYSTEM_SHIFT,
                Hypothesis.DATA_PIPELINE_OR_SCHEMA_CHANGE,
                Hypothesis.COMMON_MODE_PROCESS_CHANGE,
            ))
        )
        sample = build_review_sample(candidates, max_items=5)
        stratified_sampling = len({item.leading_hypothesis for item in sample}) == 4 and sample[0].episode_id in {"EP-0", "EP-1", "EP-2", "EP-4"}
        queue = ShadowReviewQueue(store)
        first_enqueue = queue.enqueue(sample, at=now)
        second_enqueue = queue.enqueue(sample, at=now)
        review_queue_idempotent = len(first_enqueue) == len(sample) and second_enqueue == ()
        claimed = queue.claim("reviewer-1", at=now)
        assert claimed is not None
        queue.complete(claimed.candidate.episode_id, "REV-1", reviewer="reviewer-1")
        review_queue_restart_persisted = len(ShadowReviewQueue(store).items()) == len(sample)
        lease_store = SqliteStateStore(Path(temp) / "lease.sqlite3")
        lease_queue = ShadowReviewQueue(lease_store)
        lease_queue.enqueue((sample[0],), at=now)
        remaining = lease_queue.claim("reviewer-a", at=now, lease_seconds=10)
        early = ShadowReviewQueue(lease_store).claim("reviewer-b", at=now + timedelta(seconds=5), lease_seconds=10)
        recovered = ShadowReviewQueue(lease_store).claim("reviewer-b", at=now + timedelta(seconds=11), lease_seconds=10)
        review_lease_recovery = (
            remaining is not None and early is None and recovered is not None
            and recovered.candidate.episode_id == remaining.candidate.episode_id
            and recovered.claimed_by == "reviewer-b"
        )

    reviews = tuple(
        EngineerShadowReview(
            review_id=f"REV-{idx}", episode_id=item.episode_id, reviewer="qualified-engineer",
            disposition=(ShadowReviewDisposition.NOT_USEFUL if idx == 1 else ShadowReviewDisposition.WANT_EVENT),
            comparison_valid=True, hypothesis_reasonable=True, verification_useful=True, reviewed_at=now,
        )
        for idx, item in enumerate(sample)
    )
    missed = (
        MissedEventReport(
            report_id="MISS-1", asset_id="HEAD-X", start_time=now, reporter="engineer-z",
            description="known drift absent from attention queue", created_at=now,
        ),
    )
    metrics = build_shadow_metrics(candidates=sample, reviews=reviews, missed_reports=missed, generated_at=now)
    metrics_surface_missed_and_low_value = metrics.missed_event_reports == 1 and metrics.not_useful_or_misleading == 1

    golden_cases = (registry.accepted_cases()[0],) if 'registry' in locals() else ()
    gates = (
        GateResult(plane=QualificationPlane.DATA_REALITY, passed=True, artifact="data.json"),
        GateResult(plane=QualificationPlane.BEHAVIORAL_METROLOGY, passed=True, artifact="golden.json"),
        GateResult(plane=QualificationPlane.RUNTIME_SCALE, passed=True, artifact="runtime.json"),
        GateResult(plane=QualificationPlane.RELIABILITY_DR, passed=True, artifact="reliability.json"),
    )
    builder = PromotionEvidenceBuilder()
    offline = builder.build(
        family_id="METROLOGY", release_id="R13", from_state=CertificationState.RESEARCH,
        target_state=CertificationState.OFFLINE_QUALIFIED, gate_results=gates,
        onboarding_plan=qualified_plan, golden_cases=golden_cases, generated_at=now,
    )
    offline_package_ready = offline.decision == PromotionDecision.READY
    strict_builder = PromotionEvidenceBuilder(golden_policy=GoldenCoveragePolicy(
        min_cases=2, min_high_confidence_cases=1,
        required_case_types=(BenchmarkCaseType.HEALTHY, BenchmarkCaseType.METROLOGY_SYSTEM_SHIFT),
    ))
    strict_package = strict_builder.build(
        family_id="METROLOGY", release_id="R13", from_state=CertificationState.RESEARCH,
        target_state=CertificationState.OFFLINE_QUALIFIED, gate_results=gates,
        onboarding_plan=qualified_plan, golden_cases=golden_cases, generated_at=now,
    )
    golden_coverage_policy_blocks_missing_strata = strict_package.decision == PromotionDecision.BLOCKED
    ready_package_generates_family_manifest = (
        family_manifest_from_packages((offline,), approved_by="qualification").state
        == CertificationState.OFFLINE_QUALIFIED
    )

    certification = CertificationService()
    from ephi.domain.operations import CapabilityCertification
    shadow = CapabilityCertification(capability_id="behavioral-health", state=CertificationState.SHADOW, gate_results=gates)
    try:
        certification.transition(shadow, CertificationState.SHADOW_QUALIFIED, qualified_at=now)
        shadow_qualified_requires_engineer_gate = False
    except ValueError:
        shadow_qualified_requires_engineer_gate = True

    shadow_gates = gates + (GateResult(plane=QualificationPlane.ENGINEER_SHADOW, passed=True, artifact="shadow.json"),)
    # Metrics intentionally have reviewed all sampled hypotheses here; create a coverage gap for the package failure test.
    partial_reviews = reviews[:-1]
    partial_metrics = build_shadow_metrics(candidates=sample, reviews=partial_reviews, missed_reports=missed, generated_at=now)
    shadow_package = builder.build(
        family_id="METROLOGY", release_id="R13", from_state=CertificationState.SHADOW,
        target_state=CertificationState.SHADOW_QUALIFIED, gate_results=shadow_gates,
        onboarding_plan=qualified_plan, golden_cases=golden_cases, shadow_metrics=partial_metrics,
        generated_at=now,
    )
    shadow_package_blocks_unreviewed_hypothesis = shadow_package.decision == PromotionDecision.BLOCKED

    checks = locals()
    names = [
        "required_capability_blocked", "optional_capability_limited", "qualified_plan_unblocked",
        "self_approval_blocked", "accepted_case_converts", "registry_restart_persisted",
        "stratified_sampling", "review_queue_idempotent", "review_queue_restart_persisted",
        "metrics_surface_missed_and_low_value", "offline_package_ready",
        "shadow_qualified_requires_engineer_gate", "shadow_package_blocks_unreviewed_hypothesis",
        "review_lease_recovery", "golden_coverage_policy_blocks_missing_strata",
        "ready_package_generates_family_manifest",
    ]
    values = {name: bool(checks[name]) for name in names}
    return FamilyOnboardingQualificationReport(passed=all(values.values()), **values)
