from __future__ import annotations

import json
from datetime import datetime

from ephi.adapters.base.state_store import StateStore
from ephi.domain.benchmark import BenchmarkCase, BenchmarkSourceKind
from ephi.domain.onboarding import GoldenCaseIntake, GoldenCurationState

_STATE_KEY = "onboarding:golden-case-registry:v1"


class GoldenCaseRegistry:
    """Durable curation registry. Accepted history is immutable by revision."""

    def __init__(self, state_store: StateStore | None = None) -> None:
        self.state_store = state_store
        self._history: list[GoldenCaseIntake] = []
        self._state_version: int | None = None
        if state_store is not None:
            self.restore()

    def submit(self, intake: GoldenCaseIntake) -> GoldenCaseIntake:
        if any(item.intake_id == intake.intake_id for item in self._history):
            raise ValueError("Golden intake already exists; use revise")
        self._history.append(intake)
        self.checkpoint()
        return intake

    def revise(
        self,
        intake_id: str,
        *,
        state: GoldenCurationState,
        reviewer: str,
        reviewed_at: datetime,
        note: str | None = None,
    ) -> GoldenCaseIntake:
        current = self.latest(intake_id)
        if current is None:
            raise KeyError(intake_id)
        if current.state in {GoldenCurationState.ACCEPTED, GoldenCurationState.REJECTED}:
            raise ValueError("terminal Golden intake requires a new intake ID for material relabeling")
        updated = current.model_copy(update={
            "state": state,
            "reviewed_by": reviewer,
            "reviewed_at": reviewed_at,
            "review_note": note,
            "revision": current.revision + 1,
        })
        # Re-validate model-level acceptance safeguards after model_copy.
        updated = GoldenCaseIntake.model_validate(updated.model_dump(mode="python"))
        self._history.append(updated)
        self.checkpoint()
        return updated

    def latest(self, intake_id: str) -> GoldenCaseIntake | None:
        matches = [item for item in self._history if item.intake_id == intake_id]
        return max(matches, key=lambda item: item.revision) if matches else None

    def history(self, intake_id: str | None = None) -> tuple[GoldenCaseIntake, ...]:
        items = self._history if intake_id is None else [item for item in self._history if item.intake_id == intake_id]
        return tuple(sorted(items, key=lambda item: (item.intake_id, item.revision)))

    def accepted_cases(self) -> tuple[BenchmarkCase, ...]:
        latest_ids = sorted({item.intake_id for item in self._history})
        cases = []
        for intake_id in latest_ids:
            item = self.latest(intake_id)
            if item is not None and item.state == GoldenCurationState.ACCEPTED:
                cases.append(intake_to_benchmark_case(item))
        return tuple(cases)

    def checkpoint(self) -> None:
        if self.state_store is None:
            return
        payload = json.dumps(
            [item.model_dump(mode="json") for item in self.history()],
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        record = self.state_store.compare_and_set(_STATE_KEY, expected_version=self._state_version, value=payload)
        self._state_version = record.version

    def restore(self) -> None:
        if self.state_store is None:
            return
        record = self.state_store.get(_STATE_KEY)
        if record is None:
            return
        self._history = [GoldenCaseIntake.model_validate(item) for item in json.loads(record.value.decode("utf-8"))]
        self._state_version = record.version


def intake_to_benchmark_case(intake: GoldenCaseIntake) -> BenchmarkCase:
    if intake.state != GoldenCurationState.ACCEPTED:
        raise ValueError("only ACCEPTED Golden intake can become a BenchmarkCase")
    return BenchmarkCase(
        case_id=intake.intake_id,
        family=intake.family,
        case_type=intake.case_type,
        source_kind=BenchmarkSourceKind.INTERNAL_HISTORY,
        source_locator=intake.source_locator,
        label_confidence=intake.label_confidence,
        expected_hypothesis=intake.expected_hypothesis,
        expected_local_actionable=intake.expected_local_actionable,
        expected_fleet_actionable=intake.expected_fleet_actionable,
        expected_asset_ids=intake.expected_asset_ids,
        onset_event_time=intake.onset_event_time,
        onset_low=intake.onset_low,
        onset_high=intake.onset_high,
        external_detection_time=intake.external_detection_time,
        scope_start=intake.scope_start,
        scope_end=intake.scope_end,
        asset_count=intake.asset_count,
        quality_impact=intake.quality_impact,
        root_cause_label=intake.root_cause_label,
        resolution_label=intake.resolution_label,
        actions=intake.actions,
        tags=tuple(dict.fromkeys((*intake.tags, "internal-history", "curated"))),
        notes=intake.notes,
    )
