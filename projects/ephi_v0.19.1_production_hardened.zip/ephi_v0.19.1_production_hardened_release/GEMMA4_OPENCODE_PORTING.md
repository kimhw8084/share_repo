# Gemma 4 + OpenCode Porting Guidance

EPHI's instruction design is intentionally concise and deterministic for a local coding agent: classify the change first, inspect rather than guess, use one legal customization zone, run a validator after each binding, and escalate ambiguity instead of fabricating proprietary semantics.

Gemma 4 supports system instructions, native structured tool use/function calling and thinking mode. For the work environment, prefer the organization's supported OpenCode/Gemma provider configuration rather than pinning a model ID here. Enable deeper reasoning for ambiguous schema/identity/time semantics; routine edits can use lower reasoning to reduce latency.

OpenCode project behavior is committed through `AGENTS.md`, `opencode.json` and `.opencode/agents/`. The `port` agent should be the default for the internal mapping phase; the `review` agent is read-only; `core` is exceptional.

## First internal prompt

> Inspect the EPHI semantic data requirements and the company Big Data schemas. I will give you plausible source table names. For each one, inspect bounded metadata, representative values, cardinality, time behavior and required joins; determine whether it satisfies the logical EPHI dataset; generate the most efficient valid SQL binding under `company_bindings/`; preserve partition pushdown and knowledge-time semantics; do not modify generic EPHI core; run AutoPort validation after each binding and report only genuine unresolved semantic decisions to me.
