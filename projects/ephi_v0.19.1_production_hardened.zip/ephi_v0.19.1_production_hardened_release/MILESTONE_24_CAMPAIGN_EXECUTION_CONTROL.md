# Milestone 24 — Internal Evidence Adapter Validation & Campaign Execution Control

EPHI v0.17.0 adds a durable execution layer around the v0.16 metrology launch evidence model.

## Implemented
- `LaunchEvidenceAdapterDescriptor` and complete/idempotent-stage validation.
- Company `resolve_source_snapshot(snapshot_id)` contract.
- `SourceSnapshotLineage` with parent/revision/as-of semantics.
- `LaunchArtifactReference` embedded in evidence receipts.
- `publish_receipt_artifact()` through the generic `ArtifactStore`.
- `CampaignExecutionRecord` and immutable attempt history.
- Persistent `RUNNING/PASSED/FAILED` stage attempts.
- Bounded retry budget and resume without re-running completed stages.
- Immutable evidence and replay-manifest attachment.
- Source-lineage persistence before stage completion.
- Dossier construction directly from durable campaign state.
- Idempotent handoff into `QualificationControlPlaneService`.
- Separate admin approval boundary.
- `adapter-validate`, `campaign-run`, `campaign-status`, `handoff`, `dry-run`, and `execution-qualification` CLI surfaces.
- Exact operator sequence under `scripts/metrology_campaign_command_sequence.sh`.

## Deliberately not implemented
- Automatic production promotion.
- Automatic retry forever.
- HTTP disaster-recovery or promotion bypass routes.
- Company-specific data/query implementations in core EPHI.
- Treating portable dry-run evidence as internal qualification.
