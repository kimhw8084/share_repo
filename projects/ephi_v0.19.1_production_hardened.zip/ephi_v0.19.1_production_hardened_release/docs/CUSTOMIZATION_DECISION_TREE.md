# Customization decision tree

```text
Different physical table/column? -> company_bindings/ or configs/company/
Different internal query/auth/state/artifact API? -> company_port/src/ephi_company/
Different equipment family? -> generated configs/families/; plugin only if physics truly differs
New physical feature unsupported by generic protocols? -> extensions/
Different threshold/policy? -> versioned config + qualification evidence
None of the above can solve it? -> CORE_CHANGE review
```

A company port that edits generic core merely because the source schema is different fails the portability objective.
