# WIP semantic requirement

**Tier:** C

## Purpose
- current/future exposure and preventability

**If unavailable:** WIP priority/preventability unavailable

## Fields

| Canonical field | Criticality | Meaning | Common aliases |
|---|---|---|---|
| `material_id` | REQUIRED | globally stable wafer/material identity | wafer_id, material_id, substrate_id, wafer_key |
| `available_at` | REQUIRED | time record became knowable to EPHI | available_at, load_dttm, ingest_time, create_dttm, update_time |
| `operation` | HIGH_VALUE | current/next operation | operation, oper_id, current_oper |
| `queued_asset_id` | HIGH_VALUE | committed/queued equipment | queued_asset_id, eqp_id, assigned_tool |
| `eligible_asset_ids` | HIGH_VALUE | qualified alternatives | eligible_asset_ids, candidate_tools, qualified_eqps |

## Agent validation guidance

### `material_id`
- Validate: joins across process and measurement history
- Validate: high cardinality
- Warning: wafer number 1-25 usually requires lot + wafer composite

### `available_at`
- Validate: normally >= event_time
- Validate: required for strict historical replay

## Binding rule

Map the physical source to these canonical fields through `company_bindings/`; do not edit `src/ephi/` to accommodate source naming differences.
