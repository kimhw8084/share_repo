# ASSETS semantic requirement

**Tier:** A

## Purpose
- resolve equipment identity and hierarchy

**If unavailable:** EPHI can infer assets from executions provisionally

## Fields

| Canonical field | Criticality | Meaning | Common aliases |
|---|---|---|---|
| `asset_id` | REQUIRED | stable equipment identity | eqp_id, equipment_id, tool_id, machine_id, mch_id |
| `family_id` | HIGH_VALUE | equipment family | family_id, eqp_type, model, family |
| `asset_type` | OPTIONAL | asset semantic type | asset_type, eqp_type, type |
| `parent_asset_id` | OPTIONAL | parent in asset hierarchy | parent_id, parent_asset_id, eqp_id |

## Agent validation guidance

### `asset_id`
- Validate: moderate cardinality
- Validate: stable across time

## Binding rule

Map the physical source to these canonical fields through `company_bindings/`; do not edit `src/ephi/` to accommodate source naming differences.
