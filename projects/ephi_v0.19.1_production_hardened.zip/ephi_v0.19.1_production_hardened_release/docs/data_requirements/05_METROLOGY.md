# METROLOGY semantic requirement

**Tier:** A

## Purpose
- metrology health
- process-vs-measurement-system discrimination
- spatial signatures

**If unavailable:** metrology flagship unavailable

## Fields

| Canonical field | Criticality | Meaning | Common aliases |
|---|---|---|---|
| `measurement_id` | REQUIRED | unique measurement-row identity | measurement_id, meas_id, result_id, hist_id |
| `material_id` | REQUIRED | globally stable wafer/material identity | wafer_id, material_id, substrate_id, wafer_key |
| `subject_id` | REQUIRED | measurement equipment/head producing result | subject_id, eqp_id, tool_id, head_id, module_id |
| `characteristic_id` | REQUIRED | measured characteristic | characteristic_id, item_id, item_cd, parameter, measure_item |
| `value` | REQUIRED | numeric measurement value | value, meas_val, result_value, measurement |
| `event_time` | REQUIRED | physical event or measurement time | event_time, start_time, end_time, finish_ts, finish_time, end_ts, meas_time, measure_time, proc_time |
| `available_at` | REQUIRED | time record became knowable to EPHI | available_at, load_dttm, ingest_time, create_dttm, update_time |
| `x` | HIGH_VALUE | wafer X coordinate | x, x_pos, x_coord |
| `y` | HIGH_VALUE | wafer Y coordinate | y, y_pos, y_coord |
| `site_id` | HIGH_VALUE | measurement site identity | site_id, site, point_id |
| `is_reference_material` | HIGH_VALUE | reference/control wafer flag | is_reference_material, ref_yn, reference_flag, wafer_type |
| `remeasure_group_id` | HIGH_VALUE | links repeated measurements of same target | remeasure_group_id, remeas_id, repeat_group |
| `attempt_index` | OPTIONAL | remeasure attempt order | attempt_index, attempt_no, remeas_seq |
| `recipe_id` | HIGH_VALUE | measurement recipe/method | recipe_id, rcp_id, method_id |

## Agent validation guidance

### `material_id`
- Validate: joins across process and measurement history
- Validate: high cardinality
- Warning: wafer number 1-25 usually requires lot + wafer composite

### `event_time`
- Validate: must not be inferred from warehouse load time when physical time exists

### `available_at`
- Validate: normally >= event_time
- Validate: required for strict historical replay

## Binding rule

Map the physical source to these canonical fields through `company_bindings/`; do not edit `src/ephi/` to accommodate source naming differences.
