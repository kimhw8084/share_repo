# ASSET_QUALIFICATION semantic requirement

**Tier:** C

## Purpose
- validate alternative-resource eligibility

**If unavailable:** preventable-routing recommendations unavailable

## Fields

| Canonical field | Criticality | Meaning | Common aliases |
|---|---|---|---|
| `asset_id` | REQUIRED | stable equipment identity | eqp_id, equipment_id, tool_id, machine_id, mch_id |
| `operation` | REQUIRED | operation qualification | operation, oper_id |
| `available_at` | REQUIRED | time record became knowable to EPHI | available_at, load_dttm, ingest_time, create_dttm, update_time |
| `qualified` | HIGH_VALUE | whether asset is qualified | qualified, qual_yn, status |

## Agent validation guidance

### `asset_id`
- Validate: moderate cardinality
- Validate: stable across time

### `available_at`
- Validate: normally >= event_time
- Validate: required for strict historical replay

## Binding rule

Map the physical source to these canonical fields through `company_bindings/`; do not edit `src/ephi/` to accommodate source naming differences.
