# TRACES semantic requirement

**Tier:** D

## Purpose
- selective raw-trace escalation

**If unavailable:** raw trace analysis unavailable; scalar path continues

## Fields

| Canonical field | Criticality | Meaning | Common aliases |
|---|---|---|---|
| `execution_id` | REQUIRED | execution foreign key | execution_id, hist_id, run_id |
| `signal_id` | REQUIRED | trace signal identity | signal_id, param_id, tag_name |
| `available_at` | REQUIRED | time record became knowable to EPHI | available_at, load_dttm, ingest_time, create_dttm, update_time |
| `sample_time` | HIGH_VALUE | trace sample time | sample_time, timestamp, trace_time |
| `sample_index` | HIGH_VALUE | trace sample order | sample_index, sample_no, idx |
| `value` | HIGH_VALUE | trace value | value, sample_value |

## Agent validation guidance

### `available_at`
- Validate: normally >= event_time
- Validate: required for strict historical replay

## Binding rule

Map the physical source to these canonical fields through `company_bindings/`; do not edit `src/ephi/` to accommodate source naming differences.
