# EPHI Data Requirements — Start Here

The company port is a **semantic binding task**, not a scientific-core customization task.

When given a plausible table name, determine whether its actual schema, values, temporal behavior and joins satisfy one of EPHI's logical datasets. A familiar table name is weak evidence; value/cardinality/time/join behavior is strong evidence.

## Tiers
- **Tier A — minimum viable flagship:** executions, signals/FDC, metrology; assets may initially be inferred from execution history.
- **Tier B — strongly recommended:** maintenance, quality and reference/remeasure semantics embedded in metrology.
- **Tier C — operational intelligence:** genealogy, WIP, asset qualification, historical cases.
- **Tier D — optional/high-cost:** raw traces.

Missing optional datasets must degrade capabilities explicitly rather than block unrelated health analysis.

## Bounded investigation sequence
1. Table metadata and partitions.
2. Column names/types.
3. Small recent sample.
4. Approximate/bounded cardinality and null statistics.
5. Identity tests.
6. `event_time` vs `available_at` tests.
7. Applicable join-coverage tests.
8. Query-plan/pushdown review.
9. Generate canonical SQL binding.
10. Run AutoPort validation.

Use `configs/autopilot/data_requirements.yaml` as the machine-readable source of truth.
