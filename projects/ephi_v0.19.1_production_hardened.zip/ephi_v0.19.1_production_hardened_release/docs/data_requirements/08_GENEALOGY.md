# GENEALOGY semantic requirement

**Tier:** C

## Purpose
- trace upstream/downstream material commonality

**If unavailable:** genealogy RCA unavailable

## Fields

| Canonical field | Criticality | Meaning | Common aliases |
|---|---|---|---|
| `parent_material_id` | REQUIRED | upstream material identity | parent_material_id, parent_id, source_wafer_id |
| `child_material_id` | REQUIRED | downstream material identity | child_material_id, child_id, target_wafer_id |
| `available_at` | REQUIRED | time record became knowable to EPHI | available_at, load_dttm, ingest_time, create_dttm, update_time |
| `relation_type` | HIGH_VALUE | genealogy relationship | relation_type, relation, link_type |

## Agent validation guidance

### `available_at`
- Validate: normally >= event_time
- Validate: required for strict historical replay

## Binding rule

Map the physical source to these canonical fields through `company_bindings/`; do not edit `src/ephi/` to accommodate source naming differences.
