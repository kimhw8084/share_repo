# HISTORICAL_CASES semantic requirement

**Tier:** C

## Purpose
- historical analogue and RCA memory

**If unavailable:** historical intelligence unavailable

## Fields

| Canonical field | Criticality | Meaning | Common aliases |
|---|---|---|---|
| `case_id` | REQUIRED | investigation/case identity | case_id, rca_id, ticket_id, issue_id |
| `opened_at` | REQUIRED | case opening/event time | opened_at, open_time, created_at |
| `available_at` | REQUIRED | time record became knowable to EPHI | available_at, load_dttm, ingest_time, create_dttm, update_time |
| `asset_id` | REQUIRED | stable equipment identity | eqp_id, equipment_id, tool_id, machine_id, mch_id |
| `root_cause_category` | HIGH_VALUE | curated root-cause category | root_cause_category, cause_code, rca_category |
| `resolution_summary` | HIGH_VALUE | resolution/action summary | resolution_summary, resolution, close_comment |

## Agent validation guidance

### `available_at`
- Validate: normally >= event_time
- Validate: required for strict historical replay

### `asset_id`
- Validate: moderate cardinality
- Validate: stable across time

## Binding rule

Map the physical source to these canonical fields through `company_bindings/`; do not edit `src/ephi/` to accommodate source naming differences.
