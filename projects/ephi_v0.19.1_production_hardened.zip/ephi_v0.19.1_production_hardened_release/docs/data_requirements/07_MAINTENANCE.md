# MAINTENANCE semantic requirement

**Tier:** B

## Purpose
- separate maintenance transitions
- build asset epochs

**If unavailable:** maintenance hypotheses are reduced

## Fields

| Canonical field | Criticality | Meaning | Common aliases |
|---|---|---|---|
| `maintenance_event_id` | REQUIRED | unique maintenance identity | maintenance_event_id, pm_id, work_order_id, event_id |
| `asset_id` | REQUIRED | stable equipment identity | eqp_id, equipment_id, tool_id, machine_id, mch_id |
| `event_type` | REQUIRED | PM/calibration/repair/replacement classification | event_type, pm_type, maint_type, action_type |
| `event_time` | REQUIRED | physical event or measurement time | event_time, start_time, end_time, finish_ts, finish_time, end_ts, meas_time, measure_time, proc_time |
| `available_at` | REQUIRED | time record became knowable to EPHI | available_at, load_dttm, ingest_time, create_dttm, update_time |
| `process_unit_id` | HIGH_VALUE | optional process/measurement unit below equipment | chamber_id, unit_id, head_id, module_id |
| `component_id` | HIGH_VALUE | replaced/serviced component | component_id, part_id, component |
| `action` | HIGH_VALUE | maintenance action text/code | action, work_desc, action_code |

## Agent validation guidance

### `asset_id`
- Validate: moderate cardinality
- Validate: stable across time

### `event_time`
- Validate: must not be inferred from warehouse load time when physical time exists

### `available_at`
- Validate: normally >= event_time
- Validate: required for strict historical replay

### `process_unit_id`
- Validate: few stable values per asset
- Warning: do not invent a chamber where equipment has no sub-unit

## Binding rule

Map the physical source to these canonical fields through `company_bindings/`; do not edit `src/ephi/` to accommodate source naming differences.
