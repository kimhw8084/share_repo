# EXECUTIONS semantic requirement

**Tier:** A

## Purpose
- anchor process history
- attach signals, material, route and context

**If unavailable:** behavioral analysis is unavailable

## Fields

| Canonical field | Criticality | Meaning | Common aliases |
|---|---|---|---|
| `execution_id` | REQUIRED | unique process-execution identity | execution_id, hist_id, run_id, run_key, proc_id, event_id |
| `asset_id` | REQUIRED | stable equipment identity | eqp_id, equipment_id, tool_id, machine_id, mch_id |
| `process_unit_id` | HIGH_VALUE | optional process/measurement unit below equipment | chamber_id, unit_id, head_id, module_id |
| `event_time` | REQUIRED | physical event or measurement time | event_time, start_time, end_time, finish_ts, finish_time, end_ts, meas_time, measure_time, proc_time |
| `available_at` | REQUIRED | time record became knowable to EPHI | available_at, load_dttm, ingest_time, create_dttm, update_time |
| `operation` | HIGH_VALUE | manufacturing operation | oper_id, operation, step, operation_id |
| `recipe_id` | HIGH_VALUE | recipe/process program | recipe_id, rcp_id, recipe, program_id |
| `product_id` | HIGH_VALUE | product/device | product_id, prod_id, device_id, product |
| `technology` | OPTIONAL | technology/process node | technology, tech_id, tech |
| `material_id` | REQUIRED | globally stable wafer/material identity | wafer_id, material_id, substrate_id, wafer_key |
| `source_revision` | OPTIONAL | source correction/revision identity | source_revision, revision, version, update_seq |

## Agent validation guidance

### `execution_id`
- Validate: near-unique at execution grain

### `asset_id`
- Validate: moderate cardinality
- Validate: stable across time

### `process_unit_id`
- Validate: few stable values per asset
- Warning: do not invent a chamber where equipment has no sub-unit

### `event_time`
- Validate: must not be inferred from warehouse load time when physical time exists

### `available_at`
- Validate: normally >= event_time
- Validate: required for strict historical replay

### `material_id`
- Validate: joins across process and measurement history
- Validate: high cardinality
- Warning: wafer number 1-25 usually requires lot + wafer composite

## Binding rule

Map the physical source to these canonical fields through `company_bindings/`; do not edit `src/ephi/` to accommodate source naming differences.
