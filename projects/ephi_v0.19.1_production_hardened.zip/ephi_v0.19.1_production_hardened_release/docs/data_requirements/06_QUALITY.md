# QUALITY semantic requirement

**Tier:** B

## Purpose
- estimate whether equipment state is harmful

**If unavailable:** health detection continues without quality harmfulness

## Fields

| Canonical field | Criticality | Meaning | Common aliases |
|---|---|---|---|
| `material_id` | REQUIRED | globally stable wafer/material identity | wafer_id, material_id, substrate_id, wafer_key |
| `characteristic` | REQUIRED | quality/yield target | characteristic, item_id, metric, test_name |
| `value` | REQUIRED | quality result | value, result, metric_value |
| `event_time` | REQUIRED | physical event or measurement time | event_time, start_time, end_time, finish_ts, finish_time, end_ts, meas_time, measure_time, proc_time |
| `available_at` | REQUIRED | time record became knowable to EPHI | available_at, load_dttm, ingest_time, create_dttm, update_time |
| `spec_low` | HIGH_VALUE | lower specification limit | spec_low, lsl, lower_limit |
| `spec_high` | HIGH_VALUE | upper specification limit | spec_high, usl, upper_limit |

## Agent validation guidance

### `material_id`
- Validate: joins across process and measurement history
- Validate: high cardinality
- Warning: wafer number 1-25 usually requires lot + wafer composite

### `event_time`
- Validate: must not be inferred from warehouse load time when physical time exists

### `available_at`
- Validate: normally >= event_time
- Validate: required for strict historical replay

## Binding rule

Map the physical source to these canonical fields through `company_bindings/`; do not edit `src/ephi/` to accommodate source naming differences.
