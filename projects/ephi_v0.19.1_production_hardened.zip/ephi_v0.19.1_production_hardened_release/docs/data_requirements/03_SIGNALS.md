# SIGNALS semantic requirement

**Tier:** A

## Purpose
- FDC scalar behavioral health

**If unavailable:** FDC scalar capability unavailable

## Fields

| Canonical field | Criticality | Meaning | Common aliases |
|---|---|---|---|
| `execution_id` | REQUIRED | execution foreign key | execution_id, hist_id, run_id, proc_id |
| `signal_id` | REQUIRED | FDC parameter/signal identity | signal_id, param_id, parameter, tag_name, sensor_id |
| `value` | REQUIRED | numeric signal summary | value, param_value, mean_value, avg_value, result |
| `available_at` | REQUIRED | time record became knowable to EPHI | available_at, load_dttm, ingest_time, create_dttm, update_time |
| `event_time` | REQUIRED | physical event or measurement time | event_time, start_time, end_time, finish_ts, finish_time, end_ts, meas_time, measure_time, proc_time |
| `asset_id` | REQUIRED | stable equipment identity | eqp_id, equipment_id, tool_id, machine_id, mch_id |
| `step_id` | HIGH_VALUE | recipe step | step_id, step, phase_id |
| `unit` | HIGH_VALUE | engineering unit | unit, uom, eng_unit |

## Agent validation guidance

### `available_at`
- Validate: normally >= event_time
- Validate: required for strict historical replay

### `event_time`
- Validate: must not be inferred from warehouse load time when physical time exists

### `asset_id`
- Validate: moderate cardinality
- Validate: stable across time

## Binding rule

Map the physical source to these canonical fields through `company_bindings/`; do not edit `src/ephi/` to accommodate source naming differences.
