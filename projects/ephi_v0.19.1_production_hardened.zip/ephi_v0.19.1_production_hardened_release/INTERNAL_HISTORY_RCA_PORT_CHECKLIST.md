# Internal Historical Intelligence & RCA Port Checklist — v0.9.0

## 1. Historical case source

Map the logical `historical_cases` contract. At minimum provide:

- stable `case_id`;
- `opened_at`;
- `available_at` — when EPHI could actually know the historical conclusion.

Strongly preferred:

- asset/process family;
- root-cause category;
- root-cause confidence or curation status;
- actions taken;
- action result;
- resolution summary;
- source-document/ticket locator.

Do not backdate a final RCA resolution to the original excursion date. Replay must only see the conclusion after its real `available_at`.

## 2. Case curation

Pre-EPHI tickets/reports are not ground truth by default. Map/curate cases into:

- unreviewed;
- partially structured;
- engineer reviewed;
- root cause confirmed;
- disputed;
- insufficient evidence.

Keep benign/false investigations. They are essential negative historical intelligence.

## 3. Episode fingerprint validation

Before changing weights/scales in `configs/history/reference.yaml`:

1. build fingerprints for curated historical episodes;
2. manually inspect nearest cases for representative families;
3. verify similarity is not dominated by exact asset identity, duration, or one high-magnitude feature;
4. test behavior-only, metrology-rich, quality-rich, PM, benign, and common-mode cases;
5. measure precision@K / useful-case rate with engineers;
6. measure top-K stability under small input perturbations.

Do not enable ANN before exact retrieval is the validated truth set.

## 4. Route-token construction

Materialize route tokens from canonical execution exposure rather than reconstructing routes from informal lot timestamps.

Preserve:

- material ID;
- route sequence;
- operation;
- exact asset/process unit where available;
- asset epoch;
- recipe/process regime;
- execution event time;
- rework/repeated passes;
- active EPHI episode/health state at exposure.

Do not collapse multiple passes into one unordered set.

## 5. Control populations

Provide at least one defensible matched control policy; preferably strict and broader sensitivity controls.

Potential matching dimensions include:

- product/technology;
- operation/recipe;
- calendar window;
- upstream route;
- rework state;
- lot/split-lot relationship where valid;
- queue/hold conditions where relevant.

Record policy and confidence for every control set. A candidate that disappears under reasonable alternative controls must lose control-robustness support.

## 6. Material outcome time

For temporal causal plausibility, provide downstream failure/quality outcome time where available.

Do **not** use equipment episode onset as a generic substitute for material outcome time. If material-level ordering cannot be established, EPHI should return `UNCERTAIN` temporal plausibility.

## 7. Commonality validation

Use known RCA cases to validate:

- causal candidate rank;
- routine-route negatives;
- upstream-confounding negatives;
- same-lot/split-lot cases;
- health-state-specific exposure factors;
- product/recipe interactions;
- control-policy sensitivity.

Track known-cause rank/recall@K rather than just whether the factor appears somewhere in output.

## 8. Interaction policy

Keep production interaction search bounded:

- single factors first;
- only top-K pairwise follow-up;
- only semantics-approved factor families;
- require incremental lift over either factor alone;
- no default higher-order combinations.

## 9. Scale/performance proof

Measure separately:

- historical fingerprint build throughput;
- exact similarity corpus search latency;
- case-filter pushdown/selectivity;
- route-token materialization size;
- route/commonality scan latency;
- affected/control population size;
- Big Data bytes scanned;
- materialized index read volume.

If exact search does not meet the engineer latency target, add ANN as a candidate retrieval layer and validate ANN recall against exact top-K before promotion.

## 10. API/shadow review

During shadow evaluation, engineers should review:

- whether top historical cases are genuinely useful;
- whether important differences prevent anchoring errors;
- whether routine route factors are correctly demoted;
- whether temporal contradictions are obvious;
- whether recommended verification is useful;
- whether candidate ranking is stable across reasonable control sets.

## 11. Prohibited shortcuts

Do not:

- use ticket text as confirmed root cause by default;
- expose future RCA conclusions during historical replay;
- use simple affected-set intersection as RCA;
- rank factors without controls;
- let historical similarity override temporal contradiction;
- launch all-pairs/high-order combinations;
- run full-fab genealogy traversal for every episode;
- declare a component root cause automatically from this substrate.
