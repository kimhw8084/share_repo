# Notebooks

Exploratory only. Production modules may be imported by notebooks; production code must never depend on notebook state or files.
