# EPHI v0.13.0 — Family Onboarding & Internal Qualification Automation

## Purpose

v0.13.0 converts family onboarding from a manual checklist into a versioned evidence workflow. It does **not** relax any existing certification gate and it does not let the portable package self-certify internal production readiness.

The automated path is:

1. Data Reality report
2. capability-scoped family onboarding plan
3. curated Golden Historical case registry
4. strict replay/runtime qualification evidence
5. shadow review sampling + missed-event evidence
6. promotion evidence package
7. validated immutable FamilyQualificationManifest

## New semantic objects

- `FamilyOnboardingPlan`
- `CapabilityGap`
- `OnboardingAction`
- `GoldenCaseIntake`
- `ShadowReviewCandidate`
- `ShadowReviewQueueItem`
- `ShadowQualificationMetrics`
- `PromotionEvidencePackage`

## Capability-scoped planning

Required capabilities are blockers unless `QUALIFIED`. Optional capabilities become explicit limitations rather than global blockers. This prevents both extremes:

- requiring every factory dataset before a focused pilot, and
- declaring a family ready because *some* useful tables exist.

The reference metrology policy requires:

- PROCESS_HISTORY
- METROLOGY
- REFERENCE_WAFER

and treats spatial metrology, maintenance, quality, WIP routing, and historical cases as optional until the family plan promotes them to required.

## Golden case curation

Internal-history cases use a durable intake registry. Accepted cases require:

- a stable approved `source_locator`,
- explicit scope and label confidence,
- evidence references,
- an independent reviewer (submitter cannot self-approve), and
- immutable revision history.

Only the latest ACCEPTED revision can be exported to `BenchmarkCase` / `BenchmarkCorpus`.

The reference family policy additionally requires case-type coverage. A metrology family cannot qualify using only one attractive excursion. The reference policy requires healthy, measurement-system shift, common-mode process shift, maintenance transition, data-pipeline change, and ambiguous cases, plus minimum total/high-confidence counts.

## Shadow review sampling

Engineer review sampling is deterministic and stratified. The default reference policy prioritizes:

- high operational priority,
- high technical severity,
- low-confidence cases,
- hypothesis coverage,
- deterministic tie-breaking.

All scoring weights/thresholds are versioned in `configs/onboarding/metrology_reference.yaml`.

Review queue claims are lease-based. If a reviewer abandons a claim, the item can be reclaimed after expiry. Queue state is durable through the generic CAS `StateStore`.

## Shadow metrics

The automation keeps distinct metrics instead of collapsing them into one score:

- useful / partially useful engineer rate,
- misleading rate,
- invalid-comparison rate,
- verification-useful rate,
- review completion rate,
- not-useful-or-misleading rate,
- missed-event report count,
- missed reports per 100 reviews,
- hypothesis sampling/review coverage,
- review backlog.

A missed-event report is **not** silently converted into a false-negative rate because the denominator is not generally known from shadow review alone.

## Certification correction

v0.13.0 closes a prior policy gap:

- entering `SHADOW` requires offline scientific/runtime gates,
- transitioning `SHADOW -> SHADOW_QUALIFIED` additionally requires `ENGINEER_SHADOW` evidence.

`SHADOW_QUALIFIED` is therefore no longer equivalent to merely running in shadow.

## Promotion evidence

A `PromotionEvidencePackage` is capability-specific and records:

- family/release/capability identity,
- from/to certification state,
- gate results,
- onboarding blockers/limitations,
- Golden corpus counts/confidence coverage,
- shadow metrics when required,
- supporting artifact references,
- READY/BLOCKED decision.

Blocked packages cannot create certification manifests.

Multiple READY capability packages with the same family, release, and target state can be assembled into a `FamilyQualificationManifest`. The existing `CertificationService` validates the resulting manifest before it is returned.

## CLI

New commands:

```bash
ephi onboarding plan ...
ephi onboarding golden-submit ...
ephi onboarding golden-review ...
ephi onboarding golden-export ...
ephi onboarding promotion-package ...
ephi onboarding family-manifest ...
ephi onboarding benchmark ...
```

The local Golden curation CLI uses SQLite only as a reference/offline store. Internal multi-user onboarding should instantiate `GoldenCaseRegistry` and `ShadowReviewQueue` on the approved shared CAS state backend.

## Qualification

The v0.13 mechanism qualification verifies:

- required capability gaps block promotion,
- optional gaps remain limitations,
- qualified required capabilities unblock planning,
- Golden self-approval is rejected,
- accepted cases convert to internal-history BenchmarkCase,
- Golden registry survives restart,
- shadow sampling covers hypotheses,
- queue enqueue is idempotent,
- review queue survives restart,
- expired review leases are reclaimable,
- missed/low-value metrics remain explicit,
- offline evidence can become READY,
- Golden coverage policy blocks missing strata,
- SHADOW_QUALIFIED requires engineer evidence,
- incomplete hypothesis review coverage blocks shadow qualification,
- READY packages can generate a validated family manifest.

## Production boundary

This release qualifies the **onboarding mechanism**, not any Samsung/internal family. A real family remains `RESEARCH` until its own mapped Data Reality, Golden historical replay, runtime-scale measurements, and engineer shadow evidence are loaded into the same contracts.

## Release qualification

Portable v0.13 qualification on the clean release copy:

- 176 tests collected; 175 passed; 1 optional PyArrow integration skipped;
- behavioral/metrology Golden gate PASS;
- quality/harmfulness gate PASS;
- exposure/priority gate PASS;
- history/RCA gate PASS;
- value/ROI gate PASS;
- shadow/release operations gate PASS;
- internal port mechanism gate PASS;
- family onboarding automation gate PASS;
- OpenAPI remains 26 typed paths;
- Data Reality remains 11 semantic datasets;
- release manifest recomputation matches the packaged tree.

Release identity: `ephi-0.13.0-3024e1b7c8f0-4cedb8b9516d`.

This qualifies the mechanism only. No internal manufacturing family is promoted by this artifact.
