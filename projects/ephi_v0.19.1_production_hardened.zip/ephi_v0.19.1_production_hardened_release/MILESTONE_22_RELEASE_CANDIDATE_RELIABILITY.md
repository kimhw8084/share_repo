# Milestone 22 — Release-Candidate Reliability, State Migration & Disaster Recovery

## Governing principle

EPHI must preserve **scientific truth, qualification truth, and business/audit truth across operational failure**. A restart, duplicate job, stale lease, partial source outage, state migration, corrupted checkpoint, restore, or rollback must never silently manufacture a new analytical conclusion.

The v0.15 implementation therefore separates:

- **authoritative state** — human workflow, qualification/audit history, validated value evidence, operational controls, incremental source knowledge boundaries, and the applied-work idempotency ledger;
- **rebuildable state** — detector/reference/peer caches, freshness caches, backfill progress, and queue state that can be reconstructed from authoritative source/history under controlled requalification.

Missing authoritative state blocks recovery. Missing rebuildable state triggers rebuild and blocks advisory readiness until freshness/qualification recovers.

## Implemented architecture

### 1. Snapshot-capable state-store contract

`SnapshotStateStore` extends the existing CAS `StateStore` with:

- point-in-time-consistent `snapshot(...)`;
- clean-target `restore_snapshot(...)`;
- exact preservation of state payload, CAS version, and update timestamp in the local reference adapter.

The SQLite implementation performs consistent read transactions and one write transaction for restore. SQLite remains local/reference only; company multi-pod recovery must implement the same contract on the approved shared backend.

### 2. Checksummed state backup bundles

`StateBackupBundle` contains:

- source release identity;
- release-level state schema version;
- namespace durability policy;
- each selected state record with value SHA-256;
- whole-bundle content SHA-256;
- immutable creation time and bundle ID.

Backup creation fails by default when it finds a state key not classified by the versioned reliability policy. This prevents a newly added subsystem from silently falling outside DR protection.

Restore verifies:

1. bundle checksum;
2. each record checksum;
3. required authoritative namespaces;
4. clean target requirement.

Bundles can be published through EPHI's existing immutable `ArtifactStore`; the artifact store hash and the bundle's own semantic hash are both checked on materialization.

### 3. Versioned recovery policy

`configs/reliability/reference.yaml` classifies state namespaces. Broad authoritative namespaces have more-specific rebuildable overrides where appropriate. Notable semantics:

- `business:` — authoritative;
- `onboarding:` — authoritative;
- `product:` — authoritative;
- `port:` — authoritative;
- `operations:` — authoritative by default;
- `operations:freshness:` / `operations:backfill:` — rebuildable;
- `pipeline:` — rebuildable but required to regain advisory readiness;
- `runtime:` — rebuildable by default;
- `runtime:applied-work:` — authoritative because it protects the post-handler crash window;
- `watermark:` — authoritative incremental knowledge boundary.

The reference policy is a template and must be reviewed against the actual internal state inventory before shadow promotion.

### 4. Recovery assessment

`assess_inventory(...)` produces one of:

- `READY`;
- `REBUILD_REQUIRED`;
- `BLOCKED`.

A required authoritative namespace that is absent always results in `BLOCKED`. Required rebuildable state can result in `REBUILD_REQUIRED`, after which source replay/backfill and freshness gates must complete before advisory use.

### 5. Deterministic state migration registry

`StateMigrationRegistry` provides explicit domain/from-schema/to-schema transformations. Migrations are deterministic and may declare a semantic projection. If the projection changes, migration fails.

The built-in behavioral migration demonstrates:

`behavioral_pipeline_state_v1 → behavioral_pipeline_state_v2`

by adding an empty `fleet_episodes` representation while preserving detector/episode semantics.

Release compatibility now distinguishes `REQUIRES_MIGRATION` from `REQUIRES_REBUILD`. A non-reversible migration makes rollback unsafe even when forward migration is available.

### 6. Fail-closed checkpoint semantics

Behavioral/metrology checkpoint restoration remains strict:

- malformed JSON fails;
- unsupported schemas fail;
- incomplete component payloads fail;
- no checkpoint failure is interpreted as a normal/healthy analytical state.

### 7. Multi-process durable queue hardening

`DurableWorkQueue` now uses CAS retry/re-read for enqueue, claim, complete, and fail operations. It adds:

- `work_id` as an explicit idempotency identity;
- conflicting reuse of a work ID with different payload/job semantics is rejected;
- dependency-aware work ordering via `depends_on`;
- exact-one lease winner under concurrent reference workers;
- lease expiry/reclaim after worker crash;
- at-least-once semantics retained.

### 8. Applied-work crash-window ledger

`AppliedWorkLedger` records a successful work application after the handler succeeds and before queue completion. If the process dies in this interval, a replacement worker can reclaim the lease and complete it without re-running the handler.

This closes one common EPHI-local duplicate window. It **does not** replace idempotency/transaction semantics in external company systems; external writes still need the work ID or another approved idempotency key.

### 9. Partial-source degraded mode

`assess_degraded_mode(...)` maps freshness state into capability-specific availability instead of globally declaring the platform healthy/unhealthy.

Examples:

- stale/missing WIP disables `exposure_priority` while behavioral scoring may remain available;
- stale source/canonical/feature/reference/peer state blocks new analytical scoring;
- existing materialized advisory/history/value reads may remain visible as explicitly degraded/stale where safe;
- notification delivery requires current assessment state.

Missing data never becomes normal evidence.

### 10. Company recovery seam

The `ephi-company-port` scaffold now requires a snapshot-capable recovery store in addition to ordinary shared CAS state. `ephi_company.recovery` supplies operator-only composition for:

- immutable backup creation;
- approved artifact publishing;
- clean-target restore.

There is deliberately **no HTTP restore route**. Internal authentication/change-control must wrap destructive recovery actions.


### 11. Reliability is a formal shadow certification plane

`QualificationPlane.RELIABILITY_DR` is now part of the family certification policy.

- `OFFLINE_QUALIFIED` still requires the scientific/runtime offline planes only; this preserves the distinction between offline method qualification and live-operational readiness.
- entering `SHADOW` requires `RELIABILITY_DR`;
- `SHADOW_QUALIFIED`, `ADVISORY_PILOT`, and `PRODUCTION_ADVISORY` retain that requirement in addition to their engineer-shadow and capability-specific gates.

This makes backup/restore, recovery, migration, queue-crash safety, and degraded-mode evidence a promotion prerequisite rather than a release-note assertion.

## Reference qualification

The v0.15 reliability gate verifies:

- exact backup/restore;
- real Value Ledger state deserializes after restore;
- real qualification workspace deserializes after restore;
- real operational controls survive restore;
- bundle corruption is rejected;
- unclassified state blocks backup;
- restore into a dirty target is rejected;
- corrupt/incomplete analytical checkpoints fail closed;
- immutable artifact round-trip;
- missing authoritative state blocks recovery;
- missing rebuildable state requests rebuild;
- a previous valid backup can be selected when a newer artifact is invalid;
- deterministic semantic migration;
- irreversible migration blocks rollback;
- work-ID idempotency and conflict rejection;
- explicit dependency ordering;
- stale lease recovery;
- exact-one concurrent claim;
- applied-work crash-window duplicate suppression;
- WIP-only outage isolation;
- source outage blocks new scoring.

## Deliberate limits

v0.15 does not claim:

- company database snapshot consistency;
- company backup encryption/retention compliance;
- cross-region restore RTO/RPO;
- transactional idempotency for arbitrary external side effects;
- internal Kubernetes failover performance;
- production disaster-recovery certification.

Those require the actual company backends, real data volume, and controlled shadow/DR drills.
