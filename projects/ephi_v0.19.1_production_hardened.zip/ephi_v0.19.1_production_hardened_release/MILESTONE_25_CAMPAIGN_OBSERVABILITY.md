# Milestone 25 — Campaign Observability, Evidence Reconciliation & Promotion Readiness

## Governing principle

Campaign execution history is operational evidence. It must be inspectable, reproducible, and reconcilable without creating a second analytical decision engine.

`campaign retry != changed scientific evidence`

`artifact exists != artifact is still valid`

`campaign completed != promotion ready`

`old campaign != SLO failure merely because it is old`

## Implemented in v0.18.0

### Campaign-scoped evidence

Readiness is computed only from evidence, replay manifests, and source snapshots referenced by the campaign's own stage attempts. Unrelated evidence in the same family workspace cannot leak into a campaign decision.

### Evidence-set fingerprints

Each campaign exposes three deterministic SHA-256 projections:

- evidence/replay semantic fingerprint;
- source-snapshot semantic fingerprint;
- execution-shape fingerprint.

This allows two campaigns to distinguish `IDENTICAL`, `SOURCE_CHANGED`, `EVIDENCE_CHANGED`, `EXECUTION_CHANGED`, and `TARGET_CHANGED` without conflating a retry with changed analytical truth.

### Cross-stage reconciliation

The reconciler verifies:

- release/family/config identity;
- current artifact content against the stored SHA-256;
- required-stage coverage;
- source snapshots exist;
- source lineage is same-or-descendant across ordered stages;
- source `as_of` does not move backward;
- replay manifests point to the source snapshot actually recorded by the producing stage.

A violation produces `BLOCKED`, not a warning-only promotion state.

### Failure taxonomy

Campaign failures are surfaced as bounded operational categories:

- `ADAPTER_CONTRACT`
- `SOURCE_UNAVAILABLE`
- `SOURCE_IDENTITY`
- `ARTIFACT_INTEGRITY`
- `EVIDENCE_REJECTED`
- `RETRY_EXHAUSTED`
- `CONTROL_PLANE_HANDOFF`
- `CONFIGURATION`
- `UNKNOWN`

The underlying error remains preserved; taxonomy is a read-model classification for operations/review.

### Campaign SLO

Versioned SLO policy is externalized under `configs/campaign/metrology_reference.yaml`.

The SLO measures actual execution duration. Once a campaign reaches a terminal stage state, review time no longer increases campaign elapsed duration. A campaign reviewed 90 days later therefore does not fail because it is 90 days old.

### Retention

`configs/campaign/retention_reference.yaml` governs minimum retention for:

- immutable evidence;
- replay manifests;
- source lineage;
- failed-attempt diagnostics.

Promotion/qualification evidence requires an immutable `ArtifactStore` reference.

### Promotion readiness

`CampaignReadinessView` combines:

- campaign attempts;
- stage read models;
- cross-stage reconciliation;
- campaign SLO;
- retention blockers;
- the existing `ShadowLaunchDossier` promotion result;
- qualification-control-plane handoff state when available.

This layer cannot change technical severity, evidence, quality, RCA, exposure, or value conclusions.

### Immutable qualification export

`CampaignQualificationExport` carries a deterministic export SHA-256. The export can be published through the approved immutable `ArtifactStore`; the publication reference is separate from the semantic export hash.

### Read-only API

v0.18 adds:

- `GET /v1/launch/families/{family_id}/campaigns/{campaign_id}`
- `GET .../events`
- `GET .../reconciliation`
- `GET .../slo`
- `GET .../retention`
- `GET .../export`
- `GET .../{baseline_campaign_id}/compare/{candidate_campaign_id}`

There are no campaign-observability mutation endpoints.

## Qualification

`CAMPAIGN_OBSERVABILITY_QUALIFICATION_V180.json` proves:

- campaign scope excludes unrelated family evidence;
- artifacts are re-hashed on read;
- divergent source lineage is blocked;
- replay/source disagreement is blocked;
- retry changes execution fingerprint without changing semantic evidence fingerprint;
- failure events receive a non-empty bounded taxonomy;
- completed campaign SLO does not age after completion;
- immutable evidence retention has no blockers;
- qualification export is deterministic;
- export publication through `ArtifactStore` succeeds.

## Deliberately not implemented

- No dashboard-specific logic.
- No mutation API for campaign evidence.
- No automatic promotion approval.
- No artifact deletion engine.
- No source-lineage guessing when parentage is unknown.
- No second scoring/fusion system in the observability layer.

## Internal promotion boundary

The portable v0.18 gate qualifies mechanism semantics only. Internal promotion still requires exact-release/config `INTERNAL_MEASURED` evidence and the existing qualification-control-plane approval path.
