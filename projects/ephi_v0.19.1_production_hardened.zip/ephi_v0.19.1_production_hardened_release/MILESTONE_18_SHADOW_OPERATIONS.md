# Milestone 18 — Shadow Deployment, Production Qualification & Release Operations

EPHI v0.11.0 adds the operational control plane required to move the portable reference implementation into a controlled internal shadow deployment. It does **not** promote any analytical capability to production by itself.

## Governing invariants

1. Certification is a state machine, not `dev/test/prod` labeling.
2. A capability cannot self-declare qualification; every declared state must carry the required gate evidence.
3. Shadow challengers receive identical inputs but can never alter the champion production output.
4. Challenger failures are isolated from champion execution.
5. Notification suppression blocks delivery only; analytical scoring/evidence persists.
6. Missing/stale operational data becomes `UNKNOWN/STALE`, never `NORMAL`.
7. Live/recent-correction work outranks historical backfill.
8. Queue execution is at-least-once; handlers must be idempotent.
9. Expired leases are reclaimable after worker failure.
10. Family qualification history is immutable and restartable.
11. Release rollback is blocked for destructive/incompatible state changes.
12. Kubernetes resource values in the portable template are provisional and require internal scale qualification.
13. The Kubernetes template does not use the local SQLite queue. Internal workers must provide an approved shared runtime module.

## Certification states

`RESEARCH -> OFFLINE_QUALIFIED -> SHADOW -> SHADOW_QUALIFIED -> ADVISORY_PILOT -> PRODUCTION_ADVISORY -> DEPRECATED`

Explicit rollback transitions are allowed only where the state machine defines them. Skipping qualification stages is rejected.

Capability-specific gates are enforced. For example:

- `quality-harmfulness` requires `QUALITY_HARMFULNESS` evidence;
- `exposure-priority` requires `EXPOSURE_PRIORITY`;
- `history-rca` requires `HISTORY_RCA`;
- `value-roi` requires `VALUE_ROI`.

A manifest submitted directly at a qualified state is validated against these requirements even if there was no prior registry transition.

## Family qualification registry

`FamilyQualificationRegistry` stores immutable `FamilyQualificationManifest` history using compare-and-set state. A later release/promotion never rewrites the earlier manifest.

The shipped `FAMILY_QUALIFICATION_TEMPLATE_V110.json` intentionally remains `RESEARCH` and states that synthetic qualification is not internal production evidence.

## Engineer shadow qualification

Structured `EngineerShadowReview` captures:

- whether the engineer would want the event;
- comparison validity;
- hypothesis reasonableness;
- recommended-verification usefulness;
- misleading/false-event reason.

`ShadowGatePolicy` evaluates review count, useful-event rate, misleading rate, invalid-comparison rate, and verification-useful rate. This is separate from offline model metrics.

## Champion/challenger execution

`ShadowRunner` executes one champion and any number of challengers on identical inputs. The returned production result is always the champion output. Challenger exceptions become shadow errors rather than production failures.

`ShadowComparisonStore` persists comparisons and summarizes:

- actionable disagreement rate;
- challenger error rate;
- latency delta.

These summaries are promotion evidence only; no auto-promotion exists.

## Scoped operational controls

`OperationalControlService` supports durable controls for:

- notifications;
- capability;
- detector;
- model;
- source.

Scopes can be global, family, or component. Controls preserve activation/deactivation history and optional expiry.

`NotificationDeliveryGate` proves the safety boundary: notification suppression does not disable analytical capability.

HTTP control mutation is intentionally not exposed in the portable API. The company deployment should enable mutations only behind approved identity/authorization.

## Operational freshness / SLOs

`FreshnessTracker` persists heartbeats for:

- source;
- canonical;
- feature;
- reference;
- peer;
- assessment;
- WIP;
- quality model;
- historical index;
- value reconciliation.

`OperationalSLOReport` maps each to `CURRENT`, `DEGRADED`, `STALE`, or `UNKNOWN`. Missing heartbeats are `UNKNOWN` and can block production readiness.

`configs/operations/reference.yaml` contains **reference placeholders only**. Internal family onboarding must replace them with real manufacturing time-to-action requirements.

## Bootstrap/backfill control

`BackfillController` creates restartable temporal chunks across the planned bootstrap phases:

1. canonical history;
2. material exposure;
3. core features;
4. maintenance state;
5. references;
6. peers;
7. historical replay;
8. quality;
9. history index.

Work priority is explicit: `LIVE`, then `RECENT_CORRECTION`, then `HISTORICAL_BACKFILL`.

## Durable reference work queue

`DurableWorkQueue` provides the portable queue contract:

- idempotent enqueue by work ID;
- priority ordering;
- expiring leases;
- reclaim after worker failure;
- retry or terminal failure;
- compare-and-set persistence.

It is a small reference implementation, not a mandate to use JSON/SQLite internally. The company port can replace it with an approved shared database/queue while retaining the claim/lease/idempotency semantics.

`WorkerHost` runs handlers against this contract and requeues transient failures.

## Kubernetes runtime roles

The reference deployment separates:

- API;
- incremental workers;
- batch workers;
- replay workers;
- optional GPU workers.

All resource sizes are marked `PROVISIONAL`. GPU replicas are zero by default.

The API pod requires `ephi_company.app.create_app(config)` so company-backed advisory/history/value/operations services and identity dependencies can be injected. Worker pods require `ephi_company.runtime`, which must expose:

```python
build_queue(role)
build_handlers(role)
```

The template intentionally avoids local SQLite for multi-pod execution.

## Rollback compatibility

Release compatibility checks reject destructive migrations and same-version/different-code ambiguity. State-schema changes can be classified as `REQUIRES_REBUILD` instead of pretending rollback is transparent.

The v0.11 `ReleaseManifest` schema additionally hashes:

- qualification artifacts;
- deployment artifacts;
- state schema version.

## Read-only operations API

v0.11 adds typed read-only endpoints:

- `GET /v1/operations/status`
- `GET /v1/operations/controls`
- `GET /v1/operations/certification`
- `GET /v1/operations/slo`

Portable HTTP mutation of kill switches/certification is deliberately absent.

## Reference qualification

`ephi operations benchmark` verifies:

- certification transition enforcement;
- capability-specific gates;
- self-declared qualified-manifest rejection;
- champion isolation;
- challenger failure isolation;
- engineer shadow gate;
- persistent notification controls;
- notification-vs-analytics separation;
- freshness persistence and stale blocking;
- live-work priority over backfill;
- backfill restart equivalence;
- idempotent work enqueue;
- lease recovery;
- immutable family-promotion history;
- persisted challenger comparisons;
- provisional deployment profile correctness;
- compatible rollback and destructive rollback rejection.

This is reference/synthetic operational qualification only. Internal shadow promotion still requires company Data Reality, scale, identity, durable-state, engineer-review, and SLO evidence.
