# Milestone 23 — v0.16.0 Internal Metrology Shadow Launch & Evidence Execution Kit

## Purpose

v0.16 stops adding generic analytical capability and turns the platform into an executable first-family qualification campaign. It does **not** claim that Samsung/internal evidence exists in the portable package. Instead it defines, hashes, persists, validates, and assembles the evidence that the internal environment must produce.

## Governing invariants

1. Portable/synthetic qualification never satisfies `INTERNAL_MEASURED` launch evidence.
2. Every evidence receipt is bound to `family_id + release_id + config_hash`.
3. Local evidence artifacts are re-hashed at dossier build time; mutation or deletion blocks readiness.
4. Data Reality capability state is insufficient if the report came from another config hash.
5. Production replay requires strict `available_at <= replay_as_of` knowledge time.
6. The launch kit does not invent certification rules. Receipts map into existing `QualificationPlane` values and `CertificationService` remains authoritative.
7. `OFFLINE_QUALIFIED` requires internal Data Reality + internal Golden replay + measured runtime scale.
8. `SHADOW` additionally requires internal `RELIABILITY_DR` evidence.
9. `SHADOW_QUALIFIED` additionally requires live shadow runtime evidence and `ENGINEER_SHADOW`.
10. The reference dossier is expected to remain blocked until real internal evidence is attached.

## Added production contracts

- `LaunchEvidenceReceipt`
- `InternalGoldenReplayManifest`
- `ProductionReplayManifest`
- `ProductionScaleMeasurement`
- `ReliabilityDrillMeasurement`
- `ShadowRuntimeMeasurement`
- `MetrologyShadowLaunchPolicy`
- `MetrologyShadowLaunchPlan`
- `ShadowLaunchDossier`
- `ShadowLaunchWorkspaceRepository`

## Evidence provenance

`PORTABLE_REFERENCE` and `SIMULATED_INTERNAL` are useful for mechanism regression only. They cannot satisfy launch requirements marked `require_internal_measured: true`. Only `INTERNAL_MEASURED` evidence can do so.

## Company integration seam

`ephi_company.launch.build_launch_evidence_executor(config, release_manifest)` must return an executor capable of producing the six launch evidence stages. The scaffold fails closed until implemented. Company collection code owns physical access and execution; generic EPHI owns identity, checksums, policy, readiness, and certification mapping.

## Operator CLI

- `ephi launch plan`
- `ephi launch receipt`
- `ephi launch golden-manifest`
- `ephi launch collect`
- `ephi launch dossier`
- `ephi launch module-validate`
- `ephi launch qualification`

## What is deliberately not claimed

The portable release does not provide real internal Big Data throughput, internal case truth, internal source snapshot IDs, observed RPO/RTO, real shadow observation hours, engineer review results, or a SHADOW-qualified family manifest.
