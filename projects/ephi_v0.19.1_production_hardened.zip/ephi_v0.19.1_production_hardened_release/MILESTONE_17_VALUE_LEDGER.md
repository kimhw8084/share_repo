# Milestone 17 — v0.10.0 Value Ledger, Benefit Attribution & ROI Reconciliation

## Purpose

v0.10.0 completes EPHI's technical-to-business evidence loop without allowing economics to modify scientific truth.

Permanent boundary:

```text
Health / Quality / Exposure / RCA
                ↓
           Value Ledger
                ↓
 Estimated / Observed / Validated value
```

There is no reverse dependency from value/economics into detectors, populations, evidence fusion, health severity, quality harmfulness, or episode formation.

## Core semantics

### 1. Physical evidence precedes money

EPHI can record exact physical quantities without a cost model:

- already exposed material;
- possibly affected material;
- future preventable material;
- protected materials;
- engineering hours saved;
- downtime/capacity/cycle-time/remeasurement quantities;
- compute/resource consumption.

A monetary conversion is optional and requires a versioned cost model.

### 2. Estimated exposure is not savings

`SCRAP_EXPOSURE_ESTIMATE` and `REWORK_EXPOSURE_ESTIMATE` remain `ESTIMATED`. They can never be promoted directly to `VALIDATED` ledger states.

`VALIDATED_REALIZED_BENEFIT` is a different category with mandatory reviewer/source provenance.

### 3. One economic event, one official claim group

`BenefitClaimGroup.economic_event_key` is unique. If two EPHI episodes contributed to one containment event, both episodes belong to the same claim group with separate attribution roles.

This prevents official portfolio ROI from counting one avoided loss once per episode.

### 4. Physical protection deduplication

`WAFERS_PROTECTED` retains material IDs. Program aggregation uses unique material IDs rather than blindly summing row quantities, preventing overlap across related episodes.

### 5. Immutable revisions

Value entries are append-only. A revised estimate or validated benefit explicitly references `supersedes_entry_id`; the previous entry remains available for audit but is excluded from active totals.

### 6. Attribution is explicit

Valid realized benefit requires at least one reviewed EPHI attribution of `PRIMARY`, `CONTRIBUTORY`, or `CONFIRMATORY`. `NONE`/`UNKNOWN` cannot support an EPHI realized-benefit claim.

### 7. Program ROI

Official program aggregation is:

```text
validated realized benefit
- observed/converted operating cost
= net validated value
```

Estimated exposure is reported separately. Engineering-time monetary conversion is not automatically included in validated realized benefit.

No cross-currency aggregation occurs without an explicit future FX policy.

## New modules

```text
src/ephi/domain/value.py
src/ephi/value/costs.py
src/ephi/value/ledger.py
src/ephi/value/service.py
src/ephi/value/checkpoint.py
src/ephi/value/qualification.py
```

## API additions

Read-only endpoints:

```text
GET /v1/episodes/{episode_id}/value-ledger
GET /v1/episodes/{episode_id}/value-summary
GET /v1/value/program-summary
```

Financial validation/reconciliation remains an offline/back-office service operation, not an ordinary engineer-facing HTTP mutation.

## Reference qualification

The v0.10 synthetic fixture deliberately uses arbitrary rates and validates semantics, not real ROI economics.

Reference scenario:

- 100 observed already-exposed materials;
- 50 future-preventable materials;
- estimated avoidable loss: $12,500 synthetic;
- 20 materials protected with routing evidence;
- 5 engineering hours saved;
- first validated benefit: $8,000;
- revised validated benefit: $8,500 via immutable supersession;
- observed compute + false-event cost: $216.70;
- net validated value: $8,283.30;
- benefit/cost ratio: 39.2247.

The benchmark passes only if the estimated $12,500 is excluded from validated ROI.

## Production exclusions

v0.10 intentionally does not implement:

- automatic finance/accounting approval;
- automatic avoided-scrap claims from model probabilities;
- automatic 100% EPHI attribution;
- automatic cross-currency conversion;
- learned economic priority feeding technical health;
- external finance SaaS dependencies;
- automatic operational action based on ROI.

## Internal qualification required

Before official value reporting, the company port must qualify:

1. approved cost-model ownership and effective dates;
2. accounting currency and any FX policy;
3. material-value/rework/capacity definitions;
4. routing evidence for protected-material claims;
5. EPHI contribution review policy;
6. compute/resource cost conversion;
7. value reconciliation authority/workflow;
8. overlap/double-count handling for multi-episode incidents;
9. retention/audit requirements for authoritative ledger state;
10. distinction between internal estimates and finance/operations-validated benefits.
