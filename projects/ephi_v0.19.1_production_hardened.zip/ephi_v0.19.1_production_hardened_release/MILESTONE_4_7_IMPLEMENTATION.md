# EPHI v0.2.0 — Behavioral Intelligence Vertical Slice

## Scope

This milestone implements the first real EPHI intelligence path on top of the Phase 14 runtime foundation:

`scalar feature -> known-good reference -> peer/common-mode -> robust detector -> temporal state -> evidence -> hypothesis fusion -> HealthAssessment -> HealthEpisode`

It is deliberately a **semantic/replay implementation**, not yet the final Arrow/Polars source-scale execution kernel.

## Implemented

- Manufacturing `ContextKey` and scalar feature semantics.
- Controlled known-good reference manager.
- Frozen anchor + adaptive reference.
- Score-before-admit invariant: current observations cannot affect their own reference.
- Anchor-aware admission to prevent slow baseline creep from being normalized away.
- Peer comparison using physical change from each asset's frozen anchor, rather than raw values or incomparable per-tool z-scores.
- Fleet/common-mode decomposition.
- Robust self and anchor deviation.
- Fast/slow EWMA, positive/negative CUSUM, persistence state.
- Persistent peer-residual state.
- Data-pipeline scale-discontinuity canary for fault-injection qualification.
- Structured `EvidenceItem` objects with dependency groups and hypothesis-specific support/contradiction.
- Dependency-aware evidence fusion.
- Broad frozen hypothesis enum for later Phase 6-8 channels.
- Behavioral severity gating with persistence/extreme-event safeguards.
- Common-mode suppression of local actionable escalation unless target-vs-peer divergence is persistently stronger.
- Health episode opening, recovery, resolution and stable human-readable IDs.
- Durable pipeline checkpoint/restore through `StateStore`.
- Synthetic replay CLI.
- Multi-seed behavioral benchmark script.

## Important scientific corrections made during implementation

### 1. Synthetic peer clock

The initial synthetic Parquet generator placed each asset on a separate sequential time block. That makes peer/common-mode validation invalid. Assets now share the same manufacturing time axis so fleet shifts are temporally comparable.

### 2. Peer comparison semantics

An early implementation compared each tool's self-normalized z-score directly to peer z-scores. Different healthy noise scales caused the same physical common-mode shift to appear locally different. The implementation now compares **physical change from each asset's frozen anchor**, normalized by peer/reference spread.

### 3. Baseline creep

A long gradual-drift benchmark showed the adaptive reference could follow a slow deterioration. The implementation now:

- retains a frozen anchor reference;
- stops known-good admission when anchor deviation becomes material;
- uses anchor-relative change for peer comparison;
- includes anchor deviation in novelty/evidence and local confirmation.

This was a model-architecture correction, not a threshold patch.

## Current replay qualification

Deterministic pytest suite:

- 18 tests passed;
- 1 optional local-columnar integration test skipped because `pyarrow` is not installed in the generation sandbox.

The behavioral replay suite verifies:

- healthy history creates no actionable episode;
- local gradual drift opens actionable episodes only on the target asset;
- pure common-mode shift produces no local actionable episodes;
- unit-scale discontinuity is routed to `DATA_PIPELINE_OR_SCHEMA_CHANGE`, not equipment emergency;
- slow gradual drift is not absorbed by adaptive reference;
- checkpoint/restart produces the same subsequent assessments and episode state as uninterrupted processing.

## Multi-seed stress result

A 20-seed stress pass at 800 executions/asset produced:

- **Healthy:** 0 actionable assessments for every seed.
- **Local drift:** all actionable assessments were on target asset `A000`.
- **Common mode:** 0 actionable local assessments for every seed; the final 100 assessments were common-mode in every run.
- **Unit scale change:** 0 actionable equipment assessments; all 320 post-change target assessments per run were classified as pipeline/schema-change hypothesis.

The benchmark is reproducible with:

```bash
PYTHONPATH=src python benchmarks/behavioral_vertical_slice.py --seeds 20 --executions-per-asset 800
```

## Checkpoint invariant

The intelligence state now includes:

- adaptive and anchor reference buffers;
- self sequential state;
- peer sequential state;
- active/resolved episode state;
- episode counter.

A restart test processes half a synthetic history, checkpoints to SQLite, restores into a new pipeline instance, and verifies that the second-half assessments and final episode state match uninterrupted execution.

## Runtime status

A 40,000-observation semantic replay processed at roughly **12.5k observations/second** in the generation environment. This is **not** the production-scale target and should not be extrapolated to billions of rows because the current replay layer intentionally uses Python semantic objects.

The production path still requires the planned Arrow/Polars batch kernel and materialized population/state lookups. The current milestone proves logic and restart determinism first.

## Known intentional limitations

- No full Arrow/Polars detector kernel yet.
- No absolute peer-offset channel yet; this slice implements change-relative peer comparison first.
- No fleet-level parent episode object yet; pure common-mode is recognized and suppresses local escalation.
- Context-specific target drift can create one active episode per hard-match context. Cross-context parent/merge logic comes later.
- No metrology/measurement-system evidence yet.
- No supervised quality/harmfulness yet.
- No trace features yet.
- No WIP/ROI yet.
- Scale-discontinuity detection is a qualification canary, not the final data-quality engine.

## Next implementation priority

The next code milestone should vectorize this proven semantic logic and then build the metrology flagship capability:

1. Arrow/Polars scalar feature and scoring batches.
2. Materialized `ReferenceState` / peer-state lookup rather than Python buffers on the source-scale path.
3. Dirty-range/checkpoint integration for batch state.
4. Fleet/common-mode parent episode aggregation.
5. Metrology observations, reference-wafer, remeasure, cross-tool and spatial features.
6. Measurement-system vs real-process-shift evidence.
