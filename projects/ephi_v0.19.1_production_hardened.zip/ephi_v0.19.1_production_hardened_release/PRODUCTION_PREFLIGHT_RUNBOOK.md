# EPHI v0.19.1 Production Preflight Runbook

Run these in the work environment before historical replay or Kubernetes workers.

```bash
# 1. Prove the SQL engine/API contract itself.
ephi autopilot db-qualify --executor-module ephi_company.big_data --config <company-config>

# 2. Discover/bind each candidate table and explicitly declare partition semantics.
ephi autopilot candidate \
  --dataset metrology \
  --table <candidate> \
  --inspector-module ephi_company.autopilot \
  --config <company-config> \
  --partition-column <physical_partition> \
  --partition-source-field event_time \
  --partition-granularity date \
  --watermark-column <knowledge_time_column> \
  --output-binding company_bindings/metrology.yaml

# 3. After an intentional Gemma edit, validate/reseal rather than hand-editing hashes.
ephi autopilot seal-binding --binding company_bindings/metrology.yaml

# 4. Generate config and required capability set.
ephi autopilot bootstrap \
  --binding company_bindings/executions.yaml \
  --binding company_bindings/metrology.yaml \
  --output-config configs/company/generated.yaml

# 5. One-shot infrastructure/data startup preflight.
ephi port production-preflight \
  --preflight-module ephi_company.production_preflight \
  --config configs/company/generated.yaml \
  --deployment-plan configs/deployment/shadow-reference.yaml \
  --release-manifest RELEASE_MANIFEST.json
```

`production-preflight` must be green before Data Reality or workers. It checks the schema inspector, SQL executor/dialect, Big Data client, state/recovery/materialization/artifact stores, audit backend, identity, read services, notifications, bootstrap and launch hooks, port runtime, mapping/schema/runtime SQL preflight, and every enabled worker role.

Expected configuration mistakes should return exit code 2 with concise JSON/`ERROR:` output and no Python traceback. Unexpected programming defects remain visible as tracebacks.
