# Company SQL bindings

This is the primary company customization zone. Each accepted dataset should have a YAML binding manifest containing explicit SQL, canonical column mappings, partition column, incremental watermark and knowledge-time source.

OpenCode/Gemma may create and modify files here without changing generic EPHI scientific behavior.
