-- EPHI logical dataset: asset_qualification
-- Replace <PHYSICAL_TABLE> and expressions after inspecting schema/values.
-- Requirements: docs/data_requirements/*_ASSET_QUALIFICATION.md
-- Rules: explicit projection; bounded/pushdown predicates; no SELECT *.
SELECT
    -- <physical_expression> AS <canonical_field>
FROM <PHYSICAL_TABLE>
WHERE <partition_column> >= :window_start
  AND <partition_column> < :window_end;
