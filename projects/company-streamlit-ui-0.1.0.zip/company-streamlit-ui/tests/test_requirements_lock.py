from pathlib import Path
import re


def test_all_250_requirements_are_present():
    text = Path("docs/FROZEN_REQUIREMENTS.md").read_text(encoding="utf-8")
    ids = re.findall(r"\*\*(\d{3})\*\*", text)
    assert ids == [f"{i:03d}" for i in range(1, 251)]
