from pathlib import Path

from company_ui.cli import build_parser


def test_cli_parser_supports_expected_commands():
    parser = build_parser()
    assert parser.parse_args(["init", "."]).command == "init"
    assert parser.parse_args(["doctor", "."]).command == "doctor"
    assert parser.parse_args(["check", ".", "--strict"]).strict is True


def test_assets_are_packaged():
    assets = Path("src/company_ui/assets")
    for name in [
        "config.toml",
        "AGENTS.md",
        "opencode.json",
        "UI_RULES.md",
        "COMPONENT_SELECTION.md",
        "PAGE_ARCHETYPES.md",
        "UI_REVIEW_CHECKLIST.md",
        "FROZEN_REQUIREMENTS.md",
    ]:
        assert (assets / name).exists(), name


def test_opencode_commands_are_packaged():
    commands = Path("src/company_ui/assets/commands")
    for name in ["ui-build.md", "ui-review.md", "ui-new-app.md"]:
        assert (commands / name).exists(), name
