from company_ui.tokens import TOKENS


def test_design_limits_are_frozen():
    assert TOKENS.max_tabs == 6
    assert TOKENS.max_kpis == 5
    assert TOKENS.max_content_columns == 4
    assert TOKENS.top_nav_max_destinations == 5
    assert TOKENS.page_width_px["standard"] < TOKENS.page_width_px["wide"]
