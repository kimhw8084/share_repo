from pathlib import Path

from company_ui.guardrails import scan_file


def test_rejects_direct_system_primitives(tmp_path: Path):
    app = tmp_path / "bad.py"
    app.write_text(
        "import streamlit as st\n"
        "st.set_page_config(page_title='x')\n"
        "st.metric('Revenue', 1)\n"
        "st.markdown('<b>x</b>', unsafe_allow_html=True)\n",
        encoding="utf-8",
    )
    findings = scan_file(app)
    codes = {f.code for f in findings}
    assert "CUI101" in codes
    assert "CUI104" in codes


def test_accepts_company_ui_usage(tmp_path: Path):
    app = tmp_path / "good.py"
    app.write_text(
        "import company_ui as ui\n"
        "ui.bootstrap('App')\n"
        "with ui.page('standard'):\n"
        "    ui.page_header('Page')\n",
        encoding="utf-8",
    )
    assert not scan_file(app)


def test_rejects_nested_components_v1_and_direct_charting(tmp_path: Path):
    app = tmp_path / "bad_components.py"
    app.write_text(
        "import streamlit as st\n"
        "import altair as alt\n"
        "st.line_chart({'x': [1]})\n"
        "st.components.v1.html('<div>x</div>')\n",
        encoding="utf-8",
    )
    findings = scan_file(app)
    codes = {f.code for f in findings}
    assert "CUI101" in codes
    assert "CUI102" in codes
    assert "CUI108" in codes


def test_raw_hex_is_warning(tmp_path: Path):
    app = tmp_path / "bad_color.py"
    app.write_text("ACCENT = '#123456'\n", encoding="utf-8")
    findings = scan_file(app)
    assert any(f.code == "CUI107" and f.severity == "warning" for f in findings)
