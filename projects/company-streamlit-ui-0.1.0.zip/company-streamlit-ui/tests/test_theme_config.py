from pathlib import Path
import tomllib


def test_reference_theme_is_valid_toml():
    data = tomllib.loads(Path(".streamlit/config.toml").read_text(encoding="utf-8"))
    assert data["theme"]["base"] == "light"
    assert data["theme"]["baseFontSize"] == 15
    assert data["theme"]["light"]["primaryColor"]
    assert data["theme"]["dark"]["primaryColor"]
    assert data["client"]["showErrorDetails"] == "none"
