from streamlit.testing.v1 import AppTest


def test_reference_app_default_page_runs():
    at = AppTest.from_file("examples/reference_app/app.py", default_timeout=10).run()
    assert not at.exception


def test_kitchen_sink_runs():
    at = AppTest.from_file("examples/reference_app/kitchen_sink.py", default_timeout=10).run()
    assert not at.exception
