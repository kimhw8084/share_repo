---
description: Build a Streamlit feature with the mandatory company UI system
agent: build
---

Implement this Streamlit requirement end-to-end:

$ARGUMENTS

Mandatory execution contract:
1. Read the repository `AGENTS.md`, `docs/PAGE_ARCHETYPES.md`, and the single closest reference implementation under `examples/reference_app/pages/` (or the application's corresponding golden example).
2. Select the page archetype and component composition automatically. Do not ask cosmetic, layout, spacing, color, navigation-style, chart-style, or component-style questions.
3. Preserve/clarify only material business semantics, authorization, destructive effects, and data semantics when genuinely unresolved by code/context.
4. Use `company_ui` system-owned primitives. Do not add app-level CSS/HTML/JS, raw colors, Components v1, private DOM selectors, or local visual primitives.
5. Implement loading, empty, no-results, permission, configuration, and failure states where relevant.
6. Add/update focused tests.
7. Run `company-ui check . --strict` and relevant tests.
8. Render/inspect the affected Streamlit page. Fix visual hierarchy, density, clipping, action clarity, and responsive problems before completion.
9. Report what changed and any material limitation only after verification.
