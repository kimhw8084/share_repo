---
description: Create a new Streamlit app from a product requirement using the company UI system
agent: build
---

Create the Streamlit application described below using the mandatory company UI system:

$ARGUMENTS

Choose the information architecture and page archetypes automatically. Use the canonical app shell, `PageSpec` navigation, semantic primitives, explicit system states, business-formatted tables/charts, and tests. Do not create local CSS/HTML/components and do not ask cosmetic/layout questions. Run the strict checker/tests and render/inspect all primary pages before completion.
