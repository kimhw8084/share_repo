---
description: Review and repair Streamlit UI against the company design system
agent: build
---

Audit and repair the following Streamlit surface while preserving business behavior:

$ARGUMENTS

Use the mandatory company UI contract. Identify the closest page archetype/reference, replace local presentation ownership with `company_ui` primitives, remove prohibited CSS/HTML/components/colors, fix hierarchy/density/states/actions/responsiveness, run `company-ui check . --strict`, run relevant tests, render/inspect the result, and repair remaining issues. Do not ask cosmetic questions.
