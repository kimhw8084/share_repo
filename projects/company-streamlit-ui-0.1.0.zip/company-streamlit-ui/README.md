# Company Streamlit UI

A deliberately opinionated Streamlit design system for internal company applications built with AI coding agents (especially OpenCode + Llama-class models).

The package is designed to solve a specific failure mode: coding models can produce correct Streamlit code while making dozens of individually plausible UI choices that combine into inconsistent, mediocre interfaces. `company_ui` removes most of those choices.

## Non-negotiable design doctrine

- Apple-like simplicity: calm, minimal, content-first, strong hierarchy, generous whitespace, restrained color.
- Native Streamlit first. Custom components are an exception, not a default.
- No app-level CSS, raw HTML, arbitrary hex colors, private DOM selectors, or ad-hoc visual primitives.
- Use centralized theme tokens and semantic components.
- Use `st.navigation` + `st.Page` through `company_ui` for new multipage apps.
- Cosmetic/layout ambiguity is resolved by the kit. The agent must not ask the user to design the UI.
- Business behavior, destructive effects, authorization, and data semantics remain legitimate clarification points.
- The agent must render/test/check work before declaring frontend completion.

## Install

From this repository:

```bash
pip install -e ".[dev,visual]"
company-ui init /path/to/your-streamlit-app
```

Or publish the package to your internal Python index and install a pinned version:

```bash
pip install "company-streamlit-ui==0.1.0"
```

The `init` command installs the reference `.streamlit/config.toml`, `AGENTS.md`, `opencode.json`, and the mandatory UI rules into the target app repository.

## Minimal app

```python
import company_ui as ui

ui.bootstrap("Operations Console", page_icon=":material/dashboard:")

pages = [
    ui.PageSpec("Dashboard", "pages/dashboard.py", icon=":material/dashboard:", default=True),
    ui.PageSpec("Customers", "pages/customers.py", icon=":material/group:"),
]

ui.run_navigation(pages)
```

Inside a page:

```python
import streamlit as st
import company_ui as ui

with ui.page("standard"):
    ui.page_header(
        "Customers",
        "Search, review, and act on customer records.",
        primary_action=ui.ActionSpec("Create customer", key="create_customer", icon=":material/add:"),
    )

    with ui.filter_bar("customer_filters"):
        st.text_input("Search", key="customer_search")
        st.selectbox("Status", ["All", "Active", "At risk"], key="customer_status")

    with ui.section("Customers"):
        ui.data_table(df)
```

## OpenCode usage

This package includes a committed `AGENTS.md` and `opencode.json`. OpenCode supports project-level `AGENTS.md` files and additional instruction files via the `instructions` array in `opencode.json`. Commit both so every teammate and model session gets the same design contract.

OpenCode custom commands are installed by `company-ui init`:

```text
/ui-build Build a portfolio monitoring page with summary KPIs, filters, trend charts, positions table, security drill-down, and CSV export subject to the app data policy.
/ui-review pages/legacy_dashboard.py
/ui-new-app Build an operations app for triaging customer implementation risk.
```

You can also use a normal prompt; the repository rules still apply automatically.

The agent should infer page archetype, layout, navigation, hierarchy, component selection, states, responsive behavior, chart treatment, and quality checks from the kit.

## Commands

```bash
company-ui init .            # install mandatory project files
company-ui doctor .          # validate environment and project setup
company-ui check . --strict  # fail on design-system bypasses
pytest                       # unit and Streamlit AppTest checks
python scripts/visual_regression.py --update  # establish visual baselines
python scripts/visual_regression.py           # compare to baselines
```

## Reference app

Run:

```bash
streamlit run examples/reference_app/app.py
```

The reference app demonstrates dashboards, list/search, detail, forms, workflows, analytics, settings, AI assistant patterns, dialogs, filters, tables, status states, and navigation.

## Design ownership

The approved design requirements are frozen. Teams do not bypass a rule locally because a custom implementation is faster. A required deviation is a design-system change: update the package, tests, golden example, documentation, and version together.
