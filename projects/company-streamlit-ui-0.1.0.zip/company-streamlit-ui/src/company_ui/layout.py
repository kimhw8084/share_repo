from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from contextlib import contextmanager
from typing import Iterator

import streamlit as st

from .actions import button
from .tokens import TOKENS
from .types import ActionSpec


@contextmanager
def page(width: str = "standard") -> Iterator[object]:
    if width not in TOKENS.page_width_px:
        raise ValueError(f"Unknown page width {width!r}; use 'standard' or 'wide'.")
    px = TOKENS.page_width_px[width]
    outer = st.container(horizontal=True, horizontal_alignment="center", gap=None)
    inner = outer.container(width=px, key=f"cui-page-{width}")
    with inner:
        yield inner


@contextmanager
def section(
    title: str,
    description: str | None = None,
    *,
    action: ActionSpec | None = None,
    spacing_before: str = "medium",
) -> Iterator[object]:
    st.space(spacing_before)
    with st.container(horizontal=True, vertical_alignment="center", gap="small"):
        with st.container(width="stretch"):
            st.subheader(title, anchor=False)
            if description:
                st.caption(description)
        if action:
            button(action)
    body = st.container()
    with body:
        yield body


@contextmanager
def surface(
    title: str | None = None,
    subtitle: str | None = None,
    *,
    tone: str = "neutral",
    key: str | None = None,
) -> Iterator[object]:
    if tone not in TOKENS.badge_colors:
        raise ValueError(f"Unsupported surface tone: {tone}")
    box = st.container(border=True, key=key)
    with box:
        if title:
            with st.container(horizontal=True, vertical_alignment="center", gap="xsmall"):
                st.markdown(f"**{title}**")
                if tone != "neutral":
                    st.badge(tone.title(), color=TOKENS.badge_colors[tone])
        if subtitle:
            st.caption(subtitle)
        yield box


def grid(
    spec: int | Sequence[int] = 2,
    *,
    gap: str = "small",
    vertical_alignment: str = "top",
    border: bool = False,
):
    if isinstance(spec, int):
        if not 1 <= spec <= TOKENS.max_content_columns:
            raise ValueError(f"Content grids support 1-{TOKENS.max_content_columns} columns.")
    else:
        ratio = tuple(int(x) for x in spec)
        if ratio not in TOKENS.approved_column_ratios:
            raise ValueError(f"Column ratio {ratio} is not an approved layout token.")
    return st.columns(spec, gap=gap, vertical_alignment=vertical_alignment, border=border)


def tabs(labels: Sequence[str], *, key: str, default: str | None = None):
    if len(labels) > TOKENS.max_tabs:
        raise ValueError(f"Use subpages or segmented navigation above {TOKENS.max_tabs} tabs.")
    return st.tabs(labels, key=key, default=default, on_change="ignore")


def lazy_tabs(
    renderers: Mapping[str, Callable[[], None]],
    *,
    key: str,
    default: str | None = None,
) -> None:
    labels = list(renderers)
    if len(labels) > TOKENS.max_tabs:
        raise ValueError(f"Use subpages or segmented navigation above {TOKENS.max_tabs} tabs.")
    tab_containers = st.tabs(labels, key=key, default=default, on_change="rerun")
    for label, tab in zip(labels, tab_containers):
        if tab.open:
            with tab:
                renderers[label]()
