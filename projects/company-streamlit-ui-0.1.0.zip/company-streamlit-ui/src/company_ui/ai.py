from __future__ import annotations

from collections.abc import Iterable
from typing import Any

import streamlit as st


def render_chat_history(
    messages: Iterable[dict[str, Any]],
    *,
    feedback: bool = False,
    key_prefix: str = "assistant",
) -> None:
    for index, message in enumerate(messages):
        role = message.get("role", "assistant")
        content = message.get("content", "")
        avatar = message.get("avatar")
        with st.chat_message(role, avatar=avatar):
            st.markdown(str(content))
            if feedback and role == "assistant":
                st.feedback("thumbs", key=f"{key_prefix}_feedback_{index}")
