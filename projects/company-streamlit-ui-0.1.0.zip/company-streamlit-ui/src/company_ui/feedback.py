from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

import streamlit as st


def info(message: str, *, title: str | None = None):
    return st.info(message, icon=":material/info:", title=title)


def success(message: str, *, title: str | None = None):
    return st.success(message, icon=":material/check_circle:", title=title)


def warning(message: str, *, title: str | None = None):
    return st.warning(message, icon=":material/warning:", title=title)


def error(message: str, *, title: str | None = None):
    return st.error(message, icon=":material/error:", title=title)


def toast(message: str, *, tone: str = "success") -> None:
    icons = {
        "success": ":material/check_circle:",
        "info": ":material/info:",
        "warning": ":material/warning:",
        "danger": ":material/error:",
    }
    st.toast(message, icon=icons.get(tone, ":material/info:"))


@contextmanager
def loading(*, height: int | None = None) -> Iterator[None]:
    with st.skeleton(height=height):
        yield
