from __future__ import annotations

from collections.abc import Iterable

import streamlit as st

from .types import ActionSpec


def _streamlit_type(kind: str) -> str:
    if kind == "primary":
        return "primary"
    if kind == "tertiary":
        return "tertiary"
    return "secondary"


def button(action: ActionSpec, *, width: str | int = "content") -> bool:
    icon = action.icon
    help_text = action.help
    if action.kind == "destructive":
        icon = icon or ":material/delete:"
        help_text = help_text or "Destructive action"
    return st.button(
        action.label,
        key=action.key,
        help=help_text,
        on_click=action.on_click,
        args=action.args,
        kwargs=action.kwargs,
        type=_streamlit_type(action.kind),
        icon=icon,
        disabled=action.disabled,
        width=width,
        shortcut=action.shortcut,
    )


def action_bar(
    actions: Iterable[ActionSpec],
    *,
    align: str = "right",
    key: str | None = None,
) -> dict[str, bool]:
    results: dict[str, bool] = {}
    with st.container(
        key=key,
        horizontal=True,
        horizontal_alignment=align,
        vertical_alignment="center",
        gap="xsmall",
    ):
        for action in actions:
            results[action.key] = button(action)
    return results
