from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

import streamlit as st

from .tokens import TOKENS


@contextmanager
def filter_bar(key: str, *, title: str | None = None) -> Iterator[object]:
    box = st.container(border=True, key=f"cui-filter-{key}")
    with box:
        if title:
            st.caption(title)
        row = st.container(horizontal=True, vertical_alignment="bottom", gap="small")
        with row:
            yield row


@contextmanager
def advanced_filters(label: str = "More filters") -> Iterator[object]:
    with st.popover(label, icon=":material/tune:"):
        yield


def active_filter_summary(filters: dict[str, object]) -> None:
    active = [(k, v) for k, v in filters.items() if v not in (None, "", [], (), "All")]
    if not active:
        return
    with st.container(horizontal=True, gap="xsmall"):
        st.caption("Active")
        for key, value in active:
            st.badge(f"{key}: {value}", color=TOKENS.badge_colors["neutral"])
