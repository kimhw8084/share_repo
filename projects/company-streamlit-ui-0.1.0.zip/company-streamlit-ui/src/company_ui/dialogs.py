from __future__ import annotations

from collections.abc import Callable
from typing import Any

import streamlit as st


def dialog(
    title: str,
    *,
    width: str = "small",
    dismissible: bool = True,
    icon: str | None = None,
    on_dismiss: str | Callable[..., Any] = "ignore",
):
    return st.dialog(title, width=width, dismissible=dismissible, icon=icon, on_dismiss=on_dismiss)


def confirm_dialog(
    title: str,
    message: str,
    *,
    confirm_label: str,
    on_confirm: Callable[[], Any],
    confirm_icon: str = ":material/check:",
    destructive: bool = False,
    cancel_label: str = "Cancel",
) -> None:
    @st.dialog(title, width="small", dismissible=True, icon=":material/warning:" if destructive else None)
    def _confirm() -> None:
        st.write(message)
        with st.container(horizontal=True, horizontal_alignment="right", gap="xsmall"):
            if st.button(cancel_label, type="tertiary", key="cui_confirm_cancel"):
                st.rerun()
            if st.button(
                confirm_label,
                type="secondary" if destructive else "primary",
                icon=":material/delete:" if destructive else confirm_icon,
                key="cui_confirm_accept",
            ):
                on_confirm()
                st.rerun()

    _confirm()
