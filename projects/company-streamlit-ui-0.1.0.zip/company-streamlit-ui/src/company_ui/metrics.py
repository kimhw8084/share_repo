from __future__ import annotations

from collections.abc import Sequence

import streamlit as st

from .tokens import TOKENS
from .types import MetricSpec


def metric_card(metric: MetricSpec) -> None:
    st.metric(
        metric.label,
        metric.value,
        metric.delta,
        delta_color=metric.delta_color,
        help=metric.help,
        border=True,
        chart_data=metric.chart_data,
        chart_type=metric.chart_type,
        delta_description=metric.delta_description,
    )


def metric_row(metrics: Sequence[MetricSpec]) -> None:
    if not metrics:
        return
    if len(metrics) > TOKENS.max_kpis:
        raise ValueError(f"A KPI row supports at most {TOKENS.max_kpis} metrics.")
    cols = st.columns(len(metrics), gap="small")
    for col, metric in zip(cols, metrics):
        with col:
            metric_card(metric)
