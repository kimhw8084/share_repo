from __future__ import annotations

import ast
import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class Finding:
    path: Path
    line: int
    code: str
    severity: str
    message: str


# These Streamlit primitives are intentionally wrapped by company_ui so visual and
# interaction decisions remain centrally governed. Add a company_ui primitive rather
# than bypassing this list in application code.
SYSTEM_OWNED = {
    "set_page_config": "Use company_ui.bootstrap().",
    "navigation": "Use company_ui.run_navigation().",
    "Page": "Use company_ui.PageSpec with company_ui.run_navigation().",
    "metric": "Use company_ui.metric_card()/metric_row().",
    "dataframe": "Use company_ui.data_table().",
    "table": "Use company_ui.data_table().",
    "data_editor": "Use company_ui.data_editor().",
    "tabs": "Use company_ui.tabs()/lazy_tabs().",
    "dialog": "Use company_ui.dialog()/confirm_dialog().",
    "columns": "Use company_ui.grid().",
    "line_chart": "Use company_ui.line_chart()/auto_chart().",
    "bar_chart": "Use company_ui.bar_chart()/auto_chart().",
    "area_chart": "Add/extend an approved company_ui chart primitive.",
    "scatter_chart": "Use company_ui.scatter_chart()/auto_chart().",
    "altair_chart": "Keep Altair rendering inside company_ui.charts.",
    "plotly_chart": "Plotly is not an approved app-level rendering path.",
    "pyplot": "Matplotlib rendering is not an approved app-level rendering path.",
    "vega_lite_chart": "Keep Vega/Altair rendering inside company_ui.charts.",
}

HEX_RE = re.compile(r"#[0-9a-fA-F]{6}\b")


def _attr_path(node: ast.AST) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        parent = _attr_path(node.value)
        return f"{parent}.{node.attr}" if parent else node.attr
    return None


def scan_file(path: Path) -> list[Finding]:
    findings: list[Finding] = []
    try:
        text = path.read_text(encoding="utf-8")
        tree = ast.parse(text, filename=str(path))
    except (UnicodeDecodeError, SyntaxError) as exc:
        findings.append(
            Finding(
                path,
                getattr(exc, "lineno", 1) or 1,
                "CUI000",
                "error",
                f"Cannot parse Python file: {exc}",
            )
        )
        return findings

    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            path_name = _attr_path(node.func)
            if path_name and path_name.startswith("st."):
                name = path_name.rsplit(".", 1)[-1]
                if name in SYSTEM_OWNED and path_name == f"st.{name}":
                    findings.append(
                        Finding(
                            path,
                            node.lineno,
                            "CUI101",
                            "error",
                            f"Direct st.{name} is system-owned. {SYSTEM_OWNED[name]}",
                        )
                    )
                if path_name == "st.html":
                    findings.append(
                        Finding(
                            path,
                            node.lineno,
                            "CUI103",
                            "error",
                            "App-level st.html is prohibited; add a system primitive instead.",
                        )
                    )
                if path_name == "st.markdown":
                    for kw in node.keywords:
                        if (
                            kw.arg == "unsafe_allow_html"
                            and isinstance(kw.value, ast.Constant)
                            and kw.value.value is True
                        ):
                            findings.append(
                                Finding(
                                    path,
                                    node.lineno,
                                    "CUI104",
                                    "error",
                                    "unsafe_allow_html=True is prohibited.",
                                )
                            )
                if path_name.startswith("st.components.v1"):
                    findings.append(
                        Finding(
                            path,
                            node.lineno,
                            "CUI102",
                            "error",
                            "Components v1 is prohibited for new work; central custom components must use Components v2.",
                        )
                    )

        if isinstance(node, (ast.Import, ast.ImportFrom)):
            names: list[str] = []
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif node.module:
                names = [node.module]
                if node.module == "streamlit.components" and any(alias.name == "v1" for alias in node.names):
                    findings.append(
                        Finding(
                            path,
                            node.lineno,
                            "CUI102",
                            "error",
                            "Components v1 is prohibited for new work.",
                        )
                    )
            for name in names:
                if ".components.v1" in name:
                    findings.append(
                        Finding(
                            path,
                            node.lineno,
                            "CUI102",
                            "error",
                            "Components v1 is prohibited for new work.",
                        )
                    )
                if name.startswith("streamlit_") and name not in {"streamlit_testing"}:
                    findings.append(
                        Finding(
                            path,
                            node.lineno,
                            "CUI105",
                            "warning",
                            f"Third-party Streamlit package {name!r} requires central allow-list approval.",
                        )
                    )
                if name == "altair" or name.startswith("altair."):
                    findings.append(
                        Finding(
                            path,
                            node.lineno,
                            "CUI108",
                            "warning",
                            "App-level Altair is a design-system bypass; add/extend company_ui.charts instead.",
                        )
                    )
                if name in {"plotly", "matplotlib", "seaborn"} or name.startswith(
                    ("plotly.", "matplotlib.", "seaborn.")
                ):
                    findings.append(
                        Finding(
                            path,
                            node.lineno,
                            "CUI109",
                            "warning",
                            f"App-level visualization library {name!r} is not approved; use company_ui.charts.",
                        )
                    )

    for i, line in enumerate(text.splitlines(), 1):
        lowered = line.lower()
        if "<style" in lowered or "</style" in lowered:
            findings.append(Finding(path, i, "CUI106", "error", "App-level CSS is prohibited."))
        if HEX_RE.search(line) and "# noqa: cui-color" not in line:
            findings.append(
                Finding(path, i, "CUI107", "warning", "Raw hex color detected; use theme/design tokens.")
            )
    return findings


def scan_path(root: Path) -> list[Finding]:
    findings: list[Finding] = []
    ignored = {".git", ".venv", "venv", "build", "dist", "__pycache__", ".tox"}
    for path in root.rglob("*.py"):
        if any(part in ignored for part in path.parts):
            continue
        try:
            rel_parts = path.relative_to(root).parts
        except ValueError:
            rel_parts = path.parts
        # The design-system implementation necessarily owns the wrapped primitives.
        # Do not exempt arbitrary application `src/` trees.
        if len(rel_parts) >= 2 and rel_parts[0] == "src" and rel_parts[1] == "company_ui":
            continue
        findings.extend(scan_file(path))
    return sorted(findings, key=lambda f: (str(f.path), f.line, f.code))
