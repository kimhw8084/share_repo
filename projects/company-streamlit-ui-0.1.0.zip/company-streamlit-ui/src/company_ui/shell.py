from __future__ import annotations

import os

import streamlit as st

from .compat import assert_supported_streamlit


def bootstrap(
    page_title: str,
    *,
    page_icon: str = ":material/apps:",
    layout: str = "wide",
    initial_sidebar_state: str = "expanded",
    environment: str | None = None,
    disable_data_export: bool | None = None,
    enforce_version: bool = True,
) -> None:
    """Initialize the shared app shell. Call only from the Streamlit entrypoint."""
    if enforce_version:
        assert_supported_streamlit()
    if disable_data_export is not None:
        st.set_option("client.disableDataExport", disable_data_export)
    st.set_page_config(
        page_title=page_title,
        page_icon=page_icon,
        layout=layout,
        initial_sidebar_state=initial_sidebar_state,
    )
    env = (environment or os.getenv("APP_ENV") or "production").strip().lower()
    if env not in {"prod", "production"}:
        color = "orange" if env in {"staging", "stage"} else "violet"
        st.sidebar.badge(f"{env.upper()} environment", color=color, icon=":material/science:")
