from __future__ import annotations

from collections.abc import Iterable

import streamlit as st

from .actions import button
from .tokens import TOKENS
from .types import ActionSpec


def status_badge(label: str, *, tone: str = "neutral", icon: str | None = None) -> None:
    color = TOKENS.badge_colors.get(tone, "gray")
    st.badge(label, color=color, icon=icon)


def page_header(
    title: str,
    description: str | None = None,
    *,
    status: tuple[str, str] | None = None,
    metadata: Iterable[str] | None = None,
    primary_action: ActionSpec | None = None,
    secondary_actions: Iterable[ActionSpec] = (),
) -> dict[str, bool]:
    results: dict[str, bool] = {}
    with st.container(horizontal=True, vertical_alignment="center", gap="small"):
        with st.container(width="stretch"):
            with st.container(horizontal=True, vertical_alignment="center", gap="xsmall"):
                st.title(title, anchor=False)
                if status:
                    status_badge(status[0], tone=status[1])
            if description:
                st.caption(description)
            if metadata:
                items = [str(x) for x in metadata if str(x).strip()]
                if items:
                    st.caption("  •  ".join(items))
        st.space("stretch")
        for action in secondary_actions:
            results[action.key] = button(action)
        if primary_action:
            results[primary_action.key] = button(primary_action)
    st.space("small")
    return results
