from __future__ import annotations

import argparse
import json
import shutil
import sys
import tomllib
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

from .compat import assert_supported_streamlit, supported_version_range
from .guardrails import scan_path


MANDATORY_DOCS = [
    "UI_RULES.md",
    "COMPONENT_SELECTION.md",
    "PAGE_ARCHETYPES.md",
    "UI_REVIEW_CHECKLIST.md",
    "FROZEN_REQUIREMENTS.md",
]
MANDATORY_COMMANDS = ["ui-build.md", "ui-review.md", "ui-new-app.md"]
MANDATORY_INSTRUCTIONS = [
    "docs/UI_RULES.md",
    "docs/COMPONENT_SELECTION.md",
    "docs/PAGE_ARCHETYPES.md",
    "docs/UI_REVIEW_CHECKLIST.md",
]


def _asset(name: str) -> Path:
    return Path(__file__).parent / "assets" / name


def _copy(src: Path, dst: Path, force: bool) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() and not force:
        print(f"skip  {dst} (already exists)")
        return
    shutil.copy2(src, dst)
    print(f"write {dst}")


def cmd_init(args: argparse.Namespace) -> int:
    root = Path(args.path).resolve()
    root.mkdir(parents=True, exist_ok=True)
    _copy(_asset("config.toml"), root / ".streamlit" / "config.toml", args.force)
    _copy(_asset("AGENTS.md"), root / "AGENTS.md", args.force)
    _copy(_asset("opencode.json"), root / "opencode.json", args.force)
    for name in MANDATORY_DOCS:
        _copy(_asset(name), root / "docs" / name, args.force)
    for name in MANDATORY_COMMANDS:
        _copy(_asset("commands") / name, root / ".opencode" / "commands" / name, args.force)
    print("\nNext: run `company-ui doctor .` then start OpenCode from this repository.")
    return 0


def _check_equal(root: Path, rel: str, asset_name: str) -> bool:
    target = root / rel
    if not target.exists():
        print(f"fail  missing {rel}")
        return False
    canonical = _asset(asset_name).read_bytes()
    if target.read_bytes() != canonical:
        print(f"fail  {rel} drifted from the frozen company_ui contract")
        return False
    print(f"ok    {rel}")
    return True


def _check_opencode(root: Path) -> bool:
    path = root / "opencode.json"
    if not path.exists():
        print("fail  missing opencode.json")
        return False
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"fail  invalid opencode.json: {exc}")
        return False
    instructions = data.get("instructions", [])
    missing = [item for item in MANDATORY_INSTRUCTIONS if item not in instructions]
    if missing:
        print(f"fail  opencode.json missing mandatory instructions: {', '.join(missing)}")
        return False
    print("ok    opencode.json mandatory instructions")
    return True


def _check_agents(root: Path) -> bool:
    path = root / "AGENTS.md"
    if not path.exists():
        print("fail  missing AGENTS.md")
        return False
    text = path.read_text(encoding="utf-8")
    required = [
        "Mandatory Streamlit UI agent contract",
        "do not ask cosmetic or layout questions",
        "company-ui check . --strict",
    ]
    missing = [phrase for phrase in required if phrase.lower() not in text.lower()]
    if missing:
        print("fail  AGENTS.md is missing mandatory company_ui contract language")
        return False
    print("ok    AGENTS.md mandatory contract")
    return True


def _check_theme(root: Path) -> bool:
    path = root / ".streamlit" / "config.toml"
    if not path.exists():
        print("fail  missing .streamlit/config.toml")
        return False
    try:
        cfg = tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        print(f"fail  invalid .streamlit/config.toml: {exc}")
        return False
    theme = cfg.get("theme", {})
    required = {
        "baseFontSize": 15,
        "baseFontWeight": 400,
        "showSidebarBorder": True,
    }
    bad = [key for key, val in required.items() if theme.get(key) != val]
    if bad or not isinstance(theme.get("chartCategoricalColors"), list):
        print("fail  .streamlit/config.toml is missing frozen typography/chart theme controls")
        return False
    print("ok    .streamlit/config.toml frozen theme controls")
    return True


def cmd_doctor(args: argparse.Namespace) -> int:
    root = Path(args.path).resolve()
    ok = True
    try:
        st_v = assert_supported_streamlit()
        print(f"ok    Streamlit {st_v} ({supported_version_range()})")
    except RuntimeError as exc:
        ok = False
        print(f"fail  {exc}")
    try:
        print(f"ok    company-streamlit-ui {version('company-streamlit-ui')}")
    except PackageNotFoundError:
        ok = False
        print("fail  company-streamlit-ui is not installed")

    ok = _check_agents(root) and ok
    ok = _check_opencode(root) and ok
    ok = _check_theme(root) and ok
    for name in MANDATORY_DOCS:
        ok = _check_equal(root, f"docs/{name}", name) and ok
    for name in MANDATORY_COMMANDS:
        ok = _check_equal(root, f".opencode/commands/{name}", f"commands/{name}") and ok
    return 0 if ok else 1


def cmd_check(args: argparse.Namespace) -> int:
    root = Path(args.path).resolve()
    findings = scan_path(root)
    if args.json:
        print(
            json.dumps(
                [
                    {
                        "path": str(f.path),
                        "line": f.line,
                        "code": f.code,
                        "severity": f.severity,
                        "message": f.message,
                    }
                    for f in findings
                ],
                indent=2,
            )
        )
    else:
        for f in findings:
            print(f"{f.severity.upper():7} {f.code} {f.path}:{f.line} {f.message}")
        if not findings:
            print("No company_ui guardrail violations found.")
    errors = sum(f.severity == "error" for f in findings)
    warnings = sum(f.severity == "warning" for f in findings)
    return 1 if errors or (args.strict and warnings) else 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="company-ui")
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init", help="Install the mandatory UI/OpenCode project files.")
    p_init.add_argument("path", nargs="?", default=".")
    p_init.add_argument("--force", action="store_true")
    p_init.set_defaults(func=cmd_init)

    p_doc = sub.add_parser("doctor", help="Validate version and frozen repository setup.")
    p_doc.add_argument("path", nargs="?", default=".")
    p_doc.set_defaults(func=cmd_doctor)

    p_check = sub.add_parser("check", help="Scan app code for design-system bypasses.")
    p_check.add_argument("path", nargs="?", default=".")
    p_check.add_argument("--strict", action="store_true", help="Treat warnings as failures.")
    p_check.add_argument("--json", action="store_true")
    p_check.set_defaults(func=cmd_check)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
