from __future__ import annotations

from collections import OrderedDict
from collections.abc import Sequence

import streamlit as st

from .tokens import TOKENS
from .types import PageSpec


def run_navigation(
    pages: Sequence[PageSpec],
    *,
    position: str = "sidebar",
    expanded: bool | int = False,
    user_roles: set[str] | frozenset[str] | None = None,
):
    allowed = [p for p in pages if p.is_visible_to(user_roles)]
    if not allowed:
        raise ValueError("No pages are available for the current role set.")
    defaults = [p for p in allowed if p.default]
    if len(defaults) > 1:
        raise ValueError("Exactly zero or one PageSpec may set default=True.")
    visible_count = sum(p.visibility == "visible" for p in allowed)
    if position == "top" and visible_count > TOKENS.top_nav_max_destinations and not any(p.group for p in allowed):
        raise ValueError(
            f"Ungrouped top navigation supports at most {TOKENS.top_nav_max_destinations} visible destinations."
        )

    built = []
    first_internal_seen = False
    for spec in allowed:
        default = spec.default
        if not defaults and not first_internal_seen and spec.visibility == "visible":
            default = True
            first_internal_seen = True
        page = st.Page(
            spec.source,
            title=spec.title,
            icon=spec.icon,
            url_path=spec.url_path,
            default=default,
            visibility=spec.visibility,
        )
        built.append((spec, page))

    if any(spec.group for spec, _ in built):
        grouped: OrderedDict[str, list] = OrderedDict()
        for spec, page_obj in built:
            grouped.setdefault(spec.group or "", []).append(page_obj)
        current = st.navigation(grouped, position=position, expanded=expanded)
    else:
        current = st.navigation([p for _, p in built], position=position, expanded=expanded)
    current.run()
    return current
