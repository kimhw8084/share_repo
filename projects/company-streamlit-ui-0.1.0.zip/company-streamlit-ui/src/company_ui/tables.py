from __future__ import annotations

from typing import Any

import streamlit as st


def currency_column(label: str, currency: str = "USD", *, help: str | None = None):
    symbol = {"USD": "$", "EUR": "€", "GBP": "£", "JPY": "¥"}.get(currency.upper(), "")
    return st.column_config.NumberColumn(label, help=help, format=f"{symbol}%.2f")


def percent_column(label: str, *, decimals: int = 1, help: str | None = None):
    return st.column_config.NumberColumn(label, help=help, format=f"%.{decimals}f%%")


def date_column(label: str, *, help: str | None = None):
    return st.column_config.DateColumn(label, help=help, format="MMM D, YYYY")


def datetime_column(label: str, *, help: str | None = None):
    return st.column_config.DatetimeColumn(label, help=help, format="MMM D, YYYY, h:mm a")


def data_table(
    data: Any,
    *,
    column_config: dict[str, Any] | None = None,
    column_order: list[str] | tuple[str, ...] | None = None,
    hide_index: bool = True,
    key: str | None = None,
    selection_mode: str | tuple[str, ...] | None = None,
    on_select: str = "ignore",
    height: str | int = "auto",
):
    kwargs: dict[str, Any] = dict(
        data=data,
        column_config=column_config,
        column_order=column_order,
        hide_index=hide_index,
        key=key,
        width="stretch",
        height=height,
    )
    if selection_mode is not None:
        kwargs["selection_mode"] = selection_mode
        kwargs["on_select"] = on_select
    return st.dataframe(**kwargs)


def data_editor(
    data: Any,
    *,
    column_config: dict[str, Any] | None = None,
    column_order: list[str] | tuple[str, ...] | None = None,
    hide_index: bool = True,
    key: str,
    num_rows: str = "fixed",
    disabled: bool | list[str] = False,
    height: str | int = "auto",
):
    return st.data_editor(
        data,
        column_config=column_config,
        column_order=column_order,
        hide_index=hide_index,
        key=key,
        num_rows=num_rows,
        disabled=disabled,
        width="stretch",
        height=height,
    )
