from __future__ import annotations

import streamlit as st

from .actions import button
from .types import ActionSpec


def _state(title: str, message: str, *, icon: str, action: ActionSpec | None = None, tone: str = "neutral") -> None:
    with st.container(border=True):
        with st.container(horizontal=True, vertical_alignment="center", gap="xsmall"):
            st.markdown(icon)
            st.subheader(title, anchor=False)
        st.caption(message)
        if tone != "neutral":
            color = {"danger": "red", "warning": "orange", "info": "blue"}.get(tone, "gray")
            st.badge(tone.title(), color=color)
        if action:
            st.space("small")
            button(action)


def empty_state(title: str = "Nothing here yet", message: str = "Create the first item to get started.", *, action: ActionSpec | None = None) -> None:
    _state(title, message, icon=":material/inbox:", action=action)


def no_results_state(message: str = "Try changing or clearing your filters.", *, action: ActionSpec | None = None) -> None:
    _state("No matches", message, icon=":material/search_off:", action=action)


def no_permission_state(message: str = "You do not have access to this content.", *, action: ActionSpec | None = None) -> None:
    _state("Access unavailable", message, icon=":material/lock:", action=action, tone="warning")


def not_configured_state(message: str = "Required configuration is missing.", *, action: ActionSpec | None = None) -> None:
    _state("Setup required", message, icon=":material/settings:", action=action, tone="info")


def system_error_state(reference_id: str | None = None, *, action: ActionSpec | None = None) -> None:
    suffix = f" Reference: `{reference_id}`." if reference_id else ""
    _state(
        "Something went wrong",
        "The application could not complete this request." + suffix + " Try again or contact support if it continues.",
        icon=":material/error:",
        action=action,
        tone="danger",
    )
