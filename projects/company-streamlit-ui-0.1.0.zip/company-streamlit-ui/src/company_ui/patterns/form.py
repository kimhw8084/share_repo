from __future__ import annotations

from collections.abc import Callable

from ..layout import page
from ..typography import page_header


def form_page(title: str, description: str, *, render_form: Callable[[], None]) -> None:
    with page("standard"):
        page_header(title, description)
        render_form()
