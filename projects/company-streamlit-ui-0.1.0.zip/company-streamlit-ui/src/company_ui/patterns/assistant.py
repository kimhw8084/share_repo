from __future__ import annotations

from collections.abc import Callable

import streamlit as st

from ..layout import page
from ..typography import page_header


def assistant_page(
    title: str,
    description: str,
    *,
    render_history: Callable[[], None],
    on_prompt: Callable[[str], None] | None = None,
    placeholder: str = "Ask a question…",
) -> None:
    with page("standard"):
        page_header(title, description)
        render_history()
        prompt = st.chat_input(placeholder)
        if prompt and on_prompt:
            on_prompt(prompt)
