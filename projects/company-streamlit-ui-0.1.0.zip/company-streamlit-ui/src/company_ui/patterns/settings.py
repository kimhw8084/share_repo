from __future__ import annotations

from collections.abc import Callable, Mapping

from ..layout import lazy_tabs, page
from ..typography import page_header


def settings_page(title: str, description: str, *, groups: Mapping[str, Callable[[], None]]) -> None:
    with page("standard"):
        page_header(title, description)
        lazy_tabs(groups, key="settings_tabs")
