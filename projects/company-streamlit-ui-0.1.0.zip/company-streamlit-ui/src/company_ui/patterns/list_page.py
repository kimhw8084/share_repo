from __future__ import annotations

from collections.abc import Callable

from ..layout import page, section
from ..typography import page_header
from ..types import ActionSpec


def list_page(
    title: str,
    description: str,
    *,
    render_filters: Callable[[], None],
    render_results: Callable[[], None],
    primary_action: ActionSpec | None = None,
) -> None:
    with page("wide"):
        page_header(title, description, primary_action=primary_action)
        render_filters()
        with section(title):
            render_results()
