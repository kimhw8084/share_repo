from __future__ import annotations

from collections.abc import Callable, Sequence

import streamlit as st

from ..layout import page, section
from ..typography import page_header


def workflow_page(
    title: str,
    description: str,
    *,
    steps: Sequence[str],
    active_step: int,
    render_step: Callable[[], None],
) -> None:
    if not 0 <= active_step < len(steps):
        raise ValueError("active_step must point to an existing workflow step")
    with page("standard"):
        page_header(title, description)
        st.progress((active_step + 1) / len(steps), text=f"Step {active_step + 1} of {len(steps)} — {steps[active_step]}")
        with section(steps[active_step]):
            render_step()
