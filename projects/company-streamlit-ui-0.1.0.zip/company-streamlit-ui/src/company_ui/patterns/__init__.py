from .analytics import analytics_page
from .assistant import assistant_page
from .dashboard import dashboard_page
from .detail import detail_page
from .form import form_page
from .list_page import list_page
from .settings import settings_page
from .workflow import workflow_page

__all__ = [
    "analytics_page", "assistant_page", "dashboard_page", "detail_page", "form_page",
    "list_page", "settings_page", "workflow_page",
]
