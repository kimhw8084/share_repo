from __future__ import annotations

from collections.abc import Callable

from ..layout import page, section
from ..typography import page_header


def analytics_page(
    title: str,
    description: str,
    *,
    render_filters: Callable[[], None],
    render_analysis: Callable[[], None],
    render_detail: Callable[[], None] | None = None,
) -> None:
    with page("wide"):
        page_header(title, description)
        render_filters()
        with section("Analysis"):
            render_analysis()
        if render_detail:
            with section("Underlying data"):
                render_detail()
