from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence

from ..layout import lazy_tabs, page, section
from ..typography import page_header
from ..types import ActionSpec


def detail_page(
    title: str,
    description: str | None,
    *,
    metadata: Sequence[str] = (),
    status: tuple[str, str] | None = None,
    render_summary: Callable[[], None] | None = None,
    tabs: Mapping[str, Callable[[], None]] | None = None,
    primary_action: ActionSpec | None = None,
    secondary_actions: Sequence[ActionSpec] = (),
) -> None:
    with page("standard"):
        page_header(
            title,
            description,
            status=status,
            metadata=metadata,
            primary_action=primary_action,
            secondary_actions=secondary_actions,
        )
        if render_summary:
            with section("Summary"):
                render_summary()
        if tabs:
            lazy_tabs(tabs, key="detail_tabs")
