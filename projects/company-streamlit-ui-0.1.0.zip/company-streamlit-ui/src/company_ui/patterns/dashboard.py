from __future__ import annotations

from collections.abc import Callable, Sequence

from ..layout import page, section
from ..metrics import metric_row
from ..typography import page_header
from ..types import ActionSpec, MetricSpec


def dashboard_page(
    title: str,
    description: str,
    *,
    metrics: Sequence[MetricSpec],
    render_filters: Callable[[], None] | None = None,
    render_overview: Callable[[], None] | None = None,
    render_details: Callable[[], None] | None = None,
    primary_action: ActionSpec | None = None,
) -> None:
    with page("wide"):
        page_header(title, description, primary_action=primary_action)
        if render_filters:
            render_filters()
        metric_row(metrics)
        if render_overview:
            with section("Overview"):
                render_overview()
        if render_details:
            with section("Details"):
                render_details()
