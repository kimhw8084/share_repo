from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Literal

ButtonKind = Literal["primary", "secondary", "tertiary", "destructive"]
Tone = Literal["neutral", "info", "success", "warning", "danger", "selected"]
PageWidth = Literal["standard", "wide"]
NavigationPosition = Literal["sidebar", "top", "hidden"]


@dataclass(frozen=True, slots=True)
class ActionSpec:
    label: str
    key: str
    kind: ButtonKind = "secondary"
    icon: str | None = None
    help: str | None = None
    disabled: bool = False
    on_click: Callable[..., Any] | None = None
    args: tuple[Any, ...] = ()
    kwargs: dict[str, Any] = field(default_factory=dict)
    shortcut: str | None = None


@dataclass(frozen=True, slots=True)
class MetricSpec:
    label: str
    value: Any
    delta: Any | None = None
    delta_color: Literal["normal", "inverse", "off"] = "normal"
    help: str | None = None
    chart_data: Any | None = None
    chart_type: Literal["line", "area", "bar"] = "line"
    delta_description: str | None = None


@dataclass(frozen=True, slots=True)
class PageSpec:
    title: str
    source: str | Callable[[], Any]
    icon: str | None = None
    url_path: str | None = None
    default: bool = False
    visibility: Literal["visible", "hidden"] = "visible"
    group: str | None = None
    roles: frozenset[str] | None = None

    def is_visible_to(self, roles: set[str] | frozenset[str] | None) -> bool:
        if self.roles is None:
            return True
        if not roles:
            return False
        return bool(self.roles.intersection(roles))
