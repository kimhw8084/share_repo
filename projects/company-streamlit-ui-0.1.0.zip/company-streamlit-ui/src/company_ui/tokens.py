from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class DesignTokens:
    spacing_px: dict[str, int]
    page_width_px: dict[str, int]
    max_tabs: int
    max_kpis: int
    max_content_columns: int
    top_nav_max_destinations: int
    badge_colors: dict[str, str]
    approved_column_ratios: frozenset[tuple[int, ...]]


TOKENS = DesignTokens(
    spacing_px={
        "xxs": 4,
        "xs": 8,
        "sm": 12,
        "md": 16,
        "lg": 24,
        "xl": 32,
        "2xl": 48,
        "3xl": 64,
    },
    page_width_px={"standard": 1120, "wide": 1440},
    max_tabs=6,
    max_kpis=5,
    max_content_columns=4,
    top_nav_max_destinations=5,
    badge_colors={
        "neutral": "gray",
        "info": "blue",
        "success": "green",
        "warning": "orange",
        "danger": "red",
        "selected": "primary",
    },
    approved_column_ratios=frozenset({
        (1, 1), (2, 1), (1, 2), (3, 2), (2, 3), (1, 1, 1), (1, 1, 1, 1)
    }),
)
