from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

MIN_VERSION = (1, 60, 0)
MAX_EXCLUSIVE = (1, 61, 0)


def _parse(v: str) -> tuple[int, int, int]:
    core = v.split("+", 1)[0].split("-", 1)[0]
    parts = core.split(".")
    nums = [int(p) if p.isdigit() else 0 for p in parts[:3]]
    while len(nums) < 3:
        nums.append(0)
    return tuple(nums)  # type: ignore[return-value]


def supported_version_range() -> str:
    return ">=1.60,<1.61"


def assert_supported_streamlit() -> str:
    try:
        current = version("streamlit")
    except PackageNotFoundError as exc:
        raise RuntimeError("Streamlit is not installed. Install company-streamlit-ui dependencies.") from exc
    parsed = _parse(current)
    if not (MIN_VERSION <= parsed < MAX_EXCLUSIVE):
        raise RuntimeError(
            f"Unsupported Streamlit {current}. company_ui 0.1.x requires {supported_version_range()}. "
            "Upgrade the design system before changing the application version range."
        )
    return current
