from __future__ import annotations

import shutil
from pathlib import Path


def packaged_config_path() -> Path:
    return Path(__file__).parent / "assets" / "config.toml"


def install_config(project_root: str | Path, *, force: bool = False) -> Path:
    root = Path(project_root)
    target = root / ".streamlit" / "config.toml"
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and not force:
        raise FileExistsError(f"{target} exists; use --force only after reviewing local settings.")
    shutil.copy2(packaged_config_path(), target)
    return target
