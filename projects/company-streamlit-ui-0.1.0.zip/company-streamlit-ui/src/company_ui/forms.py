from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

import streamlit as st


@contextmanager
def form(
    key: str,
    *,
    title: str | None = None,
    description: str | None = None,
    border: bool = True,
) -> Iterator[object]:
    if title:
        st.subheader(title, anchor=False)
    if description:
        st.caption(description)
    with st.form(key, border=border, clear_on_submit=False) as form_obj:
        yield form_obj


def form_actions(
    primary_label: str,
    *,
    primary_icon: str | None = None,
    secondary_label: str | None = None,
    secondary_icon: str | None = None,
) -> tuple[bool, bool]:
    with st.container(horizontal=True, horizontal_alignment="right", gap="xsmall"):
        secondary = False
        if secondary_label:
            secondary = st.form_submit_button(
                secondary_label, type="tertiary", icon=secondary_icon
            )
        primary = st.form_submit_button(
            primary_label, type="primary", icon=primary_icon
        )
    return primary, secondary


def required(value: object, label: str) -> str | None:
    if value is None:
        return f"{label} is required."
    if isinstance(value, str) and not value.strip():
        return f"{label} is required."
    if isinstance(value, (list, tuple, set, dict)) and not value:
        return f"{label} is required."
    return None
