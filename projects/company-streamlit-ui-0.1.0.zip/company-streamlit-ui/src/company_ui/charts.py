from __future__ import annotations

from typing import Any, Literal

import streamlit as st

ChartIntent = Literal["trend", "comparison", "distribution", "relationship", "composition"]


def line_chart(data: Any, *, x: str, y: str | list[str], color: str | None = None, height: int = 320):
    return st.line_chart(data, x=x, y=y, color=color, height=height, width="stretch")


def bar_chart(
    data: Any,
    *,
    x: str,
    y: str | list[str],
    color: str | None = None,
    horizontal: bool = False,
    sort: bool | str = True,
    height: int = 320,
):
    return st.bar_chart(
        data,
        x=x,
        y=y,
        color=color,
        horizontal=horizontal,
        sort=sort,
        height=height,
        width="stretch",
    )


def scatter_chart(data: Any, *, x: str, y: str, color: str | None = None, size: str | None = None, height: int = 320):
    return st.scatter_chart(data, x=x, y=y, color=color, size=size, height=height, width="stretch")


def auto_chart(
    data: Any,
    *,
    intent: ChartIntent,
    x: str,
    y: str | list[str],
    series: str | None = None,
    height: int = 320,
):
    """Deterministic chart selection. No pie/3D charts are emitted."""
    if intent == "trend":
        return line_chart(data, x=x, y=y, color=series, height=height)
    if intent in {"comparison", "composition", "distribution"}:
        return bar_chart(data, x=x, y=y, color=series, height=height)
    if intent == "relationship":
        if isinstance(y, list):
            if len(y) != 1:
                raise ValueError("Relationship charts require exactly one y field.")
            y = y[0]
        return scatter_chart(data, x=x, y=y, color=series, height=height)
    raise ValueError(f"Unsupported chart intent: {intent}")
