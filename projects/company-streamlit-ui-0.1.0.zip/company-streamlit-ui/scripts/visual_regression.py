#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from urllib.request import urlopen

from PIL import Image, ImageChops
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
BASELINES = ROOT / "visual" / "baselines"
ACTUAL = ROOT / "visual" / "actual"
APP = ROOT / "examples" / "reference_app" / "app.py"

PAGES = {
    "dashboard": "/dashboard",
    "customers": "/customers",
    "analytics": "/analytics",
    "workflow": "/workflow",
    "create-edit": "/create-edit",
    "assistant": "/assistant",
    "settings": "/settings",
    "admin": "/admin",
}


def wait_for_server(url: str, timeout: float = 30.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urlopen(url, timeout=1) as response:
                if response.status < 500:
                    return
        except Exception:
            time.sleep(0.25)
    raise RuntimeError(f"Streamlit server did not become ready at {url}")


def diff_ratio(expected: Path, actual: Path) -> float:
    a = Image.open(expected).convert("RGB")
    b = Image.open(actual).convert("RGB")
    if a.size != b.size:
        return 1.0
    diff = ImageChops.difference(a, b)
    histogram = diff.histogram()
    changed = sum(value for index, value in enumerate(histogram) if index % 256 != 0)
    total = a.width * a.height * 3
    return changed / max(total, 1)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--update", action="store_true", help="Replace approved baseline screenshots.")
    parser.add_argument("--threshold", type=float, default=0.003, help="Maximum changed-pixel ratio.")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()

    BASELINES.mkdir(parents=True, exist_ok=True)
    ACTUAL.mkdir(parents=True, exist_ok=True)
    base_url = f"http://127.0.0.1:{args.port}"
    env = os.environ.copy()
    env["APP_ENV"] = "production"
    process = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "streamlit",
            "run",
            str(APP),
            "--server.headless=true",
            f"--server.port={args.port}",
            "--browser.gatherUsageStats=false",
        ],
        cwd=ROOT,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.STDOUT,
    )

    failures: list[str] = []
    try:
        wait_for_server(base_url)
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, executable_path=os.getenv("CHROMIUM_PATH") or None)
            page = browser.new_page(viewport={"width": 1440, "height": 1100}, device_scale_factor=1)
            for name, path in PAGES.items():
                page.goto(base_url + path, wait_until="networkidle")
                page.wait_for_timeout(800)
                actual = ACTUAL / f"{name}.png"
                page.screenshot(path=str(actual), full_page=True)
                baseline = BASELINES / f"{name}.png"
                if args.update:
                    baseline.write_bytes(actual.read_bytes())
                    print(f"updated {baseline.relative_to(ROOT)}")
                elif not baseline.exists():
                    failures.append(f"Missing baseline {baseline.relative_to(ROOT)}; run with --update after approval.")
                else:
                    ratio = diff_ratio(baseline, actual)
                    print(f"{name:16} diff={ratio:.4%}")
                    if ratio > args.threshold:
                        failures.append(f"{name}: visual diff {ratio:.4%} exceeds {args.threshold:.4%}")
            browser.close()
    finally:
        if process.poll() is None:
            process.send_signal(signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()

    if failures:
        for failure in failures:
            print("FAIL", failure)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
