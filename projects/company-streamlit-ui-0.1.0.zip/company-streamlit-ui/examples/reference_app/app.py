import company_ui as ui

ui.bootstrap("Northstar Operations", page_icon=":material/space_dashboard:")

pages = [
    ui.PageSpec("Dashboard", "pages/dashboard.py", icon=":material/dashboard:", url_path="dashboard", default=True, group="Workspace"),
    ui.PageSpec("Customers", "pages/customers.py", icon=":material/group:", url_path="customers", group="Workspace"),
    ui.PageSpec("Analytics", "pages/analytics.py", icon=":material/monitoring:", url_path="analytics", group="Workspace"),
    ui.PageSpec("Workflow", "pages/workflow.py", icon=":material/checklist:", url_path="workflow", group="Workspace"),
    ui.PageSpec("Create / edit", "pages/create_edit.py", icon=":material/edit_square:", url_path="create-edit", group="Workspace"),
    ui.PageSpec("Assistant", "pages/assistant.py", icon=":material/auto_awesome:", url_path="assistant", group="Tools"),
    ui.PageSpec("Settings", "pages/settings.py", icon=":material/settings:", url_path="settings", group="Tools"),
    ui.PageSpec("Admin", "pages/admin.py", icon=":material/admin_panel_settings:", url_path="admin", group="Tools"),
    ui.PageSpec("Customer detail", "pages/customer_detail.py", icon=":material/person:", url_path="customer", visibility="hidden"),
]

ui.run_navigation(pages, position="sidebar", expanded=True)
