import pandas as pd
import streamlit as st
import company_ui as ui

ui.bootstrap("Company UI kitchen sink", page_icon=":material/widgets:")

with ui.page("wide"):
    ui.page_header(
        "Component reference",
        "Approved primitives shown together for fast agent and human reference.",
        status=("Reference", "neutral"),
        primary_action=ui.ActionSpec("Primary action", key="ks_primary", kind="primary"),
        secondary_actions=[ui.ActionSpec("Secondary", key="ks_secondary")],
    )

    with ui.section("Metrics"):
        ui.metric_row([
            ui.MetricSpec("Revenue", "$4.8M", "+8%", chart_data=[3.8, 4.0, 4.2, 4.5, 4.8]),
            ui.MetricSpec("Customers", "128", "+6"),
            ui.MetricSpec("Risk", "$540K", "+$80K", delta_color="inverse"),
        ])

    with ui.section("Surfaces and states"):
        a, b = ui.grid((1, 1))
        with a:
            with ui.surface("Neutral surface", "Use only for a meaningful boundary."):
                st.write("Content")
        with b:
            ui.not_configured_state("Connect the service before this feature can run.")

    with ui.section("Filters"):
        with ui.filter_bar("ks"):
            st.text_input("Search", key="ks_search")
            st.selectbox("Status", ["All", "Active", "Paused"], key="ks_status")
            with ui.advanced_filters():
                st.multiselect("Region", ["Americas", "EMEA", "APAC"], key="ks_region")

    with ui.section("Table"):
        df = pd.DataFrame({"Customer": ["Aperture", "Blue Oak"], "ARR": [1280000, 620000], "Growth": [8, -12]})
        ui.data_table(df, column_config={"ARR": ui.currency_column("ARR"), "Growth": ui.percent_column("Growth", decimals=0)}, key="ks_table")

    with ui.section("Feedback"):
        ui.info("Informational message")
        ui.success("Successful operation")
        ui.warning("Warning requiring attention")
