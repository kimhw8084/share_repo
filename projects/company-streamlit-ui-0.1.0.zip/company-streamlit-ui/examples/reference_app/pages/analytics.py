from datetime import date

import streamlit as st
import company_ui as ui

from data import customers, revenue_trend, segment_breakdown

with ui.page("wide"):
    ui.page_header("Revenue analytics", "Explore growth, segment mix, and account-level drivers.")

    with ui.filter_bar("analytics"):
        metric = st.segmented_control("Metric", ["ARR", "Growth"], default="ARR", key="analytics_metric")
        segment = st.multiselect("Segment", ["Enterprise", "Mid-market", "SMB"], default=["Enterprise", "Mid-market", "SMB"], key="analytics_segment")
        with ui.advanced_filters():
            st.date_input("Date range", value=(date(2026, 1, 1), date(2026, 8, 7)), key="analytics_dates")

    with ui.section("ARR trend", "Monthly recurring-revenue trajectory."):
        ui.auto_chart(revenue_trend(), intent="trend", x="month", y="arr_m", height=340)

    with ui.section("Segment contribution"):
        ui.auto_chart(segment_breakdown(), intent="comparison", x="segment", y="arr_m", height=300)

    with ui.section("Underlying accounts"):
        df = customers()
        if segment:
            df = df[df["segment"].isin(segment)]
        ui.data_table(
            df,
            column_config={"arr": ui.currency_column("ARR"), "growth": ui.percent_column("Growth", decimals=0), "updated_at": ui.datetime_column("Updated")},
            key="analytics_accounts",
        )
