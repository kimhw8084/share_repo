import streamlit as st
import company_ui as ui

with ui.page("standard"):
    ui.page_header("Create customer", "Add a customer record with the minimum information needed to start work.")

    with ui.form("create_customer_form", title="Customer details", description="Fields marked by business rules must be completed before creation."):
        name = st.text_input("Customer name", key="create_name")
        domain = st.text_input("Company domain", placeholder="example.com", key="create_domain")
        left, right = ui.grid((1, 1))
        with left:
            segment = st.selectbox("Segment", ["Enterprise", "Mid-market", "SMB"], key="create_segment")
        with right:
            owner = st.selectbox("Owner", ["Maya Patel", "Alex Chen", "Jordan Rivera"], key="create_owner")
        arr = st.number_input("Annual recurring revenue", min_value=0, step=1000, key="create_arr")
        notes = st.text_area("Internal notes", key="create_notes")
        submitted, cancelled = ui.form_actions("Create customer", primary_icon=":material/person_add:", secondary_label="Cancel")

    if submitted:
        errors = [x for x in [ui.required(name, "Customer name"), ui.required(domain, "Company domain")] if x]
        if errors:
            for message in errors:
                ui.error(message)
        else:
            ui.success(f"{name} is ready to be created in the backend service.", title="Validated")
    if cancelled:
        ui.toast("No changes saved", tone="info")
