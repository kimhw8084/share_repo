import streamlit as st
import company_ui as ui

if "workflow_step" not in st.session_state:
    st.session_state.workflow_step = 0

steps = ["Upload", "Validate", "Map fields", "Review"]
step = st.session_state.workflow_step

with ui.page("standard"):
    ui.page_header("Import customers", "Upload and validate customer records before they are committed.")
    st.progress((step + 1) / len(steps), text=f"Step {step + 1} of {len(steps)} — {steps[step]}")

    with ui.section(steps[step]):
        if step == 0:
            st.file_uploader("Customer file", type=["csv", "xlsx"], key="workflow_file")
            st.caption("Maximum 20 MB. CSV or XLSX.")
        elif step == 1:
            ui.success("File structure is valid.", title="Validation complete")
            st.checkbox("12 rows contain optional blank phone numbers", value=True, disabled=True)
        elif step == 2:
            st.selectbox("Customer name", ["company_name", "name", "customer"], key="map_name")
            st.selectbox("Annual recurring revenue", ["arr", "annual_value", "revenue"], key="map_arr")
        else:
            ui.info("128 customers will be created. 7 existing records will be updated.", title="Ready to import")

    actions = []
    if step > 0:
        actions.append(ui.ActionSpec("Back", key="workflow_back", kind="tertiary", icon=":material/arrow_back:"))
    if step < len(steps) - 1:
        actions.append(ui.ActionSpec("Continue", key="workflow_next", kind="primary", icon=":material/arrow_forward:"))
    else:
        actions.append(ui.ActionSpec("Import customers", key="workflow_commit", kind="primary", icon=":material/upload:"))
    result = ui.action_bar(actions)
    if result.get("workflow_back"):
        st.session_state.workflow_step -= 1
        st.rerun()
    if result.get("workflow_next"):
        st.session_state.workflow_step += 1
        st.rerun()
    if result.get("workflow_commit"):
        ui.toast("Import queued")
