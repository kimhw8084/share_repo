import streamlit as st
import company_ui as ui

from data import customers, revenue_trend, segment_breakdown

with ui.page("wide"):
    header = ui.page_header(
        "Business overview",
        "A concise view of revenue, customer health, and near-term attention areas.",
        metadata=["Updated 2 minutes ago", "Production data"],
        primary_action=ui.ActionSpec("Create report", key="dashboard_report", kind="primary", icon=":material/add_chart:"),
    )
    if header.get("dashboard_report"):
        ui.toast("Report request created")

    with ui.filter_bar("dashboard"):
        period = st.selectbox("Period", ["Last 30 days", "Quarter to date", "Year to date"], key="dash_period")
        segment = st.selectbox("Segment", ["All", "Enterprise", "Mid-market", "SMB"], key="dash_segment")
        with ui.advanced_filters():
            st.multiselect("Region", ["Americas", "EMEA", "APAC"], key="dash_region")
            st.toggle("Include paused customers", key="dash_paused")
    ui.active_filter_summary({"Period": period, "Segment": segment})

    data = customers()
    ui.metric_row([
        ui.MetricSpec("Annual recurring revenue", "$10.7M", "+8.4%", chart_data=[9.4, 9.7, 10.0, 10.3, 10.7]),
        ui.MetricSpec("Active customers", "9", "+2"),
        ui.MetricSpec("At-risk ARR", "$2.19M", "+$180K", delta_color="inverse"),
        ui.MetricSpec("Net retention", "112%", "+3.1 pp"),
    ])

    with ui.section("Revenue trajectory", "ARR trend and current segment mix."):
        left, right = ui.grid((2, 1))
        with left:
            ui.auto_chart(revenue_trend(), intent="trend", x="month", y="arr_m", height=320)
        with right:
            ui.auto_chart(segment_breakdown(), intent="comparison", x="segment", y="arr_m", height=320)

    with ui.section("Accounts needing attention", "Prioritize records with current risk signals."):
        risk = data[data["status"] == "At risk"].copy()
        ui.data_table(
            risk,
            column_order=["customer", "segment", "arr", "growth", "updated_at"],
            column_config={
                "customer": "Customer",
                "segment": "Segment",
                "arr": ui.currency_column("ARR"),
                "growth": ui.percent_column("Growth", decimals=0),
                "updated_at": ui.datetime_column("Updated"),
            },
            key="dashboard_risk_table",
        )
