import pandas as pd
import streamlit as st
import company_ui as ui

with ui.page("wide"):
    ui.page_header(
        "Administration",
        "Operational controls for authorized administrators.",
        status=("Restricted", "warning"),
    )

    with ui.section("System health"):
        ui.metric_row([
            ui.MetricSpec("Queued jobs", "14", "-6"),
            ui.MetricSpec("Failed jobs", "2", "+1", delta_color="inverse"),
            ui.MetricSpec("Median latency", "182 ms", "-24 ms"),
        ])

    with ui.section("Jobs", "Use selection plus a single action area instead of a button in every row."):
        jobs = pd.DataFrame({
            "job_id": ["J-8821", "J-8822", "J-8823"],
            "type": ["Customer import", "Risk refresh", "Report export"],
            "status": ["Running", "Failed", "Queued"],
            "owner": ["M. Patel", "System", "A. Chen"],
        })
        ui.data_table(jobs, key="admin_jobs", selection_mode="single-row", on_select="rerun")
        ui.action_bar([
            ui.ActionSpec("Retry selected", key="admin_retry", kind="secondary", icon=":material/replay:"),
            ui.ActionSpec("Cancel selected", key="admin_cancel", kind="destructive", icon=":material/cancel:"),
        ])

    with ui.section("Danger zone", "Material destructive controls are separated from routine operations."):
        with ui.surface("Purge development cache", "This does not affect production data.", tone="warning"):
            if ui.button(ui.ActionSpec("Purge cache", key="purge_cache", kind="destructive")):
                ui.confirm_dialog(
                    "Purge development cache?",
                    "Cached development artifacts will be deleted and rebuilt on demand.",
                    confirm_label="Purge cache",
                    destructive=True,
                    on_confirm=lambda: st.session_state.update(cache_purged=True),
                )
        if st.session_state.get("cache_purged"):
            ui.toast("Development cache purged")
