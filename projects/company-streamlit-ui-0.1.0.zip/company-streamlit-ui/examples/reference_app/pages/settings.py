import streamlit as st
import company_ui as ui

with ui.page("standard"):
    ui.page_header("Settings", "Manage application preferences and notification behavior.")

    def general():
        with ui.form("settings_general", title="General"):
            st.selectbox("Default landing page", ["Dashboard", "Customers", "Analytics"], key="settings_landing")
            st.toggle("Show compact table density", key="settings_compact")
            saved, _ = ui.form_actions("Save changes", primary_icon=":material/save:")
        if saved:
            ui.toast("Settings saved")

    def notifications():
        with ui.form("settings_notifications", title="Notifications"):
            st.toggle("Risk alerts", value=True, key="notify_risk")
            st.toggle("Weekly summary", value=True, key="notify_weekly")
            st.selectbox("Summary day", ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"], key="notify_day")
            saved, _ = ui.form_actions("Save changes", primary_icon=":material/save:")
        if saved:
            ui.toast("Notification settings saved")

    def access():
        ui.info("Access is managed through company identity groups.", title="Managed centrally")
        ui.data_table({"Role": ["Analyst", "Admin"], "Members": [24, 5]}, key="settings_access")

    ui.lazy_tabs({"General": general, "Notifications": notifications, "Access": access}, key="settings_tabs_ref")
