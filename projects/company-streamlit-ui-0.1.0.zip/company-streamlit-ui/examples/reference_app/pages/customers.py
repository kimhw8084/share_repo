import streamlit as st
import company_ui as ui

from data import customers

with ui.page("wide"):
    header = ui.page_header(
        "Customers",
        "Search, review, and act on customer records.",
        primary_action=ui.ActionSpec("Create customer", key="create_customer", kind="primary", icon=":material/person_add:"),
    )
    if header.get("create_customer"):
        ui.toast("Use the Create/Edit archetype for the creation flow", tone="info")

    with ui.filter_bar("customers"):
        query = st.text_input("Search", placeholder="Customer or ID", key="customers_query")
        status = st.selectbox("Status", ["All", "Active", "At risk", "Paused"], key="customers_status")
        segment = st.selectbox("Segment", ["All", "Enterprise", "Mid-market", "SMB"], key="customers_segment")
    ui.active_filter_summary({"Status": status, "Segment": segment})

    df = customers()
    if query:
        q = query.casefold()
        df = df[df["customer"].str.casefold().str.contains(q) | df["id"].str.casefold().str.contains(q)]
    if status != "All":
        df = df[df["status"] == status]
    if segment != "All":
        df = df[df["segment"] == segment]

    with ui.section("Results", f"{len(df)} customers"):
        if df.empty:
            ui.no_results_state()
        else:
            page_no = st.pagination(max(1, (len(df) + 7) // 8), key="customers_page")
            start = (page_no - 1) * 8
            view = df.iloc[start:start + 8]
            ui.data_table(
                view,
                column_order=["id", "customer", "segment", "status", "arr", "growth", "updated_at"],
                column_config={
                    "id": "ID",
                    "customer": "Customer",
                    "segment": "Segment",
                    "status": "Status",
                    "arr": ui.currency_column("ARR"),
                    "growth": ui.percent_column("Growth", decimals=0),
                    "updated_at": ui.datetime_column("Updated"),
                },
                key="customers_table",
                selection_mode="single-row",
                on_select="rerun",
            )
