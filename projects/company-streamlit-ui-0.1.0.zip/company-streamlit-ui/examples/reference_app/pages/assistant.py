import streamlit as st
import company_ui as ui

if "assistant_messages" not in st.session_state:
    st.session_state.assistant_messages = [
        {"role": "assistant", "content": "I can help analyze customer risk, revenue movement, and account activity."}
    ]

with ui.page("standard"):
    ui.page_header("Operations assistant", "Ask questions about the current operating data.", status=("Internal", "neutral"))

    ui.render_chat_history(st.session_state.assistant_messages, feedback=True, key_prefix="ops_assistant")
    prompt = st.chat_input("Ask about customers, revenue, or risk…")
    if prompt:
        st.session_state.assistant_messages.append({"role": "user", "content": prompt})
        st.session_state.assistant_messages.append({"role": "assistant", "content": "Reference implementation response. Connect this surface to your approved model/data layer."})
        st.rerun()
