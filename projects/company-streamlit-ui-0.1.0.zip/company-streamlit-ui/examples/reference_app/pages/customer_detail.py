import streamlit as st
import company_ui as ui

from data import activity, customers

record = customers().iloc[0]

with ui.page("standard"):
    header = ui.page_header(
        record["customer"],
        "Enterprise customer account",
        status=(record["status"], "success"),
        metadata=[record["id"], "Enterprise", "Owner: Maya Patel"],
        primary_action=ui.ActionSpec("Edit customer", key="detail_edit", kind="primary", icon=":material/edit:"),
        secondary_actions=[ui.ActionSpec("More", key="detail_more", kind="tertiary", icon=":material/more_horiz:")],
    )
    if header.get("detail_edit"):
        ui.toast("Edit action selected", tone="info")

    with ui.section("Summary"):
        ui.metric_row([
            ui.MetricSpec("ARR", "$1.28M", "+8%"),
            ui.MetricSpec("Health score", "91", "+4"),
            ui.MetricSpec("Open actions", "3", "-2"),
        ])

    def overview():
        left, right = ui.grid((1, 1))
        with left:
            with ui.surface("Account context"):
                st.write("Strategic healthcare account with strong product adoption and an upcoming renewal.")
        with right:
            with ui.surface("Next milestone"):
                st.write("Executive business review — September 3, 2026")

    def timeline():
        ui.data_table(activity(), column_config={"date": ui.datetime_column("Date"), "event": "Event", "owner": "Owner"})

    def commercial():
        st.write("Renewal: December 15, 2026")
        st.write("Contract term: 24 months")
        st.write("Primary package: Enterprise Plus")

    ui.lazy_tabs({"Overview": overview, "Activity": timeline, "Commercial": commercial}, key="customer_detail_tabs")
