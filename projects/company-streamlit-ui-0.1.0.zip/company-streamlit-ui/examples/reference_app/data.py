from __future__ import annotations

from datetime import date, timedelta

import pandas as pd


def customers() -> pd.DataFrame:
    rows = [
        ("C-1001", "Aperture Health", "Enterprise", "Active", 1280000, 0.08, "2026-08-06"),
        ("C-1002", "Blue Oak Logistics", "Mid-market", "At risk", 620000, -0.12, "2026-08-05"),
        ("C-1003", "Cedar Labs", "Enterprise", "Active", 980000, 0.04, "2026-08-07"),
        ("C-1004", "Delta Foods", "SMB", "Active", 210000, 0.11, "2026-08-02"),
        ("C-1005", "Evergreen Retail", "Mid-market", "At risk", 455000, -0.06, "2026-08-07"),
        ("C-1006", "Fathom Energy", "Enterprise", "Active", 1440000, 0.15, "2026-08-04"),
        ("C-1007", "Granite Works", "SMB", "Paused", 175000, -0.02, "2026-07-31"),
        ("C-1008", "Harbor Systems", "Mid-market", "Active", 510000, 0.07, "2026-08-03"),
        ("C-1009", "Indigo Media", "SMB", "Active", 260000, 0.03, "2026-08-06"),
        ("C-1010", "Juniper Finance", "Enterprise", "At risk", 1110000, -0.09, "2026-08-01"),
        ("C-1011", "Kite Manufacturing", "Mid-market", "Active", 575000, 0.05, "2026-08-07"),
        ("C-1012", "Lumen Software", "Enterprise", "Active", 1325000, 0.18, "2026-08-05"),
    ]
    df = pd.DataFrame(rows, columns=["id", "customer", "segment", "status", "arr", "growth", "updated_at"])
    df["updated_at"] = pd.to_datetime(df["updated_at"])
    return df


def revenue_trend() -> pd.DataFrame:
    start = date(2026, 1, 1)
    values = [3.8, 4.0, 4.2, 4.35, 4.6, 4.75, 4.9, 5.05]
    return pd.DataFrame({
        "month": [start + timedelta(days=30 * i) for i in range(len(values))],
        "arr_m": values,
    })


def segment_breakdown() -> pd.DataFrame:
    return pd.DataFrame({
        "segment": ["Enterprise", "Mid-market", "SMB"],
        "arr_m": [6.1, 2.9, 1.7],
    })


def activity() -> pd.DataFrame:
    return pd.DataFrame({
        "date": pd.to_datetime(["2026-08-07", "2026-08-05", "2026-08-02", "2026-07-29"]),
        "event": ["Quarterly review completed", "Risk model refreshed", "Contract amended", "Executive sponsor changed"],
        "owner": ["A. Chen", "System", "M. Patel", "J. Rivera"],
    })
