# Mandatory Streamlit UI agent contract

This repository uses the company Streamlit design system. These rules are mandatory.

## Core behavior

1. For any Streamlit frontend work, read `docs/UI_RULES.md` and the closest reference page before implementation.
2. Use `company_ui` semantic primitives and patterns. Do not create parallel visual primitives.
3. When presentation is ambiguous, resolve it from the design system. Do not ask the user cosmetic/layout questions.
4. Ask only when ambiguity materially changes business semantics, destructive effects, security/authorization, data meaning, or irreversible workflow behavior.
5. Native Streamlit is preferred. Custom components require design-system ownership and must use Components v2 for new work.
6. Never add app-level CSS, raw HTML, `unsafe_allow_html=True`, private Streamlit DOM selectors, arbitrary hex colors, or Components v1.
7. Never bypass the system because custom code is faster. A missing primitive is a design-system issue, not permission for local invention.

## Required implementation order

1. Identify the page archetype from `docs/PAGE_ARCHETYPES.md`.
2. Reuse the closest implementation in `examples/reference_app/pages/`.
3. Use `company_ui` page shell, header, sections, actions, metrics, filters, tables, charts, states, dialogs, and navigation.
4. Keep one primary action per functional region.
5. Use progressive disclosure for secondary complexity.
6. Preserve desktop-first, mobile-functional behavior; avoid layouts dependent on absolute positioning or horizontal scrolling outside tables.
7. Implement explicit loading, empty, no-results, permission, not-configured, and failure states when relevant.
8. Test functional behavior.
9. Run `company-ui check . --strict`.
10. Run the relevant tests. For meaningful UI changes, render/capture the affected page and inspect it before completion.

## Prohibited direct ownership

Application code must not directly own system-level presentation primitives such as:
- `st.set_page_config`
- `st.navigation` / `st.Page`
- `st.metric`
- `st.dataframe` / `st.data_editor` / `st.table`
- `st.dialog`
- `st.tabs`
- `st.columns` (use `company_ui.grid`)
- direct chart rendering (`st.line_chart`, `st.bar_chart`, `st.area_chart`, `st.scatter_chart`, `st.altair_chart`, `st.plotly_chart`, `st.pyplot`, `st.vega_lite_chart`)
- app-level Altair/Plotly/Matplotlib/Seaborn visual implementations
- custom CSS/HTML or custom Streamlit components

Use `company_ui` wrappers instead. Normal input widgets (`st.text_input`, `st.selectbox`, `st.multiselect`, `st.date_input`, etc.) are allowed inside approved forms/filter/layout patterns.

## Completion contract

Do not declare a Streamlit frontend task complete until:
- the requested behavior works,
- the page follows the closest archetype,
- no prohibited styling/primitive bypass exists,
- `company-ui check . --strict` passes,
- tests pass or any unavoidable limitation is stated,
- the rendered UI has been reviewed for hierarchy, spacing, density, clipping, empty/error states, and action clarity.
