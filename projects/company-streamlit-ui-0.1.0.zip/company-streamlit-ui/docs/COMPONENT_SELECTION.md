# Component selection

Use this file as a deterministic decision table. Do not ask the user to choose between these UI primitives when the intent is clear.

| Intent | Required/default primitive | Notes |
|---|---|---|
| App bootstrap | `ui.bootstrap` | Entry point only |
| Multipage navigation | `ui.PageSpec` + `ui.run_navigation` | Never call `st.navigation` directly |
| Standard page width | `ui.page("standard")` | Default for forms/details/settings |
| Wide page | `ui.page("wide")` | Analytics, dashboards, wide tables |
| Page identity/actions | `ui.page_header` | One page title, one primary page action |
| Content grouping | `ui.section` | Prefer whitespace to borders |
| True bounded surface | `ui.surface` | Do not card every section |
| 2–4 column grid | `ui.grid` | Approved ratios only |
| Peer views | `ui.tabs` | Cheap content only, max 6 |
| Expensive peer views | `ui.lazy_tabs` | Selected tab renders on rerun |
| KPI | `ui.MetricSpec` + `ui.metric_row` | Max 5 |
| Read-only data | `ui.data_table` | Business formatting via column helpers |
| Editable tabular workflow | `ui.data_editor` | Only when editing is the actual task |
| Filters | `ui.filter_bar` | Above affected content |
| Advanced filters | `ui.advanced_filters` | Secondary configuration |
| Filter chips | `ui.active_filter_summary` | When controls are collapsed/complex |
| Primary/secondary action | `ui.ActionSpec` + `ui.button` | Verb labels |
| Action group | `ui.action_bar` | Consistent alignment |
| Confirmation | `ui.confirm_dialog` | Material destructive actions only |
| General modal | `ui.dialog` | Focused tasks only |
| Empty dataset | `ui.empty_state` | Explain and provide next action |
| Filter no match | `ui.no_results_state` | Different from empty dataset |
| Authorization denial | `ui.no_permission_state` | Never imitate system failure |
| Missing setup | `ui.not_configured_state` | Provide setup path when appropriate |
| Backend/system failure | `ui.system_error_state` | No stack trace |
| Loading | `ui.loading` | Skeleton, not fake percentage |
| Transient success | `ui.toast` | Quiet confirmation |
| Trend | `ui.auto_chart(... intent="trend")` | Line |
| Category comparison | `ui.auto_chart(... intent="comparison")` | Bar |
| Composition | `ui.auto_chart(... intent="composition")` | Bar, not pie by default |
| Relationship | `ui.auto_chart(... intent="relationship")` | Scatter |
| Distribution | `ui.auto_chart(... intent="distribution")` | Bar/histogram-like |
| AI transcript | `ui.render_chat_history` | Optional response feedback |

## Input widgets

Native Streamlit input widgets remain allowed within approved form/filter/page patterns. Choose the narrowest correct widget:

- `st.text_input`: short free text / search
- `st.text_area`: longer text
- `st.selectbox`: one choice from a moderate set
- `st.multiselect`: multiple choices
- `st.segmented_control`: very small peer choice set with short labels
- `st.pills`: compact multi/single tags when spatially appropriate
- `st.date_input` / `st.datetime_input`: temporal input
- `st.toggle`: immediate boolean setting where on/off semantics are clear
- `st.file_uploader`: upload workflows with explicit validation/state

Do not replace a clear native widget merely for visual novelty.
