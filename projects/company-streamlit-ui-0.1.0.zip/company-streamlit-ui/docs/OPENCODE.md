# OpenCode + Llama usage

## Why these files exist

OpenCode loads project rules from `AGENTS.md`. It can also load additional instruction files through the `instructions` list in `opencode.json`. This kit uses both: a short high-priority contract in `AGENTS.md`, plus detailed deterministic decision files in `docs/`.

## One-time setup in an application repository

Install the package, then run:

```bash
company-ui init .
company-ui doctor .
```

Commit the generated files:

```text
AGENTS.md
opencode.json
.streamlit/config.toml
docs/UI_RULES.md
docs/COMPONENT_SELECTION.md
docs/PAGE_ARCHETYPES.md
docs/UI_REVIEW_CHECKLIST.md
```

If the repository already has an `AGENTS.md` or `opencode.json`, do not discard its existing engineering rules. Merge them while preserving the UI contract verbatim. `company-ui init` does not overwrite existing files unless `--force` is explicitly supplied.

## Recommended OpenCode workflow

Start OpenCode from the app repository. You normally do not need a UI-specific preamble because the repository rules are already loaded. `company-ui init` also installs project-local custom commands under `.opencode/commands/`:

- `/ui-build $ARGUMENTS` — implement and verify one feature/page.
- `/ui-review $ARGUMENTS` — audit and repair an existing Streamlit surface.
- `/ui-new-app $ARGUMENTS` — create a new application/information architecture from a product requirement.

These commands are intentionally terse wrappers around the full mandatory contract.

### Feature prompt

```text
Build a customer risk dashboard with global filters, four summary KPIs,
risk trend, segment breakdown, customer table, and customer drill-down.
Implement the feature end-to-end and verify it. Do not ask cosmetic/layout questions.
```

### Existing page improvement

```text
Bring this Streamlit page into full compliance with the company UI system.
Preserve business behavior. Replace local presentation patterns with approved
company_ui primitives, run the strict checker/tests, and inspect the rendered result.
```

### New app

```text
Create the Streamlit app for this product requirement using the company design system.
Select the appropriate page archetypes and navigation automatically. Build realistic
loading/empty/error states and tests. Do not create local CSS or components.
```

## Agent behavior expectation

OpenCode/Llama should inspect the closest golden page, implement using the closed vocabulary, run checks, and repair violations without asking the developer about appearance. If a requested feature cannot be expressed with approved primitives, the agent should identify the missing design-system capability and implement it centrally (with tests/docs/reference usage) rather than locally bypassing the kit.

## Model context efficiency

Do not load every reference file for every task. The `AGENTS.md` contract is always relevant. Then load:

1. `PAGE_ARCHETYPES.md` to choose structure.
2. The single closest reference page.
3. `COMPONENT_SELECTION.md` for unclear component choice.
4. `UI_REVIEW_CHECKLIST.md` during verification.

This keeps Llama context focused while retaining deterministic behavior.
