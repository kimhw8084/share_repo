# Company adoption and rollout

This kit is intended to be installed as a versioned internal dependency, not copied and edited per application.

## 1. Publish the package

Publish the wheel from `dist/` to the company's approved Python package registry. New applications pin the kit version:

```text
company-streamlit-ui==0.1.0
```

Keep Streamlit inside the supported range declared by the package. Version upgrades happen deliberately through the design-system repository.

## 2. Initialize each application repository

From the application root:

```bash
pip install "company-streamlit-ui==0.1.0"
company-ui init .
company-ui doctor .
company-ui check . --strict
```

Commit the generated OpenCode rules, Streamlit theme, UI docs, and custom commands. If the repository already has engineering rules, merge them without weakening the mandatory UI contract. Do not use `--force` over unrelated project rules without reviewing the diff.

## 3. CI gate

Every Streamlit repository should run at minimum:

```bash
company-ui doctor .
company-ui check . --strict
pytest
```

`doctor` verifies the pinned runtime, mandatory OpenCode instructions, frozen UI documents, custom commands, and critical theme controls. `check --strict` rejects application-level design-system bypasses, including raw colors and unapproved visualization paths.

## 4. OpenCode workflow

Developers should normally use one of these terse project commands:

```text
/ui-build <product requirement>
/ui-review <existing page or feature>
/ui-new-app <application requirement>
```

The model must choose presentation, layout, page archetype, chart treatment, component hierarchy, and states itself from the system. It should not ask the developer to make cosmetic decisions.

## 5. Change governance

A missing visual capability is handled in this repository:

1. Define the semantic use case.
2. Add or extend a `company_ui` primitive.
3. Add tests.
4. Add/reference it in a golden page.
5. Update the agent rules/component-selection documentation.
6. Run static, AppTest, and visual checks.
7. Release a new package version.

Application teams do not solve missing design-system capability with local CSS, HTML, JavaScript, raw colors, third-party Streamlit components, or direct visualization libraries.

## 6. Visual baseline rollout

The package ships the visual-regression harness but not pre-rendered baseline images because baselines must be captured in the company's real browser/font/runtime environment. For the first release:

```bash
python -m playwright install chromium
python scripts/visual_regression.py --update
```

Review those screenshots manually against the design doctrine, then commit the approved PNGs under `visual/baselines/`. Thereafter, CI or release validation runs:

```bash
python scripts/visual_regression.py
```

Do not update baselines merely to make a regression pass; baseline changes are design-system changes.
