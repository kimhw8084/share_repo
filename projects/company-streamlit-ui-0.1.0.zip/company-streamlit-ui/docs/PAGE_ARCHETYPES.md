# Page archetypes

The agent MUST select the closest archetype before implementation. Combine archetypes only when the user workflow genuinely combines them.

## 1. Dashboard

**Use for:** executive/operational summary, monitoring, KPI overview.

**Order:** page header → global filters → 3–5 KPIs → trend → breakdown → detailed table/action area.

**Width:** wide.

## 2. List / Search

**Use for:** customers, tickets, assets, jobs, records, catalogues.

**Order:** page header + create action → search/frequent filters → active filter summary → results count/table → pagination → no-results state.

**Width:** wide.

## 3. Record detail

**Use for:** one customer/order/ticket/asset/project.

**Order:** entity header + status + metadata + actions → summary → peer detail tabs (max 6) → audit/activity if relevant.

**Width:** standard unless data-heavy.

## 4. Create / Edit form

**Use for:** record creation/editing and configuration changes.

**Order:** header → short explanation → logical form sections → inline validation → cancel/primary submit → success/error feedback.

**Width:** standard.

## 5. Workflow / Task

**Use for:** ordered human process requiring completion stages.

**Order:** header → step/progress context → current-step content → task actions → next-step confirmation.

**Width:** standard.

## 6. Analytics / Explore

**Use for:** investigation, segmentation, trends, slice-and-dice.

**Order:** header → persistent frequent filters + advanced filters → key analytical view(s) → supporting breakdowns → underlying data.

**Width:** wide.

## 7. Settings / Configuration

**Use for:** user/team/app settings.

**Order:** header → small number of peer settings groups → settings form(s) → explicit save for material writes.

**Width:** standard.

## 8. AI Assistant / Copilot

**Use for:** conversational analysis/work assistance.

**Order:** header/context → transcript → generated artifacts/citations as needed → feedback → persistent chat input. Secondary configuration is progressively disclosed.

**Width:** standard unless paired with a large work surface.

## 9. Admin / Operations

This is a composition of list/detail/workflow patterns, not an excuse for dense bespoke UI. Prefer subpages and explicit permissions.

## Selection examples

- “Monitor portfolio exposure and drill into securities” → Dashboard + hidden Record Detail.
- “Search customers and update status” → List/Search + Record Detail or dialog for small atomic update.
- “Upload a file, validate it, map fields, submit” → Workflow.
- “Tune model thresholds and notification preferences” → Settings.
- “Analyze revenue by region and cohort” → Analytics.
