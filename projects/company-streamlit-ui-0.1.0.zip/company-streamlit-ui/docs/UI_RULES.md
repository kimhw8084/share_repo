# Mandatory UI rules

These rules are normative. **MUST**, **MUST NOT**, **SHOULD**, and **SHOULD NOT** are intentional. Local application code cannot waive them.

## Objective

Produce simple, modern, calm internal tools with an Apple-like design character while remaining fully supportable in pinned Streamlit. The system optimizes for excellent defaults and minimal prompt back-and-forth.

## Decision authority

- Presentation ambiguity MUST be resolved from this design system.
- Agents MUST NOT ask users to choose spacing, colors, border radii, card styles, tab placement, button hierarchy, chart palette, or similar cosmetic details.
- Clarification is allowed only when ambiguity changes business semantics, authorization/security, destructive effects, data meaning, or irreversible workflow behavior.
- Missing visual primitives MUST be added to the design system, not invented ad hoc in an app.

## Visual doctrine

- Content first; ornament second.
- Neutral surfaces, one primary accent, semantic status colors only.
- Generous whitespace and restrained density.
- Flat/subtle borders are preferred to shadows.
- No glassmorphism, ornamental gradients, 3D UI, decorative clutter, or saturated large surfaces.
- One dominant visual hierarchy per page.
- Progressive disclosure for secondary complexity.
- Light mode is the canonical reference; dark mode is supported from the shared theme.
- System UI typography; do not bundle proprietary Apple fonts.

## Layout

- Use `company_ui.page("standard")` for normal pages and `company_ui.page("wide")` for analytics/table-heavy pages.
- Maximum four content columns; KPI rows maximum five.
- Use approved ratios only: 1:1, 2:1, 1:2, 3:2, 2:3, equal three, equal four.
- Application code MUST use `company_ui.grid` instead of directly owning `st.columns`.
- Do not nest columns more than once.
- Desktop-first, mobile-functional. Layouts must stack/wrap naturally.
- Avoid horizontal scrolling except where tabular data requires it.
- Avoid fixed-height scroll containers over 500px.
- Use whitespace before dividers; dividers are a last resort.

## Navigation

- New multipage apps MUST use `company_ui.PageSpec` + `company_ui.run_navigation`.
- Sidebar is the default for many destinations.
- Top navigation is for small information architectures; ungrouped top nav is capped by the kit.
- Tabs are peer views of the same object, not primary app routing.
- More than six peer tabs requires subpages or another approved information architecture.
- Hidden routable detail pages are allowed for drill-down.
- Role-based page visibility must be applied centrally in navigation.

## Page hierarchy

- Exactly one page title.
- Description immediately under the title when context is useful.
- One primary action per functional region.
- Secondary actions are secondary or tertiary.
- Status should sit near the entity/page identity.
- Breadcrumbs only for genuinely deep hierarchy.
- Every section must answer a clear user question or group a coherent task.

## Cards and surfaces

- Cards communicate a real semantic boundary; they are not default decoration.
- Do not put every section in a card.
- Avoid nested cards.
- Use `company_ui.surface` for approved bordered surfaces.

## Forms

- Use explicit submit behavior for expensive or write operations.
- Labels remain visible.
- Helper text adds meaning; it does not repeat labels.
- Validation is near the affected field.
- Preserve entered values on validation failure.
- Split long forms into logical sections.
- Destructive/irreversible impact is summarized before confirmation.

## Filters and search

- Frequently used filters are visible above affected content.
- Advanced filters use progressive disclosure.
- Active hidden filters are summarized.
- No-results state differs from no-data state.
- Expensive searches do not run on meaningless empty input.

## Tables

- Read-only tables use `company_ui.data_table`; editable workflows use `company_ui.data_editor`.
- Format business types centrally.
- Never expose raw database column names.
- Order columns by task importance.
- Hide low-value columns instead of forcing extreme width.
- Large datasets require server-side limits/pagination/query strategies.
- Data export obeys the centrally selected app-level data policy. Set it in `company_ui.bootstrap(..., disable_data_export=...)`; pages do not override it.

## Metrics and dashboards

- Use `company_ui.metric_row`/`metric_card`.
- KPI value, label, optional comparison, and compact context only.
- Dashboard hierarchy: summary → trend → breakdown → detail.
- Do not duplicate the same fact as both KPI and decorative chart.
- Color communicates semantic meaning, not merely mathematical sign.

## Charts

- Use `company_ui` chart wrappers or approved Altair extensions **inside the design-system package**. Application code MUST NOT directly render Streamlit/Altair/Plotly/Matplotlib/Seaborn charts.
- 3D charts are prohibited.
- Pie/donut charts are discouraged; use bars for most part-to-whole comparisons.
- Minimize legends/gridlines/axis decoration where redundant.
- Use centralized chart palette; no raw chart colors in app code.
- Titles should express the question or measure, not generic “Chart” labels.
- Important charts should have a table alternative where appropriate.

## States and feedback

- Explicitly distinguish loading, empty, no results, permission denied, not configured, warning, and system failure.
- Success feedback should be quiet unless user attention is required.
- Errors say what happened in user terms and what to do next.
- Never expose raw stack traces to normal users.
- Use real progress only when progress is measurable; otherwise use `company_ui.loading` / skeletons.
- Toasts are transient confirmations, not durable instructions.

## Dialogs

- Use `company_ui.dialog` / `confirm_dialog`.
- Dialogs are for focused tasks, not full pages.
- Multi-step complex workflows should usually be dedicated pages.
- Only one dialog can be open in a script run; do not construct competing dialog calls.
- Never use sidebar elements inside a dialog.

## Custom components and security

- Native Streamlit first.
- New custom components, when unavoidable, belong in the design-system package and use Streamlit Components v2.
- Components v1 are prohibited for new work.
- User input, DB content, uploaded files, query params, external content, and LLM output MUST NOT be passed as trusted HTML/CSS/JS.
- App-level `st.html`, `unsafe_allow_html=True`, raw CSS, raw JavaScript, and private DOM selectors are prohibited.
- Third-party Streamlit components require allow-list review.

## Completion

Frontend work is incomplete until functional tests, `company-ui check . --strict`, relevant AppTest coverage, and visual inspection pass.
