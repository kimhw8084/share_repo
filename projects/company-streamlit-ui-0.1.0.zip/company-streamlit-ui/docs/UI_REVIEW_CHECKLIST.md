# Mandatory UI review checklist

The agent MUST review every meaningful Streamlit frontend change against this checklist before completion.

## Structure

- [ ] Correct page archetype selected.
- [ ] Exactly one page title.
- [ ] Page width is standard or wide for a clear reason.
- [ ] One primary action per functional region.
- [ ] Sections have coherent purpose and order.
- [ ] Tabs are peer views and no more than six.
- [ ] Navigation uses company-owned wrappers.

## Visual quality

- [ ] Calm neutral surfaces; accent used primarily for interaction/selection.
- [ ] No decorative gradients, glassmorphism, heavy shadows, or card soup.
- [ ] Whitespace clearly separates hierarchy.
- [ ] Typography hierarchy is restrained and consistent.
- [ ] No arbitrary colors or styling.
- [ ] Content is scannable without being needlessly sparse.

## Responsive behavior

- [ ] No absolute positioning dependency.
- [ ] No more than four content columns.
- [ ] No deeply nested columns.
- [ ] Narrow viewport remains functional.
- [ ] Horizontal scroll is limited to data that genuinely requires it.
- [ ] Long labels/buttons do not clip.

## Interaction

- [ ] Button labels are actions/verbs.
- [ ] Destructive actions are clearly separated and confirmed when material.
- [ ] Expensive operations are not triggered accidentally on every field change.
- [ ] Hidden/advanced controls use progressive disclosure.
- [ ] Disabled actions explain non-obvious unavailability.

## Data

- [ ] Tables use business labels/formatting and intentional column order.
- [ ] Large datasets are bounded/paginated/server-filtered.
- [ ] Export behavior follows sensitivity policy.
- [ ] Chart selection matches the analytical question.
- [ ] Important chart meaning does not depend only on color.

## States

- [ ] Loading state is explicit for meaningful waits.
- [ ] Empty state exists when no data exists.
- [ ] No-results state is distinct from empty data.
- [ ] Permission-denied state is distinct from system failure.
- [ ] Configuration-missing state is explicit where relevant.
- [ ] System errors hide stack traces and provide a useful next action/reference.

## Security / maintainability

- [ ] No app-level CSS/HTML/JS.
- [ ] No `unsafe_allow_html=True`.
- [ ] No private DOM selectors.
- [ ] No new Components v1.
- [ ] No unreviewed third-party Streamlit component.
- [ ] No untrusted content is treated as component HTML/CSS/JS.

## Verification

- [ ] `company-ui check . --strict` passes.
- [ ] Relevant tests pass.
- [ ] App was rendered/inspected after the change.
- [ ] Visual baselines updated only for intentional approved changes.
