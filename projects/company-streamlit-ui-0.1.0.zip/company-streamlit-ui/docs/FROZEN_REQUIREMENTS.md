# Frozen requirements — approved baseline

All 250 questionnaire defaults were approved without exception. These are system requirements, not suggestions. A local application or agent may not negotiate them away. A change requires an intentional design-system revision with owner approval, tests, documentation and versioning.

## Mission, scope and authority

- **001** — The kit is the mandatory default for every new internal Streamlit application.
- **002** — Teams need an explicit system-level reason to deviate; local opt-out is not supported.
- **003** — The primary target is internal enterprise applications, not consumer marketing sites.
- **004** — Visual consistency generally outranks developer-specific styling preference.
- **005** — Functional clarity outranks ornamental design.
- **006** — The system covers dashboards, CRUD, analytics, AI tools, workflow, admin, operations and reporting apps.
- **007** — Highly specialized consumer-style experiences are outside the default scope.
- **008** — The system should make reasonable UI decisions automatically rather than expose style knobs.
- **009** — Apps from different teams should look recognizably related.
- **010** — The kit is a versioned internal platform, not copied starter code.

## Agent behavior and minimal-prompt objective

- **011** — OpenCode/Llama inspects the UI contract automatically before Streamlit frontend work.
- **012** — Agents implement rather than ask when a design-system default exists.
- **013** — Questions are reserved for material business, security, data-semantic or destructive ambiguities.
- **014** — Visual/layout ambiguities should almost never trigger questions.
- **015** — The kit contains deterministic mappings from user intent to page archetype.
- **016** — The agent automatically selects the appropriate page archetype.
- **017** — A structured internal UI plan/spec may be formed before implementation without burdening the user.
- **018** — Agents make explicit internal assumptions and proceed rather than ask cosmetic preference questions.
- **019** — Agents may not introduce new visual primitives when an approved primitive solves the problem.
- **020** — Generated pages must pass a machine-checkable UI checklist before completion.

## OpenCode integration

- **021** — Repository-level rules are the primary shared OpenCode instruction mechanism.
- **022** — UI instructions live in the repository so they apply to every teammate/session.
- **023** — A concise agent contract is separate from long human documentation.
- **024** — Agent rules explicitly name relevant examples and files to inspect.
- **025** — Rules use direct DO/DO NOT language, not prose-only guidance.
- **026** — Critical rules are reinforced by both instructions and component APIs/checks.
- **027** — Examples stay small enough that Llama can load only the relevant ones.
- **028** — Examples favor canonical repetition over endless customization variants.
- **029** — Semantic functions such as page_header are preferred over remembering CSS.
- **030** — Agents search/reuse the kit before attempting any new CSS, HTML or component code.

## Repository and package architecture

- **031** — The design system is distributed as an internal Python package.
- **032** — Applications use a simple import such as `import company_ui as ui`.
- **033** — Applications pin the UI kit version.
- **034** — Design tokens have one canonical source of truth.
- **035** — The standard `.streamlit/config.toml` is provided/scaffolded by the kit.
- **036** — Application-specific CSS is disallowed by default.
- **037** — The package separates semantic concerns such as layout, navigation, charts, tables and states.
- **038** — Teams extend through documented system extension points instead of forks.
- **039** — Deprecated components warn before removal and evolve through versioning.
- **040** — Component APIs use semantic parameters rather than raw visual values.

## Streamlit platform baseline

- **041** — New applications standardize on a current approved Streamlit version.
- **042** — The kit declares its supported Streamlit version range.
- **043** — Legacy applications use compatibility/migration rather than forcing new APIs backward.
- **044** — New multipage apps use `st.navigation` and `st.Page` through the kit rather than legacy `pages/` auto-discovery.
- **045** — Approved features are limited to APIs supported by the pinned Streamlit version.
- **046** — Experimental/private Streamlit APIs are forbidden.
- **047** — Undocumented DOM selector dependence is forbidden wherever possible.
- **048** — JavaScript injection outside approved custom components is forbidden.
- **049** — Third-party Streamlit packages require explicit allow-listing.
- **050** — System components should have native-Streamlit fallbacks when feasible.

## Core visual doctrine

- **051** — Apple-like means minimalist, calm and content-first, not copying Apple branding.
- **052** — Generous negative space is a core characteristic.
- **053** — Decorative UI without information/interaction value is avoided.
- **054** — Borders are preferred to heavy shadows.
- **055** — Gradients are rare and prohibited for ordinary application chrome.
- **056** — Glassmorphism is avoided.
- **057** — Primary page backgrounds remain visually quiet.
- **058** — Information density is moderate rather than maximal above the fold.
- **059** — Progressive disclosure hides secondary complexity until needed.
- **060** — Every page has one obvious visual hierarchy.

## Color system

- **061** — The palette is predominantly neutral with one primary accent.
- **062** — Arbitrary hex colors are prohibited in application code.
- **063** — Semantic status colors are limited and centrally defined.
- **064** — Large surfaces avoid saturated colors.
- **065** — Accent color primarily indicates interaction and selection rather than decoration.
- **066** — Charts use a centrally approved categorical palette.
- **067** — Meaning never relies exclusively on color.
- **068** — Dark mode is supported by the shared system.
- **069** — Dark mode is token/theme driven rather than reimplemented per app.
- **070** — Light mode remains the canonical reference appearance.

## Typography

- **071** — Use a system UI font stack and avoid unnecessary external font dependencies.
- **072** — Aim for an SF-Pro-like system aesthetic without bundling proprietary Apple fonts.
- **073** — Use a small fixed type scale.
- **074** — Page titles use one standardized size/weight.
- **075** — Section headings are restrained rather than oversized.
- **076** — Body copy uses a readable compact enterprise scale.
- **077** — Monospace is restricted to code and identifiers.
- **078** — Uppercase labels are rare.
- **079** — Very light font weights are avoided.
- **080** — Text hierarchy is encoded in components/theme rather than manually styled Markdown.

## Spacing, sizing and geometry

- **081** — Spacing follows a fixed token scale.
- **082** — Arbitrary margin/padding choices are prohibited.
- **083** — Cards use standardized radii.
- **084** — Controls share consistent sizing where Streamlit permits.
- **085** — Sections have more separation than elements within a section.
- **086** — Card/surface padding follows approved density patterns.
- **087** — Nested cards are generally prohibited.
- **088** — Excessive pill-shaped containers are avoided.
- **089** — Icon sizing is standardized by native components/system conventions.
- **090** — Widths and breakpoints use named layout tokens instead of arbitrary numbers.

## Global application shell

- **091** — Every application uses the canonical shell.
- **092** — The shell owns page config, theme bootstrap, navigation, shared user/environment context and global concerns.
- **093** — Pages do not independently call `st.set_page_config`.
- **094** — Normal pages have a standard maximum content width.
- **095** — Analytical pages can opt into a wider approved preset.
- **096** — Application identity is present without dominating the screen.
- **097** — Corporate branding is subtle.
- **098** — Non-production environments display a standardized environment indicator.
- **099** — Production minimizes/hides environment chrome.
- **100** — Developer/debug controls are segregated from end-user chrome.

## Navigation architecture

- **101** — Sidebar navigation is the default for applications with many destinations.
- **102** — Top navigation is reserved for small applications.
- **103** — Ungrouped top navigation is capped at roughly five top-level destinations.
- **104** — Navigation groups reflect business domains, not technical modules.
- **105** — Navigation icons are optional and used only when clear.
- **106** — Navigation order remains stable.
- **107** — Hidden routable detail pages are supported for drill-down flows.
- **108** — Role-based navigation is generated centrally from permissions/roles.
- **109** — External navigation links are explicitly distinguishable.
- **110** — Agents may not invent bespoke navigation bars.

## Page archetypes

- **111** — The kit defines a canonical Dashboard page.
- **112** — The kit defines a List/Search page.
- **113** — The kit defines a Record Detail page.
- **114** — The kit defines a Create/Edit Form page.
- **115** — The kit defines a Workflow/Task page.
- **116** — The kit defines an Analytics/Explore page.
- **117** — The kit defines a Settings/Configuration page.
- **118** — The kit defines an AI Assistant/Copilot page.
- **119** — The kit supports Admin/Operations as approved compositions.
- **120** — Every archetype has a complete golden implementation/reference.

## Page headers and hierarchy

- **121** — Every page has exactly one primary title.
- **122** — Supporting text sits directly beneath the title when needed.
- **123** — Page-level actions are aligned consistently in the header.
- **124** — There is normally at most one visually primary action per page/region.
- **125** — Secondary actions use restrained styling.
- **126** — Breadcrumbs appear only for genuinely deep navigation hierarchy.
- **127** — Record-detail pages place identifying metadata near the title.
- **128** — Status badges appear adjacent to the entity/page identity.
- **129** — Data freshness timestamps are standardized where relevant.
- **130** — Header layouts wrap responsively using supported Streamlit layout primitives.

## Sections, cards and containers

- **131** — A section primitive standardizes heading, description, spacing and optional actions.
- **132** — Cards/surfaces are used only when grouping communicates a meaningful boundary.
- **133** — Putting every section inside a card is an anti-pattern.
- **134** — Cards use flat/subtle borders instead of large shadows.
- **135** — Selectable surfaces are semantically distinct from informational surfaces.
- **136** — Cards avoid deeply nested interactive controls.
- **137** — Dividers are used sparingly.
- **138** — Surface semantics include neutral and status/selection concepts where needed.
- **139** — Whitespace is preferred over dividers when grouping remains obvious.
- **140** — Surfaces expose standardized structure rather than arbitrary HTML.

## Columns and responsive layout

- **141** — Approved column ratios are fixed and limited.
- **142** — Four columns is the normal maximum for content grids.
- **143** — KPI rows support at most five metrics.
- **144** — Narrow/mobile behavior favors stacking and wrapping.
- **145** — The target is desktop-first and mobile-functional.
- **146** — Multi-column forms are discouraged unless fields are meaningfully related.
- **147** — Critical actions never depend on hover-only affordances.
- **148** — Horizontal scrolling is a last resort except for tables/data grids.
- **149** — Grid abstractions enforce approved ratios and limits.
- **150** — Agents avoid pixel-perfect absolute positioning.

## Tabs, expanders and progressive disclosure

- **151** — Tabs represent peer views of the same conceptual object.
- **152** — Primary app routing via tabs is prohibited when pages/URLs are appropriate.
- **153** — Visible tab sets are capped at six.
- **154** — Excess peer views become subpages/approved alternative navigation.
- **155** — Expanders hold optional or secondary information, not critical primary content.
- **156** — Nested expanders are prohibited.
- **157** — Popovers are appropriate for compact secondary actions/filter configuration.
- **158** — Advanced settings use progressive disclosure rather than permanent clutter.
- **159** — Lazy/dynamic tab behavior is used for expensive content.
- **160** — Stateful disclosure uses supported Streamlit APIs rather than DOM hacks.

## Buttons and actions

- **161** — Action hierarchy is standardized into primary, secondary, tertiary and destructive semantics.
- **162** — A functional region normally has one primary CTA.
- **163** — Destructive actions do not use the normal primary emphasis treatment.
- **164** — Material destructive actions require confirmation.
- **165** — Icon-only actions require accessible labels/help.
- **166** — Button labels use specific verbs rather than vague labels like Submit where possible.
- **167** — Non-obvious disabled actions explain why they are unavailable.
- **168** — Loading behavior prevents duplicate action execution where relevant.
- **169** — Form/dialog action placement is standardized.
- **170** — Agents avoid redundant actions already expressed through selection/navigation.

## Forms and data entry

- **171** — Forms default to explicit submit semantics for writes/expensive operations.
- **172** — Field labels remain visible except for truly obvious compact controls.
- **173** — Helper text explains format/intent instead of repeating the label.
- **174** — Validation errors appear adjacent to affected fields where possible.
- **175** — Required-field behavior is consistent.
- **176** — Long forms are split into logical sections.
- **177** — Wizard/multi-step flows are an approved pattern when justified.
- **178** — Safe known defaults are pre-populated.
- **179** — Irreversible changes summarize impact before confirmation.
- **180** — Form values persist through validation failures.

## Filters, search and controls

- **181** — Page-level filters appear consistently above the content they affect.
- **182** — Frequent filters remain visible while advanced filters are progressively disclosed.
- **183** — Shareable filter state uses query parameters when that improves the workflow.
- **184** — Filter control ordering is deterministic.
- **185** — Clear/reset-all appears once filter complexity warrants it.
- **186** — Active filters are summarized when controls are collapsed.
- **187** — Global search and page filtering are treated as distinct patterns.
- **188** — Expensive searches use explicit/debounced semantics where appropriate.
- **189** — Empty search values avoid unnecessary backend calls.
- **190** — No matches is distinct from no data exists.

## Tables and structured data

- **191** — Read-only tabular display uses the system data-table primitive.
- **192** — Editable tables are reserved for genuine edit workflows.
- **193** — Common business datatypes have centralized formatting conventions.
- **194** — Currency, percentages, timestamps and identifiers use fixed formatting rules.
- **195** — Raw database column names never reach end users.
- **196** — Columns are ordered by task importance rather than source schema order.
- **197** — Wide tables hide lower-value columns intentionally where possible.
- **198** — Row-level buttons are avoided when selection plus an action area is cleaner.
- **199** — Export capability is centrally configurable based on sensitivity.
- **200** — Large datasets use server-side bounding, pagination/filtering/query strategies.

## Metrics and dashboards

- **201** — One canonical KPI/metric primitive is used.
- **202** — A KPI contains value, label, optional comparison and compact context only.
- **203** — KPI color represents business meaning, not merely numeric sign.
- **204** — Excessive KPI rows are discouraged.
- **205** — Dashboards lead with decision-relevant summary information.
- **206** — Each dashboard section answers a clear question.
- **207** — Charts do not decoratively duplicate KPI information.
- **208** — Analytical hierarchy follows summary to trend to breakdown to detail.
- **209** — Dashboard filters apply predictably unless explicitly scoped otherwise.
- **210** — Dashboard density is optimized for scanning, not widget count.

## Charts and visualization

- **211** — The kit standardizes approved chart wrappers/library behavior.
- **212** — Altair/native Streamlit charting is acceptable as the advanced/default visualization layer.
- **213** — Charts inherit centralized typography, colors and spacing.
- **214** — Redundant legends/gridlines/axis decoration are minimized.
- **215** — 3D charts are prohibited by default.
- **216** — Pie/donut charts are discouraged except rare small part-to-whole cases.
- **217** — Agents choose chart types deterministically from semantic data intent.
- **218** — Important charts have accessible tabular alternatives when appropriate.
- **219** — Unrelated accent colors are limited within a viewport.
- **220** — Chart titles communicate the measure/question rather than generic names.

## Feedback, loading and system states

- **221** — Loading, success, warning, error and information patterns are standardized.
- **222** — Ordinary success uses quiet feedback rather than large banners.
- **223** — Errors state what happened in user terms and the next useful action.
- **224** — Raw stack traces never appear to normal users.
- **225** — Long operations show meaningful progress only when progress is measurable.
- **226** — Skeleton placeholders are preferred to fake progress where appropriate.
- **227** — Empty states explain the situation and next action when relevant.
- **228** — No permission, no results, not configured and system failure have distinct states.
- **229** — Toasts are reserved for transient confirmations.
- **230** — Blocking issues appear inline at the point preventing continuation.

## Dialogs, confirmation and overlays

- **231** — The system dialog wrapper is the canonical modal implementation.
- **232** — Dialogs are reserved for focused tasks rather than entire complex pages.
- **233** — Only destructive/high-consequence actions require confirmation by default.
- **234** — Dialog widths are standardized by task type.
- **235** — Dismissibility is chosen deliberately from semantic needs.
- **236** — Dialog action placement is consistent.
- **237** — Only one dialog is opened per Streamlit script run.
- **238** — Sidebars inside dialogs are prohibited.
- **239** — Multi-step modal workflows usually become dedicated pages.
- **240** — Dialog interactions are tested for rerun/session-state side effects.

## Custom components, security, QA and enforcement

- **241** — Native Streamlit primitives are preferred before custom components.
- **242** — New unavoidable custom components use Streamlit Components v2.
- **243** — Custom components live centrally in the design-system package.
- **244** — Untrusted/user/database/upload/query/LLM content must never become trusted component HTML/CSS/JS.
- **245** — Automated visual regression is part of the golden page/component process.
- **246** — Meaningful frontend work is rendered and visually reviewed before completion.
- **247** — Agents repair obvious design-system violations found during review.
- **248** — CI rejects prohibited raw styling, deprecated APIs and selected accessibility/quality violations.
- **249** — Design-system releases ship maintained golden examples that exercise approved primitives/patterns.
- **250** — When presentation is uncertain, follow the kit; do not ask the user to design the interface.
