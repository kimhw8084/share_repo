# Architecture

`company_ui` is intentionally a thin semantic layer over public Streamlit 1.60 APIs.

## Layering

1. **Frozen requirements** — product/design/agent constraints.
2. **Theme** — `.streamlit/config.toml`: color, typography, radius, borders, chart palette, light/dark behavior.
3. **Tokens** — numerical/semantic limits used by runtime validation.
4. **Primitives** — page width, sections, surfaces, actions, filters, metrics, tables, charts, states, dialogs.
5. **Archetypes** — canonical page composition patterns.
6. **Reference app** — executable examples that agents can copy structurally.
7. **Agent contract** — `AGENTS.md` + OpenCode instruction files.
8. **Guardrails** — static checks, tests, and visual regression.

## Why no heavy custom CSS

Modern Streamlit exposes theme configuration, widths, horizontal containers, alignment, spacing, badges, dialogs, skeletons, top/sidebar navigation, lazy tabs, and richer tables. The kit uses these public APIs so visual quality is not coupled to Streamlit's private DOM. Application code is therefore resilient to frontend implementation changes.

## Extension policy

A new component is accepted only if:

- at least two realistic product use cases require it,
- native Streamlit cannot express the interaction cleanly,
- its API is semantic rather than style-driven,
- it supports light/dark theme and accessibility,
- it has tests and a reference example,
- it does not accept unsanitized external/LLM/user content as trusted HTML/CSS/JS,
- the UI owner approves it as a system-level addition.

For unavoidable custom frontend work, prefer Streamlit Components v2 and keep it in this package.
