# Testing and quality gates

## Fast checks

```bash
ruff check src tests examples scripts
company-ui check examples/reference_app --strict
pytest
```

`pytest` uses Streamlit's native `AppTest` for headless functional smoke testing.

## Visual regression

Install visual extras and a Chromium browser available to Playwright:

```bash
pip install -e ".[dev,visual]"
playwright install chromium
python scripts/visual_regression.py --update
```

Review the baseline images, then commit them. Subsequent runs:

```bash
python scripts/visual_regression.py
```

Set `CHROMIUM_PATH` if your enterprise image provides Chromium outside Playwright's default browser install.

## Agent completion

For a meaningful frontend change, OpenCode should:

1. run the strict static checker,
2. run focused tests plus the relevant reference/app test,
3. start/render the affected app/page,
4. inspect layout and states,
5. run visual comparison where a baseline exists,
6. repair failures before reporting completion.
