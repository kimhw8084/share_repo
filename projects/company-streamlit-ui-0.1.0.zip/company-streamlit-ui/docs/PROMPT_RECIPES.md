# Minimal-prompt recipes

The repository rules are always active. Prefer short product requirements; do not restate visual requirements.

## Build a page

```text
/ui-build Customer health dashboard: 4 KPIs, trend, segment breakdown, risk table, global filters, customer drill-down.
```

## Build a workflow

```text
/ui-build File import workflow: upload CSV, validate, map columns, review changes, commit, show row-level validation failures.
```

## Build analytics

```text
/ui-build Revenue analytics by month, region and segment with filters, trend, comparison, underlying accounts and export subject to data policy.
```

## Build CRUD/list/detail

```text
/ui-build Vendors: searchable/filterable list, create/edit form, hidden detail route, status history, deactivate confirmation.
```

## Build AI assistant

```text
/ui-build Operations copilot using the existing model endpoint: transcript, citations, suggested actions, feedback, error/loading states.
```

## Repair a legacy page

```text
/ui-review pages/portfolio.py
```

## New app

```text
/ui-new-app Internal model-governance app for inventory, review workflows, model details, risk analytics and admin settings.
```

## What not to prompt

Do not specify card radius, Apple-like styling, button colors, spacing, top-vs-side navigation, tab styling, chart palette, loading treatment, or empty-state appearance unless you are intentionally changing the design system itself. Those decisions are owned by the kit.
