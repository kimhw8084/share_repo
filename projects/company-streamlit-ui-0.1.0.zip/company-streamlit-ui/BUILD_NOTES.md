# Build and validation notes — 0.1.0

## Completed in this package build

- Frozen requirements document contains exactly IDs 001–250 in order.
- Package source, examples, tests, OpenCode rules, custom commands, theme, and CI workflows compile as Python/TOML/JSON where applicable.
- The reference application passes the strict static design-system scan with zero findings.
- Static/unit tests that do not require an installed Streamlit runtime pass in the build environment.
- The wheel builds successfully and contains the mandatory project assets used by `company-ui init`.
- Current Streamlit 1.60 API usage and OpenCode rule/command integration were checked against their current official documentation during the build.

## Environment-specific verification still required

This artifact build environment does not contain Streamlit and cannot reach PyPI, so it cannot launch the reference app, execute `streamlit.testing.v1.AppTest`, or capture browser screenshots here.

The package intentionally includes those checks for the company runtime:

```bash
pip install -e ".[dev,visual]"
company-ui doctor .
company-ui check examples/reference_app --strict
pytest
python -m playwright install chromium
python scripts/visual_regression.py --update   # first approved baseline only
python scripts/visual_regression.py            # subsequent regression checks
```

The first visual baseline must be captured and manually approved in the company's actual browser/font/runtime environment. After that, `.github/workflows/ui-visual.yml` gates relevant pull requests against the committed baselines.
