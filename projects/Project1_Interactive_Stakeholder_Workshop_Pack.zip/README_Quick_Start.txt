PROJECT 1 — SAMPLING POLICY REPLAY & ROI SIMULATOR
Interactive Stakeholder Workshop — Quick Start

WHAT THIS FILE IS
A self-contained, offline HTML workshop application for a 60-minute meeting with the sampling team.

HOW TO RUN
1. Copy the HTML file to your computer.
2. Open it in a modern browser such as Chrome, Edge, Safari, or Firefox.
3. Click “Load illustrative demo” only if you want to preview the experience.
4. Before the meeting, clear the demo or edit fields to match your context.
5. During the meeting, use the left navigation and the built-in 60-minute timer.
6. Click “Save locally” periodically. Data is stored in that browser on that computer.
7. At the end, export JSON, CSV, and the text meeting summary.
8. Use “Print / PDF” to create a shareable meeting record.

IMPORTANT
• All sample values are illustrative.
• Validate every metric, ROI input, and policy interpretation with an accountable owner.
• The MVP is framed as historical replay and decision support—not autonomous sampling control.
• Browser-local storage does not synchronize across devices.
• For sensitive fab information, follow your company’s approved data-handling rules.

RECOMMENDED FACILITATION
• Use one shared screen.
• Assign one person to facilitate and one to type.
• Capture the sampling team’s exact language.
• Do not debate every issue immediately; record open concerns and assign owners.
• End with explicit decisions, data actions, and a next checkpoint.
