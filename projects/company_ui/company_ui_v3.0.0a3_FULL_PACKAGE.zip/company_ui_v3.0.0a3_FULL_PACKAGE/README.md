# Company UI 3.0.0a3 — Agent-Native Application Platform Alpha

Company UI 3.0.0a3 is the current governed v3 development baseline. It preserves the hardened v2 renderer/UI constitution while adding the v3 runtime/data/workspace architecture and an operational coding-agent application factory.

## Verified build facts
- 694/694 source regressions PASS after final setup hardening.
- Governance: 0 errors / 0 warnings.
- Static certification: 12 PASS / 1 expected sandbox warning / 0 FAIL.
- Visual integration coverage: 183/183.
- Chromium UI/UX constitution: 46/46 PASS.
- Collapsed sidebar: Support + Documentation only; both utility glyphs measured 0 px off-center.
- Agent starter matrix: 6/6 PASS.
- Wheel RECORD integrity: 404/404 hashes; zero mismatches.

## Run on macOS/Linux
```bash
chmod +x *.sh
./setup.sh
./run_lab.sh
```
Production external dependencies are installed only from `requirements.txt`; the bundled Company UI wheel is then installed with `--no-deps`. Setup owns a package-local `.venv` and rebuilds it if its interpreter does not match the selected supported Python 3.11–3.13 interpreter.

## Coding-agent workflow
```bash
company-ui create my_app --name "My App" --template analysis-workspace
cd my_app
company-ui agent-context "describe the requirement"
company-ui agent-check .
company-ui gate .
```
For target release acceptance use `company-ui gate . --release`; it is intentionally fail-closed unless the exact NiceGUI/browser runtime prerequisites are available.

Stable `3.0.0` remains blocked on target-machine NiceGUI 3.15.0 execution, live 22-route smoke, supported browser certification, and human visual-baseline approval.

## Single-file deployment
If your company publisher asks for one main Python file, select the package-root `app.py`. The standard NiceGUI launch is `python app.py`. It binds to `0.0.0.0:8080` by default and honors `COMPANY_UI_HOST`/`COMPANY_UI_PORT` or generic `HOST`/`PORT`. `run_lab.sh` remains the developer/certification launcher with preflight checks.

