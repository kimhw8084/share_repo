# Company UI 3.0.0a3 Full Package

Portable source + wheel + requirements + setup/certification tooling + coding-agent scaffolds + release evidence. Start with `00_READ_ME_FIRST.md`.

The bundled wheel is `wheel/company_ui-3.0.0a3-py3-none-any.whl`; production external dependencies are installed from `requirements.txt` using the machine's configured company package index.
