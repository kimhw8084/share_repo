# Company UI 3.0.0a3 Full Package

Portable source + wheel + requirements + setup/certification tooling + coding-agent scaffolds + release evidence. Start with `00_READ_ME_FIRST.md`.

The bundled wheel is `wheel/company_ui-3.0.0a3-py3-none-any.whl`; production external dependencies are installed from `requirements.txt` using the machine's configured company package index.

## Single-file deployment
If your company publisher asks for one main Python file, select the package-root `app.py`. The standard NiceGUI launch is `python app.py`. It binds to `0.0.0.0:8080` by default and honors `COMPANY_UI_HOST`/`COMPANY_UI_PORT` or generic `HOST`/`PORT`. `run_lab.sh` remains the developer/certification launcher with preflight checks.

