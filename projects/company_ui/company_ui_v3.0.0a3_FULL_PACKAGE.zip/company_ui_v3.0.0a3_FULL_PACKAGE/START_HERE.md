# Company UI 3.0.0a3 — Read Me First

This is the authoritative portable Company UI v3 coding-agent/application-platform alpha package.

## Current authority
- Framework: `3.0.0a3` / ALPHA. Stable promotion target: `3.0.0`.
- Production runtime dependency: `nicegui==3.15.0` from `requirements.txt`.
- Python: `>=3.11,<3.14`.
- Source regression estate: **694/694 PASS**, executed in three deterministic disjoint process-isolated batches.
- Governance: **0 errors / 0 warnings**.
- Static certification: **12 PASS / 1 expected sandbox warning / 0 FAIL**.
- Visual integration coverage: **183/183**.
- Browser-native UI/UX constitution: **46/46 PASS**.
- Coding-agent starter dogfood: **6/6 PASS**.
- Collapsed sidebar utilities: Support + Documentation only; both measured **0 px off-center** in focused Chromium evidence.

## Start on macOS/Linux
```bash
chmod +x *.sh
./setup.sh
./run_lab.sh
```
`setup.sh` verifies package checksums, selects Python 3.11–3.13, repairs/recreates an incompatible local `.venv`, installs `requirements.txt` through the configured company package index, installs the bundled Company UI wheel with `--no-deps`, verifies the exact runtime contract, and runs the 22-route runtime smoke.

For final browser certification:
```bash
./install_certification_deps.sh
./certify.sh --exhaustive
```
Do not approve the visual baseline until the rendered product has been reviewed on the target machine.

For coding agents, read `docs/V3_AGENT_DEVELOPMENT.md`, then use `company-ui create`, `company-ui agent-context`, `company-ui agent-check`, and `company-ui gate`.
## Deploy by selecting one Python file
For company publishing systems that ask for a main Python file, choose the root **`app.py`**. The normal NiceGUI launch model is simply `python app.py`; the entrypoint calls the existing Company UI live runtime and honors platform `HOST`/`PORT` variables.

