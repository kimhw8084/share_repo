# Company UI 3.0.0a3 — Single-file deployment entrypoint

Company UI's full reference application now ships a root `app.py` for company publishing systems that require one main Python file.

## Standard launch

```bash
python app.py
```

The file launches the exact existing Company UI live reference application; it does not duplicate or fork page construction, runtime middleware, operational endpoints, or NiceGUI configuration.

## Publisher contract

- Default bind: `0.0.0.0:8080`
- Host precedence: `COMPANY_UI_HOST`, then `HOST`, then `0.0.0.0`
- Port precedence: `COMPANY_UI_PORT`, then `PORT`, then `8080`
- Browser auto-open: disabled
- Invalid ports fail closed before server startup
- Bundled `source/` is inserted ahead of global packages so the selected file always launches the exact Company UI source distributed beside it
- External runtime dependency authority remains `requirements.txt` (`nicegui==3.15.0`)

`run_lab.sh` remains the developer/certification launcher because it adds environment preflight. `app.py` is the deployment/publisher entrypoint.
