# Gate Status

## Passed in the build environment
- 693/693 pytest regressions, six deterministic disjoint batches.
- Governance 0 errors / 0 warnings.
- Static certification 12 PASS / 1 expected NiceGUI-unavailable warning / 0 FAIL.
- 183/183 visual integration coverage.
- Chromium browser-native UI/UX constitution 46/46.
- Sidebar focused gate 3/3; Support and Documentation glyph center delta 0 px.
- Coding-agent application factory dogfood 6/6.
- Wheel: 405 ZIP members, 404 RECORD hashes verified, zero mismatches; isolated no-deps import PASS.

## Explicitly pending on the supported target/company environment
- Exact installed NiceGUI 3.15.0 runtime contract.
- Real 22-route server/WebSocket smoke.
- Live supported Chrome/Edge responsive/interaction/geometry/performance/screenshot matrix.
- Human approval of the visual baseline.
- Stable `3.0.0` promotion.

Never convert a pending target gate to PASS from static/source evidence alone.
