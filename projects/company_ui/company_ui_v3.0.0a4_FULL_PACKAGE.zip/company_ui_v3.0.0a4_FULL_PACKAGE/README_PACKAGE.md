# Company UI 3.0.0a4 Full Package

Authoritative portable golden-template package. Use `app.py` as the single-file company publisher entrypoint. Bundled wheel: `wheel/company_ui-3.0.0a4-py3-none-any.whl`.
