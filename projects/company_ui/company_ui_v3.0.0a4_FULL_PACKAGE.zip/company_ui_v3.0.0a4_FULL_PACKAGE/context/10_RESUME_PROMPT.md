# Resume Prompt — Company UI v3

Open `00_READ_ME_FIRST.md`, then treat this package's `source/` directory as the authoritative Company UI `3.0.0a4` baseline.

Continue actual Company UI development with a strict zero-regression policy. Do not replace the inherited v2 renderer or globally migrate existing routes merely to use v3 architecture. V3 runtime, data-session, adaptive-workspace, semantic-visualization, extension, persistence, coding-agent, and application-factory capabilities are additive unless a tested migration is materially better.

Before modifying anything, read `RELEASE_MANIFEST.json`, `PHASE_49_V300A3_SIDEBAR_UTILITY_HARDENING_REPORT.json`, `PHASE_50_V300A3_AGENT_APPLICATION_FACTORY_REPORT.json`, `BROWSER_UIUX_GATE.json`, `AGENT_DOGFOOD_REPORT.json`, and `context/20_ARCHITECTURE_STATE.md`.

Current hard source/build gates: 694/694 tests, governance 0/0, static certification 12 PASS / 1 expected environment warning / 0 FAIL, visual coverage 183/183, Chromium UI/UX 46/46, six generated starter dogfood 6/6. Installed NiceGUI 3.15.0 runtime, real 22-route live smoke, supported target browser matrix, and human visual-baseline approval remain mandatory before stable 3.0.0.


Phase 52: publisher subpath forwarding and graceful runtime-smoke shutdown are authoritative. `/visualizer` is not a framework route.
