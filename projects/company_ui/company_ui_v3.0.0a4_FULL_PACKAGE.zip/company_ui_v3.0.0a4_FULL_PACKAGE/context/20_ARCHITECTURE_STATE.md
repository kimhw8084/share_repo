# V3 Architecture State

Company UI v3 is an additive application platform over the hardened v2 renderer/design constitution. Implemented: ApplicationRuntime/WorkspaceRuntime ownership; typed transactional state and undo/redo; unified Dataset/DataSession; adaptive persistent workspace grid; semantic visual planning over certified renderers; extension registry; diagnostics; RC5 lifecycle/async/DataTable/overlay/chart hardening; coding-agent context/preflight; six governed application starters; source and live release application gates. Existing v2 routes remain the visual/behavior compatibility floor.

Agent-native workflow: `company-ui create`, `company-ui agent-context`, `company-ui agent-check`, `company-ui gate`, and target-only `company-ui gate --release`.
