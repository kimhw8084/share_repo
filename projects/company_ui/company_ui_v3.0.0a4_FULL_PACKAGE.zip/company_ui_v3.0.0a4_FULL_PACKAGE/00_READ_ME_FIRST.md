# Company UI 3.0.0a4 — Read Me First

This is the authoritative portable golden NiceGUI template/application-platform alpha package.

## Authority
- Framework: `3.0.0a4` / ALPHA; stable target `3.0.0`.
- Runtime: `nicegui==3.15.0`; Python `>=3.11,<3.14`.
- Source regressions: 698/698 PASS. Governance 0/0. Static certification 12 PASS / 1 expected sandbox warning / 0 FAIL. Visual coverage 183/183.
- Existing browser-native UI/UX constitution: 46/46 PASS; a4 contains no renderer/CSS/UI anatomy change.

## Publish one file
Choose `app.py`; standard launch is `python app.py`.

If the company publisher exposes the app below a subpath such as `/visualizer`, that path comes from the publisher, not Company UI. Prefer the publisher-provided `ROOT_PATH`/`SCRIPT_NAME`; otherwise set `COMPANY_UI_ROOT_PATH=/visualizer`. The entrypoint forwards this to NiceGUI's root-path runtime support.

## Smoke-test shutdown
The harness now performs graceful process termination; it no longer sends SIGINT, so its own cleanup should not create `asyncio.CancelledError` / `KeyboardInterrupt` tracebacks.

## Setup
```bash
chmod +x *.sh
./setup.sh
```
