from __future__ import annotations
import json, time
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path('/mnt/data/company_ui_work/v3_a3_browser_uiux')
HTML=(ROOT/'harness.html').read_text(encoding='utf-8')
CASES=[
 ('desktop_light_expanded',1440,900,'light','expanded',False),
 ('desktop_dark_compact',1440,900,'dark','compact',False),
 ('tablet_light',820,1000,'light','expanded',False),
 ('mobile_dark_reduced',390,844,'dark','expanded',True),
]
checks=[]
def add(case,key,ok,detail): checks.append({'case':case,'key':key,'status':'PASS' if ok else 'FAIL','detail':str(detail)})

with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    for name,w,h,theme,sidebar,reduced in CASES:
        page=browser.new_page(viewport={'width':w,'height':h})
        if reduced: page.emulate_media(reduced_motion='reduce')
        started=time.perf_counter()
        page.set_content(HTML, wait_until='load')
        page.evaluate("([theme,sidebar])=>{document.documentElement.dataset.theme=theme;document.documentElement.dataset.sidebar=sidebar}",[theme,sidebar])
        # Settle shell width transition when compact. Reduced-motion cases settle nearly instantly.
        page.wait_for_timeout(320 if sidebar=='compact' else 100)
        elapsed=(time.perf_counter()-started)*1000
        dims=page.evaluate("() => ({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,page:document.querySelector('.cui-page').getBoundingClientRect().width,table:document.querySelector('.demo-table-wrap').getBoundingClientRect().width,bg:getComputedStyle(document.body).backgroundColor,text:getComputedStyle(document.body).color,sideDisplay:getComputedStyle(document.querySelector('.cui-app-sidebar')).display,sideWidth:document.querySelector('.cui-app-sidebar').getBoundingClientRect().width,mainLeft:document.querySelector('main').getBoundingClientRect().left,badge:getComputedStyle(document.querySelector('.cui-environment-badge')).display,primaryH:document.querySelector('#primary').getBoundingClientRect().height,labelDisplay:getComputedStyle(document.querySelector('.cui-sidebar-footer__action-label')).display})")
        add(name,'no-horizontal-page-overflow',dims['sw']<=dims['cw']+1,f"scrollWidth={dims['sw']} clientWidth={dims['cw']}")
        add(name,'page-contained',dims['page']<=w+1,f"page={dims['page']:.1f}px viewport={w}px")
        add(name,'table-contained',dims['table']<=dims['page']+1,f"tableWrap={dims['table']:.1f}px page={dims['page']:.1f}px")
        theme_ok = ('247' in dims['bg'] and '29' in dims['text']) if theme=='light' else (('32' in dims['bg'] or '16' in dims['bg']) and ('245' in dims['text'] or '242' in dims['text']))
        add(name,'theme-resolves',theme_ok,f"bg={dims['bg']} text={dims['text']}")
        if w>=900:
            add(name,'desktop-sidebar-visible',dims['sideDisplay']!='none' and dims['sideWidth']>0,f"display={dims['sideDisplay']} width={dims['sideWidth']:.1f}px")
            if sidebar=='compact':
                add(name,'compact-footer-label-hidden',dims['labelDisplay']=='none',f"display={dims['labelDisplay']}")
                add(name,'compact-sidebar-narrower',dims['sideWidth']<120,f"width={dims['sideWidth']:.1f}px")
        else:
            add(name,'mobile-sidebar-hidden',dims['sideDisplay']=='none',f"display={dims['sideDisplay']}")
            add(name,'mobile-main-origin',abs(dims['mainLeft'])<=1.0,f"mainLeft={dims['mainLeft']:.1f}")
            if w<=480:
                add(name,'mobile-environment-badge-hidden',dims['badge']=='none',f"display={dims['badge']}")
                add(name,'mobile-touch-target',dims['primaryH']>=44,f"primary height={dims['primaryH']:.1f}px")
        # Focus by keyboard, never just JS .focus(), to exercise :focus-visible.
        page.locator('body').press('Tab')
        page.locator('body').press('Tab')
        page.locator('body').press('Tab')
        focus=page.evaluate("() => {const e=document.activeElement,s=getComputedStyle(e);return {tag:e.tagName,id:e.id,outline:s.outline,shadow:s.boxShadow}}")
        add(name,'keyboard-focus-visible',focus['tag'] in ('BUTTON','A','INPUT','SELECT') and (focus['shadow']!='none' or focus['outline']!='none'),json.dumps(focus))
        # Drawer: wait through the governed 220ms slide animation, then measure settled geometry.
        page.click('#drawerOpen')
        page.wait_for_timeout(300)
        dr=page.evaluate("() => {const r=document.querySelector('.cui-drawer').getBoundingClientRect();return {left:r.left,right:r.right,width:r.width}}")
        drawer_ok=abs(dr['right']-w)<=1.1 and dr['left']>=-1.1 and dr['width']<=w+1
        add(name,'drawer-side-slide-geometry',drawer_ok,f"left={dr['left']:.1f} right={dr['right']:.1f} width={dr['width']:.1f}")
        page.keyboard.press('Escape'); page.wait_for_timeout(30)
        active=page.evaluate("() => document.activeElement && document.activeElement.id")
        add(name,'drawer-escape-focus-restore',active=='drawerOpen','focus returned to inspector opener' if active=='drawerOpen' else f'active={active!r}')
        if reduced:
            trans=page.evaluate("() => getComputedStyle(document.querySelector('#primary')).transitionDuration")
            parts=[]
            for token in trans.split(','):
                token=token.strip()
                if token.endswith('ms'): parts.append(float(token[:-2])/1000)
                elif token.endswith('s'): parts.append(float(token[:-1]))
            add(name,'reduced-motion',bool(parts) and max(parts)<=0.0011,f'transitionDuration={trans}')
        add(name,'render-budget',elapsed<2000,f'set_content+load={elapsed:.1f}ms')
        if name=='desktop_dark_compact':
            util=page.evaluate("() => [...document.querySelectorAll('.cui-sidebar-footer__action')].map(b=>b.getAttribute('aria-label'))")
            add(name,'compact-utility-actions',util==['Support','Documentation'],f'labels={util}')
            for label,key in [('Support','compact-support-icon-centered'),('Documentation','compact-documentation-icon-centered')]:
                v=page.evaluate("label=>{const b=document.querySelector(`.cui-sidebar-footer__action[aria-label=\"${label}\"]`),i=b.querySelector('.cui-svg-icon-host');const br=b.getBoundingClientRect(),ir=i.getBoundingClientRect();return {dx:Math.abs((br.left+br.width/2)-(ir.left+ir.width/2)),dy:Math.abs((br.top+br.height/2)-(ir.top+ir.height/2))}}",label)
                add(name,key,v['dx']<=0.5 and v['dy']<=0.5,f"dx={v['dx']:.2f}px dy={v['dy']:.2f}px")
        page.screenshot(path=str(ROOT/f'{name}.png'), full_page=True)
        page.close()
    browser.close()

failed=sum(1 for x in checks if x['status']=='FAIL')
out={
 'framework_version':'3.0.0a3','gate':'browser-native-uiux-constitution','scope':'actual Company UI CSS + deterministic representative DOM; settled transition geometry; system Chromium','chromium':'/usr/bin/chromium',
 'cases':len(CASES),'checks_total':len(checks),'passed':len(checks)-failed,'failed':failed,'status':'PASS' if not failed else 'FAIL','checks':checks,
 'screenshots':[f'{c[0]}.png' for c in CASES]
}
(ROOT/'BROWSER_UIUX_GATE.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({k:out[k] for k in ('status','passed','failed','checks_total')},indent=2))
if failed:
    for x in checks:
        if x['status']=='FAIL': print('FAIL',x)
    raise SystemExit(1)
