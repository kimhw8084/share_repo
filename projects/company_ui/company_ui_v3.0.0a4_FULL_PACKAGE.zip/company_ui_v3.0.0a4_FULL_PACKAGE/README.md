# Company UI 3.0.0a4 — Golden NiceGUI Template / Agent-Native Application Platform

`3.0.0a4` is the current governed golden-template baseline for team application development. It preserves the proven UI/UX/rendering constitution and hardens only publisher mounting and runtime-smoke shutdown behavior.

## Verified source facts
- 698/698 collected regressions PASS in deterministic process-isolated execution groups.
- Governance: 0 errors / 0 warnings.
- Static certification: 12 PASS / 1 expected build-environment warning / 0 FAIL.
- Visual integration coverage: 183/183.
- Existing Chromium UI/UX constitution: 46/46 PASS and unchanged by a4.
- Golden live route authority: exactly 22 routes; `/visualizer` is **not** a Company UI route.
- Runtime smoke no longer sends SIGINT to its own server.

## Company publisher: one-file entrypoint
Select the package-root `app.py`. Standard NiceGUI launch:
```bash
python app.py
```
Default bind is `0.0.0.0:8080`; `HOST`/`PORT` and `COMPANY_UI_HOST`/`COMPANY_UI_PORT` are supported.

### If the publisher mounts the app under a URL subpath
If the external URL is, for example, `/visualizer`, that is a **publisher mount prefix**, not a Company UI page. The app supports the existing NiceGUI `root_path` deployment contract through these variables (first one wins):
`COMPANY_UI_ROOT_PATH`, `ROOT_PATH`, `SCRIPT_NAME`, `APPLICATION_ROOT`, `MOUNT_PATH`.

Example if the platform does not set one automatically:
```bash
COMPANY_UI_ROOT_PATH=/visualizer python app.py
```
Do not add a fake `/visualizer` page to Company UI.

## Full target setup
```bash
chmod +x *.sh
./setup.sh
```
Setup owns the local `.venv`, pins `nicegui==3.15.0`, verifies runtime compatibility and performs the live route smoke.
