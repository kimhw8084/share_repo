from __future__ import annotations

import argparse
import json
from pathlib import Path

from company_ui.ai.context import build_agent_context, render_agent_context
from company_ui.ai.preflight import run_agent_preflight
from company_ui.ai.scaffold import install_ai_materials
from company_ui.ai.project import create_application
from company_ui.ai.gate import run_application_gate


def init_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='Install Company UI coding-agent materials into an application workspace.')
    parser.add_argument('path', nargs='?', default='.')
    parser.add_argument('--overwrite', action='store_true')
    args = parser.parse_args(argv)
    written = install_ai_materials(Path(args.path), overwrite=args.overwrite)
    print(f'Company UI agent materials: {len(written)} files written.')
    return 0


def context_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='Build a compact task-specific Company UI coding-agent context pack.')
    parser.add_argument('task', help='Current application task or requirement')
    parser.add_argument('--format', choices=('text', 'json'), default='text')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args(argv)
    pack = build_agent_context(args.task)
    text = json.dumps(pack.to_dict(), indent=2, sort_keys=True) + '\n' if args.format == 'json' else render_agent_context(pack)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding='utf-8')
        print(args.output)
    else:
        print(text, end='')
    return 0


def check_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='Fail-closed Company UI coding-agent preflight.')
    parser.add_argument('path', nargs='?', default='.')
    parser.add_argument('--format', choices=('text', 'json'), default='text')
    args = parser.parse_args(argv)
    report = run_agent_preflight(args.path)
    if args.format == 'json':
        print(json.dumps(report.to_dict(), indent=2, sort_keys=True))
    else:
        for issue in report.issues:
            print(issue)
        print(
            f'Company UI agent check: {"PASS" if report.passed else "FAIL"} · '
            f'framework {report.framework_version} · scaffold {report.scaffold_version or "missing"} · '
            f'{report.validation_errors} errors · {report.validation_warnings} warnings'
        )
    return 0 if report.passed else 1


def create_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='Create a governed Company UI application starter.')
    parser.add_argument('path')
    parser.add_argument('--name', required=True)
    parser.add_argument('--template', choices=('dashboard','data-explorer','crud','analysis-workspace','responsive-operations','async-workflow'), default='analysis-workspace')
    parser.add_argument('--overwrite', action='store_true')
    args = parser.parse_args(argv)
    created = create_application(args.path, name=args.name, template=args.template, overwrite=args.overwrite)
    print(f'Created {created.name} at {created.root} using Company UI {created.framework_version} ({created.template}); {len(created.written)} files written.')
    return 0


def gate_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='Run Company UI application acceptance gates.')
    parser.add_argument('path', nargs='?', default='.')
    parser.add_argument('--release', action='store_true', help='Require live NiceGUI/browser application certification in addition to source gates.')
    parser.add_argument('--format', choices=('text','json'), default='text')
    args = parser.parse_args(argv)
    report = run_application_gate(args.path, release=args.release)
    if args.format == 'json':
        print(json.dumps(report.to_dict(), indent=2, sort_keys=True))
    else:
        for check in report.checks:
            print(f'[{check.status}] {check.name}: {check.detail}')
        print(f'Company UI application gate: {"PASS" if report.passed else "FAIL"}')
    return 0 if report.passed else 1


__all__ = ['check_main', 'context_main', 'create_main', 'gate_main', 'init_main']
