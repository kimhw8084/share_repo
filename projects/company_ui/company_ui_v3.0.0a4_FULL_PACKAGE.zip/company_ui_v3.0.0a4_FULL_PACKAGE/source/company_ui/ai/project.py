from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from company_ui.ai.scaffold import install_ai_materials
from company_ui.version import FRAMEWORK_VERSION

_PROJECT_NAME_RE = re.compile(r'^[A-Za-z][A-Za-z0-9 _.-]{1,79}$')
_TEMPLATE_NAMES = ('dashboard', 'data-explorer', 'crud', 'analysis-workspace', 'responsive-operations', 'async-workflow')


@dataclass(frozen=True, slots=True)
class CreatedApplication:
    root: Path
    name: str
    template: str
    framework_version: str
    written: tuple[Path, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            'root': str(self.root),
            'name': self.name,
            'template': self.template,
            'framework_version': self.framework_version,
            'written': [str(path) for path in self.written],
        }


def _module_name(name: str) -> str:
    value = re.sub(r'[^a-z0-9]+', '_', name.lower()).strip('_')
    return value or 'company_app'


def _home_source(template: str) -> str:
    if template == 'dashboard':
        return '''from company_ui import AxisSpec, AxisType, DashboardPage, Icons, LayoutSlot, LineChart, MetricCard, MetricStrip, SeriesSpec, StatusIntent, TrendDirection\n\n\ndef build_page() -> None:\n    with DashboardPage('Operations overview', 'Fast status, trend and exception scanning.') as page:\n        with page.slot(LayoutSlot.METRICS):\n            with MetricStrip():\n                MetricCard('Availability', '99.4%', delta='+0.3 pp', trend=TrendDirection.UP, intent=StatusIntent.SUCCESS, icon=Icons.CHECK)\n                MetricCard('Open alerts', 7, delta='-3', trend=TrendDirection.DOWN, intent=StatusIntent.SUCCESS, icon=Icons.WARNING)\n        with page.slot(LayoutSlot.PRIMARY):\n            LineChart('Throughput trend', (SeriesSpec('throughput', 'Throughput', (84, 87, 91, 93, 96), smooth=True),), x_axis=AxisSpec(kind=AxisType.CATEGORY, categories=('06:00','09:00','12:00','15:00','18:00')))\n'''
    if template == 'data-explorer':
        return '''from company_ui import Aggregation, AxisSpec, AxisType, BarChart, ColumnKind, DataExplorerPage, DataSession, Dataset, Dimension, LayoutSlot, Metric, MetricCard, MetricStrip, SeriesSpec, TableColumn, DataTable\n\n_ROWS = (\n    {'id':'A-101','area':'ETCH','output':112,'yield_pct':98.7},\n    {'id':'A-102','area':'ETCH','output':104,'yield_pct':97.9},\n    {'id':'A-103','area':'CVD','output':121,'yield_pct':99.1},\n)\n\ndef make_session() -> DataSession:\n    return DataSession(Dataset('production', _ROWS, row_key='id', dimensions=(Dimension('area'),), metrics=(Metric('output', aggregation=Aggregation.SUM), Metric('yield_pct', aggregation=Aggregation.AVG))))\n\ndef build_page() -> None:\n    session = make_session()\n    grouped = session.aggregate(dimensions=('area',), metrics=('output',)).rows\n    with DataExplorerPage('Production explorer', 'One governed data session drives every analytical surface.') as page:\n        with page.slot(LayoutSlot.METRICS):\n            with MetricStrip():\n                MetricCard('Total output', session.metric('output'))\n                MetricCard('Average yield', f\"{session.metric('yield_pct'):.1f}%\")\n        with page.slot(LayoutSlot.PRIMARY):\n            BarChart('Output by area', (SeriesSpec('output','Output',[row['output'] for row in grouped]),), x_axis=AxisSpec(kind=AxisType.CATEGORY, categories=tuple(row['area'] for row in grouped)))\n        with page.slot(LayoutSlot.DATA):\n            DataTable(session.rows().rows, (TableColumn('id','Record'), TableColumn('area','Area'), TableColumn('output','Output',kind=ColumnKind.INTEGER), TableColumn('yield_pct','Yield',kind=ColumnKind.PERCENT,decimals=1)), row_key='id', title='Production records')\n'''
    if template == 'crud':
        return '''from company_ui import Button, ButtonIntent, CrudPage, DataTable, Icons, LayoutSlot, TableColumn\nfrom services.equipment import EquipmentService\n\n\ndef build_page(service: EquipmentService | None = None) -> None:\n    service = service or EquipmentService()\n    with CrudPage('Equipment', 'Search, inspect and manage equipment records.') as page:\n        with page.slot(LayoutSlot.ACTIONS):\n            Button('Add equipment', intent=ButtonIntent.PRIMARY, icon=Icons.ADD)\n        with page.slot(LayoutSlot.DATA):\n            DataTable(service.rows(), (TableColumn('equipment_id','Equipment'), TableColumn('area','Area'), TableColumn('owner','Owner')), row_key='equipment_id', title='Equipment records')\n'''
    if template == 'analysis-workspace':
        return '''from company_ui import Aggregation, AnalysisWorkspacePage, ApplicationRuntime, Dataset, Dimension, LayoutSlot, Metric, MetricCard, MetricStrip, PanelSpec, StateKey, StateNamespace, WorkspaceBreakpoint\n\n_RUNTIME = ApplicationRuntime()\n_RUNTIME.data.register(Dataset('analysis', ({'id':1,'area':'ETCH','value':12.4},{'id':2,'area':'CVD','value':13.1}), row_key='id', dimensions=(Dimension('area'),), metrics=(Metric('value', aggregation=Aggregation.AVG),)))\n_WORKSPACE = _RUNTIME.open_workspace('analysis')\n_WORKSPACE.open_data_session('analysis', session_id='primary')\n_WORKSPACE.layout.register_panel(PanelSpec('primary', preferred_columns=8, preferred_rows=5))\n_WORKSPACE.layout.register_panel(PanelSpec('detail', preferred_columns=4, preferred_rows=5))\n_WORKSPACE.layout.derive_breakpoint(WorkspaceBreakpoint.PHONE, source=WorkspaceBreakpoint.DESKTOP)\n_SELECTION = StateKey[str | None]('selected_record', namespace=StateNamespace.WORKSPACE, default=None)\n_WORKSPACE.state.set(_SELECTION, None, source='initial')\n\n\ndef build_page() -> None:\n    session = _WORKSPACE.data_session('primary')\n    with AnalysisWorkspacePage('Analysis workspace', 'Shared runtime, data and layout ownership.') as page:\n        with page.slot(LayoutSlot.METRICS):\n            with MetricStrip():\n                MetricCard('Average value', f\"{session.metric('value'):.2f}\")\n'''
    if template == 'responsive-operations':
        return '''from company_ui import DashboardPage, LayoutSlot, MetricCard, MetricStrip, PanelSpec, WorkspaceLayoutEngine, WorkspaceBreakpoint\n\n_LAYOUT = WorkspaceLayoutEngine()\n_LAYOUT.register_panel(PanelSpec('summary', preferred_columns=12, preferred_rows=3))\n_LAYOUT.register_panel(PanelSpec('operations', preferred_columns=8, preferred_rows=6))\n_LAYOUT.register_panel(PanelSpec('exceptions', preferred_columns=4, preferred_rows=6))\n_LAYOUT.derive_breakpoint(WorkspaceBreakpoint.TABLET, source=WorkspaceBreakpoint.DESKTOP)\n_LAYOUT.derive_breakpoint(WorkspaceBreakpoint.PHONE, source=WorkspaceBreakpoint.TABLET)\n\n\ndef build_page() -> None:\n    with DashboardPage('Responsive operations', 'Company UI owns breakpoint geometry; page code owns composition.') as page:\n        with page.slot(LayoutSlot.METRICS):\n            with MetricStrip():\n                MetricCard('Running', 42)\n                MetricCard('Attention', 3)\n'''
    if template == 'async-workflow':
        return '''from company_ui import AsyncAction, Button, ButtonIntent, DashboardPage, DuplicatePolicy, LayoutSlot, MetricCard, MetricStrip\n\n_SAVE = AsyncAction[str](timeout=10.0, duplicate_policy=DuplicatePolicy.IGNORE)\n\nasync def save_record() -> str:\n    async def operation() -> str:\n        return 'saved'\n    return await _SAVE.run(operation) or 'saved'\n\ndef build_page() -> None:\n    with DashboardPage('Async workflow', 'Runtime-owned async actions prevent duplicate submissions and lifecycle leaks.') as page:\n        with page.slot(LayoutSlot.METRICS):\n            with MetricStrip():\n                MetricCard('Queue', 0)\n        with page.slot(LayoutSlot.ACTIONS):\n            Button('Save', intent=ButtonIntent.PRIMARY, on_click=save_record)\n'''
    raise KeyError(template)


def _service_source() -> str:
    return '''from dataclasses import dataclass\n\n@dataclass(frozen=True, slots=True)\nclass Equipment:\n    equipment_id: str\n    area: str\n    owner: str\n\nclass EquipmentService:\n    def rows(self) -> list[dict[str, str]]:\n        records = (Equipment('ETCH-01','ETCH','A. Kim'), Equipment('CVD-04','CVD','J. Lee'))\n        return [{'equipment_id': item.equipment_id, 'area': item.area, 'owner': item.owner} for item in records]\n'''


def create_application(destination: str | Path, *, name: str, template: str = 'analysis-workspace', overwrite: bool = False) -> CreatedApplication:
    if not _PROJECT_NAME_RE.match(name.strip()):
        raise ValueError('name must start with a letter and contain 2-80 letters, numbers, spaces, dot, underscore or dash characters')
    if template not in _TEMPLATE_NAMES:
        raise ValueError(f'unknown template {template!r}; choose one of: {", ".join(_TEMPLATE_NAMES)}')
    root = Path(destination).resolve()
    if root.exists() and any(root.iterdir()) and not overwrite:
        raise FileExistsError(f'{root} is not empty; use --overwrite only when replacement is intentional')
    root.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []

    def write(rel: str, content: str) -> None:
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists() and not overwrite:
            raise FileExistsError(path)
        path.write_text(content, encoding='utf-8')
        written.append(path)

    module_name = _module_name(name)
    write('app.py', f'''from __future__ import annotations\nimport os\nfrom company_ui import NiceGUIRuntimeAdapter, RuntimeConfig\nfrom pages.home import build_page\n\n\ndef runtime() -> NiceGUIRuntimeAdapter:\n    return NiceGUIRuntimeAdapter(RuntimeConfig({name!r}, app_version='0.1.0', host=os.getenv('COMPANY_UI_HOST','127.0.0.1'), port=int(os.getenv('COMPANY_UI_PORT','8080')), require_storage_secret=False, show_browser=False))\n\ndef main() -> None:\n    runtime().run(root=build_page)\n\nif __name__ == '__main__':\n    main()\n''')
    write('pages/__init__.py', '')
    write('pages/home.py', _home_source(template))
    write('services/__init__.py', '')
    write('services/equipment.py', _service_source())
    write('domain/__init__.py', '')
    write('data/__init__.py', '')
    write('tests/test_project_contract.py', f'''from company_ui import FRAMEWORK_VERSION\nimport app\n\ndef test_framework_contract() -> None:\n    assert FRAMEWORK_VERSION == {FRAMEWORK_VERSION!r}\n    assert callable(app.runtime)\n    assert callable(app.main)\n''')
    write('requirements.txt', f'company-ui=={FRAMEWORK_VERSION}\n')
    write('requirements-dev.txt', '-r requirements.txt\npytest>=8,<9\n')
    write('company_ui.toml', f'''[company_ui]\nframework_version = {FRAMEWORK_VERSION!r}\napplication_name = {name!r}\nmodule_name = {module_name!r}\ntemplate = {template!r}\nentrypoint = "app:main"\nbuild_page = "pages.home:build_page"\n\n[company_ui.gates]\nrequire_zero_validator_findings = true\nrequire_tests = true\nrequire_exact_framework_pin = true\nrequire_live_for_release = true\n''')
    write('.gitignore', '.venv/\n__pycache__/\n.pytest_cache/\ncertification_output/\nvisual_baseline/\ndist/\nbuild/\n')
    write('README.md', f'''# {name}\n\nGenerated by Company UI {FRAMEWORK_VERSION} using the `{template}` golden path.\n\n## Development\n\n```bash\npython -m venv .venv\n. .venv/bin/activate\npython -m pip install -r requirements-dev.txt\ncompany-ui agent-context "describe the current task"\ncompany-ui agent-check .\npython app.py\n```\n\n## Acceptance\n\n```bash\ncompany-ui gate .\ncompany-ui gate . --release\n```\n\nThe release gate intentionally requires the exact NiceGUI/browser environment; source-only success is not visual approval.\n''')
    written.extend(install_ai_materials(root, overwrite=overwrite))
    return CreatedApplication(root=root, name=name, template=template, framework_version=FRAMEWORK_VERSION, written=tuple(dict.fromkeys(written)))


__all__ = ['CreatedApplication', 'create_application']
