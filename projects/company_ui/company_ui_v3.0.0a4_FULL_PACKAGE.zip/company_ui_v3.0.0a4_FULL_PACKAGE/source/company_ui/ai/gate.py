from __future__ import annotations

import importlib
import json
import os
import subprocess
import sys
import tomllib
from dataclasses import dataclass
from pathlib import Path

from company_ui.ai.preflight import run_agent_preflight
from company_ui.version import FRAMEWORK_VERSION


@dataclass(frozen=True, slots=True)
class GateCheck:
    name: str
    status: str
    detail: str

    def to_dict(self) -> dict[str, str]:
        return {'name': self.name, 'status': self.status, 'detail': self.detail}


@dataclass(frozen=True, slots=True)
class ApplicationGateReport:
    root: Path
    framework_version: str
    release_mode: bool
    checks: tuple[GateCheck, ...]

    @property
    def passed(self) -> bool:
        return all(check.status == 'PASS' for check in self.checks)

    def to_dict(self) -> dict[str, object]:
        return {
            'root': str(self.root),
            'framework_version': self.framework_version,
            'release_mode': self.release_mode,
            'passed': self.passed,
            'checks': [check.to_dict() for check in self.checks],
        }


def _manifest(root: Path) -> dict:
    path = root / 'company_ui.toml'
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open('rb') as handle:
        value = tomllib.load(handle)
    company = value.get('company_ui')
    if not isinstance(company, dict):
        raise ValueError('company_ui.toml must define [company_ui]')
    return company


def _compile_python(root: Path) -> tuple[int, list[str]]:
    failures: list[str] = []
    count = 0
    excludes = {'.venv', 'venv', '.git', '__pycache__', 'build', 'dist'}
    for path in root.rglob('*.py'):
        if any(part in excludes for part in path.relative_to(root).parts):
            continue
        count += 1
        try:
            compile(path.read_text(encoding='utf-8'), str(path), 'exec')
        except (OSError, SyntaxError, UnicodeError) as exc:
            failures.append(f'{path.relative_to(root)}: {exc}')
    return count, failures


def _import_symbol(root: Path, spec: str) -> object:
    module_name, separator, symbol = spec.partition(':')
    if not separator or not module_name or not symbol:
        raise ValueError(f'invalid entrypoint {spec!r}; expected module:symbol')
    old_path = list(sys.path)
    try:
        sys.path.insert(0, str(root))
        importlib.invalidate_caches()
        # Generated starters use stable module names (app/pages/services). Purge
        # those app-local modules so repeated dogfood gates cannot reuse a module
        # imported from a different workspace.
        for loaded in tuple(sys.modules):
            if loaded == module_name or loaded == 'pages' or loaded.startswith('pages.') or loaded == 'services' or loaded.startswith('services.') or loaded == 'data' or loaded.startswith('data.') or loaded == 'domain' or loaded.startswith('domain.'):
                sys.modules.pop(loaded, None)
        module = importlib.import_module(module_name)
        value = getattr(module, symbol)
        if not callable(value):
            raise TypeError(f'{spec} is not callable')
        return value
    finally:
        sys.path[:] = old_path


def _exact_requirement(root: Path) -> bool:
    path = root / 'requirements.txt'
    if not path.exists():
        return False
    normalized = {line.strip().lower().replace('_','-') for line in path.read_text(encoding='utf-8').splitlines() if line.strip() and not line.lstrip().startswith('#')}
    return f'company-ui=={FRAMEWORK_VERSION}'.lower() in normalized


def _run_tests(root: Path) -> tuple[bool, str]:
    tests = root / 'tests'
    if not tests.exists():
        return False, 'tests/ is missing'
    env = dict(os.environ)
    package_root = str(Path(__file__).resolve().parents[2])
    env['PYTHONPATH'] = package_root + (os.pathsep + env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
    completed = subprocess.run([sys.executable, '-m', 'pytest', '-q', str(tests)], cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180, env=env)
    tail = '\n'.join(completed.stdout.splitlines()[-12:])
    return completed.returncode == 0, tail or f'pytest exit={completed.returncode}'


def _run_live_release_gate(root: Path) -> tuple[bool, str]:
    # Delegate the target-only browser/runtime work to the application live gate.
    # Keeping this in a subprocess prevents the gate from contaminating the caller's
    # NiceGUI event loop or module state.
    completed = subprocess.run(
        [sys.executable, '-m', 'company_ui.ai.live_gate', '--root', str(root), '--format', 'json'],
        cwd=root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=180,
        env=dict(os.environ),
    )
    if completed.returncode == 0:
        try:
            payload = json.loads(completed.stdout)
            return True, f"{payload.get('passed_checks', 0)}/{payload.get('total_checks', 0)} live checks"
        except json.JSONDecodeError:
            return True, 'live application certification passed'
    return False, '\n'.join(completed.stdout.splitlines()[-12:]) or f'live gate exit={completed.returncode}'


def run_application_gate(root: str | Path='.', *, release: bool=False) -> ApplicationGateReport:
    root = Path(root).resolve()
    checks: list[GateCheck] = []
    try:
        manifest = _manifest(root)
        version = str(manifest.get('framework_version') or '')
        checks.append(GateCheck('manifest', 'PASS' if version == FRAMEWORK_VERSION else 'FAIL', f'framework={version or "missing"}; installed={FRAMEWORK_VERSION}'))
    except Exception as exc:
        manifest = {}
        checks.append(GateCheck('manifest', 'FAIL', str(exc)))

    preflight = run_agent_preflight(root)
    checks.append(GateCheck('agent-preflight', 'PASS' if preflight.passed else 'FAIL', f'{preflight.validation_errors} errors / {preflight.validation_warnings} warnings; scaffold={preflight.scaffold_version or "missing"}'))

    checks.append(GateCheck('dependency-pin', 'PASS' if _exact_requirement(root) else 'FAIL', f'requirements.txt must contain company-ui=={FRAMEWORK_VERSION}'))

    count, failures = _compile_python(root)
    checks.append(GateCheck('python-compile', 'PASS' if not failures else 'FAIL', f'{count} files' if not failures else '; '.join(failures[:4])))

    entrypoint = str(manifest.get('entrypoint') or '')
    try:
        _import_symbol(root, entrypoint)
        checks.append(GateCheck('entrypoint', 'PASS', entrypoint))
    except Exception as exc:
        checks.append(GateCheck('entrypoint', 'FAIL', f'{entrypoint or "missing"}: {exc}'))

    try:
        tests_ok, tests_detail = _run_tests(root)
    except Exception as exc:
        tests_ok, tests_detail = False, str(exc)
    checks.append(GateCheck('tests', 'PASS' if tests_ok else 'FAIL', tests_detail))

    if release:
        try:
            live_ok, live_detail = _run_live_release_gate(root)
        except Exception as exc:
            live_ok, live_detail = False, str(exc)
        checks.append(GateCheck('live-uiux', 'PASS' if live_ok else 'FAIL', live_detail))

    return ApplicationGateReport(root=root, framework_version=FRAMEWORK_VERSION, release_mode=release, checks=tuple(checks))


__all__ = ['ApplicationGateReport', 'GateCheck', 'run_application_gate']
