# OpenCode / Gemma Bootstrap Prompt

Use the following as the first instruction for a coding agent working in an application built on Company UI.

> Treat Company UI as the application platform and `company_ui/` as stable framework code unless the task explicitly requests framework development. Read `AGENTS.md` first. Before coding, run `company-ui agent-context "<current task>"` and inspect the recommended golden example plus `.company_ui/framework_catalog.json`. Use only real Company UI public APIs; do not invent symbols or parameters. Keep page modules limited to composition and event delegation, with business logic in services and data access in repositories. Do not import NiceGUI directly, create raw AG Grid/ECharts, add arbitrary CSS/geometry/colors, or create parallel state/filter/layout/overlay systems. Use v3 `ApplicationRuntime`/`WorkspaceRuntime`, `DataSession`, workspace layout, and semantic visualization layers when they remove duplicate ownership. Preserve existing UI/UX unless the task explicitly improves it. After meaningful changes run `company-ui agent-check .`, application tests, and browser/runtime checks for visual work. Do not declare completion with validator warnings, failing tests, or unreviewed visual changes.

For a new workspace, bootstrap once with:

```bash
company-ui agent-init .
```

For every substantive task:

```bash
company-ui agent-context "<task>"
company-ui agent-check .
```


## Agent-native application factory (current release)

For a new application, start from a governed template instead of inventing repository structure:

```bash
company-ui create ./my_app --name "My App" --template analysis-workspace
cd my_app
company-ui agent-context "<current task>"
company-ui agent-check .
company-ui gate .
```

Available starter intents are `dashboard`, `data-explorer`, `crud`, `analysis-workspace`, `responsive-operations`, and `async-workflow`. Before production promotion run `company-ui gate . --release`; it is intentionally fail-closed unless the exact NiceGUI/browser application gate passes.
