# Company UI Coding-Agent Workflow

This is the operational workflow for OpenCode/Gemma-style coding agents. It intentionally reduces choice: the fastest path is the governed path.

## 0. Bootstrap the workspace once

```bash
company-ui agent-init .
```

This installs `AGENTS.md`, Company UI guides, the machine-readable framework catalog, and canonical golden examples without touching existing application code. Use `--overwrite` only when intentionally refreshing generated Company UI materials after a framework upgrade.

## 1. Build a task-specific context pack before coding

```bash
company-ui agent-context "build an equipment dashboard with KPIs, filters, trend chart and table"
```

The output identifies the dominant page pattern, construction categories, exact documents/registries to inspect, and the closest golden examples. Coding agents should use this compact pack instead of loading the entire framework into context.

## 2. Inspect before inventing

Use this order:

1. closest golden example under `examples/company_ui/`
2. `.company_ui/framework_catalog.json`
3. `docs/company_ui/PUBLIC_API_INDEX.md`
4. actual public Python signature/source when needed

Never guess a Company UI symbol or parameter.

## 3. Keep application architecture boring

```text
app.py / runtime
pages/              Company UI composition only
services/           business logic / orchestration
repositories/       SQL / APIs / persistence
models/             typed business models
 tests/              application behavior
```

Pages should remain small. A page callback delegates substantial work to a service or Company UI async/runtime primitive.

## 4. Use the v3 ownership layers when they remove duplicate logic

- `ApplicationRuntime` / `WorkspaceRuntime` — shared lifecycle, state, commands, undo/redo, diagnostics.
- `Dataset` / `DataSession` — one filter/query authority across table, chart and KPI surfaces.
- `WorkspaceLayoutEngine` — persistent, responsive analytical panel geometry.
- `SemanticVisualizationPlanner` — semantic intent routed into the certified visual renderer stack.

Do not migrate a proven v2 screen merely to say it uses v3. Adopt these layers when they eliminate duplicated state, filtering, lifecycle or layout behavior.

## 5. Validate continuously

```bash
company-ui agent-check .
```

This fails closed when the installed framework and generated agent scaffold disagree, or when static Company UI construction laws produce errors/warnings.

For machine-readable detail:

```bash
python -m company_ui.validate . --format json --warnings-as-errors
```

## 6. Completion contract

A coding-agent task is not complete until:

- no Company UI validator errors or warnings remain;
- application tests pass;
- startup/runtime smoke relevant to the application passes;
- browser output is reviewed for visual changes;
- no raw NiceGUI/AG Grid/ECharts/CSS path was introduced simply because it was faster to type;
- a framework extension is isolated and documented if the public vocabulary genuinely could not express the requirement.

The framework is the platform. The coding agent builds the product on top of it.


## Agent-native application factory (current release)

For a new application, start from a governed template instead of inventing repository structure:

```bash
company-ui create ./my_app --name "My App" --template analysis-workspace
cd my_app
company-ui agent-context "<current task>"
company-ui agent-check .
company-ui gate .
```

Available starter intents are `dashboard`, `data-explorer`, `crud`, `analysis-workspace`, `responsive-operations`, and `async-workflow`. Before production promotion run `company-ui gate . --release`; it is intentionally fail-closed unless the exact NiceGUI/browser application gate passes.
