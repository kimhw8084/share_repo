# Company UI Golden Agent Examples

These are canonical construction examples for coding agents. Copy their **architecture and Company UI usage**, not their demo data.

- `golden_dashboard.py` — KPI/trend overview and runtime adapter.
- `golden_data_explorer.py` — one v3 `DataSession` feeding KPI, chart and table.
- `golden_crud.py` — page/service/repository separation with a governed `DataTable`.
- `golden_analysis_workspace.py` — v3 application runtime, shared dataset, workspace state and responsive panel geometry.

Rules:

1. Prefer the closest example before inventing composition.
2. Keep business-specific data/services outside `company_ui/`.
3. Use root-level public imports from `company_ui` unless a documented guide explicitly requires otherwise.
4. Run `python -m company_ui.validate . --warnings-as-errors` after modification.
5. Visual changes require real browser inspection/certification; source correctness is not visual certification.
