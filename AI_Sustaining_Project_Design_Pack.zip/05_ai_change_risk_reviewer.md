# AI Change-Risk and Incident-Correlation Reviewer

**Status:** DRAFT FOR REVIEW  
**Version:** 1.0  
**Date:** 2026-07-30  
**Purpose:** Reduce review and diagnosis time by identifying missing change controls and highlighting plausible links between recent changes and incidents.  
**Primary users:** Engineers and technical reviewers  
**Proposed owner:** To be assigned by manager  
**Approval authority:** Existing change and production owners

## 1. Problem

Sustaining investigations often spend significant time determining what changed, what dependencies may be affected, and whether rollback and validation plans are complete.

## 2. Proposed Outcome

A read-only AI reviewer that summarizes proposed changes, identifies missing safeguards, and ranks possible incident correlations without claiming causation.

## 3. MVP Scope

Start with one change category, such as application deployment or approved configuration change.

Inputs:
- Change description
- Affected components
- Architecture references
- Test plan
- Deployment plan
- Rollback plan
- Observability plan
- Recent approved changes
- Historical incidents for the same component

Outputs:
- Change summary
- Potential dependencies
- Historical failure patterns
- Missing tests
- Rollback gaps
- Monitoring gaps
- Support-readiness gaps
- Recommended reviewers
- Possible incident correlations

## 4. Non-Goals

- Approving or rejecting changes
- Executing deployments
- Executing rollback
- Confirming that a change caused an incident
- Replacing architecture review

## 5. Workflow

1. User submits an approved change record.
2. AI reviews the record against a standard checklist.
3. AI retrieves relevant architecture and historical incident evidence.
4. Reviewer confirms or rejects findings.
5. Final decisions remain in the existing change process.
6. During incidents, the tool may rank recent changes for investigation.

## 6. Safety and Quality Controls

- Read-only operation.
- No automated approval or deployment.
- Distinguish temporal correlation from causal evidence.
- Require source references for historical claims.
- Preserve existing approval authority.
- Keep sensitive implementation details under source access controls.

## 7. Success Measures

- Reduction in review preparation time
- Missing rollback or validation items caught before deployment
- Reduction in time to identify relevant recent changes
- Reviewer acceptance rate
- False-correlation rate
- Percentage of reviewed changes with complete support-readiness data

## 8. Dependencies

- Structured change records
- Architecture documentation
- Historical incident data
- Review checklist
- Internal AI API
- Source access controls

## 9. Key Risks

- False correlation
- Incomplete change records
- Excessive generic findings
- Review fatigue
- Users mistaking recommendations for approval

## 10. MVP Completion Evidence

- One change category piloted
- Review checklist implemented
- Historical sources linked
- False-correlation rate measured
- Human approval remains mandatory
- Time savings exceed review overhead

## 11. Stop or Review Criteria

Pause if source records are too incomplete, findings are mostly generic, or false correlations materially distract incident response.
