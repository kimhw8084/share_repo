# AI Incident Triage Copilot

**Status:** DRAFT FOR REVIEW  
**Version:** 1.0  
**Date:** 2026-07-30  
**Purpose:** Reduce engineer time spent reading tickets, requesting missing evidence, summarizing logs, and preparing the first diagnostic response.  
**Primary users:** Technicians and sustaining engineers  
**Related system:** Existing NiceGUI/Jira analysis application  
**Proposed owner:** To be assigned by manager  
**Technical approver:** Responsible engineer for each supported production system

## 1. Problem

Sustaining engineers repeatedly spend time reconstructing incident scope, requesting basic evidence, reviewing long ticket histories, and preparing initial hypotheses.

## 2. Proposed Outcome

A read-only AI assistant that converts a Jira ticket and approved evidence into a structured, engineer-ready triage package.

## 3. MVP Scope

Support two or three high-volume incident categories.

Inputs:
- Jira summary, description, comments, and timestamps
- Approved log excerpts
- User-entered impact and scope
- Recent-change information
- Links to approved internal references

Outputs:
- Observed facts
- Missing evidence
- Affected and unaffected scope
- Timeline
- Recent changes
- Similar known incidents
- Ranked hypotheses
- Safest discriminating checks
- Technician stop conditions
- Engineer escalation summary

## 4. Non-Goals

- Confirming root cause
- Executing recovery
- Writing to production systems
- Automatically closing tickets
- Replacing engineer judgment

## 5. Workflow

1. User selects a supported ticket.
2. System validates required fields.
3. AI generates structured triage output.
4. User reviews and corrects the output.
5. Approved summary is copied or posted to Jira through existing controls.
6. Feedback is stored for evaluation.

## 6. Safety and Quality Controls

- Label observations, assumptions, and hypotheses separately.
- Require source references for factual claims.
- Block unsupported “confirmed cause” language.
- Preserve original timestamps and evidence.
- Keep all production actions outside the AI workflow.
- Require human approval before Jira updates.

## 7. Success Measures

- Reduction in engineer ticket-reading time
- Fewer clarification cycles
- Lower time to first useful diagnostic action
- Percentage of outputs accepted with minor edits
- Unsupported-claim rate
- User correction rate

## 8. Dependencies

- Internal AI API access
- Jira data access through approved mechanisms
- Representative historical tickets
- Approved log-handling rules
- Named technical reviewers

## 9. Key Risks

- Hallucinated facts
- Missing or stale ticket data
- Sensitive information in prompts
- Overreliance by inexperienced users
- Weak output consistency

## 10. MVP Completion Evidence

- Pilot completed on representative cases
- Output schema validated
- Human review remains mandatory
- Measurable reduction in triage effort
- No production action capability
- Documented fallback when AI is unavailable

## 11. Stop or Review Criteria

Pause expansion if unsupported claims remain high, reviewers do not trust the output, or time savings do not exceed review overhead.
