# AI Recurring-Issue and Sustaining Demand Miner

**Status:** DRAFT FOR REVIEW  
**Version:** 1.0  
**Date:** 2026-07-30  
**Purpose:** Identify recurring sustaining demand and convert it into a prioritized elimination backlog.  
**Primary users:** Manager, sustaining engineers, automation developers  
**Proposed owner:** To be assigned by manager  
**Decision owner:** Manager

## 1. Problem

Ticket volume alone does not reveal which recurring issues consume the most engineering capacity or which patterns are suitable for permanent elimination.

## 2. Proposed Outcome

An AI-assisted analysis that groups related tickets, estimates sustaining demand, identifies likely elimination opportunities, and produces a reviewable backlog.

## 3. MVP Scope

Analyze six to twelve months of approved team Jira data.

Classify or cluster by:
- Production system
- Symptom
- Component
- Workaround
- Confirmed cause
- Suspected cause
- Technician effort
- Engineer effort
- Monitoring gap
- Documentation gap
- Automation candidate
- Recurring versus unique demand

## 4. Required Output

For each cluster:
- Cluster name
- Ticket count
- Estimated sustaining effort
- Representative tickets
- Shared symptom
- Confirmed common cause, if any
- Current workaround
- Candidate elimination action
- Expected value
- Evidence quality
- Proposed reviewer
- Continue, investigate, or reject recommendation

## 5. Non-Goals

- Treating semantic similarity as common root cause
- Automatically assigning projects
- Producing precise ROI without reliable inputs
- Replacing engineering review
- Closing incidents

## 6. Workflow

1. Extract approved Jira data.
2. Normalize basic fields.
3. Use AI to classify and cluster ticket text.
4. Review top clusters with system owners.
5. Estimate low, base, and high effort where evidence permits.
6. Create a sustaining elimination backlog.
7. Track whether selected clusters actually decline.

## 7. Safety and Quality Controls

- Separate same symptom, likely related, and confirmed common cause.
- Show representative tickets for every cluster.
- Record confidence and evidence quality.
- Require human review before portfolio decisions.
- Avoid exposing sensitive incident details in broad reports.

## 8. Success Measures

- Percentage of sustaining effort categorized
- Number of valid recurring clusters identified
- Permanent-fix projects created
- Reduction in recurrence for selected clusters
- Engineering hours recovered
- False-cluster and missed-cluster rates

## 9. Dependencies

- Jira data export or approved access
- Effort estimates or proxy fields
- System-owner review
- Internal AI API
- Historical ticket quality
- Agreed prioritization process

## 10. Key Risks

- Poor ticket quality
- Misleading clusters
- False precision in effort estimates
- Focus on ticket count instead of impact
- Failure to act on findings

## 11. MVP Completion Evidence

- Historical sample analyzed
- Top clusters reviewed by owners
- At least one elimination candidate selected
- Baseline recurrence and effort recorded
- Dashboard or report supports repeatable review
- False grouping rate is acceptable

## 12. Stop or Review Criteria

Pause if ticket data is too inconsistent to support reliable grouping or if no team capacity exists to execute the resulting elimination work.
