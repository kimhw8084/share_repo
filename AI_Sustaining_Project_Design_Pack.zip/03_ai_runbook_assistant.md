# AI Runbook Drafting and Maintenance Assistant

**Status:** DRAFT FOR REVIEW  
**Version:** 1.0  
**Date:** 2026-07-30  
**Purpose:** Convert resolved incidents into maintainable technician-ready runbook drafts and identify outdated operational documentation.  
**Primary users:** Engineers, technicians, and document owners  
**Proposed owner:** To be assigned by manager  
**Approval authority:** Responsible engineer and manager where operational risk requires

## 1. Problem

Resolved incidents often remain buried in Jira comments. The same sustaining work repeats because lessons are not converted into validated procedures.

## 2. Proposed Outcome

An AI assistant that creates a structured runbook draft from incident evidence and later compares runbooks with new incidents to identify gaps or staleness.

## 3. MVP Scope

Use ten selected resolved incidents to generate drafts containing:
- Purpose and supported symptom
- Preconditions and required access
- Safety warnings
- Decision tree
- Evidence to preserve
- Technician-safe checks
- Expected result after each step
- Stop conditions
- Engineer escalation package
- Recovery verification
- Known failure modes
- Owner and review date

## 4. Non-Goals

- Publishing without review
- Inventing commands
- Declaring actions technician-safe
- Autonomous recovery
- Replacing validation or training

## 5. Workflow

1. Engineer selects a resolved incident.
2. AI extracts facts, recovery steps, and evidence.
3. AI generates a DRAFT runbook.
4. Engineer validates technical accuracy.
5. Technician reviews usability.
6. Procedure is tested through the approved method.
7. Authorized owner publishes it.
8. Later incidents are compared for missing branches or new failure modes.

## 6. Safety and Quality Controls

- Generated documents remain DRAFT until approved.
- Commands and values must come from approved evidence.
- Technician-safe classification requires explicit validation.
- Include rollback, stop conditions, and escalation.
- Record owner, version, and review trigger.
- Preserve unresolved questions as “needs verification.”

## 7. Success Measures

- Reduction in engineer drafting time
- Percentage of drafts accepted after review
- Number of recurring incidents converted into validated runbooks
- Reduction in repeat engineer execution
- Runbook usage and successful completion rate
- Number of stale instructions identified

## 8. Dependencies

- Resolved incidents with sufficient evidence
- Standard runbook template
- Named technical reviewers
- Validation environment or approved test approach
- Document repository and ownership process

## 9. Key Risks

- Unsafe inferred steps
- Missing context from Jira history
- False confidence from polished language
- Outdated commands
- Publishing without adequate validation

## 10. MVP Completion Evidence

- Ten drafts generated
- Review effort measured
- All published items have technical approval
- Technician usability feedback captured
- No unsupported steps remain
- Review and ownership metadata is complete

## 11. Stop or Review Criteria

Pause if incident records are too incomplete to support reliable drafts or if technical review requires nearly full document recreation.
