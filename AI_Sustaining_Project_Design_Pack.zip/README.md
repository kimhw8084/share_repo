# AI Sustaining Reduction Project Pack

**Status:** DRAFT FOR REVIEW  
**Version:** 1.0  
**Date:** 2026-07-30  
**Audience:** Project owners, technical reviewers, manager  
**Purpose:** Provide five streamlined, owner-ready project design documents for using the internal AI API to reduce production-system sustaining effort while preserving support quality and human control.

## Program Goal

Reduce recurring engineering sustaining time to the lowest credible level so engineers can focus primarily on production-system improvement and automation innovation.

## Recommended Sequence

1. AI Incident Triage Copilot
2. AI Internal Knowledge and Known-Issue Assistant
3. AI Runbook Drafting and Maintenance Assistant
4. AI Recurring-Issue and Sustaining Demand Miner
5. AI Change-Risk and Incident-Correlation Reviewer

## Shared Design Principles

- Start read-only.
- Require human review before Jira updates or operational decisions.
- Keep observations, hypotheses, and confirmed causes separate.
- Preserve source references and timestamps.
- Do not allow the AI to execute production changes.
- Use structured outputs that can be validated.
- Measure recovered engineering capacity, not AI usage.
- Build reusable shared services instead of five disconnected integrations.

## Shared Platform Components

- Internal AI API client
- Prompt and schema versioning
- Retrieval from approved internal sources
- Structured JSON validation
- Access control and audit logging
- Sensitive-data filtering
- Source citation handling
- User feedback capture
- Evaluation dataset and regression tests
- Model timeout and fallback behavior

## Shared Unknowns to Verify

- API authentication and authorization
- Rate limits and latency
- Context-window limits
- Structured-output support
- Data retention and logging behavior
- Approved data classes
- Model availability expectations
- Internal deployment and support ownership

## Program Success Measures

- Engineering sustaining hours per month
- Engineer interruptions per week
- Median time to useful diagnosis
- Repeat incident frequency
- Percentage of incidents with complete evidence
- Percentage of eligible work handled through validated technician procedures
- AI output acceptance and correction rates
- Hours returned to improvement and automation work
