# AI Internal Knowledge and Known-Issue Assistant

**Status:** DRAFT FOR REVIEW  
**Version:** 1.0  
**Date:** 2026-07-30  
**Purpose:** Reduce sustaining time spent locating SOPs, prior incidents, known issues, owners, and escalation guidance.  
**Primary users:** Technicians and engineers  
**Proposed owner:** To be assigned by manager  
**Content approvers:** Document and system owners

## 1. Problem

Operational knowledge is distributed across Jira tickets, SOPs, troubleshooting notes, and individual engineers. Search effort and knowledge concentration increase sustaining time.

## 2. Proposed Outcome

A retrieval-grounded assistant that answers internal support questions only from approved sources and always shows where the answer came from.

## 3. MVP Scope

Index a controlled set of:
- Validated SOPs
- Selected resolved Jira incidents
- Architecture summaries
- Ownership records
- Known-error documentation

Supported questions:
- Has this symptom occurred before?
- Which SOP applies?
- What evidence is required?
- Who owns this system?
- What are the technician stop conditions?
- Are any sources stale or contradictory?

## 4. Required Answer Format

- Direct answer
- Source title and link
- Revision date
- Source owner
- Supporting excerpt or citation
- Confidence or evidence limitation
- Escalation path
- “No approved answer found” when unsupported

## 5. Non-Goals

- General-purpose chat
- Inventing missing procedures
- Using unapproved content
- Executing commands
- Replacing document ownership

## 6. Workflow

1. User asks a sustaining question.
2. System retrieves approved sources.
3. AI answers only from retrieved content.
4. Response shows source and freshness.
5. User can flag incorrect, stale, or conflicting content.
6. Content owner receives a review item through the approved process.

## 7. Safety and Quality Controls

- No answer without supporting source.
- Show conflicts rather than silently resolving them.
- Enforce source-level access controls.
- Display document owner and review date.
- Distinguish known issue, workaround, and confirmed root cause.
- Provide an escalation response when evidence is insufficient.

## 8. Success Measures

- Reduction in average search time
- Fewer engineer interruptions for known issues
- Percentage of answers grounded in approved sources
- Unanswered-question rate
- Incorrect-answer rate
- Number of stale or conflicting documents identified

## 9. Dependencies

- Approved content inventory
- Source permissions
- Retrieval/indexing capability
- Document ownership metadata
- Internal AI API
- Evaluation questions with known answers

## 10. Key Risks

- Stale content
- Access-control leakage
- Misleading synthesis across conflicting documents
- Poor retrieval quality
- Users treating guidance as universally valid

## 11. MVP Completion Evidence

- Controlled corpus indexed
- Retrieval precision validated
- Every answer cites an approved source
- Access rules tested
- “No answer” behavior validated
- Pilot users show measurable search-time reduction

## 12. Stop or Review Criteria

Pause if the corpus cannot be governed, source access cannot be enforced, or retrieval errors create more review burden than value.
