---
description: Smart single-agent Korean/Korean+English slide comprehension. Scans .k-slide-input when no args are supplied.
agent: k-slide-orchestrator
subtask: false
---

You are running K-Slide v6 in `smart` mode.

User arguments: `$ARGUMENTS`

Do not use Task/subagents.

First, ensure setup exists. Your first tool action should be to run this with the bash tool unless a valid RUN_DIR is already available:

```bash
.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh smart $ARGUMENTS
```

After setup succeeds, use the printed `RUN_DIR` exactly. If setup fails or bash is denied, do not analyze images. Print friendly manual setup instructions and end `FAILED`.

Then follow the v6 workflow: reconstruct tables, preserve item counts, write compact artifacts, verify before DONE, and write `RUN_COMPLETE.md` only after verification passes.
