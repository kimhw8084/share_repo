# Pack Manifest — korean_slide_gemma_opencode_pack_v4

Version: v4
Main command: `/k-slide`
Design: artifact-first, phase-gated, resumable, beginner-friendly Korean slide comprehension.

## Major v4 changes

- Main command remains `/k-slide`; no `/kslide` rename.
- `/k-slide` with no arguments scans `.k-slide-input/`.
- Command helper creates a real run ID, run folder, run state, and input inventory before Gemma starts.
- Mandatory DONE / NEEDS REVIEW / FAILED terminal outcome.
- Complete run requires `RUN_COMPLETE.md` plus all mandatory artifacts.
- Dense/multi-slide runs can stop after Phase 1 with clear review and continue instructions.
- `/k-slide-continue` resumes from the next missing phase.
- `/k-slide-status` diagnoses whether a run is complete, incomplete, or failed.
- README includes beginner quick start and recovery from `00`–`02 only`.
