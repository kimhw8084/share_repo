#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-.}"
fail=0
check() {
  if [ -e "$TARGET/$1" ]; then
    echo "[ok] $1"
  else
    echo "[missing] $1"
    fail=1
  fi
}
check ".opencode/commands/k-slide.md"
check ".opencode/commands/k-slide-continue.md"
check ".opencode/commands/k-slide-status.md"
check ".opencode/commands/k-slide-doctor.md"
check ".opencode/agents/k-slide-orchestrator.md"
check ".opencode/agents/input-run-manager.md"
check ".opencode/skills/korean-slide-comprehension/SKILL.md"
check ".opencode/skills/korean-slide-comprehension/bin/prepare_run.sh"
check ".opencode/skills/korean-slide-comprehension/bin/status_run.sh"
check ".k-slide-input"
check ".k-slide-runs"
if [ "$fail" -ne 0 ]; then
  echo "Install verification FAILED."
  exit 1
fi
RID="$($TARGET/.opencode/skills/korean-slide-comprehension/bin/new_run_id.sh)"
echo "[ok] run id helper produced: $RID"
case "$RID" in
  kslide-[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9][0-9][0-9]-*) echo "[ok] run id format" ;;
  *) echo "[warn] unexpected run id format" ;;
esac
echo "Install verification PASSED."
