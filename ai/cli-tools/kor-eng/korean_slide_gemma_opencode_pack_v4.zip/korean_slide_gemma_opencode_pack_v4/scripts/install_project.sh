#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-}"
if [ -z "$TARGET" ]; then
  echo "Usage: ./scripts/install_project.sh /path/to/project"
  exit 1
fi
mkdir -p "$TARGET"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$TARGET/.opencode" "$TARGET/.k-slide-input" "$TARGET/.k-slide-runs" "$TARGET/.k-slide-archive"

if [ -d "$TARGET/.opencode/skills/korean-slide-comprehension" ] || [ -f "$TARGET/.opencode/commands/k-slide.md" ]; then
  BACKUP="$TARGET/.opencode.backup-k-slide-$(date +%Y%m%d-%H%M%S)"
  echo "Existing k-slide OpenCode files detected. Creating backup: $BACKUP"
  mkdir -p "$BACKUP"
  [ -d "$TARGET/.opencode/skills/korean-slide-comprehension" ] && mkdir -p "$BACKUP/skills" && cp -R "$TARGET/.opencode/skills/korean-slide-comprehension" "$BACKUP/skills/"
  [ -d "$TARGET/.opencode/commands" ] && mkdir -p "$BACKUP/commands" && cp -R "$TARGET/.opencode/commands" "$BACKUP/commands/"
  [ -d "$TARGET/.opencode/agents" ] && mkdir -p "$BACKUP/agents" && cp -R "$TARGET/.opencode/agents" "$BACKUP/agents/"
fi

cp -R "$PACK_DIR/.opencode/agents" "$TARGET/.opencode/"
cp -R "$PACK_DIR/.opencode/commands" "$TARGET/.opencode/"
mkdir -p "$TARGET/.opencode/skills"
cp -R "$PACK_DIR/.opencode/skills/korean-slide-comprehension" "$TARGET/.opencode/skills/"
cp "$PACK_DIR/AGENTS.md" "$TARGET/AGENTS.md"
chmod +x "$TARGET/.opencode/skills/korean-slide-comprehension/bin/"*.sh || true

if [ ! -f "$TARGET/.k-slide-input/README.md" ]; then
  cat > "$TARGET/.k-slide-input/README.md" <<'EOF'
Put Korean/Korean+English slide screenshots here, then run /k-slide in OpenCode.
Recommended names: slide-001.png, slide-002.png, slide-003.png
EOF
fi

echo "Installed Korean Slide Comprehension v4 into: $TARGET"
echo "Next: put images in $TARGET/.k-slide-input/ and run /k-slide in OpenCode."
