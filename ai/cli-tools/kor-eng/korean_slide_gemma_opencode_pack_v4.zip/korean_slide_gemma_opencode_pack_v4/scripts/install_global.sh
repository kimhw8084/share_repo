#!/usr/bin/env bash
set -euo pipefail
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${XDG_CONFIG_HOME:-$HOME/.config}/opencode"
mkdir -p "$TARGET/agents" "$TARGET/commands" "$TARGET/skills"
cp -R "$PACK_DIR/.opencode/agents/"* "$TARGET/agents/"
cp -R "$PACK_DIR/.opencode/commands/"* "$TARGET/commands/"
cp -R "$PACK_DIR/.opencode/skills/korean-slide-comprehension" "$TARGET/skills/"
chmod +x "$TARGET/skills/korean-slide-comprehension/bin/"*.sh || true
echo "Installed globally into: $TARGET"
echo "Project-local install is recommended before global use."
