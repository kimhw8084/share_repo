# Korean Slide Comprehension Pack v4 — Project Rules

This project contains an OpenCode skill pack for Korean/Korean+English slide-image comprehension using the current OpenCode model brain, normally Gemma 4 31B in the target environment.

## Golden workflow

1. Put slide screenshots into `.k-slide-input/`.
2. Run `/k-slide` in OpenCode.
3. Open `.k-slide-runs/<run-id>/05_final_report.md`.

## Non-negotiable behavior

- The user-facing command is `/k-slide`.
- `/k-slide` with no arguments scans `.k-slide-input/`.
- Long content is written to files, not streamed into the terminal.
- The terminal must end with one of: `DONE`, `NEEDS REVIEW`, or `FAILED`.
- A complete run requires `RUN_COMPLETE.md` and all mandatory artifacts.
- If a run stops after `00`–`02`, it is Phase 1 only, not complete.
- Dense/multi-slide runs may intentionally stop after Phase 1 and ask the user to run `/k-slide-continue <run-folder>`.
- Every visible text/number/label/table/chart/visual relationship detected from the input must be covered, explained, translated, reconstructed, or explicitly marked unresolved.
- Do not invent unreadable text. Provide possible readings only when clearly labeled low confidence.
- Do not mutate the project glossary without explicit user approval through `/k-slide-glossary` or `/k-slide-correct`.

## Safety

Prefer project-local installation. Only write within `.k-slide-runs/` and explicit glossary/update files. Do not run arbitrary shell from agents. Helper shell scripts in this pack are deterministic setup/diagnostic utilities.
