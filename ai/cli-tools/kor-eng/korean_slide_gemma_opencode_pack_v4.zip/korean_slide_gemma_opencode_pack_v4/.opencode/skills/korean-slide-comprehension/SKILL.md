# Korean Slide Comprehension Skill v4

## Purpose

Convert Korean or Korean+English slide screenshots into English-native reports so a non-Korean reader fully understands the slide/deck without silently missing detected content.

## Main command

Use `/k-slide`. Do not rename it. `/k-slide` with no arguments scans `.k-slide-input/`.

## Core promise

Every detected item is either translated, explained, reconstructed, covered in the final report, or explicitly marked unresolved. Never claim unreadable pixels are known.

## Required workflow

1. Intake and inventory
2. Visual extraction
3. Layout and coverage
4. Translation audit
5. Visual/table/chart interpretation
6. English-native final report
7. Verification
8. One repair pass when useful
9. Completion sentinel

## Mandatory artifacts for complete max/default run

- `00_run_manifest.md`
- `00_input_inventory.json`
- `RUN_STATE.json`
- `01_extraction.json`
- `02_layout_coverage.json`
- `03_translation_audit.md`
- `04_visual_interpretation.md`
- `05_final_report.md`
- `06_verification.md`
- `07_unresolved_items.md`
- `08_coverage_ledger.md`
- `09_glossary_suggestions.json`
- `10_reader_quiz.md`
- `RUN_COMPLETE.md`

If any mandatory file is missing, the run is not complete.

## Phase gate

Default `/k-slide` may stop after Phase 1 and write `RUN_INCOMPLETE.md` when input is dense, low-confidence, multi-slide, or ambiguous. It must tell the user exactly what to review and to run: `/k-slide-continue <run-folder>`.

## Terminal policy

Long output goes to files. Terminal output is checkpoints and next action only. End with `DONE`, `NEEDS REVIEW`, or `FAILED`.

## Translation policy

For each Korean/mixed element: source Korean, literal English, natural business English, implied meaning, confidence, uncertainty. Preserve numbers, names, acronyms, dates, percentages, and units exactly.

## Coverage IDs

Use stable IDs: `T001`, `S001`, `B001`, `TB001-R01-C01`, `C001`, `A001`, `L001`, `V001`, `F001`, `N001`.

## Verification

Verification fails if detected coverage IDs are silently missing, numbers changed, visuals ignored, unsupported claims introduced, unreadable text guessed as fact, or final report is not understandable to a zero-Korean reader.

## Glossary

Use `references/glossary.seed.json` and `references/glossary.project.json`. Do not mutate project glossary without explicit approval.
