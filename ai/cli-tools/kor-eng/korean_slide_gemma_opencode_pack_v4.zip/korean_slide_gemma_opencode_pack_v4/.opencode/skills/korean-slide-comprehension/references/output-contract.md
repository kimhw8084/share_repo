# Output Contract

A complete run must create mandatory artifacts and `RUN_COMPLETE.md`. `05_final_report.md` must include status, inputs, summary, reconstruction, explanation, takeaways, visual explanation, Korean business terms, coverage summary, unresolved items, and next action. Terminal must end with DONE, NEEDS REVIEW, or FAILED.
