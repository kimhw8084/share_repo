# Prompt Passes

1. Extract visible content only.
2. Map layout and coverage IDs.
3. Translate literally and business-natively.
4. Interpret visuals.
5. Write final report.
6. Verify.
7. Repair once if appropriate.
