# Verification Checklist

- [ ] All mandatory files exist.
- [ ] `RUN_COMPLETE.md` exists only if complete.
- [ ] Every extracted coverage ID is covered or unresolved.
- [ ] Numbers, dates, units, percentages preserved exactly.
- [ ] Tables reconstructed or unreadable cells flagged.
- [ ] Charts/diagrams/arrows explained.
- [ ] Korean business terms are natural and faithful.
- [ ] No unsupported claims added.
- [ ] Unreadable text is not guessed as fact.
- [ ] Final report is understandable to a zero-Korean reader.
