# Workflow Contract v4

Default `/k-slide` scans `.k-slide-input/`, creates a real run folder via helper, writes artifacts after each phase, may gate dense input after Phase 1, and never claims complete without `RUN_COMPLETE.md`. Recovery: `/k-slide-status <run-folder>` then `/k-slide-continue <run-folder>`.
