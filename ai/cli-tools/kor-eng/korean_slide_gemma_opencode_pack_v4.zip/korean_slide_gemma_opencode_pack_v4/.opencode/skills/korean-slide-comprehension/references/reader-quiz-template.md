# Reader Quiz Template

1. What is the slide/deck mainly saying?
2. What decision/action/recommendation is implied?
3. What are the key numbers/dates/metrics?
4. What do the visuals show?
5. What Korean terms required interpretation?
6. What remains uncertain?
