# Evaluation Rubric

Score 0–100: coverage completeness, number preservation, translation faithfulness, English readability, visual explanation, uncertainty honesty, zero-Korean comprehension. Pass target for max mode: no critical misses and average >= 90.
