# Failure Modes

Only 00–02 exists = Phase 1 only. Run `/k-slide-status <run>` then `/k-slide-continue <run>`. Fake timestamp folders such as `140000` are invalid. Use `/k-slide`, not `/k-slide-inline`, to avoid long terminal streaming.
