# Run Folder Structure

```text
.k-slide-runs/<run-id>/
  00_run_manifest.md
  00_input_inventory.json
  RUN_STATE.json
  01_extraction.json
  02_layout_coverage.json
  03_translation_audit.md
  04_visual_interpretation.md
  05_final_report.md
  06_verification.md
  07_unresolved_items.md
  08_coverage_ledger.md
  09_glossary_suggestions.json
  10_reader_quiz.md
  RUN_COMPLETE.md | RUN_INCOMPLETE.md | RUN_FAILED.md
```
