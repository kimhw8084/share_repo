# Example Phase Gate Message

NEEDS REVIEW

Phase 1 extraction/layout is complete. Review `02_layout_coverage.json` and `07_unresolved_items.md`, then run `/k-slide-continue .k-slide-runs/<run-id>`.
