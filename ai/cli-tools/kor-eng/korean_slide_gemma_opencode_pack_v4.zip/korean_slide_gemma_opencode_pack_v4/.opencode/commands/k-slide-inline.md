---
description: Inline terminal output for tiny slides only; files still preferred.
agent: k-slide-orchestrator
subtask: false
---

Command setup output:
!`.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh inline $ARGUMENTS`

Run inline mode only for tiny inputs. If output would exceed about 80 lines, switch to artifact-first.

