---
description: Standard quality artifact-first run.
agent: k-slide-orchestrator
subtask: false
---

Command setup output:
!`.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh standard $ARGUMENTS`

Run standard mode using exactly the printed `RUN_DIR`. Verification is still required.

