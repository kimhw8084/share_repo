---
description: Source coverage, literal translation, confidence, and faithfulness audit.
agent: k-slide-orchestrator
subtask: false
---

Command setup output:
!`.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh audit $ARGUMENTS`

Run audit mode using exactly the printed `RUN_DIR`. Emphasize source extraction, literal translation, business translation, confidence, coverage IDs, and unresolved items.

