---
description: Verify an existing run folder for completeness and faithfulness.
agent: k-slide-orchestrator
subtask: false
---

User arguments: `$ARGUMENTS`

Status before verify:
!`.opencode/skills/korean-slide-comprehension/bin/status_run.sh $ARGUMENTS`

Verify existing run. Do not create a new folder. Write/update `06_verification.md` and `07_unresolved_items.md`; write/update `RUN_COMPLETE.md` only if complete.

