---
description: Check whether a run folder is complete, incomplete, or failed.
agent: input-run-manager
subtask: false
---

User arguments: `$ARGUMENTS`

Status output:
!`.opencode/skills/korean-slide-comprehension/bin/status_run.sh $ARGUMENTS`

Explain compactly. If incomplete, give `/k-slide-continue <run-folder>`. Do not do new slide analysis.

