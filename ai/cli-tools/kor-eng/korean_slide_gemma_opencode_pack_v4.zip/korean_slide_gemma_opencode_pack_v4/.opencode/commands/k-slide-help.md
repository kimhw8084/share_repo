---
description: Show quick help for the Korean slide comprehension workflow.
agent: input-run-manager
subtask: false
---

Show compact help for v4. Include: put images in `.k-slide-input/`, run `/k-slide`, open `05_final_report.md`, use `/k-slide-status` and `/k-slide-continue` if only 00–02 files exist.

