---
description: Review project glossary and pending suggestions.
agent: glossary-steward
subtask: false
---

Review project glossary and any referenced `09_glossary_suggestions.json`. Suggest updates. Do not mutate glossary without explicit approval.

