---
description: Fast artifact-first comprehension summary for a small slide.
agent: k-slide-orchestrator
subtask: false
---

Command setup output:
!`.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh quick $ARGUMENTS`

Run quick mode using exactly the printed `RUN_DIR`. Produce minimum viable artifacts and no hallucinated unreadable content.

