---
description: Diagnose installation and basic folder setup.
agent: input-run-manager
subtask: false
---

Doctor output:
!`.opencode/skills/korean-slide-comprehension/bin/doctor.sh`

Explain the doctor output in under 25 lines. If there is a problem, give the exact fix.

