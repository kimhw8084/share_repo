---
description: Explicit cleanup/archive workflow; never delete without confirmation.
agent: input-run-manager
subtask: false
---

Prepare a cleanup plan for `.k-slide-runs/` and `.k-slide-archive/`. Do not delete or move anything unless user explicitly confirms.

