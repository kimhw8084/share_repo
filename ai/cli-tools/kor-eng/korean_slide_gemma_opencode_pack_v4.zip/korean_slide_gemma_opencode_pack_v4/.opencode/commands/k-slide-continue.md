---
description: Resume a partial k-slide run from the next missing phase.
agent: k-slide-orchestrator
subtask: false
---

User arguments: `$ARGUMENTS`

Status before resume:
!`.opencode/skills/korean-slide-comprehension/bin/status_run.sh $ARGUMENTS`

Use the korean-slide-comprehension skill. Resume the existing run folder from the next missing phase. Do not create a new run folder. If `00`–`02` exist, resume at translation/visual interpretation. Terminal must end with DONE, NEEDS REVIEW, or FAILED.

