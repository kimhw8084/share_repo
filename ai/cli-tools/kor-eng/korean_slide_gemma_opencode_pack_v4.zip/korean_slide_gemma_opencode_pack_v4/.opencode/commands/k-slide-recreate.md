---
description: Produce English slide-ready copy and speaker notes.
agent: k-slide-orchestrator
subtask: false
---

Command setup output:
!`.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh recreate $ARGUMENTS`

Run recreate mode using exactly the printed `RUN_DIR`. Produce slide-ready English copy and speaker notes.

