---
description: Apply user corrections as glossary/report patch suggestions.
agent: k-slide-orchestrator
subtask: false
---

Use correction workflow mode. Read the referenced run folder and user correction. Produce patch/glossary suggestions. Do not mutate `glossary.project.json` unless user explicitly confirms.

