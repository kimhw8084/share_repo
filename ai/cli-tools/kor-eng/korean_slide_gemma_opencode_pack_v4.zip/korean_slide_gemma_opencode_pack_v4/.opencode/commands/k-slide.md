---
description: Max-quality artifact-first Korean/Korean+English slide comprehension. Scans .k-slide-input when no args are supplied.
agent: k-slide-orchestrator
subtask: false
---


You are running the v4 `/k-slide` workflow.

Command setup output:
!`.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh max $ARGUMENTS`

Use the `korean-slide-comprehension` skill and the command setup output above.

Hard contract:
- Use exactly the `RUN_DIR` printed above.
- If `NO_INPUT=1`, do not proceed; print `FAILED` and tell the user to put files in `.k-slide-input/` and run `/k-slide`.
- Artifact-first. Do not print the full report.
- Terminal output must stay compact and end with `DONE`, `NEEDS REVIEW`, or `FAILED`.
- Full completion requires all mandatory files plus `RUN_COMPLETE.md`.
- If Phase 1 should stop for review, write `RUN_INCOMPLETE.md` and print the exact `/k-slide-continue <RUN_DIR>` command.
- If the run is simple enough, continue end-to-end and create `RUN_COMPLETE.md`.
- Main command is `/k-slide`; do not rename it.

