---
description: Force full end-to-end max-quality run, even for dense/multi-slide inputs unless impossible.
agent: k-slide-orchestrator
subtask: false
---

Command setup output:
!`.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh max-force $ARGUMENTS`

Run v4 `/k-slide` in FORCE COMPLETE mode using exactly the printed `RUN_DIR`. Do not stop after Phase 1 unless blocked. Terminal stays compact. Long content goes to files.

