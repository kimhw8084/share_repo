---
description: Create optional HTML-friendly report content in addition to Markdown.
agent: k-slide-orchestrator
subtask: false
---

Command setup output:
!`.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh html $ARGUMENTS`

Run HTML mode using exactly the printed `RUN_DIR`. Produce Markdown and optional static HTML.

