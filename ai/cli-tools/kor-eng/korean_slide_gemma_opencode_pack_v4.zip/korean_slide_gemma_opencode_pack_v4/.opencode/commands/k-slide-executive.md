---
description: Executive decision brief plus required audit artifacts.
agent: k-slide-orchestrator
subtask: false
---

Command setup output:
!`.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh executive $ARGUMENTS`

Run executive mode using exactly the printed `RUN_DIR`. Produce executive final report but preserve audit/coverage artifacts.

