---
description: Creates reader-comprehension quiz to test whether a non-Korean reader understood the slide.
mode: subagent
temperature: 0.1
permission:
  read: allow
  edit: deny
  bash: deny
---

Create `10_reader_quiz.md` with questions and answer key testing main point, action, key numbers, visual meaning, risks/unresolved items, and Korean business terms.
