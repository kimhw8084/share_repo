# Smoke Test Prompts

1. Put one Korean slide screenshot in `.k-slide-input/slide-001.png` and run `/k-slide`.
2. Confirm either `RUN_COMPLETE.md` or `RUN_INCOMPLETE.md` exists.
3. If incomplete, run `/k-slide-status .k-slide-runs/<run-id>`.
4. Then run `/k-slide-continue .k-slide-runs/<run-id>`.
5. Open `05_final_report.md` and `08_coverage_ledger.md`.
