# Korean Slide Comprehension for OpenCode + Gemma 4 31B — v4

Turn Korean or Korean+English slide screenshots into English-native comprehension reports that a non-Korean speaker can understand immediately.

This pack is designed for an OpenCode environment whose main model brain is Gemma 4 31B. It does not require external OCR/translation APIs. It uses staged Gemma reasoning, strict artifact files, coverage ledgers, and verification.

## 5-minute quick start

### 1. Install into a project

```bash
unzip korean_slide_gemma_opencode_pack_v4.zip
cd korean_slide_gemma_opencode_pack_v4
./scripts/install_project.sh /path/to/your/project
```

### 2. Put slide images here

```text
/path/to/your/project/.k-slide-input/
```

Recommended filenames:

```text
slide-001.png
slide-002.png
slide-003.png
```

Supported by the workflow contract:

```text
.png, .jpg, .jpeg, .webp, .pdf
```

Images are the most reliable. PDFs are supported by instruction, but local OpenCode/model behavior may vary.

### 3. Start OpenCode

```bash
cd /path/to/your/project
opencode
```

### 4. Run

```text
/k-slide
```

With no arguments, `/k-slide` scans `.k-slide-input/`.

You can also pass files explicitly:

```text
/k-slide slide-001.png
/k-slide .k-slide-input/slide-001.png .k-slide-input/slide-002.png
/k-slide .k-slide-input/
```

### 5. Open the final report

```text
.k-slide-runs/<run-id>/05_final_report.md
```

A successful complete run also has:

```text
.k-slide-runs/<run-id>/RUN_COMPLETE.md
```

## What `/k-slide` produces

A complete max-quality run produces:

```text
.k-slide-runs/<run-id>/
  00_run_manifest.md
  00_input_inventory.json
  RUN_STATE.json
  01_extraction.json
  02_layout_coverage.json
  03_translation_audit.md
  04_visual_interpretation.md
  05_final_report.md
  06_verification.md
  07_unresolved_items.md
  08_coverage_ledger.md
  09_glossary_suggestions.json
  10_reader_quiz.md
  RUN_COMPLETE.md
```

The main file for normal users is `05_final_report.md`. The audit files are for quality control and debugging.

## Terminal behavior

The terminal is not the report. The terminal should show short phase checkpoints and file paths only.

Expected terminal outcome:

```text
DONE
Final report: .k-slide-runs/<run-id>/05_final_report.md
Verification: PASS
Unresolved items: 0
```

Or:

```text
NEEDS REVIEW
Phase 1 extraction/layout is complete.
Review: .k-slide-runs/<run-id>/02_layout_coverage.json
Then run: /k-slide-continue .k-slide-runs/<run-id>
```

Or:

```text
FAILED
Open: .k-slide-runs/<run-id>/RUN_FAILED.md
```

## If only `00`–`02` exist

That is **not** a complete run.

It means one of two things:

1. The workflow intentionally stopped after Phase 1 because the input was dense, low-confidence, or multi-slide.
2. The model/runtime stopped early.

Run:

```text
/k-slide-status .k-slide-runs/<run-id>
```

Then continue:

```text
/k-slide-continue .k-slide-runs/<run-id>
```

If the stop was intentional, review these first:

```text
02_layout_coverage.json
07_unresolved_items.md
08_coverage_ledger.md
```

Then continue.

## Commands

Main:

```text
/k-slide
```

Max-quality, artifact-first default. Scans `.k-slide-input/` when no path is provided.

Recovery:

```text
/k-slide-continue .k-slide-runs/<run-id>
/k-slide-status .k-slide-runs/<run-id>
/k-slide-doctor
```

Other modes:

```text
/k-slide-quick       Faster summary; less audit detail.
/k-slide-max         Force full end-to-end even for dense/multi-slide input.
/k-slide-audit       Literal translation + coverage focus.
/k-slide-executive   Executive/decision brief focus.
/k-slide-recreate    English slide-ready copy.
/k-slide-inline      Terminal output for tiny slides only.
/k-slide-verify      Verify an existing run.
/k-slide-correct     Apply user corrections as glossary/report patch suggestions.
/k-slide-glossary    Review or update glossary suggestions.
/k-slide-clean       Explicit cleanup/archive workflow.
/k-slide-help        Show usage help.
```

## Phase gates

`/k-slide` normally tries to finish end-to-end for a simple single slide.

It may intentionally stop after Phase 1 when:

```text
- More than 3 slides are detected.
- A slide has low OCR/extraction confidence.
- A slide has dense tables/charts.
- A slide has more than about 40 extracted elements.
- The screenshot looks thumbnail-like or blurry.
- Slide order is uncertain.
```

This is not a bug. It prevents compounding extraction mistakes into translation mistakes.

When it stops, it writes `RUN_INCOMPLETE.md` and tells the user exactly what to review and what command to run next.

To force end-to-end:

```text
/k-slide-max
```

## Quality promise

The tool should not claim it can magically read unreadable pixels.

The reliable promise is:

```text
Every detected item is either covered, translated, explained, reconstructed, or explicitly marked unresolved.
```

That is why the pack requires `02_layout_coverage.json`, `08_coverage_ledger.md`, `06_verification.md`, and `07_unresolved_items.md`.

## What the final report includes

`05_final_report.md` should include:

```text
1. Status banner: COMPLETE / NEEDS REVIEW / LOW CONFIDENCE
2. Deck or slide summary
3. English-native slide reconstruction
4. Plain-English explanation for non-Korean readers
5. Key takeaways and implications
6. Tables/charts/diagrams/arrows explanation
7. Korean business terms explained
8. Coverage summary
9. Unresolved or low-confidence items
10. Recommended next action
```

Korean source text belongs mainly in `03_translation_audit.md`, so the final report remains easy for English-only readers.

## Good input practice

Best:

```text
.k-slide-input/slide-001.png
.k-slide-input/slide-002.png
.k-slide-input/slide-003.png
```

Avoid:

```text
Screenshot 2026-06-29 at 2.00.00 PM.png
KakaoTalk_Photo_2026-06-29-final-final.png
image.png
```

If a screenshot contains multiple slide thumbnails, the tool may process it but should mark lower confidence. One slide per image is best.

## Install scripts

Project-local install:

```bash
./scripts/install_project.sh /path/to/your/project
```

Global install:

```bash
./scripts/install_global.sh
```

Use project-local first. Global install is only recommended after a smoke test.

Verify install:

```bash
./scripts/verify_install.sh /path/to/your/project
```

## Smoke test

After install:

1. Put one Korean slide image into `.k-slide-input/`.
2. Run `/k-slide`.
3. Confirm either `RUN_COMPLETE.md` or `RUN_INCOMPLETE.md` exists.
4. If incomplete, run `/k-slide-status .k-slide-runs/<run-id>` and `/k-slide-continue .k-slide-runs/<run-id>`.
5. Open `05_final_report.md` if complete.
6. Open `08_coverage_ledger.md` to confirm coverage.

## Troubleshooting

### Problem: run folder uses `140000` or a repeated fake time

That should not happen in v4. The helper script creates a real run ID before Gemma starts.

Expected:

```text
.k-slide-runs/kslide-20260629-153012-a4f2/
```

Invalid:

```text
.k-slide-runs/140000/
.k-slide-runs/<YYYYMMDD-HHMMSS>/
```

Run `/k-slide-doctor`.

### Problem: only `00`–`02` exist

Run:

```text
/k-slide-status .k-slide-runs/<run-id>
/k-slide-continue .k-slide-runs/<run-id>
```

### Problem: terminal keeps typing forever

Use the default `/k-slide`, not `/k-slide-inline`. Default behavior is artifact-first and terminal-quiet.

### Problem: glossary term is wrong

Run:

```text
/k-slide-correct .k-slide-runs/<run-id>
```

Then provide a correction such as:

```text
For this company, 고도화 should mean capability enhancement, not modernization.
```

The pack should suggest a glossary update instead of silently mutating it.

## Design philosophy

This is not a plain translator. It is a slide comprehension system.

The pipeline is:

```text
intake
→ extraction
→ layout and coverage
→ translation audit
→ visual/table/chart interpretation
→ English-native report
→ verification
→ one repair pass if needed
→ completion sentinel
```

This staged approach is designed to maximize Gemma 4 31B performance while minimizing missed content, false confidence, terminal latency, and user confusion.
