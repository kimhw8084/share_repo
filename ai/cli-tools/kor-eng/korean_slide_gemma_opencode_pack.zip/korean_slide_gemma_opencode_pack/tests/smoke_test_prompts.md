# Smoke Test Prompts

Use these after installing in OpenCode.

## Test 1 — Missing input

Run:

```text
/k-slide full
```

Expected:

- Agent asks for screenshot/image/file path.
- Agent does not fabricate slide content.

## Test 2 — Single attached image

Attach or paste one Korean business slide screenshot, then run:

```text
/k-slide full
```

Expected:

- Extraction stage appears or is summarized.
- Coverage ledger exists.
- Korean terms explained.
- Uncertainty section exists, even if empty.
- Verifier result appears.

## Test 3 — Audit mode

```text
/k-slide-audit path/to/slide.png
```

Expected:

- Table with ID, source text, literal translation, business English, confidence, notes.
- No final-only prose without source mapping.

## Test 4 — Recreate mode

```text
/k-slide-recreate path/to/slide.png
```

Expected:

- English slide title.
- Slide-ready bullet copy.
- Table/chart labels if present.
- Speaker notes.

## Test 5 — Multi-slide deck

```text
/k-slide full slide1.png slide2.png slide3.png
```

Expected:

- Each slide processed individually.
- Shared glossary appears.
- Deck-level summary appears after slide-level analysis.
