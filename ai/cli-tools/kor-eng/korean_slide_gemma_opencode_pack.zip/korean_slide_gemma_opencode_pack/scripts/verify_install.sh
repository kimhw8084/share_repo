#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-.}"
TARGET_DIR="$(cd "$TARGET" && pwd)"

required=(
  "AGENTS.md"
  ".opencode/commands/k-slide.md"
  ".opencode/agents/k-slide-orchestrator.md"
  ".opencode/agents/visual-extraction-agent.md"
  ".opencode/agents/layout-and-coverage-agent.md"
  ".opencode/agents/korean-business-translation-agent.md"
  ".opencode/agents/slide-verifier.md"
  ".opencode/skills/korean-slide-comprehension/SKILL.md"
  ".opencode/skills/korean-slide-comprehension/references/glossary.seed.json"
)

missing=0
for f in "${required[@]}"; do
  if [ ! -e "$TARGET_DIR/$f" ]; then
    echo "MISSING: $f"
    missing=1
  else
    echo "OK: $f"
  fi
done

if [ "$missing" -eq 1 ]; then
  echo "Install verification failed." >&2
  exit 1
fi

echo "Install verification passed."
