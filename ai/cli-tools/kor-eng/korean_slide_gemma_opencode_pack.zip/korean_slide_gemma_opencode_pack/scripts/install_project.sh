#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-}"
if [ -z "$TARGET" ]; then
  echo "Usage: ./scripts/install_project.sh /path/to/project" >&2
  exit 1
fi

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET_DIR="$(cd "$TARGET" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"

mkdir -p "$TARGET_DIR"

if [ -e "$TARGET_DIR/AGENTS.md" ]; then
  cp "$TARGET_DIR/AGENTS.md" "$TARGET_DIR/AGENTS.md.backup.$STAMP"
  echo "Backed up existing AGENTS.md to AGENTS.md.backup.$STAMP"
fi

if [ -e "$TARGET_DIR/.opencode" ]; then
  cp -R "$TARGET_DIR/.opencode" "$TARGET_DIR/.opencode.backup.$STAMP"
  echo "Backed up existing .opencode to .opencode.backup.$STAMP"
fi

cp "$SRC_DIR/AGENTS.md" "$TARGET_DIR/AGENTS.md"
mkdir -p "$TARGET_DIR/.opencode"
cp -R "$SRC_DIR/.opencode/agents" "$TARGET_DIR/.opencode/"
cp -R "$SRC_DIR/.opencode/commands" "$TARGET_DIR/.opencode/"
cp -R "$SRC_DIR/.opencode/skills" "$TARGET_DIR/.opencode/"

cat <<EOF
Installed Korean Slide Comprehension Pack into:
$TARGET_DIR

Next:
cd "$TARGET_DIR"
opencode

Then run:
/k-slide full path/to/slide.png
EOF
