#!/usr/bin/env bash
set -euo pipefail

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="$HOME/.config/opencode"
STAMP="$(date +%Y%m%d_%H%M%S)"

mkdir -p "$DEST/agents" "$DEST/commands" "$DEST/skills"

cp -R "$SRC_DIR/.opencode/agents/"* "$DEST/agents/"
cp -R "$SRC_DIR/.opencode/commands/"* "$DEST/commands/"
cp -R "$SRC_DIR/.opencode/skills/"* "$DEST/skills/"
cp "$SRC_DIR/AGENTS.md" "$DEST/AGENTS.korean-slide.md"

cat <<EOF
Installed agents, commands, and skills globally into:
$DEST

Copied global rules as:
$DEST/AGENTS.korean-slide.md

Manual step recommended:
Review and merge AGENTS.korean-slide.md into $DEST/AGENTS.md if you want these rules globally.
EOF
