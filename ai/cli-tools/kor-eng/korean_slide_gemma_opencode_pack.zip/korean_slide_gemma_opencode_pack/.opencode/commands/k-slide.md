---
description: Korean/Korean+English slide screenshot comprehension: full, executive, audit, or recreate mode.
agent: k-slide-orchestrator
subtask: true
---


Use the `korean-slide-comprehension` skill.

User arguments: `$ARGUMENTS`

Determine mode:
- If `$ARGUMENTS` begins with `executive`, use executive mode.
- If `$ARGUMENTS` begins with `audit`, use audit mode.
- If `$ARGUMENTS` begins with `recreate`, use recreate mode.
- Otherwise use full mode.

Input may be one or more attached screenshots, pasted images, or referenced local image/PDF/PPTX files.

Run the staged workflow:

1. Visual extraction
2. Layout and coverage mapping
3. Korean business translation
4. Korean context expansion
5. Table/chart/diagram interpretation
6. English-native reconstruction
7. Zero-Korean explanation
8. Verification
9. Final formatting

Use subagents when available:

- @visual-extraction-agent
- @layout-and-coverage-agent
- @korean-business-translation-agent
- @korean-context-expander
- @table-chart-interpreter
- @english-slide-rewriter
- @zero-korean-explainer
- @glossary-manager
- @slide-verifier
- @final-output-formatter

If subagent invocation is unavailable, perform the same steps sequentially under those role names.

Never produce a final answer until coverage IDs have been created and checked.

If no screenshot/image/file is present, ask for the screenshot or file path. Do not fabricate slide content.

