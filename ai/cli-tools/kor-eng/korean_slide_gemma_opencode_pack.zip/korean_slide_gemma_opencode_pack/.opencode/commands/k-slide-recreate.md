---
description: Recreate Korean slide screenshot as English slide-ready copy.
agent: k-slide-orchestrator
subtask: true
---


Use the `korean-slide-comprehension` skill in `recreate` mode.

User arguments: `$ARGUMENTS`

Input may be one or more attached screenshots, pasted images, or referenced local image/PDF/PPTX files.

Run the same staged workflow as `/k-slide`, but format the final answer for `recreate` mode.

Required pipeline:

Extract → Layout → Translate → Rewrite → Explain → Verify → Coverage ledger

If no screenshot/image/file is present, ask for the screenshot or file path. Do not fabricate slide content.

