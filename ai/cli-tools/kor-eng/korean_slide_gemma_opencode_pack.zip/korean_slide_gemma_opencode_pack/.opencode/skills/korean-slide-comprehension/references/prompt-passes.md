# Prompt Passes

Use these passes in sequence. Do not combine into one prompt unless the input is extremely simple.

## Pass 1 — Extract

```text
Extract every visible text and visual element from this Korean/Korean+English slide.

Do not translate.
Do not summarize.
Do not infer.

Assign coverage IDs.
Return source text exactly as visible.
Mark unreadable regions.
```

## Pass 2 — Layout

```text
Using the extraction and the slide image, map the slide structure.

Identify title, sections, bullets, tables, charts, diagrams, arrows, callouts, footnotes, and reading order.

Create a coverage ledger. Every extracted ID must be assigned a final destination.
```

## Pass 3 — Translate

```text
For each Korean or mixed Korean/English text element, produce:

- source text
- literal translation
- natural business English
- implied meaning
- confidence

Preserve numbers, dates, units, acronyms, and proper names exactly.
```

## Pass 4 — Interpret visuals

```text
Reconstruct tables, chart labels, legends, axes, arrows, process flows, and comparison structures in English.

Explain what the visual is saying and why it matters.
Do not invent hidden values.
```

## Pass 5 — English-native report

```text
Write the report so a non-Korean speaker fully understands the slide.

Include English-native slide reconstruction, plain-English explanation, key takeaway, visual explanation, Korean terms explained, coverage ledger, and uncertainties.
```

## Pass 6 — Verify

```text
Compare the final report against the extraction and coverage ledger.

Return PASS/FAIL and required fixes:
- missing IDs
- number/unit errors
- mistranslations
- hallucination risks
- inadequate uncertainty handling
```
