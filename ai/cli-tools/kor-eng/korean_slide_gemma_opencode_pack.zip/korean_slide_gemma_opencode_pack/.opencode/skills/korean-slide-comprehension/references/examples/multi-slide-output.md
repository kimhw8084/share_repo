# Example Multi-Slide Output

# Deck Summary

## Main message

The deck proposes improving an internal process by moving from manual, fragmented work to a standardized and partially automated workflow.

## Slide storyline

| Slide | Role in deck | Summary |
|---|---|---|
| 1 | Context | Current process has manual work and inconsistent execution. |
| 2 | Proposal | Target process introduces standard templates and automation. |
| 3 | Impact | Expected benefits are faster turnaround and fewer errors. |

---

# Slide 1 — Current Process Issues

## 1. English-native slide reconstruction
...

## 2. What this slide means
...

## 6. Coverage ledger
...

---

# Cross-slide glossary

| Korean | English used | Notes |
|---|---|---|
| 업무 표준화 | process standardization | Used consistently across slides. |
| 자동화 | automation | Preserved as automation. |
| 고도화 | process enhancement | Context is process maturity, not technical upgrade only. |
