# Korean Business Glossary Seed

Use this as a starting point. Context overrides the default.

| Korean | Preferred English | Avoid | Notes |
|---|---|---|---|
| 추진 | execute / implement / drive / carry forward | promote | Usually means moving an initiative forward, not marketing promotion. |
| 추진 방향 | strategic direction / implementation direction | promotion direction | Direction or approach for execution. |
| 고도화 | enhance / mature / upgrade / improve capability | advancement / heightening | Depends on object: system, process, model, capability. |
| 전사 | company-wide / enterprise-wide | warrior | In corporate context means entire company. |
| 고객사 | client company / customer organization | customer company | B2B customer organization. |
| 확보 | secure / ensure / obtain / establish | acquire always | Meaning depends on object. |
| 검토 | review / assess / evaluate | examine only | Business review/evaluation. |
| 검토 필요 | requires further review | review need | Not yet decided. |
| 대응 방안 | mitigation plan / response strategy / action plan | response plan only | Use based on issue/risk context. |
| 현황 | current status / current state | present condition | Often section title. |
| 개선 | improve / improvement | betterment | Use naturally. |
| 개선안 | improvement proposal | improvement idea | Proposed plan. |
| 과제 | initiative / task / challenge | homework | Context-dependent. |
| 목표 | target / goal | objective only | Metrics often use target. |
| 기대효과 | expected impact / expected benefits | expectation effect | Common slide section. |
| 리스크 | risk | - | Borrowed English. |
| 이슈 | issue | - | Borrowed English. |
| 매출 | revenue | sales amount sometimes | Finance/business context. |
| 영업이익 | operating profit | business profit | Finance term. |
| 비용 절감 | cost reduction | cost saving | Either okay. |
| 생산성 향상 | productivity improvement | productivity elevation | Natural business English. |
| 업무 표준화 | process standardization / work standardization | business standardization | Depends on context. |
| 운영 효율화 | improve operational efficiency | operational efficiency-ization | Needs verb. |
| 자동화 | automation | - | Preserve meaning. |
| 내재화 | internalize / bring in-house | immanentization | Often means building capability internally. |
| 외주 | outsource / external vendor | outside order | Context-dependent. |
| 협업 | collaboration | - | Usually cross-team/vendor cooperation. |
| 유관부서 | relevant departments / related teams | organic departments | Korean corporate term. |
| 담당자 | owner / person in charge | charger | Translate by context. |
| 일정 | schedule / timeline | date only | Timeline context. |
| 지연 | delay | - | Schedule risk. |
| 완료 | completed | complete | Status. |
| 진행 중 | in progress | progressing | Status. |
| 예정 | planned / scheduled | expected only | Future status. |
| 미정 | TBD / not yet decided | undecided | Use TBD in slide copy. |
| AS-IS | current state | - | Usually preserve AS-IS and explain if needed. |
| TO-BE | target/future state | - | Usually preserve TO-BE and explain if needed. |
