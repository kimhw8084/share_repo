# Evaluation Rubric

Score each output from 0 to 5.

## 1. Extraction completeness

5 = all visible text/visuals captured or marked unreadable.
3 = most main text captured, some labels missed.
1 = major sections missed.

## 2. Translation accuracy

5 = accurate Korean meaning and business context.
3 = understandable but literal/awkward in places.
1 = misleading or wrong.

## 3. English-native quality

5 = reads like original English business slide/report.
3 = understandable but translated-sounding.
1 = awkward or confusing.

## 4. Layout preservation

5 = hierarchy, tables, charts, arrows preserved.
3 = main hierarchy preserved but some visuals flattened.
1 = layout ignored.

## 5. Number/date/unit preservation

5 = exact.
3 = minor uncertainty flagged.
1 = errors or silent omissions.

## 6. Visual understanding

5 = chart/table/diagram meaning explained.
3 = labels translated but implication weak.
1 = visuals ignored.

## 7. Hallucination control

5 = no unsupported claims; uncertainty explicit.
3 = minor over-interpretation.
1 = invented facts/metrics.

## 8. Zero-Korean reader comprehension

5 = reader can answer what/why/so-what.
3 = reader gets general idea but misses details.
1 = reader still needs Korean speaker.

## Production acceptance target

- Average score >= 4.5
- No category below 4 for important slides
- Category 5 and 7 must be 5 or explicitly justified by uncertainty
