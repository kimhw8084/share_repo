# Example Single-Slide Output

# Slide 1 — 2026 Revenue Growth Strategy

## 1. English-native slide reconstruction

**Strategic Direction: Improve customer retention and expand revenue from existing accounts**

- Strengthen customer retention programs for existing clients.
- Improve product stickiness through deeper integration and service quality.
- Review pricing and renewal strategy for high-value accounts.

## 2. What this slide means

This slide says the company wants to grow revenue in 2026 mainly by keeping existing customers longer and increasing the value of each account. The Korean phrasing implies an implementation direction, not just a general idea.

## 3. Key takeaway

The main strategy is to protect and expand existing customer revenue rather than relying only on new customer acquisition.

## 4. Visual / table / chart / diagram explanation

The AS-IS / TO-BE structure compares the current customer management approach with the target approach. AS-IS means the current state; TO-BE means the desired future state.

## 5. Korean terms explained

| Source | Business English | Explanation | IDs |
|---|---|---|---|
| 추진 방향 | Strategic / implementation direction | The planned direction for execution. | T002 |
| 고객 락인 강화 | Improve customer retention and product stickiness | Borrowed term from “lock-in”; means reducing churn. | B001 |

## 6. Coverage ledger

| ID | Source element | Covered where | Status |
|---|---|---|---|
| T001 | 2026년 매출 성장 전략 | English title | Covered |
| B001 | 고객 락인 강화 | Reconstruction + glossary | Covered |
| V001 | AS-IS → TO-BE arrow | Visual explanation | Covered |

## 7. Uncertain or unreadable items

None detected.

## 8. Verifier result

PASS — all detected text and visual relationships are covered.
