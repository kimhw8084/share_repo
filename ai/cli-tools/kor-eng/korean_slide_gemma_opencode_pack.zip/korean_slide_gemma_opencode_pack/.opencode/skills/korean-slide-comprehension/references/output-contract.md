# Output Contract

## Full mode

```markdown
# Deck / Slide Summary

## Main message
...

## Key implications
...

---

# Slide N — English Title

## 1. English-native slide reconstruction
...

## 2. What this slide means
...

## 3. Key takeaway
...

## 4. Visual / table / chart / diagram explanation
...

## 5. Korean terms explained
| Source | Business English | Explanation | IDs |
|---|---|---|---|

## 6. Coverage ledger
| ID | Source element | Covered where | Status |
|---|---|---|---|

## 7. Uncertain or unreadable items
...

## 8. Verifier result
...
```

## Executive mode

```markdown
# Executive Summary

## Main message
...

## Key implications
...

## Decisions / actions / risks
...

## Important numbers
...

## Material uncertainties
...

## Slide-by-slide notes
...
```

## Audit mode

```markdown
# Translation Audit

| ID | Source text | Literal translation | Business English | Meaning | Confidence | Notes |
|---|---|---|---|---|---|---|
```

## Recreate mode

```markdown
# English Slide-Ready Copy

## Slide N Title
...

## Section headers
...

## Bullet text
- ...

## Tables
...

## Chart labels
...

## Speaker notes
...
```

## Status labels

Use these in coverage ledger:

- Covered
- Covered in visual explanation
- Covered in glossary
- Marked uncertain
- Unreadable
- Decorative/nonsemantic

## Confidence labels

- High: clear text and clear meaning
- Medium: clear text but ambiguous business meaning
- Low: unclear text or limited context
