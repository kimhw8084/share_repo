# Failure Modes and Required Behavior

## Blurry or tiny text

Behavior:
- Mark unreadable/low-confidence region.
- Provide partial reading only if clear.
- Do not guess.

## Dense table

Behavior:
- Reconstruct visible table structure.
- Mark uncertain cells individually.
- Do not summarize away rows/columns.

## Chart with unclear values

Behavior:
- Translate visible labels.
- Explain visible trend only if supported.
- Mark exact values uncertain if unreadable.

## Mixed Korean/English phrase

Behavior:
- Preserve English technical/business terms.
- Translate Korean around them.
- Explain combined meaning.

## Korean noun phrase sounds awkward in English

Behavior:
- Provide literal translation in audit.
- Use natural business English in final.

## Undefined acronym

Behavior:
- Preserve acronym.
- State "not defined on this slide".
- Do not invent expansion.

## Logo/company/product name

Behavior:
- Preserve as-is.
- Do not translate unless official English version is visible.

## Decorative shapes/colors

Behavior:
- Mark decorative only when clearly nonsemantic.
- If color indicates status/category, explain it.

## Contradiction between OCR-like reading and visual meaning

Behavior:
- Mark conflict.
- Use lower confidence.
- Do not hide the ambiguity.
