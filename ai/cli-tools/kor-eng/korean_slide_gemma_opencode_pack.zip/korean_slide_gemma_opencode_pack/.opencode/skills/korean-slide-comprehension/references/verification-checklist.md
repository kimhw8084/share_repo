# Verification Checklist

Before final output, verify every item below.

## Coverage

- [ ] Every extracted text ID appears in the coverage ledger.
- [ ] Every visual relationship ID appears in the coverage ledger.
- [ ] Every ID is covered, marked uncertain, or marked decorative/nonsemantic.
- [ ] No major section/header/bullet/table/chart is missing.

## Numbers and exact data

- [ ] Numbers are preserved exactly.
- [ ] Percentages are preserved exactly.
- [ ] Dates are preserved exactly.
- [ ] Units/currency are preserved exactly.
- [ ] Signs/arrows/increase/decrease indicators are preserved.

## Korean translation quality

- [ ] Korean business phrases are translated by meaning.
- [ ] Literal awkward translations are not used in final prose.
- [ ] Ambiguous terms have notes or uncertainty.
- [ ] Proper nouns and acronyms are preserved unless official translation is visible.

## Layout and visuals

- [ ] Table structure is reconstructed when visible.
- [ ] Chart title, axes, legends, and visible labels are handled.
- [ ] Arrows/process flows are explained.
- [ ] AS-IS/TO-BE or before/after structures are explained.
- [ ] Footnotes/callouts are handled.

## Hallucination control

- [ ] No invented text.
- [ ] No invented numbers.
- [ ] No invented causes or recommendations.
- [ ] Inferences are labeled.
- [ ] Unreadable regions are explicitly listed.

## Zero-Korean comprehension

- [ ] A reader with no Korean can explain the slide's main message.
- [ ] The reader can understand the table/chart/diagram.
- [ ] The reader can identify key numbers and implications.
- [ ] The reader can see what remains uncertain.
