---
name: korean-slide-comprehension
description: Use when the user provides Korean or Korean+English slide screenshots, slide images, PPT/PDF slide exports, or requests English-native understanding of Korean slide content. Produces extraction, translation, explanation, coverage ledger, and verification.
---

# Korean Slide Comprehension Skill

## Mission

Transform Korean/Korean+English slide screenshots into English-native comprehension reports.

The final output must allow a reader with zero Korean knowledge to understand:

1. what the slide says,
2. what each visible point means,
3. what numbers/tables/charts/visuals mean,
4. what Korean business shorthand implies,
5. what is uncertain or unreadable.

## Critical distinction

This is not a translation-only skill.

Translation is only one internal step. The full task is:

```text
Extract → Layout → Translate → Rewrite → Explain → Verify → Coverage ledger
```

## Non-negotiable laws

1. No direct screenshot-to-final translation.
2. No silent omissions.
3. No invented unreadable text.
4. No invented numbers, dates, units, trends, causes, or decisions.
5. Preserve every visible number/date/unit/acronym/symbol exactly.
6. Use coverage IDs for every detected text/visual element.
7. The final report must state what was uncertain.
8. For Korean business language, translate intent and usage, not dictionary words.
9. For tables/charts/diagrams, explain the visual argument, not just text labels.
10. For multi-slide input, verify each slide before producing deck-level synthesis.

## Required staged workflow

### Stage 1 — Visual extraction

Read the slide globally, then region by region.

Extract:

- Korean text
- English text
- mixed Korean/English terms
- numbers
- dates
- percentages
- units
- acronyms
- table headers/cells
- chart labels/legends/axes
- footnotes
- callouts
- arrows and visual relationships
- logos/proper names
- unreadable regions

Do not translate yet.

### Stage 2 — Layout and coverage

Create a slide structure:

- title
- subtitle
- sections
- bullets
- tables
- charts
- process flows
- comparisons
- footnotes
- visual relationships

Assign coverage IDs and create a coverage ledger.

### Stage 3 — Korean business translation

For each Korean/mixed element, produce:

- source text
- literal translation
- business-English translation
- implied meaning
- confidence

### Stage 4 — Context expansion

Explain Korean business shorthand that literal translation misses.

Examples:

- `추진 방향` → strategic / implementation direction
- `고도화` → enhance, mature, upgrade, or improve capability depending on object
- `검토 필요` → requires further review before decision
- `대응 방안` → mitigation plan / response strategy / action plan

### Stage 5 — Visual interpretation

For tables, charts, diagrams, and arrows:

- reconstruct the structure in English,
- preserve visible values exactly,
- explain what the visual compares/shows,
- explain business implication,
- mark uncertain cells/labels.

### Stage 6 — English-native reconstruction

Rewrite the slide as if it was originally written in English.

This is not literal translation. It must sound natural to a US/global business reader.

### Stage 7 — Zero-Korean explanation

Explain plainly:

- what this slide says,
- why it matters,
- key takeaway,
- important numbers,
- visual/table/chart meaning,
- implied decision/action/risk.

### Stage 8 — Verification

Before final output, verify:

- every coverage ID is covered or marked uncertain,
- numbers and units are exact,
- table/chart structure is preserved,
- no hallucinated facts were added,
- ambiguous Korean terms are handled correctly,
- the report is understandable to an English-only reader.

If verification fails, repair once. If failure is caused by unreadable input, final output must explicitly state the unresolved items.

## Default output format

```markdown
# Deck / Slide Summary

## Main message
...

## Key implications
...

---

# Slide 1 — English Title

## 1. English-native slide reconstruction
...

## 2. What this slide means
...

## 3. Key takeaway
...

## 4. Visual / table / chart / diagram explanation
...

## 5. Korean terms explained
| Source | Business English | Explanation | IDs |
|---|---|---|---|

## 6. Coverage ledger
| ID | Source element | Covered where | Status |
|---|---|---|---|

## 7. Uncertain or unreadable items
...

## 8. Verifier result
...
```

## Mode-specific outputs

### Full

Use full default output.

### Executive

Only include:

- main message,
- slide-by-slide key points,
- key implications,
- decisions/actions/risks,
- important numbers,
- material uncertainties.

### Audit

Include extraction and translation mapping:

```markdown
| ID | Source text | Literal translation | Business English | Meaning | Confidence | Notes |
|---|---|---|---|---|---|---|
```

### Recreate

Produce English slide-ready copy:

- title,
- section headers,
- bullet text,
- table text,
- chart labels,
- speaker notes.

## Reference files

Use these references when needed:

- `references/workflow-contract.md`
- `references/prompt-passes.md`
- `references/output-contract.md`
- `references/korean-business-glossary.md`
- `references/glossary.seed.json`
- `references/coverage-ledger-schema.json`
- `references/verification-checklist.md`
- `references/failure-modes.md`
- `references/evaluation-rubric.md`
