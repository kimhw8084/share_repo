# Workflow Contract

## Input contract

Accepted input:

- single slide screenshot
- multiple slide screenshots
- pasted/attached image
- local file path to image/PDF/PPT export, if OpenCode can access it
- Korean only or Korean+English mixed slides

If no input image/file exists, ask for one and stop.

## Processing contract

1. Visual extraction must happen before translation.
2. Layout mapping must happen before final explanation.
3. Coverage ledger must exist before final output.
4. Translation must include literal and business-English layers.
5. Visual interpretation must cover tables/charts/arrows/process flows.
6. Verification must run before final output.

## Output contract

Final report must make the slide understandable to a reader with zero Korean.

It must include either:

- coverage for every detected point, or
- explicit uncertainty/unreadable marker.

## Repair loop

If verifier returns FAIL:

1. Fix missing coverage IDs.
2. Fix number/unit mismatches.
3. Fix mistranslated Korean business terms.
4. Remove or label unsupported inference.
5. Re-run verification once.

If still failing due to image quality, final output must state limitations.
