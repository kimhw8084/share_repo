# Korean Slide Comprehension Pack for OpenCode + Gemma 4 31B

This pack turns OpenCode + Gemma 4 31B into a Korean/Korean+English slide-screenshot comprehension system.

The goal is **not** simple translation. The goal is:

> Any English-only reader should understand the Korean slide image as if the slide had originally been written in English, with no detected point silently skipped.

Professional guarantee:

- Every detected text/visual element must be covered in the report, or explicitly marked uncertain/unreadable.
- The system must preserve numbers, dates, units, acronyms, table structure, chart labels, arrows, and visual hierarchy.
- It must not invent unreadable text.

## What is inside

```text
AGENTS.md
.opencode/
  agents/
    k-slide-orchestrator.md
    visual-extraction-agent.md
    layout-and-coverage-agent.md
    korean-business-translation-agent.md
    korean-context-expander.md
    table-chart-interpreter.md
    english-slide-rewriter.md
    zero-korean-explainer.md
    glossary-manager.md
    slide-verifier.md
    final-output-formatter.md
    deck-synthesis-agent.md
  commands/
    k-slide.md
    k-slide-executive.md
    k-slide-audit.md
    k-slide-recreate.md
  skills/
    korean-slide-comprehension/
      SKILL.md
      references/
        workflow-contract.md
        prompt-passes.md
        output-contract.md
        coverage-ledger-schema.json
        glossary.seed.json
        korean-business-glossary.md
        verification-checklist.md
        failure-modes.md
        evaluation-rubric.md
        examples/
          single-slide-output.md
          multi-slide-output.md
opencode.example.jsonc
scripts/
  install_project.sh
  install_global.sh
  verify_install.sh
tests/
  smoke_test_prompts.md
```

## Design philosophy

This pack copies the high-ROI patterns used by strong document intelligence systems, but implements them as Gemma-only OpenCode instructions:

1. **Korean-first interpretation** — Korean business language is interpreted as Korean business language, not word-by-word translation.
2. **Mixed-language extraction first** — Korean, English, numbers, acronyms, symbols, and labels are extracted together.
3. **Region-aware visual parsing** — the model reads globally, then region by region, then merges.
4. **English-native reconstruction** — final output sounds like a US business slide/report, not machine-translated English.
5. **Fail-closed verification** — uncertain/unreadable content is flagged instead of guessed.
6. **Coverage ledger** — every detected point receives an ID and must be accounted for.

## Installation: per-project, safest

From inside the unzipped pack:

```bash
./scripts/install_project.sh /path/to/your/project
```

This copies:

```text
AGENTS.md → /path/to/your/project/AGENTS.md
.opencode/ → /path/to/your/project/.opencode/
```

If the target project already has `AGENTS.md` or `.opencode`, the installer creates timestamped backups before copying.

Then start OpenCode from that project root:

```bash
cd /path/to/your/project
opencode
```

Use:

```text
/k-slide full path/to/slide.png
/k-slide executive path/to/slide.png
/k-slide audit path/to/slide.png
/k-slide recreate path/to/slide.png
```

You can also paste or attach one or multiple screenshots in the OpenCode conversation, then run:

```text
/k-slide full
```

## Installation: global

Global install makes the commands/agents available across OpenCode sessions:

```bash
./scripts/install_global.sh
```

This copies:

```text
.opencode/agents/*   → ~/.config/opencode/agents/
.opencode/commands/* → ~/.config/opencode/commands/
.opencode/skills/*   → ~/.config/opencode/skills/
```

It also copies `AGENTS.md` as:

```text
~/.config/opencode/AGENTS.korean-slide.md
```

Do not automatically overwrite your global `~/.config/opencode/AGENTS.md`; merge manually if you want these rules globally.

## Model configuration

The agent files intentionally **do not set a model field**. They use whatever OpenCode model is already active.

Because your environment uses Gemma 4 31B as the only brain, leave the model fields omitted unless your OpenCode provider requires explicit model IDs.

If you need an example config, see:

```text
opencode.example.jsonc
```

Merge it manually into your existing `opencode.json` or `opencode.jsonc`. Do not blindly replace your production config.

## How to run

### Full comprehension report

```text
/k-slide full path/to/korean_slide.png
```

Returns:

- deck/slide summary
- English-native slide reconstruction
- plain-English explanation
- table/chart/diagram explanation
- Korean business terms explained
- coverage ledger
- uncertainty report
- verifier result

### Executive mode

```text
/k-slide-executive path/to/deck_or_slide.png
```

Returns:

- main message
- key implications
- decisions/risks/actions
- important numbers
- concise slide-by-slide notes

### Audit mode

```text
/k-slide-audit path/to/slide.png
```

Returns:

- extracted Korean/English source text
- literal translation
- business-English translation
- confidence
- coverage IDs
- uncertainty list

### Recreate mode

```text
/k-slide-recreate path/to/slide.png
```

Returns English slide-ready copy:

- title
- bullets
- table text
- chart labels
- speaker notes

## Important operating rule

Never ask Gemma to simply “translate this slide.”

Always force the staged pipeline:

```text
Extract → Layout → Translate → Rewrite → Explain → Verify → Coverage ledger
```

The coverage ledger is the anti-hallucination device. Without it, a model can sound fluent while silently skipping points.

## Expected limitations

This system is optimized for Gemma 4 31B, but screenshots can still be unreadable. The correct behavior is:

- Read everything visible.
- Mark low-confidence text.
- Do not invent small/blurred text.
- Ask for a higher-resolution image only when the missing region is material.

## Smoke test

After installing, run:

```bash
./scripts/verify_install.sh /path/to/your/project
```

Then use the prompts in:

```text
tests/smoke_test_prompts.md
```

## Recommended first real test

Use a single Korean slide screenshot that contains:

- title
- 3–5 bullets
- one small table or process arrow
- one mixed Korean/English phrase like `AS-IS / TO-BE`

Run:

```text
/k-slide full slide.png
```

A good output should let an English-only reader answer:

1. What is the slide saying?
2. What are the main points?
3. What do the numbers mean?
4. What do the visuals/tables/arrows mean?
5. What decision or implication does this slide support?
6. What was uncertain or unreadable?
