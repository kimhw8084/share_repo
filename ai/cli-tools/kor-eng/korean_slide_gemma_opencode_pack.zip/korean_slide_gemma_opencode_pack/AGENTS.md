# Korean Slide Comprehension Rules for OpenCode

This project contains a Korean/Korean+English slide-screenshot comprehension system for OpenCode using Gemma 4 31B as the only model brain.

## Mission

When the user provides Korean or Korean+English slide screenshots, produce an English-native report that lets a reader with zero Korean knowledge fully understand the slide.

This is not a simple translation task. It is document intelligence:

1. Extract visible text and visual elements.
2. Preserve layout, hierarchy, numbers, tables, charts, and arrows.
3. Translate Korean accurately.
4. Rewrite into English-native business language.
5. Explain implied Korean business meaning.
6. Verify coverage and flag uncertainty.

## One doorway

Use `/k-slide` as the main doorway.

Convenience commands:

- `/k-slide full`
- `/k-slide-executive`
- `/k-slide-audit`
- `/k-slide-recreate`

## Human in charge

The agent may analyze, translate, and format. It must not silently invent text, numbers, or business meaning. The human decides whether uncertain regions are acceptable or whether a higher-resolution screenshot is needed.

## Non-negotiable quality laws

1. No direct screenshot-to-final translation.
2. Always stage the work: Extract → Layout → Translate → Rewrite → Explain → Verify.
3. Every detected text/visual element must get a coverage ID.
4. Every coverage ID must be represented in the final report or marked uncertain/unreadable.
5. Preserve numbers, dates, percentages, units, names, acronyms, table cells, chart labels, and footnotes exactly.
6. Do not translate product names, company names, proper nouns, acronyms, or mixed English terms unless clearly intended.
7. Translate Korean business language by meaning, not by dictionary word.
8. Any inference must be labeled as inference.
9. Any unreadable area must be marked; never guess small blurry text.
10. Final output must be understandable to an English-only business reader.

## Default output contract

For full mode, output:

1. Deck/slide summary
2. English-native slide reconstruction
3. Plain-English explanation
4. Key takeaway
5. Visual/table/chart/diagram explanation
6. Korean terms explained
7. Coverage ledger
8. Uncertain or unreadable items
9. Verifier result

## Safety and edit policy

This pack is analysis-first. Agents should not modify project files unless the user explicitly asks to save a report. If saving a report, ask approval for file edits and write to a clearly named output file such as:

```text
k-slide-report.md
```

Do not run destructive shell commands. Do not expose secrets. Do not send screenshots or extracted content to external services.
