# Workflow Contract v3

## Default `/k-slide`

Mode: max
Output: artifact-first
Terminal: compact checkpoints only
Verification: mandatory
Repair: one loop if FAIL

## Stage artifacts

1. `00_run_manifest.md` — run settings, input list, mode, assumptions
2. `01_extraction.json` — visible text only, no translation
3. `02_layout_coverage.json` — layout map and coverage IDs
4. `03_translation_audit.md` — literal/natural/implied translations
5. `04_visual_interpretation.md` — tables, charts, diagrams, arrows
6. `05_final_report.md` — English-native comprehension report
7. `06_verification.md` — PASS/FAIL/PASS_WITH_UNRESOLVED_ITEMS
8. `07_unresolved_items.md` — unreadable/ambiguous items
9. `08_coverage_ledger.md` — ID-by-ID coverage proof
10. `09_glossary_suggestions.json` — reviewable term suggestions
11. `10_reader_quiz.md` — comprehension validation questions

## Success definition

An English-only reader can answer:

1. What is the slide/deck about?
2. What are the main points?
3. What numbers/dates/metrics matter?
4. What do the tables/charts/diagrams mean?
5. What decision, implication, risk, or recommendation is supported?
6. What Korean business terms required contextual explanation?
7. What is unresolved or uncertain?

## Failure definition

A run fails if it sounds fluent but silently skips visible points.
