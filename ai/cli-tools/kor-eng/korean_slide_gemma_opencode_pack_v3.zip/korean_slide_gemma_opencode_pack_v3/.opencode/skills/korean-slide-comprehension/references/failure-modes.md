# Known Failure Modes

## Fluent but incomplete

The model writes natural English but skips small text, footnotes, chart labels, or arrows.

Mitigation: strict coverage ledger.

## Literal Korean business translation

Examples:

- `추진 방향` → "promotion direction"
- `고도화` → "advancement"
- `전사` → "warrior"

Mitigation: glossary and implied-meaning layer.

## Number drift

The model changes 12.8% to 12.3% or drops units.

Mitigation: verification checks numbers/dates/units.

## Table hallucination

The model fills unreadable table cells.

Mitigation: unreadable cells must be flagged, not guessed.

## Visual relationship loss

The model translates text but misses arrows, before/after layout, color status, or dependency structure.

Mitigation: visual-table-chart-agent and V### coverage IDs.

## Terminal rendering bottleneck

The model streams too much text in OpenCode.

Mitigation: artifact-first output and terminal line budget.
