# Korean Slide Comprehension Skill v3

This skill governs Korean/Korean+English slide screenshot comprehension in OpenCode using Gemma 4 31B as the only brain.

## Prime directive

Your goal is not translation. Your goal is full English comprehension.

Make an English-only reader understand the slide/deck as if it had originally been written in English.

No detected visible point may be silently skipped.

## Supported inputs

- single slide screenshot
- multiple slide screenshots
- Korean-only slides
- Korean + English mixed slides
- image/PDF/PPTX paths if OpenCode can access them
- pasted or attached images if available in the runtime

Prefer one slide per image for best quality.

## Default mode

`/k-slide` means:

- max quality
- artifact-first
- terminal-quiet
- strict coverage
- mandatory verification
- one repair loop if verification fails

## Artifact-first law

Long work must go to files, not terminal.

Create a run folder:

`.k-slide-runs/<run-id>/`

Write artifacts as work progresses. Terminal output should only contain short checkpoints and final file paths.

## Required max-mode artifacts

- `00_run_manifest.md`
- `01_extraction.json`
- `02_layout_coverage.json`
- `03_translation_audit.md`
- `04_visual_interpretation.md`
- `05_final_report.md`
- `06_verification.md`
- `07_unresolved_items.md`
- `08_coverage_ledger.md`
- `09_glossary_suggestions.json`
- `10_reader_quiz.md`

## Staged workflow

### 1. Intake

Determine:

- input count and type
- slide order
- mode
- expected output
- run folder

Write `00_run_manifest.md`.

### 2. Visual extraction

Extract visible text only. Do not translate.

Include:

- Korean
- English
- mixed Korean-English
- numbers
- units
- dates
- percentages
- table cells
- chart labels
- legends
- axis labels
- footnotes
- page numbers
- callouts
- logos if meaningful

Write `01_extraction.json`.

### 3. Layout and coverage

Create stable coverage IDs.

Map:

- title
- subtitle
- sections
- bullets
- tables
- charts
- diagrams
- arrows
- process flows
- before/after relationships
- reading order
- visual groups

Write `02_layout_coverage.json` and `08_coverage_ledger.md`.

### 4. Translation audit

For every Korean/mixed item, produce:

- source text
- literal translation
- natural English business wording
- implied meaning
- confidence
- notes

Write `03_translation_audit.md` and `09_glossary_suggestions.json`.

### 5. Visual interpretation

For tables/charts/diagrams:

- reconstruct when readable
- explain what they mean
- preserve numbers exactly
- mark unreadable cells/labels
- explain visual relationships

Write `04_visual_interpretation.md`.

### 6. Final English-native report

Write `05_final_report.md`.

The report must include:

- confidence/unresolved summary
- deck-level summary if multiple slides
- slide-by-slide English-native reconstruction
- what each slide means
- what a non-Korean reader should understand
- key numbers and implications
- visual/table/chart explanation
- unresolved items summary
- files generated

### 7. Reader quiz

Write `10_reader_quiz.md` with questions a non-Korean reader should be able to answer after reading the report.

### 8. Verification

Write `06_verification.md` and `07_unresolved_items.md`.

Fail if:

- coverage IDs are missing
- visible numbers changed
- visible chart/table content ignored
- unsupported claims appear
- unreadable text is guessed as fact
- Korean business meaning is mistranslated or left awkward
- non-Korean reader comprehension is not achieved

### 9. Repair once

In max mode, if verification fails, repair once and re-verify.

Do not loop endlessly.

If image quality is the blocker, mark unresolved rather than guessing.

## Confidence scale

Use both label and numeric score:

- High: 85–100
- Medium: 60–84
- Low: below 60

## Translation style

Use balanced English-native rewriting:

- faithful to source
- natural business English
- not overly literal
- not over-invented

## Korean business terminology

Use `korean-business-glossary.md`, `glossary.seed.json`, and `glossary.project.json`.

Common examples:

- `추진` → drive / execute / implement / carry forward
- `고도화` → enhance / mature / upgrade / improve sophistication
- `검토` → review / assess / evaluate
- `대응` → respond / address / mitigation plan / response strategy
- `확보` → secure / ensure / obtain / establish
- `전사` → company-wide / enterprise-wide
- `유관부서` → relevant departments / stakeholder teams
- `정합성` → consistency / alignment / data integrity
- `내재화` → internalize / bring in-house / embed capability internally

## Hallucination policy

Never invent content from unreadable regions.

Allowed:

```text
Possible reading, low confidence: ...
Do not treat as confirmed.
```

Not allowed:

```text
The slide says X.
```

when X is unreadable or inferred without evidence.

## Terminal response policy

Final terminal response should be compact and include only:

- run folder
- final report path
- verification status
- unresolved count
- audit path
- coverage ledger path
- recommended next action

Never paste full artifacts into terminal unless inline mode was explicitly requested.
