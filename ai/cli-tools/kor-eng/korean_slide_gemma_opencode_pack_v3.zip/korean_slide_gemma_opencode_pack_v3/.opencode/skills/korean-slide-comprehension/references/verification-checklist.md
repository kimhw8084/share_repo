# Verification Checklist

Before final response, verify:

1. Every extracted element has a coverage ID or unresolved ID.
2. Every coverage ID is either covered or explicitly unresolved.
3. Every number, date, percentage, unit, currency, and metric is preserved exactly.
4. Every readable table is reconstructed or explained.
5. Every readable chart has axes/legend/trend/implication explained.
6. Every arrow/process/visual relationship is explained.
7. Korean business terms are not awkwardly literal.
8. English source terms/acronyms are preserved unless clearly defined otherwise.
9. Product/company/team names are preserved and explained if needed.
10. Low-confidence readings are labeled as low confidence.
11. Unreadable text is not guessed as fact.
12. Final report is understandable to a non-Korean reader.
13. Terminal output remains compact.
