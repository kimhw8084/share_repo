# Output Contract

## `05_final_report.md`

Required sections:

```markdown
# Korean Slide Comprehension Report

## Confidence and unresolved-item summary

## Deck-level summary

## Slide-by-slide report

### Slide N — English-native title

#### English-native slide reconstruction

#### What this slide means

#### What a non-Korean reader should understand

#### Key details, numbers, and implications

#### Visual/table/chart explanation

#### Business implication or likely decision support

#### Unresolved or low-confidence items

## Coverage summary

## Files generated
```

## `03_translation_audit.md`

Required columns or subsections:

- ID
- source text
- literal translation
- natural business English
- implied meaning
- confidence
- notes

## `08_coverage_ledger.md`

Required:

- every coverage ID
- source text or visual description
- status
- where covered
- unresolved reason if any

## `10_reader_quiz.md`

Include 5–12 questions a non-Korean reader should be able to answer after reading the final report.
