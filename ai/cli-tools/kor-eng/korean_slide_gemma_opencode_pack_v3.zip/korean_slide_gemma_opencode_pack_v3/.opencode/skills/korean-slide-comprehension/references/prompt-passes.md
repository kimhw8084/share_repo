# Prompt Passes

Use staged reasoning. Do not perform one-shot screenshot-to-final-report translation.

## Pass 1 — Extraction

Extract every visible text element. Do not translate, summarize, or infer.

Return JSON.

## Pass 2 — Layout and coverage

Map slide structure and assign coverage IDs. Include visual relationships.

## Pass 3 — Translation audit

For each Korean/mixed item, produce literal, natural business English, implied meaning, confidence, and notes.

## Pass 4 — Visual interpretation

Reconstruct readable tables. Explain charts, axes, legends, arrows, diagrams, colors, and process flows.

## Pass 5 — Final report

Write English-native report for zero-Korean readers.

## Pass 6 — Verification

Compare extraction + coverage + audit + visuals + final report. Fail on missing points or unsupported claims.

## Pass 7 — Repair

If max mode and FAIL, repair once. Do not loop endlessly.
