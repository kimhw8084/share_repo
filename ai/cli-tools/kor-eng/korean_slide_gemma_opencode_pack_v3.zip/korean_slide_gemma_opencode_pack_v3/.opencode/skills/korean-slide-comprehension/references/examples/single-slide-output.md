# Example Single-Slide Output Skeleton

# Korean Slide Comprehension Report

## Confidence and unresolved-item summary

Overall confidence: High / 91
Unresolved items: 1 low-confidence footer item.

## Slide-by-slide report

### Slide 1 — 2026 Revenue Growth Strategy

#### English-native slide reconstruction

**Strategic Direction:** Improve revenue growth by strengthening existing customer retention, expanding new account acquisition, and enhancing sales process visibility.

#### What this slide means

This slide explains the company’s 2026 sales growth plan. It separates the strategy into existing-customer retention, new-customer expansion, and operational improvements.

#### What a non-Korean reader should understand

The company is not only trying to sell more. It is trying to make sales execution more systematic and measurable.

#### Key details, numbers, and implications

- Revenue target: 15% YoY growth.
- Existing customer focus: retention and upsell.
- New customer focus: pipeline expansion.

#### Visual/table/chart explanation

The left-to-right arrow indicates movement from current ad-hoc sales activity to standardized pipeline management.

#### Business implication or likely decision support

The slide likely supports investment in sales process standardization and customer retention programs.

#### Unresolved or low-confidence items

- F001: small footer text is unreadable.

## Coverage summary

All required coverage IDs are covered or unresolved. See `08_coverage_ledger.md`.
