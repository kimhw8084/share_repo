# Evaluation Rubric

Score each run from 0–5 on each dimension.

1. Coverage completeness
2. OCR/extraction fidelity
3. Number/date/unit preservation
4. Korean-English translation accuracy
5. English-native readability
6. Korean business-context explanation
7. Table/chart/diagram explanation
8. Uncertainty honesty
9. Hallucination avoidance
10. Zero-Korean comprehension

## Passing score

- Minimum acceptable: 40/50
- Good: 44/50
- Excellent: 47/50+

## Critical fail regardless of score

- fabricated unreadable content
- missing key visible numbers
- missing main slide message
- silently skipped chart/table/diagram
