# Artifact-First Execution

Terminal rendering can become a bottleneck. Therefore:

- Write long artifacts to files immediately.
- Keep terminal checkpoints short.
- Do not stream final reports, JSON, coverage ledgers, or translation audits.
- If interrupted, partial files should remain useful.

## Checkpoint pattern

```text
[k-slide] Run folder: .k-slide-runs/<run-id>
[k-slide] Stage 1/7 extraction complete → 01_extraction.json
[k-slide] Stage 2/7 coverage mapped → 02_layout_coverage.json
[k-slide] Stage 3/7 translation audit complete → 03_translation_audit.md
[k-slide] Verification: PASS_WITH_UNRESOLVED_ITEMS
[k-slide] Final report: .k-slide-runs/<run-id>/05_final_report.md
```

## Max terminal budget

Default: 20 lines in the final answer.

## Inline exception

Only `/k-slide-inline` may print a full report, and only when the slide is small.
