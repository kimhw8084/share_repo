# Reader Quiz Template

After reading the report, a non-Korean reader should be able to answer:

1. What is the slide/deck about?
2. What is the main message?
3. What are the most important numbers, metrics, dates, or targets?
4. What does the table/chart/diagram show?
5. What visual relationships matter, such as arrows, process flow, or before/after structure?
6. What decision, risk, opportunity, or recommendation is implied?
7. Which Korean business terms required context beyond literal translation?
8. What remains uncertain or unreadable?

For each actual run, customize questions to the slide content.
