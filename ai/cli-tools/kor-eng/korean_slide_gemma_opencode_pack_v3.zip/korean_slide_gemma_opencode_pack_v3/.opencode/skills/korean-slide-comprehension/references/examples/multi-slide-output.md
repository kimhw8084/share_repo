# Example Multi-Slide Output Skeleton

# Korean Slide Comprehension Report

## Confidence and unresolved-item summary

Overall confidence: Medium-High / 84
Unresolved items: 4, mostly small table cells on Slide 3.

## Deck-level summary

This deck presents the current operational challenges, proposed improvement direction, expected impact, and rollout roadmap.

## Main message

The organization wants to move from manual, fragmented operations to standardized and more visible execution.

## Slide-by-slide report

### Slide 1 — Current Operational Challenges
...

### Slide 2 — Proposed Improvement Direction
...

### Slide 3 — Expected Impact and KPIs
...

## Cross-slide glossary

- 고도화 → process/system enhancement
- 전사 확산 → company-wide rollout
- 정합성 → data/process consistency

## Coverage summary

See `08_coverage_ledger.md`.
