# Korean Business Glossary Notes

This is a Korean business-slide glossary for Gemma-guided translation. Use context.

| Korean | Preferred English | Avoid | Notes |
|---|---|---|---|
| 추진 | drive, execute, implement, carry forward | promote | Means to advance/execute an initiative. |
| 추진 방향 | strategic direction, implementation direction | promotion direction | Depends on whether strategy or execution. |
| 고도화 | enhance, mature, upgrade, improve sophistication | advancement, heightening | Used for systems/processes/capabilities. |
| 검토 | review, assess, evaluate | examine only | Often means decision review. |
| 대응 | response, mitigation, action plan, address | confrontation | Context determines word. |
| 대응 방안 | response strategy, mitigation plan, action plan | response method | For risks/issues. |
| 확보 | secure, ensure, obtain, establish | acquire always | Object-dependent. |
| 전사 | company-wide, enterprise-wide | warrior | Business context. |
| 유관부서 | relevant departments, stakeholder teams | related department only | Often cross-functional. |
| 현황 | current status, current state | present condition | Often means baseline/current situation. |
| 개선 | improve, improvement | reform always | Process/product/metric improvement. |
| 과제 | initiative, task, workstream, challenge | homework | Business initiative/challenge. |
| 목표 | goal, target, objective | aim only | Metric or strategic target. |
| 성과 | performance, result, outcome | achievement only | Business result. |
| 리스크 | risk | — | Usually keep as risk. |
| 정합성 | consistency, alignment, coherence, data integrity | suitability | Context-specific. |
| 운영 | operations, operate, run | management always | Can be noun/verb. |
| 도입 | adoption, introduction, implementation | import | System/process adoption. |
| 확산 | rollout, expansion, scaling, diffusion | spread | Often means roll out across org. |
| 내재화 | internalize, bring in-house, embed internally | internalization only | Capability or process. |
| 자동화 | automation | — | Preserve context. |
| 표준화 | standardization | — | Process/data standardization. |
| 효율화 | efficiency improvement, streamline | efficiency-ization | Natural English required. |
| 가시화 | visualization, make visible, increase visibility | visibility-ization | Dashboard/reporting context. |
| 체계화 | systematize, structure, formalize | systematization only | Process/governance context. |
| 안정화 | stabilize, stabilization | — | System/process operations. |
| 연계 | integration, linkage, connection | link only | System/data/process integration. |
| 협업 | collaboration, cross-functional collaboration | cooperation only | Team context. |
| 장애 | incident, failure, outage, disruption | disability | IT/manufacturing context. |
| 품질 | quality | — | Preserve metrics/defect context. |
| 수율 | yield | — | Semiconductor/manufacturing. |
| 불량 | defect, defective item, failure | badness | Manufacturing quality. |
| 설비 | equipment, tool, facility | installation | Manufacturing context. |
| 공정 | process, manufacturing process | fairness | Manufacturing context. |
| 운영자 | operator | manager sometimes | Manufacturing/process context. |
| 엔지니어 | engineer | — | Preserve. |
| 고객사 | client company, customer company | customer company sometimes awkward | B2B context. |
| 매출 | revenue, sales | sales only if context | Finance context. |
| 영업이익 | operating profit | business profit | Finance term. |
