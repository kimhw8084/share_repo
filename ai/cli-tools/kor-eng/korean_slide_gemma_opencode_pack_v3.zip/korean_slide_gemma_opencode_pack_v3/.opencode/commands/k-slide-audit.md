---
description: Audit-focused Korean slide extraction, literal translation, and coverage report.
agent: k-slide-orchestrator
subtask: true
---

Use the `korean-slide-comprehension` skill.

User arguments: `$ARGUMENTS`

Run mode: `audit`.

Prioritize:

- source text extraction
- literal translation
- natural business English
- implied meaning
- confidence
- coverage ledger
- unresolved items

The final report may be shorter, but the audit must be detailed.
