---
description: Korean slide comprehension with optional standalone HTML final report.
agent: k-slide-orchestrator
subtask: true
---

Use the `korean-slide-comprehension` skill.

User arguments: `$ARGUMENTS`

Run mode: `html`.

Run max-quality artifact-first workflow and also create `optional_05_final_report.html` via @html-report-agent.
