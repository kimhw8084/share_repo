---
description: Fast artifact-first Korean slide comprehension summary.
agent: k-slide-orchestrator
subtask: true
---

Use the `korean-slide-comprehension` skill.

User arguments: `$ARGUMENTS`

Run mode: `quick`.

Produce a fast English comprehension report with uncertainty flags. Keep terminal short. Do not perform full audit depth unless needed.

Required artifacts:

- `00_run_manifest.md`
- compact `01_extraction.json`
- compact `05_final_report.md`
- `07_unresolved_items.md`
