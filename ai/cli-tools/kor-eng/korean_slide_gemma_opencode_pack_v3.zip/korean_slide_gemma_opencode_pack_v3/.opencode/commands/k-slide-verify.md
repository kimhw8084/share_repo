---
description: Verify an existing Korean slide comprehension run folder.
agent: slide-verifier-agent
subtask: true
---

Use the `korean-slide-comprehension` skill.

User arguments: `$ARGUMENTS`

Read the existing run folder and verify:

- extraction coverage
- final report coverage
- number/date/unit preservation
- translation quality
- visual/table/chart explanation
- unresolved item honesty

Write or update `06_verification.md` and `07_unresolved_items.md`.
