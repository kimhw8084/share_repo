---
description: Standard artifact-first Korean slide comprehension with verification.
agent: k-slide-orchestrator
subtask: true
---

Use the `korean-slide-comprehension` skill.

User arguments: `$ARGUMENTS`

Run mode: `standard`.

Artifact-first. Verification required. May combine some stages for speed but must still create extraction, coverage, final report, verification, unresolved items, and coverage ledger artifacts.
