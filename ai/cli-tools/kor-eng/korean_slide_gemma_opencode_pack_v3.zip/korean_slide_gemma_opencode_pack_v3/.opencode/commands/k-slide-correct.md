---
description: Apply user corrections to a prior Korean slide comprehension run.
agent: correction-workflow-agent
subtask: true
---

Use the `korean-slide-comprehension` skill.

User arguments: `$ARGUMENTS`

Use the referenced run folder and the user's correction text.

Create correction artifacts without overwriting originals unless explicitly asked:

- `11_corrections_received.md`
- `12_corrected_report_patch.md`
- updated `09_glossary_suggestions.json` if applicable
