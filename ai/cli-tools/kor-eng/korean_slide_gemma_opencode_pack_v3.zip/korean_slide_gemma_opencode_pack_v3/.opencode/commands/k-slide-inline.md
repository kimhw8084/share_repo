---
description: Inline terminal output for small Korean slide tasks only.
agent: k-slide-orchestrator
subtask: true
---

Use the `korean-slide-comprehension` skill.

User arguments: `$ARGUMENTS`

Run mode: `inline`.

This mode may print the report to terminal only if the content is small. If the slide is dense, switch back to artifact-first and explain why.
