---
description: Default max-quality artifact-first Korean/Korean+English slide comprehension.
agent: k-slide-orchestrator
subtask: true
---

Use the `korean-slide-comprehension` skill.

User arguments: `$ARGUMENTS`

Run mode: `max`.

Default behavior:

- Artifact-first.
- Terminal-quiet.
- Full staged pipeline.
- Mandatory verification.
- One repair loop if verification fails.
- Produce all core artifacts.

Input may be one or more image/PDF/PPTX paths, pasted images, or attachments.

Do not stream the full report to terminal. Write to `.k-slide-runs/<run-id>/` and show compact final paths only.
