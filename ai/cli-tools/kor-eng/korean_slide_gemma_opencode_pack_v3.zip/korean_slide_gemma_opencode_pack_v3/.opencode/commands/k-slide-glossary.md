---
description: Review glossary suggestions from a Korean slide comprehension run.
agent: glossary-steward
subtask: true
---

Use the `korean-slide-comprehension` skill.

User arguments: `$ARGUMENTS`

Review glossary suggestions from the referenced `.k-slide-runs/<run-id>/09_glossary_suggestions.json` or from pasted corrections.

Do not mutate `glossary.project.json` unless the user explicitly says to apply/approve the changes.
