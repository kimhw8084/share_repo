---
description: Explicit max-quality artifact-first Korean slide comprehension.
agent: k-slide-orchestrator
subtask: true
---

Use the `korean-slide-comprehension` skill.

User arguments: `$ARGUMENTS`

Run mode: `max`.

Run every stage:

1. manifest
2. extraction
3. layout/coverage
4. translation audit
5. visual interpretation
6. final report
7. verification
8. one repair loop if needed
9. final compact terminal summary

Produce all 10 core artifacts.
