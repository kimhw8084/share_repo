---
description: Produces English slide-ready copy from Korean/Korean+English slide screenshots.
agent: k-slide-orchestrator
subtask: true
---

Use the `korean-slide-comprehension` skill.

User arguments: `$ARGUMENTS`

Run mode: `recreate`.

Produce:

- English slide title
- slide-ready bullet copy
- translated table headers/cells when readable
- translated chart labels/legends when readable
- speaker notes explaining the slide
- unresolved items

Do not generate PPTX in v3. Produce Markdown artifacts suitable for manual slide recreation.
