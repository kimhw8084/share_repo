---
description: Executive-focused Korean slide/deck comprehension report.
agent: k-slide-orchestrator
subtask: true
---

Use the `korean-slide-comprehension` skill.

User arguments: `$ARGUMENTS`

Run mode: `executive`.

Produce artifact-first output focused on:

- main message
- key decisions
- risks/opportunities
- important numbers
- recommended action
- unresolved items

Still preserve audit/coverage artifacts so no point is silently skipped.
