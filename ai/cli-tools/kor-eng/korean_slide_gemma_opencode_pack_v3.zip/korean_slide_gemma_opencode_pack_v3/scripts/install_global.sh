#!/usr/bin/env bash
set -euo pipefail

TARGET="$HOME/.config/opencode"
mkdir -p "$TARGET/agents" "$TARGET/commands" "$TARGET/skills"
cp -R .opencode/agents/. "$TARGET/agents/"
cp -R .opencode/commands/. "$TARGET/commands/"
cp -R .opencode/skills/korean-slide-comprehension "$TARGET/skills/"

echo "Installed Korean Slide Comprehension Pack v3 globally into: $TARGET"
echo "Run opencode in any project and use: /k-slide path/to/slide.png"
