#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${1:-}"
if [[ -z "$PROJECT_DIR" ]]; then
  echo "Usage: ./scripts/install_project.sh /path/to/project" >&2
  exit 1
fi

if [[ ! -d "$PROJECT_DIR" ]]; then
  echo "Project directory does not exist: $PROJECT_DIR" >&2
  exit 1
fi

mkdir -p "$PROJECT_DIR/.opencode/agents" "$PROJECT_DIR/.opencode/commands" "$PROJECT_DIR/.opencode/skills"
cp -R .opencode/agents/. "$PROJECT_DIR/.opencode/agents/"
cp -R .opencode/commands/. "$PROJECT_DIR/.opencode/commands/"
cp -R .opencode/skills/korean-slide-comprehension "$PROJECT_DIR/.opencode/skills/"

if [[ -f "$PROJECT_DIR/AGENTS.md" ]]; then
  cp "$PROJECT_DIR/AGENTS.md" "$PROJECT_DIR/AGENTS.md.bak.$(date +%Y%m%d%H%M%S)"
fi
cp AGENTS.md "$PROJECT_DIR/AGENTS.md"

mkdir -p "$PROJECT_DIR/.k-slide-runs"

echo "Installed Korean Slide Comprehension Pack v3 into: $PROJECT_DIR"
echo "Run: cd '$PROJECT_DIR' && opencode"
echo "Then use: /k-slide path/to/slide.png"
