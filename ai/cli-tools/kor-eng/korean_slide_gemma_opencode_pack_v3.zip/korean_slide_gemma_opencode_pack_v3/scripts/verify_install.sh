#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${1:-.}"

missing=0
check_file() {
  local f="$PROJECT_DIR/$1"
  if [[ ! -f "$f" ]]; then
    echo "MISSING: $1"
    missing=1
  else
    echo "OK: $1"
  fi
}

check_file "AGENTS.md"
check_file ".opencode/commands/k-slide.md"
check_file ".opencode/commands/k-slide-quick.md"
check_file ".opencode/commands/k-slide-correct.md"
check_file ".opencode/agents/k-slide-orchestrator.md"
check_file ".opencode/agents/slide-verifier-agent.md"
check_file ".opencode/skills/korean-slide-comprehension/SKILL.md"
check_file ".opencode/skills/korean-slide-comprehension/references/glossary.seed.json"
check_file ".opencode/skills/korean-slide-comprehension/references/verification-checklist.md"

if [[ $missing -eq 0 ]]; then
  echo "Install verification PASS."
else
  echo "Install verification FAIL."
  exit 1
fi
