# Smoke Test Prompts

Use these after installing the pack.

## 1. Simple slide

```text
/k-slide-quick path/to/simple_korean_slide.png
```

Expected:

- compact report
- uncertainty flags if any
- no huge terminal stream

## 2. Max mode

```text
/k-slide path/to/korean_business_slide.png
```

Expected:

- `.k-slide-runs/<run-id>/` folder
- 10 core artifacts
- verification report
- compact terminal final answer

## 3. Audit mode

```text
/k-slide-audit path/to/korean_mixed_english_slide.png
```

Expected:

- source text
- literal translation
- natural business English
- implied meaning
- confidence

## 4. Recreate mode

```text
/k-slide-recreate path/to/slide.png
```

Expected:

- English slide-ready title
- English bullets
- chart/table labels if readable
- speaker notes

## 5. Verification of existing run

```text
/k-slide-verify .k-slide-runs/<run-id>
```

Expected:

- updated verification report
- unresolved items listed
