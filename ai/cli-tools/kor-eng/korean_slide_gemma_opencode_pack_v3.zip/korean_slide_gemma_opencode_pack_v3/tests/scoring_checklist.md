# Scoring Checklist

Score each run 0–5:

1. Coverage completeness
2. OCR/extraction fidelity
3. Number/date/unit preservation
4. Korean-English translation accuracy
5. English-native readability
6. Korean business-context explanation
7. Table/chart/diagram explanation
8. Uncertainty honesty
9. Hallucination avoidance
10. Zero-Korean comprehension

Target score for production use: 47/50+.

Critical failure if:

- unreadable text is guessed as fact
- key visible numbers are missing or changed
- the main slide message is wrong
- visual relationships are ignored
