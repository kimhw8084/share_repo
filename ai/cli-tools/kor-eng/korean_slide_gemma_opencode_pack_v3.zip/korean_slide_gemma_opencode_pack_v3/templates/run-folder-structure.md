# Run Folder Structure

```text
.k-slide-runs/<timestamp-slug>/
  00_run_manifest.md
  01_extraction.json
  02_layout_coverage.json
  03_translation_audit.md
  04_visual_interpretation.md
  05_final_report.md
  06_verification.md
  07_unresolved_items.md
  08_coverage_ledger.md
  09_glossary_suggestions.json
  10_reader_quiz.md
  optional_05_final_report.html
  11_corrections_received.md
  12_corrected_report_patch.md
```
