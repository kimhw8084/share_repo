# Korean Slide Comprehension Pack v3 — Project Rules

This project includes a Korean/Korean+English slide screenshot comprehension workflow for OpenCode with Gemma 4 31B.

## Prime directive

Make an English-only reader fully understand Korean or Korean+English slide screenshots as if the slides had originally been written in English.

Do not merely translate. Extract, map, translate, explain, verify, and write artifacts.

## Artifact-first law

Long outputs must be written to `.k-slide-runs/<run-id>/` files. Terminal output must stay compact.

Never stream full extraction JSON, coverage ledgers, translation audits, or final reports into the terminal unless the user explicitly runs `/k-slide-inline` or asks for inline output.

## Coverage law

Every detected visible text/number/label/table/chart/arrow/footnote/callout element must receive a coverage ID and must be either:

1. covered in the final report, or
2. listed in unresolved items with uncertainty reason.

No detected point may be silently skipped.

## Translation law

For Korean content, preserve three layers:

1. literal translation for audit,
2. natural English business wording,
3. implied meaning for a zero-Korean reader.

## Uncertainty law

Never invent unreadable text. If a possible reading is provided, label it as low confidence and not confirmed.

## Verification law

Max mode requires verification and one repair loop if verification fails.

## Permissions law

Agents may write only output artifacts and explicit glossary/correction files. Do not use shell execution inside the agent workflow unless the user explicitly asks.

## Default command

`/k-slide` means max-quality, artifact-first execution.
