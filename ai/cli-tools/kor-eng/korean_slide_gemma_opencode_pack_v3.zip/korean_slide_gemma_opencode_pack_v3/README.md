# Korean Slide Comprehension Pack v3 for OpenCode + Gemma 4 31B

This pack turns Korean or Korean+English slide screenshots into an English-native comprehension report for readers with **zero Korean knowledge**.

It is designed for your environment:

- **OpenCode** as the agent runtime
- **Gemma 4 31B** as the only model brain
- **Artifact-first output**, so OpenCode does not waste time streaming huge reports into the terminal
- **Strict coverage ledger**, so visible points are either covered or explicitly marked uncertain
- **Mandatory verification**, including one repair loop in max mode

The core idea is simple:

```text
Do not ask Gemma to “translate the slide” in one pass.
Force Gemma through a document-intelligence workflow:
extract → layout → coverage → translate → explain → verify → write artifacts.
```

## What v3 optimizes for

The goal is not just translation. The goal is:

> Any non-Korean reader should understand the slide as if it had originally been written in English, without silently missing any detected point.

Professional guarantee:

```text
No detected visible point is silently skipped.
Unreadable or ambiguous content is explicitly flagged.
```

No screenshot pipeline can guarantee it will read unreadable pixels. This pack instead guarantees the workflow will be honest: it covers what it can detect and flags what it cannot.

---

## Included files

```text
AGENTS.md
README.md
opencode.example.jsonc
.opencode/
  agents/
    k-slide-orchestrator.md
    visual-extraction-agent.md
    layout-coverage-agent.md
    korean-business-translation-agent.md
    visual-table-chart-agent.md
    english-native-report-agent.md
    slide-verifier-agent.md
    glossary-steward.md
    final-artifact-formatter.md
    deck-synthesis-agent.md
    html-report-agent.md
    correction-workflow-agent.md
  commands/
    k-slide.md
    k-slide-max.md
    k-slide-standard.md
    k-slide-quick.md
    k-slide-executive.md
    k-slide-audit.md
    k-slide-recreate.md
    k-slide-inline.md
    k-slide-html.md
    k-slide-glossary.md
    k-slide-verify.md
    k-slide-correct.md
  skills/
    korean-slide-comprehension/
      SKILL.md
      references/
        workflow-contract.md
        artifact-first-execution.md
        prompt-passes.md
        output-contract.md
        extraction-schema.json
        coverage-ledger-schema.json
        verification-checklist.md
        korean-business-glossary.md
        glossary.seed.json
        glossary.project.json
        failure-modes.md
        evaluation-rubric.md
        reader-quiz-template.md
        examples/
          single-slide-output.md
          multi-slide-output.md
scripts/
  install_project.sh
  install_global.sh
  verify_install.sh
tests/
  smoke_test_prompts.md
  scoring_checklist.md
templates/
  run-folder-structure.md
```

---

## Recommended install: per-project

Use per-project install first. It is safer than changing your global OpenCode config.

```bash
unzip korean_slide_gemma_opencode_pack_v3.zip
cd korean_slide_gemma_opencode_pack_v3
./scripts/install_project.sh /path/to/your/project
cd /path/to/your/project
opencode
```

Then run:

```text
/k-slide path/to/slide.png
```

`/k-slide` defaults to **max quality, artifact-first mode**.

---

## Optional global install

Use this only after testing per-project.

```bash
unzip korean_slide_gemma_opencode_pack_v3.zip
cd korean_slide_gemma_opencode_pack_v3
./scripts/install_global.sh
opencode
```

Global install copies agents, commands, and the skill into:

```text
~/.config/opencode/
```

---

## How to run

### Best default

```text
/k-slide path/to/slide.png
```

Same as max mode:

```text
/k-slide-max path/to/slide.png
```

### Faster modes

```text
/k-slide-standard path/to/slide.png
/k-slide-quick path/to/slide.png
```

### Output-specific modes

```text
/k-slide-executive path/to/slide.png
/k-slide-audit path/to/slide.png
/k-slide-recreate path/to/slide.png
/k-slide-html path/to/slide.png
```

### Terminal inline mode

Only for tiny slides:

```text
/k-slide-inline path/to/slide.png
```

### Verify or correct an existing run

```text
/k-slide-verify .k-slide-runs/20260629-151230-my-slide
/k-slide-correct .k-slide-runs/20260629-151230-my-slide
```

---

## What gets generated

Every artifact-first run creates a folder like:

```text
.k-slide-runs/<timestamp>-<slug>/
  00_run_manifest.md
  01_extraction.json
  02_layout_coverage.json
  03_translation_audit.md
  04_visual_interpretation.md
  05_final_report.md
  06_verification.md
  07_unresolved_items.md
  08_coverage_ledger.md
  09_glossary_suggestions.json
  10_reader_quiz.md
  optional_05_final_report.html
```

The terminal should stay compact:

```text
[k-slide] Run folder: .k-slide-runs/20260629-151230-market-plan
[k-slide] Stage 1/7 extraction complete
[k-slide] Stage 2/7 coverage mapped
[k-slide] Stage 3/7 translation audit complete
[k-slide] Verification: PASS
[k-slide] Final report: .k-slide-runs/.../05_final_report.md
```

The full report should be read from file, not streamed through the terminal.

---

## Quality modes

### Max mode

Default. Best for your goal.

```text
extract → layout/coverage → translation audit → visual interpretation → final report → verification → one repair loop if needed
```

Produces all 10 core artifacts.

### Standard mode

Still artifact-first, but can combine some stages.

Good for simple slides.

### Quick mode

Fast summary. Still flags uncertainty, but may not produce the full audit depth.

Use only when you need a fast read.

---

## Why artifact-first matters

If OpenCode streams a huge report to the terminal, terminal rendering can become slower than the model work itself. This pack prevents that by writing long content directly to files and showing only short terminal checkpoints.

If a run is interrupted, partial files should still exist.

---

## The coverage ledger

The key v3 feature is coverage IDs.

Examples:

```text
T001 = title
S001 = subtitle
B001 = bullet
TB001-R2C3 = table cell
C001 = chart title
AX001 = chart axis label
LG001 = legend label
V001 = arrow or visual relationship
F001 = footnote
N001 = note/callout
```

The final report should not silently skip an ID. If something is unreadable, it goes to:

```text
07_unresolved_items.md
```

and is referenced in:

```text
06_verification.md
```

---

## Glossary behavior

The pack includes a seeded Korean business glossary and an empty project glossary:

```text
.opencode/skills/korean-slide-comprehension/references/glossary.seed.json
.opencode/skills/korean-slide-comprehension/references/glossary.project.json
```

The agent should **not automatically mutate the project glossary** during ordinary runs. It should write suggestions to:

```text
09_glossary_suggestions.json
```

Review suggestions with:

```text
/k-slide-glossary .k-slide-runs/<run-id>
```

---

## Best input practices

For maximum accuracy:

```text
1. Use one slide per image when possible.
2. Use high-resolution screenshots.
3. Avoid thumbnail-grid screenshots for dense slides.
4. Keep filenames ordered naturally: slide01.png, slide02.png, slide03.png.
5. For multi-slide decks, pass all images in order or use ordered filenames.
```

The agent can still process imperfect screenshots, but it should mark lower confidence.

---

## What the final report contains

`05_final_report.md` should include:

```text
1. Warning banner if confidence is low
2. Deck summary if multiple slides
3. English-native slide reconstruction
4. What this slide means
5. What a non-Korean reader should understand
6. Key numbers / metrics / dates
7. Table, chart, and visual explanation
8. Business implications
9. Unresolved items summary
10. Links/paths to audit files
```

The Korean source text should primarily live in audit files, not the main report, so English-only readers are not overwhelmed.

---

## Verification standard

A run should fail verification if:

```text
- Extracted text IDs are missing from final output or unresolved list
- Visible numbers/dates/percentages/units are missing or changed
- Table/chart/diagram content is not reconstructed or explained
- Korean business terms are translated awkwardly without explanation
- The final report invents claims not grounded in the slide
- Unreadable text is guessed without being labeled as low confidence
```

Max mode performs one repair loop. If still failing due to image quality, the final report must say so.

---

## OpenCode model configuration

This pack intentionally does **not** hardcode a model ID. It uses your current OpenCode default model, which in your environment is Gemma 4 31B.

If your OpenCode setup requires explicit model names, copy `opencode.example.jsonc` and adapt the model field to your internal model ID.

---

## Test it

After installing:

```bash
./scripts/verify_install.sh /path/to/your/project
```

Then run smoke tests from:

```text
tests/smoke_test_prompts.md
```

Best first test:

```text
/k-slide-quick path/to/simple-korean-slide.png
```

Then test max mode:

```text
/k-slide path/to/dense-korean-business-slide.png
```

---

## Troubleshooting

### Problem: terminal is still streaming too much

Use:

```text
/k-slide path/to/slide.png
```

not inline mode. Then tell OpenCode:

```text
Do not print long artifacts. Write them to files and show only final paths.
```

The command and orchestrator already enforce this, but an explicit reminder can help if the runtime drifts.

### Problem: report is fluent but misses slide elements

Open:

```text
08_coverage_ledger.md
06_verification.md
```

If IDs are missing, run:

```text
/k-slide-verify .k-slide-runs/<run-id>
```

### Problem: Korean term is translated awkwardly

Add a correction through:

```text
/k-slide-correct .k-slide-runs/<run-id>
```

or manually update:

```text
.opencode/skills/korean-slide-comprehension/references/glossary.project.json
```

### Problem: tiny table text is wrong

Use a higher-resolution crop of the table or one slide per image. The system should flag uncertain cells, not guess.

---

## Design philosophy

This pack follows four laws:

```text
1. Artifact-first: write long work to files, not terminal.
2. Coverage-first: every detected point must be covered or flagged.
3. Translation is not enough: explain Korean business meaning in English-native language.
4. Fail closed: uncertainty must be visible, not hidden.
```
