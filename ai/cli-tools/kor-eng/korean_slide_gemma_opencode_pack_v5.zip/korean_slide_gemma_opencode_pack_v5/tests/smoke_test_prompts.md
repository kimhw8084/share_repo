# K-Slide v5 Smoke Tests

1. No input: empty `.k-slide-input/`, run `/k-slide`, expect `FAILED` with instructions.
2. Single image: put one image in `.k-slide-input/`, run `/k-slide`, expect `DONE` or `NEEDS REVIEW`.
3. Partial run: run `/k-slide-status <run>` then `/k-slide-continue <run>`.
4. Raw tool-call/gibberish: run `/k-slide-recover <run>`.
5. Doctor: run `/k-slide-doctor`.
