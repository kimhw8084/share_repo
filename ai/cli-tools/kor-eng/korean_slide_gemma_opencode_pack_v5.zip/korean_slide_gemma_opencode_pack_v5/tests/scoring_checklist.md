# K-Slide Quality Checklist

- Could a zero-Korean reader explain the slide's main point?
- Are all visible numbers/dates/units preserved?
- Are chart/table/process visuals explained?
- Are Korean business terms explained naturally?
- Are low-confidence/unreadable items clearly marked?
- Does `RUN_COMPLETE.md` exist only when artifacts validate?
- Are subagent claims verified by artifact reality?
