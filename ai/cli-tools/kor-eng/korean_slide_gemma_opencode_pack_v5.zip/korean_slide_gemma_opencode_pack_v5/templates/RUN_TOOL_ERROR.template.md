# FAILED — Tool execution problem, not translation failure

What happened:
- Category: `<FAILURE_CATEGORY>`
- Stage: `<STAGE>`
- Artifact: `<ARTIFACT>`

What was preserved:
- Source images were not modified.
- Run folder: `<RUN_DIR>`

Next:
```text
/k-slide-status <RUN_DIR>
/k-slide-continue <RUN_DIR>
```

If this repeats:
```text
/k-slide-recover <RUN_DIR>
/k-slide-safe <RUN_DIR>
/k-slide-doctor
```
