# K-Slide v5 Project Law

This project contains the K-Slide Korean/Korean+English slide-image comprehension pack for OpenCode with Gemma 4 31B as the only model brain.

## Prime directive
Make an English-only reader understand Korean/Korean+English slide images as if the slides had originally been written in English, while keeping the tool easy enough for any OpenCode user:

1. Put screenshots in `.k-slide-input/`.
2. Run `/k-slide`.
3. Open `.k-slide-runs/<run-id>/05_final_report.md`.

## Non-negotiable laws

1. The main command is `/k-slide`. Do not rename it.
2. Default `/k-slide` is smart mode: fast when safe, strict when needed, phase-gated when risky.
3. Artifact files are the source of truth. Chat/subagent claims are not source of truth.
4. A delegated subagent/skill closing out never means its task succeeded. Expected artifacts must be validated.
5. A run is complete only when `RUN_COMPLETE.md` exists and `RUN_STATE.json` says complete.
6. If a run stops, the user must get `DONE`, `NEEDS REVIEW`, or `FAILED` with exact next command.
7. Never stream long reports, JSON, translation tables, or coverage ledgers to the terminal.
8. Never silently skip a detected source item. Cover it, explain it, or mark it unresolved.
9. Never guess unreadable pixels as fact. Label possible readings as low confidence.
10. If any unexpected tool/read/write/edit/runtime behavior happens, stop normal work and give a friendly recovery path.

## Source of truth files

- `RUN_STATE.json`: machine-readable current state.
- `ARTIFACT_MANIFEST.json`: expected artifacts and validators.
- `VALIDATION_REPORT.json`: reality check of files and delegated tasks.
- `SUBAGENT_TASKS.json`: delegated task claims vs verified outputs.
- `RUN_RECOVERY_GUIDE.md`: what the user can do if anything stops.

## Completion rule
Do not say `DONE` unless all of these are true:

- `RUN_COMPLETE.md` exists.
- `RUN_STATE.json` says `status = complete`.
- Required artifacts exist and are non-placeholder.
- `VALIDATION_REPORT.json` says the required set passed.
- `06_verification.md` says `COMPLETE`.
- No required subagent task is `returned_unverified`, `failed`, or `abandoned`.
