---
description: Diagnose K-Slide installation, folders, helpers, and basic read/write capability.
agent: k-slide-recovery-manager
subtask: false
---

Run K-Slide doctor.

Doctor helper output:
!`.opencode/skills/korean-slide-comprehension/bin/doctor.sh`

Then perform one tiny model-file-tool smoke test if allowed:
- write `.k-slide-runs/.doctor/model_write_smoke.md` with one line: `model write smoke ok`
- read it back if possible

If any smoke test fails, do not continue into slide processing. Print friendly steps.
End with `DONE` if doctor passes, otherwise `FAILED`.
