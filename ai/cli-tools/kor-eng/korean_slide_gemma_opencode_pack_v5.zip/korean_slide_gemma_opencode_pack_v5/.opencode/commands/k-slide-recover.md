---
description: Recover from raw tool-call gibberish, unexpected exits, missing artifacts, or subagent false-completion.
agent: k-slide-recovery-manager
subtask: false
---

Recover a K-Slide run.

Recovery helper output:
!`.opencode/skills/korean-slide-comprehension/bin/recover_run.sh $ARGUMENTS`

Use the helper output and `korean-slide-comprehension` skill.

Recovery contract:
- Ignore terminal gibberish from previous attempts.
- Treat files + `RUN_STATE.json` + `ARTIFACT_MANIFEST.json` + `VALIDATION_REPORT.json` + `SUBAGENT_TASKS.json` as source of truth.
- Explain whether to continue, run safe mode, rerun, or doctor.
- End with `DONE`, `NEEDS REVIEW`, or `FAILED`.
