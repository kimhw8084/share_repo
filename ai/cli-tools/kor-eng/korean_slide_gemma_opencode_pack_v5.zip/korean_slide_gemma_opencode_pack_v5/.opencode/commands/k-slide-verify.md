---
description: Re-verify an existing K-Slide run.
agent: k-slide-verifier
subtask: false
---

Verify this K-Slide run:
!`.opencode/skills/korean-slide-comprehension/bin/status_run.sh $ARGUMENTS`

Use artifacts as source of truth. Check completion, coverage, placeholders, semantic verification, and subagent task validation. Update `06_verification.md` and `VALIDATION_REPORT.json` if possible. End with DONE / NEEDS REVIEW / FAILED.
