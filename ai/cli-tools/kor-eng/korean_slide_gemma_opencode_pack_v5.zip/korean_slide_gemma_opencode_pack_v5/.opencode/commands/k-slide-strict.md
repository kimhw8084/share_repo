---
description: Strict maximum-completeness Korean slide comprehension with detailed coverage/audit artifacts.
agent: k-slide-orchestrator
subtask: false
---

You are running K-Slide v5 strict mode.

Command setup output:
!`.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh strict $ARGUMENTS`

Strict mode contract:
- Maximize completeness over speed.
- Produce full extraction, layout, translation audit, visual interpretation, final report, verification, unresolved list, coverage ledger, glossary suggestions, and reader quiz.
- Use per-slide subfolders for dense/multi-slide input to keep writes small.
- Validate every delegated task and artifact before proceeding.
- End only with `DONE`, `NEEDS REVIEW`, or `FAILED`.
