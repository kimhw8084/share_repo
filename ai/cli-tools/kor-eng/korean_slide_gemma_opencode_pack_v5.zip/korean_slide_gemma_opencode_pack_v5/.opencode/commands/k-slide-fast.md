---
description: Fast Korean slide comprehension. Produces a compact report and escalates only when risk is detected.
agent: k-slide-orchestrator
subtask: false
---

You are running K-Slide v5 fast mode.

Command setup output:
!`.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh fast $ARGUMENTS`

Use the `korean-slide-comprehension` skill.

Fast mode contract:
- Target speed and usefulness.
- Generate `01_slide_understanding.json`, `05_final_report.md`, `06_verification.md`.
- If the slide is dense/low-confidence, stop with `NEEDS REVIEW`; do not force a bad fast answer.
- Use exact `RUN_DIR` from setup.
- End only with `DONE`, `NEEDS REVIEW`, or `FAILED`.
