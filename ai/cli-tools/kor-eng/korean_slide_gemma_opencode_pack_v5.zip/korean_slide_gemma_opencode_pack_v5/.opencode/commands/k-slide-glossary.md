---
description: Review K-Slide glossary seed, project glossary, and suggestions.
agent: glossary-steward
subtask: false
---

Review K-Slide glossary files and suggestions. Do not auto-apply suggestions without explicit user approval.

Input: $ARGUMENTS
