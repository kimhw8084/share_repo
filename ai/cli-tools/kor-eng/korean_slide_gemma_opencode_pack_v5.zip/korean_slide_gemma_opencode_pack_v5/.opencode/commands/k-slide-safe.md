---
description: Safe fallback mode for fragile tool-call environments. One slide or one phase at a time, small writes.
agent: k-slide-orchestrator
subtask: false
---

You are running K-Slide v5 safe mode.

Command setup output:
!`.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh safe $ARGUMENTS`

Safe mode contract:
- Use the smallest reliable artifact writes.
- Prefer one slide and one phase at a time.
- Phase-gate frequently.
- If any write/read/edit/tool issue occurs, stop immediately with `RUN_TOOL_ERROR.md` if possible and friendly terminal guidance.
- End only with `DONE`, `NEEDS REVIEW`, or `FAILED`.
