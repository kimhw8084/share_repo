---
description: Show concise K-Slide help.
agent: k-slide-recovery-manager
subtask: false
---

Show concise K-Slide v5 help:
- main command `/k-slide`
- put files in `.k-slide-input/`
- output in `.k-slide-runs/<run-id>/05_final_report.md`
- continue/status/recover/doctor commands
Keep it under 40 lines.
