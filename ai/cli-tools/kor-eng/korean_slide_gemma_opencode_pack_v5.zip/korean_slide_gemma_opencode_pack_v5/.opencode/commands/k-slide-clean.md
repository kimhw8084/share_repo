---
description: Explain safe cleanup for K-Slide runs and inputs.
agent: k-slide-recovery-manager
subtask: false
---

Explain safe cleanup. Do not delete anything without explicit user confirmation. Recommend archiving old run folders to `.k-slide-archive/`.
