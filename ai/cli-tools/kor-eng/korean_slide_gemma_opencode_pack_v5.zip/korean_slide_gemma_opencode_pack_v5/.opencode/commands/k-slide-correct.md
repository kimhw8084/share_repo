---
description: Apply user-approved terminology or report corrections to a K-Slide run.
agent: glossary-steward
subtask: false
---

Help the user correct terminology or report issues for a K-Slide run. Do not mutate `glossary.project.json` without explicit approval. Prefer writing suggestions to `09_glossary_suggestions.json`.

Input: $ARGUMENTS
