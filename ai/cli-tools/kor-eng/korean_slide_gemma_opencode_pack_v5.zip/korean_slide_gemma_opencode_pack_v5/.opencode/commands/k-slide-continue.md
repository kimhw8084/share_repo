---
description: Resume an incomplete K-Slide run from the next missing or invalid phase.
agent: k-slide-orchestrator
subtask: false
---

You are continuing an existing K-Slide v5 run.

Run status helper output:
!`.opencode/skills/korean-slide-comprehension/bin/status_run.sh $ARGUMENTS`

Use the `korean-slide-comprehension` skill.

Continue contract:
- Use the run folder reported by the helper.
- Read `RUN_STATE.json`, `ARTIFACT_MANIFEST.json`, `VALIDATION_REPORT.json`, and `SUBAGENT_TASKS.json`.
- Resume from the next missing/placeholder/invalid required phase.
- Do not restart from scratch unless the status says the run state is corrupt and the user explicitly chooses rerun.
- If `RUN_COMPLETE.md` is already valid, print `DONE` and the report path.
- End only with `DONE`, `NEEDS REVIEW`, or `FAILED`.
