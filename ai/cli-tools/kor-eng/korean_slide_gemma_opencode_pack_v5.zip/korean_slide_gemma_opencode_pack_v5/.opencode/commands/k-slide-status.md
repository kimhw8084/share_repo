---
description: Show deterministic status for a K-Slide run.
agent: k-slide-recovery-manager
subtask: false
---

Show the K-Slide run status.

Status helper output:
!`.opencode/skills/korean-slide-comprehension/bin/status_run.sh $ARGUMENTS`

Use the helper output as the source of truth. Do not invent state. Give a compact result with the exact next command.
