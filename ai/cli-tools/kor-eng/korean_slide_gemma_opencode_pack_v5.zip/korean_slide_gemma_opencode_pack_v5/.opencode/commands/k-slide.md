---
description: Smart artifact-first Korean/Korean+English slide comprehension. Scans .k-slide-input when no args are supplied.
agent: k-slide-orchestrator
subtask: false
---

You are running K-Slide v5 smart mode.

Command setup output:
!`.opencode/skills/korean-slide-comprehension/bin/prepare_run.sh smart $ARGUMENTS`

Use the `korean-slide-comprehension` skill and the setup output above.

Hard contract:
- Main command is `/k-slide`; do not rename it.
- Use exactly the `RUN_DIR` printed above.
- If `NO_INPUT=1`, do not process slides. End `FAILED` with simple instructions to add files to `.k-slide-input/` or pass a path.
- Normal/simple slides should finish end-to-end quickly.
- Dense, low-confidence, or >3-slide input should phase-gate after Phase 1 with `NEEDS REVIEW` and exact `/k-slide-continue <RUN_DIR>`.
- Do not stream long reports, JSON, ledgers, or translation tables.
- If any tool/read/write/edit/subagent error happens, use the v5 recovery protocol.
- `DONE` is allowed only after `RUN_COMPLETE.md` exists and required artifacts validate.
