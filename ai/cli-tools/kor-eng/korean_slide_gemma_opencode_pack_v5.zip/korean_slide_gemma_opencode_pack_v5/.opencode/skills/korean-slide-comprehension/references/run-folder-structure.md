# Run Folder Structure

Default root files:

```text
00_run_manifest.md
00_input_inventory.json
RUN_STATE.json
RUN_RECOVERY_GUIDE.md
ARTIFACT_MANIFEST.json
VALIDATION_REPORT.json
SUBAGENT_TASKS.json
SUBAGENT_STATUS.md
01_slide_understanding.json
01_extraction.json
02_layout_coverage.json
03_translation_audit.md
04_visual_interpretation.md
05_final_report.md
06_verification.md
07_unresolved_items.md
08_coverage_ledger.md
09_glossary_suggestions.json
10_reader_quiz.md
```

Dense/multi-slide strict runs may create `slides/slide-001/`, etc.
