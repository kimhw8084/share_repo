# Reader Quiz Template

1. What is the main message of the slide/deck?
2. What action or decision does it support?
3. What numbers/metrics matter?
4. What does the table/chart/process flow show?
5. Which items were unresolved or low-confidence?
