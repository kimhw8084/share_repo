# Verification Rubric

Score 0-100:
- Coverage completeness
- Number/date/unit preservation
- Translation faithfulness
- English readability
- Visual/table/chart explanation
- Uncertainty honesty
- Zero-Korean comprehension

Fail if required artifacts are missing/placeholder, source items are silently skipped, numbers changed, or subagent tasks are unverified.
