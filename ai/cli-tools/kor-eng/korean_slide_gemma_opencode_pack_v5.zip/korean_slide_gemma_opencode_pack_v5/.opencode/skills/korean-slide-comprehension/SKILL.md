# Korean Slide Comprehension Skill v5

## Purpose
Turn Korean or Korean+English slide images into English-native reports that allow a zero-Korean reader to understand the slides immediately.

## Core product promise
Every detected source item is either:

1. covered in the report,
2. translated/explained in an audit artifact,
3. reconstructed as table/chart/visual meaning, or
4. explicitly marked unresolved/low-confidence.

Do not promise to read unreadable pixels.

## Main command
The main command is `/k-slide`.

## Modes

Smart mode (`/k-slide`): fast when safe, strict when needed, phase-gated when risky.
Fast mode (`/k-slide-fast`): optimized for normal slides.
Strict mode (`/k-slide-strict`): maximum completeness.
Safe mode (`/k-slide-safe`): one slide/phase at a time, smallest writes.

## Mandatory run files
Created at setup:
- `00_run_manifest.md`
- `00_input_inventory.json`
- `RUN_STATE.json`
- `RUN_RECOVERY_GUIDE.md`
- `ARTIFACT_MANIFEST.json`
- `VALIDATION_REPORT.json`
- `SUBAGENT_TASKS.json`
- `SUBAGENT_STATUS.md`

Fast artifacts:
- `01_slide_understanding.json`
- `05_final_report.md`
- `06_verification.md`

Strict/risky artifacts:
- `01_extraction.json`
- `02_layout_coverage.json`
- `03_translation_audit.md`
- `04_visual_interpretation.md`
- `07_unresolved_items.md`
- `08_coverage_ledger.md`
- `09_glossary_suggestions.json`
- `10_reader_quiz.md`

Completion sentinel: `RUN_COMPLETE.md`.
Failure/review sentinels: `RUN_INCOMPLETE.md`, `RUN_FAILED.md`, `RUN_TOOL_ERROR.md`.

## Delegated Work Verification Law
Any subagent, skill, or delegated process may claim completion, but the orchestrator must treat that claim as unverified until all expected artifacts pass acceptance checks.

A delegated task may be: `assigned`, `running`, `returned_unverified`, `verified_complete`, `needs_review`, `failed`, `tool_error`, `abandoned`.

`returned_unverified` is not complete.

## Risk classifier
Use `FAST_OK` for a single clear readable slide.
Use `STRICT_NEEDED` for dense table/chart/process slides, tiny Korean text, important numbers, or many visual relationships.
Use `PHASE_GATE_NEEDED` for more than 3 slides, very dense/low-confidence input, ambiguous order, or large deck review.
Use `INPUT_TOO_LOW_QUALITY` when text is unreadable enough that a report would be misleading.

## Output style
Final report must be English-native, not literal machine translation.

Include:
1. Executive summary.
2. English-native slide reconstruction.
3. What a zero-Korean reader should understand.
4. Key numbers/metrics.
5. Tables/charts/visual relationships.
6. Important Korean business terms explained.
7. Unresolved/low-confidence items.
8. Coverage summary.

## Korean business translation rules
Use literal translation only for audit. The final report should use natural business English.

Examples:
- `추진` → drive / execute / implement, not usually “promote”.
- `고도화` → enhance / mature / upgrade / improve capability, depending on object.
- `전사` → company-wide, not warrior.
- `검토 필요` → requires further review before decision.
- `대응 방안` → mitigation plan / response strategy / action plan.
- `확보` → secure / ensure / obtain / establish based on object.

Preserve English terms/acronyms unless they need explanation.

## Tool-error protocol
If any read/write/edit/tool/subagent issue occurs:
1. Stop normal work.
2. Do not dump raw tool syntax.
3. Retry at most once if the fix is obvious and smaller/simpler.
4. If still failing, write `RUN_TOOL_ERROR.md` if possible.
5. Print a friendly recovery guide.
6. End `FAILED` or `NEEDS REVIEW`.

If you cannot write recovery files, print exactly:

```text
FAILED — I could not safely write recovery files.

Run:
 /k-slide-doctor

Then restart OpenCode with:
 opencode --log-level DEBUG

Check logs:
 ~/.local/share/opencode/log/
```

## Write-size rules
Avoid giant artifact writes. Keep each artifact write under roughly 12,000 characters or 250 lines. For dense decks, use `slides/slide-###/` subfolders. Do not stream long content to terminal.

## Final-state rules
Terminal final status must be exactly one of: `DONE`, `NEEDS REVIEW`, `FAILED`.

`DONE` requires `RUN_COMPLETE.md` and successful validation.
`NEEDS REVIEW` requires `RUN_INCOMPLETE.md` and exact continue command.
`FAILED` requires `RUN_FAILED.md`, `RUN_TOOL_ERROR.md`, or clear terminal last-resort failure guidance.
