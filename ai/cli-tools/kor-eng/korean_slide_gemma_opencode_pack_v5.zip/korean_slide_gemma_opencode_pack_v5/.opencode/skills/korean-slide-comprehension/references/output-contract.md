# Final Report Contract

`05_final_report.md` should be readable by someone with zero Korean.

Structure:
1. Status banner.
2. Executive summary.
3. English-native slide/deck reconstruction.
4. What this means in plain English.
5. Key numbers and metrics.
6. Tables/charts/process flows explained.
7. Korean business terms explained.
8. Unresolved/low-confidence items.
9. Coverage summary.
10. Where to find audit/verification files.
