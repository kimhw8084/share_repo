# Artifact Acceptance Rules

A file is not valid if it is missing, empty, placeholder-only, malformed, or missing required sections.

Fast path:
- `01_slide_understanding.json`: run_id, mode, risk_classification, slides, detected items or unresolved reason.
- `05_final_report.md`: summary, English-native reconstruction, zero-Korean explanation, unresolved summary, coverage summary.
- `06_verification.md`: final status, coverage score, number preservation score, translation faithfulness score, unresolved count.

Strict path:
- `01_extraction.json`: extracted elements or clear unreadable reason.
- `02_layout_coverage.json`: reading order, visual groups, coverage IDs, unresolved regions.
- `03_translation_audit.md`: source IDs to literal/business English/implied meaning.
- `08_coverage_ledger.md`: every detected item covered or unresolved.
