# K-Slide Failure Taxonomy

- `NO_INPUT`: no supported files found.
- `BAD_INPUT_PATH`: supplied path does not exist.
- `FILE_NOT_READABLE`: input exists but cannot be read.
- `LOW_IMAGE_QUALITY`: text too blurry/tiny for reliable reading.
- `TOOL_READ_FAILED`: OpenCode read tool failed.
- `TOOL_WRITE_FAILED`: OpenCode write tool failed.
- `TOOL_EDIT_FAILED`: OpenCode edit/patch failed.
- `RAW_TOOLCALL_LEAK`: raw tool-call text appeared in output.
- `RUN_STATE_CORRUPT`: state file invalid or inconsistent.
- `MISSING_ARTIFACTS`: expected artifacts missing or placeholder.
- `PERMISSION_BLOCKED`: permission/config blocked a required tool.
- `MODEL_STOPPED_EARLY`: model returned before required artifacts were valid.
- `SUBAGENT_RETURNED_UNVERIFIED`: delegated task returned but output validation failed.
- `VERIFICATION_FAILED`: semantic verification failed.
- `UNKNOWN_RUNTIME_ERROR`: otherwise unknown runtime problem.

Each user-facing error must include what happened, what was preserved, exact next command, and when to use `/k-slide-doctor`.
