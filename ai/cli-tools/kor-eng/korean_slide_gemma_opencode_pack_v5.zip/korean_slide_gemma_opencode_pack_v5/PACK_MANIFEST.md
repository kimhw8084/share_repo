# K-Slide v5 Pack Manifest

Version: v5 optimized-smart, fail-soft, resumable.

## Major changes from v4

- Main command remains `/k-slide`.
- Default mode is smart/optimized, not always strict.
- Deterministic setup pre-creates run folders, placeholders, state, recovery guide, and manifests.
- Added `RUN_STATE.json`, `ARTIFACT_MANIFEST.json`, `VALIDATION_REPORT.json`, `SUBAGENT_TASKS.json`, and `SUBAGENT_STATUS.md`.
- Added delegated-work verification law: subagent closure is never success by itself.
- Added friendly failure taxonomy and recovery protocols.
- Added `/k-slide-fast`, `/k-slide-strict`, `/k-slide-safe`, `/k-slide-recover`.
- Added chunking and small-artifact rules to reduce write/tool-call failure risk.
- Added phase-gate behavior for dense/multi-slide/low-confidence input.
- Added stronger doctor/status/recover helpers.

## Commands

- `/k-slide`
- `/k-slide-fast`
- `/k-slide-strict`
- `/k-slide-safe`
- `/k-slide-continue`
- `/k-slide-status`
- `/k-slide-recover`
- `/k-slide-doctor`
- `/k-slide-help`
- `/k-slide-clean`
- `/k-slide-verify`
- `/k-slide-correct`
- `/k-slide-glossary`

## Core agents

- `k-slide-orchestrator`
- `k-slide-fast-reader`
- `k-slide-strict-reader`
- `k-slide-reporter`
- `k-slide-verifier`
- `k-slide-recovery-manager`
- `table-chart-specialist`
- `glossary-steward`

## Install

Use project install first:

```bash
./scripts/install_project.sh /path/to/project
```
