# K-Slide v5 — OpenCode Korean Slide Comprehension Pack

K-Slide turns Korean or Korean+English slide screenshots into English-native comprehension reports using your current OpenCode model brain, such as Gemma 4 31B.

It is optimized for frequent real use:

- simple beginner flow
- fast smart default
- strict escalation only when needed
- artifact-first output
- no false completion
- clear recovery from unexpected failures

The main command is:

```text
/k-slide
```

No `/kslide` command is used.

---

## 5-minute quick start

### 1. Install into a project

```bash
unzip korean_slide_gemma_opencode_pack_v5.zip
cd korean_slide_gemma_opencode_pack_v5
./scripts/install_project.sh /path/to/your/project
```

### 2. Put screenshots here

```text
/path/to/your/project/.k-slide-input/
```

Recommended filenames:

```text
slide-001.png
slide-002.png
slide-003.png
```

Supported file extensions:

```text
.png .jpg .jpeg .webp .pdf
```

Image files are the most reliable. PDFs are accepted as inputs but may depend on your OpenCode/model environment.

### 3. Start OpenCode

```bash
cd /path/to/your/project
opencode
```

### 4. Run

```text
/k-slide
```

### 5. Open the report

```text
.k-slide-runs/<run-id>/05_final_report.md
```

---

## Direct file usage

You can also pass files directly:

```text
/k-slide slide.png
/k-slide slide-001.png slide-002.png
/k-slide .k-slide-input/
```

If no arguments are provided, `/k-slide` scans `.k-slide-input/`.

---

## What `/k-slide` does

Default `/k-slide` uses **smart mode**:

```text
normal simple slide      → fast end-to-end
moderate slide           → end-to-end with stronger verification
dense/low-confidence     → stop after extraction/layout and ask you to continue
multi-slide deck >3      → stop after Phase 1 unless forced/strict
```

This keeps common use fast while preserving quality and recoverability.

---

## Expected runtime

Real speed depends on your Gemma/OpenCode provider and image density.

Typical target:

```text
normal slide:          ~30–90 seconds
moderate slide:        ~1–2 minutes
very dense slide:      may phase-gate or exceed 2 minutes
multi-slide deck:      Phase 1 first, then continue
```

K-Slide is designed to avoid unlimited patience-test runs. If input is risky, it should stop at a clear phase boundary and tell you what to review and what command to run next.

---

## Final states

Every command should end with exactly one user-facing state:

```text
DONE
NEEDS REVIEW
FAILED
```

### DONE

Open:

```text
.k-slide-runs/<run-id>/05_final_report.md
```

### NEEDS REVIEW

Open the listed files, then run:

```text
/k-slide-continue .k-slide-runs/<run-id>
```

### FAILED

The command should explain what happened and show next steps. Usually:

```text
/k-slide-status .k-slide-runs/<run-id>
/k-slide-continue .k-slide-runs/<run-id>
/k-slide-doctor
```

---

## If only 00–02 files exist

That is not complete.

It means the run stopped after Phase 1 or was interrupted.

Run:

```text
/k-slide-status .k-slide-runs/<run-id>
/k-slide-continue .k-slide-runs/<run-id>
```

---

## If terminal shows raw tool-call gibberish

Sometimes an OpenCode/model tool bridge can fail and print raw tool-call-looking text instead of executing cleanly.

Do not treat that as completion.

Run:

```text
/k-slide-status .k-slide-runs/<run-id>
/k-slide-recover .k-slide-runs/<run-id>
```

If it repeats:

```text
/k-slide-safe .k-slide-runs/<run-id>
/k-slide-doctor
```

For OpenCode logs:

```bash
opencode --log-level DEBUG
```

Then check:

```text
~/.local/share/opencode/log/
```

---

## Commands

### Main use

```text
/k-slide
```

Smart default. Scans `.k-slide-input/` if no args are provided.

### Fast mode

```text
/k-slide-fast slide.png
```

Optimized for speed. Produces the useful report quickly and escalates if risk is detected.

### Strict mode

```text
/k-slide-strict slide.png
```

Maximum completeness. Produces detailed coverage/audit artifacts and may take longer.

### Safe mode

```text
/k-slide-safe slide.png
```

For fragile OpenCode/tool environments. One slide, smaller writes, more checkpoints.

### Continue

```text
/k-slide-continue .k-slide-runs/<run-id>
```

Resumes from the next missing/invalid phase.

### Status

```text
/k-slide-status .k-slide-runs/<run-id>
```

Determines whether a run is complete, incomplete, failed, or recoverable.

### Recover

```text
/k-slide-recover .k-slide-runs/<run-id>
```

Use after raw tool-call text, confusing exits, partial runs, or suspected subagent failure.

### Doctor

```text
/k-slide-doctor
```

Checks installation, folders, helper scripts, run-id creation, placeholder creation, and basic filesystem read/write smoke tests.

---

## Output files

Every run folder starts with recovery/state files before Gemma starts reasoning:

```text
00_run_manifest.md
00_input_inventory.json
RUN_STATE.json
RUN_RECOVERY_GUIDE.md
ARTIFACT_MANIFEST.json
VALIDATION_REPORT.json
SUBAGENT_TASKS.json
SUBAGENT_STATUS.md
```

Normal fast/smart output:

```text
01_slide_understanding.json
05_final_report.md
06_verification.md
RUN_COMPLETE.md
```

Strict/risky output may also include:

```text
01_extraction.json
02_layout_coverage.json
03_translation_audit.md
04_visual_interpretation.md
07_unresolved_items.md
08_coverage_ledger.md
09_glossary_suggestions.json
10_reader_quiz.md
slides/slide-001/...
```

---

## Completion guarantee

K-Slide does not promise to read unreadable pixels.

It does promise this operating standard:

> Every detected source item is either covered, explained, reconstructed, or explicitly marked unresolved. A run is never complete just because a subagent says it is done.

---

## Troubleshooting quick table

| Symptom | What to do |
|---|---|
| No files found | Put images in `.k-slide-input/`, run `/k-slide` |
| Only 00–02 exist | `/k-slide-status <run>` then `/k-slide-continue <run>` |
| Says done but no `RUN_COMPLETE.md` | Not complete. Run `/k-slide-status <run>` |
| Raw tool-call text appears | `/k-slide-recover <run>` |
| File not found during read/edit | `/k-slide-status <run>` then `/k-slide-continue <run>` |
| Write/edit failure | `/k-slide-safe <input-or-run>` and `/k-slide-doctor` |
| Subagent says file created but file missing | `/k-slide-recover <run>`; artifacts are source of truth |
| Repeated failures | Restart OpenCode, run `opencode --log-level DEBUG`, check logs |

---

## Design philosophy

K-Slide v5 is not strict-only. It is optimized smart mode:

```text
fast when safe
strict when needed
phase-gated when risky
recoverable when anything unexpected happens
```

This keeps everyday use lightweight while preserving a high reliability bar.
