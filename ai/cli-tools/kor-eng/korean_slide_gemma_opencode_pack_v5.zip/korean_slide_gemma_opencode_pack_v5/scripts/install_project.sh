#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-}"
if [ -z "$TARGET" ]; then echo "Usage: ./scripts/install_project.sh /path/to/project"; exit 1; fi
mkdir -p "$TARGET"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$TARGET/.opencode" "$TARGET/.k-slide-input" "$TARGET/.k-slide-runs" "$TARGET/.k-slide-archive"
if [ -d "$TARGET/.opencode/skills/korean-slide-comprehension" ] || ls "$TARGET/.opencode/commands/k-slide"*.md >/dev/null 2>&1; then
  BAK="$TARGET/.opencode/k-slide-backup-$(date +%Y%m%d-%H%M%S)"; mkdir -p "$BAK/commands" "$BAK/agents" "$BAK/skills"
  [ -d "$TARGET/.opencode/skills/korean-slide-comprehension" ] && mv "$TARGET/.opencode/skills/korean-slide-comprehension" "$BAK/skills/" || true
  mv "$TARGET/.opencode/commands/k-slide"*.md "$BAK/commands/" 2>/dev/null || true
  mv "$TARGET/.opencode/agents/k-slide"*.md "$BAK/agents/" 2>/dev/null || true
  mv "$TARGET/.opencode/agents/table-chart-specialist.md" "$BAK/agents/" 2>/dev/null || true
  mv "$TARGET/.opencode/agents/glossary-steward.md" "$BAK/agents/" 2>/dev/null || true
  echo "Backed up existing K-Slide assets to $BAK"
fi
mkdir -p "$TARGET/.opencode/commands" "$TARGET/.opencode/agents" "$TARGET/.opencode/skills"
cp -R "$ROOT/.opencode/commands/." "$TARGET/.opencode/commands/"
cp -R "$ROOT/.opencode/agents/." "$TARGET/.opencode/agents/"
cp -R "$ROOT/.opencode/skills/." "$TARGET/.opencode/skills/"
cp "$ROOT/AGENTS.md" "$TARGET/AGENTS.md.k-slide-v5"
if [ ! -f "$TARGET/AGENTS.md" ]; then cp "$ROOT/AGENTS.md" "$TARGET/AGENTS.md"; else echo "Existing AGENTS.md found. K-Slide law copied to AGENTS.md.k-slide-v5."; fi
if [ ! -f "$TARGET/.gitignore" ]; then touch "$TARGET/.gitignore"; fi
for line in ".k-slide-runs/" ".k-slide-input/" ".k-slide-archive/"; do grep -qxF "$line" "$TARGET/.gitignore" || echo "$line" >> "$TARGET/.gitignore"; done
chmod +x "$TARGET/.opencode/skills/korean-slide-comprehension/bin/"*.sh
echo "Installed K-Slide v5 into $TARGET"
echo "Next: cd $TARGET && opencode && run /k-slide"
