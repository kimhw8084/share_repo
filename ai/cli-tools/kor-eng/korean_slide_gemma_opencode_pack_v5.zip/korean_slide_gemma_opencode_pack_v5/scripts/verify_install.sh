#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-.}"
fail=0
check(){ if [ -e "$TARGET/$2" ]; then echo "[OK] $1"; else echo "[FAIL] $1: $2"; fail=1; fi; }
check "main command" ".opencode/commands/k-slide.md"
check "fast command" ".opencode/commands/k-slide-fast.md"
check "strict command" ".opencode/commands/k-slide-strict.md"
check "safe command" ".opencode/commands/k-slide-safe.md"
check "continue command" ".opencode/commands/k-slide-continue.md"
check "status command" ".opencode/commands/k-slide-status.md"
check "recover command" ".opencode/commands/k-slide-recover.md"
check "doctor command" ".opencode/commands/k-slide-doctor.md"
check "orchestrator" ".opencode/agents/k-slide-orchestrator.md"
check "skill" ".opencode/skills/korean-slide-comprehension/SKILL.md"
check "prepare helper" ".opencode/skills/korean-slide-comprehension/bin/prepare_run.sh"
check "status helper" ".opencode/skills/korean-slide-comprehension/bin/status_run.sh"
check "input folder" ".k-slide-input"
check "runs folder" ".k-slide-runs"
if [ "$fail" -eq 0 ]; then echo "K-Slide v5 install verification passed."; else echo "K-Slide v5 install verification failed."; exit 1; fi
