#!/usr/bin/env bash
set -euo pipefail
DEST="$HOME/.config/opencode"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$DEST/commands" "$DEST/agents" "$DEST/skills"
cp -R "$ROOT/.opencode/commands/." "$DEST/commands/"
cp -R "$ROOT/.opencode/agents/." "$DEST/agents/"
cp -R "$ROOT/.opencode/skills/." "$DEST/skills/"
chmod +x "$DEST/skills/korean-slide-comprehension/bin/"*.sh
echo "Installed K-Slide v5 globally into $DEST"
echo "Project-local install is recommended first for smoke testing."
