#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def request_json(base: str, path: str, method: str = "GET", data: bytes | None = None, headers: dict[str, str] | None = None, timeout: int = 90, context: ssl.SSLContext | None = None) -> dict[str, Any]:
    url = base.rstrip("/") + path
    req = urllib.request.Request(url, data=data, method=method, headers=headers or {})
    started = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=context) as response:
            raw = response.read()
            elapsed = time.monotonic() - started
            content_type = response.headers.get("content-type", "")
            body: Any
            if "json" in content_type:
                body = json.loads(raw.decode("utf-8"))
            else:
                body = raw.decode("utf-8", errors="replace")
            return {"ok": 200 <= response.status < 300, "status": response.status, "elapsed_seconds": round(elapsed, 3), "body": body}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            body = json.loads(raw)
        except json.JSONDecodeError:
            body = raw
        return {"ok": False, "status": exc.code, "elapsed_seconds": round(time.monotonic() - started, 3), "body": body}
    except Exception as exc:
        return {"ok": False, "status": None, "elapsed_seconds": round(time.monotonic() - started, 3), "error": repr(exc)}


def multipart_for_file(path: Path) -> tuple[bytes, str]:
    boundary = "----KSlideProbeBoundary7MA4YWxkTrZu0gW"
    data = path.read_bytes()
    body = bytearray()
    body.extend(f"--{boundary}\r\n".encode())
    body.extend(f'Content-Disposition: form-data; name="files"; filename="{path.name}"\r\n'.encode())
    body.extend(b"Content-Type: application/octet-stream\r\n\r\n")
    body.extend(data)
    body.extend(f"\r\n--{boundary}--\r\n".encode())
    return bytes(body), f"multipart/form-data; boundary={boundary}"


def stream_timing(base: str, path: str, context: ssl.SSLContext | None) -> dict[str, Any]:
    url = base.rstrip("/") + path
    started = time.monotonic()
    arrivals: list[float] = []
    lines: list[str] = []
    try:
        target_lines = 10 if "sse" in path.lower() else 5
        with urllib.request.urlopen(url, timeout=30, context=context) as response:
            while len(lines) < target_lines:
                raw = response.readline()
                if not raw:
                    break
                line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
                if line:
                    arrivals.append(round(time.monotonic() - started, 3))
                    lines.append(line)
        distinct = len({round(value) for value in arrivals}) >= 3
        return {
            "ok": True,
            "status": response.status,
            "arrivals_seconds": arrivals,
            "lines": lines,
            "appears_streamed": distinct and (arrivals[-1] - arrivals[0] >= 5 if len(arrivals) > 1 else False),
        }
    except Exception as exc:
        return {"ok": False, "error": repr(exc), "arrivals_seconds": arrivals, "lines": lines}


def classify(results: dict[str, Any]) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []

    def add(test: str, status: str, meaning: str, action: str) -> None:
        findings.append({"test": test, "status": status, "meaning": meaning, "action": action})

    live = results.get("health_live", {})
    add("HTTP/DNS", "PASS" if live.get("ok") else "BLOCKED", "The FastAPI application is reachable through company DNS." if live.get("ok") else "The app did not become reachable; deployment, startup, ingress, or DNS is failing.", "Proceed." if live.get("ok") else "Inspect publish/build/runtime logs before testing anything else.")

    ready = results.get("health_ready", {})
    ready_body = ready.get("body") if isinstance(ready.get("body"), dict) else {}
    add("Writable data directory", "PASS" if ready.get("ok") and ready_body.get("data_dir_writable") else "BLOCKED", "The runtime can write application state." if ready_body.get("data_dir_writable") else "The configured data directory is not writable.", "Use this directory for the probe only; separately test restart persistence." if ready_body.get("data_dir_writable") else "Set PROBE_DATA_DIR to an allowed writable mount/path.")

    versions = results.get("versions", {}).get("body", {}) if isinstance(results.get("versions", {}).get("body"), dict) else {}
    for exe in ("node", "npm", "opencode"):
        found = bool(versions.get(exe, {}).get("found"))
        severity = "PASS" if found else ("BLOCKED" if exe == "opencode" else "NEEDS_DECISION")
        meaning = f"{exe} is visible to the published Python process." if found else f"{exe} is not visible to the published Python process."
        action = "No action." if found else ("Find a supported build-time/runtime installation method for OpenCode." if exe == "opencode" else "Node/npm is needed only if OpenCode must be installed in this runtime.")
        add(f"Executable: {exe}", severity, meaning, action)

    child = results.get("child_process", {}).get("body", {}) if isinstance(results.get("child_process", {}).get("body"), dict) else {}
    add("Child processes", "PASS" if child.get("success") else "BLOCKED", "FastAPI can execute child processes." if child.get("success") else "The PaaS blocks or breaks subprocess execution.", "OpenCode can potentially be managed by FastAPI." if child.get("success") else "Use an external OpenCode service or a platform-supported worker; embedded OpenCode is not viable.")

    secondary = results.get("secondary_port", {}).get("body", {}) if isinstance(results.get("secondary_port", {}).get("body"), dict) else {}
    add("Internal localhost port", "PASS" if secondary.get("success") else "BLOCKED", "The app can bind and reach a secondary localhost server." if secondary.get("success") else "The app cannot host an internal OpenCode server on localhost.", "Preferred OpenCode server architecture remains viable." if secondary.get("success") else "Fall back to direct opencode run calls or an externally published OpenCode service.")

    long_child = results.get("child_status", {}).get("body", {}) if isinstance(results.get("child_status", {}).get("body"), dict) else {}
    add("Long-lived child process", "PASS" if long_child.get("alive") else "BLOCKED", "A managed child process remains alive." if long_child.get("alive") else "Long-lived child process is absent or terminated.", "Recheck after 5 and 15 minutes and after idle periods." if long_child.get("alive") else "OpenCode server cannot be embedded reliably without a different process model.")

    stream = results.get("stream_test", {})
    add("HTTP streaming", "PASS" if stream.get("appears_streamed") else "FALLBACK_REQUIRED", "Ingress delivered chunks over time." if stream.get("appears_streamed") else "Ingress appears to buffer streaming output.", "Use SSE/native stream plus polling fallback." if stream.get("appears_streamed") else "Use background jobs with polling; do not depend on live token streaming.")

    sse = results.get("sse_test", {})
    add("SSE", "PASS" if sse.get("appears_streamed") else "FALLBACK_REQUIRED", "SSE events arrive incrementally." if sse.get("appears_streamed") else "SSE is buffered or unavailable.", "Use SSE with polling fallback." if sse.get("appears_streamed") else "Use polling as the production status transport.")

    identity = results.get("identity", {}).get("body", {}) if isinstance(results.get("identity", {}).get("body"), dict) else {}
    found_identity = bool(identity.get("found"))
    add("Corporate identity header", "PASS" if found_identity else "BLOCKED_FOR_MULTIUSER", "At least one configured trusted identity header reached the app." if found_identity else "No expected identity header reached the app.", "Confirm which header is a username versus a credential before storing it." if found_identity else "Ask the platform team for a trusted username/email header or provide app-level authentication.")

    persistence = results.get("persistence_read", {}).get("body", {}) if isinstance(results.get("persistence_read", {}).get("body"), dict) else {}
    add("Persistence current pod", "PASS" if persistence.get("exists") else "NOT_TESTED", "The marker exists now." if persistence.get("exists") else "No persistence marker exists yet.", "Restart/republish, then rerun collector with --read-only to determine durability." if persistence.get("exists") else "Run collector without --read-only to write a marker first.")

    database = results.get("database", {}).get("body", {}) if isinstance(results.get("database", {}).get("body"), dict) else {}
    db_status = "PASS" if database.get("success") else ("NOT_CONFIGURED" if not database.get("configured") else "BLOCKED")
    add("PostgreSQL", db_status, "Database connectivity works." if database.get("success") else ("No DB URL is injected." if not database.get("configured") else "A DB URL exists but SELECT 1 failed."), "Use PostgreSQL for production metadata and governance." if database.get("success") else "Link psqldb/inject DATABASE_URL, or inspect TLS/driver/network settings.")

    oc = results.get("opencode_server", {}).get("body", {}) if isinstance(results.get("opencode_server", {}).get("body"), dict) else {}
    if "opencode_server" in results:
        add("OpenCode server lifecycle", "PASS" if oc.get("success") else "BLOCKED", "FastAPI successfully started and reached OpenCode server health." if oc.get("success") else "OpenCode server could not be started or reached.", "Use OpenCode server API architecture." if oc.get("success") else "Review opencode path, corporate config, child process, localhost port, and stderr output.")

    return findings


def markdown_report(base: str, results: dict[str, Any], findings: list[dict[str, str]]) -> str:
    lines = [
        "# K-Slide PaaS Capability Probe Results",
        "",
        f"- Base URL: `{base}`",
        f"- Collected: `{results['collected_at']}`",
        "",
        "## Decision summary",
        "",
        "| Test | Status | Meaning | Required action |",
        "|---|---|---|---|",
    ]
    for item in findings:
        values = [item["test"], item["status"], item["meaning"], item["action"]]
        lines.append("| " + " | ".join(value.replace("|", "\\|").replace("\n", " ") for value in values) + " |")
    lines.extend([
        "",
        "## Raw results",
        "",
        "See the adjacent JSON file for complete endpoint responses and timing data.",
        "",
        "## Persistence follow-up",
        "",
        "After the first run, restart or republish the app and run:",
        "",
        "```bash",
        f'python scripts/collect_published_results.py --base-url "{base}" --read-only',
        "```",
        "",
        "If `persistence-read` still returns the same UUID, the selected data directory survived that lifecycle event.",
    ])
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Collect K-Slide PaaS probe results from a published company DNS.")
    parser.add_argument("--base-url", required=True, help="Published base URL, for example https://project.company.example")
    parser.add_argument("--output-dir", default="results", help="Directory for JSON and Markdown reports")
    parser.add_argument("--upload-image", help="Optional PNG/JPEG/WEBP used for the multipart upload test")
    parser.add_argument("--run-opencode-server-test", action="store_true", help="Ask the published app to launch an OpenCode server and check /global/health")
    parser.add_argument("--run-real-model-test", action="store_true", help="Run the opt-in non-confidential real model smoke test; server must have ENABLE_REAL_MODEL_TEST=1")
    parser.add_argument("--read-only", action="store_true", help="Do not overwrite the persistence marker")
    parser.add_argument("--insecure", action="store_true", help="Disable TLS verification only if your corporate test certificate requires it")
    args = parser.parse_args()

    context = ssl._create_unverified_context() if args.insecure else None
    base = args.base_url.rstrip("/")
    results: dict[str, Any] = {"base_url": base, "collected_at": utc_now()}

    endpoints = {
        "health_live": "/health/live",
        "health_ready": "/health/ready",
        "versions": "/versions",
        "runtime": "/runtime",
        "child_process": "/child-process",
        "child_status": "/child-status",
        "secondary_port": "/secondary-port-test",
        "environment": "/environment-safe",
        "identity": "/identity-test",
        "database": "/database-test",
        "opencode_info": "/opencode/info",
        "proxy": "/proxy-test",
    }
    for name, path in endpoints.items():
        print(f"Testing {path} ...", flush=True)
        results[name] = request_json(base, path, context=context)

    if not args.read_only:
        print("Writing persistence marker ...", flush=True)
        results["persistence_write"] = request_json(base, "/persistence-write", method="POST", data=b"", context=context)
    results["persistence_read"] = request_json(base, "/persistence-read", context=context)

    print("Testing HTTP streaming (~10 seconds) ...", flush=True)
    results["stream_test"] = stream_timing(base, "/stream-test", context)
    print("Testing SSE (~10 seconds) ...", flush=True)
    results["sse_test"] = stream_timing(base, "/sse-test", context)

    if args.upload_image:
        path = Path(args.upload_image)
        if not path.is_file():
            parser.error(f"Upload image does not exist: {path}")
        body, content_type = multipart_for_file(path)
        print(f"Testing image upload with {path} ...", flush=True)
        results["upload"] = request_json(base, "/upload-test", method="POST", data=body, headers={"Content-Type": content_type}, timeout=90, context=context)

    if args.run_opencode_server_test:
        print("Testing managed OpenCode server lifecycle (up to 45 seconds) ...", flush=True)
        results["opencode_server"] = request_json(base, "/opencode/server-test", method="POST", data=b"", timeout=70, context=context)

    if args.run_real_model_test:
        print("Running opt-in real model smoke test (up to 2 minutes) ...", flush=True)
        results["real_model"] = request_json(base, "/opencode/model-smoke", method="POST", data=b"", timeout=150, context=context)

    findings = classify(results)
    results["findings"] = findings

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    json_path = output_dir / f"paas-probe-{timestamp}.json"
    md_path = output_dir / f"paas-probe-{timestamp}.md"
    json_text = json.dumps(results, indent=2, ensure_ascii=False, default=str)
    report_text = markdown_report(base, results, findings)
    json_path.write_text(json_text, encoding="utf-8")
    md_path.write_text(report_text, encoding="utf-8")
    latest_json = output_dir / "LATEST_PROBE.json"
    latest_md = output_dir / "LATEST_PROBE.md"
    latest_json.write_text(json_text, encoding="utf-8")
    latest_md.write_text(report_text, encoding="utf-8")

    print(f"\nJSON: {json_path}")
    print(f"Report: {md_path}")
    print(f"Latest JSON: {latest_json}")
    print(f"Latest report: {latest_md}\n")
    for finding in findings:
        print(f"[{finding['status']}] {finding['test']}: {finding['meaning']}")

    blocked = any(item["status"] == "BLOCKED" for item in findings)
    return 2 if blocked else 0


if __name__ == "__main__":
    sys.exit(main())
