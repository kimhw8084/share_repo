#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 https://your-project.company-domain [--insecure]" >&2
  exit 64
fi

BASE_URL="$1"
shift
IMAGE="$(python scripts/generate_test_image.py)"
set +e
python scripts/collect_published_results.py \
  --base-url "$BASE_URL" \
  --upload-image "$IMAGE" \
  --run-opencode-server-test \
  "$@"
RC=$?
set -e

if [[ $RC -eq 2 ]]; then
  echo "Probe completed and produced reports; one or more architectural blockers were detected." >&2
elif [[ $RC -ne 0 ]]; then
  echo "Probe execution itself failed. Review the terminal output." >&2
fi
exit "$RC"
