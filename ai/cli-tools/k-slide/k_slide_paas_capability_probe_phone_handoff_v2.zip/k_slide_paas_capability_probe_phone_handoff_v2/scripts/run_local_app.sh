#!/usr/bin/env bash
set -euo pipefail
. .venv/bin/activate
export PROBE_DATA_DIR="${PROBE_DATA_DIR:-$(pwd)/probe-data}"
exec ./start.sh
