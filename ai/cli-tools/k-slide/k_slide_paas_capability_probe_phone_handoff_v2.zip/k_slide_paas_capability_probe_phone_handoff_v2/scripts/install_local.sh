#!/usr/bin/env bash
set -euo pipefail

python -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo "Installed Python dependencies into .venv"
echo "OpenCode is intentionally not installed by this script."
echo "Install it using your company-approved method, for example: npm install -g opencode-ai"
