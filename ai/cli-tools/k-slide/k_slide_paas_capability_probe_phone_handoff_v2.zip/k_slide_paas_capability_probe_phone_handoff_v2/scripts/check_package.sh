#!/usr/bin/env bash
set -euo pipefail

python -m compileall -q app scripts local_tests tests
bash -n start.sh scripts/*.sh local_tests/*.sh
python tests/self_test.py
python scripts/generate_test_image.py >/dev/null
python - <<'PY'
from pathlib import Path
required = [
    "main.py",
    "requirements.txt",
    "start.sh",
    "README.md",
    "app/main.py",
    "scripts/collect_published_results.py",
    "scripts/one_touch_handoff.sh",
    "scripts/local_auto_results.py",
    "scripts/manual_observation_wizard.py",
    "scripts/phone_handoff.py",
    "local_tests/run_all_safe.sh",
    "docs/PHONE_HANDOFF.md",
    "docs/RESULT_INTERPRETATION.md",
    "results/RESULTS_TEMPLATE.md",
]
missing = [item for item in required if not Path(item).exists()]
if missing:
    raise SystemExit(f"Missing required files: {missing}")
for script in ["start.sh", "scripts/one_touch_handoff.sh", "scripts/run_published_probe.sh"]:
    if not Path(script).stat().st_mode & 0o111:
        raise SystemExit(f"Script is not executable: {script}")
print("PASS: package structure and executable permissions")
PY
