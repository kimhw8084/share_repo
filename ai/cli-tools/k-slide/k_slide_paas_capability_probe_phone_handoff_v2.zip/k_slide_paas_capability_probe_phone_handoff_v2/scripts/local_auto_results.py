#!/usr/bin/env python3
from __future__ import annotations

import base64
import json
import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def command_result(name: str, args: list[str]) -> dict[str, Any]:
    print(f"  checking {name}...", flush=True)
    path = shutil.which(name)
    result: dict[str, Any] = {"found": bool(path), "path": path}
    if not path:
        return result
    try:
        completed = subprocess.run(
            [path, *args],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        result.update(
            {
                "returncode": completed.returncode,
                "stdout": completed.stdout.strip()[-1000:],
                "stderr": completed.stderr.strip()[-1000:],
                "success": completed.returncode == 0,
            }
        )
    except Exception as exc:
        result.update({"success": False, "error": repr(exc)})
    print(f"  finished {name}", flush=True)
    return result


def terminate(process: subprocess.Popen[str] | None) -> None:
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=8)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=4)


def opencode_server_test() -> dict[str, Any]:
    opencode = shutil.which("opencode")
    if not opencode:
        return {"success": False, "reason": "opencode_not_found"}

    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]

    password = uuid.uuid4().hex
    env = os.environ.copy()
    env["OPENCODE_SERVER_PASSWORD"] = password
    process: subprocess.Popen[str] | None = None
    try:
        process = subprocess.Popen(
            [opencode, "serve", "--hostname", "127.0.0.1", "--port", str(port)],
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        credentials = base64.b64encode(f"opencode:{password}".encode()).decode()
        deadline = time.monotonic() + 45
        last_error = None
        while time.monotonic() < deadline:
            if process.poll() is not None:
                break
            try:
                request = urllib.request.Request(
                    f"http://127.0.0.1:{port}/global/health",
                    headers={"Authorization": f"Basic {credentials}"},
                )
                with urllib.request.urlopen(request, timeout=2) as response:
                    body = json.loads(response.read().decode("utf-8"))
                    return {
                        "success": True,
                        "port": port,
                        "health": body,
                    }
            except Exception as exc:
                last_error = repr(exc)
                time.sleep(0.5)

        stdout = ""
        stderr = ""
        if process.poll() is not None:
            stdout, stderr = process.communicate(timeout=5)
        return {
            "success": False,
            "returncode": process.poll(),
            "last_error": last_error,
            "stdout_tail": stdout[-1500:],
            "stderr_tail": stderr[-2500:],
        }
    except Exception as exc:
        return {"success": False, "error": repr(exc)}
    finally:
        terminate(process)


def main() -> int:
    output = Path(sys.argv[1] if len(sys.argv) > 1 else "results/local-auto.json")
    output.parent.mkdir(parents=True, exist_ok=True)

    results: dict[str, Any] = {
        "collected_at": now_iso(),
        "python": sys.version.split()[0],
        "executables": {
            "node": command_result("node", ["--version"]),
            "npm": command_result("npm", ["--version"]),
            "opencode": command_result("opencode", ["--version"]),
            "git": command_result("git", ["--version"]),
        },
        "shell_child_process": command_result("sh", ["-c", "printf child-process-ok"]),
    }
    print("  checking local opencode server...", flush=True)
    results["opencode_server"] = opencode_server_test()
    print("  finished local opencode server", flush=True)
    output.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Local automatic results: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
