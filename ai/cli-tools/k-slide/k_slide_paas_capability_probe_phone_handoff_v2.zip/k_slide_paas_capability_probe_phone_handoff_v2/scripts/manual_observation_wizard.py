#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

QUESTIONS = [
    ("web_loads", "OpenCode Web page loads in your personal work environment"),
    ("paste_one", "You can paste one screenshot into OpenCode Web"),
    ("paste_multiple", "You can attach/paste multiple images in one session"),
    ("kslide_command", "The /k-slide command appears and can be selected"),
    ("output_streams", "The response visibly streams while it is generated"),
    ("real_model_ok", "A real model smoke test returned MODEL_OK"),
    ("published_inherits_model", "Published FastAPI runtime inherits the corporate model configuration"),
]


def ask_bool(label: str) -> str:
    while True:
        answer = input(f"{label}\n  [y] yes  [n] no  [?] unknown/not tested: ").strip().lower()
        if answer in {"y", "yes"}:
            return "yes"
        if answer in {"n", "no"}:
            return "no"
        if answer in {"?", "", "u", "unknown", "skip", "s"}:
            return "unknown"
        print("Please type only y, n, or ?.")


def ask_identity() -> str:
    while True:
        answer = input(
            "What does the AccessKey value represent?\n"
            "  [u] username/employee ID  [s] secret/token  [o] other  [?] unknown: "
        ).strip().lower()
        mapping = {
            "u": "username_or_employee_id",
            "s": "secret_or_token",
            "o": "other",
            "?": "unknown",
            "": "unknown",
        }
        if answer in mapping:
            return mapping[answer]
        print("Please type only u, s, o, or ?.")


def main() -> int:
    output = Path(sys.argv[1] if len(sys.argv) > 1 else "results/manual-observations.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    print("\nK-Slide manual observations — single-key answers only.\n")
    observations = {key: ask_bool(label) for key, label in QUESTIONS}
    observations["accesskey_kind"] = ask_identity()
    payload = {
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "observations": observations,
    }
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"\nManual observations saved: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
