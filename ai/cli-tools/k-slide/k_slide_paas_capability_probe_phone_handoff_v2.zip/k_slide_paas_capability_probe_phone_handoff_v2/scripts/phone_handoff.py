#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import html
import json
import textwrap
from datetime import datetime
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFont

STATUS_SYMBOL = {
    "PASS": "+",
    "BLOCKED": "-",
    "BLOCKED_FOR_MULTIUSER": "!",
    "FALLBACK_REQUIRED": "~",
    "NOT_CONFIGURED": "0",
    "NEEDS_DECISION": "?",
    "NOT_TESTED": "?",
}

STATUS_LABEL = {
    "PASS": "PASS",
    "BLOCKED": "BLOCKED",
    "BLOCKED_FOR_MULTIUSER": "IDENTITY BLOCKED",
    "FALLBACK_REQUIRED": "FALLBACK",
    "NOT_CONFIGURED": "NOT CONFIGURED",
    "NEEDS_DECISION": "CHECK",
    "NOT_TESTED": "NOT TESTED",
}

STATUS_COLOR = {
    "PASS": (36, 138, 74),
    "BLOCKED": (190, 52, 52),
    "BLOCKED_FOR_MULTIUSER": (190, 52, 52),
    "FALLBACK_REQUIRED": (190, 119, 26),
    "NOT_CONFIGURED": (102, 112, 133),
    "NEEDS_DECISION": (102, 112, 133),
    "NOT_TESTED": (102, 112, 133),
}

FINDING_ORDER = [
    ("D", "HTTP/DNS"),
    ("W", "Writable data directory"),
    ("N", "Executable: node"),
    ("M", "Executable: npm"),
    ("O", "Executable: opencode"),
    ("C", "Child processes"),
    ("L", "Internal localhost port"),
    ("G", "Long-lived child process"),
    ("T", "HTTP streaming"),
    ("E", "SSE"),
    ("I", "Corporate identity header"),
    ("P", "Persistence current pod"),
    ("B", "PostgreSQL"),
    ("S", "OpenCode server lifecycle"),
]

MANUAL_ORDER = [
    ("WL", "web_loads", "OpenCode Web loads"),
    ("P1", "paste_one", "Paste one image"),
    ("PM", "paste_multiple", "Paste multiple images"),
    ("KC", "kslide_command", "/k-slide appears"),
    ("OS", "output_streams", "OpenCode output streams"),
    ("RM", "real_model_ok", "Real model smoke"),
    ("CF", "published_inherits_model", "Published runtime model config"),
]


def load_json(path: Path | None) -> dict[str, Any]:
    if path is None or not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def finding_map(probe: dict[str, Any]) -> dict[str, dict[str, str]]:
    return {
        item.get("test", ""): item
        for item in probe.get("findings", [])
        if isinstance(item, dict)
    }


def symbol_for(status: str | None) -> str:
    return STATUS_SYMBOL.get(status or "", "?")


def manual_symbol(value: str | None) -> str:
    return {"yes": "Y", "no": "N", "unknown": "?"}.get(value or "", "?")


def architecture_decision(findings: dict[str, dict[str, str]]) -> tuple[str, list[str]]:
    def status(name: str) -> str:
        return findings.get(name, {}).get("status", "NOT_TESTED")

    opencode = status("Executable: opencode") == "PASS"
    child = status("Child processes") == "PASS"
    port = status("Internal localhost port") == "PASS"
    long_child = status("Long-lived child process") == "PASS"
    server = status("OpenCode server lifecycle") == "PASS"
    identity = status("Corporate identity header") == "PASS"
    db = status("PostgreSQL") == "PASS"

    actions: list[str] = []
    if opencode and child and port and long_child and server:
        title = "Preferred design is viable: FastAPI + managed OpenCode server."
    elif opencode and child:
        title = "Fallback design is viable: FastAPI + per-run opencode subprocess."
        actions.append("Do not depend on a persistent OpenCode server until failed server checks are fixed.")
    elif not opencode:
        title = "Published runtime cannot run K-Slide until OpenCode is installed or supplied."
        actions.append("Confirm an approved build-time OpenCode installation method.")
    else:
        title = "Embedded OpenCode is blocked by the published runtime."
        actions.append("Use an external OpenCode service or request platform support.")

    if not identity:
        actions.append("Obtain a trusted employee identity header before multi-user release.")
    if not db:
        actions.append("Link PostgreSQL for durable users, runs, audit, and configuration versions.")
    if not actions:
        actions.append("Proceed to the full K-Slide application build and real model validation.")
    return title, actions[:4]


def make_compact_code(probe: dict[str, Any], local: dict[str, Any], manual: dict[str, Any]) -> str:
    findings = finding_map(probe)
    published_parts = []
    for key, name in FINDING_ORDER:
        published_parts.append(f"{key}{symbol_for(findings.get(name, {}).get('status'))}")

    observations = manual.get("observations", {}) if isinstance(manual, dict) else {}
    manual_parts = [f"{key}{manual_symbol(observations.get(field))}" for key, field, _ in MANUAL_ORDER]
    access_kind = observations.get("accesskey_kind", "unknown")
    access_symbol = {
        "username_or_employee_id": "U",
        "secret_or_token": "S",
        "other": "O",
        "unknown": "?",
    }.get(access_kind, "?")
    manual_parts.append(f"AK{access_symbol}")

    local_exec = local.get("executables", {}).get("opencode", {}) if isinstance(local, dict) else {}
    local_opencode = "+" if local_exec.get("success") else ("-" if local_exec.get("found") else "?")
    local_server = "+" if local.get("opencode_server", {}).get("success") else "-"
    body = f"KSP2 {' '.join(published_parts)} | LO{local_opencode} LS{local_server} | {' '.join(manual_parts)}"
    checksum = hashlib.sha256(body.encode("utf-8")).hexdigest()[:6].upper()
    return f"{body} #{checksum}"


def unknown_questions(manual: dict[str, Any]) -> list[str]:
    observations = manual.get("observations", {}) if isinstance(manual, dict) else {}
    questions = []
    for key, field, label in MANUAL_ORDER:
        if observations.get(field, "unknown") == "unknown":
            questions.append(f"{key}: {label}? Reply Y or N")
    if observations.get("accesskey_kind", "unknown") == "unknown":
        questions.append("AK: AccessKey is username/ID (U), secret/token (S), or other (O)?")
    return questions


def font(size: int, bold: bool = False) -> ImageFont.ImageFont:
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/dejavu/DejaVuSans.ttf",
        "/Library/Fonts/Arial Bold.ttf" if bold else "/Library/Fonts/Arial.ttf",
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size=size)
        except OSError:
            continue
    return ImageFont.load_default()


def wrapped(draw: ImageDraw.ImageDraw, text: str, xy: tuple[int, int], max_width: int, fnt: ImageFont.ImageFont, fill: tuple[int, int, int], spacing: int = 8) -> int:
    words = text.split()
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if draw.textbbox((0, 0), candidate, font=fnt)[2] <= max_width or not current:
            current = candidate
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    x, y = xy
    line_h = draw.textbbox((0, 0), "Ag", font=fnt)[3] + spacing
    for line in lines:
        draw.text((x, y), line, font=fnt, fill=fill)
        y += line_h
    return y


def make_png(path: Path, probe: dict[str, Any], local: dict[str, Any], manual: dict[str, Any], code: str) -> None:
    width, height = 1170, 3000
    image = Image.new("RGB", (width, height), (247, 248, 250))
    draw = ImageDraw.Draw(image)
    title_font = font(54, bold=True)
    sub_font = font(31)
    section_font = font(34, bold=True)
    row_font = font(29, bold=True)
    small_font = font(25)
    code_font = font(24, bold=True)

    margin = 70
    y = 65
    draw.text((margin, y), "K-Slide Environment Results", font=title_font, fill=(22, 28, 45))
    y += 75
    collected = str(probe.get("collected_at", "not collected"))[:19].replace("T", " ")
    draw.text((margin, y), f"Generated {collected}", font=sub_font, fill=(95, 104, 124))
    y += 72

    findings = finding_map(probe)
    decision, actions = architecture_decision(findings)
    draw.rounded_rectangle((margin, y, width - margin, y + 205), radius=28, fill=(232, 238, 248), outline=(205, 214, 231), width=2)
    y = wrapped(draw, decision, (margin + 30, y + 28), width - 2 * margin - 60, section_font, (25, 48, 86), spacing=10) + 20

    y += 35
    draw.text((margin, y), "Published FastAPI runtime", font=section_font, fill=(22, 28, 45))
    y += 56
    row_h = 74
    for index, (_, name) in enumerate(FINDING_ORDER):
        item = findings.get(name, {"status": "NOT_TESTED"})
        status = item.get("status", "NOT_TESTED")
        top = y + index * row_h
        fill = (255, 255, 255) if index % 2 == 0 else (242, 244, 248)
        draw.rounded_rectangle((margin, top, width - margin, top + row_h - 8), radius=16, fill=fill)
        draw.text((margin + 22, top + 16), name, font=small_font, fill=(32, 39, 57))
        label = STATUS_LABEL.get(status, status)
        color = STATUS_COLOR.get(status, (102, 112, 133))
        bbox = draw.textbbox((0, 0), label, font=row_font)
        draw.text((width - margin - 22 - (bbox[2] - bbox[0]), top + 13), label, font=row_font, fill=color)
    y += len(FINDING_ORDER) * row_h + 22

    draw.text((margin, y), "Personal work environment", font=section_font, fill=(22, 28, 45))
    y += 55
    local_exec = local.get("executables", {}).get("opencode", {}) if isinstance(local, dict) else {}
    local_rows = [
        ("OpenCode executable", "PASS" if local_exec.get("success") else ("BLOCKED" if local_exec.get("found") else "NOT_TESTED")),
        ("OpenCode server", "PASS" if local.get("opencode_server", {}).get("success") else "BLOCKED"),
    ]
    for index, (name, status) in enumerate(local_rows):
        top = y + index * row_h
        fill = (255, 255, 255) if index % 2 == 0 else (242, 244, 248)
        draw.rounded_rectangle((margin, top, width - margin, top + row_h - 8), radius=16, fill=fill)
        draw.text((margin + 22, top + 16), name, font=small_font, fill=(32, 39, 57))
        label = STATUS_LABEL.get(status, status)
        color = STATUS_COLOR.get(status, (102, 112, 133))
        bbox = draw.textbbox((0, 0), label, font=row_font)
        draw.text((width - margin - 22 - (bbox[2] - bbox[0]), top + 13), label, font=row_font, fill=color)
    y += len(local_rows) * row_h + 22

    observations = manual.get("observations", {}) if isinstance(manual, dict) else {}
    draw.text((margin, y), "Manual observations", font=section_font, fill=(22, 28, 45))
    y += 58
    manual_text = "   ".join(f"{key}:{manual_symbol(observations.get(field))}" for key, field, _ in MANUAL_ORDER)
    manual_text += "   AK:" + {
        "username_or_employee_id": "U",
        "secret_or_token": "S",
        "other": "O",
        "unknown": "?",
    }.get(observations.get("accesskey_kind", "unknown"), "?")
    y = wrapped(draw, manual_text, (margin, y), width - 2 * margin, row_font, (32, 39, 57), spacing=12) + 25

    draw.text((margin, y), "Next actions", font=section_font, fill=(22, 28, 45))
    y += 55
    for action in actions:
        draw.ellipse((margin + 2, y + 10, margin + 18, y + 26), fill=(49, 97, 177))
        y = wrapped(draw, action, (margin + 34, y), width - 2 * margin - 34, small_font, (45, 52, 70), spacing=8) + 12

    y += 12
    draw.text((margin, y), "Send this code or this image", font=section_font, fill=(22, 28, 45))
    y += 56
    draw.rounded_rectangle((margin, y, width - margin, min(height - 65, y + 240)), radius=22, fill=(22, 28, 45))
    wrapped(draw, code, (margin + 28, y + 28), width - 2 * margin - 56, code_font, (255, 255, 255), spacing=10)

    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path, format="PNG", optimize=True)


def make_html(path: Path, probe: dict[str, Any], local: dict[str, Any], manual: dict[str, Any], code: str) -> None:
    findings = finding_map(probe)
    decision, actions = architecture_decision(findings)
    rows = []
    for _, name in FINDING_ORDER:
        status = findings.get(name, {}).get("status", "NOT_TESTED")
        rows.append(
            f"<tr><td>{html.escape(name)}</td><td class='s {html.escape(status.lower())}'>{html.escape(STATUS_LABEL.get(status, status))}</td></tr>"
        )
    local_exec = local.get("executables", {}).get("opencode", {}) if isinstance(local, dict) else {}
    local_items = (
        f"<li><b>OpenCode executable</b>: {'PASS' if local_exec.get('success') else 'NOT READY'}</li>"
        f"<li><b>OpenCode server</b>: {'PASS' if local.get('opencode_server', {}).get('success') else 'NOT READY'}</li>"
    )
    observations = manual.get("observations", {}) if isinstance(manual, dict) else {}
    manual_items = "".join(
        f"<li><b>{html.escape(key)}</b> — {html.escape(label)}: {html.escape(manual_symbol(observations.get(field)))}</li>"
        for key, field, label in MANUAL_ORDER
    )
    action_items = "".join(f"<li>{html.escape(action)}</li>" for action in actions)
    document = f"""<!doctype html>
<html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>K-Slide Phone Handoff</title>
<style>
body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f5f6f8;color:#171b29;margin:0;padding:24px}}
main{{max-width:760px;margin:auto}} h1{{font-size:32px}} .decision{{background:#e9eef8;border:1px solid #ced8e9;padding:18px;border-radius:18px;font-size:20px;font-weight:700}}
table{{width:100%;border-collapse:separate;border-spacing:0 6px}} td{{background:#fff;padding:13px;border-bottom:1px solid #e9ebf0}} td:first-child{{border-radius:12px 0 0 12px}} td:last-child{{border-radius:0 12px 12px 0;text-align:right;font-weight:800}}
.pass{{color:#218a4a}} .blocked,.blocked_for_multiuser{{color:#bd3434}} .fallback_required{{color:#bd771a}} .not_configured,.needs_decision,.not_tested{{color:#687086}}
.code{{background:#171b29;color:#fff;border-radius:16px;padding:18px;font-family:ui-monospace,monospace;word-break:break-word;font-size:17px}} button{{margin-top:10px;padding:12px 16px;border:0;border-radius:12px;background:#2463d4;color:#fff;font-weight:700}}
</style></head><body><main>
<h1>K-Slide Environment Results</h1><div class='decision'>{html.escape(decision)}</div>
<h2>Published runtime</h2><table>{''.join(rows)}</table>
<h2>Personal work environment</h2><ul>{local_items}</ul>
<h2>Manual observations</h2><ul>{manual_items}</ul>
<h2>Next actions</h2><ol>{action_items}</ol>
<h2>Send to ChatGPT</h2><div id='code' class='code'>{html.escape(code)}</div><button id='copy' type='button'>Copy short code</button>
<script>document.getElementById('copy').addEventListener('click',async()=>{{try{{await navigator.clipboard.writeText(document.getElementById('code').textContent);document.getElementById('copy').textContent='Copied';}}catch(e){{document.getElementById('copy').textContent='Select and copy the code';}}}});</script>
</main></body></html>"""
    path.write_text(document, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a phone-friendly K-Slide environment handoff.")
    parser.add_argument("--probe-json", required=True)
    parser.add_argument("--local-json")
    parser.add_argument("--manual-json")
    parser.add_argument("--output-dir", default="results/handoff")
    args = parser.parse_args()

    probe = load_json(Path(args.probe_json))
    local = load_json(Path(args.local_json)) if args.local_json else {}
    manual = load_json(Path(args.manual_json)) if args.manual_json else {}
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)

    code = make_compact_code(probe, local, manual)
    findings = finding_map(probe)
    decision, actions = architecture_decision(findings)
    questions = unknown_questions(manual)

    payload = {
        "generated_at": datetime.now().isoformat(),
        "short_code": code,
        "decision": decision,
        "actions": actions,
        "remaining_questions": questions,
        "published_probe": probe,
        "local_auto": local,
        "manual": manual,
    }
    (output / "FULL_HANDOFF.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    (output / "PHONE_REPLY.txt").write_text(code + "\n", encoding="utf-8")
    (output / "DECISION.txt").write_text(decision + "\n" + "\n".join(f"- {a}" for a in actions) + "\n", encoding="utf-8")
    (output / "REMAINING_QUESTIONS.txt").write_text(("\n".join(questions) if questions else "No remaining manual questions.") + "\n", encoding="utf-8")
    make_png(output / "PHONE_SCREENSHOT.png", probe, local, manual, code)
    make_html(output / "PHONE_REPORT.html", probe, local, manual, code)

    print("\n============================================================")
    print("PHONE HANDOFF READY")
    print("============================================================")
    print(code)
    print("\nUse any ONE method:")
    print(f"1. Paste: {output / 'PHONE_REPLY.txt'}")
    print(f"2. Upload or photograph: {output / 'PHONE_SCREENSHOT.png'}")
    print(f"3. Open in browser: {output / 'PHONE_REPORT.html'}")
    if questions:
        print(f"\nUnanswered observations: {output / 'REMAINING_QUESTIONS.txt'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
