#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw

output = Path(__file__).resolve().parents[1] / "results" / "probe-image.png"
output.parent.mkdir(parents=True, exist_ok=True)
image = Image.new("RGB", (800, 450), "white")
draw = ImageDraw.Draw(image)
draw.rectangle((30, 30, 770, 420), outline="black", width=3)
draw.text((60, 70), "K-Slide PaaS upload probe", fill="black")
draw.text((60, 120), "This contains no confidential data.", fill="black")
image.save(output)
print(output)
