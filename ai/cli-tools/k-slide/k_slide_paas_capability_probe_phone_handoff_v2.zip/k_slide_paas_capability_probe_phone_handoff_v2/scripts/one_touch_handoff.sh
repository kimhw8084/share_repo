#!/usr/bin/env bash
set -uo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 https://your-project.company-domain [--insecure] [--no-manual]" >&2
  exit 64
fi

BASE_URL="$1"
shift
INSECURE=0
NO_MANUAL=0
for arg in "$@"; do
  case "$arg" in
    --insecure) INSECURE=1 ;;
    --no-manual) NO_MANUAL=1 ;;
    *) echo "Unknown option: $arg" >&2; exit 64 ;;
  esac
done

mkdir -p results
rm -f results/LATEST_PROBE.json results/LATEST_PROBE.md
IMAGE="$(python scripts/generate_test_image.py)"
COLLECT_ARGS=(--base-url "$BASE_URL" --upload-image "$IMAGE" --run-opencode-server-test)
if [[ $INSECURE -eq 1 ]]; then
  COLLECT_ARGS+=(--insecure)
fi

echo "[1/4] Testing the published FastAPI runtime..."
python scripts/collect_published_results.py "${COLLECT_ARGS[@]}"
COLLECT_RC=$?
if [[ $COLLECT_RC -ne 0 && $COLLECT_RC -ne 2 ]]; then
  echo "The published collector crashed; no handoff can be generated." >&2
  exit "$COLLECT_RC"
fi

PROBE_JSON="results/LATEST_PROBE.json"
if [[ ! -f "$PROBE_JSON" ]]; then
  echo "No published probe JSON was generated." >&2
  exit 70
fi

echo "[2/4] Testing local OpenCode capabilities..."
python scripts/local_auto_results.py results/local-auto.json || true

if [[ $NO_MANUAL -eq 0 ]]; then
  echo "[3/4] Recording the few observations automation cannot see..."
  python scripts/manual_observation_wizard.py results/manual-observations.json
else
  echo "[3/4] Manual observations skipped. Unknown values will be marked ?."
fi

echo "[4/4] Creating phone-sized handoff..."
ARGS=(--probe-json "$PROBE_JSON" --local-json results/local-auto.json --output-dir results/handoff)
if [[ -f results/manual-observations.json ]]; then
  ARGS+=(--manual-json results/manual-observations.json)
fi
python scripts/phone_handoff.py "${ARGS[@]}"

cat <<'TEXT'

You do NOT need to type a long explanation on your phone.
Send ChatGPT either:
  • the single line in results/handoff/PHONE_REPLY.txt, OR
  • a screenshot/photo of results/handoff/PHONE_SCREENSHOT.png.
TEXT
exit 0
