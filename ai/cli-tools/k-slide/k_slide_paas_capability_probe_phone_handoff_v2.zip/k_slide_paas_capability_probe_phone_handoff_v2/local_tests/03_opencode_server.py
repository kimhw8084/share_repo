#!/usr/bin/env python3
from __future__ import annotations

import base64
import json
import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
import uuid


def terminate(process: subprocess.Popen[str]) -> None:
    if process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


opencode = shutil.which("opencode")
if not opencode:
    print("FAIL: opencode is not available in PATH")
    sys.exit(2)

with socket.socket() as sock:
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]

password = uuid.uuid4().hex
env = os.environ.copy()
env["OPENCODE_SERVER_PASSWORD"] = password
process = subprocess.Popen(
    [opencode, "serve", "--hostname", "127.0.0.1", "--port", str(port)],
    env=env,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
)

credentials = base64.b64encode(f"opencode:{password}".encode()).decode()
try:
    deadline = time.monotonic() + 45
    last_error = None
    while time.monotonic() < deadline:
        if process.poll() is not None:
            break
        try:
            request = urllib.request.Request(
                f"http://127.0.0.1:{port}/global/health",
                headers={"Authorization": f"Basic {credentials}"},
            )
            with urllib.request.urlopen(request, timeout=2) as response:
                body = json.loads(response.read().decode())
                print(json.dumps({"PASS": True, "port": port, "health": body}, indent=2))
                sys.exit(0)
        except Exception as exc:
            last_error = repr(exc)
            time.sleep(0.5)

    stdout, stderr = process.communicate(timeout=5) if process.poll() is not None else ("", "")
    print(json.dumps({
        "PASS": False,
        "returncode": process.poll(),
        "last_error": last_error,
        "stdout_tail": stdout[-2000:],
        "stderr_tail": stderr[-4000:],
    }, indent=2))
    sys.exit(3)
finally:
    terminate(process)
