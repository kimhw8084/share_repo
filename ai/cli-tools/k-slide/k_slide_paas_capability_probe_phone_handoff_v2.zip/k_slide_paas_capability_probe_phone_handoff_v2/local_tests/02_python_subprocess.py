#!/usr/bin/env python3
import shutil
import subprocess

for command in ("sh", "opencode"):
    path = shutil.which(command)
    print(f"{command}: {path}")
    if not path:
        continue
    args = [path, "-c", "printf child-process-ok"] if command == "sh" else [path, "--version"]
    result = subprocess.run(args, capture_output=True, text=True, timeout=30, check=False)
    print({"returncode": result.returncode, "stdout": result.stdout.strip(), "stderr": result.stderr.strip()})
