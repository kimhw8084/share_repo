#!/usr/bin/env bash
set -euo pipefail

if [[ "${ENABLE_REAL_MODEL_TEST:-0}" != "1" ]]; then
  echo "SKIPPED: Set ENABLE_REAL_MODEL_TEST=1 only after approval."
  echo "The test sends the non-confidential prompt: Reply only with MODEL_OK"
  exit 0
fi

if ! command -v opencode >/dev/null 2>&1; then
  echo "FAIL: opencode not found"
  exit 2
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
printf '# Capability probe\nReturn only the requested short test string.\n' > "$TMP/AGENTS.md"
cd "$TMP"
opencode run "Reply only with MODEL_OK"
