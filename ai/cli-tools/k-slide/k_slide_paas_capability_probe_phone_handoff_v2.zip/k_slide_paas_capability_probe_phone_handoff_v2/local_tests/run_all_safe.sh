#!/usr/bin/env bash
set -u

STATUS=0
run() {
  echo
  echo "============================================================"
  echo "RUNNING: $*"
  echo "============================================================"
  "$@" || STATUS=$?
}

run bash local_tests/01_versions.sh
run python local_tests/02_python_subprocess.py
run python local_tests/03_opencode_server.py
run bash local_tests/06_opencode_api_inventory.sh

echo
if [[ $STATUS -eq 0 ]]; then
  echo "SAFE LOCAL TESTS COMPLETED WITHOUT A COMMAND FAILURE."
else
  echo "ONE OR MORE LOCAL TESTS FAILED. Review output and docs/RESULT_INTERPRETATION.md."
fi
exit "$STATUS"
