#!/usr/bin/env bash
set -euo pipefail

cat <<'TEXT'
This test inventories the OpenCode server API for the installed version.
It starts the server through local_tests/03_opencode_server.py only for health.
For a full inventory:

1. Start:
   OPENCODE_SERVER_PASSWORD=test-password opencode serve --hostname 127.0.0.1 --port 4097

2. In a second terminal, open:
   http://127.0.0.1:4097/doc

3. Confirm operations or SDK methods for:
   - global health
   - create/list/read session
   - send prompt/message
   - list commands
   - list agents
   - file/image attachment or message parts
   - event stream

4. Record differences in results/RESULTS_TEMPLATE.md.

Do not assume API paths from an older OpenCode release; treat the installed /doc page as source of truth.
TEXT
