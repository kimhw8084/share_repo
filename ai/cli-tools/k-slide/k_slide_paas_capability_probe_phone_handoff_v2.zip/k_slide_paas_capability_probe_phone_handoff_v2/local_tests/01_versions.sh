#!/usr/bin/env bash
set -u

echo '=== Runtime ==='
uname -a || true
python --version || true

echo
echo '=== Executables ==='
for cmd in node npm opencode git bash sh; do
  echo "--- $cmd ---"
  command -v "$cmd" || true
  "$cmd" --version 2>&1 | head -n 5 || true
done

echo
echo '=== Python PATH visibility ==='
python - <<'PY'
import os
import shutil
for name in ("node", "npm", "opencode", "git", "bash", "sh"):
    print(f"{name}: {shutil.which(name)}")
print("PATH:", os.environ.get("PATH"))
PY
