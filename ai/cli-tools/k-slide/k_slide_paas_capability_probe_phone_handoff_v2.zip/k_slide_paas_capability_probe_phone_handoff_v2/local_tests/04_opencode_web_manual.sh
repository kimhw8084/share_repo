#!/usr/bin/env bash
set -euo pipefail

if ! command -v opencode >/dev/null 2>&1; then
  echo "FAIL: opencode not found"
  exit 2
fi

PORT="${1:-4098}"
PASSWORD="${OPENCODE_SERVER_PASSWORD:-kslide-probe-only-change-me}"
cat <<TEXT
Starting OpenCode Web on localhost:${PORT}.

Manual checks:
1. Open the URL printed by OpenCode.
2. Verify the page loads.
3. Create a session.
4. Paste one non-confidential PNG screenshot.
5. Paste or attach multiple images.
6. Confirm output streams.
7. In a K-Slide project, confirm /k-slide appears.
8. Stop with Ctrl+C when finished.

This test uses HTTP Basic authentication. Username defaults to: opencode
Password for this test: ${PASSWORD}
TEXT

OPENCODE_SERVER_PASSWORD="$PASSWORD" opencode web --hostname 127.0.0.1 --port "$PORT"
