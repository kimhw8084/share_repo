# K-Slide Environment Results

## Deployment

- Project name:
- Company DNS:
- Publish type: fastapi
- Publish date:
- PaaS runtime/language version shown:
- Build command, if visible:
- Start command, if visible:
- Replica count:
- CPU limit:
- Memory limit:
- Persistent mount path:
- PostgreSQL linked: yes/no

## Published probe

Attach:

- `paas-probe-*.json`
- `paas-probe-*.md`

Record manually:

- `/health/live` loads: yes/no
- `/health/ready` loads: yes/no
- Node found:
- npm found:
- OpenCode found:
- Child process pass:
- Secondary port pass:
- Long-lived child alive immediately:
- Long-lived child alive after 5 minutes:
- Long-lived child alive after 15 minutes:
- Streaming incremental:
- SSE incremental:
- Identity header name:
- Is identity value a username, ID, or secret?:
- Persistence survives restart:
- Persistence survives republish:
- Persistence survives pod replacement:
- PostgreSQL SELECT 1 pass:
- OpenCode server test pass:
- Real model smoke pass:

## Local OpenCode

- `which opencode`:
- OpenCode version:
- Node version:
- npm version:
- Python can launch OpenCode: yes/no
- `opencode serve` health pass: yes/no
- OpenCode Web loads: yes/no
- Clipboard image paste: yes/no
- Multi-image attach: yes/no
- `/k-slide` command appears in test workspace: yes/no
- Output streams: yes/no
- Model receives image content: yes/no

## OpenCode server API inventory

Installed `/doc` supports:

- health:
- session create/list/read:
- prompt/message send:
- command list:
- agent list:
- image/file message parts:
- events/SSE:

## Identity and quota

- Trusted username header:
- Trusted email/employee-ID header:
- Authorization-group header:
- Can clients forge headers?:
- Personal terminal model quota identity:
- Personal OpenCode Web quota identity:
- Published app model quota identity:
- Can app forward employee identity to model gateway?:

## Platform-team answers

- npm install during build supported:
- approved npm registry:
- request timeout:
- idle timeout:
- upload limit:
- SSE support:
- WebSocket support:
- SIGTERM grace period:
- object storage available:
- confidential image retention rule:

## Notes and unexpected behavior

Add exact error messages with secrets removed.
