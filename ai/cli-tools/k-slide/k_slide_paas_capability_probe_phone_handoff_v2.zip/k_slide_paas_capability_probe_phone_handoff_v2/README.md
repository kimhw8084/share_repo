# K-Slide PaaS Capability Probe — Phone Handoff Edition

This repository is designed for your exact constraint: tests run on the work computer, while results may need to be communicated from an iPhone. **You do not need to type a long report.**

## One-command workflow

After publishing this repository as `fastapi`, run on the work computer:

```bash
./scripts/one_touch_handoff.sh "https://<project-company-dns>"
```

The script performs the published-runtime tests, checks local OpenCode, and asks only a few single-key questions (`y`, `n`, or `?`) for behaviors automation cannot observe.

It creates:

```text
results/handoff/PHONE_REPLY.txt       one short line to paste
results/handoff/PHONE_SCREENSHOT.png  large phone-friendly result image
results/handoff/PHONE_REPORT.html     readable browser report with copy button
results/handoff/REMAINING_QUESTIONS.txt only unresolved questions
results/handoff/FULL_HANDOFF.json     complete machine-readable evidence
```

To report the result, use **any one** of these methods:

1. Paste the one line from `PHONE_REPLY.txt`.
2. Upload `PHONE_SCREENSHOT.png`.
3. Display `PHONE_SCREENSHOT.png` on the work monitor, take a photo with the iPhone, and upload the photo.

No manual explanation is required. The short code contains a checksum and fixed status positions so it can be interpreted even when abbreviated.

Skip the manual questions when necessary:

```bash
./scripts/one_touch_handoff.sh "https://<project-company-dns>" --no-manual
```

Unknown items will be marked `?`, and `REMAINING_QUESTIONS.txt` will contain only the minimum follow-up questions. See [Phone handoff guide](docs/PHONE_HANDOFF.md).

---


This repository is a **safe deployment probe**, not the final K-Slide product. Copy it into a work Git repository, publish it using your company's `fastapi` application type, and use the included scripts to determine exactly which K-Slide architecture the PaaS can support.

It tests:

- company DNS and FastAPI startup;
- injected application port and proxy headers;
- Node, npm and OpenCode visibility inside the **published** Python process;
- Python child-process execution;
- long-lived child-process survival;
- binding and reaching a second localhost-only port;
- HTTP streaming and Server-Sent Events;
- corporate identity headers, masked by default;
- writable and persistent storage;
- PostgreSQL connectivity;
- image upload validation;
- OpenCode server startup and `/global/health`;
- optional, explicitly enabled real-model smoke testing.

## Safety characteristics

- It does not modify OpenCode provider/model configuration.
- It does not include or request model credentials.
- It does not dump the full environment.
- Identity header values are masked by default and accompanied by a one-way fingerprint.
- The real model test is disabled unless `ENABLE_REAL_MODEL_TEST=1` is deliberately configured.
- The model test uses only the non-confidential prompt `Reply only with MODEL_OK`.
- Uploaded test images are validated in memory and not retained.

## Fastest path

### 1. Copy into a work repository

Place the contents of this folder at the repository root. The root must contain:

```text
main.py
requirements.txt
start.sh
app/
scripts/
local_tests/
```

### 2. Publish as FastAPI

Use your company's normal publish command and select:

```text
fastapi
```

The PaaS should import:

```python
main:app
```

If it asks for a start command, use:

```bash
./start.sh
```

The script listens on `${PORT:-8000}`.

### 3. Configure safe probe variables

Recommended first publish:

```text
PROBE_DATA_DIR=/data/k-slide-probe
PROBE_START_LONG_CHILD=1
PROBE_MAX_UPLOAD_MB=25
PROBE_OPENCODE_PORT=4199
PROBE_IDENTITY_REVEAL=0
ENABLE_REAL_MODEL_TEST=0
```

Set `PROBE_DATA_DIR` to the mounted path your PaaS supports. If no mount is configured yet, use a writable temporary path and treat persistence as expected to fail after restart.

If you want the OpenCode server test to use a fixed password rather than a generated test password:

```text
PROBE_OPENCODE_SERVER_PASSWORD=<non-production-test-password>
```

### 4. Verify basic access

Open:

```text
https://<project-company-dns>/
https://<project-company-dns>/health/live
https://<project-company-dns>/health/ready
https://<project-company-dns>/diagnostics
```

Expected `/health/live` response:

```json
{
  "status": "ok",
  "app": "k-slide-paas-capability-probe",
  "version": "2.0.0"
}
```

If the root or `/health/live` does not return quickly, stop. The application has not been successfully published or routed. Inspect PaaS build/runtime logs.

### 5. Collect all published-runtime results

From a terminal with this repository checked out:

```bash
./scripts/run_published_probe.sh "https://<project-company-dns>"
```

This command:

- generates a non-confidential PNG;
- tests image upload;
- tests all safe runtime endpoints;
- tests streaming and SSE timing;
- writes a persistence marker;
- asks the app to start and health-check OpenCode;
- creates JSON and Markdown reports under `results/`.

For a corporate test certificate that your command-line trust store does not recognize:

```bash
./scripts/run_published_probe.sh "https://<project-company-dns>" --insecure
```

Use `--insecure` only for this diagnostic situation.

### 6. Test persistence after restart or republish

After the first collector run:

1. restart or republish the app;
2. do not delete its mounted storage;
3. run:

```bash
python scripts/collect_published_results.py \
  --base-url "https://<project-company-dns>" \
  --read-only
```

Interpretation:

- same persistence UUID: data survived that lifecycle event;
- marker missing: storage is ephemeral, mount is wrong, or the app started on another replica without shared storage;
- different UUID only occurs when the marker was overwritten by a non-read-only collector run.

### 7. Run local OpenCode tests

In the interactive work environment where you normally install OpenCode:

```bash
./local_tests/run_all_safe.sh
```

Manual OpenCode Web image test:

```bash
./local_tests/04_opencode_web_manual.sh
```

Optional real model smoke test:

```bash
ENABLE_REAL_MODEL_TEST=1 ./local_tests/05_model_smoke.sh
```

Do not run the real model test until use of the configured corporate model is approved.

## Result files to return

Return these files with secrets redacted:

```text
results/paas-probe-<timestamp>.json
results/paas-probe-<timestamp>.md
results/RESULTS_TEMPLATE.md
```

The JSON collector intentionally masks expected identity values. Review it anyway before sharing outside your company.

## Architecture decisions produced by the probe

| Result | Architectural meaning |
|---|---|
| OpenCode found + child process pass + secondary port pass + OpenCode server pass | Preferred architecture is viable: FastAPI employee UI plus internally managed `opencode serve` API |
| OpenCode found + child process pass, but secondary port/OpenCode server fails | Use direct `opencode run` background jobs rather than a persistent server |
| OpenCode missing, Node/npm present | Determine whether the FastAPI build can install `opencode-ai` using an approved npm registry |
| OpenCode missing and Node/npm absent | Embedded OpenCode is blocked; platform team must supply a supported runtime or separate service |
| Streaming/SSE buffered | Use background jobs and polling; this does not block K-Slide |
| No trusted identity header | Multi-user run ownership/admin roles are blocked until identity is supplied or app authentication is added |
| No persistent volume | Use PostgreSQL for metadata and approved object storage for artifacts, or accept temporary runs |
| PostgreSQL pass | Production metadata, audit, prompt versions and run ownership can be durable |
| Long-lived child dies | Do not embed `opencode serve`; use per-run subprocesses or an external OpenCode service |
| Multiple replicas without shared session routing | Force one replica for v1 or redesign engine/session ownership before scaling |

## Important distinction

Passing local terminal tests does **not** prove the published FastAPI runtime can run OpenCode. The published-runtime results are the source of truth for deployment architecture.

## Documentation index

- [Published testing guide](docs/PUBLISHED_TEST_GUIDE.md)
- [Local OpenCode testing guide](docs/LOCAL_TEST_GUIDE.md)
- [Complete interpretation matrix](docs/RESULT_INTERPRETATION.md)
- [Security and privacy notes](docs/SECURITY.md)
- [Platform-team questions](docs/PLATFORM_QUESTIONS.md)
- [Results template](results/RESULTS_TEMPLATE.md)
