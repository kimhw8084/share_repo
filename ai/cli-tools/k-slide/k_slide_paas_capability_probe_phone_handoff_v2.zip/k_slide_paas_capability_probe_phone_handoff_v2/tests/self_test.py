#!/usr/bin/env python3
from __future__ import annotations

import io
import json
import os
import tempfile
import sys
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from PIL import Image


def make_png() -> bytes:
    stream = io.BytesIO()
    Image.new("RGB", (320, 180), "white").save(stream, format="PNG")
    return stream.getvalue()


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="kslide-probe-selftest-") as tmp:
        os.environ["PROBE_DATA_DIR"] = tmp
        os.environ["PROBE_START_LONG_CHILD"] = "1"

        from fastapi.testclient import TestClient
        from app.main import app

        with TestClient(app) as client:
            checks = []

            response = client.get("/health/live")
            checks.append(("health/live", response.status_code == 200 and response.json().get("status") == "ok", response.text))

            response = client.get("/health/ready")
            checks.append(("health/ready", response.status_code == 200 and response.json().get("data_dir_writable") is True, response.text))

            response = client.get("/child-process")
            checks.append(("child-process", response.status_code == 200 and response.json().get("success") is True, response.text))

            response = client.get("/child-status")
            checks.append(("child-status", response.status_code == 200 and response.json().get("alive") is True, response.text))

            response = client.get("/secondary-port-test")
            checks.append(("secondary-port", response.status_code == 200 and response.json().get("success") is True, response.text))

            response = client.post("/persistence-write")
            marker = response.json().get("payload", {}).get("uuid")
            response2 = client.get("/persistence-read")
            checks.append(("persistence", response.status_code == 200 and response2.json().get("content", {}).get("uuid") == marker, response2.text))

            response = client.get("/database-test")
            checks.append(("database-not-configured", response.status_code == 200 and response.json().get("configured") is False, response.text))

            response = client.post(
                "/upload-test",
                files=[("files", ("probe.png", make_png(), "image/png"))],
            )
            checks.append(("image-upload", response.status_code == 200 and response.json().get("files", [{}])[0].get("detected_format") == "PNG", response.text))

            response = client.post(
                "/upload-test",
                files=[("files", ("fake.png", b"not-an-image", "image/png"))],
            )
            checks.append(("invalid-image-rejected", response.status_code == 415, response.text))

            response = client.get("/identity-test", headers={"AccessKey": "example-user"})
            body = response.json()
            checks.append(("identity-masked", response.status_code == 200 and body.get("found") and body["found"][0]["value"] != "example-user", response.text))

            response = client.post("/opencode/model-smoke")
            checks.append(("real-model-disabled", response.status_code == 403, response.text))

            response = client.get("/diagnostics")
            checks.append(("diagnostics", response.status_code == 200 and "versions" in response.json(), response.text))

        # Phone handoff generation from a synthetic probe result.
        synthetic = {
            "collected_at": "2026-07-20T12:00:00+00:00",
            "findings": [
                {"test": "HTTP/DNS", "status": "PASS", "meaning": "ok", "action": "none"},
                {"test": "Writable data directory", "status": "PASS", "meaning": "ok", "action": "none"},
                {"test": "Executable: node", "status": "PASS", "meaning": "ok", "action": "none"},
                {"test": "Executable: npm", "status": "PASS", "meaning": "ok", "action": "none"},
                {"test": "Executable: opencode", "status": "PASS", "meaning": "ok", "action": "none"},
                {"test": "Child processes", "status": "PASS", "meaning": "ok", "action": "none"},
                {"test": "Internal localhost port", "status": "PASS", "meaning": "ok", "action": "none"},
                {"test": "Long-lived child process", "status": "PASS", "meaning": "ok", "action": "none"},
                {"test": "HTTP streaming", "status": "FALLBACK_REQUIRED", "meaning": "buffered", "action": "poll"},
                {"test": "SSE", "status": "FALLBACK_REQUIRED", "meaning": "buffered", "action": "poll"},
                {"test": "Corporate identity header", "status": "BLOCKED_FOR_MULTIUSER", "meaning": "missing", "action": "header"},
                {"test": "Persistence current pod", "status": "PASS", "meaning": "ok", "action": "restart"},
                {"test": "PostgreSQL", "status": "NOT_CONFIGURED", "meaning": "missing", "action": "link"},
                {"test": "OpenCode server lifecycle", "status": "PASS", "meaning": "ok", "action": "use"},
            ],
        }
        local = {
            "executables": {"opencode": {"found": True, "success": True}},
            "opencode_server": {"success": True},
        }
        manual = {
            "observations": {
                "web_loads": "yes",
                "paste_one": "yes",
                "paste_multiple": "yes",
                "kslide_command": "yes",
                "output_streams": "yes",
                "real_model_ok": "unknown",
                "published_inherits_model": "unknown",
                "accesskey_kind": "username_or_employee_id",
            }
        }
        fixture_dir = Path(tmp) / "handoff-fixture"
        fixture_dir.mkdir()
        probe_path = fixture_dir / "probe.json"
        local_path = fixture_dir / "local.json"
        manual_path = fixture_dir / "manual.json"
        probe_path.write_text(json.dumps(synthetic), encoding="utf-8")
        local_path.write_text(json.dumps(local), encoding="utf-8")
        manual_path.write_text(json.dumps(manual), encoding="utf-8")
        handoff_dir = fixture_dir / "handoff"
        result = subprocess.run(
            [
                sys.executable,
                str(ROOT / "scripts" / "phone_handoff.py"),
                "--probe-json", str(probe_path),
                "--local-json", str(local_path),
                "--manual-json", str(manual_path),
                "--output-dir", str(handoff_dir),
            ],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )
        phone_ok = (
            result.returncode == 0
            and (handoff_dir / "PHONE_REPLY.txt").is_file()
            and (handoff_dir / "PHONE_SCREENSHOT.png").is_file()
            and (handoff_dir / "PHONE_REPORT.html").is_file()
            and (handoff_dir / "FULL_HANDOFF.json").is_file()
            and (handoff_dir / "PHONE_SCREENSHOT.png").stat().st_size > 10000
            and (handoff_dir / "PHONE_REPLY.txt").read_text().startswith("KSP2 ")
        )
        checks.append(("phone-handoff", phone_ok, result.stdout + result.stderr))

        failures = [name for name, passed, _ in checks if not passed]
        for name, passed, detail in checks:
            print(f"{'PASS' if passed else 'FAIL'}: {name}")
            if not passed:
                print(detail[:2000])

        if failures:
            print(json.dumps({"success": False, "failures": failures}, indent=2))
            return 1
        print(json.dumps({"success": True, "checks": len(checks)}, indent=2))
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
