# Published FastAPI Test Guide

Use these tests only after the repository is published under the company's `fastapi` type.

## Endpoint sequence

| Order | Endpoint | Method | Expected result | Failure meaning |
|---:|---|---|---|---|
| 1 | `/health/live` | GET | HTTP 200 immediately | Build, startup, ingress, DNS or routing failure |
| 2 | `/health/ready` | GET | HTTP 200 and writable directory | Configured data directory is not writable |
| 3 | `/versions` | GET | Paths/versions for available tools | Determines whether OpenCode can run or be installed |
| 4 | `/child-process` | GET | `success: true` | Embedded OpenCode cannot be executed by FastAPI |
| 5 | `/secondary-port-test` | GET | `success: true` | A persistent internal OpenCode server is likely not viable |
| 6 | `/child-status` | GET | `alive: true` over time | PaaS terminates long-lived children or startup hook failed |
| 7 | `/stream-test` | GET with `curl -N` | One line every ~2 seconds | Proxy buffers; use polling fallback |
| 8 | `/sse-test` | GET with `curl -N` | One event every ~2 seconds | SSE buffered; use polling fallback |
| 9 | `/identity-test` | GET in logged-in browser | Trusted identity header found | Per-user ownership/admin roles blocked |
| 10 | `/persistence-write` then `/persistence-read` | POST/GET | Marker exists | Current writable state works |
| 11 | Restart and `/persistence-read` | GET | Same marker UUID | Storage survives restart |
| 12 | `/database-test` | GET | `success: true` | Database absent, unreachable, TLS or driver mismatch |
| 13 | `/upload-test` | POST multipart | Valid image metadata | Ingress size, multipart, or image handling issue |
| 14 | `/opencode/info` | GET | `opencode.found: true` | Runtime lacks OpenCode |
| 15 | `/opencode/server-test` | POST | `success: true` | OpenCode startup/config/localhost lifecycle issue |
| 16 | `/opencode/model-smoke` | POST, opt-in | output contains `MODEL_OK` | Corporate model config/quota/runtime identity issue |

## Automated execution

```bash
./scripts/run_published_probe.sh "https://<dns>"
```

This includes the OpenCode server test but excludes the real model test.

To include the real model test, first configure the published app:

```text
ENABLE_REAL_MODEL_TEST=1
```

Then run:

```bash
python scripts/collect_published_results.py \
  --base-url "https://<dns>" \
  --run-opencode-server-test \
  --run-real-model-test
```

## Long-lived child-process test

`/child-status` should be checked:

- immediately after publish;
- after 1 minute;
- after 5 minutes;
- after 15 minutes;
- after the app has been idle;
- after expected platform maintenance/restart behavior.

A process that survives only for a few seconds does not establish that `opencode serve` can be operated reliably.

## Streaming test by hand

```bash
curl -N "https://<dns>/stream-test"
```

Expected timestamps arrive approximately every two seconds. If all lines appear together at the end, ingress buffering is active.

SSE:

```bash
curl -N "https://<dns>/sse-test"
```

Polling remains a required fallback even when streaming passes.

## Identity test caution

`/identity-test` returns only configured headers. Values are masked unless `PROBE_IDENTITY_REVEAL=1`.

Do not enable raw reveal in a shared environment unless approved. A header named `AccessKey` might be a credential rather than a username. The final product must store a trusted username/employee identifier, not a bearer secret.
