# Security and Privacy Notes

## Safe by default

- No provider keys are included.
- The application exposes only a small allowlist of environment variables.
- Identity values are masked and fingerprinted.
- Uploads are processed in memory and not saved.
- Only PNG, JPEG and WEBP are accepted after content validation.
- Real model invocation is disabled by default.
- Temporary OpenCode server tests bind only to `127.0.0.1` and terminate after testing.

## Identity warning

A header called `AccessKey` may be either an employee identifier or a credential. Do not assume it is safe to store.

Before building the final application, determine:

1. whether the value is a username/employee ID or a bearer secret;
2. whether callers can forge the header;
3. whether a separate trusted display-name/email header is available;
4. whether authorization groups are provided.

The final application should trust identity headers only from the corporate ingress and should never log raw credentials.

## Endpoint exposure

This probe is intended for a controlled internal test DNS. It contains diagnostics that reveal executable paths and runtime metadata. Remove the probe after capability testing; do not retain it as the production application.

## Real model test

Only enable:

```text
ENABLE_REAL_MODEL_TEST=1
```

when approved. The test prompt is non-confidential, but it still consumes model capacity and may create an audit entry.

## Sharing results

Before returning result files:

- inspect JSON for corporate hostnames and paths;
- redact anything your policy considers sensitive;
- do not include secrets or full AccessKey values;
- use the masked identity output unless raw identity testing is explicitly approved.
