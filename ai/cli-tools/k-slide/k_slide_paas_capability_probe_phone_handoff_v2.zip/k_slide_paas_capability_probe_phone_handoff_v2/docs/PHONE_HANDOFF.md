# Phone Handoff Guide

The probe is designed so the person operating the work computer does not need to retype logs or explain technical behavior on a phone.

## Preferred workflow

```bash
./scripts/one_touch_handoff.sh "https://<project-company-dns>"
```

The command performs four phases:

1. Tests the published FastAPI runtime through its company DNS.
2. Tests local Node, npm, OpenCode, Python subprocess execution, and `opencode serve`.
3. Asks single-key questions for browser behaviors that cannot be detected automatically.
4. Produces a short code and a phone-sized image.

## What to send

Send one of:

```text
results/handoff/PHONE_REPLY.txt
results/handoff/PHONE_SCREENSHOT.png
```

The image can be photographed directly from the work monitor. It is intentionally high-resolution, high-contrast, and contains no raw credentials.

## Short-code format

Example:

```text
KSP2 D+ W+ N+ M+ O- C+ L+ G+ T~ E~ I! P+ B0 S- | LO+ LS+ | WLY P1Y PMY KCY OSY RM? CF? AKU #ABC123
```

Published-runtime keys:

| Key | Test |
|---|---|
| D | Company DNS/FastAPI reachable |
| W | Data directory writable |
| N | Node available in published process |
| M | npm available in published process |
| O | OpenCode available in published process |
| C | Child processes work |
| L | Secondary localhost port works |
| G | Long-lived child process survives |
| T | HTTP streaming works |
| E | Server-Sent Events work |
| I | Trusted corporate identity header is present |
| P | Persistence marker exists in current pod |
| B | PostgreSQL is connected |
| S | Published FastAPI can start and reach OpenCode server |

Local-workspace keys:

| Key | Test |
|---|---|
| LO | Local OpenCode executable works |
| LS | Local `opencode serve` health test works |

Manual keys:

| Key | Observation |
|---|---|
| WL | OpenCode Web loads |
| P1 | One image can be pasted |
| PM | Multiple images can be attached |
| KC | `/k-slide` appears |
| OS | OpenCode output streams |
| RM | Real model smoke test returned `MODEL_OK` |
| CF | Published runtime inherits corporate model configuration |
| AK | AccessKey type: `U` user/employee ID, `S` secret/token, `O` other, `?` unknown |

Status symbols:

| Symbol | Meaning |
|---|---|
| `+` | Pass |
| `-` | Blocked |
| `!` | Multi-user identity blocked |
| `~` | Feature unavailable but a fallback exists |
| `0` | Not configured |
| `?` | Unknown, undecided, or not tested |

The final six hexadecimal characters are a checksum that helps catch mistyped codes.

## Manual wizard

The wizard accepts only:

```text
y = yes
n = no
? = unknown or not tested
```

For AccessKey classification:

```text
u = username or employee ID
s = secret or token
o = other
? = unknown
```

The wizard never asks you to enter an actual AccessKey value.

## When the test command reports blockers

The one-touch script still produces the handoff files. Architectural blockers are test results, not script crashes. The command exits successfully after producing the report unless the test tooling itself failed.

## Privacy

Before sharing the full JSON outside the company, review it. Expected identity header values are masked by the published probe. The phone handoff contains statuses and architecture decisions, not raw headers, model credentials, slide content, or environment secrets.
