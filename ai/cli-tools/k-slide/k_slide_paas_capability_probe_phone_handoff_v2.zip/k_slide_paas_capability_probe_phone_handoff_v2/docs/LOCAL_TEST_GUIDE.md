# Local OpenCode Test Guide

These tests determine what works in your interactive workspace. They do not replace published-runtime tests.

## Safe automated tests

```bash
./local_tests/run_all_safe.sh
```

This runs:

1. executable and version inventory;
2. Python subprocess visibility;
3. temporary authenticated `opencode serve` startup and `/global/health` request;
4. instructions for inventorying the installed API documentation.

## Manual OpenCode Web test

```bash
./local_tests/04_opencode_web_manual.sh
```

Verify using only non-confidential images:

- page loads;
- session creation works;
- clipboard image paste works;
- multiple images attach successfully;
- output streams;
- K-Slide custom command appears when started in a K-Slide project;
- the model receives the actual image content.

## Optional model test

```bash
ENABLE_REAL_MODEL_TEST=1 ./local_tests/05_model_smoke.sh
```

Expected output contains:

```text
MODEL_OK
```

Failure meanings:

| Failure | Likely meaning |
|---|---|
| `opencode: command not found` | OpenCode is not installed or not in PATH |
| Python cannot find OpenCode but shell can | Shell initialization changes PATH; published Python likely cannot see it either |
| OpenCode server exits immediately | Bad runtime/config/plugin/provider initialization; inspect stderr |
| `/global/health` returns 401 | Basic auth username/password mismatch |
| Server starts but model test fails | Server capability passes; provider/model identity or quota does not |
| Image paste UI works but model ignores image | Installed model/provider or message attachment path does not support the image as expected |

## API inventory

Start:

```bash
OPENCODE_SERVER_PASSWORD=test-password \
opencode serve --hostname 127.0.0.1 --port 4097
```

Open:

```text
http://127.0.0.1:4097/doc
```

For the installed version, confirm support for:

- global health;
- session create/list/read;
- prompts/messages;
- commands and agents;
- file or image message parts;
- event streaming.

The installed API documentation is the source of truth. Do not rely on remembered endpoint paths from an older release.
