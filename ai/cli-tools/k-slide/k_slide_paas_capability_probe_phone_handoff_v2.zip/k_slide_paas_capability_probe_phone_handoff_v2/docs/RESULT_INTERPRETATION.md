# Complete Result Interpretation

## Hard blockers

| Failed capability | Impact | Final design consequence |
|---|---|---|
| Published FastAPI cannot start | No app surface | Resolve PaaS packaging/start command before K-Slide work |
| Python child processes blocked | FastAPI cannot launch OpenCode | Require external OpenCode service or platform-supported worker |
| OpenCode unavailable and cannot be installed | No K-Slide engine | Platform runtime change is required |
| No trusted employee identity | Cannot safely isolate user histories or assign admins | Add ingress identity header or app authentication |
| Corporate model unavailable in published runtime | Real image comprehension cannot run | Platform must propagate approved model configuration/identity |

## Preferred architecture blockers only

| Failed capability | Impact | Fallback |
|---|---|---|
| Secondary localhost port blocked | Cannot maintain internal `opencode serve` | Use `opencode run` per job |
| Long-lived child terminated | Persistent server unreliable | Use short-lived subprocess jobs or external engine |
| SSE/streaming buffered | No live token/stage stream | Background execution plus polling |
| WebSockets blocked | Stock OpenCode Web proxy may fail | Custom HTTP/SSE/polling K-Slide UI |
| Persistent volume absent | Artifacts disappear on restart | PostgreSQL metadata + object storage, or temporary downloads |
| PostgreSQL absent | Governance/history less durable | SQLite only for local/pilot with persistent volume |

## Green-light combination for preferred architecture

The preferred design—focused FastAPI employee UI plus internally managed OpenCode server—is supported when all are true:

```text
health live PASS
health ready PASS
opencode found PASS
child process PASS
secondary port PASS
long-lived child PASS
OpenCode server lifecycle PASS
corporate model smoke PASS
trusted identity PASS
```

Streaming and SSE improve experience but are not hard blockers because polling can replace them.

## Rate-limit interpretation

This probe cannot determine model quota ownership from HTTP behavior alone. After the real model smoke test, inspect the corporate AI gateway/audit view and record whether the request is attributed to:

- the employee;
- the PaaS application/service account;
- a shared corporate credential;
- both application and employee.

This determines whether a published service consumes shared application quota or each employee's quota.

## Replica interpretation

If the platform runs multiple replicas:

- `/child-status` may report different PIDs or hosts on different requests;
- persistence may appear inconsistent without a shared mount;
- each replica may start a separate OpenCode server;
- an OpenCode session created on one replica may not exist on another.

For the first production release, force one replica unless the final architecture externalizes engine/session routing.
