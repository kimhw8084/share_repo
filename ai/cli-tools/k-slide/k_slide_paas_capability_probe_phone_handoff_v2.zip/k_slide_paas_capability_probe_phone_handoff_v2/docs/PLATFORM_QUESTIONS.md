# Questions for the PaaS and AI Platform Teams

Record answers in `results/RESULTS_TEMPLATE.md`.

1. Can a published FastAPI process launch and maintain child processes?
2. Can it bind and access a second localhost-only port?
3. Are SSE responses passed without buffering?
4. Are WebSockets supported?
5. What are request and idle timeouts?
6. What is the ingress upload-size limit?
7. Which trusted headers contain username, employee ID, email and authorization groups?
8. Can a caller forge those headers through the company DNS?
9. Is a persistent volume available, and what mount path should be used?
10. Is approved object storage available for confidential artifacts?
11. How is `psqldb` linked and which environment variable contains the URL?
12. Does PostgreSQL require TLS parameters or a custom CA?
13. How many replicas are created by default?
14. Can the release be fixed to one replica?
15. What CPU, RAM, ephemeral disk and process limits apply?
16. What SIGTERM grace period is provided?
17. Can npm packages be installed during build?
18. Which approved npm registry must be used?
19. Does the published runtime inherit the same umbrella OpenCode/Gemma configuration as the interactive terminal?
20. What identity and quota bucket does the AI gateway record for calls from the published app?
21. Can trusted employee identity be forwarded to the AI gateway for attribution?
22. What slide-data classification and retention rules apply?
23. Who may inspect user slide content during support incidents?
24. How long are application and platform logs retained?
25. Which readiness and liveness endpoint settings can the publish command configure?
