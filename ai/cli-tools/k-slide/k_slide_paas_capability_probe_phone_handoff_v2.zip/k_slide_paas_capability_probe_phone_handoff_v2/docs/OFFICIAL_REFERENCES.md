# Official References Used

These links should be rechecked against the OpenCode version installed in the corporate environment.

- OpenCode server: https://opencode.ai/docs/server/
- OpenCode web interface: https://opencode.ai/docs/web/
- OpenCode CLI: https://opencode.ai/docs/cli/
- OpenCode SDK: https://opencode.ai/docs/sdk/
- OpenCode network/proxy notes: https://opencode.ai/docs/network/
- OpenCode configuration: https://opencode.ai/docs/config/

Current official documentation describes:

- `opencode serve [--port] [--hostname] [--cors]` as a headless HTTP server;
- an OpenAPI document at the server `/doc` route;
- `/global/health` for server health/version;
- `opencode web` for the browser interface;
- `OPENCODE_SERVER_PASSWORD` for HTTP Basic authentication when the server is exposed beyond local use.

The installed server's `/doc` page remains the authoritative contract for its exact API operations.
