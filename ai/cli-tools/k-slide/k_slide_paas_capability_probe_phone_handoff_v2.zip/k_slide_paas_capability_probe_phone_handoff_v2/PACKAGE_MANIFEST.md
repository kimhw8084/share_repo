# Package Manifest

## Application

- `main.py` — FastAPI import entrypoint
- `app/main.py` — safe published-runtime probes
- `app/settings.py` — environment-driven settings
- `app/util.py` — safe version, masking and runtime helpers
- `requirements.txt` — pinned Python dependencies
- `start.sh` — PaaS-compatible Uvicorn startup

## One-touch phone handoff

- `scripts/one_touch_handoff.sh` — complete published + local + manual workflow
- `scripts/local_auto_results.py` — machine-readable local Node/npm/OpenCode checks
- `scripts/manual_observation_wizard.py` — single-key browser/model observation wizard
- `scripts/phone_handoff.py` — short code, PNG, HTML, and unresolved-question generator
- `docs/PHONE_HANDOFF.md` — code legend and low-typing workflow

Generated handoff files:

- `results/handoff/PHONE_REPLY.txt`
- `results/handoff/PHONE_SCREENSHOT.png`
- `results/handoff/PHONE_REPORT.html`
- `results/handoff/REMAINING_QUESTIONS.txt`
- `results/handoff/FULL_HANDOFF.json`

## Automated published testing

- `scripts/collect_published_results.py` — DNS collector, decision report, latest-result aliases
- `scripts/run_published_probe.sh` — published test only
- `scripts/generate_test_image.py` — non-confidential upload fixture
- `scripts/check_package.sh` — local package self-test
- `tests/self_test.py` — FastAPI endpoints plus handoff generation integration test

## Local OpenCode testing

- `local_tests/01_versions.sh`
- `local_tests/02_python_subprocess.py`
- `local_tests/03_opencode_server.py`
- `local_tests/04_opencode_web_manual.sh`
- `local_tests/05_model_smoke.sh`
- `local_tests/06_opencode_api_inventory.sh`
- `local_tests/run_all_safe.sh`

## Documentation

- `README.md`
- `docs/PHONE_HANDOFF.md`
- `docs/PUBLISHED_TEST_GUIDE.md`
- `docs/LOCAL_TEST_GUIDE.md`
- `docs/RESULT_INTERPRETATION.md`
- `docs/SECURITY.md`
- `docs/PLATFORM_QUESTIONS.md`
- `docs/OFFICIAL_REFERENCES.md`
- `results/RESULTS_TEMPLATE.md`
