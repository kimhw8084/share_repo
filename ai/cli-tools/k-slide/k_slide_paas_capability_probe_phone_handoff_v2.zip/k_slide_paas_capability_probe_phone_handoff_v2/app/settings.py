from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    data_dir: Path = Path(os.getenv("PROBE_DATA_DIR", "/tmp/k-slide-probe"))
    max_upload_mb: int = _int("PROBE_MAX_UPLOAD_MB", 25)
    start_long_child: bool = _bool("PROBE_START_LONG_CHILD", True)
    opencode_port: int = _int("PROBE_OPENCODE_PORT", 4199)
    opencode_password: str = os.getenv("PROBE_OPENCODE_SERVER_PASSWORD", "")
    identity_headers: tuple[str, ...] = tuple(
        item.strip()
        for item in os.getenv(
            "PROBE_IDENTITY_HEADERS",
            "AccessKey,X-Access-Key,X-Auth-Request-User,X-Forwarded-User,Remote-User,X-User,X-Email,X-Forwarded-Email",
        ).split(",")
        if item.strip()
    )
    reveal_identity: bool = _bool("PROBE_IDENTITY_REVEAL", False)
    database_url: str = os.getenv("PROBE_DATABASE_URL") or os.getenv("DATABASE_URL", "")
    enable_real_model_test: bool = _bool("ENABLE_REAL_MODEL_TEST", False)
    real_model_test_prompt: str = os.getenv("REAL_MODEL_TEST_PROMPT", "Reply only with MODEL_OK")


settings = Settings()
