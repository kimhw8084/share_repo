from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any


SECRET_NAME_PATTERN = re.compile(r"(secret|token|password|credential|api[_-]?key|access[_-]?key)", re.I)


def executable_version(name: str, timeout: int = 20) -> dict[str, Any]:
    path = shutil.which(name)
    if not path:
        return {"found": False, "path": None, "version": None, "returncode": None, "stderr": None}
    try:
        result = subprocess.run(
            [path, "--version"],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        version = (result.stdout or result.stderr).strip()
        return {
            "found": True,
            "path": path,
            "version": version,
            "returncode": result.returncode,
            "stderr": result.stderr.strip() or None,
        }
    except Exception as exc:  # diagnostic endpoint must report, not crash
        return {"found": True, "path": path, "version": None, "returncode": None, "stderr": repr(exc)}


def masked(value: str | None) -> str | None:
    if value is None:
        return None
    if len(value) <= 4:
        return "*" * len(value)
    return f"{value[:2]}***{value[-2:]}"


def stable_fingerprint(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", errors="replace")).hexdigest()[:16]


def safe_environment_snapshot() -> dict[str, Any]:
    allow = {
        "PORT",
        "HOST",
        "HOME",
        "USER",
        "PWD",
        "PATH",
        "HTTP_PROXY",
        "HTTPS_PROXY",
        "NO_PROXY",
        "KUBERNETES_SERVICE_HOST",
        "KUBERNETES_SERVICE_PORT",
    }
    snapshot: dict[str, Any] = {}
    for name in sorted(allow):
        value = os.getenv(name)
        if value is None:
            continue
        snapshot[name] = masked(value) if SECRET_NAME_PATTERN.search(name) else value
    return snapshot


def runtime_summary() -> dict[str, Any]:
    return {
        "python": sys.version,
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "cpu_count": os.cpu_count(),
        "cwd": str(Path.cwd()),
    }


def json_text(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2, default=str)
