from __future__ import annotations

import asyncio
import base64
import io
import json
import os
import resource
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, AsyncIterator

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from PIL import Image, UnidentifiedImageError
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError

from .settings import settings
from .util import executable_version, masked, runtime_summary, safe_environment_snapshot, stable_fingerprint

APP_VERSION = "2.0.0"
LONG_CHILD: subprocess.Popen[str] | None = None


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def terminate_process(process: subprocess.Popen[Any] | None, timeout: float = 5.0) -> None:
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=timeout)


@asynccontextmanager
async def lifespan(_: FastAPI):
    global LONG_CHILD
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    if settings.start_long_child:
        LONG_CHILD = subprocess.Popen(
            [sys.executable, "-c", "import time; time.sleep(86400)"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
        )
    try:
        yield
    finally:
        terminate_process(LONG_CHILD)
        LONG_CHILD = None


app = FastAPI(
    title="K-Slide PaaS Capability Probe",
    version=APP_VERSION,
    description="Safe diagnostic application for validating whether a managed FastAPI PaaS can host K-Slide and an internal OpenCode server.",
    lifespan=lifespan,
)


@app.get("/", response_class=HTMLResponse)
def home() -> str:
    return """
    <!doctype html>
    <html lang="en">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      <title>K-Slide PaaS Probe</title>
      <style>
        :root { color-scheme: light dark; font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
        body { max-width: 920px; margin: 0 auto; padding: 40px 22px; line-height: 1.55; }
        h1 { letter-spacing: -0.035em; }
        .card { border: 1px solid color-mix(in srgb,currentColor 18%,transparent); border-radius: 18px; padding: 18px; margin: 14px 0; }
        code { font-family: ui-monospace,SFMono-Regular,Menlo,monospace; }
        a { color: inherit; }
        .ok { font-weight: 600; }
      </style>
    </head>
    <body>
      <p class="ok">Capability probe is running.</p>
      <h1>K-Slide PaaS Capability Probe</h1>
      <p>This is not the final K-Slide application. It safely tests the runtime, child processes, internal ports, persistence, identity headers, database access, streaming, uploads, and OpenCode availability.</p>
      <div class="card">
        <h2>Start here</h2>
        <ul>
          <li><a href="/health/live"><code>/health/live</code></a></li>
          <li><a href="/health/ready"><code>/health/ready</code></a></li>
          <li><a href="/diagnostics"><code>/diagnostics</code></a></li>
          <li><a href="/docs"><code>/docs</code></a></li>
        </ul>
      </div>
      <p>Use <code>scripts/collect_published_results.py</code> from a terminal to collect the complete result set.</p>
    </body>
    </html>
    """


@app.get("/health/live")
def health_live() -> dict[str, Any]:
    return {"status": "ok", "app": "k-slide-paas-capability-probe", "version": APP_VERSION, "time": now_iso()}


@app.get("/health/ready")
def health_ready() -> JSONResponse:
    writable = False
    error = None
    try:
        settings.data_dir.mkdir(parents=True, exist_ok=True)
        test_path = settings.data_dir / f".write-test-{uuid.uuid4().hex}"
        test_path.write_text("ok", encoding="utf-8")
        test_path.unlink()
        writable = True
    except Exception as exc:
        error = repr(exc)

    payload = {
        "status": "ok" if writable else "not_ready",
        "data_dir": str(settings.data_dir),
        "data_dir_writable": writable,
        "error": error,
    }
    return JSONResponse(payload, status_code=200 if writable else 503)


@app.get("/versions")
def versions() -> dict[str, Any]:
    return {name: executable_version(name) for name in ("python", "node", "npm", "opencode", "git", "bash", "sh")}


@app.get("/runtime")
def runtime() -> dict[str, Any]:
    limits = {}
    for name, key in (
        ("address_space", resource.RLIMIT_AS),
        ("process_count", resource.RLIMIT_NPROC),
        ("open_files", resource.RLIMIT_NOFILE),
        ("cpu_seconds", resource.RLIMIT_CPU),
    ):
        try:
            limits[name] = resource.getrlimit(key)
        except (ValueError, OSError) as exc:
            limits[name] = {"error": repr(exc)}
    disk = shutil.disk_usage(settings.data_dir)
    return {
        "runtime": runtime_summary(),
        "safe_environment": safe_environment_snapshot(),
        "resource_limits": limits,
        "disk": {"total": disk.total, "used": disk.used, "free": disk.free},
        "data_dir": str(settings.data_dir),
    }


@app.get("/child-process")
def child_process() -> dict[str, Any]:
    try:
        result = subprocess.run(
            ["sh", "-c", "printf child-process-ok"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        return {"success": result.returncode == 0 and result.stdout == "child-process-ok", "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
    except Exception as exc:
        return {"success": False, "error": repr(exc)}


@app.get("/child-status")
def child_status() -> dict[str, Any]:
    return {
        "enabled": settings.start_long_child,
        "pid": LONG_CHILD.pid if LONG_CHILD else None,
        "alive": bool(LONG_CHILD and LONG_CHILD.poll() is None),
        "returncode": LONG_CHILD.poll() if LONG_CHILD else None,
    }


@app.get("/secondary-port-test")
def secondary_port_test() -> dict[str, Any]:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]

    process = subprocess.Popen(
        [sys.executable, "-m", "http.server", str(port), "--bind", "127.0.0.1"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
    )
    try:
        deadline = time.monotonic() + 8
        last_error = None
        while time.monotonic() < deadline:
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}", timeout=2) as response:
                    return {"success": response.status == 200, "status": response.status, "port": port}
            except Exception as exc:
                last_error = repr(exc)
                time.sleep(0.25)
        stderr = process.stderr.read() if process.stderr else ""
        return {"success": False, "port": port, "error": last_error, "stderr": stderr[-2000:]}
    finally:
        terminate_process(process)


@app.get("/stream-test")
async def stream_test() -> StreamingResponse:
    async def generate() -> AsyncIterator[bytes]:
        for number in range(5):
            yield f"step {number} {now_iso()}\n".encode()
            await asyncio.sleep(2)
    return StreamingResponse(generate(), media_type="text/plain", headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"})


@app.get("/sse-test")
async def sse_test() -> StreamingResponse:
    async def generate() -> AsyncIterator[bytes]:
        for number in range(5):
            data = json.dumps({"step": number, "time": now_iso()})
            yield f"event: probe\ndata: {data}\n\n".encode()
            await asyncio.sleep(2)
    return StreamingResponse(generate(), media_type="text/event-stream", headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"})


@app.get("/environment-safe")
def environment_safe() -> dict[str, Any]:
    return safe_environment_snapshot()


@app.get("/identity-test")
def identity_test(request: Request) -> dict[str, Any]:
    headers_by_lower = {key.lower(): value for key, value in request.headers.items()}
    found = []
    for configured_name in settings.identity_headers:
        raw = headers_by_lower.get(configured_name.lower())
        if raw is None:
            continue
        found.append(
            {
                "header": configured_name,
                "value": raw if settings.reveal_identity else masked(raw),
                "fingerprint": stable_fingerprint(raw),
                "length": len(raw),
            }
        )
    return {
        "found": found,
        "reveal_identity": settings.reveal_identity,
        "note": "Raw identity values are masked by default. A fingerprint helps compare requests without storing the credential.",
    }


@app.post("/persistence-write")
def persistence_write() -> dict[str, Any]:
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    path = settings.data_dir / "persistence-test.json"
    payload = {"written_at": now_iso(), "instance_hint": os.getenv("HOSTNAME"), "uuid": uuid.uuid4().hex}
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return {"written": True, "path": str(path), "payload": payload}


@app.get("/persistence-read")
def persistence_read() -> dict[str, Any]:
    path = settings.data_dir / "persistence-test.json"
    return {"exists": path.exists(), "path": str(path), "content": json.loads(path.read_text(encoding="utf-8")) if path.exists() else None}


@app.delete("/persistence-delete")
def persistence_delete() -> dict[str, Any]:
    path = settings.data_dir / "persistence-test.json"
    existed = path.exists()
    if existed:
        path.unlink()
    return {"deleted": existed, "path": str(path)}


@app.get("/database-test")
def database_test() -> dict[str, Any]:
    if not settings.database_url:
        return {"configured": False, "success": False, "meaning": "No PROBE_DATABASE_URL or DATABASE_URL was injected."}
    database_url = settings.database_url
    safe_scheme = database_url.split(":", 1)[0]
    if database_url.startswith("postgres://"):
        database_url = "postgresql+psycopg://" + database_url[len("postgres://"):]
    elif database_url.startswith("postgresql://"):
        database_url = "postgresql+psycopg://" + database_url[len("postgresql://"):]
    try:
        engine = create_engine(database_url, pool_pre_ping=True)
        with engine.connect() as connection:
            value = connection.execute(text("SELECT 1")).scalar_one()
        engine.dispose()
        return {"configured": True, "success": value == 1, "driver_scheme": safe_scheme, "select_1": value}
    except SQLAlchemyError as exc:
        return {"configured": True, "success": False, "driver_scheme": safe_scheme, "error_type": type(exc).__name__, "error": str(exc)[:2000]}


def _image_type(data: bytes) -> tuple[str, tuple[int, int]]:
    try:
        with Image.open(io.BytesIO(data)) as image:
            image.verify()
        with Image.open(io.BytesIO(data)) as image:
            fmt = (image.format or "").upper()
            size = image.size
    except (UnidentifiedImageError, OSError) as exc:
        raise HTTPException(status_code=415, detail=f"The upload is not a valid image: {exc}") from exc
    allowed = {"PNG", "JPEG", "WEBP"}
    if fmt not in allowed:
        raise HTTPException(status_code=415, detail=f"Unsupported image format {fmt!r}; allowed: {sorted(allowed)}")
    return fmt, size


@app.post("/upload-test")
async def upload_test(files: list[UploadFile] = File(...)) -> dict[str, Any]:
    if not files:
        raise HTTPException(status_code=400, detail="At least one image is required.")
    maximum = settings.max_upload_mb * 1024 * 1024
    results = []
    total = 0
    for upload in files:
        data = await upload.read(maximum + 1)
        if len(data) > maximum:
            raise HTTPException(status_code=413, detail=f"{upload.filename!r} exceeds {settings.max_upload_mb} MB.")
        total += len(data)
        fmt, dimensions = _image_type(data)
        results.append({"original_filename": upload.filename, "content_type": upload.content_type, "detected_format": fmt, "width": dimensions[0], "height": dimensions[1], "bytes": len(data), "sha256_prefix": __import__("hashlib").sha256(data).hexdigest()[:16]})
    return {"success": True, "file_count": len(results), "total_bytes": total, "files": results}


def _basic_auth_header(password: str) -> str:
    token = base64.b64encode(f"opencode:{password}".encode()).decode()
    return f"Basic {token}"


def _opencode_health(port: int, password: str, timeout: float = 2.0) -> dict[str, Any]:
    request = urllib.request.Request(
        f"http://127.0.0.1:{port}/global/health",
        headers={"Authorization": _basic_auth_header(password)},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return {"status": response.status, "body": json.loads(response.read().decode("utf-8"))}


@app.get("/opencode/info")
def opencode_info() -> dict[str, Any]:
    return {
        "opencode": executable_version("opencode"),
        "node": executable_version("node"),
        "npm": executable_version("npm"),
        "password_configured": bool(settings.opencode_password),
        "configured_test_port": settings.opencode_port,
        "real_model_test_enabled": settings.enable_real_model_test,
    }


@app.post("/opencode/server-test")
def opencode_server_test() -> dict[str, Any]:
    executable = shutil.which("opencode")
    if not executable:
        return {"success": False, "classification": "OPENCODE_NOT_FOUND", "message": "The published runtime cannot find the opencode executable."}
    password = settings.opencode_password or uuid.uuid4().hex
    env = os.environ.copy()
    env["OPENCODE_SERVER_PASSWORD"] = password
    process = subprocess.Popen(
        [executable, "serve", "--hostname", "127.0.0.1", "--port", str(settings.opencode_port)],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    try:
        deadline = time.monotonic() + 45
        last_error = None
        while time.monotonic() < deadline:
            if process.poll() is not None:
                break
            try:
                health = _opencode_health(settings.opencode_port, password)
                return {"success": True, "classification": "PASS", "health": health, "port": settings.opencode_port}
            except Exception as exc:
                last_error = repr(exc)
                time.sleep(0.5)
        stdout, stderr = process.communicate(timeout=5) if process.poll() is not None else ("", "")
        return {"success": False, "classification": "SERVER_DID_NOT_BECOME_HEALTHY", "returncode": process.poll(), "last_error": last_error, "stdout_tail": stdout[-2000:], "stderr_tail": stderr[-4000:]}
    finally:
        terminate_process(process, timeout=10)


@app.post("/opencode/model-smoke")
def opencode_model_smoke() -> dict[str, Any]:
    if not settings.enable_real_model_test:
        raise HTTPException(status_code=403, detail="Real model test is disabled. Set ENABLE_REAL_MODEL_TEST=1 only with approval and a non-confidential prompt.")
    executable = shutil.which("opencode")
    if not executable:
        return {"success": False, "classification": "OPENCODE_NOT_FOUND"}
    with tempfile.TemporaryDirectory(prefix="kslide-model-smoke-") as tmp:
        Path(tmp, "AGENTS.md").write_text("# Capability probe\nReturn only the requested short test string.\n", encoding="utf-8")
        try:
            result = subprocess.run(
                [executable, "run", settings.real_model_test_prompt],
                cwd=tmp,
                capture_output=True,
                text=True,
                timeout=120,
                check=False,
            )
            return {
                "success": result.returncode == 0 and "MODEL_OK" in result.stdout,
                "returncode": result.returncode,
                "stdout_tail": result.stdout[-2000:],
                "stderr_tail": result.stderr[-2000:],
                "note": "This test intentionally uses a non-confidential prompt and does not modify provider configuration.",
            }
        except subprocess.TimeoutExpired as exc:
            return {"success": False, "classification": "TIMEOUT", "timeout_seconds": 120, "stdout_tail": (exc.stdout or "")[-1000:] if isinstance(exc.stdout, str) else None, "stderr_tail": (exc.stderr or "")[-1000:] if isinstance(exc.stderr, str) else None}


@app.get("/proxy-test")
def proxy_test(request: Request) -> dict[str, Any]:
    return {
        "scheme": request.url.scheme,
        "host": request.url.hostname,
        "port": request.url.port,
        "root_path": request.scope.get("root_path"),
        "client": request.client.host if request.client else None,
        "forwarded": request.headers.get("forwarded"),
        "x_forwarded_proto": request.headers.get("x-forwarded-proto"),
        "x_forwarded_host": request.headers.get("x-forwarded-host"),
        "x_forwarded_for_masked": masked(request.headers.get("x-forwarded-for")),
    }


@app.get("/diagnostics")
def diagnostics(request: Request) -> dict[str, Any]:
    return {
        "probe": {"version": APP_VERSION, "time": now_iso()},
        "health": health_live(),
        "versions": versions(),
        "runtime": runtime(),
        "child_status": child_status(),
        "identity": identity_test(request),
        "database": database_test(),
        "opencode": opencode_info(),
        "proxy": proxy_test(request),
        "persistence": persistence_read(),
    }
