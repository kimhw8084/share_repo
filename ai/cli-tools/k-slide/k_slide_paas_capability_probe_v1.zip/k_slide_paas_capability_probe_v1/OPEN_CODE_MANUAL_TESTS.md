# OpenCode Manual Test Checklist

## Local server

```bash
PROBE_OPENCODE_PASSWORD=temporary-test-password \
./scripts/opencode_server_test.sh
```

Pass conditions:

- process starts;
- `/global/health` returns HTTP 200;
- body reports healthy and a version;
- `/doc` returns HTTP 200.

## API surface

Start a persistent server:

```bash
OPENCODE_SERVER_PASSWORD=temporary-test-password \
opencode serve --hostname 127.0.0.1 --port 4097
```

In another terminal:

```bash
PROBE_OPENCODE_PASSWORD=temporary-test-password \
OPENCODE_URL=http://127.0.0.1:4097 \
python scripts/opencode_api_surface_probe.py
```

Required endpoints:

- global health;
- OpenAPI documentation;
- current project;
- sessions;
- commands;
- agents.

## Web/image test

```bash
PROBE_OPENCODE_PROJECT_DIR=/path/to/k-slide-project \
./scripts/opencode_web_manual.sh
```

Record:

| Check | Result | Notes |
|---|---|---|
| Browser page loads | | |
| Login works | | |
| Session creation | | |
| PNG clipboard paste | | |
| JPEG clipboard paste | | |
| Multi-image attachment | | |
| Image order preserved | | |
| `/k-slide` visible | | |
| Correct agent | | |
| Skill recognized | | |
| Output streams | | |
| Follow-up question retains context | | |

## K-Slide static checks

```bash
KSLIDE_PROJECT_DIR=/path/to/k-slide-project \
./scripts/kslide_project_test.sh
```

This checks the command, agent and skill paths plus skill frontmatter and task-denial signal.
