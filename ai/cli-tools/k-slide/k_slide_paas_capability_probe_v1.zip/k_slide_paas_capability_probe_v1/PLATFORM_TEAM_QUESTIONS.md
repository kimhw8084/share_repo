# Questions for the PaaS / Platform Team

Copy this list into a platform-support ticket if the probe cannot answer them.

| # | Question | Why K-Slide needs it |
|---:|---|---|
| 1 | Can published FastAPI apps launch and maintain child processes? | OpenCode engine process |
| 2 | Can a child process bind a localhost-only secondary port? | Internal `opencode serve` |
| 3 | Are SSE responses supported without buffering? | Live progress |
| 4 | Are WebSocket upgrades supported? | Only needed to proxy stock OpenCode Web |
| 5 | What are request and idle timeouts? | Long slide analysis |
| 6 | What is the maximum request/upload size? | Multi-image upload |
| 7 | Which authenticated employee identity headers are injected? | Run ownership and audit |
| 8 | Can external callers forge those headers? | Trust boundary |
| 9 | Is AccessKey an identifier or credential/token? | Safe logging design |
| 10 | Is a persistent volume available, and what mount path should be used? | Reports and configuration |
| 11 | Is object storage available? | Durable images/artifacts |
| 12 | How is PostgreSQL linked and which URL variable is injected? | Metadata and governance |
| 13 | Can the app be pinned to one replica? | Initial session engine design |
| 14 | Can the platform autoscale it? If so, can autoscaling be disabled? | Session consistency |
| 15 | Which health paths can be configured for readiness/liveness? | Safe routing |
| 16 | Does the app receive SIGTERM and how long is the grace period? | Graceful shutdown |
| 17 | Can npm packages be installed at build time? | OpenCode installation |
| 18 | Must npm use an internal registry? | Supply-chain/network policy |
| 19 | Can the published runtime reach the corporate Gemma endpoint? | Model execution |
| 20 | How is AI quota calculated for a published app? | Fair-use/capacity design |
| 21 | Can employee identity be forwarded to the AI gateway? | Per-user accounting |
| 22 | What CPU, memory, storage and process limits apply? | Capacity/concurrency |
| 23 | Are application logs available and for how long? | Operations/audit |
| 24 | Are confidential slide screenshots permitted in the selected storage? | Data classification |
| 25 | Can app roles use corporate LDAP/AccessKey groups? | Admin authorization |
