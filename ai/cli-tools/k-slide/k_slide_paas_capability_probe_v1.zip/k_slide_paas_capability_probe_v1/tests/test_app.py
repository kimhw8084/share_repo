from __future__ import annotations

import time
from pathlib import Path

from fastapi.testclient import TestClient

import main


def configure_temp_paths(tmp_path: Path) -> None:
    main.DATA_DIR = tmp_path
    main.PERSISTENCE_FILE = tmp_path / "persistence-test.json"
    main.LOG_DIR = tmp_path / "logs"
    main.RESULTS_DIR = tmp_path / "results"


def test_core_endpoints(tmp_path: Path) -> None:
    configure_temp_paths(tmp_path)
    with TestClient(main.app) as client:
        assert client.get("/health/live").status_code == 200
        assert client.get("/health/ready").status_code == 200

        child = client.get("/probe/child-process").json()
        assert child["passed"] is True

        secondary = client.get("/probe/secondary-port").json()
        assert secondary["passed"] is True

        write_result = client.get("/probe/persistence/write").json()
        assert write_result["passed"] is True
        read_result = client.get("/probe/persistence/read").json()
        assert read_result["exists"] is True
        assert read_result["payload"]["probe_id"] == write_result["payload"]["probe_id"]

        identity = client.get(
            "/probe/identity",
            headers={"AccessKey": "very-sensitive-example-value"},
        ).json()
        assert "accesskey" in identity["found_headers"]
        assert identity["found_headers"]["accesskey"]["display"] != "very-sensitive-example-value"

        start = client.post("/probe/long-lived/start").json()
        assert start["created"] is True
        time.sleep(0.1)
        status = client.get("/probe/long-lived/status").json()
        assert status["alive"] is True
        stop = client.post("/probe/long-lived/stop").json()
        assert stop["stopped"] is True

        aggregate = client.get("/probe/aggregate")
        assert aggregate.status_code == 200
        payload = aggregate.json()
        assert payload["checks"]["child_process"]["passed"] is True
        assert payload["checks"]["secondary_port"]["passed"] is True


def test_model_smoke_is_disabled_by_default(tmp_path: Path) -> None:
    configure_temp_paths(tmp_path)
    with TestClient(main.app) as client:
        response = client.post("/probe/opencode/model-smoke")
        assert response.status_code == 403


def test_models_discovery_is_disabled_by_default(tmp_path: Path) -> None:
    configure_temp_paths(tmp_path)
    with TestClient(main.app) as client:
        response = client.get("/probe/opencode/models")
        assert response.status_code == 403
