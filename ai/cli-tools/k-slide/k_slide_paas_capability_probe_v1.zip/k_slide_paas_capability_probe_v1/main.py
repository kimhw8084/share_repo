from __future__ import annotations

import asyncio
import base64
import hashlib
import importlib.metadata
import json
import logging
import os
import platform
import resource
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from fastapi import FastAPI, File, HTTPException, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse

APP_NAME = "K-Slide PaaS Capability Probe"
APP_VERSION = "1.0.0"
STARTED_AT = datetime.now(timezone.utc)
DATA_DIR = Path(os.getenv("PROBE_DATA_DIR", "/data/kslide-probe"))
PERSISTENCE_FILE = DATA_DIR / "persistence-test.json"
LOG_DIR = DATA_DIR / "logs"
RESULTS_DIR = DATA_DIR / "results"

IDENTITY_HEADER_CANDIDATES = tuple(
    value.strip().lower()
    for value in os.getenv(
        "PROBE_IDENTITY_HEADERS",
        "AccessKey,X-Access-Key,X-Auth-Request-User,X-Forwarded-User,Remote-User,X-User,X-Email,X-Forwarded-Email",
    ).split(",")
    if value.strip()
)

SHOW_IDENTITY_VALUES = os.getenv("PROBE_SHOW_IDENTITY_VALUES", "0") == "1"
START_OPENCODE = os.getenv("PROBE_START_OPENCODE", "0") == "1"
OPENCODE_HOST = os.getenv("PROBE_OPENCODE_HOST", "127.0.0.1")
OPENCODE_PORT = int(os.getenv("PROBE_OPENCODE_PORT", "4099"))
OPENCODE_PROJECT_DIR = Path(os.getenv("PROBE_OPENCODE_PROJECT_DIR", str(Path.cwd())))
OPENCODE_PASSWORD = os.getenv("PROBE_OPENCODE_PASSWORD", "")
OPENCODE_USERNAME = os.getenv("OPENCODE_SERVER_USERNAME", "opencode")
MODEL_TIMEOUT_SECONDS = int(os.getenv("PROBE_MODEL_TIMEOUT_SECONDS", "180"))

logger = logging.getLogger("kslide_probe")
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(message)s")

_long_lived_lock = threading.RLock()
_long_lived_process: subprocess.Popen[str] | None = None
_opencode_process: subprocess.Popen[str] | None = None
_opencode_log_handle: Any | None = None


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def log_event(event: str, **fields: Any) -> None:
    payload = {"timestamp": utc_now(), "event": event, **fields}
    logger.info(json.dumps(payload, ensure_ascii=False, default=str))


def command_result(command: list[str], timeout: int = 30, cwd: Path | None = None) -> dict[str, Any]:
    executable = shutil.which(command[0])
    if executable is None:
        return {
            "available": False,
            "command": command,
            "returncode": None,
            "stdout": "",
            "stderr": f"{command[0]} was not found on PATH",
            "timed_out": False,
        }

    try:
        result = subprocess.run(
            command,
            cwd=str(cwd) if cwd else None,
            text=True,
            capture_output=True,
            timeout=timeout,
            env=os.environ.copy(),
            check=False,
        )
        return {
            "available": True,
            "command": command,
            "returncode": result.returncode,
            "stdout": result.stdout[-8000:],
            "stderr": result.stderr[-8000:],
            "timed_out": False,
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "available": True,
            "command": command,
            "returncode": None,
            "stdout": (exc.stdout or "")[-8000:] if isinstance(exc.stdout, str) else "",
            "stderr": (exc.stderr or "")[-8000:] if isinstance(exc.stderr, str) else "",
            "timed_out": True,
        }
    except Exception as exc:  # pragma: no cover - defensive runtime reporting
        return {
            "available": True,
            "command": command,
            "returncode": None,
            "stdout": "",
            "stderr": f"{type(exc).__name__}: {exc}",
            "timed_out": False,
        }


def safe_package_version(package_name: str) -> str | None:
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        return None


def read_first_existing(paths: Iterable[Path]) -> str | None:
    for path in paths:
        try:
            if path.exists():
                return path.read_text(encoding="utf-8", errors="replace").strip()
        except OSError:
            continue
    return None


def masked_identity(value: str) -> dict[str, Any]:
    digest = hashlib.sha256(value.encode("utf-8", errors="replace")).hexdigest()[:16]
    if SHOW_IDENTITY_VALUES:
        display = value
    elif len(value) <= 4:
        display = "*" * len(value)
    else:
        display = f"{value[:2]}{'*' * min(8, len(value) - 4)}{value[-2:]}"
    return {"display": display, "length": len(value), "sha256_prefix": digest}


def runtime_probe() -> dict[str, Any]:
    cpu_quota = read_first_existing(
        [Path("/sys/fs/cgroup/cpu.max"), Path("/sys/fs/cgroup/cpu/cpu.cfs_quota_us")]
    )
    memory_limit = read_first_existing(
        [Path("/sys/fs/cgroup/memory.max"), Path("/sys/fs/cgroup/memory/memory.limit_in_bytes")]
    )
    return {
        "app": {"name": APP_NAME, "version": APP_VERSION, "started_at": STARTED_AT.isoformat()},
        "python": {
            "version": sys.version,
            "executable": sys.executable,
            "implementation": platform.python_implementation(),
        },
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
            "hostname": socket.gethostname(),
        },
        "resources": {
            "os_cpu_count": os.cpu_count(),
            "cgroup_cpu": cpu_quota,
            "cgroup_memory": memory_limit,
            "address_space_limit": list(resource.getrlimit(resource.RLIMIT_AS)),
            "process_limit": list(resource.getrlimit(resource.RLIMIT_NPROC)),
            "open_files_limit": list(resource.getrlimit(resource.RLIMIT_NOFILE)),
        },
        "paths": {
            "cwd": str(Path.cwd()),
            "home": str(Path.home()),
            "data_dir": str(DATA_DIR),
            "temp_dir": tempfile.gettempdir(),
            "path_entries": os.environ.get("PATH", "").split(os.pathsep),
        },
        "safe_environment": {
            "PORT": os.environ.get("PORT"),
            "HOST": os.environ.get("HOST"),
            "HTTP_PROXY_configured": bool(os.environ.get("HTTP_PROXY") or os.environ.get("http_proxy")),
            "HTTPS_PROXY_configured": bool(os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")),
            "NO_PROXY": os.environ.get("NO_PROXY") or os.environ.get("no_proxy"),
            "DATABASE_URL_configured": bool(find_database_url()),
            "PROBE_START_OPENCODE": START_OPENCODE,
        },
        "python_packages": {
            "fastapi": safe_package_version("fastapi"),
            "uvicorn": safe_package_version("uvicorn"),
            "sqlalchemy": safe_package_version("sqlalchemy"),
            "psycopg": safe_package_version("psycopg"),
        },
    }


def executable_probe() -> dict[str, Any]:
    output: dict[str, Any] = {}
    for name in ("node", "npm", "opencode", "git", "curl"):
        path = shutil.which(name)
        version = command_result([name, "--version"], timeout=30) if path else None
        output[name] = {"path": path, "version": version}
    return output


def child_process_probe() -> dict[str, Any]:
    result = command_result(["sh", "-c", "printf child-process-ok"], timeout=10)
    passed = result["returncode"] == 0 and result["stdout"] == "child-process-ok"
    return {"passed": passed, **result}


def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def secondary_port_probe() -> dict[str, Any]:
    port = find_free_port()
    process = subprocess.Popen(
        [sys.executable, "-m", "http.server", str(port), "--bind", "127.0.0.1"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        text=True,
    )
    try:
        last_error: str | None = None
        for _ in range(20):
            if process.poll() is not None:
                return {
                    "passed": False,
                    "port": port,
                    "error": f"child server exited with {process.returncode}",
                }
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}", timeout=2) as response:
                    return {
                        "passed": response.status == 200,
                        "port": port,
                        "status": response.status,
                    }
            except Exception as exc:  # server can need a moment to bind
                last_error = f"{type(exc).__name__}: {exc}"
                time.sleep(0.1)
        return {"passed": False, "port": port, "error": last_error or "connection failed"}
    finally:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)


def persistence_write_probe() -> dict[str, Any]:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    payload = {
        "probe_id": str(uuid.uuid4()),
        "written_at": utc_now(),
        "hostname": socket.gethostname(),
        "app_started_at": STARTED_AT.isoformat(),
    }
    PERSISTENCE_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return {
        "passed": PERSISTENCE_FILE.exists(),
        "path": str(PERSISTENCE_FILE),
        "payload": payload,
        "next_step": "Restart or republish the app, then call /probe/persistence/read.",
    }


def persistence_read_probe() -> dict[str, Any]:
    if not PERSISTENCE_FILE.exists():
        return {"passed": False, "exists": False, "path": str(PERSISTENCE_FILE), "payload": None}
    try:
        payload = json.loads(PERSISTENCE_FILE.read_text(encoding="utf-8"))
    except Exception as exc:
        return {
            "passed": False,
            "exists": True,
            "path": str(PERSISTENCE_FILE),
            "error": f"{type(exc).__name__}: {exc}",
        }
    return {
        "passed": True,
        "exists": True,
        "path": str(PERSISTENCE_FILE),
        "payload": payload,
        "current_hostname": socket.gethostname(),
        "current_app_started_at": STARTED_AT.isoformat(),
    }


def find_database_url() -> str | None:
    for key in ("DATABASE_URL", "KSLIDE_DATABASE_URL", "POSTGRES_URL", "POSTGRESQL_URL"):
        if os.environ.get(key):
            return os.environ[key]
    return None


def database_probe() -> dict[str, Any]:
    database_url = find_database_url()
    if not database_url:
        return {
            "configured": False,
            "passed": False,
            "meaning": "No supported database URL environment variable was found.",
        }
    try:
        from sqlalchemy import create_engine, text

        engine = create_engine(database_url, pool_pre_ping=True)
        with engine.connect() as connection:
            value = connection.execute(text("SELECT 1")).scalar_one()
        engine.dispose()
        return {
            "configured": True,
            "passed": value == 1,
            "driver": database_url.split(":", 1)[0],
            "result": value,
        }
    except Exception as exc:
        return {
            "configured": True,
            "passed": False,
            "driver": database_url.split(":", 1)[0],
            "error": f"{type(exc).__name__}: {exc}",
        }


def basic_auth_header(username: str, password: str) -> str:
    token = base64.b64encode(f"{username}:{password}".encode("utf-8")).decode("ascii")
    return f"Basic {token}"


def opencode_health_request(timeout: int = 3) -> dict[str, Any]:
    url = f"http://{OPENCODE_HOST}:{OPENCODE_PORT}/global/health"
    headers: dict[str, str] = {}
    if OPENCODE_PASSWORD:
        headers["Authorization"] = basic_auth_header(OPENCODE_USERNAME, OPENCODE_PASSWORD)
    request = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = response.read().decode("utf-8", errors="replace")
            try:
                parsed: Any = json.loads(body)
            except json.JSONDecodeError:
                parsed = body
            return {"reachable": True, "status": response.status, "body": parsed, "url": url}
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        return {"reachable": False, "status": exc.code, "error": body, "url": url}
    except Exception as exc:
        return {"reachable": False, "status": None, "error": f"{type(exc).__name__}: {exc}", "url": url}


def opencode_probe() -> dict[str, Any]:
    path = shutil.which("opencode")
    version = command_result(["opencode", "--version"], timeout=30) if path else None
    server_status = {
        "configured_to_start": START_OPENCODE,
        "process_alive": _opencode_process is not None and _opencode_process.poll() is None,
        "pid": _opencode_process.pid if _opencode_process is not None else None,
        "host": OPENCODE_HOST,
        "port": OPENCODE_PORT,
        "project_dir": str(OPENCODE_PROJECT_DIR),
        "password_configured": bool(OPENCODE_PASSWORD),
        "health": opencode_health_request() if START_OPENCODE else None,
    }
    return {"path": path, "version": version, "server": server_status}


def start_opencode_child() -> None:
    global _opencode_process, _opencode_log_handle
    if not START_OPENCODE:
        return
    if not OPENCODE_PASSWORD:
        raise RuntimeError("PROBE_START_OPENCODE=1 requires PROBE_OPENCODE_PASSWORD")
    if shutil.which("opencode") is None:
        raise RuntimeError("PROBE_START_OPENCODE=1 but opencode was not found on PATH")
    if not OPENCODE_PROJECT_DIR.exists():
        raise RuntimeError(f"OpenCode project directory does not exist: {OPENCODE_PROJECT_DIR}")

    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_path = LOG_DIR / "opencode-server.log"
    _opencode_log_handle = log_path.open("a", encoding="utf-8")
    env = os.environ.copy()
    env["OPENCODE_SERVER_PASSWORD"] = OPENCODE_PASSWORD
    _opencode_process = subprocess.Popen(
        [
            "opencode",
            "serve",
            "--hostname",
            OPENCODE_HOST,
            "--port",
            str(OPENCODE_PORT),
        ],
        cwd=str(OPENCODE_PROJECT_DIR),
        env=env,
        stdout=_opencode_log_handle,
        stderr=subprocess.STDOUT,
        text=True,
    )
    log_event("opencode_child_started", pid=_opencode_process.pid, port=OPENCODE_PORT)


def stop_process(process: subprocess.Popen[str] | None, name: str) -> None:
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)
    log_event("child_stopped", child=name, returncode=process.returncode)


def aggregate_probe() -> dict[str, Any]:
    checks = {
        "runtime": runtime_probe(),
        "executables": executable_probe(),
        "child_process": child_process_probe(),
        "secondary_port": secondary_port_probe(),
        "persistence_read": persistence_read_probe(),
        "database": database_probe(),
        "opencode": opencode_probe(),
        "long_lived_child": long_lived_status_probe(),
    }
    required_passes = {
        "child_process": checks["child_process"].get("passed") is True,
        "secondary_port": checks["secondary_port"].get("passed") is True,
        "node_found": bool(checks["executables"]["node"]["path"]),
        "npm_found": bool(checks["executables"]["npm"]["path"]),
        "opencode_found": bool(checks["executables"]["opencode"]["path"]),
    }
    return {
        "generated_at": utc_now(),
        "required_passes": required_passes,
        "all_core_runtime_checks_pass": all(required_passes.values()),
        "checks": checks,
        "manual_tests_still_required": [
            "Streaming through ingress: curl -N <BASE_URL>/probe/stream",
            "Identity header inspection: open <BASE_URL>/probe/identity",
            "Persistence after restart/republish: write, restart, then read",
            "OpenCode Web image paste and multi-image behavior",
            "Real model smoke test, only with approval",
            "Replica count and platform resource limits",
        ],
    }


def long_lived_status_probe() -> dict[str, Any]:
    with _long_lived_lock:
        process = _long_lived_process
        return {
            "started": process is not None,
            "alive": process is not None and process.poll() is None,
            "pid": process.pid if process else None,
            "returncode": process.poll() if process else None,
        }


@asynccontextmanager
async def lifespan(_: FastAPI):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    log_event("application_start", version=APP_VERSION, data_dir=str(DATA_DIR))
    if START_OPENCODE:
        try:
            start_opencode_child()
        except Exception as exc:
            log_event("opencode_child_start_failed", error=f"{type(exc).__name__}: {exc}")
    yield
    stop_process(_long_lived_process, "long_lived_test")
    stop_process(_opencode_process, "opencode")
    if _opencode_log_handle is not None:
        _opencode_log_handle.close()
    log_event("application_stop")


app = FastAPI(title=APP_NAME, version=APP_VERSION, lifespan=lifespan)


@app.get("/", response_class=HTMLResponse)
def home() -> str:
    return """
    <main style="max-width:1100px;margin:0 auto;padding:40px 24px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#161617">
      <style>
        body{margin:0;background:#f5f5f7} .panel{background:white;border:1px solid #e5e5e7;border-radius:20px;padding:24px;margin:18px 0}
        h1{font-size:38px;letter-spacing:-1.2px;margin:0 0 10px} h2{font-size:22px;margin-top:0} p,li{line-height:1.55}
        a{color:#06c;text-decoration:none} code{background:#f1f1f3;padding:2px 6px;border-radius:6px}
        button{border:0;border-radius:999px;background:#161617;color:#fff;padding:12px 18px;font-weight:600;cursor:pointer}
        pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#111;color:#e8e8e8;padding:18px;border-radius:14px;min-height:120px}
        .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px}.chip{display:inline-block;padding:5px 10px;border-radius:999px;background:#e8f1ff;color:#064b9b;font-size:13px}
      </style>
      <span class="chip">PaaS environment diagnostic</span>
      <h1>K-Slide Capability Probe</h1>
      <p>This temporary app determines whether the published FastAPI runtime can host the complete K-Slide platform and an internal OpenCode server.</p>
      <section class="panel">
        <h2>Start here</h2>
        <div class="grid">
          <div><strong>1. Run core checks</strong><p>Checks executables, child processes, localhost ports, storage, database and OpenCode.</p></div>
          <div><strong>2. Test streaming</strong><p>Use <code>curl -N &lt;DNS&gt;/probe/stream</code>. Lines should arrive every two seconds.</p></div>
          <div><strong>3. Test persistence</strong><p>Write the marker, restart/republish, then read it again.</p></div>
          <div><strong>4. Inspect identity</strong><p>Identity headers are masked by default and secrets are never returned.</p></div>
        </div>
        <button id="run">Run core checks</button>
      </section>
      <section class="panel">
        <h2>Useful endpoints</h2>
        <ul>
          <li><a href="/health/live">/health/live</a></li>
          <li><a href="/health/ready">/health/ready</a></li>
          <li><a href="/probe/aggregate">/probe/aggregate</a></li>
          <li><a href="/probe/runtime">/probe/runtime</a></li>
          <li><a href="/probe/identity">/probe/identity</a></li>
          <li><a href="/probe/persistence/write">/probe/persistence/write</a></li>
          <li><a href="/probe/persistence/read">/probe/persistence/read</a></li>
          <li><a href="/probe/opencode">/probe/opencode</a></li>
          <li><a href="/docs">/docs</a></li>
        </ul>
      </section>
      <pre id="output">Press “Run core checks”.</pre>
      <script>
        document.getElementById('run').addEventListener('click', async () => {
          const output = document.getElementById('output');
          output.textContent = 'Running…';
          try {
            const response = await fetch('/probe/aggregate');
            output.textContent = JSON.stringify(await response.json(), null, 2);
          } catch (error) {
            output.textContent = String(error);
          }
        });
      </script>
    </main>
    """


@app.get("/health/live")
def health_live() -> dict[str, Any]:
    return {"status": "ok", "app": APP_NAME, "version": APP_VERSION, "time": utc_now()}


@app.get("/health/ready")
def health_ready() -> JSONResponse:
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        test_file = DATA_DIR / ".write-test"
        test_file.write_text("ok", encoding="utf-8")
        test_file.unlink(missing_ok=True)
        status_code = 200
        body = {"status": "ready", "data_dir_writable": True, "time": utc_now()}
    except Exception as exc:
        status_code = 503
        body = {
            "status": "not_ready",
            "data_dir_writable": False,
            "error": f"{type(exc).__name__}: {exc}",
            "time": utc_now(),
        }
    return JSONResponse(body, status_code=status_code)


@app.get("/probe/runtime")
def probe_runtime() -> dict[str, Any]:
    return runtime_probe()


@app.get("/probe/executables")
def probe_executables() -> dict[str, Any]:
    return executable_probe()


@app.get("/probe/child-process")
def probe_child_process() -> dict[str, Any]:
    return child_process_probe()


@app.get("/probe/secondary-port")
def probe_secondary_port() -> dict[str, Any]:
    return secondary_port_probe()


@app.post("/probe/long-lived/start")
def probe_long_lived_start() -> dict[str, Any]:
    global _long_lived_process
    with _long_lived_lock:
        if _long_lived_process is not None and _long_lived_process.poll() is None:
            return {"created": False, "reason": "already_running", "status": long_lived_status_probe()}
        _long_lived_process = subprocess.Popen(
            [sys.executable, "-c", "import time; time.sleep(86400)"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
        )
        return {"created": True, "status": long_lived_status_probe()}


@app.get("/probe/long-lived/status")
def probe_long_lived_status() -> dict[str, Any]:
    return long_lived_status_probe()


@app.post("/probe/long-lived/stop")
def probe_long_lived_stop() -> dict[str, Any]:
    global _long_lived_process
    with _long_lived_lock:
        process = _long_lived_process
        if process is None:
            return {"stopped": False, "reason": "not_started"}
        stop_process(process, "long_lived_test")
        _long_lived_process = None
        return {"stopped": True}


@app.get("/probe/stream")
async def probe_stream() -> StreamingResponse:
    async def generate():
        for number in range(5):
            yield json.dumps({"step": number, "time": utc_now()}) + "\n"
            await asyncio.sleep(2)

    return StreamingResponse(
        generate(),
        media_type="application/x-ndjson",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/probe/sse")
async def probe_sse() -> StreamingResponse:
    async def generate():
        for number in range(5):
            payload = json.dumps({"step": number, "time": utc_now()})
            yield f"event: probe\ndata: {payload}\n\n"
            await asyncio.sleep(2)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.websocket("/probe/ws")
async def probe_websocket(websocket: WebSocket) -> None:
    await websocket.accept()
    try:
        while True:
            message = await websocket.receive_text()
            await websocket.send_json({"echo": message, "time": utc_now()})
    except WebSocketDisconnect:
        return


@app.post("/probe/upload")
async def probe_upload(file: UploadFile = File(...)) -> dict[str, Any]:
    limit_bytes = int(os.getenv("PROBE_UPLOAD_LIMIT_MB", "60")) * 1024 * 1024
    digest = hashlib.sha256()
    size = 0
    while True:
        chunk = await file.read(1024 * 1024)
        if not chunk:
            break
        size += len(chunk)
        if size > limit_bytes:
            raise HTTPException(status_code=413, detail=f"Upload exceeded {limit_bytes} bytes")
        digest.update(chunk)
    return {
        "passed": True,
        "filename": Path(file.filename or "upload").name,
        "content_type": file.content_type,
        "bytes": size,
        "sha256": digest.hexdigest(),
        "stored": False,
    }


@app.get("/probe/delay/{seconds}")
async def probe_delay(seconds: int) -> dict[str, Any]:
    maximum = int(os.getenv("PROBE_MAX_DELAY_SECONDS", "120"))
    if seconds < 0 or seconds > maximum:
        raise HTTPException(status_code=400, detail=f"seconds must be between 0 and {maximum}")
    started = utc_now()
    await asyncio.sleep(seconds)
    return {"passed": True, "requested_seconds": seconds, "started_at": started, "finished_at": utc_now()}


@app.get("/probe/identity")
def probe_identity(request: Request) -> dict[str, Any]:
    found: dict[str, Any] = {}
    for key, value in request.headers.items():
        if key.lower() in IDENTITY_HEADER_CANDIDATES:
            found[key] = masked_identity(value)
    return {
        "found_headers": found,
        "candidate_headers": IDENTITY_HEADER_CANDIDATES,
        "values_are_masked": not SHOW_IDENTITY_VALUES,
        "security_note": "Do not persist raw AccessKey/token values. Confirm whether the header is identity or credential material.",
    }


@app.get("/probe/persistence/write")
def probe_persistence_write() -> dict[str, Any]:
    return persistence_write_probe()


@app.get("/probe/persistence/read")
def probe_persistence_read() -> dict[str, Any]:
    return persistence_read_probe()


@app.get("/probe/database")
def probe_database() -> dict[str, Any]:
    return database_probe()


@app.get("/probe/opencode")
def probe_opencode() -> dict[str, Any]:
    return opencode_probe()


@app.get("/probe/opencode/models")
def probe_opencode_models() -> dict[str, Any]:
    if os.getenv("PROBE_ALLOW_MODEL_DISCOVERY", "0") != "1":
        raise HTTPException(
            status_code=403,
            detail="Set PROBE_ALLOW_MODEL_DISCOVERY=1 to allow the read-only 'opencode models' check.",
        )
    return command_result(["opencode", "models"], timeout=60, cwd=OPENCODE_PROJECT_DIR)


@app.post("/probe/opencode/model-smoke")
def probe_opencode_model_smoke() -> dict[str, Any]:
    if os.getenv("PROBE_ALLOW_MODEL_SMOKE", "0") != "1":
        raise HTTPException(
            status_code=403,
            detail="Set PROBE_ALLOW_MODEL_SMOKE=1 only after model usage is approved.",
        )
    if shutil.which("opencode") is None:
        raise HTTPException(status_code=503, detail="opencode was not found on PATH")
    with tempfile.TemporaryDirectory(prefix="kslide-opencode-smoke-") as temporary_directory:
        path = Path(temporary_directory)
        (path / "AGENTS.md").write_text(
            "# Smoke test\nReply exactly as requested. Do not use tools.\n",
            encoding="utf-8",
        )
        result = command_result(
            ["opencode", "run", "--auto", "Reply only with MODEL_OK"],
            timeout=MODEL_TIMEOUT_SECONDS,
            cwd=path,
        )
        result["passed"] = result["returncode"] == 0 and "MODEL_OK" in result["stdout"]
        return result


@app.get("/probe/aggregate")
def probe_aggregate() -> dict[str, Any]:
    report = aggregate_probe()
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    report_path = RESULTS_DIR / "latest-aggregate.json"
    report_path.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    return report


@app.get("/probe/aggregate/download")
def probe_aggregate_download() -> JSONResponse:
    return JSONResponse(aggregate_probe(), headers={"Content-Disposition": "attachment; filename=kslide-probe-results.json"})
