# Package Manifest

## Application

- `main.py` — FastAPI probe and diagnostic endpoints.
- `requirements.txt` — production probe dependencies.
- `requirements-dev.txt` — local test dependencies.
- `start.sh` — generic PaaS start command.
- `Procfile` — alternative PaaS process declaration.
- `.env.example` — safe configuration template.

## Automated scripts

- `scripts/run_local.sh` — create a virtual environment and run the probe locally.
- `scripts/run_full_local_probe.sh` — local runtime, package and pytest checks.
- `scripts/local_runtime_checks.sh` — Node/npm/OpenCode/Python/resource/network checks.
- `scripts/published_smoke.sh` — comprehensive company-DNS test and report collection.
- `scripts/persistence_recheck.sh` — verify persistence after restart/republish.
- `scripts/sse_probe.sh` — progressive SSE test.
- `scripts/upload_limit_probe.sh` — configurable ingress upload-limit test.
- `scripts/timeout_probe.sh` — configurable request-timeout test.
- `scripts/websocket_probe.py` — WebSocket upgrade and echo test.
- `scripts/replica_observation.py` — observe distinct serving hostnames.
- `scripts/opencode_server_test.sh` — local OpenCode server health/doc test.
- `scripts/opencode_api_surface_probe.py` — session/command/agent API checks.
- `scripts/opencode_web_manual.sh` — OpenCode Web image-paste checklist launcher.
- `scripts/model_smoke.sh` — opt-in real model request.
- `scripts/kslide_project_test.sh` — K-Slide command/agent/skill static checks and optional real run.
- `scripts/summarize_results.py` — published test summary generator.
- `scripts/validate_package.py` — package structure and syntax validation.

## Documentation

- `README.md` — immediate work-repo and publication instructions.
- `TEST_MATRIX.md` — pass/fail meaning and architecture consequences.
- `EXPECTED_RESULTS.md` — healthy and failing result examples.
- `DECISION_TREE.md` — final architecture selection logic.
- `RESULTS_TEMPLATE.md` — fill-in report to return after testing.
- `PLATFORM_TEAM_QUESTIONS.md` — unresolved PaaS questions.
- `SECURITY.md` — temporary-probe security controls.
- `OPEN_CODE_MANUAL_TESTS.md` — image, API and skill manual checks.
- `INTERNAL_TEST_REPORT.md` — checks completed before packaging.

## Tests

- `tests/test_app.py` — FastAPI behavior and safety-default regression tests.
- `pytest.ini` — restricts collection to the `tests` directory.
