# K-Slide PaaS Probe Results

## Deployment

- Project name:
- Company DNS:
- Publish type: fastapi
- Publish date/time:
- Repository commit:
- PaaS runtime/language version shown:
- Build command, if visible:
- Start command, if visible:

## Application startup

- Root page loads: yes / no
- `/health/live`: pass / fail
- `/health/ready`: pass / fail
- Build log summary:
- Runtime log summary:

## Runtime executables

- Python version:
- Node path/version:
- npm path/version:
- OpenCode path/version:
- npm registry access: pass / fail

## Process capabilities

- Python child process: pass / fail
- Secondary localhost port: pass / fail
- Long-lived child immediately: alive / dead
- Long-lived child after 5 minutes: alive / dead
- Long-lived child after 15 minutes: alive / dead

## Network/proxy

- Injected `PORT`:
- NDJSON streaming progressive: yes / buffered / failed
- SSE progressive: yes / buffered / failed
- WebSocket: pass / fail / not tested
- 45-second request: pass / fail
- 90-second request: pass / fail
- Maximum successful upload size:

## Identity

- Identity header names found:
- Does AccessKey contain username, employee ID, token or opaque secret?:
- Safe stable user ID available: yes / no
- Admin group/role header available: yes / no / unknown

Do not paste raw credential or token values here.

## Persistence

- Configured data path:
- Initial write/read: pass / fail
- After app restart: persists / lost
- After republish: persists / lost
- After pod replacement: persists / lost / unknown

## PostgreSQL

- Database URL variable name:
- Connection test: pass / fail
- Driver:
- TLS or connection notes:

## OpenCode server

- Internal startup enabled: yes / no
- Process alive: yes / no
- `/global/health`: pass / fail
- `/doc`: pass / fail
- `/session`: pass / fail
- `/command`: pass / fail
- `/agent`: pass / fail
- Server log summary:

## OpenCode Web manual test

- Page loads:
- Create session:
- Paste PNG from clipboard:
- Paste JPEG from clipboard:
- Attach multiple images:
- `/k-slide` visible:
- Correct K-Slide agent selected:
- Streaming visible:
- Browser/version:

## Corporate model

- `opencode models` succeeds: yes / no / not tested
- Model smoke returns `MODEL_OK`: yes / no / not tested
- Model/provider name shown:
- Gateway records user or app identity:
- Quota bucket observed:

## Platform policy

- Replica count:
- Autoscaling enabled:
- CPU limit:
- Memory limit:
- Ephemeral storage:
- Request timeout:
- Idle timeout:
- Termination grace period:

## Architecture outcome

Select one:

- [ ] Preferred: FastAPI + internal OpenCode server API
- [ ] Fallback: FastAPI + `opencode run` jobs
- [ ] Blocked: published runtime cannot host OpenCode

## Blockers and follow-ups

1.
2.
3.
