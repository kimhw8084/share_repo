# Security Notes

## This probe is temporary

Publish it only long enough to collect environment results. Remove or disable it afterward.

## Identity

The `/probe/identity` endpoint only inspects an allowlist of likely identity headers. Values are masked unless `PROBE_SHOW_IDENTITY_VALUES=1`.

Do not enable raw identity display until the platform team confirms that the value is a non-secret user identifier. If AccessKey is a bearer token or opaque credential, never log or store it.

## Environment variables

The application does not expose the full environment. It only reports whether a database URL or proxy is configured and shows safe variables such as `PORT`.

## Database credentials

`/probe/database` reports only the URL scheme/driver and `SELECT 1` result. It does not return host, username, password or complete URL.

## OpenCode server

When `PROBE_START_OPENCODE=1`:

- `PROBE_OPENCODE_PASSWORD` is mandatory;
- the server binds to `127.0.0.1` by default;
- the password is not returned by diagnostics;
- the server log is written under the probe data directory;
- the server should not be exposed directly through company ingress.

Use a random temporary password and remove it after testing.

## Model usage

Real model requests are disabled by default. They require:

```text
PROBE_ALLOW_MODEL_SMOKE=1
```

or, for the local script:

```text
I_UNDERSTAND_MODEL_USAGE=1
```

Use only non-confidential test prompts/images.

## Upload test

`/probe/upload` reads the body, calculates size and SHA-256, and discards the content. It does not write the upload to disk.

## Delay/child tests

The probe exposes controlled delay and harmless child-process endpoints. They are useful for runtime testing but should not remain available as a permanent production service.

## Recommended publication boundary

Use company-authenticated DNS only. Do not make the probe public.
