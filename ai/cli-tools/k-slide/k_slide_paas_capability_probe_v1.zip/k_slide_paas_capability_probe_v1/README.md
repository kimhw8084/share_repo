# K-Slide PaaS Capability Probe

A temporary, security-conscious FastAPI project for determining whether your company PaaS can host the final K-Slide platform and an internal OpenCode server.

This is **not the final K-Slide product**. It is a deployment probe that answers the runtime questions that currently block a reliable one-package implementation.

## What this tests

The package tests whether the published FastAPI runtime can:

- see Node, npm and OpenCode;
- launch ordinary child processes;
- keep a child process alive;
- bind and reach a second localhost port;
- launch an internal `opencode serve` process;
- reach the OpenCode health/API endpoints;
- stream through the company ingress;
- support server-sent events and WebSockets;
- receive employee identity headers;
- persist files after restart or republish;
- connect to PostgreSQL;
- accept large multipart uploads;
- survive longer HTTP requests;
- expose enough CPU, memory and process capacity;
- inherit the corporate OpenCode/Gemma setup.

## Safety defaults

The probe is deliberately conservative:

- Identity header values are masked by default.
- It never returns the complete environment.
- It never returns database credentials.
- It does not store uploaded test files.
- It does not start OpenCode unless explicitly enabled.
- It does not make a model request unless explicitly enabled.
- It binds the internal OpenCode server to `127.0.0.1`.
- It requires an OpenCode server password when internal startup is enabled.

Do not publish this probe permanently. Remove it after the environment report is collected.

---

# Fastest test sequence

## Step 1 — Copy into a new work repository

Copy the entire extracted folder to an empty repository. The root must contain:

```text
main.py
requirements.txt
start.sh
Procfile
```

Commit it if your publish process requires a Git repository.

## Step 2 — Publish as `fastapi`

Use the company publish command and choose:

```text
fastapi
```

For the first publish, do **not** enable OpenCode startup or model usage.

Suggested first-publish variables:

```text
PROBE_DATA_DIR=/data/kslide-probe
PROBE_START_OPENCODE=0
PROBE_SHOW_IDENTITY_VALUES=0
PROBE_ALLOW_MODEL_DISCOVERY=0
PROBE_ALLOW_MODEL_SMOKE=0
```

`PROBE_DATA_DIR` can be changed to the mount path your PaaS provides. If no mount is configured, the app should still start, but persistence may fail after a restart.

## Step 3 — Open the company DNS

Expected page:

```text
https://<project-company-dns>/
```

You should immediately see **K-Slide Capability Probe**. The page itself must not wait for OpenCode or Gemma.

If the root URL loads forever, first try:

```text
https://<project-company-dns>/health/live
```

Expected:

```json
{
  "status": "ok",
  "app": "K-Slide PaaS Capability Probe",
  "version": "1.0.0"
}
```

If `/health/live` fails, the FastAPI app is not starting or the PaaS is not routing to it. Inspect platform build/start logs before doing any OpenCode tests.

## Step 4 — Run published smoke tests

From a terminal with access to the company DNS:

```bash
./scripts/published_smoke.sh https://<project-company-dns>
```

This creates a timestamped folder under:

```text
results/published-YYYYMMDD-HHMMSS/
```

It tests:

- liveness/readiness;
- runtime details;
- executables;
- child processes;
- second localhost port;
- identity headers;
- initial persistence write/read;
- database connectivity;
- OpenCode visibility;
- long-lived child startup;
- streamed output.

## Step 5 — Test persistence after a restart

First confirm `/probe/persistence/write` was called by the smoke script.

Then restart, republish, or replace the application pod. After it returns:

```bash
./scripts/persistence_recheck.sh https://<project-company-dns>
```

Pass:

```json
"exists": true
```

The `probe_id` should be the same as before the restart.

Failure:

```json
"exists": false
```

Meaning: the selected data folder is ephemeral, the persistent mount was not configured, or the mount path changed.

## Step 6 — Recheck the long-lived child

Immediately after the smoke test:

```text
GET /probe/long-lived/status
```

Check again after 5 and 15 minutes.

Expected:

```json
{
  "started": true,
  "alive": true
}
```

If it changes to `alive: false`, the PaaS is killing child processes or the process is being isolated between requests.

## Step 7 — Enable internal OpenCode server test

Only after the base FastAPI tests pass, set:

```text
PROBE_START_OPENCODE=1
PROBE_OPENCODE_PASSWORD=<random-long-test-password>
PROBE_OPENCODE_HOST=127.0.0.1
PROBE_OPENCODE_PORT=4099
PROBE_OPENCODE_PROJECT_DIR=<repo-root-or-k-slide-project-path>
```

Republish or restart, then open:

```text
/probe/opencode
```

Expected:

```text
path: non-null
server.process_alive: true
server.health.reachable: true
server.health.status: 200
```

If `path` is null, the published FastAPI runtime does not have OpenCode on `PATH`.

If the process is alive but health is unreachable, inspect `/data/kslide-probe/logs/opencode-server.log` if the data folder is mounted and accessible through your workspace, plus the platform application logs.

## Step 8 — Test OpenCode locally in your interactive work environment

Run:

```bash
./scripts/local_runtime_checks.sh
./scripts/opencode_server_test.sh
```

Manual OpenCode Web test:

```bash
PROBE_OPENCODE_PROJECT_DIR=/path/to/k-slide-project \
./scripts/opencode_web_manual.sh
```

Use the browser checklist printed by the script to test:

- page loading;
- image clipboard paste;
- multiple image attachments;
- `/k-slide` visibility;
- streaming;
- configured model access.

## Step 9 — Test the OpenCode server API surface

Start the test server in terminal 1:

```bash
PROBE_OPENCODE_PASSWORD=temporary-test-password \
./scripts/opencode_server_test.sh
```

That script exits after its own health check. For a persistent manual server, use:

```bash
PROBE_OPENCODE_PASSWORD=temporary-test-password \
OPENCODE_SERVER_PASSWORD=temporary-test-password \
opencode serve --hostname 127.0.0.1 --port 4097
```

Then in terminal 2:

```bash
PROBE_OPENCODE_PASSWORD=temporary-test-password \
OPENCODE_URL=http://127.0.0.1:4097 \
python scripts/opencode_api_surface_probe.py
```

Required API checks:

```text
/global/health
/doc
/project/current
/session
/command
/agent
```

## Step 10 — Test real model access only after approval

This makes an actual model request and may consume corporate quota:

```bash
I_UNDERSTAND_MODEL_USAGE=1 ./scripts/model_smoke.sh
```

Expected output includes:

```text
MODEL_OK
```

The published endpoint equivalent is disabled by default. To enable temporarily:

```text
PROBE_ALLOW_MODEL_SMOKE=1
```

Then call:

```text
POST /probe/opencode/model-smoke
```

Turn it off immediately after testing.

---

# Published endpoints

| Endpoint | Purpose | Expected result |
|---|---|---|
| `/` | Human-readable probe dashboard | Loads immediately |
| `/health/live` | Kubernetes/PaaS liveness | HTTP 200 |
| `/health/ready` | Writable data directory | HTTP 200 or explanatory 503 |
| `/probe/runtime` | Safe runtime, port, resource and path data | JSON |
| `/probe/executables` | Node/npm/OpenCode/Git/curl detection | Non-null paths where available |
| `/probe/child-process` | Python can execute a child process | `passed: true` |
| `/probe/secondary-port` | Child can bind/reach localhost port | `passed: true` |
| `/probe/long-lived/start` | Start harmless sleeping child | `created: true` |
| `/probe/long-lived/status` | Verify child remains alive | `alive: true` |
| `/probe/long-lived/stop` | Stop sleeping child | `stopped: true` |
| `/probe/stream` | Chunked NDJSON stream | New line every ~2 seconds |
| `/probe/sse` | Server-sent events | Event every ~2 seconds |
| `/probe/ws` | WebSocket echo | Use `scripts/websocket_probe.py` |
| `/probe/upload` | Multipart upload limit test | Returns size/hash; file not stored |
| `/probe/delay/{seconds}` | Ingress/request timeout test | Completes up to configured cap |
| `/probe/identity` | Trusted identity header discovery | Header names plus masked values |
| `/probe/persistence/write` | Create persistence marker | `passed: true` |
| `/probe/persistence/read` | Read persistence marker | `exists: true` after restart if persistent |
| `/probe/database` | PostgreSQL connection test | `configured: true`, `passed: true` |
| `/probe/opencode` | OpenCode binary/server status | Path/version and optional health |
| `/probe/opencode/models` | Read-only model list | Disabled unless explicitly enabled |
| `/probe/opencode/model-smoke` | Real model request | Disabled unless explicitly enabled |
| `/probe/aggregate` | Combined report | JSON plus saved report if writable |
| `/docs` | FastAPI OpenAPI interface | Loads |

---

# Upload limit test

Create a test file of a known size:

```bash
dd if=/dev/zero of=/tmp/probe-30mb.bin bs=1M count=30
curl -F "file=@/tmp/probe-30mb.bin" \
  https://<dns>/probe/upload
```

Expected for a 30 MB request when ingress/app permits it:

```json
{
  "passed": true,
  "bytes": 31457280,
  "stored": false
}
```

If the request is rejected before reaching FastAPI, the response is usually generated by the ingress. That establishes the platform upload limit.

The app-side probe limit defaults to 60 MB and can be changed with:

```text
PROBE_UPLOAD_LIMIT_MB=60
```

# Request-timeout test

```bash
time curl --fail https://<dns>/probe/delay/45
```

If 45 seconds succeeds, repeat with a larger value up to the allowed maximum:

```bash
time curl --fail https://<dns>/probe/delay/90
```

`PROBE_MAX_DELAY_SECONDS` defaults to 120.

A gateway timeout means the final K-Slide product must use background execution with polling/SSE instead of holding the upload request open.

# Streaming and SSE tests

NDJSON:

```bash
curl -N https://<dns>/probe/stream
```

SSE:

```bash
curl -N -H 'Accept: text/event-stream' https://<dns>/probe/sse
```

Pass: one item appears roughly every two seconds.

Fail: all items appear at the end. This means the ingress is buffering responses. The final app should retain polling as a fallback.

# WebSocket test

Install dev dependencies locally:

```bash
python -m pip install -r requirements-dev.txt
```

Then:

```bash
python scripts/websocket_probe.py \
  wss://<project-company-dns>/probe/ws
```

WebSockets are not required for the recommended design, but the result determines whether stock OpenCode Web can be proxied safely.

# Replica observation

```bash
python scripts/replica_observation.py \
  https://<project-company-dns>
```

Multiple hostnames prove multiple replicas are serving traffic. One observed hostname does not prove autoscaling is impossible; confirm the deployment policy with the platform team.

# K-Slide project static test

After copying the latest K-Slide project to the work computer:

```bash
KSLIDE_PROJECT_DIR=/path/to/k-slide-project \
./scripts/kslide_project_test.sh
```

To test a real image and consume model quota:

```bash
KSLIDE_PROJECT_DIR=/path/to/k-slide-project \
KSLIDE_TEST_IMAGE=/path/to/non-confidential-slide.png \
I_UNDERSTAND_MODEL_USAGE=1 \
./scripts/kslide_project_test.sh
```

# Files to return for architecture finalization

Return these with secrets and confidential values redacted:

```text
results/local-*/
results/published-*/
RESULTS_TEMPLATE.md (completed)
```

Also provide:

- screenshot of the published probe homepage;
- screenshot or copy of the PaaS build/start logs;
- result of persistence after restart;
- result after five and fifteen minutes for the long-lived child;
- manual OpenCode Web checklist;
- exact identity header names, without raw secret values;
- platform team answers from `PLATFORM_TEAM_QUESTIONS.md`.

# What happens after the probe

Use `DECISION_TREE.md` to select the final architecture.

The strongest passing configuration is:

```text
FastAPI employee UI
+ internal opencode serve child process
+ OpenCode server API/SDK
+ PostgreSQL
+ persistent artifact storage
+ polling fallback for streaming
```

If OpenCode or long-lived child processes are unavailable in published FastAPI, the package cannot honestly embed the complete engine in that PaaS runtime. The decision tree explains the fallback options and which platform capability must change.
