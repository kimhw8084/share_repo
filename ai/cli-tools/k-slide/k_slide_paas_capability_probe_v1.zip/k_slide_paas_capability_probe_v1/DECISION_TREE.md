# Architecture Decision Tree

Start after completing the probe.

## 1. Does published FastAPI run?

- **No:** fix publish entrypoint/routing. Do not proceed.
- **Yes:** continue.

## 2. Are Node, npm and OpenCode visible?

- **All yes:** continue.
- **Node/npm yes, OpenCode no:** install OpenCode during the approved build step, then retest.
- **Node/npm no, OpenCode no:** ask the platform team for an OpenCode-enabled runtime or approved binary mechanism.
- **OpenCode yes without Node/npm:** acceptable for runtime if the executable is stable and supported.

## 3. Can Python execute child processes?

- **No:** OpenCode cannot run inside the FastAPI pod. Use a separate OpenCode service or managed personal OpenCode Web.
- **Yes:** continue.

## 4. Can it bind and reach a second localhost port?

- **No:** use `opencode run` per background job. Do not design around `opencode serve`.
- **Yes:** continue.

## 5. Does a long-lived child remain alive?

- **No:** use per-job CLI or a separately managed OpenCode service.
- **Yes:** continue.

## 6. Does internal `opencode serve` become healthy?

- **No:** inspect logs and provider configuration. The server API architecture is blocked until fixed.
- **Yes:** preferred engine design is viable.

## 7. Does the OpenCode API expose session, message, command and agent endpoints?

- **No:** adapt to the installed API version or use CLI fallback.
- **Yes:** use a generated/typed server client.

## 8. Does the published runtime reach the corporate Gemma model?

- **No:** platform must inject model/provider identity/configuration. This is a hard blocker.
- **Yes:** continue.

## 9. Do identity headers reach FastAPI?

- **No:** request trusted identity forwarding or add app-level authentication.
- **Yes, but value is a credential:** never store raw value; use a separate user header or HMAC pseudonym.
- **Yes, stable user ID:** use it for ownership/audit.

## 10. Is storage persistent?

- **Yes:** use the configured mount for artifacts and PostgreSQL for metadata.
- **No:** PostgreSQL is mandatory, and object storage/PV is required for durable reports/images.

## 11. Does SSE stream progressively?

- **Yes:** use SSE plus polling fallback.
- **No:** use polling as the primary progress mechanism.

## 12. Are WebSockets supported?

- **Yes:** stock OpenCode Web proxy remains technically possible.
- **No:** use the recommended custom K-Slide web UI over HTTP/SSE/polling.

## Final recommendation by result

### Preferred

```text
Focused FastAPI K-Slide UI
→ internal authenticated opencode serve
→ OpenCode session API
→ PostgreSQL
→ persistent artifacts
→ SSE with polling fallback
```

### Compatible fallback

```text
Focused FastAPI K-Slide UI
→ PostgreSQL job queue
→ opencode run per job
→ file/DB artifacts
→ polling
```

### Environment-blocked

```text
No OpenCode/process/model access in published FastAPI
```

Requires a platform change or a separate/personal OpenCode deployment model. No code-only package can bypass a missing runtime capability.
