# Test Matrix and Failure Meaning

Use this table to interpret every result. “Final design consequence” is the action that should be taken when building the complete K-Slide package.

| ID | Test | Pass condition | Common failure | What failure means | Final design consequence |
|---|---|---|---|---|---|
| T01 | Root page | Loads immediately | Infinite loading/502 | App did not start, wrong entrypoint, wrong publish type or ingress issue | Fix FastAPI publication before OpenCode work |
| T02 | `/health/live` | HTTP 200 | 404/502/timeout | PaaS is not running `main:app` or routing is broken | Determine required entrypoint/start command |
| T03 | `/health/ready` | HTTP 200 | 503 | Configured data directory is unwritable | Use writable/mounted path and permissions |
| T04 | Node detection | Non-null path and version | Path null | Published Python image lacks Node | Install Node during build or request platform runtime change |
| T05 | npm detection | Non-null path/version | Path null | OpenCode npm installation cannot occur in this runtime | Use approved preinstalled OpenCode/binary service |
| T06 | OpenCode detection | Non-null path/version | Path null | Terminal installation is not present in published pod | Add build install step or platform-provided executable |
| T07 | Python child process | `passed: true` | Permission denied/disabled | PaaS blocks subprocess execution | Cannot embed OpenCode process; use external service/personal runtime |
| T08 | Secondary localhost port | `passed: true` | Bind/connection fails | Child server cannot bind or loopback is isolated | Use per-run CLI instead of internal server, or external OpenCode service |
| T09 | Long-lived child | `alive: true` after 15 min | Child disappears | PaaS kills children or requests run in isolated workers | Cannot rely on managed `opencode serve` child |
| T10 | OpenCode server health | `reachable: true`, HTTP 200 | Process exits or no health | Missing config, password, binary, model/provider initialization or runtime restriction | Inspect OpenCode log; server API architecture blocked until fixed |
| T11 | OpenCode `/doc` | HTTP 200 | 404 | Version mismatch or wrong process | Adapt client to installed API or update OpenCode |
| T12 | Session/command/agent API | HTTP 200 | Endpoint errors | Installed server API differs or project config failed | Generate client from actual `/doc`; fix K-Slide project loading |
| T13 | Streaming NDJSON | Item every ~2 sec | All at end | Proxy buffering | Use polling as mandatory fallback |
| T14 | SSE | Event every ~2 sec | Disconnect/buffering | SSE unsupported or buffered | Polling-first UI; streaming optional |
| T15 | WebSocket | Echo succeeds | Upgrade failure | Ingress lacks WebSocket support | Do not proxy stock OpenCode Web; custom HTTP/SSE UI |
| T16 | Identity headers | Stable trusted user header found | No header | Published app cannot identify employees | Request ingress identity header or use app auth |
| T17 | AccessKey classification | Confirmed identity, not secret | Header is token/credential | Logging it would leak credentials | Store HMAC/derived ID or use separate username header |
| T18 | Persistence initial | Write/read works | Permission/path error | Wrong mount or data path | Configure `PROBE_DATA_DIR` to writable path |
| T19 | Persistence after restart | Same probe ID remains | File missing | Ephemeral storage | PostgreSQL/object store/PV required; no local artifact guarantees |
| T20 | Database | `configured: true`, `passed: true` | No URL/connection error | DB not linked, wrong driver/TLS/network | Resolve before production metadata/governance |
| T21 | Upload 25–50 MB | FastAPI receives full size | 413/timeout before app | Ingress body-size limit | Set product upload cap below platform limit or request increase |
| T22 | Request delay | 45–90 sec succeeds | 504/gateway timeout | Synchronous processing cannot be held open | Background job + polling/SSE is mandatory |
| T23 | Replica observation | One replica for v1 | Multiple hosts | Requests may hit different pods | Enforce one replica or externalize OpenCode session engine |
| T24 | CPU/memory/process limits | Meets minimum | Very low limits | OpenCode child or image workloads may be killed | Increase resource class or lower concurrency |
| T25 | npm registry access | `npm view` works | DNS/proxy/403 | Runtime cannot install from public npm | Use company registry or prebuilt approved artifact |
| T26 | Corporate model smoke | Returns `MODEL_OK` | Auth/model/provider error | Published runtime does not inherit terminal model config | Platform must inject approved config/identity |
| T27 | OpenCode Web image paste | Paste and multi-image succeed | Clipboard/attachment unavailable | Stock OpenCode Web cannot satisfy UX in installed version | Custom upload UI is required |
| T28 | K-Slide command | `/k-slide` listed/runs | Missing command | Project root/config layout incorrect | Fix project packaging and command discovery |
| T29 | Skill load | YAML frontmatter valid | Skill missing | Skill file is invalid or wrong location | Block deployment until doctor/static check passes |
| T30 | Task denial | Agent cannot delegate | Raw task calls appear | Permission/agent regression | Keep task deny hard gate and regression test |

## Architecture thresholds

### Green — internal OpenCode server is viable

Required:

```text
T02, T04–T10, T12, T16, T20 and T26 pass
```

Recommended architecture:

```text
FastAPI focused UI + internal opencode serve + server API/SDK
```

### Yellow — per-run OpenCode CLI only

Typical result:

```text
OpenCode exists and child execution works, but long-lived child/secondary server is not reliable
```

Architecture:

```text
FastAPI focused UI + DB queue + opencode run per job
```

Tradeoffs:

- slower startup per run;
- weaker conversational continuity;
- streaming may be harder;
- still deployable if model access passes.

### Red — complete published package is blocked

Typical result:

```text
Published runtime has no OpenCode and cannot install it, or subprocesses are blocked, or corporate model config is unavailable
```

Meaning:

The final AI engine cannot run inside the FastAPI PaaS. One of these must change:

- platform adds OpenCode to the runtime;
- platform allows an approved build/install step;
- OpenCode becomes a separately published internal service;
- employees run a managed personal OpenCode Web workspace;
- another supported model invocation API replaces OpenCode.
