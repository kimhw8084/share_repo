#!/usr/bin/env bash
set -uo pipefail

BASE_URL="${1:-${BASE_URL:-}}"
if [[ -z "$BASE_URL" ]]; then
  echo "Usage: $0 https://project.company-domain"
  exit 2
fi
BASE_URL="${BASE_URL%/}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RESULT_DIR="$ROOT_DIR/results/published-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$RESULT_DIR"

request() {
  local name="$1"
  local method="$2"
  local path="$3"
  echo "Testing $path"
  local output="$RESULT_DIR/$name.txt"
  local code_file="$RESULT_DIR/$name.httpcode"
  local code
  code=$(curl --silent --show-error --location \
    --connect-timeout 15 --max-time 120 \
    --request "$method" \
    --output "$output" \
    --write-out '%{http_code}' \
    "$BASE_URL$path" 2>"$RESULT_DIR/$name.curl-error.txt")
  local status=$?
  printf '%s' "$code" >"$code_file"
  printf '%s' "$status" >"$RESULT_DIR/$name.exitcode"
  if [[ $status -eq 0 && "$code" =~ ^2 ]]; then
    echo "PASS: $path ($code)"
  else
    echo "FAIL: $path (curl=$status, HTTP=$code)"
  fi
}

request health_live GET /health/live
request health_ready GET /health/ready
request runtime GET /probe/runtime
request executables GET /probe/executables
request child_process GET /probe/child-process
request secondary_port GET /probe/secondary-port
request identity GET /probe/identity
request persistence_write GET /probe/persistence/write
request persistence_read GET /probe/persistence/read
request database GET /probe/database
request opencode GET /probe/opencode
request aggregate GET /probe/aggregate
request long_lived_start POST /probe/long-lived/start
sleep 2
request long_lived_status GET /probe/long-lived/status

printf '\nStreaming test (timestamps should arrive every ~2 seconds):\n' | tee "$RESULT_DIR/stream.txt"
{
  date -u +'%Y-%m-%dT%H:%M:%SZ stream-start'
  curl --no-buffer --silent --show-error --max-time 30 "$BASE_URL/probe/stream"
  date -u +'%Y-%m-%dT%H:%M:%SZ stream-end'
} | tee -a "$RESULT_DIR/stream.txt"

python "$ROOT_DIR/scripts/summarize_results.py" "$RESULT_DIR" >"$RESULT_DIR/SUMMARY.md"
cat "$RESULT_DIR/SUMMARY.md"

echo
printf 'Results saved to: %s\n' "$RESULT_DIR"
