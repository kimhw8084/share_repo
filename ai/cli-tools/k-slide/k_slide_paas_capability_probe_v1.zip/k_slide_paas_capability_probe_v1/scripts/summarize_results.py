from __future__ import annotations

import json
import sys
from pathlib import Path

result_dir = Path(sys.argv[1])


def read_json(name: str):
    path = result_dir / f"{name}.txt"
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def status(name: str) -> tuple[str, str]:
    code_path = result_dir / f"{name}.httpcode"
    exit_path = result_dir / f"{name}.exitcode"
    code = code_path.read_text().strip() if code_path.exists() else "missing"
    exit_code = exit_path.read_text().strip() if exit_path.exists() else "missing"
    passed = exit_code == "0" and code.startswith("2")
    return ("PASS" if passed else "FAIL", f"HTTP {code}, curl {exit_code}")

checks = [
    "health_live",
    "health_ready",
    "runtime",
    "executables",
    "child_process",
    "secondary_port",
    "identity",
    "persistence_write",
    "persistence_read",
    "database",
    "opencode",
    "aggregate",
    "long_lived_start",
    "long_lived_status",
]

print("# Published probe summary\n")
print("| Check | Result | Transport |")
print("|---|---|---|")
for check in checks:
    result, transport = status(check)
    print(f"| `{check}` | **{result}** | {transport} |")

executables = read_json("executables") or {}
print("\n## Runtime executables\n")
for name in ("node", "npm", "opencode"):
    path = (executables.get(name) or {}).get("path")
    print(f"- **{name}:** `{path}`")

child = read_json("child_process") or {}
secondary = read_json("secondary_port") or {}
long_status = read_json("long_lived_status") or {}
identity = read_json("identity") or {}
persistence = read_json("persistence_read") or {}
database = read_json("database") or {}
opencode = read_json("opencode") or {}

print("\n## Architecture signals\n")
print(f"- Python child process: **{'PASS' if child.get('passed') else 'FAIL'}**")
print(f"- Secondary localhost port: **{'PASS' if secondary.get('passed') else 'FAIL'}**")
print(f"- Long-lived child alive: **{long_status.get('alive')}**")
print(f"- Persistence marker exists now: **{persistence.get('exists')}**")
print(f"- Database configured/reachable: **{database.get('configured')} / {database.get('passed')}**")
print(f"- OpenCode path: **{opencode.get('path')}**")
print(f"- Identity headers detected: **{', '.join((identity.get('found_headers') or {}).keys()) or 'none'}**")

print("\n## Next actions\n")
print("1. Review `TEST_MATRIX.md` for each failed signal.")
print("2. Restart or republish the application, then run `scripts/persistence_recheck.sh <BASE_URL>`. ")
print("3. Recheck `/probe/long-lived/status` after 5 and 15 minutes.")
print("4. Inspect `stream.txt`; timestamps should arrive progressively, not all at once.")
print("5. Do not enable the real model smoke test until corporate quota use is approved.")
