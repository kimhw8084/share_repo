#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${1:-${BASE_URL:-}}"
SECONDS_VALUE="${2:-45}"
if [[ -z "$BASE_URL" ]]; then
  echo "Usage: $0 https://project.company-domain [seconds]"
  exit 2
fi
BASE_URL="${BASE_URL%/}"

echo "Requesting a ${SECONDS_VALUE}-second response delay…"
time curl --silent --show-error --fail-with-body \
  "$BASE_URL/probe/delay/$SECONDS_VALUE"
echo
