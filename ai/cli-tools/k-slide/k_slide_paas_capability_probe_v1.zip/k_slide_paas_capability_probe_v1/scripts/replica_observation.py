from __future__ import annotations

import json
import sys
import time
import urllib.request
from collections import Counter

if len(sys.argv) != 2:
    raise SystemExit("Usage: python scripts/replica_observation.py https://project.company-domain")
base = sys.argv[1].rstrip("/")
hosts: list[str] = []
for _ in range(30):
    with urllib.request.urlopen(base + "/probe/runtime", timeout=20) as response:
        payload = json.load(response)
    hosts.append(payload["platform"]["hostname"])
    time.sleep(0.2)
counts = Counter(hosts)
print(json.dumps(counts, indent=2))
print(f"Observed {len(counts)} distinct hostname(s).")
print("Note: one observed hostname does not prove the deployment can never scale; confirm replica policy with the platform team.")
