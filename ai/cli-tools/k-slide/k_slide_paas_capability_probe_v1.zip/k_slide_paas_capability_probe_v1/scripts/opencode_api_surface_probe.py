from __future__ import annotations

import base64
import json
import os
import sys
import urllib.error
import urllib.request

base_url = os.getenv("OPENCODE_URL", "http://127.0.0.1:4097").rstrip("/")
username = os.getenv("OPENCODE_SERVER_USERNAME", "opencode")
password = os.getenv("PROBE_OPENCODE_PASSWORD", "")
if not password:
    raise SystemExit("Set PROBE_OPENCODE_PASSWORD to the password used by the test server")

token = base64.b64encode(f"{username}:{password}".encode()).decode()
headers = {"Authorization": f"Basic {token}"}

checks = {
    "/global/health": "health/version",
    "/doc": "OpenAPI documentation",
    "/project/current": "current project",
    "/session": "session list",
    "/command": "custom command list",
    "/agent": "agent list",
}

failed = False
for path, meaning in checks.items():
    request = urllib.request.Request(base_url + path, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            body = response.read().decode("utf-8", errors="replace")
            print(f"PASS {path}: HTTP {response.status} — {meaning}")
            if path != "/doc":
                try:
                    parsed = json.loads(body)
                    print(json.dumps(parsed, indent=2)[:2000])
                except json.JSONDecodeError:
                    print(body[:500])
    except urllib.error.HTTPError as exc:
        failed = True
        print(f"FAIL {path}: HTTP {exc.code} — {exc.read().decode(errors='replace')[:1000]}")
    except Exception as exc:
        failed = True
        print(f"FAIL {path}: {type(exc).__name__}: {exc}")

raise SystemExit(1 if failed else 0)
