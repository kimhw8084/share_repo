#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${1:-${BASE_URL:-}}"
if [[ -z "$BASE_URL" ]]; then
  echo "Usage: $0 https://project.company-domain"
  exit 2
fi
BASE_URL="${BASE_URL%/}"
echo "Events should appear one at a time, approximately every two seconds."
date -u +'%Y-%m-%dT%H:%M:%SZ start'
curl --no-buffer --silent --show-error --fail \
  -H 'Accept: text/event-stream' \
  "$BASE_URL/probe/sse"
date -u +'%Y-%m-%dT%H:%M:%SZ end'
