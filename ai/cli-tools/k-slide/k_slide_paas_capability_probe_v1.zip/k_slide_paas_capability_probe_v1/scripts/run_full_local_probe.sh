#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

./scripts/local_runtime_checks.sh
python scripts/validate_package.py
python -m compileall -q main.py scripts tests

if python -c 'import pytest' >/dev/null 2>&1; then
  python -m pytest -q
else
  echo "pytest is not installed. Run: python -m pip install -r requirements-dev.txt"
fi

echo
cat <<'NEXT'
Automated local checks are complete.

Run the OpenCode-specific tests separately:
  ./scripts/opencode_server_test.sh
  ./scripts/opencode_web_manual.sh

The real model smoke test is opt-in:
  I_UNDERSTAND_MODEL_USAGE=1 ./scripts/model_smoke.sh
NEXT
