#!/usr/bin/env bash
set -euo pipefail

HOST="${PROBE_OPENCODE_WEB_HOST:-127.0.0.1}"
PORT_VALUE="${PROBE_OPENCODE_WEB_PORT:-4098}"
PASSWORD="${PROBE_OPENCODE_PASSWORD:-kslide-web-test}"
PROJECT_DIR="${PROBE_OPENCODE_PROJECT_DIR:-.}"

if ! command -v opencode >/dev/null 2>&1; then
  echo "FAIL: opencode is not on PATH."
  exit 1
fi

cat <<INSTRUCTIONS
This is a manual browser test.

After the server starts, open:
  http://$HOST:$PORT_VALUE

Use username:
  ${OPENCODE_SERVER_USERNAME:-opencode}

Password:
  $PASSWORD

Verify and record:
  [ ] page loads
  [ ] a session can be created
  [ ] one PNG/JPEG can be pasted from clipboard
  [ ] multiple images can be attached
  [ ] the configured model answers
  [ ] /k-slide appears when this is run from the K-Slide project
  [ ] response text streams progressively

Stop the test with Ctrl+C.
INSTRUCTIONS

cd "$PROJECT_DIR"
OPENCODE_SERVER_PASSWORD="$PASSWORD" \
  exec opencode web --hostname "$HOST" --port "$PORT_VALUE"
