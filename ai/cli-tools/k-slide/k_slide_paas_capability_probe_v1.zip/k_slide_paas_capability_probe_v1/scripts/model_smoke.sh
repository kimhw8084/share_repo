#!/usr/bin/env bash
set -euo pipefail

if [[ "${I_UNDERSTAND_MODEL_USAGE:-0}" != "1" ]]; then
  cat <<'MESSAGE'
This test makes a real model request and may consume corporate quota.
Run only after approval:

  I_UNDERSTAND_MODEL_USAGE=1 ./scripts/model_smoke.sh
MESSAGE
  exit 2
fi

if ! command -v opencode >/dev/null 2>&1; then
  echo "FAIL: opencode is not on PATH."
  exit 1
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
printf '# Probe\nDo not use tools. Reply exactly as requested.\n' >"$TMP_DIR/AGENTS.md"

cd "$TMP_DIR"
set +e
OUTPUT="$(opencode run --auto 'Reply only with MODEL_OK' 2>&1)"
STATUS=$?
set -e
printf '%s\n' "$OUTPUT"

if [[ $STATUS -eq 0 && "$OUTPUT" == *MODEL_OK* ]]; then
  echo "PASS: OpenCode reached the configured model and returned MODEL_OK."
  exit 0
fi

echo "FAIL: model smoke test did not return MODEL_OK. Exit code: $STATUS"
exit 1
