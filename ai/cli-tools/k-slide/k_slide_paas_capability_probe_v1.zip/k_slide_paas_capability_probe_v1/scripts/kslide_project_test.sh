#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${KSLIDE_PROJECT_DIR:-}"
if [[ -z "$PROJECT_DIR" ]]; then
  echo "Usage: KSLIDE_PROJECT_DIR=/path/to/k-slide-project ./scripts/kslide_project_test.sh"
  exit 2
fi

required=(
  ".opencode/commands/k-slide.md"
  ".opencode/agents/k-slide-orchestrator.md"
  ".opencode/skills/korean-slide-comprehension/SKILL.md"
)

failed=0
for path in "${required[@]}"; do
  if [[ -f "$PROJECT_DIR/$path" ]]; then
    echo "PASS: $path"
  else
    echo "FAIL: missing $path"
    failed=1
  fi
done

if grep -Eq '^---$' "$PROJECT_DIR/.opencode/skills/korean-slide-comprehension/SKILL.md" 2>/dev/null \
   && grep -Eq '^name:' "$PROJECT_DIR/.opencode/skills/korean-slide-comprehension/SKILL.md" \
   && grep -Eq '^description:' "$PROJECT_DIR/.opencode/skills/korean-slide-comprehension/SKILL.md"; then
  echo "PASS: SKILL.md appears to contain YAML frontmatter with name and description"
else
  echo "FAIL: SKILL.md frontmatter is missing or incomplete"
  failed=1
fi

if grep -Eq 'task:|"task"' "$PROJECT_DIR/.opencode/agents/k-slide-orchestrator.md" \
   && grep -Eq 'deny' "$PROJECT_DIR/.opencode/agents/k-slide-orchestrator.md"; then
  echo "PASS: orchestrator contains a task-deny rule"
else
  echo "WARN: could not confirm task/subagent denial"
fi

if [[ "${I_UNDERSTAND_MODEL_USAGE:-0}" == "1" && -n "${KSLIDE_TEST_IMAGE:-}" ]]; then
  echo "Running a real /k-slide command. This may consume model quota."
  cd "$PROJECT_DIR"
  opencode run --auto --command k-slide "$KSLIDE_TEST_IMAGE"
else
  echo "Static checks only. To make a real request, set I_UNDERSTAND_MODEL_USAGE=1 and KSLIDE_TEST_IMAGE=/path/to/image."
fi

exit "$failed"
