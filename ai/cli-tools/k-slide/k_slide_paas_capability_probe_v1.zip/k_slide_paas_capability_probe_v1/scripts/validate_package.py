from __future__ import annotations

import ast
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
required = [
    "main.py",
    "requirements.txt",
    "README.md",
    "TEST_MATRIX.md",
    "EXPECTED_RESULTS.md",
    "DECISION_TREE.md",
    "RESULTS_TEMPLATE.md",
    "PLATFORM_TEAM_QUESTIONS.md",
    "SECURITY.md",
    "start.sh",
    "scripts/published_smoke.sh",
]

missing = [name for name in required if not (root / name).exists()]
if missing:
    print("Missing required files:", missing)
    raise SystemExit(1)

ast.parse((root / "main.py").read_text(encoding="utf-8"))
print("PASS: package structure and main.py syntax are valid")
