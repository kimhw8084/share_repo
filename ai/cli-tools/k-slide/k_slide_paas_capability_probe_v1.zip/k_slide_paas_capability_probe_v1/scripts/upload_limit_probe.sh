#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${1:-${BASE_URL:-}}"
SIZE_MB="${2:-25}"
if [[ -z "$BASE_URL" ]]; then
  echo "Usage: $0 https://project.company-domain [size_mb]"
  exit 2
fi
BASE_URL="${BASE_URL%/}"
TMP_FILE="$(mktemp)"
trap 'rm -f "$TMP_FILE"' EXIT

echo "Creating ${SIZE_MB} MB temporary upload…"
dd if=/dev/zero of="$TMP_FILE" bs=1M count="$SIZE_MB" status=none

echo "Uploading to $BASE_URL/probe/upload"
curl --silent --show-error --fail-with-body \
  -F "file=@$TMP_FILE;filename=probe-${SIZE_MB}mb.bin" \
  "$BASE_URL/probe/upload"
echo
