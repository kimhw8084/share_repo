#!/usr/bin/env bash
set -euo pipefail

HOST="${PROBE_OPENCODE_HOST:-127.0.0.1}"
PORT_VALUE="${PROBE_OPENCODE_PORT:-4097}"
PASSWORD="${PROBE_OPENCODE_PASSWORD:-kslide-probe-$(date +%s)-$$}"
USERNAME="${OPENCODE_SERVER_USERNAME:-opencode}"
PROJECT_DIR="${PROBE_OPENCODE_PROJECT_DIR:-.}"
LOG_FILE="${PROBE_OPENCODE_LOG:-/tmp/kslide-opencode-server-test.log}"

if ! command -v opencode >/dev/null 2>&1; then
  echo "FAIL: opencode is not on PATH."
  exit 1
fi

cleanup() {
  if [[ -n "${PID:-}" ]] && kill -0 "$PID" 2>/dev/null; then
    kill "$PID" 2>/dev/null || true
    wait "$PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT

(
  cd "$PROJECT_DIR"
  OPENCODE_SERVER_PASSWORD="$PASSWORD" \
    opencode serve --hostname "$HOST" --port "$PORT_VALUE" >"$LOG_FILE" 2>&1
) &
PID=$!

echo "Started OpenCode server PID $PID. Waiting for /global/health…"
for attempt in $(seq 1 45); do
  if ! kill -0 "$PID" 2>/dev/null; then
    echo "FAIL: OpenCode server exited early."
    tail -n 100 "$LOG_FILE" || true
    exit 1
  fi
  if curl --silent --show-error --fail \
      --user "$USERNAME:$PASSWORD" \
      "http://$HOST:$PORT_VALUE/global/health"; then
    echo
    echo "PASS: OpenCode server health endpoint is reachable."
    echo "Checking /doc…"
    curl --silent --show-error --fail --head \
      --user "$USERNAME:$PASSWORD" \
      "http://$HOST:$PORT_VALUE/doc" >/dev/null
    echo "PASS: OpenCode API documentation endpoint is reachable."
    exit 0
  fi
  sleep 1
done

echo "FAIL: OpenCode server did not become healthy within 45 seconds."
tail -n 100 "$LOG_FILE" || true
exit 1
