from __future__ import annotations

import asyncio
import json
import sys

import websockets


async def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python scripts/websocket_probe.py wss://project.company-domain/probe/ws")
    url = sys.argv[1]
    async with websockets.connect(url, open_timeout=15, close_timeout=5) as socket:
        await socket.send("KSLIDE_WS_OK")
        response = json.loads(await asyncio.wait_for(socket.recv(), timeout=15))
        print(json.dumps(response, indent=2))
        if response.get("echo") != "KSLIDE_WS_OK":
            raise SystemExit("FAIL: unexpected echo response")
        print("PASS: WebSocket upgrade and bidirectional message worked")


asyncio.run(main())
