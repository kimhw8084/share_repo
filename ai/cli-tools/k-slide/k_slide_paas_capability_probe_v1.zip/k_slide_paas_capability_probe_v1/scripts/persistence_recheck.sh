#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${1:-${BASE_URL:-}}"
if [[ -z "$BASE_URL" ]]; then
  echo "Usage: $0 https://project.company-domain"
  exit 2
fi
BASE_URL="${BASE_URL%/}"

echo "Reading persistence marker after restart/republish/pod replacement:"
curl --silent --show-error --fail "$BASE_URL/probe/persistence/read"
echo

echo "Interpretation:"
echo "- exists=true with the same probe_id: mounted storage persisted."
echo "- exists=false: local storage is ephemeral or the mount path changed."
echo "- a different hostname is fine and can prove persistence across pod replacement."
