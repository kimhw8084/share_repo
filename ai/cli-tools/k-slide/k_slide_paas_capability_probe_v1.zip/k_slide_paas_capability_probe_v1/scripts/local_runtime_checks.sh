#!/usr/bin/env bash
set -uo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RESULT_DIR="$ROOT_DIR/results/local-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$RESULT_DIR"

run_and_capture() {
  local name="$1"
  shift
  echo "### $name"
  {
    echo "+ $*"
    "$@"
  } >"$RESULT_DIR/$name.txt" 2>&1
  local status=$?
  echo "$status" >"$RESULT_DIR/$name.exitcode"
  if [[ $status -eq 0 ]]; then
    echo "PASS: $name"
  else
    echo "FAIL ($status): $name — inspect $RESULT_DIR/$name.txt"
  fi
  return 0
}

run_and_capture python_version python --version
run_and_capture node_path sh -c 'command -v node && node --version'
run_and_capture npm_path sh -c 'command -v npm && npm --version'
run_and_capture opencode_path sh -c 'command -v opencode && opencode --version'
run_and_capture python_sees_opencode python - <<'PY'
import os, shutil
print("PATH=", os.environ.get("PATH"))
print("opencode=", shutil.which("opencode"))
raise SystemExit(0 if shutil.which("opencode") else 1)
PY
run_and_capture python_child_opencode python - <<'PY'
import subprocess
result = subprocess.run(["opencode", "--version"], text=True, capture_output=True, timeout=30)
print("returncode:", result.returncode)
print("stdout:", result.stdout)
print("stderr:", result.stderr)
raise SystemExit(result.returncode)
PY
run_and_capture resources python - <<'PY'
import os, resource
print("cpu_count:", os.cpu_count())
print("address_space_limit:", resource.getrlimit(resource.RLIMIT_AS))
print("process_limit:", resource.getrlimit(resource.RLIMIT_NPROC))
print("open_files:", resource.getrlimit(resource.RLIMIT_NOFILE))
PY
run_and_capture filesystem sh -c 'df -h; echo; (free -h || true)'
run_and_capture npm_registry sh -c 'npm view opencode-ai version'

cat >"$RESULT_DIR/SUMMARY.txt" <<SUMMARY
Local capability checks finished.

Result directory:
$RESULT_DIR

Review every *.exitcode and *.txt file. A nonzero exit code for node, npm, opencode, Python child execution, or npm registry access is architecturally significant. See TEST_MATRIX.md.
SUMMARY

cat "$RESULT_DIR/SUMMARY.txt"
