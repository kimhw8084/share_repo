# Expected Results and Examples

## Healthy baseline

### Liveness

```json
{
  "status": "ok",
  "app": "K-Slide PaaS Capability Probe",
  "version": "1.0.0"
}
```

### Readiness

```json
{
  "status": "ready",
  "data_dir_writable": true
}
```

### Child process

```json
{
  "passed": true,
  "returncode": 0,
  "stdout": "child-process-ok"
}
```

### Secondary port

```json
{
  "passed": true,
  "status": 200
}
```

### Executables — best case

```json
{
  "node": {"path": "/usr/bin/node"},
  "npm": {"path": "/usr/bin/npm"},
  "opencode": {"path": "/usr/local/bin/opencode"}
}
```

Exact paths and versions may differ. Non-null paths are what matters.

### Identity

```json
{
  "found_headers": {
    "accesskey": {
      "display": "ji******an",
      "length": 12,
      "sha256_prefix": "..."
    }
  },
  "values_are_masked": true
}
```

This does not prove the header is safe to store. Confirm whether it is a user identifier or a credential.

### Database

```json
{
  "configured": true,
  "passed": true,
  "driver": "postgresql+psycopg",
  "result": 1
}
```

### OpenCode server — best case

```json
{
  "path": "/usr/local/bin/opencode",
  "server": {
    "configured_to_start": true,
    "process_alive": true,
    "password_configured": true,
    "health": {
      "reachable": true,
      "status": 200,
      "body": {
        "healthy": true,
        "version": "..."
      }
    }
  }
}
```

## Common failures

### `opencode` path is null

Meaning:

- OpenCode installed in your interactive terminal is not installed in the published pod; or
- the binary directory is missing from the FastAPI process `PATH`.

Actions:

1. Compare `/probe/runtime` PATH with `which opencode` in the work terminal.
2. Determine whether the PaaS supports npm installation during build.
3. Check whether a company npm registry must be used.
4. Do not attempt a real K-Slide run until the binary is visible.

### Child process fails

Example:

```json
{
  "passed": false,
  "stderr": "Permission denied"
}
```

Meaning: FastAPI cannot launch OpenCode. An embedded engine is blocked regardless of Node/OpenCode installation.

### Secondary port fails

Meaning: FastAPI may execute short subprocesses but cannot run a local HTTP engine. Use `opencode run` per job or a separately hosted engine.

### OpenCode starts but health is 401

Meaning: password/username mismatch. Confirm:

```text
PROBE_OPENCODE_PASSWORD
OPENCODE_SERVER_USERNAME
```

The username defaults to `opencode` unless overridden.

### OpenCode process exits immediately

Inspect:

```text
/data/kslide-probe/logs/opencode-server.log
```

and platform logs. Common causes:

- missing binary;
- invalid project directory;
- permission/config error;
- port conflict;
- corporate provider configuration absent;
- process restrictions.

### Stream output arrives all at once

Meaning: corporate ingress buffers streaming. The final product must display progress using polling, although the engine can still run.

### Persistence disappears

Meaning: container filesystem is ephemeral. Run metadata should be in PostgreSQL; report/image persistence requires a mounted folder or object storage.

### No identity header appears

Meaning: the PaaS ingress authenticates the browser but does not forward identity to the app, or the header name is not in the candidate list.

Action: ask the platform team for the exact trusted identity header and add it to:

```text
PROBE_IDENTITY_HEADERS
```

### Upload returns 413

If the FastAPI body does not appear, the ingress rejected it. The final upload limit must be lower than the gateway limit unless the platform team raises it.

### Model smoke fails in published app but works in terminal

Meaning: the PaaS pod does not inherit the same corporate OpenCode/provider identity or configuration as the interactive workspace.

This is a hard blocker until the platform injects the approved configuration into the published runtime.
