# Internal Test Report

Package version: `1.0.0`

Tests performed before packaging:

| Test | Result |
|---|---|
| Python AST/package structure validation | Pass |
| Python compileall | Pass |
| Pytest application suite | 3 passed |
| FastAPI liveness/readiness | Pass |
| Child-process execution | Pass |
| Secondary localhost HTTP server | Pass |
| Long-lived child start/status/stop | Pass |
| Persistence write/read | Pass |
| Identity header masking | Pass |
| Model discovery disabled by default | Pass |
| Model smoke disabled by default | Pass |
| Published smoke script against local Uvicorn | Pass |
| Progressive NDJSON stream | Pass |
| Progressive SSE stream | Pass |
| Multipart upload/hash/no-storage behavior | Pass |
| Controlled delay endpoint | Pass |
| WebSocket echo | Pass |

Environment-dependent tests not performed here:

- your company FastAPI publisher;
- company DNS/ingress behavior;
- mounted persistence after pod replacement;
- company identity headers;
- PostgreSQL service linkage;
- OpenCode availability in the published runtime;
- corporate Gemma configuration and quota;
- stock OpenCode Web image clipboard behavior on your installed version.

Those are the purpose of this package and are explicitly documented in the README and test matrix.
