# Changelog

## 1.0.0 — 2026-07-22

- Preserved K-Slide v6 as an immutable baseline with checksum.
- Rebuilt K-Slide as a personal OpenCode Web appliance for corporate cloud workspaces.
- Made K-Slide the default primary agent.
- Removed Bash, edit, task, web, and filesystem dependencies from normal slide analysis.
- Added evidence-first slide comprehension, table/chart/diagram contracts, explicit uncertainty, and prompt-injection resistance.
- Added complete and deep-verification commands plus strict JSON evaluation mode.
- Added one-command start, stop, status, doctor, update, version activation, and rollback workflows.
- Added structured evaluation schemas, deterministic validators, A/B runner, and synthetic regression tests.
- Added scientific basis, evaluation methodology, user guide, admin guide, security guide, and troubleshooting.
- Added automatic first-run/update setup behind the single `./start-k-slide` command.
- Added project-local OpenCode installation fallback when global npm installation is denied.
- Added setup-state drift detection, blind v6-versus-candidate evaluation, phone-friendly review codes, release checklist, and research decision log.
- Removed the undocumented `--auto` CLI flag from evaluation runners and made the temporary baseline permission change explicit.
