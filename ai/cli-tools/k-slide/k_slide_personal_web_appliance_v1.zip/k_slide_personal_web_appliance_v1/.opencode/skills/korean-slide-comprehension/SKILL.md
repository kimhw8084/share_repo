---
name: korean-slide-comprehension
description: Canonical evidence-grounded Korean slide comprehension contract.
---

Active version: `2026.07.22-research-candidate-1`

The compiled primary agent embeds the complete active contract directly to avoid a runtime skill-tool call.
