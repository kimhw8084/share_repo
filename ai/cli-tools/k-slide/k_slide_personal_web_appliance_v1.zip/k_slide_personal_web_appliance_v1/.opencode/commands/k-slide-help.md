---
description: One-screen K-Slide usage help.
agent: k-slide
subtask: false
---

Reply exactly with this concise help:

K-Slide is ready.
1. Paste or attach one or more slide screenshots.
2. Press Enter for complete analysis; no command is required.
3. Use `/k-slide-deep` for dense or critical slides.
4. Ask follow-up questions in the same session.
5. K-Slide will mark unreadable content instead of guessing.
