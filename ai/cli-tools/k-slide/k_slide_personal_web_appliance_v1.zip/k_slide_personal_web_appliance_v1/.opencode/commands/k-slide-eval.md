---
description: Machine-readable K-Slide evidence output for regression evaluation.
agent: k-slide
subtask: false
---

Run the K-Slide evaluation mode on every attached image. Output only one valid JSON object conforming to the complete evaluation JSON contract embedded in the active K-Slide agent. Do not use Markdown fences. Do not add prose outside the JSON.

Evaluation context: `$ARGUMENTS`
