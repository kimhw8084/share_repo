---
description: Deep second-pass verification for dense tables, charts, diagrams, or critical slides.
agent: k-slide
subtask: false
---

Run K-Slide in deep-verification mode on every attached image. Perform two independent inventories in different reading orders, reconcile disagreements, include stable element IDs and an explicit coverage ledger, verify every number/table/chart/relationship, and favor completeness over brevity.

User context: `$ARGUMENTS`
