---
description: Complete Korean slide comprehension for attached images.
agent: k-slide
subtask: false
---

Analyze every attached image using the complete K-Slide contract. Begin immediately. Preserve every material element, reconstruct tables and visual relationships, preserve numbers, separate observation from interpretation, verify independently, and return the normal human-readable response.

User context: `$ARGUMENTS`
