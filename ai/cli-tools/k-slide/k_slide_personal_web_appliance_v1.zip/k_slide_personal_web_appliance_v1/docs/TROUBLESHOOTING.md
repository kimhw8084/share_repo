# Troubleshooting

## `opencode` not found

```bash
npm install -g opencode-ai
./doctor-k-slide
```

## Corporate model unavailable

Run:

```bash
opencode models
opencode run "Reply only with MODEL_OK"
```

The package deliberately does not overwrite corporate provider configuration.

## Web page does not open

```bash
./status-k-slide
cat .k-slide/runtime/web.log
```

Open the port shown by `./status-k-slide` through VS Code’s Ports panel.

## Browser asks for a password that does not work

Stop the process and start with the package launcher:

```bash
./stop-k-slide
unset OPENCODE_SERVER_PASSWORD OPENCODE_SERVER_USERNAME
./start-k-slide
```

The launcher removes stale OpenCode Basic-auth variables by default and binds to loopback.

## Dense text is missed

Use the highest-quality screenshot available and rerun with `/k-slide-deep`. Record the case in the golden regression corpus before changing image limits or prompts.

## Raw tool-call text appears

This candidate agent denies every tool and runs with one response step. Confirm the active agent:

```bash
./doctor-k-slide
python3 scripts/validate_prompt.py
```
