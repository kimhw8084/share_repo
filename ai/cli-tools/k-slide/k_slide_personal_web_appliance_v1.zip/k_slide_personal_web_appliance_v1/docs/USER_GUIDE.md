# Employee user guide

## Start

1. Open the K-Slide repository in cloud VS Code.
2. Open a terminal.
3. Run `./start-k-slide`. On first use, it automatically performs setup, security checks, and package tests.
4. In VS Code’s **Ports** panel, open the forwarded K-Slide port.

## Analyze slides

1. Paste or attach one or more screenshots in slide order.
2. Press Enter without typing anything.
3. K-Slide reconstructs every material item in English, recreates tables, explains charts/processes, preserves numbers, and lists unreadable content.
4. Ask follow-up questions in the same conversation.

## Dense slides

Attach the images and enter `/k-slide-deep` when the slide contains dense tables, small text, complex charts, or when the result is business-critical.

## Good input

- Use the original screenshot rather than a photo of a monitor.
- Keep the entire slide visible.
- Prefer high resolution.
- Upload one logical deck per session and preserve slide order.

## Meaning of final status

- `COMPLETE` — all material content was represented and verified.
- `COMPLETE_WITH_NOTES` — complete, with minor ambiguity explicitly noted.
- `NEEDS_REVIEW` — one or more material regions could not be confidently resolved.
- `INPUT_UNREADABLE` — the image quality is insufficient.
