# Scientific and technical basis

The K-Slide architecture converts research findings into testable engineering hypotheses. Research does not automatically prove effectiveness on the corporate Gemma model; every technique must pass paired internal evaluation.

## Document OCR and layout limitations

OCRBench v2 reports persistent weaknesses in fine-grained perception, layout perception, complex-element parsing, and logical reasoning across multimodal models. K-Slide therefore uses explicit evidence inventory, structure-specific contracts, and unresolved markers rather than trusting fluent summaries.

- Fu et al., “OCRBench v2: An Improved Benchmark for Evaluating Large Multimodal Models on Visual Text Localization and Reasoning,” NeurIPS 2025. https://arxiv.org/abs/2501.00321
- CC-OCR V2, enterprise-oriented OCR benchmark, 2026. https://arxiv.org/abs/2605.03903

## High-resolution document understanding

Research such as UReader, TextMonkey, and mPLUG-DocOwl2 shows that high-resolution handling, adaptive cropping, visual token compression, and positional grounding materially affect text-rich document understanding. K-Slide raises the OpenCode image limit and makes image-resolution strategy an explicit A/B test.

- Ye et al., “UReader,” Findings of EMNLP 2023. https://aclanthology.org/2023.findings-emnlp.187/
- Liu et al., “TextMonkey,” 2024/2026. https://arxiv.org/abs/2403.04473
- Hu et al., “mPLUG-DocOwl2,” ACL 2025. https://aclanthology.org/2025.acl-long.291/

## Table structure

PubTabNet separates table structure from cell content and introduced TEDS because ordinary text metrics fail to measure structural errors. K-Slide therefore represents rows, columns, cells, spans, and content separately in evaluation mode.

- Zhong et al., “Image-based table recognition: data, model, and evaluation,” ECCV 2020. https://arxiv.org/abs/1911.10683
- Nassar et al., “TableFormer,” 2022. https://arxiv.org/abs/2203.01017

## Chart reasoning

ChartQA demonstrates that chart understanding requires both visual and logical reasoning. K-Slide explicitly inventories axes, scales, legends, series, values, annotations, comparisons, and inferred implications.

- Masry et al., “ChartQA,” Findings of ACL 2022. https://aclanthology.org/2022.findings-acl.177/

## Verification and repair

Chain-of-Verification reduces hallucination by separating drafting, verification-question planning, independent answers, and final revision. Self-Refine shows iterative feedback can improve outputs, though intrinsic self-assessment remains weaker than deterministic or human verification. K-Slide uses independent verification questions and only one targeted repair pass.

- Dhuliawala et al., “Chain-of-Verification,” 2023. https://arxiv.org/abs/2309.11495
- Madaan et al., “Self-Refine,” 2023. https://arxiv.org/abs/2303.17651

## Translation quality

K-Slide adapts the Multidimensional Quality Metrics framework to classify omissions, additions, mistranslations, terminology errors, structural errors, numeric errors, fluency problems, and uncertainty-handling failures rather than relying only on naturalness.

- MQM Council. https://themqm.org/
- Multi-dimensional English–Korean MQM evaluation work, 2024. https://arxiv.org/abs/2403.12666

## Multimodal prompt injection

Research and OWASP guidance document that malicious instructions can be embedded in images. K-Slide treats image text strictly as data and removes all tool permissions from the normal agent.

- OWASP GenAI, LLM01:2025 Prompt Injection. https://genai.owasp.org/llmrisk/llm01-prompt-injection/
- Wang et al., “Manipulating Multimodal Agents via Cross-Modal Prompt Injection,” 2025. https://arxiv.org/abs/2504.14348

## OpenCode implementation basis

OpenCode supports a Web interface, project-level default agents, custom commands, disabled sharing, subagent-depth control, image attachment limits, and granular permissions. The package uses these documented controls while preserving corporate model configuration.

- Web: https://opencode.ai/docs/web/
- Config: https://opencode.ai/docs/config/
- Agents: https://opencode.ai/docs/agents/
- Permissions: https://opencode.ai/docs/permissions/
- Network: https://opencode.ai/docs/network/
