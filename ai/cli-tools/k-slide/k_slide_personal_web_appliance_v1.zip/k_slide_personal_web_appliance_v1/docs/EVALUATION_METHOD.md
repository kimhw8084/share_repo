# K-Slide evaluation method

## Principle

Research suggests candidate techniques; controlled paired evaluation on the corporate Gemma model determines promotion.

## Golden corpus

Start with at least 30 non-confidential Korean slides and expand to 75–100. Include simple bullets, dense text, basic and merged tables, charts, process diagrams, roadmaps, mixed Korean/English slides, footnotes, low-resolution screenshots, and multi-slide decks.

Each gold record should include:

- every material element and its reading order;
- exact Korean source text where legible;
- accepted English translations and terminology;
- numbers, dates, units, percentages, currencies, and footnotes;
- table dimensions and cell spans;
- chart axes, series, labels and required conclusions;
- diagram nodes and relations;
- legitimately unreadable regions;
- factual and structural comprehension questions.

## Primary metrics

- Material element coverage
- Silent omission rate
- Significant numeric fidelity
- Cardinality fidelity
- Table structure fidelity
- Chart-question accuracy
- Diagram-relation fidelity
- MQM-style translation error severity
- Unsupported inference rate
- Zero-Korean comprehension score
- First-pass success and repair success
- Latency and runtime failure rate

## Release gates

- Significant numeric fidelity: 100%
- Cardinality fidelity: 100%
- Material element coverage: at least 99%
- Table structure fidelity: at least 98%
- Explicit handling of unresolved material: 100%
- Unsupported factual additions: below 1%
- Zero-Korean comprehension: at least 90%
- Friendly terminal status: 100%

## Running a candidate

```bash
python3 evaluation/run_candidate.py   evaluation/golden/example-slide.png   --output evaluation/results/candidate/example.json

python3 evaluation/score_ledger.py evaluation/results/candidate/example.json
```

The immutable v6 baseline is evaluated separately using its original workflow and artifacts. Never retrofit candidate instructions into the baseline.

## Blind baseline-versus-candidate run

Run both the immutable v6 control and the active candidate on the same image(s):

```bash
python3 evaluation/run_ab.py case-001 path/to/slide.png
```

The command creates a timestamped folder under `evaluation/results/` containing:

- baseline and candidate raw outputs;
- candidate evidence ledger and deterministic score;
- `BLIND_OUTPUT_A.md` and `BLIND_OUTPUT_B.md` in randomized order;
- `PAIR_REVIEW.md`;
- `mapping.json`, which must remain unopened until the blind review is complete.

The baseline zip itself is never modified. The runner changes `bash: ask` to `bash: allow` only in the temporary installed copy so current non-interactive OpenCode can execute the original v6 workflow without an approval prompt.

## Phone-friendly review handoff

After reviewing A and B, run:

```bash
python3 evaluation/phone_review.py evaluation/results/case-001/<timestamp>
```

Answer with one key per question. The script creates `PHONE_REPLY.txt`, a single line that can be pasted from a phone without explaining the run manually.

## Promotion decision

Research does not promote a prompt. Real paired evidence does. Review `docs/RELEASE_CHECKLIST.md` and `docs/RESEARCH_DECISION_LOG.md` before changing the active version.
