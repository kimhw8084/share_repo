# Security model

## Image prompt injection

Slide images are untrusted inputs. Visible or hidden instructions in an image must never override the K-Slide contract. The agent has no tool privileges, so an image cannot induce shell execution, file access, workspace edits, web requests, or subagent calls.

## Network exposure

The launcher binds OpenCode Web to `127.0.0.1` and expects access through the corporate cloud VS Code authenticated port-forwarding feature. Do not change `KSLIDE_HOST` to `0.0.0.0` unless the workspace has an independently approved access-control boundary.

Basic authentication is optional through `KSLIDE_USE_BASIC_AUTH=1`, but it is disabled by default because the environment test observed password incompatibility. Loopback binding is mandatory when Basic auth is not enabled.

## Data handling

- OpenCode sharing is disabled.
- Do not use public share links.
- Do not enable web search for confidential slides.
- The package does not contain or modify provider credentials.
- Session retention follows the personal OpenCode workspace configuration and company policy.

## Minimum OpenCode version

K-Slide refuses to start OpenCode versions below `1.1.10`. This minimum is above the patched version for CVE-2026-22812 (`1.0.216`) and includes the fix for CVE-2026-22813 (`1.1.10`). These advisories involved unauthenticated/local Web-server exposure and Web UI injection that could reach command-execution endpoints. The package records both the minimum secure version and the version tested for this release. Run `./start-k-slide`; secure setup and upgrade are automatic when required.
