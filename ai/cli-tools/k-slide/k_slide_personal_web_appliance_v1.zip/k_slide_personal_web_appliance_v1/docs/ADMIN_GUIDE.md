# Maintainer and administrator guide

## Version model

- Immutable historical baseline: `baseline/korean_slide_gemma_opencode_pack_v6.zip`
- Versioned candidates: `config/versions/<version>/`
- Active version pointer: `ACTIVE_PROMPT_VERSION`
- Compiled runtime agent: `.opencode/agents/k-slide.md`

## Activate a version

```bash
python3 scripts/apply_version.py <version>
./scripts/self_test.sh
```

Restart OpenCode Web after activation:

```bash
./stop-k-slide
./start-k-slide
```

## Rollback

Set the previously approved version:

```bash
python3 scripts/apply_version.py <previous-version>
./scripts/self_test.sh
./stop-k-slide
./start-k-slide
```

## Promotion rule

A candidate must not be promoted based only on subjective prompt review. It must:

1. pass all deterministic package and prompt-contract tests;
2. run against the fixed golden slide corpus with identical model/settings;
3. match or exceed the approved baseline on every critical metric;
4. have zero regression in significant numeric fidelity and cardinality;
5. have no critical table/diagram regression;
6. pass Korean-speaker review and zero-Korean comprehension testing.

## Updating employees

Employees run `./update-k-slide`, which performs a fast-forward Git pull, applies the active prompt version, runs tests, and restarts the personal Web appliance.
