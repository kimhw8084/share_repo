# Research Decision Log

This document prevents research-backed ideas from becoming production behavior without measured evidence.

| Decision | Research basis | Engineering hypothesis | Candidate implementation | Required promotion evidence | Status |
|---|---|---|---|---|---|
| Evidence inventory before prose | Document/OCR benchmarks show fine-grained layout and omission weaknesses | Enumerating stable elements reduces silent omission | Evidence-first internal protocol and JSON ledger | Higher material-element recall and lower silent omission than v6 | Candidate |
| Preserve high-resolution attachments | High-resolution document models use adaptive resolution/cropping | Larger slide input preserves small Korean text | OpenCode image limits raised to 4096×4096 and 16 MiB | Better dense-text recall without unacceptable failures/latency | Candidate |
| Reconstruct tables structurally | TEDS/PubTabNet show text-only metrics miss table structure | Explicit rows, columns and spans reduce table loss | Table law plus cell-grid evidence schema | Better row/column/cell fidelity than v6 | Candidate |
| Separate observed, translated and inferred content | Translation and hallucination evaluation distinguish accuracy from fluency | Layer separation reduces unsupported claims | Three-layer output contract | Lower unsupported-inference and MQM accuracy errors | Candidate |
| Independent verification questions | Chain-of-Verification and iterative refinement reduce some factual errors | Image-grounded verification catches omissions before final answer | Seven-question verification and one targeted repair | Improved numeric/cardinality/coverage fidelity | Candidate |
| One targeted repair only | Unbounded self-refinement can add latency and regress correct content | Focused repair corrects gaps with lower drift | One repair pass restricted to failed elements | Better repair success with no increased hallucination | Candidate |
| Disable all model tools | Prior K-Slide failures were dominated by setup, file-write and tool-call errors | Chat-only inference improves reliability and reduces token/tool overhead | Read/edit/bash/task/web/skill denied | 100% friendly terminal state and fewer runtime failures | Candidate |
| Treat image text as untrusted | Multimodal prompt-injection research demonstrates cross-modal instruction attacks | Explicit data/instruction separation prevents slide-borne prompt injection | Safety boundary in primary agent | Adversarial image suite produces no tool/action compliance | Candidate |
| Keep v6 immutable | Scientific comparison requires a stable control | Side-by-side testing prevents accidental baseline drift | Checksummed v6 zip under `baseline/` | Checksum remains unchanged in every release | Active control |

## Promotion rule

A candidate may replace the baseline only after:

1. deterministic package and contract tests pass;
2. blinded paired tests show no critical regression;
3. material-element, numeric, cardinality and table metrics meet release thresholds;
4. Korean-speaking reviewers approve translation accuracy;
5. zero-Korean readers meet the comprehension threshold;
6. launcher/setup succeeds from a fresh Git clone.
