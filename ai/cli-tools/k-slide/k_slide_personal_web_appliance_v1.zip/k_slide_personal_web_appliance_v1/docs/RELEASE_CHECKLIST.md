# Release Checklist

## Deterministic gate

- [ ] `./scripts/self_test.sh` passes.
- [ ] `python3 scripts/validate_prompt.py` passes.
- [ ] Active agent is byte-identical to its compiled version.
- [ ] Baseline v6 SHA-256 matches `baseline/SHA256SUMS.txt`.
- [ ] OpenCode version is at or above `OPENCODE_MIN_VERSION`.
- [ ] OpenCode tested-version drift is documented.
- [ ] Release zip contains executable modes for lifecycle scripts.
- [ ] Self-test passes from a clean extracted release zip.

## Corporate environment gate

- [ ] `./setup-k-slide` succeeds from a fresh Git clone.
- [ ] `./doctor-k-slide` reports READY.
- [ ] `./start-k-slide` starts OpenCode Web.
- [ ] VS Code port forwarding opens the Web UI.
- [ ] Image paste works.
- [ ] Multiple images preserve order.
- [ ] Default K-Slide agent is selected automatically.
- [ ] Model smoke test succeeds through corporate configuration.

## Quality gate

- [ ] At least 30 representative non-confidential Korean slides are annotated.
- [ ] Candidate and v6 are compared blindly.
- [ ] Significant numeric fidelity is 100%.
- [ ] Cardinality fidelity is 100%.
- [ ] Material-element coverage is at least 99%.
- [ ] Table structure fidelity is at least 98%.
- [ ] No visible table is replaced only by a summary.
- [ ] Unsupported factual additions remain below 1%.
- [ ] All uncertainty is explicitly surfaced.
- [ ] Zero-Korean comprehension quiz accuracy is at least 90%.
- [ ] No critical regression is reported by any reviewer.

## Security gate

- [ ] Sharing remains disabled.
- [ ] Default binding remains loopback unless explicitly approved.
- [ ] Model tools remain denied.
- [ ] Image prompt-injection test suite passes.
- [ ] No credentials or provider settings are bundled.
- [ ] No runtime logs or evaluation results are included in release zip.

A release failing any critical item remains a candidate and must not replace the approved baseline.
