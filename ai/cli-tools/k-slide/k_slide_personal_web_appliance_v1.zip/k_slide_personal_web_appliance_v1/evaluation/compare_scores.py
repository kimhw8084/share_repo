#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument('baseline'); ap.add_argument('candidate'); a=ap.parse_args()
b=json.loads(Path(a.baseline).read_text()); c=json.loads(Path(a.candidate).read_text())
keys=sorted(set(b.get('metrics',{}))|set(c.get('metrics',{})))
print('| Metric | Baseline | Candidate | Delta |')
print('|---|---:|---:|---:|')
for k in keys:
    bv=b.get('metrics',{}).get(k); cv=c.get('metrics',{}).get(k)
    if isinstance(bv,(int,float)) and isinstance(cv,(int,float)):
        print(f'| {k} | {bv:.4f} | {cv:.4f} | {cv-bv:+.4f} |')
    else: print(f'| {k} | {bv} | {cv} | — |')
print(f"\nBaseline gate: {b.get('release_gate_pass')}\nCandidate gate: {c.get('release_gate_pass')}")
