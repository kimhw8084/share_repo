#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

def ask(prompt: str, allowed: set[str]) -> str:
    while True:
        value=input(prompt).strip().upper() or '?'
        if value in allowed: return value
        print('Enter one of:', '/'.join(sorted(allowed)))

def main() -> int:
    ap=argparse.ArgumentParser(description='Create a one-line phone handoff for a blind A/B review.')
    ap.add_argument('run_dir')
    args=ap.parse_args()
    root=Path(args.run_dir).resolve()
    mapping_path=root/'mapping.json'
    if not mapping_path.is_file(): raise SystemExit(f'Missing {mapping_path}')
    print('Review BLIND_OUTPUT_A.md and BLIND_OUTPUT_B.md before answering.')
    preferred=ask('Preferred output [A/B/T/?]: ',{'A','B','T','?'})
    korean=ask('Better Korean accuracy [A/B/T/?]: ',{'A','B','T','?'})
    comprehension=ask('Better zero-Korean comprehension [A/B/T/?]: ',{'A','B','T','?'})
    regression=ask('Any critical regression? [Y/N/?]: ',{'Y','N','?'})
    table=ask('Better tables/structure [A/B/T/?]: ',{'A','B','T','?'})
    numbers=ask('Any missing/wrong important number? [A/B/N/?] (A or B identifies offender): ',{'A','B','N','?'})
    mapping=json.loads(mapping_path.read_text())
    payload={
        'case': root.parent.name,
        'preferred': preferred,
        'korean_accuracy': korean,
        'zero_korean_comprehension': comprehension,
        'critical_regression': regression,
        'table_structure': table,
        'numeric_offender': numbers,
        'mapping': mapping,
    }
    raw=json.dumps(payload,sort_keys=True,separators=(',',':'))
    checksum=hashlib.sha256(raw.encode()).hexdigest()[:8].upper()
    line=(f"KSR1 CASE={payload['case']} P={preferred} K={korean} Z={comprehension} "
          f"R={regression} T={table} NUM={numbers} MAPA={mapping.get('A')} MAPB={mapping.get('B')} #{checksum}")
    (root/'PHONE_REVIEW.json').write_text(json.dumps(payload,indent=2)+'\n')
    (root/'PHONE_REPLY.txt').write_text(line+'\n')
    print('\n'+line)
    print(f'\nSaved: {root/"PHONE_REPLY.txt"}')
    return 0
if __name__=='__main__': raise SystemExit(main())
