# Golden corpus

Do not place confidential production slides in a broadly shared repository.

Create one folder per approved non-confidential case:

```text
evaluation/golden/<case-id>/
  slide-001.png
  gold.json
  reviewer-notes.md
```

Use `evaluation/schemas/evidence-ledger.schema.json` for candidate output and maintain separate human gold annotations. A case is admitted only after a Korean-speaking reviewer confirms the source transcription and structural annotation.
