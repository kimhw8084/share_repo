#!/usr/bin/env python3
from __future__ import annotations
import json,re,sys
from pathlib import Path
text=Path(sys.argv[1]).read_text(encoding='utf-8',errors='replace') if len(sys.argv)>1 else sys.stdin.read()
candidates=[]
for m in re.finditer(r'\{',text):
    start=m.start(); depth=0; ins=False; esc=False
    for i,ch in enumerate(text[start:],start):
        if ins:
            if esc: esc=False
            elif ch=='\\': esc=True
            elif ch=='"': ins=False
        else:
            if ch=='"': ins=True
            elif ch=='{': depth+=1
            elif ch=='}':
                depth-=1
                if depth==0:
                    raw=text[start:i+1]
                    try: candidates.append(json.loads(raw))
                    except Exception: pass
                    break
if not candidates: raise SystemExit('No valid JSON object found')
print(json.dumps(candidates[-1],ensure_ascii=False,indent=2))
