#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, random, shutil, subprocess, sys, tempfile, time, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from kslide_paths import find_opencode
BASELINE_ZIP=ROOT/'baseline/korean_slide_gemma_opencode_pack_v6.zip'

def run(cmd,cwd,timeout=1200):
    return subprocess.run(cmd,cwd=cwd,capture_output=True,text=True,timeout=timeout)

def candidate_normal(images,out):
    oc=find_opencode() or 'opencode'
    cmd=[oc,'run','--dir',str(ROOT),'--command','k-slide','--format','default']
    for i in images: cmd += ['--file',str(i)]
    cmd += ['Analyze the attached slide image(s) completely.']
    p=run(cmd,ROOT)
    (out/'stdout.txt').write_text(p.stdout or '',encoding='utf-8')
    (out/'stderr.txt').write_text(p.stderr or '',encoding='utf-8')
    (out/'returncode.txt').write_text(str(p.returncode)+'\n')
    return p.returncode

def candidate_eval(images,out):
    cmd=[sys.executable,str(ROOT/'evaluation/run_candidate.py'),*[str(i) for i in images],'--output',str(out/'evidence.json')]
    p=run(cmd,ROOT)
    (out/'eval-runner.txt').write_text((p.stdout or '')+'\nSTDERR:\n'+(p.stderr or ''),encoding='utf-8')
    if (out/'evidence.json').exists():
        s=run([sys.executable,str(ROOT/'evaluation/score_ledger.py'),str(out/'evidence.json'),'--output',str(out/'score.json')],ROOT)
        (out/'score-runner.txt').write_text((s.stdout or '')+'\nSTDERR:\n'+(s.stderr or ''),encoding='utf-8')
    return p.returncode

def baseline(images,out):
    with tempfile.TemporaryDirectory() as td:
        td=Path(td); extracted=td/'extracted'; project=td/'project'; extracted.mkdir(); project.mkdir()
        with zipfile.ZipFile(BASELINE_ZIP) as z: z.extractall(extracted)
        pack=extracted/'korean_slide_gemma_opencode_pack_v6'
        p=run([str(pack/'scripts/install_project.sh'),str(project)],pack)
        if p.returncode:
            (out/'install-error.txt').write_text((p.stdout or '')+'\n'+(p.stderr or ''),encoding='utf-8'); return p.returncode
        # The immutable baseline prompts are unchanged. For non-interactive A/B execution only,
        # convert its Bash permission from ask to allow in this temporary extracted project.
        baseline_agent=project/'.opencode/agents/k-slide-orchestrator.md'
        if baseline_agent.is_file():
            text=baseline_agent.read_text(encoding='utf-8')
            baseline_agent.write_text(text.replace('  bash: ask','  bash: allow'),encoding='utf-8')
        copied=[]
        for n,img in enumerate(images,1):
            dst=project/'.k-slide-input'/f'{n:03d}{img.suffix.lower()}'
            shutil.copy2(img,dst); copied.append(dst)
        oc=find_opencode() or 'opencode'
        cmd=[oc,'run','--dir',str(project),'--command','k-slide','--format','default']
        cmd += [str(x.relative_to(project)) for x in copied]
        p=run(cmd,project)
        (out/'stdout.txt').write_text(p.stdout or '',encoding='utf-8')
        (out/'stderr.txt').write_text(p.stderr or '',encoding='utf-8')
        (out/'returncode.txt').write_text(str(p.returncode)+'\n')
        runs=sorted((project/'.k-slide-runs').glob('*'),key=lambda x:x.stat().st_mtime,reverse=True)
        if runs: shutil.copytree(runs[0],out/'artifacts')
        return p.returncode

def main():
    ap=argparse.ArgumentParser(description='Run immutable v6 and candidate side by side.')
    ap.add_argument('case_id'); ap.add_argument('images',nargs='+'); ap.add_argument('--results-dir',default=str(ROOT/'evaluation/results'))
    a=ap.parse_args(); images=[Path(x).resolve() for x in a.images]
    for p in images:
        if not p.is_file(): raise SystemExit(f'Missing image: {p}')
    stamp=time.strftime('%Y%m%d-%H%M%S'); dest=Path(a.results_dir)/a.case_id/stamp; dest.mkdir(parents=True)
    b=dest/'baseline-v6'; c=dest/'candidate'; b.mkdir(); c.mkdir()
    rc_b=baseline(images,b); rc_c=candidate_normal(images,c); rc_e=candidate_eval(images,c)
    labels=['A','B']; random.shuffle(labels); mapping={labels[0]:'baseline-v6',labels[1]:'candidate'}
    for label,source in mapping.items():
        src=b if source=='baseline-v6' else c
        report=''
        if source=='baseline-v6' and (src/'artifacts/05_final_report.md').exists(): report=(src/'artifacts/05_final_report.md').read_text(errors='replace')
        elif (src/'stdout.txt').exists(): report=(src/'stdout.txt').read_text(errors='replace')
        (dest/f'BLIND_OUTPUT_{label}.md').write_text(report,encoding='utf-8')
    (dest/'mapping.json').write_text(json.dumps(mapping,indent=2)+'\n')
    (dest/'PAIR_REVIEW.md').write_text(f'''# Blind paired review — {a.case_id}

Review `BLIND_OUTPUT_A.md` and `BLIND_OUTPUT_B.md` without opening `mapping.json` first.

Score each output from 0–5 on:

| Dimension | A | B | Notes |
|---|---:|---:|---|
| Material element coverage | | | |
| Silent omission avoidance | | | |
| Numeric/date/unit fidelity | | | |
| Cardinality fidelity | | | |
| Table structure fidelity | | | |
| Chart/diagram relationship fidelity | | | |
| Korean translation accuracy | | | |
| Natural English readability | | | |
| Separation of observed vs inferred | | | |
| Honest uncertainty | | | |
| Zero-Korean comprehension | | | |

Critical regression check:

- [ ] Neither output loses a significant number/date/unit.
- [ ] Neither output silently drops a material element.
- [ ] Neither output summarizes a visible table instead of reconstructing it.
- [ ] Neither output invents unsupported facts.

Preferred output: `A / B / tie`
Reviewer role: `Korean speaker / zero-Korean reader / technical reviewer`
Comments:
''',encoding='utf-8')
    summary={'case_id':a.case_id,'images':[str(x) for x in images],'baseline_returncode':rc_b,'candidate_returncode':rc_c,'candidate_eval_returncode':rc_e,'mapping_file':'mapping.json'}
    (dest/'run-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(dest)
    return 0 if rc_b==0 and rc_c==0 and rc_e==0 else 2
if __name__=='__main__': raise SystemExit(main())
