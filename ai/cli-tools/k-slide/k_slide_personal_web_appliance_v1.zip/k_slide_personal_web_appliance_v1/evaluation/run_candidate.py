#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from kslide_paths import find_opencode
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('images',nargs='+'); ap.add_argument('--output',required=True); ap.add_argument('--model'); a=ap.parse_args()
    oc=find_opencode() or 'opencode'
    cmd=[oc,'run','--dir',str(ROOT),'--command','k-slide-eval','--format','default']
    if a.model: cmd += ['--model',a.model]
    for img in a.images: cmd += ['--file',str(Path(img).resolve())]
    cmd += ['Return the strict K-Slide evidence ledger JSON for the attached slide image(s).']
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=900)
    raw=Path(a.output).with_suffix('.raw.txt'); raw.parent.mkdir(parents=True,exist_ok=True); raw.write_text((p.stdout or '')+'\nSTDERR:\n'+(p.stderr or ''),encoding='utf-8')
    if p.returncode: print(f'OpenCode failed ({p.returncode}); see {raw}',file=sys.stderr); return p.returncode
    ex=subprocess.run([sys.executable,str(ROOT/'evaluation/extract_json.py'),str(raw)],capture_output=True,text=True)
    if ex.returncode: print(ex.stderr,file=sys.stderr); return ex.returncode
    Path(a.output).write_text(ex.stdout,encoding='utf-8'); print(a.output); return 0
if __name__=='__main__': raise SystemExit(main())
