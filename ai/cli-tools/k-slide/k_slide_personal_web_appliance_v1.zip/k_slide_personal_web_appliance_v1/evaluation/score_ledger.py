#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re,sys
from pathlib import Path
NUM=re.compile(r'(?<![A-Za-z])[-+]?\d+(?:[.,]\d+)*(?:%|[A-Za-z₩$€¥℃°]+)?')
def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def score(d):
    slides=d.get('slides',[]); elems=[e for s in slides for e in s.get('elements',[])]
    material=[e for e in elems if e.get('materiality') in ('high','medium')]
    represented=[e for e in material if e.get('represented')]
    tables=[t for s in slides for t in s.get('tables',[])]; charts=[c for s in slides for c in s.get('charts',[])]; rel=[r for s in slides for r in s.get('relations',[])]
    nums=[n for s in slides for n in s.get('numbers',[])]
    unresolved=[u for s in slides for u in s.get('unresolved',[])]
    metrics={
      'material_element_coverage': len(represented)/len(material) if material else 1.0,
      'table_representation': sum(bool(t.get('represented')) for t in tables)/len(tables) if tables else 1.0,
      'chart_representation': sum(bool(c.get('represented')) for c in charts)/len(charts) if charts else 1.0,
      'relation_representation': sum(bool(r.get('represented')) for r in rel)/len(rel) if rel else 1.0,
      'numeric_inventory_count': len(nums),
      'unresolved_count': len(unresolved),
      'verification_pass_rate': sum(bool(v) for k,v in d.get('verification',{}).items() if k!='exceptions' and isinstance(v,bool))/6,
    }
    critical=(metrics['material_element_coverage']>=.99 and metrics['table_representation']>=.98 and metrics['relation_representation']>=.98 and d.get('verification',{}).get('numeric_fidelity') is True and d.get('verification',{}).get('cardinality_fidelity') is True)
    return {'status':d.get('status'),'metrics':metrics,'release_gate_pass':critical}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('ledger'); ap.add_argument('--output'); a=ap.parse_args(); out=score(load(a.ledger)); txt=json.dumps(out,indent=2)
    if a.output: Path(a.output).write_text(txt+'\n')
    print(txt); return 0 if out['release_gate_pass'] else 2
if __name__=='__main__': raise SystemExit(main())
