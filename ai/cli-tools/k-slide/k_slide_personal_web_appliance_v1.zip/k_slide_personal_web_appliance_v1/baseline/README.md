# Immutable K-Slide v6 baseline

This directory preserves the previously approved K-Slide v6 package exactly as the non-regression baseline.

- File: `korean_slide_gemma_opencode_pack_v6.zip`
- SHA-256: `bc7ff0bd0a76fdf781f38bf19c82f545ae58a0db226baf31af554556f93fac00`

Do not edit or replace this archive. Candidate prompts and runtime files live outside `baseline/`.
The evaluation harness compares candidate results with this baseline before promotion.
