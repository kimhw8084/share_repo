#!/usr/bin/env python3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
t=(ROOT/'evaluation/run_ab.py').read_text()
for x in ['BASELINE_ZIP','BLIND_OUTPUT_A.md','PAIR_REVIEW.md','mapping.json','candidate_eval','bash: allow']:
    assert x in t,x
assert '--auto' not in t, 'unsupported --auto flag must not be used'
print('test_ab_runner_static PASS')
