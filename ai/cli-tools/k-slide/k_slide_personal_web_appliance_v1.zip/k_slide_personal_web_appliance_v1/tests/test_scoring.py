#!/usr/bin/env python3
import json,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def run(name):
 p=subprocess.run([sys.executable,str(ROOT/'evaluation/score_ledger.py'),str(ROOT/'tests/fixtures'/name)],capture_output=True,text=True)
 return p.returncode,json.loads(p.stdout)
rc,d=run('complete_ledger.json'); assert rc==0 and d['release_gate_pass'] is True
rc,d=run('incomplete_ledger.json'); assert rc==2 and d['release_gate_pass'] is False
print('test_scoring PASS')
