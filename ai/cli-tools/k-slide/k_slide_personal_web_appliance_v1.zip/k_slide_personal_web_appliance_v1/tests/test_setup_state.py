#!/usr/bin/env python3
from __future__ import annotations
import json, os, subprocess, tempfile, textwrap
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    runtime=ROOT/'.k-slide/runtime'; runtime.mkdir(parents=True,exist_ok=True)
    state=runtime/'setup_state.json'; old=state.read_bytes() if state.exists() else None
    with tempfile.TemporaryDirectory() as td:
        oc=Path(td)/'opencode'
        oc.write_text('#!/usr/bin/env bash\n[ "${1:-}" = "--version" ] && echo 1.18.4 || echo ok\n'); oc.chmod(0o755)
        env=os.environ.copy(); env['PATH']=td+os.pathsep+env.get('PATH','')
        try:
            p=subprocess.run(['python3',str(ROOT/'scripts/setup_state.py'),'write'],cwd=ROOT,env=env,capture_output=True,text=True)
            assert p.returncode==0,(p.stdout,p.stderr)
            p=subprocess.run(['python3',str(ROOT/'scripts/setup_state.py'),'check'],cwd=ROOT,env=env)
            assert p.returncode==0
            data=json.loads(state.read_text()); data['package_version']='drift'; state.write_text(json.dumps(data))
            p=subprocess.run(['python3',str(ROOT/'scripts/setup_state.py'),'check'],cwd=ROOT,env=env)
            assert p.returncode==1
        finally:
            if old is None: state.unlink(missing_ok=True)
            else: state.write_bytes(old)
    print('test_setup_state PASS')
    return 0
if __name__=='__main__': raise SystemExit(main())
