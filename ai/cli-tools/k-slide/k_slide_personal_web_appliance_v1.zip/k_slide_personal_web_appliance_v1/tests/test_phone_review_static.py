#!/usr/bin/env python3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
t=(ROOT/'evaluation/phone_review.py').read_text()
for token in ['KSR1','PHONE_REPLY.txt','mapping.json','critical_regression']:
    assert token in t, token
print('test_phone_review_static PASS')
