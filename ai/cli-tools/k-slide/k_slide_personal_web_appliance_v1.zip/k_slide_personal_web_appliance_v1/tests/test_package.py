#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
required=['opencode.json','AGENTS.md','.opencode/agents/k-slide.md','.opencode/commands/k-slide.md','setup-k-slide','start-k-slide','doctor-k-slide','evaluation/schemas/evidence-ledger.schema.json','baseline/korean_slide_gemma_opencode_pack_v6.zip']
missing=[p for p in required if not (ROOT/p).exists()]
assert not missing,missing
expected=(ROOT/'baseline/SHA256SUMS.txt').read_text().split()[0]
actual=hashlib.sha256((ROOT/'baseline/korean_slide_gemma_opencode_pack_v6.zip').read_bytes()).hexdigest()
assert actual==expected,(actual,expected)
for p in ['setup-k-slide','start-k-slide','stop-k-slide','status-k-slide','doctor-k-slide','update-k-slide']:
    assert (ROOT/p).stat().st_mode & 0o111,p
print('test_package PASS')
