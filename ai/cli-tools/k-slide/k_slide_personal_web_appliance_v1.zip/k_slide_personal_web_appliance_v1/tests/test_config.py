#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
c=json.loads((ROOT/'opencode.json').read_text())
assert c['default_agent']=='k-slide'
assert c['share']=='disabled'
assert c['subagent_depth']==0
for k in ['bash','edit','task','webfetch','websearch','skill']:
 assert c['permission'][k]=='deny',k
assert c['attachment']['image']['max_width']>=3000
print('test_config PASS')
