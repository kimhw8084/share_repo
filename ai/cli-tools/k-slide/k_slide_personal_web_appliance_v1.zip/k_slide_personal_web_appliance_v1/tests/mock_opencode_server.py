#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import argparse, json
class H(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/global/health':
            b=json.dumps({'healthy':True,'version':'mock-1.0'}).encode()
            self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
        else:
            b=b'mock opencode web'; self.send_response(200); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def log_message(self,*args): pass
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--port',type=int,required=True); a=p.parse_args(); ThreadingHTTPServer(('127.0.0.1',a.port),H).serve_forever()
