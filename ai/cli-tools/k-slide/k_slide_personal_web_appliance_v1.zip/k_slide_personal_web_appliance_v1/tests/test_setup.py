#!/usr/bin/env python3
from __future__ import annotations
import os, subprocess, sys, tempfile, textwrap
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def make_oc(path:Path, version:str):
    path.write_text(textwrap.dedent(f'''#!/usr/bin/env bash
case "${{1:-}}" in
 --version) echo {version} ;;
 models) echo corporate/gemma-mock ;;
 *) echo ok ;;
esac
'''))
    path.chmod(0o755)

def main():
    with tempfile.TemporaryDirectory() as td:
        b=Path(td); make_oc(b/'opencode','1.18.4')
        for n in ['node','npm']:
            p=b/n; p.write_text('#!/usr/bin/env bash\necho mock\n'); p.chmod(0o755)
        env=os.environ.copy(); env['PATH']=str(b)+os.pathsep+env.get('PATH',''); env['KSLIDE_SETUP_SKIP_SELF_TEST']='1'
        p=subprocess.run([str(ROOT/'setup-k-slide')],cwd=ROOT,env=env,capture_output=True,text=True,timeout=120)
        assert p.returncode==0,(p.stdout,p.stderr)
        assert 'Setup complete' in p.stdout
    print('test_setup PASS')
    return 0
if __name__=='__main__': raise SystemExit(main())
