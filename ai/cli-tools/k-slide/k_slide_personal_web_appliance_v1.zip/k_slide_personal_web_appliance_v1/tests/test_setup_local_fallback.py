#!/usr/bin/env python3
from __future__ import annotations
import os, shutil, subprocess, tempfile, textwrap
from pathlib import Path
SRC=Path(__file__).resolve().parents[1]

def main():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/'package'; root.mkdir()
        for name in ['setup-k-slide','OPENCODE_MIN_VERSION','OPENCODE_TESTED_VERSION','ACTIVE_PROMPT_VERSION','VERSION']:
            shutil.copy2(SRC/name,root/name)
        shutil.copytree(SRC/'scripts',root/'scripts',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        shutil.copytree(SRC/'config',root/'config')
        (root/'.opencode/agents').mkdir(parents=True)
        (root/'.opencode/skills/korean-slide-comprehension').mkdir(parents=True)
        bindir=Path(td)/'bin'; bindir.mkdir()
        node=bindir/'node'; node.write_text('#!/usr/bin/env bash\necho v20.0.0\n'); node.chmod(0o755)
        npm=bindir/'npm'
        npm.write_text(textwrap.dedent('''#!/usr/bin/env bash
set -e
if [ "${1:-}" = "install" ] && [ "${2:-}" = "-g" ]; then
  exit 77
fi
prefix=""
while [ "$#" -gt 0 ]; do
  if [ "$1" = "--prefix" ]; then prefix="$2"; shift 2; continue; fi
  shift
done
[ -n "$prefix" ] || exit 2
mkdir -p "$prefix/node_modules/.bin"
cat > "$prefix/node_modules/.bin/opencode" <<'EOF'
#!/usr/bin/env bash
case "${1:-}" in
  --version) echo 1.18.4 ;;
  models) echo corporate/gemma-mock ;;
  *) echo ok ;;
esac
EOF
chmod +x "$prefix/node_modules/.bin/opencode"
'''))
        npm.chmod(0o755)
        env=os.environ.copy()
        env['PATH']=str(bindir)+os.pathsep+'/usr/bin:/bin'
        env['KSLIDE_SETUP_SKIP_SELF_TEST']='1'
        env['KSLIDE_SETUP_SKIP_DOCTOR']='1'
        p=subprocess.run([str(root/'setup-k-slide')],cwd=root,env=env,capture_output=True,text=True,timeout=120)
        assert p.returncode==0,(p.stdout,p.stderr)
        local=root/'.k-slide/tools/node_modules/.bin/opencode'
        assert local.is_file() and os.access(local,os.X_OK),local
        assert 'installing privately' in p.stdout.lower(),p.stdout
    print('test_setup_local_fallback PASS')
    return 0
if __name__=='__main__': raise SystemExit(main())
