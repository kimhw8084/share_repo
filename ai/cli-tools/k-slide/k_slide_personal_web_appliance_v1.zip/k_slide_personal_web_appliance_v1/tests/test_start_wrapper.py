#!/usr/bin/env python3
from __future__ import annotations
import subprocess, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        (root/'scripts').mkdir()
        (root/'start-k-slide').write_text((ROOT/'start-k-slide').read_text()); (root/'start-k-slide').chmod(0o755)
        (root/'scripts/setup_state.py').write_text('#!/usr/bin/env python3\nraise SystemExit(1)\n'); (root/'scripts/setup_state.py').chmod(0o755)
        (root/'setup-k-slide').write_text('#!/usr/bin/env bash\necho setup >> flow.txt\n'); (root/'setup-k-slide').chmod(0o755)
        (root/'scripts/web_runtime.py').write_text('#!/usr/bin/env python3\nfrom pathlib import Path\nPath("flow.txt").open("a").write("runtime\\n")\n'); (root/'scripts/web_runtime.py').chmod(0o755)
        p=subprocess.run([str(root/'start-k-slide')],cwd=root,capture_output=True,text=True)
        assert p.returncode==0,(p.stdout,p.stderr)
        assert (root/'flow.txt').read_text().splitlines()==['setup','runtime']
    print('test_start_wrapper PASS')
    return 0
if __name__=='__main__': raise SystemExit(main())
