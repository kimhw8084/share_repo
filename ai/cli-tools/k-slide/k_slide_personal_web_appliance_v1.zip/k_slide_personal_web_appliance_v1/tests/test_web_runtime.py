#!/usr/bin/env python3
from __future__ import annotations
import os, socket, subprocess, sys, tempfile, textwrap, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def free_port():
    s=socket.socket(); s.bind(('127.0.0.1',0)); p=s.getsockname()[1]; s.close(); return p

def main():
    with tempfile.TemporaryDirectory() as td:
        b=Path(td); oc=b/'opencode'
        oc.write_text(textwrap.dedent(f'''#!/usr/bin/env bash
set -e
case "${{1:-}}" in
  --version) echo 1.18.4 ;;
  models) echo corporate/gemma-mock ;;
  web)
    shift
    PORT=""
    while [ "$#" -gt 0 ]; do
      case "$1" in --port) PORT="$2"; shift 2;; --hostname) shift 2;; *) shift;; esac
    done
    exec "{sys.executable}" "{ROOT/'tests/mock_opencode_server.py'}" --port "$PORT"
    ;;
  *) echo unsupported mock command >&2; exit 2;;
esac
'''))
        oc.chmod(0o755)
        env=os.environ.copy(); env['PATH']=str(b)+os.pathsep+env.get('PATH',''); env['KSLIDE_PORT']=str(free_port())
        # clean stale process files
        subprocess.run([sys.executable,str(ROOT/'scripts/web_runtime.py'),'stop'],cwd=ROOT,env=env,capture_output=True)
        p=subprocess.run([sys.executable,str(ROOT/'scripts/web_runtime.py'),'start'],cwd=ROOT,env=env,capture_output=True,text=True,timeout=60)
        assert p.returncode==0,(p.stdout,p.stderr)
        assert 'K-SLIDE IS READY' in p.stdout,p.stdout
        s=subprocess.run([sys.executable,str(ROOT/'scripts/web_runtime.py'),'status'],cwd=ROOT,env=env,capture_output=True,text=True)
        assert s.returncode==0 and 'RUNNING' in s.stdout,s.stdout
        q=subprocess.run([sys.executable,str(ROOT/'scripts/web_runtime.py'),'stop'],cwd=ROOT,env=env,capture_output=True,text=True,timeout=30)
        assert q.returncode==0,q.stdout
        s2=subprocess.run([sys.executable,str(ROOT/'scripts/web_runtime.py'),'status'],cwd=ROOT,env=env,capture_output=True,text=True)
        assert s2.returncode!=0 and 'STOPPED' in s2.stdout,s2.stdout
    print('test_web_runtime PASS')
    return 0
if __name__=='__main__': raise SystemExit(main())
