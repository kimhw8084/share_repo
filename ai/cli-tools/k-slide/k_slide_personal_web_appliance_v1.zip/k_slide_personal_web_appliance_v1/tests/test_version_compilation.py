#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
version=(ROOT/'ACTIVE_PROMPT_VERSION').read_text().strip()
source=(ROOT/'config/versions'/version/'SKILL_SOURCE.md').read_text()
header=(ROOT/'config/AGENT_FRONTMATTER.txt').read_text()
compiled=(ROOT/'config/versions'/version/'k-slide.md').read_text()
active=(ROOT/'.opencode/agents/k-slide.md').read_text()
assert compiled==header+source
assert active==compiled
print('test_version_compilation PASS')
