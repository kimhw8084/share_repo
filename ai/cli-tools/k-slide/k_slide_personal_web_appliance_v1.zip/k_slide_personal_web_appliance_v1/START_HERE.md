# Start here — K-Slide

## First use

Open this repository in your corporate cloud VS Code, then run exactly:

```bash
./start-k-slide
```

When VS Code reports a forwarded port, open it in the browser.

Then:

1. Paste or attach one or more Korean slide screenshots.
2. Press Enter. You do not need to type a command.
3. Read the complete English reconstruction.
4. Ask follow-up questions in the same session.

For a very dense or critical slide, type `/k-slide-deep` after attaching it.

## If it does not start

```bash
./doctor-k-slide
```

Send only the failed lines to the maintainer.
