#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
python3 -m compileall -q scripts evaluation tests
python3 tests/test_package.py
python3 tests/test_config.py
python3 tests/test_prompt_contract.py
python3 tests/test_scoring.py
python3 tests/test_web_runtime.py
python3 tests/test_ab_runner_static.py
python3 tests/test_version_compilation.py
python3 tests/test_setup.py
python3 tests/test_setup_local_fallback.py
python3 tests/test_setup_state.py
python3 tests/test_start_wrapper.py
python3 tests/test_phone_review_static.py
for f in setup-k-slide start-k-slide stop-k-slide status-k-slide doctor-k-slide update-k-slide scripts/*.sh; do
  [ -e "$f" ] && bash -n "$f"
done
python3 scripts/apply_version.py --ensure
printf '
ALL K-SLIDE STATIC AND DETERMINISTIC TESTS PASSED
'
