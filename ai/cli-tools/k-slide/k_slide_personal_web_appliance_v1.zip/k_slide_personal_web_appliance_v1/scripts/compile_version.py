#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
VERSIONS=ROOT/'config/versions'
HEADER=(ROOT/'config/AGENT_FRONTMATTER.txt').read_text(encoding='utf-8')
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('version'); a=ap.parse_args()
    d=VERSIONS/a.version; src=d/'SKILL_SOURCE.md'; out=d/'k-slide.md'
    if not src.is_file(): raise SystemExit(f'Missing {src}')
    out.write_text(HEADER+src.read_text(encoding='utf-8'),encoding='utf-8')
    print(f'Compiled {out}')
    return 0
if __name__=='__main__': raise SystemExit(main())
