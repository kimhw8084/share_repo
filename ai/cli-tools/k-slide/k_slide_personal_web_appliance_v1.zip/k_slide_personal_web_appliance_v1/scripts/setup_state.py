#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re, subprocess
from pathlib import Path
from kslide_paths import find_opencode
ROOT=Path(__file__).resolve().parents[1]
STATE=ROOT/'.k-slide/runtime/setup_state.json'

def sha(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else ''

def vt(value:str)->tuple[int,...]:
    return tuple(int(x) for x in value.split('.'))

def opencode_version()->str:
    oc=find_opencode()
    if not oc: return ''
    try:
        p=subprocess.run([oc,'--version'],capture_output=True,text=True,timeout=15)
        m=re.search(r'(\d+\.\d+\.\d+)',(p.stdout or '')+(p.stderr or ''))
        return m.group(1) if p.returncode==0 and m else ''
    except Exception:
        return ''

def expected()->dict[str,str]:
    return {
        'package_version': (ROOT/'VERSION').read_text().strip(),
        'active_prompt_version': (ROOT/'ACTIVE_PROMPT_VERSION').read_text().strip(),
        'agent_sha256': sha(ROOT/'.opencode/agents/k-slide.md'),
        'minimum_opencode_version': (ROOT/'OPENCODE_MIN_VERSION').read_text().strip(),
        'tested_opencode_version': (ROOT/'OPENCODE_TESTED_VERSION').read_text().strip(),
    }

def check(verbose:bool=False)->bool:
    exp=expected(); current=opencode_version()
    if not current:
        if verbose: print('setup required: OpenCode not found')
        return False
    if vt(current)<vt(exp['minimum_opencode_version']):
        if verbose: print(f'setup required: OpenCode {current} is below {exp["minimum_opencode_version"]}')
        return False
    try: state=json.loads(STATE.read_text())
    except Exception:
        if verbose: print('setup required: setup state missing')
        return False
    for key in ['package_version','active_prompt_version','agent_sha256']:
        if state.get(key)!=exp[key]:
            if verbose: print(f'setup required: {key} changed')
            return False
    if verbose: print(f'setup current: package {exp["package_version"]}, OpenCode {current}')
    return True

def write()->None:
    data=expected(); data['actual_opencode_version']=opencode_version()
    STATE.parent.mkdir(parents=True,exist_ok=True)
    STATE.write_text(json.dumps(data,indent=2)+'\n')
    print(f'Setup state recorded: {STATE}')

def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument('action',choices=['check','write']); ap.add_argument('--verbose',action='store_true'); a=ap.parse_args()
    if a.action=='write': write(); return 0
    return 0 if check(a.verbose) else 1
if __name__=='__main__': raise SystemExit(main())
