#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, shutil, stat, subprocess, sys, tempfile, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
EXCLUDES={'.git','.k-slide','__pycache__','.pytest_cache','results'}

def include(path:Path)->bool:
    rel=path.relative_to(ROOT)
    return not any(part in EXCLUDES or part.endswith('.pyc') for part in rel.parts)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',default=str(ROOT.parent/'k_slide_personal_web_appliance_v1.zip')); a=ap.parse_args()
    subprocess.run([str(ROOT/'scripts/self_test.sh')],cwd=ROOT,check=True)
    out=Path(a.output).resolve(); out.unlink(missing_ok=True)
    prefix=ROOT.name+'/'
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(ROOT.rglob('*')):
            if not include(p): continue
            rel=prefix+p.relative_to(ROOT).as_posix()
            if p.is_dir():
                info=zipfile.ZipInfo(rel.rstrip('/')+'/'); info.external_attr=(0o755|stat.S_IFDIR)<<16; z.writestr(info,b'')
            elif p.is_file():
                info=zipfile.ZipInfo.from_file(p,arcname=rel)
                mode=0o755 if os.access(p,os.X_OK) else 0o644
                info.external_attr=(mode|stat.S_IFREG)<<16
                info.compress_type=zipfile.ZIP_DEFLATED
                z.writestr(info,p.read_bytes())
    digest=hashlib.sha256(out.read_bytes()).hexdigest()
    (out.with_suffix(out.suffix+'.sha256')).write_text(f'{digest}  {out.name}\n')
    with tempfile.TemporaryDirectory() as td:
        with zipfile.ZipFile(out) as z: z.extractall(td)
        extracted=Path(td)/ROOT.name
        # Python's extractall may not preserve modes on every platform, so validate metadata and content separately.
        with zipfile.ZipFile(out) as z:
            for name in [prefix+'setup-k-slide',prefix+'start-k-slide',prefix+'scripts/self_test.sh']:
                mode=(z.getinfo(name).external_attr>>16)&0o777
                if mode&0o111==0: raise SystemExit(f'Executable mode missing in zip: {name}')
        p=subprocess.run([sys.executable,str(extracted/'tests/test_package.py')],cwd=extracted,capture_output=True,text=True)
        if p.returncode: raise SystemExit(p.stdout+p.stderr)
    print(out); print(digest); return 0
if __name__=='__main__': raise SystemExit(main())
