from __future__ import annotations
import os, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
LOCAL=ROOT/'.k-slide/tools/node_modules/.bin/opencode'
def find_opencode()->str|None:
    explicit=os.getenv('KSLIDE_OPENCODE')
    if explicit and Path(explicit).is_file(): return str(Path(explicit).resolve())
    if LOCAL.is_file(): return str(LOCAL)
    return shutil.which('opencode')
