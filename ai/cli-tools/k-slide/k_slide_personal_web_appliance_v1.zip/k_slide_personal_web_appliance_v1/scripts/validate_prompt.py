#!/usr/bin/env python3
from __future__ import annotations
import json, re, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
AGENT = ROOT / ".opencode" / "agents" / "k-slide.md"
CONTRACT = json.loads((ROOT / "evaluation" / "prompt_contract.json").read_text(encoding="utf-8"))

def main() -> int:
    text = AGENT.read_text(encoding="utf-8")
    failures=[]
    for phrase in CONTRACT["required_phrases"]:
        if phrase not in text: failures.append(f"missing required phrase: {phrase}")
    for phrase in CONTRACT["forbidden_runtime_capabilities"]:
        if phrase in text: failures.append(f"forbidden capability: {phrase}")
    if not text.startswith("---\n"): failures.append("agent frontmatter missing")
    if "mode: primary" not in text: failures.append("agent is not primary")
    if re.search(r"(?m)^\s*temperature:\s*(0\.[3-9]|1)", text): failures.append("temperature too high")
    if failures:
        print("PROMPT VALIDATION FAILED")
        for f in failures: print("-", f)
        return 1
    print("PROMPT VALIDATION PASS")
    return 0
if __name__ == "__main__": raise SystemExit(main())
