#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, shutil, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ACTIVE_FILE = ROOT / "ACTIVE_PROMPT_VERSION"
VERSIONS = ROOT / "config" / "versions"
AGENT_DST = ROOT / ".opencode" / "agents" / "k-slide.md"
SKILL_DST = ROOT / ".opencode" / "skills" / "korean-slide-comprehension" / "SKILL.md"

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def validate(version: str) -> tuple[Path, Path]:
    src_dir = VERSIONS / version
    skill = src_dir / "SKILL_SOURCE.md"
    agent = src_dir / "k-slide.md"
    if not skill.is_file() or not agent.is_file():
        raise SystemExit(f"Version {version!r} is incomplete: expected SKILL_SOURCE.md and k-slide.md")
    text = agent.read_text(encoding="utf-8")
    required = ["mode: primary", "bash: deny", "edit: deny", "task:", '"*": deny', "Table reconstruction law", "Cardinality law"]
    missing = [x for x in required if x not in text]
    if missing:
        raise SystemExit(f"Version {version!r} failed prompt validation: missing {missing}")
    return skill, agent

def apply(version: str) -> None:
    skill, agent = validate(version)
    AGENT_DST.parent.mkdir(parents=True, exist_ok=True)
    SKILL_DST.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(agent, AGENT_DST)
    SKILL_DST.write_text(
        "---\nname: korean-slide-comprehension\ndescription: Canonical evidence-grounded Korean slide comprehension contract.\n---\n\n"
        f"Active version: `{version}`\n\n"
        "The compiled primary agent embeds the complete active contract directly to avoid a runtime skill-tool call.\n",
        encoding="utf-8",
    )
    ACTIVE_FILE.write_text(version + "\n", encoding="utf-8")
    manifest = {
        "version": version,
        "agent_sha256": sha(AGENT_DST),
        "source_skill_sha256": sha(skill),
    }
    (ROOT / ".k-slide" / "runtime").mkdir(parents=True, exist_ok=True)
    (ROOT / ".k-slide" / "runtime" / "active_prompt.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")
    print(f"Activated K-Slide prompt version: {version}")
    print(f"Agent SHA-256: {manifest['agent_sha256']}")

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("version", nargs="?")
    parser.add_argument("--ensure", action="store_true")
    args = parser.parse_args()
    version = args.version or ACTIVE_FILE.read_text(encoding="utf-8").strip()
    skill, agent = validate(version)
    if args.ensure and AGENT_DST.is_file() and sha(AGENT_DST) == sha(agent):
        print(f"K-Slide prompt already active: {version}")
        return 0
    apply(version)
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
