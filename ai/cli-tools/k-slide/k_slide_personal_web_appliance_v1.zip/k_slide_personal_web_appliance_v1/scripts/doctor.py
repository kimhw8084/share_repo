#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, re, shutil, socket, subprocess, sys
from kslide_paths import find_opencode
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def cmd(args):
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=20)
        return p.returncode,(p.stdout or p.stderr).strip()
    except Exception as e: return 99,str(e)

def main():
    checks=[]
    def add(name,ok,detail): checks.append((name,ok,detail))
    add("repository root", (ROOT/'opencode.json').is_file(), str(ROOT))
    oc=find_opencode(); add("opencode executable", bool(oc), oc or 'not found')
    if oc:
        rc,out=cmd([oc,'--version'])
        match=re.search(r'(\d+\.\d+\.\d+)',out)
        current=match.group(1) if match else ''
        minimum=(ROOT/'OPENCODE_MIN_VERSION').read_text().strip()
        tested=(ROOT/'OPENCODE_TESTED_VERSION').read_text().strip()
        def vt(v): return tuple(int(x) for x in v.split('.'))
        secure=bool(current) and vt(current)>=vt(minimum)
        detail=f'{out} | minimum secure {minimum} | package tested {tested}'
        add("opencode security version", rc==0 and secure, detail)
        if current and current != tested:
            add("opencode tested-version alignment", True, f'{current} differs from tested {tested}; allowed, but regression smoke testing is recommended')
        rc,out=cmd([oc,'models']); add("corporate model configuration", rc==0, 'models available' if rc==0 else out[-300:])
    add("active agent", (ROOT/'.opencode/agents/k-slide.md').is_file(), '.opencode/agents/k-slide.md')
    add("share disabled", '"share": "disabled"' in (ROOT/'opencode.json').read_text(), 'opencode.json')
    rc=subprocess.run([sys.executable,str(ROOT/'scripts/validate_prompt.py')],capture_output=True,text=True).returncode
    add("prompt contract", rc==0, 'pass' if rc==0 else 'failed')
    baseline=ROOT/'baseline/korean_slide_gemma_opencode_pack_v6.zip'
    expected=(ROOT/'baseline/SHA256SUMS.txt').read_text().split()[0]
    actual=hashlib.sha256(baseline.read_bytes()).hexdigest() if baseline.exists() else ''
    add("immutable v6 baseline", actual==expected, actual or 'missing')
    print("\nK-SLIDE DOCTOR\n")
    for n,ok,d in checks: print(f"[{'PASS' if ok else 'FAIL'}] {n}: {d}")
    failed=[x for x in checks if not x[1]]
    print(f"\nResult: {'READY' if not failed else 'NOT READY'} ({len(checks)-len(failed)}/{len(checks)} checks passed)")
    return 0 if not failed else 1
if __name__=='__main__': raise SystemExit(main())
