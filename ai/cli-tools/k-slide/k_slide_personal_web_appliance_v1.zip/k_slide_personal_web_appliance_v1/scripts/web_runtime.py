#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, signal, socket, subprocess, sys, time, urllib.request
from kslide_paths import find_opencode
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUNTIME=ROOT/'.k-slide/runtime'; RUNTIME.mkdir(parents=True,exist_ok=True)
PID=RUNTIME/'web.pid'; META=RUNTIME/'web.json'; LOG=RUNTIME/'web.log'

def alive(pid:int)->bool:
    try: os.kill(pid,0); return True
    except OSError: return False

def choose_port(preferred:int)->int:
    for p in range(preferred,preferred+100):
        with socket.socket() as s:
            try: s.bind(('127.0.0.1',p)); return p
            except OSError: pass
    raise RuntimeError('No free port found')

def health(port:int)->bool:
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/global/health',timeout=1) as r:
            return 200 <= r.status < 300
    except Exception: return False

def read_meta():
    try: return json.loads(META.read_text())
    except Exception: return {}

def start(foreground=False):
    if PID.exists():
        try:
            p=int(PID.read_text().strip())
            if alive(p):
                m=read_meta(); print(f"K-Slide is already running at {m.get('url','unknown')} (PID {p})"); return 0
        except Exception: pass
    subprocess.run([sys.executable,str(ROOT/'scripts/apply_version.py'),'--ensure'],check=True)
    if subprocess.run([sys.executable,str(ROOT/'scripts/doctor.py')]).returncode != 0:
        print('\nFix the failed doctor checks before starting.'); return 1
    oc=find_opencode()
    if not oc: print('OpenCode is not installed or not in PATH.'); return 1
    port=choose_port(int(os.getenv('KSLIDE_PORT','4096')))
    host=os.getenv('KSLIDE_HOST','127.0.0.1')
    env=os.environ.copy()
    current=env.get('NO_PROXY') or env.get('no_proxy') or ''
    parts=[x for x in current.split(',') if x]
    for x in ['localhost','127.0.0.1']:
        if x not in parts: parts.append(x)
    env['NO_PROXY']=','.join(parts); env['no_proxy']=env['NO_PROXY']
    # Avoid the previously observed Basic-auth failure by default. Loopback binding plus the company's authenticated VS Code port forwarding is the expected boundary.
    if env.get('KSLIDE_USE_BASIC_AUTH','0') != '1':
        env.pop('OPENCODE_SERVER_PASSWORD',None); env.pop('OPENCODE_SERVER_USERNAME',None)
    cmd=[oc,'web','--hostname',host,'--port',str(port)]
    if foreground:
        print('Starting:', ' '.join(cmd)); return subprocess.call(cmd,cwd=ROOT,env=env)
    fh=LOG.open('a',encoding='utf-8')
    proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=fh,stderr=subprocess.STDOUT,start_new_session=True,text=True)
    PID.write_text(str(proc.pid)+'\n')
    url=f'http://127.0.0.1:{port}'
    META.write_text(json.dumps({'pid':proc.pid,'port':port,'host':host,'url':url,'started_at':time.time()},indent=2)+'\n')
    for _ in range(30):
        if proc.poll() is not None: break
        if health(port):
            print('\nK-SLIDE IS READY')
            print('================')
            print(f'Local URL: {url}')
            print('In cloud VS Code, open the Ports panel and open the forwarded URL for this port.')
            print('Then paste slide screenshot(s) and press Enter. No command is required.')
            print(f'Log: {LOG}')
            return 0
        time.sleep(1)
    print('K-Slide did not become healthy. Last log lines:')
    try: print('\n'.join(LOG.read_text(errors='replace').splitlines()[-30:]))
    except Exception: pass
    return 1

def stop():
    if not PID.exists(): print('K-Slide is not running.'); return 0
    try: p=int(PID.read_text().strip())
    except Exception: PID.unlink(missing_ok=True); return 0
    if alive(p):
        try: os.killpg(p,signal.SIGTERM)
        except Exception:
            try: os.kill(p,signal.SIGTERM)
            except Exception: pass
        for _ in range(20):
            if not alive(p): break
            time.sleep(.25)
        if alive(p):
            try: os.killpg(p,signal.SIGKILL)
            except Exception: pass
    PID.unlink(missing_ok=True); META.unlink(missing_ok=True)
    print('K-Slide stopped.'); return 0

def status():
    m=read_meta(); p=m.get('pid')
    if p and alive(int(p)):
        print(f"RUNNING | {m.get('url')} | PID {p} | health={'PASS' if health(int(m.get('port'))) else 'FAIL'}")
        return 0
    print('STOPPED'); return 1

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('action',choices=['start','stop','status']); ap.add_argument('--foreground',action='store_true'); a=ap.parse_args()
    return {'start':lambda:start(a.foreground),'stop':stop,'status':status}[a.action]()
if __name__=='__main__': raise SystemExit(main())
