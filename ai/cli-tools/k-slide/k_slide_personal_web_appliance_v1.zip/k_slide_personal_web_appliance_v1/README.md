# K-Slide Personal OpenCode Web Appliance

K-Slide turns Korean or Korean–English slide screenshots into complete, evidence-grounded English reconstructions for readers with zero Korean ability.

This package is designed for the proven corporate environment:

- source is distributed through the company GitLab repository;
- each employee has a personal filesystem and terminal through cloud VS Code;
- each employee runs OpenCode in their own workspace;
- users access OpenCode Web through the workspace’s authenticated port forwarding;
- the published FastAPI/Kubernetes runtime is not used because it blocks OpenCode, child processes, writable storage, internal ports, and multi-user identity.

## Employee quick start

First use and every later use:

```bash
./start-k-slide
```

The launcher automatically performs secure setup on the first run and after package updates.

Open the forwarded port, paste screenshots, and press Enter. K-Slide is the default agent; no command is necessary.

## Commands

```text
/k-slide       Complete analysis (normally automatic)
/k-slide-deep  Slower second-pass verification for dense or critical slides
/k-slide-help  One-screen help
```

## Lifecycle commands

```bash
./start-k-slide
./status-k-slide
./stop-k-slide
./doctor-k-slide
./update-k-slide
./scripts/self_test.sh
```

## Security defaults

- OpenCode binds to `127.0.0.1` by default.
- The company’s authenticated VS Code port-forwarding boundary is expected.
- OpenCode sharing is disabled.
- The K-Slide agent cannot use Bash, edit files, read the workspace, call subagents, search the web, or load arbitrary skills.
- Text visible inside images is treated as untrusted evidence, never as instructions.
- Model/provider configuration is inherited from the corporate environment and is not modified by this package.

## Non-regression

The previous K-Slide v6 package is preserved unchanged under `baseline/` with a SHA-256 checksum. Candidate changes are versioned under `config/versions/` and must pass deterministic tests and real-slide regression evaluation before promotion.

See:

- `docs/USER_GUIDE.md`
- `docs/ADMIN_GUIDE.md`
- `docs/SCIENTIFIC_BASIS.md`
- `docs/EVALUATION_METHOD.md`
- `docs/SECURITY.md`
- `docs/TROUBLESHOOTING.md`
