# Release Status

**Package stage:** Research candidate and personal-Web appliance foundation

**Active candidate:** `2026.07.22-research-candidate-1`

**Immutable control:** K-Slide v6, preserved under `baseline/`

## What is proven now

- Package structure, compilation, version activation and baseline integrity.
- Deterministic evidence-ledger scoring.
- Mock OpenCode Web launcher lifecycle.
- Setup logic, including project-local npm fallback.
- Denial of model tools and disabled sharing.
- Blind A/B test workflow.

## What must be proven in the corporate environment

- Real OpenCode Web image paste and multi-image behavior.
- Compatibility with the corporate Gemma model variant.
- Translation, table, chart and comprehension gains over v6.
- Latency and rate-limit effects.
- Fresh-clone usability by a nontechnical employee.

The candidate is intentionally **not declared superior to v6** until the real-slide gates pass. This is the mechanism that prevents regression.
