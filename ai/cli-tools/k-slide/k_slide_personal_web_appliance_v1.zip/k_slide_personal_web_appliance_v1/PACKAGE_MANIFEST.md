# Package manifest

- Package: K-Slide Personal OpenCode Web Appliance
- Version: 1.0.0
- Active prompt: 2026.07.22-research-candidate-1
- Immutable baseline SHA-256: `bc7ff0bd0a76fdf781f38bf19c82f545ae58a0db226baf31af554556f93fac00`

Key components:

- one-command personal OpenCode Web launcher;
- read-only/default K-Slide primary agent;
- complete and deep-verification commands;
- evidence-ledger evaluation mode and schema;
- immutable v6 baseline;
- prompt version activation and rollback;
- deterministic tests and scoring;
- employee, administrator, scientific, security, evaluation, and troubleshooting documentation.

Additional release controls:

- single-command automatic setup and secure-version gate;
- project-local npm fallback;
- setup drift detection;
- blind paired baseline/candidate runner;
- phone-friendly result handoff;
- research decision log and release checklist;
- clean release builder with executable-mode and extraction checks.
