# OpenCode Gemma Agents V1 — Compact Operational Edition

Optimized for Gemma 4 31B/32B-class local OpenCode use.

## Included

```text
AGENTS.md
.opencode/agents/*.md
.opencode/commands/*.md
config/*.example.json
reference/*.md
```

## Install per project

Copy into your repo root:

```bash
cp -R .opencode /path/to/your/repo/
cp AGENTS.md /path/to/your/repo/
mkdir -p /path/to/your/repo/config
cp config/*.example.json /path/to/your/repo/config/
```

## Install globally

```bash
mkdir -p ~/.config/opencode/agents
cp .opencode/agents/*.md ~/.config/opencode/agents/
```

Project install is recommended for company/repo-specific behavior.

## How to use now

Keep OpenCode primary agent as Build or Plan.

Implementation:

```text
Tab → Build
@script-worker ingest these Python/API/JSON scripts into this repo system
```

Review/planning:

```text
Tab → Plan
@code-reviewer review current diff
@security-auditor review this before production
```

All agents are `mode: subagent` for safe testing. They will not appear as Tab primary agents. Invoke with `@agent-name`.

`builder-router` is hidden and internal.

## Agents
- `automation-survey.md`
- `backend-builder.md`
- `builder-router.md`
- `code-reviewer.md`
- `dashboard-builder.md`
- `data-engineer.md`
- `debugger.md`
- `deployment-engineer.md`
- `docs-architect.md`
- `feature-worker.md`
- `file-transform-builder.md`
- `frontend-builder.md`
- `notification-builder.md`
- `powershell-builder.md`
- `python-builder.md`
- `scheduler-builder.md`
- `script-worker.md`
- `security-auditor.md`
- `sql-pro.md`
- `test-automator.md`
- `work-package-coordinator.md`
- `workflow-builder.md`

## Commands
- `/debug` → `debugger`
- `/docs` → `docs-architect`
- `/feature` → `feature-worker`
- `/release` → `deployment-engineer`
- `/review` → `code-reviewer`
- `/script` → `script-worker`
- `/security` → `security-auditor`
- `/sql` → `sql-pro`
- `/survey` → `automation-survey`
- `/sync` → `work-package-coordinator`
- `/testpack` → `test-automator`
