---
description: Use for independent compact code review.
agent: code-reviewer
---

Use for independent compact code review.

Follow target agent rules and repository `AGENTS.md`. Return compact output only.
