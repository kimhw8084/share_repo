---
description: Use to create validation checks or human test packets.
agent: test-automator
---

Use to create validation checks or human test packets.

Follow target agent rules and repository `AGENTS.md`. Return compact output only.
