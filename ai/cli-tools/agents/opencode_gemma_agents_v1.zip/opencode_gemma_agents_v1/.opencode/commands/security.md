---
description: Use for security, safety, blast-radius, secrets, mutation, or approval risk.
agent: security-auditor
---

Use for security, safety, blast-radius, secrets, mutation, or approval risk.

Follow target agent rules and repository `AGENTS.md`. Return compact output only.
