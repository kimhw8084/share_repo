---
description: Use for known script/file integration or edits.
agent: script-worker
---

Use for known script/file integration or edits.

Follow target agent rules and repository `AGENTS.md`. Return compact output only.
