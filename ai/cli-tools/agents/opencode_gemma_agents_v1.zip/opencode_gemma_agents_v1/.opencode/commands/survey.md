---
description: Use for new or unclear automation ideas. Survey process, ROI, risk, MVP, and builder route.
agent: automation-survey
---

Use for new or unclear automation ideas. Survey process, ROI, risk, MVP, and builder route.

Follow target agent rules and repository `AGENTS.md`. Return compact output only.
