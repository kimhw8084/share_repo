---
description: Use for SQL/report/data reconciliation or query work.
agent: sql-pro
---

Use for SQL/report/data reconciliation or query work.

Follow target agent rules and repository `AGENTS.md`. Return compact output only.
