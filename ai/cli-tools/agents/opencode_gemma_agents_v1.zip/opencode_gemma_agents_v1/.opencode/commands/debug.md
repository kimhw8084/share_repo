---
description: Use for errors, logs, wrong output, failed jobs, or root-cause work.
agent: debugger
---

Use for errors, logs, wrong output, failed jobs, or root-cause work.

Follow target agent rules and repository `AGENTS.md`. Return compact output only.
