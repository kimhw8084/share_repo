---
description: Use to sync work item, knowledge page, comments, artifacts, approvals, and feedback.
agent: work-package-coordinator
---

Use to sync work item, knowledge page, comments, artifacts, approvals, and feedback.

Follow target agent rules and repository `AGENTS.md`. Return compact output only.
