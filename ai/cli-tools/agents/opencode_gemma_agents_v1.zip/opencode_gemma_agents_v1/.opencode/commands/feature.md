---
description: Use for known feature work in an existing app/dashboard/API/service.
agent: feature-worker
---

Use for known feature work in an existing app/dashboard/API/service.

Follow target agent rules and repository `AGENTS.md`. Return compact output only.
