---
description: Use for runbooks, architecture notes, and Confluence-ready docs.
agent: docs-architect
---

Use for runbooks, architecture notes, and Confluence-ready docs.

Follow target agent rules and repository `AGENTS.md`. Return compact output only.
