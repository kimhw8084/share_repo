# Sourcing Notes

This compact package is based on the approved OpenCode Agent Workflow Map V1 design.

Public agent libraries were used as inspiration/backbone for common specialists:
- wshobson/agents
- VoltAgent/awesome-claude-code-subagents
- contains-studio/agents

This package is not a verbatim copy. It is a compact operational rewrite optimized for OpenCode, Gemma 4 31B/32B-class local use, strict output contracts, safe subagent operation, and company-adapter neutrality.
