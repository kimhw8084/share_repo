# Phase 10 Stage 3 Patch Contract

## P0 controls

1. A source quote is eligible only from an immutable source-native capture or a verifiable source-document span.
2. Provider-normalized, generated, synthetic, fixture-only, output-derived or analyst-created text cannot qualify as source evidence.
3. Every accepted evidence row must store its source-document hash, exact character span and deterministic semantic-support result.
4. Distinct events require event-specific evidence, timing, affected entities and a causal chain.
5. Company and security sensitivities require entity-specific evidence and an explicit causal bridge.
6. Excessive evidence-set overlap across distinct events or companies is a blocking defect.
7. Machine-readable falsifiers require monitor variable, comparison operator and numeric threshold.

## P1 controls

1. Research stopping requires a completed current-report freshness sweep.
2. Material geographies require explicit geography and local-language coverage.
3. Solar-class holdouts require at least 85% recall against the frozen authoritative-domain registry.
4. Role-lens quality in validation must reconcile to the canonical professional-lens table.

## Regression law

The sealed Stage 1 solar holdout must remain unchanged and must hard-fail under the patched controls. Passing the old bundle would be a validator false pass.
