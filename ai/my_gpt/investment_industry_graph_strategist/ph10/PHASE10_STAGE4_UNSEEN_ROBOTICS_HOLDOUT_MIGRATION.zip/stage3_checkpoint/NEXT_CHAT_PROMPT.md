We are inside the Industry Intelligence project. Use the active Project Sources as binding law.

Resume from PHASE10_STAGE3_EVIDENCE_GROUNDING_ANALYTICAL_SPECIFICITY.zip.

Accepted state:
- Phase 10 Stage 3 complete
- Engine version 0.10.0 frozen
- 68 tests passed, 0 failed
- Stage 1 solar holdout remains byte-for-byte sealed
- The patched engine correctly hard-fails the sealed holdout for source-native grounding and analytical-specificity defects
- World-class and unattended-production claims remain prohibited

Next task:
1. Verify the Stage 3 archive and checksum.
2. Do not modify engine 0.10.0 or the sealed solar holdout.
3. Execute a new unseen provider-backed holdout under the Stage 3 controls.
4. Require immutable source-native captures, exact extraction spans, semantic support, event/company-specific lineage, machine-readable falsifiers, freshness and geography/local-language sweeps, and >=85% recall against a frozen authoritative registry.
5. Produce a full bundle, browser-tested HTML, validation, manifest, pre/post-repair audit, and external human-review packet.
6. Do not claim world-class until genuine independent human reviewers complete the blind benchmark.
