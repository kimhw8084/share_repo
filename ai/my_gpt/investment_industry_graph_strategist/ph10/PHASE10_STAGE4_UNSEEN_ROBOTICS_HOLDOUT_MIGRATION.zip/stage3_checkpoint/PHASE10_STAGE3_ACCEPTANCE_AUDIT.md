# Phase 10 Stage 3 Acceptance Audit

## Verdict

Accepted as the mandatory evidence-grounding and analytical-specificity repair.

## Implemented controls

- Source-native capture contracts
- Generated/provider-normalized quotation blocking
- Exact extraction-span lineage
- Deterministic semantic-support checks
- Event-specific evidence and causal-chain enforcement
- Company/security-specific sensitivity lineage
- Evidence-overlap controls
- Machine-readable falsifier thresholds
- Frozen authoritative-domain recall benchmark
- Freshness and geography/local-language stopping gates
- Role-lens score reconciliation
- HTML exposure of grounding and recall diagnostics

## Tests

- Engine regression: 68 passed
- Failures: 0
- Clean wheel build: passed
- Source distribution build: passed
- Isolated wheel installation: passed
- Installed CLI smoke: passed
- Generated/provider-normalized capture: correctly ineligible
- Source-native capture and exact-span evidence: accepted

## Sealed regression

The Stage 1 solar holdout ZIP SHA-256 remains:
`52f98cb83e12c5c86bfe57dd868d9d7b5376b8b651fff0f9c08ed498aa938f41`

Under engine 0.10.0 it is now classified `fail_invalid` with hard failures for source-native grounding and analytical specificity. This is the intended result and closes the Stage 2 validator false pass.

## Remaining conditions

- No new unseen holdout has yet passed the patched controls.
- Genuine independent human expert review remains pending.
- Licensed full-text archives, calibrated forecasting and live valuation remain future capability work.
- World-class and unattended-production claims remain prohibited.
