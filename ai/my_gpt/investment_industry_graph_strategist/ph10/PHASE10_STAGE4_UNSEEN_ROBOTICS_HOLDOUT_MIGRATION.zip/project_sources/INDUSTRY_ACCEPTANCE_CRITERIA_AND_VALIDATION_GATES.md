# Industry Intelligence Engine — Acceptance Criteria and Validation Gates

**Document ID:** `INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md`  
**Project:** Industry Intelligence Engine  
**Phase:** Phase 4 — Acceptance Criteria and Validation Gates  
**Version:** 1.0.0  
**Status:** Canonical law after user approval  
**Authority:** This document governs acceptance, maturity labeling, hard-fail rules, score caps, validator expectations, and output-quality gates for every industry packet produced by the Industry Intelligence Engine.  
**Depends on:**

1. `INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md`
2. `INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md`
3. `INDUSTRY_RESEARCH_DATA_CONTRACT.md`
4. `INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md`

**Next phase after this document:** Phase 5 — `INDUSTRY_HTML_PACKET_TEMPLATE_SPEC.md`

---

## 1. Purpose

Phase 4 creates the canonical acceptance and validation law for the Industry Intelligence Engine. It defines when an output can be considered valid, seed-level, structured, investable, institutional, or world-class.

This document prevents the engine from producing cosmetically polished but analytically weak outputs. It blocks fake investment-grade labels, unsupported theses, hidden blanks, weak evidence, stale sources, broken simulations, random company lists, non-durable citations, and black-box scoring.

The central law is:

> Better incomplete and honest than polished and wrong.

No future HTML packet, simulation report, opportunity ranking, score, or mass-test benchmark may be treated as valid unless it complies with this document.

---

## 2. Acceptance philosophy

The engine must judge quality from structured data, not from persuasive writing. Prose quality, visual polish, or large source counts cannot compensate for missing data, missing evidence, broken joins, unsupported investment conclusions, stale current facts, or failed validators.

Every packet must disclose:

- maturity level
- score and score decomposition
- hard-fail status
- source/evidence coverage
- data-contract completeness
- role-lens coverage
- unresolved gaps
- unresolved conflicts
- stale-source risks
- weak-source dependencies
- simulation readiness
- top weaknesses
- next actions required to improve quality

A packet may be useful while incomplete, but it must be labeled honestly. A weak packet may be shown as Seed or Structured, but it must not be called investable, institutional, world-class, or benchmark-ready.

---

## 3. Maturity levels

The engine must use the following maturity levels.

| Level | Label | Meaning | Maximum normal score |
|---:|---|---|---:|
| 0 | Objective Only | Mission/spec exists, but no valid industry packet exists. | 19 |
| 1 | Seed | Preliminary sourced map with boundary, early source ledger, early evidence, basic value-chain sketch, and visible gaps. | 54 |
| 2 | Structured | Required core tables exist with meaningful population, source/evidence ledger, and field-level gap visibility. | 69 |
| 3 | Investable Research Candidate | Enough evidence, value chain, money flows, company/security exposure, catalysts, risks, falsifiers, and basic scenario logic to support investment research. | 79, low 80s only with exceptional evidence and no hard fails |
| 4 | Institutional-Grade Candidate / Institutional | Full structured dataset, strong evidence density, validated source coverage, simulation outputs, role-lens gates, opportunity ranking, and validation report. | 95 |
| 5 | World-Class / Benchmark-Ready | Repeatable, deeply sourced, cross-checked, role-complete, simulation-ready, regression-tested across benchmark industries, and reproducible. | 100 |

Higher levels require all lower-level gates. A packet cannot skip levels by having strong prose or attractive UI.

---

## 4. Minimum thresholds by maturity

Thresholds are adaptive by industry complexity, but maturity labels must remain honest.

### 4.1 Level 1 — Seed

Minimum expectations:

- clear industry boundary
- 8 credible sources, unless explicitly labeled very preliminary
- 30+ atomic evidence rows
- basic source ledger
- basic atomic evidence ledger
- basic value-chain map
- visible gap register
- no unsupported material investment claim

Seed output must not be described as investable or institutional.

### 4.2 Level 2 — Structured

Minimum expectations:

- 12+ credible sources
- 75+ atomic evidence rows
- required core tables present
- source ledger and evidence ledger connected to data-contract fields
- field-level blank/gap visibility
- basic value-chain nodes and edges
- preliminary company universe
- no hidden blocker gaps

Structured output may organize the research but is not automatically investable.

### 4.3 Level 3 — Investable Research Candidate

Minimum expectations:

- 12–15+ credible sources depending on industry complexity
- 100+ atomic evidence rows
- value-chain nodes and edges
- money-flow logic
- profit-pool direction or explicit gap
- company/security exposure map where public securities exist
- catalyst/event table
- risks and falsifiers
- basic scenario assumptions
- opportunity zones with evidence, downside, horizon, and confidence
- validation report

Level 3 can support investment research, but still may be below institutional quality.

### 4.4 Level 4 — Institutional

Minimum expectations:

- 15–20+ credible sources depending on industry complexity
- 250+ atomic evidence rows where feasible; if infeasible, limitation must be explicitly disclosed
- full Phase 2 data-contract structure
- source-family diversity
- triangulation for major metrics
- value-chain graph with money flows and profit pools
- company/security exposure validation
- financial sensitivity / valuation context where accessible
- quantamental signal inventory and feasibility assessment
- event/catalyst validation
- scenario assumptions and simulation outputs
- opportunity-zone ranking with upside, downside, catalyst, valuation context, risks, falsifiers, and confidence
- role-specific gates
- full validation report
- reproducible output bundle

Level 4 may be called institutional only if no hard fails exist.

### 4.5 Level 5 — World-Class / Benchmark-Ready

Minimum expectations:

- Level 4 compliance
- cross-source triangulation for major metrics and thesis-critical claims
- few/no major unresolved gaps
- role-complete coverage or explicit justified exceptions
- validated simulation formulas
- reproducible bundle with manifest
- benchmark proof across difficult industries
- regression-tested failure fixes
- stable score above 95 across repeated tests

A single strong packet cannot justify a 95+ “any industry” claim. That requires mass-test evidence.

---

## 5. Industry complexity adjustments

The engine must raise source and validation expectations for difficult industries.

| Industry type | Source expectation | Special validation emphasis |
|---|---:|---|
| Simple / public / well-documented | 8 seed, 12 investable | source diversity, evidence density |
| Normal investable | 12+ | company/security exposure, earnings bridge |
| Regulated / global / healthcare / financial | 15+ | current regulation, filings, event/catalyst freshness |
| Opaque / private / fragmented | 20+ plus explicit gaps | private-market limits, PE lens, gap honesty |
| Fast-moving technology | 15+ with freshness checks | current events, disruption, signal freshness |
| Commodity / cyclical / industrial | 15+ | pricing, capacity, utilization, cycle validation |

Thresholds may increase by sector, but may not be quietly lowered without maturity downgrade.

---

## 6. Hard-fail conditions

A hard fail caps maturity and score regardless of strengths elsewhere. Hard fails cannot be averaged away.

The following are hard fails:

1. Missing industry boundary.
2. Missing durable source ledger.
3. Missing atomic evidence ledger above Level 1.
4. Missing value-chain nodes.
5. Missing value-chain edges above Seed.
6. Missing money-flow logic for Investable+.
7. Missing profit-pool analysis for Institutional+.
8. Missing company universe for Investable+.
9. Missing security mapping where public securities exist for Investable+.
10. Missing company exposure logic.
11. Missing risks and falsifiers for Investable+.
12. Missing catalysts/events for Investable+, unless justified by industry structure.
13. Missing scenario assumptions for Institutional+.
14. Broken simulation formulas.
15. Unsupported material investment thesis.
16. Hidden blocker gaps.
17. State inconsistency affecting source/evidence truth.
18. Non-durable temporary references only, such as chat-only source references.
19. Hallucinated data.
20. Invented source details.
21. Unlabeled stale current facts.
22. Unresolved critical conflicts hidden from the user.
23. One blended score without decomposition.
24. Pretty HTML masking weak data.

When a hard fail exists, the output may still be produced as partial, but it must be labeled below the affected maturity level and must disclose the fail.

---

## 7. Gap severity law

All missing data must be recorded in `gap_register` and classified by severity.

| Severity | Definition | Maturity impact |
|---|---|---|
| Blocker | Missing core structure required to make the packet valid. Examples: boundary, source ledger, evidence ledger, value chain, company exposure, simulation integrity. | Prevents Investable+ or higher depending on gap type. |
| Major | Missing important analytical coverage. Examples: segment detail, private-market view, quant signal, catalyst sizing, valuation context. | Usually prevents Institutional unless justified. |
| Moderate | Missing useful but non-core refinement. | Reduces score and confidence. |
| Minor | Cosmetic or low-materiality missing item. | Small score penalty. |

Every gap record must include:

- gap_id
- affected table
- affected field
- severity
- reason missing
- affected output section
- required source family
- next action
- maturity impact
- score impact

Gaps must be visible in the final packet. No silent blanks are allowed.

---

## 8. Source validation gates

Source validation is separate from evidence validation. A source can be credible but irrelevant, or relevant but low quality.

Accepted source ledger records must include:

- source_id
- title
- URL or durable file path
- publisher
- author if available
- publication date if available
- accessed date
- source type
- source quality tier
- geography
- topic coverage tags
- relevance notes
- reliability/bias notes
- extraction method

Source validation must check:

- metadata completeness
- source-family coverage
- source-tier diversity
- relevance to data-contract fields
- freshness for current facts
- stale-source risk
- weak-source dependency
- promotional or management bias
- paywall/access limitations where relevant

Source validation output must include:

- pass/fail
- source count by family
- source count by tier
- stale-source list
- missing source families
- weak-source dependency warnings
- source gaps
- recommended follow-up searches

---

## 9. Evidence validation gates

Evidence must be atomic. A source summary is not sufficient.

Accepted atomic evidence records must include:

- evidence_id
- source_id
- claim
- metric/value if applicable
- unit if applicable
- period/date if applicable
- geography if applicable
- source location: page, table, section, paragraph, chart, or timestamp where possible
- linked data-contract table
- linked field
- confidence
- source caveat
- conflict status
- extraction method

Evidence validation must check:

- evidence density by maturity level
- evidence coverage by required table
- evidence coverage by material claim
- evidence-to-field mapping
- source_id resolution
- unit/period/geography completeness for metrics
- confidence distribution
- conflict status
- unsupported material claims
- excessive one-source dependence

Evidence validation output must include:

- pass/fail
- total evidence rows
- evidence rows by table
- unsupported fields
- unsupported claims
- conflicts
- weak evidence clusters
- top missing evidence gaps

---

## 10. Data contract validation gates

The packet must validate against the Phase 2 Research Data Contract.

Validation must check:

- required tables exist
- required fields exist
- required fields are populated or gapped
- IDs are stable and unique
- relationships resolve across IDs
- controlled enums are valid
- derived fields include formulas
- assumptions are labeled
- user-defined values are separated from model/default/source values
- blank values are allowed only when registered as gaps or optional blanks

Required relationship checks include:

- `source_id` resolves to `source_ledger`
- `evidence_id` resolves to `atomic_evidence`
- `node_id` resolves to `value_chain_nodes`
- `edge_id` resolves to `value_chain_edges`
- `company_id` resolves to `company_universe`
- `security_id` resolves to `security_master` where relevant
- `scenario_id` resolves to `scenario_assumptions`
- `event_id` resolves to `event_catalysts`

Data contract validation output must include:

- pass/fail
- missing tables
- missing fields
- invalid enums
- broken joins
- blank severity
- derived formula gaps
- assumption labeling gaps

---

## 11. Value-chain validation gates

The value chain is a core product requirement.

A valid value chain must include, where relevant:

- raw inputs
- components/intermediate suppliers
- production/service creation
- distribution/channel
- direct customer
- final customer
- replacement/aftersales/maintenance cycle
- substitutes and complements where material
- regulators or standards bodies where material

Validation must check:

- nodes exist and are typed
- edges exist and have direction
- edges have flow type: physical, money, data, regulatory, service, contract, or risk
- orphan nodes are justified or removed
- money flows are mapped for Investable+
- profit pools are mapped to nodes
- bottlenecks are mapped to nodes/edges
- final-customer path exists
- node economics exist: revenue model, pricing power, margin profile, capex intensity, cyclicality, bottleneck relevance
- evidence supports major nodes and flows

Value-chain validation output must include:

- completeness score
- missing node types
- missing edges
- orphan nodes
- missing money flows
- missing profit-pool mapping
- missing final-customer path
- unsupported nodes/edges

---

## 12. Company and security validation gates

Industry intelligence is not investable without company and security exposure where public securities exist.

Validation must check:

- company universe exists
- public/private ownership type is clear
- value-chain node participation is mapped
- direct vs indirect exposure is classified
- exposure magnitude is provided: high, medium, low, unknown, plus percentage where available
- exposure direction is provided: benefits, hurt, mixed, uncertain
- company exposure is evidence-linked
- security master exists where public securities exist
- security records include ticker, exchange, country, currency, security type, issuer, and liquidity where available
- diversified companies are not treated as pure plays without segment evidence
- private players are included where material
- unsupported company mentions are flagged

Company/security validation output must include:

- pass/fail
- company coverage score
- ticker/security coverage score
- exposure-purity score
- unsupported companies
- missing public/private coverage
- missing segment exposure
- investability gaps

---

## 13. Financial and valuation validation gates

Financial validation is required for Investable+.

Validation must check:

- revenue drivers
- price/volume bridge
- margin drivers
- input-cost exposure
- capex/capital intensity
- working-capital relevance where material
- cash-flow implications where material
- cyclicality
- segment financial exposure where available
- valuation context where securities are ranked
- consensus expectations where accessible, otherwise gap
- accounting-risk coverage for public companies

Security-linked opportunity rankings require valuation context where accessible. If valuation context is unavailable, this must be a major gap.

Financial validation output must include:

- earnings-bridge score
- valuation-context score
- missing financial drivers
- unsupported sensitivities
- accounting-risk coverage
- consensus/expectations gap

---

## 14. Quantamental validation gates

Quantamental coverage must be honest. A packet cannot claim quantamental quality without data lineage.

Required for Institutional+:

- signal inventory
- signal feasibility assessment
- source lineage
- freshness status
- formula definition or explicit gap
- data frequency
- lag/revision behavior where known
- point-in-time status where possible
- backtest status: tested, untested, insufficient data, or hypothesis only

Validation must check:

- signal definitions
- formulas
- data sources
- update frequency
- current value/status where available
- expected direction
- confidence
- mapping to nodes/companies where possible
- untested signals labeled correctly

Missing quant data should reduce the quantamental role score and may prevent Level 4/5 if the packet claims quantamental depth.

---

## 15. Event and catalyst validation gates

Month-to-year investment research requires timing.

Event/catalyst validation must check:

- event_id
- event type
- date status: announced, expected, estimated, actual, unknown
- source support
- affected node
- affected company/security where relevant
- probability or uncertainty label
- impact magnitude or caveat
- thesis implication: confirms, challenges, invalidates, accelerates, delays, unknown
- negative catalysts included
- event freshness verified before publication

Event types include:

- earnings
- guidance
- investor day
- regulation
- litigation
- M&A
- spin-off
- tariff
- subsidy
- approval/reimbursement
- product launch
- capacity start-up/shutdown
- contract award/loss
- bankruptcy/distress
- labor action
- supply disruption

Event validation output must include:

- catalyst coverage score
- event freshness status
- impact sizing quality
- negative catalyst coverage
- affected-company mapping
- thesis mapping
- missing event gaps

---

## 16. Scenario and simulation validation gates

Simulation is required for Institutional+.

Required scenarios:

1. Base
2. Bull
3. Bear
4. Shock
5. Structural transition
6. Custom-ready scenario

Required assumption fields:

- assumption_id
- scenario_id
- assumption name
- value
- unit
- allowed range
- source status: source-backed, analyst-estimated, user-defined, model-default, gap
- affected node(s)
- affected company/security where relevant
- formula link
- confidence

Simulation validation must check:

- scenario completeness
- assumption coverage
- formula integrity
- unit consistency
- sensitivity output
- node winners/losers update
- company/security winners/losers update where possible
- opportunity ranking changes
- thesis invalidation thresholds
- incomplete-data warnings

Broken formulas are hard fail. A simulation may be shown as incomplete or low-confidence, but must not be presented as valid if formulas or required assumptions are missing.

---

## 17. Opportunity-zone validation gates

Opportunity zones must be structured and evidence-backed.

Required opportunity-zone fields:

- zone_id
- linked node/segment/company/security/basket/event
- thesis
- upside
- downside
- catalyst path
- evidence strength
- valuation context where securities are involved
- risks
- falsifiers
- time horizon: 1–3 months, 3–12 months, 1–3 years
- confidence
- role-lens relevance

Validation must check:

- evidence support
- upside/downside completeness
- time horizon
- catalyst linkage
- falsifier linkage
- valuation context where applicable
- exposed companies/securities
- risk-adjusted ranking logic
- weak ideas labeled as watchlist/hypothesis, not high conviction

Opportunity validation output must include:

- ranking integrity
- evidence strength
- missing downside cases
- missing falsifiers
- valuation gaps
- confidence distribution
- unsupported opportunities

---

## 18. Risk and falsifier validation gates

Every investable thesis must have risks and falsifiers.

Required risk categories:

- demand
- supply
- pricing
- competition
- regulation
- technology
- macro
- rates
- FX
- commodity/input cost
- execution
- accounting
- valuation
- liquidity
- geopolitical

Validation must check:

- risk mapping to nodes
- risk mapping to companies/securities where possible
- risk mapping to opportunity zones
- probability/impact where estimable
- measurable falsifiers where possible
- bear case included
- unresolved risks reduce score

Missing bear case or missing falsifiers hard-fails Investable+.

---

## 19. Role-specific acceptance gates

The engine’s stated standard combines five professional lenses. Each lens must be separately evaluated.

### 19.1 Long/short equity PM gate

Requires:

- opportunity zones
- exposed securities
- long/short/pair/basket implications
- valuation context
- catalysts
- downside
- liquidity/crowding where available
- falsifiers

### 19.2 Fundamental equity analyst gate

Requires:

- segment exposure
- revenue drivers
- margin drivers
- unit economics
- accounting-risk checks
- earnings bridge
- valuation sensitivity

### 19.3 Quantamental data lead gate

Requires:

- structured signal inventory
- signal formulas
- data lineage
- freshness
- frequency/lag
- point-in-time status where possible
- backtest status or hypothesis label

### 19.4 Event-driven special situations PM gate

Requires:

- event/catalyst table
- date certainty
- probability/impact
- affected securities
- negative catalysts
- event freshness
- thesis implication

### 19.5 Growth equity / PE sector principal gate

Requires:

- private players
- sponsor/M&A view where available
- unit economics
- fragmentation/consolidation view
- exit logic
- diligence questions
- private-market gaps where unavailable

Role-specific output must include:

- pass/fail per lens
- score per lens
- missing fields per lens
- next actions per lens

One blended score is invalid without role-lens decomposition.

---

## 20. Scoring model

Scoring is allowed only after gates run. A score cannot override hard fails.

Recommended 0–100 score decomposition:

| Component | Weight |
|---|---:|
| Source quality and source-family coverage | 15 |
| Atomic evidence density and evidence-field coverage | 15 |
| Data-contract completeness and relationship integrity | 15 |
| Value-chain completeness, money flows, profit pools | 10 |
| Company/security exposure mapping | 10 |
| Simulation readiness and formula integrity | 10 |
| Investment logic: opportunities, risks, catalysts, falsifiers, valuation | 15 |
| Role-lens coverage | 5 |
| UI/artifact readiness | 5 |
| **Total** | **100** |

Source and evidence together must carry at least 30% weight. UI must remain a small weight because visual polish cannot compensate for weak research.

Score output must include:

- total score
- maturity level
- hard-fail cap if any
- component scores
- confidence level
- top five weaknesses
- improvement actions

---

## 21. Score bands and labels

| Score | Label | Meaning |
|---:|---|---|
| 0–19 | Invalid / Not Usable | Core structure missing or hard failure. |
| 20–39 | Very Preliminary / Major Gaps | Some useful notes, not reliable. |
| 40–54 | Seed | Preliminary map with sources and visible gaps. |
| 55–69 | Structured but Not Investable | Structured data exists but insufficient investment logic or validation. |
| 70–79 | Investable Research Candidate | Usable for investment research, but not institutional. |
| 80–89 | Institutional-Grade Candidate | Strong packet, but may have remaining gaps or unproven benchmark performance. |
| 90–95 | Institutional-Grade | Strong validated packet with no hard fails. |
| 96–100 | World-Class / Benchmark-Ready | Rare; requires cross-industry proof and regression-tested repeatability. |

Rules:

- No 80+ without company/security exposure where investable.
- No 80+ final packet without simulation readiness.
- No 90+ with unresolved blocker gaps.
- No 90+ without role-specific gates.
- No 95+ “any industry” claim without benchmark/mass-test proof.

---

## 22. Maturity-score caps

Hard caps apply unless explicitly changed in a later approved version.

| Condition | Score cap |
|---|---:|
| Objective/spec only | 19 |
| Seed maturity | 54 |
| Structured but not investable | 69 |
| Missing company/security mapping where investable | 69 |
| Missing money-flow logic | 69 |
| Missing risks/falsifiers | 69 |
| Missing catalysts for month-to-year horizon | 74 |
| Missing valuation context for security rankings | 79 |
| Missing simulation for final Institutional packet | 79 |
| Weak role-lens coverage | 89 |
| No benchmark proof | 95 |
| State inconsistency affecting baseline truth | hard fail until reconciled |
| Hallucinated data or invented source | invalid until removed and corrected |

---

## 23. Validation report requirements

Every packet must include a validation report.

The validation report must exist in both:

1. machine-readable JSON
2. human-readable Markdown or HTML section

Required fields:

- run_id
- industry_id
- packet title
- maturity level
- total score
- score decomposition
- hard-fail list
- validator results
- gap summary
- source statistics
- evidence statistics
- role-lens results
- unresolved conflicts
- stale-source warnings
- weak-source warnings
- top weaknesses
- next actions
- schema version
- source playbook version
- validator version
- packet template version
- run timestamp

The validation report must be visible in the final HTML packet.

---

## 24. Reproducibility and state gates

Reproducibility is an acceptance requirement.

Every output bundle must include:

- manifest
- canonical JSON dataset
- CSV exports for key tables
- source ledger
- atomic evidence ledger
- validation report
- assumptions file
- simulation outputs where applicable
- final HTML packet where applicable
- run log

The manifest must include:

- run_id
- industry_id
- schema version
- source strategy version
- acceptance criteria version
- validator version
- HTML template version
- simulation model version
- generation timestamp
- generated file list
- file hashes where feasible
- draft/final status

State inconsistency, such as conflicting source/evidence counts across current-state files and actual artifacts, is a hard fail until reconciled.

---

## 25. Output blocking and labeling

The engine may produce partial output, but must label it honestly.

Required labels:

- Invalid
- Preliminary
- Seed
- Structured
- Investable Research Candidate
- Institutional Candidate
- Institutional
- World-Class / Benchmark-Ready

Rules:

- Incomplete packets must display gap list.
- Warning labels must be prominent.
- Unsupported investment ranking must be hidden or downgraded to hypothesis/watchlist.
- Broken simulation must not be displayed as valid.
- Stale-source warnings must be shown.
- Weak-source warnings must be shown when material.
- Unresolved conflict warnings must be shown.
- Low maturity prevents investment-grade language.

---

## 26. Prototype and mass-test acceptance

### 26.1 One-industry prototype acceptance

The prototype must produce:

- full structured dataset
- source ledger
- atomic evidence ledger
- value-chain map
- company/security exposure map
- scenario assumptions
- simulation outputs or explicit incomplete simulation status
- opportunity zones
- risks/falsifiers
- validation report
- visible gaps
- artifact manifest

Prototype failure is acceptable if it produces useful failure fingerprints.

### 26.2 Five-industry test acceptance

The five-industry test must include cross-sector variety, such as:

- data-rich industrial
- regulated healthcare
- financial/payments
- consumer/service
- energy/infrastructure or software/platform

The purpose is to expose schema, source, extraction, simulation, UI, and validator failures.

### 26.3 Twenty-industry mass-test acceptance

The twenty-industry benchmark may begin only after:

- one prototype has completed
- five-industry test failures have been patched
- regression checks pass
- validators produce stable results

The mass test must produce:

- failure taxonomy
- score distribution
- maturity distribution
- hard-fail rate
- validator failure rate
- role-lens weakness map
- source/evidence coverage map
- regression notes

A 95+ “any industry” claim requires benchmark evidence across difficult sectors and repeated runs.

---

## 27. Validator output contract

Every validator should eventually produce machine-readable output with this structure:

```json
{
  "validator_id": "string",
  "validator_name": "string",
  "status": "pass|warning|fail|hard_fail",
  "score": 0,
  "severity": "none|minor|moderate|major|blocker",
  "affected_tables": [],
  "affected_fields": [],
  "affected_claims": [],
  "findings": [],
  "required_actions": [],
  "maturity_cap": null,
  "score_cap": null
}
```

Validator outputs must be aggregated into the validation report.

---

## 28. Required validator families

The following validator families are required before institutional scoring:

1. `source_coverage_validator`
2. `source_quality_validator`
3. `evidence_density_validator`
4. `evidence_field_coverage_validator`
5. `data_contract_compliance_validator`
6. `id_relationship_integrity_validator`
7. `blank_gap_validator`
8. `value_chain_completeness_validator`
9. `money_flow_validator`
10. `profit_pool_validator`
11. `company_exposure_validator`
12. `security_master_validator`
13. `financial_sensitivity_validator`
14. `quantamental_signal_validator`
15. `event_catalyst_validator`
16. `simulation_integrity_validator`
17. `opportunity_zone_validator`
18. `risk_falsifier_validator`
19. `role_lens_validator`
20. `score_consistency_validator`
21. `state_manifest_validator`
22. `reproducibility_validator`

---

## 29. Non-negotiable laws

The following laws are absolute unless superseded by a later approved canonical version.

1. Maturity levels are mandatory.
2. Hard fails override scores.
3. Source ledger and atomic evidence ledger are mandatory.
4. Source count alone never passes a packet.
5. Evidence density and field coverage are mandatory.
6. Value chain, money flows, and profit pools must be validated.
7. Company/security exposure must be validated.
8. Risks, falsifiers, catalysts, and opportunity zones must be structured and validated.
9. Simulation is required for Institutional+.
10. Broken simulation formulas hard-fail.
11. Missing data must appear in the gap register.
12. Role-specific gates are mandatory.
13. Score must be decomposed and capped by maturity/hard fails.
14. A 95+ world-class claim requires benchmark/mass-test proof.
15. UI/HTML cannot compensate for weak data or evidence.
16. Unsupported material investment theses hard-fail.
17. Hidden stale-source dependency hard-fails when material.
18. State inconsistency hard-fails until reconciled.
19. One blended score without role-lens results is invalid.
20. Partial output is allowed only with honest maturity labeling and visible gaps.

---

## 30. Active Project Source guidance

After this document is generated and approved, active Project Sources should include:

1. `INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md`
2. `INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md`
3. `INDUSTRY_RESEARCH_DATA_CONTRACT.md`
4. `INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md`
5. `INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md`
6. `BUG_REGISTER.md`

Old current-status files with disputed or stale progress counts must remain archived unless reconciled and clearly marked as volatile current state.

---

## 31. Next phase

After Phase 4 is approved and uploaded, proceed to:

```text
Phase 5 — HTML Packet Template Specification
File: INDUSTRY_HTML_PACKET_TEMPLATE_SPEC.md
```

Phase 5 must not invent content requirements. It must consume the Phase 2 data contract, Phase 3 source playbook, and Phase 4 validation gates.

The HTML packet is the interface. It is not the source of truth.

