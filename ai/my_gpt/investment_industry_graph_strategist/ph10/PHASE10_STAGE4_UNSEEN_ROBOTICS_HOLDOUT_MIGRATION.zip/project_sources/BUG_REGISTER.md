# BUG_REGISTER.md

Status: Active Project Source
Purpose: Durable register of known engine/process/UI bugs that must be checked before prototype execution and regression-tested after fixes.

## Authority

This file is part of the active Industry Intelligence Project Source baseline. It does not define the whole system; it records known defects, failure fingerprints, and regression obligations that the prototype and validators must not ignore.

## Required use

Before any Phase 8 prototype run, Stage 0 readiness must review this bug register and explicitly state whether each active bug is:

- still open,
- mitigated for the current run,
- fixed and regression-tested,
- not applicable to the current run.

No bug in this file may be silently ignored if it could affect source truth, progress truth, validation truth, UI truth, simulation truth, or artifact lineage.

---

## BUG-001 — Source/evidence count truth mismatch

Severity: Blocker for Institutional+ if unreconciled
Status: Open / must be checked in every run
Fingerprint: `source_count_truth_mismatch`
First observed: Prior project status artifacts claimed inconsistent source/evidence counts, including status-style claims of 61 sources/evidence rows while artifact/manifest-style records showed 58 rows.

### Problem

Different artifacts or status summaries can report different counts for sources, evidence rows, files, progress, or validation status. This creates false progress and makes the user unable to trust the packet state.

### Why it matters

The Industry Intelligence Engine depends on source ledgers, atomic evidence ledgers, manifests, validation reports, and progress reporting. If these disagree, the final packet cannot be considered auditable or institutional-grade.

### Required prevention

Every prototype run must maintain one canonical manifest and compute all public counts from the actual artifact files, not from chat memory or manually typed summaries.

Counts that must reconcile:

- accepted source count,
- rejected source count,
- atomic evidence row count,
- required table count,
- populated required field count,
- gap count by severity,
- validator pass/fail/warning count,
- file inventory count,
- progress percentage.

### Required validator behavior

The validator must compare all count claims across:

- manifest,
- source ledger,
- evidence ledger,
- validation report,
- progress log,
- HTML quality header,
- final summary.

Any material mismatch must produce `source_count_truth_mismatch` and cap maturity until reconciled.

### Required regression fixture

Create a bad packet fixture where the manifest says one number and the final summary says another. The validator must detect and fail it.

---

## BUG-002 — Cosmetic progress without artifact proof

Severity: Major; Blocker if used to claim completion
Status: Open / must be checked in every run
Fingerprint: `fake_progress_ring`
First observed: User concern that prior progress displays could imply work was completed without durable source visits, extraction, post-processing, validators, or artifact changes.

### Problem

A progress ring or percent can overstate completion if it is not tied to real artifacts and validator status.

### Why it matters

The user explicitly requires real progress one by one: source plan, searches, accepted/rejected sources, data extraction, post-processing, validation, repair pass, and final bundle. Cosmetic progress destroys trust.

### Required prevention

Progress may only advance when a durable artifact changes or a validator/check completes.

Progress must show:

- current stage,
- completed artifact/check,
- source/evidence counts if relevant,
- unresolved blockers,
- current maturity cap,
- next action.

Progress may not show 100% if any blocker or hard-fail validator remains unresolved.

### Required validator behavior

The validator must compare progress log claims to artifact existence and validation status. If progress claims exceed artifact reality, emit `fake_progress_ring`.

---

## BUG-003 — Random range / shift selection bug in monitoring UI

Severity: Major for any UI/monitoring feature using selectable ranges
Status: Open / not directly related to industry prototype unless progress/monitoring UI uses range selection
Fingerprint: `random_shift_selection_range`
First observed: User reported that shift selection is buggy and selects random ranges across monitoring, services, and external views.

### Problem

Range/shift selection can select incorrect or random ranges, causing monitoring views to display wrong data.

### Why it matters

If the prototype includes progress dashboards, monitoring widgets, time-window filters, source-date filters, event calendars, or validation trend windows, wrong range selection can corrupt user interpretation.

### Required prevention

Any date/range/shift selector must:

- show selected range explicitly,
- use deterministic start/end values,
- log selected range in output metadata,
- avoid hidden auto-range changes,
- include regression tests for boundary cases.

### Required validator behavior

For any UI artifact using range selection, verify displayed range equals dataset/filter state. If not, emit `random_shift_selection_range` or `ui_truth_mismatch`.

---

## BUG-004 — One-source-one-evidence-row shallow extraction

Severity: Major; Blocker for Investable+ if systematic
Status: Open / must be checked in every run
Fingerprint: `one_source_one_evidence_row`

### Problem

A source is summarized into one generic evidence row instead of extracting many atomic claims, metrics, caveats, dates, units, and field-mapped evidence rows.

### Why it matters

The project law requires atomic evidence. Source count alone is meaningless if each source becomes a shallow summary.

### Required prevention

Accepted sources should often produce multiple atomic evidence rows. Every evidence row must map to source_id and target table/field where material.

### Required validator behavior

If the source-to-evidence ratio indicates systematic shallow extraction, emit `one_source_one_evidence_row`, reduce evidence score, and cap maturity depending on severity.

---

## BUG-005 — HTML/UI truth mismatch

Severity: Blocker for final packet if material
Status: Open / must be checked in every run
Fingerprint: `ui_truth_mismatch`

### Problem

HTML may display claims, counts, scores, charts, rankings, maturity labels, or warnings that do not match the canonical dataset, manifest, validation report, source ledger, or evidence ledger.

### Why it matters

The HTML packet is only the product surface. It cannot override the dataset and validation truth.

### Required prevention

All HTML values must be generated from canonical files. Material claims require evidence drilldowns. Quality warnings must match validators.

### Required validator behavior

Compare HTML-visible metrics and claims to canonical dataset and validation report. Any material mismatch emits `ui_truth_mismatch` and blocks final trust label.

---

## BUG-006 — Random ticker list / unsupported company exposure

Severity: Blocker for Investable+ where securities exist
Status: Open / must be checked in every run
Fingerprint: `random_ticker_list`

### Problem

The packet may list companies or securities because they are generally associated with an industry, without evidence-backed exposure type, magnitude, direction, purity, geography, node mapping, or valuation context.

### Why it matters

The engine must produce investable exposure mapping, not generic company lists.

### Required prevention

Every ranked company/security must link to company_id, security_id where applicable, node_id, segment_id, exposure magnitude, exposure direction, purity, evidence, and confidence.

### Required validator behavior

Unsupported companies must be downgraded to hypothesis/watchlist or excluded from rankings. Systematic unsupported company mapping emits `random_ticker_list`.

---

## BUG-007 — Fake simulator / decorative scenario UI

Severity: Blocker for Institutional+
Status: Open / must be checked in every run
Fingerprint: `fake_simulator`

### Problem

The simulator can contain sliders or scenario cards that are not tied to structured assumptions, formulas, value-chain propagation, company/security impacts, sensitivity outputs, or thesis-break thresholds.

### Why it matters

Simulation must be transparent and auditable, not decorative.

### Required prevention

Every simulation output must link to scenario_id, assumption_id, formula_id where applicable, affected nodes/companies/securities, confidence, and output tables.

### Required validator behavior

If simulator UI exists but formulas/assumptions/outputs/lineage are missing or broken, emit `fake_simulator`, disable simulation trust, and cap maturity below Institutional.

