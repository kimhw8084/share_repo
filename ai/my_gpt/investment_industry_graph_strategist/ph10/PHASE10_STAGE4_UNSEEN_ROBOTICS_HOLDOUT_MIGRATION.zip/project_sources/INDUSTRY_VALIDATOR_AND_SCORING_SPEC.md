# Industry Intelligence Engine — Validator and Scoring Specification

**File:** `INDUSTRY_VALIDATOR_AND_SCORING_SPEC.md`  
**Phase:** 7 — Validator and Scoring Specification  
**Status:** Approved canonical project-source law  
**Version:** 1.0.0  
**Generated:** 2026-06-29  
**Authority:** This document converts the previously approved Industry Intelligence project laws into executable validation and scoring requirements. It validates, but does not rewrite, the Canonical Project Goal, Foundation Phase Plan, Research Data Contract, Source Strategy and Reference Playbook, Acceptance Criteria and Validation Gates, HTML Packet Template Specification, and Simulation Engine Contract.

---

## 1. Purpose

Phase 7 defines the validator and scoring system for the Industry Intelligence Engine.

The validator system exists to answer, with machine-checkable evidence:

1. Did the packet follow the approved data contract?
2. Did the packet satisfy the approved source strategy?
3. Did the evidence support the claims?
4. Did the value chain connect end-to-end?
5. Did money flows and profit pools connect to value-chain economics?
6. Did company and security exposure map to value-chain nodes, segments, and financial drivers?
7. Did the simulation engine use visible, bounded, sourced, labeled, and validated assumptions?
8. Did the opportunity ranking depend on evidence, scenario logic, risks, valuation context, catalysts, and falsifiers?
9. Did the HTML packet accurately display maturity, gaps, warnings, evidence, and validation state?
10. What score, maturity level, confidence level, failure fingerprints, and next actions should be assigned?

The validator system must prevent cosmetic progress, unsupported claims, hidden blanks, broken joins, fake simulators, random ticker lists, stale current claims, inflated evidence counts, and self-awarded 95+ scores.

---

## 2. Highest Validator Principle

> **Trust the artifact bundle, not the narrative.**

Validators must inspect the structured artifact bundle. They must not treat polished prose, attractive HTML, or confident summaries as proof of quality.

A packet is not valid because it reads well. It is valid only if the exported dataset, source ledger, evidence ledger, gap register, assumptions, formulas, simulation outputs, validation report, manifest, and HTML packet satisfy the approved laws.

---

## 3. Relationship to Prior Phase Documents

Phase 7 validates prior laws. It does not silently change them.

| Prior phase | File | Phase 7 responsibility |
|---|---|---|
| Phase 0 | `INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md` | Validate that the packet serves the approved one-input industry intelligence objective. |
| Phase 1 | `INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md` | Validate phase discipline, artifact lineage, and do-not-skip rules. |
| Phase 2 | `INDUSTRY_RESEARCH_DATA_CONTRACT.md` | Validate schema, required tables, required fields, controlled enums, IDs, relationships, assumptions, formulas, and gaps. |
| Phase 3 | `INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md` | Validate source families, source tiers, freshness, evidence density, dynamic search logging, and source metadata. |
| Phase 4 | `INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md` | Implement maturity levels, hard fails, score caps, gap severity, and pass/fail rules. |
| Phase 5 | `INDUSTRY_HTML_PACKET_TEMPLATE_SPEC.md` | Validate the HTML packet truthfully displays dataset outputs, gaps, evidence, quality, and warnings. |
| Phase 6 | `INDUSTRY_SIMULATION_ENGINE_CONTRACT.md` | Validate scenario assumptions, formulas, propagation, sensitivity, thesis breaks, and simulation outputs. |

If these documents conflict, the project must halt for reconciliation before claiming a high maturity level.

---

## 4. Non-Negotiable Phase 7 Laws

1. Scoring cannot happen before validators run.
2. Validators inspect the artifact bundle, not only the final narrative.
3. Validators must produce both machine-readable and human-readable outputs.
4. Hard fails override numeric averages.
5. Score caps are mandatory.
6. Maturity is computed from gates, not cosmetic score.
7. Source count alone never passes a packet.
8. Atomic evidence density, evidence coverage, and source quality are mandatory.
9. Broken lineage and broken joins are hard failures at higher maturity.
10. Value-chain, money-flow, company/security, risk, and simulation validators are mandatory.
11. Unsupported material claims hard-fail Investable+ packets.
12. Random ticker lists hard-fail Investable+ packets.
13. Broken formulas or invalid units hard-fail simulation.
14. UI/HTML must match the canonical dataset.
15. Exports and manifest are required for final packets.
16. Role-specific validation scores are mandatory.
17. Failure fingerprints must identify repeatable bug patterns.
18. Regression fixtures must include intentionally bad packets.
19. Progress reporting must be tied to real validator state.
20. 95+ World-Class cannot be claimed without benchmark and mass-test proof.
21. Every major or blocker failure must produce concrete fix actions.
22. Validator versions cannot change silently.
23. Old contradictory project state cannot remain active truth.
24. UI beauty cannot raise maturity above data, evidence, validation, and simulation quality.

---

## 5. Required Artifact Bundle

A final packet cannot be validated from HTML alone. Validators require a standard artifact bundle.

### 5.1 Required Files for Final Packet Validation

| Artifact | Required file name or pattern | Required for |
|---|---|---|
| Canonical dataset | `industry_dataset.json` | All final packets |
| Table exports | `tables/*.csv` or `csv/*.csv` | All final packets |
| Source ledger | `source_ledger.csv` and/or `source_ledger.json` | All final packets |
| Atomic evidence ledger | `atomic_evidence.csv` and/or `atomic_evidence.json` | All final packets |
| Gap register | `gap_register.csv` and/or `gap_register.json` | All final packets |
| Scenario assumptions | `scenario_assumptions.csv` and/or `scenario_assumptions.json` | Investable+ and simulation-bearing packets |
| Formula registry | `formula_registry.csv` and/or `formula_registry.json` | Any packet with derived outputs or simulation |
| Simulation outputs | `simulation_outputs/*.csv` or `simulation_outputs/*.json` | Institutional+ and any packet showing simulation |
| Validation report | `validation_report.json` and `validation_report.md` | All final packets |
| Manifest | `manifest.json` | All final packets |
| HTML packet | `index.html` or named packet HTML | Final HTML packet validation |
| Export index | export links or `exports/` directory | Institutional+ |

### 5.2 Manifest Requirements

`manifest.json` must include:

| Field | Requirement |
|---|---|
| `run_id` | Required stable run identifier |
| `industry_id` | Required stable industry identifier |
| `industry_name` | Required display name |
| `generated_at` | Required timestamp |
| `validated_at` | Required timestamp after validation |
| `schema_version` | Required |
| `source_playbook_version` | Required |
| `acceptance_criteria_version` | Required |
| `html_template_spec_version` | Required |
| `simulation_contract_version` | Required |
| `validator_spec_version` | Required |
| `template_version` | Required for HTML packets |
| `source_accessed_range` | Required when sources are included |
| `file_inventory` | Required list of files |
| `checksums` | Required where feasible |
| `artifact_state` | `draft`, `candidate`, `final`, `archived`, or `diagnostic` |
| `known_state_conflicts` | Required list, even if empty |

Missing manifest is a hard fail for final packets.

---

## 6. Validator Result Schema

Each validator must return a standard result object.

```json
{
  "validator_id": "VAL_SCHEMA_REQUIRED_TABLES",
  "validator_name": "Required Tables Validator",
  "validator_version": "1.0.0",
  "status": "pass | fail | warning | skipped | not_applicable | needs_review",
  "severity": "blocker | major | moderate | minor | info",
  "score_delta": 0,
  "score_cap": null,
  "maturity_cap": null,
  "affected_tables": [],
  "affected_fields": [],
  "affected_outputs": [],
  "failure_code": null,
  "message": "Human-readable result message.",
  "evidence_refs": [],
  "source_refs": [],
  "gap_refs": [],
  "fix_actions": [],
  "requires_human_review": false
}
```

### 6.1 Status Definitions

| Status | Meaning |
|---|---|
| `pass` | Validator passed without material issue. |
| `fail` | Validator failed. Severity and caps apply. |
| `warning` | Validator found a material limitation that does not fully fail the packet. |
| `skipped` | Validator did not run because prerequisites failed. Must include reason. |
| `not_applicable` | Validator is not applicable to this industry/run. Must include justification. |
| `needs_review` | Machine check is inconclusive; human review required. |

### 6.2 Severity Definitions

| Severity | Effect |
|---|---|
| `blocker` | Blocks Investable+ or final packet depending on context. Usually caps score at 54 or lower. |
| `major` | Usually blocks Institutional+ and materially reduces confidence. |
| `moderate` | Reduces score/confidence but may still allow Investable if transparent. |
| `minor` | Small penalty or improvement action. |
| `info` | No penalty; useful context. |

### 6.3 Required Fix Action Structure

Every blocker and major failure must include concrete fix actions.

```json
{
  "fix_id": "FIX_SOURCE_FAMILY_REGULATOR",
  "priority": "P0 | P1 | P2 | P3",
  "action": "Collect current regulator source covering policy status.",
  "target_table": "source_ledger",
  "target_field": "source_type",
  "expected_artifact_change": "Add regulator source and linked evidence rows.",
  "validator_to_rerun": "VAL_SOURCE_FAMILY_COVERAGE"
}
```

---

## 7. Severity, Hard-Fail, and Score-Cap Law

### 7.1 Hard-Fail Rule

Hard fails cannot be averaged away.

If any validator sets a score cap, the final score cannot exceed the lowest active cap.

```text
final_score = min(weighted_score, lowest_active_score_cap)
```

If any validator sets a maturity cap, final maturity cannot exceed the most restrictive maturity cap.

### 7.2 Default Score Caps

| Failure type | Default cap |
|---|---:|
| Missing manifest for final packet | 39 |
| Missing canonical dataset | 19 |
| Missing source ledger | 39 |
| Missing atomic evidence ledger above Seed | 54 |
| Missing industry boundary | 39 |
| Missing value-chain nodes | 39 |
| Missing value-chain edges above Seed | 54 |
| Missing company universe for Investable+ | 54 |
| Missing security mapping where public securities exist | 69 |
| Random ticker list / unsupported company exposure | 54 |
| Missing risks/falsifiers for Investable+ | 54 |
| Missing scenario assumptions for Institutional+ | 79 |
| Broken formulas or invalid units in simulation | 69 |
| Unsupported material investment thesis | 54 |
| UI/dataset mismatch on material claim | 69 |
| State inconsistency affecting truth baseline | 39 until reconciled |
| Hallucinated data or fabricated source details | 19 |
| No benchmark proof for 96+ claim | 95 maximum |

These caps are defaults. Individual validators may set stricter caps.

---

## 8. Validator Suites

The validator system must be organized into suites.

| Suite ID | Suite Name | Purpose |
|---|---|---|
| `SUITE_ARTIFACT` | Artifact and Manifest Validators | Validate file inventory, versions, run lineage, duplicate state, and bundle integrity. |
| `SUITE_SCHEMA` | Schema and Data Contract Validators | Validate Phase 2 tables, fields, IDs, types, enums, formulas, assumptions, and gaps. |
| `SUITE_SOURCE` | Source-Ledger Validators | Validate Phase 3 source families, metadata, tiering, freshness, diversity, and weak-source dependence. |
| `SUITE_EVIDENCE` | Atomic-Evidence Validators | Validate evidence atomicity, evidence density, table coverage, confidence, caveats, conflicts, and source links. |
| `SUITE_LINEAGE` | Linkage and Lineage Validators | Validate joins across sources, evidence, tables, formulas, scenarios, companies, securities, and HTML claims. |
| `SUITE_BOUNDARY` | Boundary and Segmentation Validators | Validate industry definition, inclusions/exclusions, adjacent industries, geography, time horizon, and segment mapping. |
| `SUITE_VALUE_CHAIN` | Value-Chain Validators | Validate nodes, edges, graph connectivity, final-customer path, flow types, node economics, and confidence. |
| `SUITE_MONEY_FLOW` | Money-Flow and Profit-Pool Validators | Validate payer/receiver logic, revenue model, pricing basis, profit pools, margins, and node/edge economics. |
| `SUITE_COMPANY_SECURITY` | Company and Security Validators | Validate company universe, public/private split, security master, exposure magnitude, direction, purity, and evidence. |
| `SUITE_FINANCIAL` | Financial and Valuation Validators | Validate financial bridge, valuation context, accounting risks, capex, working capital, and expectation gaps. |
| `SUITE_QUANT` | Quantamental Validators | Validate signal inventory, formulas, data lineage, freshness, lag, point-in-time status, and hypothesis labels. |
| `SUITE_EVENT` | Event and Catalyst Validators | Validate events, dates, probability labels, impact, negative catalysts, scenario/opportunity linkage, and freshness. |
| `SUITE_SIMULATION` | Simulation Validators | Validate scenarios, assumptions, formulas, units, propagation, sensitivity, thesis breaks, and output tables. |
| `SUITE_OPPORTUNITY` | Opportunity-Zone Validators | Validate opportunities, upside/downside, catalysts, risks, falsifiers, evidence, valuation context, and ranking formula. |
| `SUITE_RISK` | Risk and Falsifier Validators | Validate risk categories, mechanisms, affected entities, monitoring indicators, and measurable falsifiers. |
| `SUITE_HTML` | HTML/UI Validators | Validate required tabs, maturity display, evidence drilldowns, warnings, gap visibility, and UI/dataset consistency. |
| `SUITE_EXPORT` | Export and Reproducibility Validators | Validate export bundle, CSV/JSON consistency, file inventory, checksums, and draft/final state. |
| `SUITE_ROLE` | Role-Specific Validators | Validate long/short PM, fundamental analyst, quantamental, event-driven, and PE/growth coverage. |
| `SUITE_ANTI_GAMING` | Anti-Gaming and Consistency Validators | Detect citation stuffing, duplicate evidence, weak-source backbone, count mismatches, score inflation, and fake progress. |

---

## 9. Validator Execution Order

Validators must run in ordered stages.

| Stage | Validator focus | Reason |
|---:|---|---|
| 1 | Artifact and manifest integrity | Do not validate missing or conflicting bundles. |
| 2 | Schema and required tables/fields | Do not validate domain logic on broken data. |
| 3 | Source and evidence ledgers | Do not score unsupported data. |
| 4 | Linkage and lineage joins | Do not trust disconnected tables. |
| 5 | Domain modules: boundary, value chain, company, financial, quant, event, risk | Validate business/investment structure. |
| 6 | Simulation assumptions, formulas, units, outputs | Validate model logic after data foundation. |
| 7 | Opportunity rankings and role-lens gates | Validate decision layer after evidence/model checks. |
| 8 | HTML/UI/export checks | Validate product surface after dataset truth. |
| 9 | Score, maturity, caps, fingerprints, next actions | Score only after all relevant checks. |

If prerequisites fail, downstream validators may return `skipped`, but must include a skipped reason.

---

## 10. Core Validator Requirements

### 10.1 Artifact and Manifest Validators

Required validators:

| Validator ID | Requirement | Failure impact |
|---|---|---|
| `VAL_MANIFEST_EXISTS` | `manifest.json` exists for final packet. | Missing manifest hard-fails final packet. |
| `VAL_MANIFEST_FILE_INVENTORY` | Manifest lists all required outputs. | Missing required files caps maturity. |
| `VAL_MANIFEST_VERSIONS` | Manifest includes all version fields. | Missing versions major failure. |
| `VAL_MANIFEST_RUN_ID` | Stable `run_id` exists. | Missing run ID major failure. |
| `VAL_MANIFEST_INDUSTRY_ID` | Stable `industry_id` exists. | Missing industry ID major failure. |
| `VAL_MANIFEST_TIMESTAMPS` | Generated, source accessed, and validation timestamps exist. | Missing timestamps major/moderate. |
| `VAL_MANIFEST_CHECKSUMS` | Checksums present where feasible. | Missing checksums moderate. |
| `VAL_DUPLICATE_ACTIVE_ARTIFACTS` | Detect duplicate/conflicting active truth files. | Conflict hard-fails if truth baseline affected. |
| `VAL_STATE_COUNT_CONSISTENCY` | Source/evidence/counts match across manifest, dataset, validation report, HTML. | Truth mismatch failure fingerprint. |

### 10.2 Schema and Data-Contract Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_SCHEMA_REQUIRED_TABLES` | All required tables from Phase 2 exist or are marked with blocker gaps if not applicable. |
| `VAL_SCHEMA_REQUIRED_FIELDS` | Required fields exist in each table. |
| `VAL_SCHEMA_FIELD_TYPES` | Dates, numbers, strings, arrays, enums, and booleans use expected types. |
| `VAL_SCHEMA_CONTROLLED_ENUMS` | Controlled enum fields only contain allowed values. |
| `VAL_SCHEMA_PRIMARY_KEYS` | Primary keys are present, stable, and unique. |
| `VAL_SCHEMA_FOREIGN_KEYS` | Foreign keys resolve across source, evidence, nodes, companies, securities, scenarios, formulas, and opportunities. |
| `VAL_SCHEMA_REQUIRED_BLANKS` | Required blanks are either populated or explicitly represented in gap register. |
| `VAL_SCHEMA_FORMULA_IDS` | Derived fields include formula IDs. |
| `VAL_SCHEMA_ASSUMPTION_STATUS` | Assumptions include source status. |
| `VAL_SCHEMA_VERSION_DRIFT` | Schema changes require version bump. |

### 10.3 Source-Ledger Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_SOURCE_IDS` | Every accepted source has stable `source_id`. |
| `VAL_SOURCE_METADATA` | Required metadata exists: title, URL/file path, publisher, date if available, accessed date, source type, tier, geography, coverage tags, reliability notes. |
| `VAL_SOURCE_TIER_ENUM` | Source tier is controlled enum. |
| `VAL_SOURCE_FAMILY_COVERAGE` | Mandatory source families were checked and accepted/rejected with reasons. |
| `VAL_SOURCE_FRESHNESS_BY_FIELD` | Current claims use current sources; stale claims are marked. |
| `VAL_SOURCE_WEAK_DEPENDENCY` | Detect weak-source backbone. |
| `VAL_SOURCE_RELEVANCE` | Irrelevant/citation-stuffing sources do not count toward thresholds. |
| `VAL_SOURCE_COUNT_THRESHOLD` | Source count meets maturity/complexity threshold. |
| `VAL_SOURCE_DIVERSITY_THRESHOLD` | Sources span required families. |
| `VAL_SOURCE_PRIMARY_GAPS` | Missing primary sources create gap records. |
| `VAL_SOURCE_DURABLE_REFERENCE` | Temporary chat references are rejected as durable final sources. |

### 10.4 Atomic-Evidence Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_EVIDENCE_ATOMICITY` | Evidence rows are atomic claims/metrics, not source summaries. |
| `VAL_EVIDENCE_REQUIRED_FIELDS` | Evidence includes evidence_id, claim, metric/value if applicable, unit, period, geography, source_id, source location, confidence, caveat, linked table/field, conflict status. |
| `VAL_EVIDENCE_SOURCE_LINKS` | Every evidence row links to valid source_id. |
| `VAL_EVIDENCE_FIELD_LINKS` | Material evidence links to target table/field. |
| `VAL_EVIDENCE_COUNT_THRESHOLD` | Evidence row count meets maturity/complexity threshold. |
| `VAL_EVIDENCE_TABLE_COVERAGE` | Required tables have adequate evidence coverage. |
| `VAL_EVIDENCE_SOURCE_RATIO` | Detect one-source-one-row shallow extraction pattern. |
| `VAL_UNSUPPORTED_MATERIAL_CLAIMS` | Detect material claims without evidence, assumption, formula, or gap. |
| `VAL_EVIDENCE_CONFIDENCE_DISTRIBUTION` | Score evidence confidence distribution. |
| `VAL_EVIDENCE_CAVEATS` | Caveats required where source limitations exist. |
| `VAL_EVIDENCE_CONFLICT_STATUS` | Conflict status exists and unresolved conflicts reduce confidence. |
| `VAL_EVIDENCE_DUPLICATES` | Duplicate/repeated evidence rows are flagged and de-duplicated for score. |

### 10.5 Linkage and Lineage Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_CLAIM_LINEAGE` | Every material claim traces to evidence, assumption, formula, or gap. |
| `VAL_SOURCE_EVIDENCE_JOIN` | Source references in evidence resolve. |
| `VAL_FORMULA_INPUT_JOIN` | Formula inputs exist and resolve. |
| `VAL_DERIVED_OUTPUT_FORMULA_LINK` | Derived outputs link to formula IDs. |
| `VAL_SIM_OUTPUT_SCENARIO_LINK` | Simulation outputs link to scenario IDs. |
| `VAL_COMPANY_NODE_LINK` | Company exposure links to value-chain nodes. |
| `VAL_SECURITY_COMPANY_LINK` | Security exposure links to company IDs. |
| `VAL_OPPORTUNITY_LINEAGE` | Opportunities link to evidence, risks, catalysts, falsifiers, valuation context where applicable. |
| `VAL_LINEAGE_DEPTH_SCORE` | Deeper support chains score higher than shallow support. |

### 10.6 Boundary and Segmentation Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_BOUNDARY_EXISTS` | Industry boundary exists. Missing boundary hard-fails. |
| `VAL_BOUNDARY_REQUIRED_FIELDS` | Definition, included segments, excluded areas, geography, time horizon, adjacent industries, investability scope exist. |
| `VAL_BOUNDARY_ASSUMPTIONS` | Ambiguous industry names have visible assumptions. |
| `VAL_BOUNDARY_EXCLUSIONS` | Exclusions are explicit. |
| `VAL_ADJACENT_INDUSTRY_CATEGORIES` | Adjacent industries categorized as upstream, downstream, substitute, complement, or overlap. |
| `VAL_SEGMENTATION_EXISTS` | Segmentation table exists. |
| `VAL_SEGMENT_LINKS` | Segment IDs link to nodes and companies. |
| `VAL_SEGMENT_EVIDENCE` | Missing segment evidence creates gaps. |

### 10.7 Value-Chain Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_VALUE_CHAIN_NODES` | Nodes exist. Missing nodes hard-fails. |
| `VAL_VALUE_CHAIN_EDGES` | Edges exist above Seed. |
| `VAL_NODE_REQUIRED_FIELDS` | Nodes include ID, name, type, segment/geography, economics, evidence, confidence, gaps. |
| `VAL_EDGE_REQUIRED_FIELDS` | Edges include from/to node IDs, flow type, direction, materiality, evidence, confidence. |
| `VAL_GRAPH_CONNECTIVITY` | Graph has no unjustified orphan nodes. |
| `VAL_FINAL_CUSTOMER_PATH` | Chain reaches final customer where relevant. |
| `VAL_FLOW_DIRECTION` | Upstream/downstream direction is coherent. |
| `VAL_FLOW_TYPE_ENUM` | Flow types use controlled values: physical, money, data, regulatory, service, contract, risk. |
| `VAL_NODE_CONFIDENCE` | Low-confidence nodes are marked and scored. |
| `VAL_NODE_ECONOMICS_GAPS` | Missing node economics create gaps. |

### 10.8 Money-Flow and Profit-Pool Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_MONEY_FLOW_REQUIRED` | Money flows exist for Investable+. |
| `VAL_PROFIT_POOL_REQUIRED` | Profit pools exist for Institutional+. |
| `VAL_MONEY_FLOW_FIELDS` | Payer, receiver, node/edge, revenue model, pricing basis, period/geography, evidence, confidence exist. |
| `VAL_PROFIT_POOL_FIELDS` | Node/segment, revenue/profit/margin/ROIC where available, period, geography, evidence, confidence exist. |
| `VAL_MONEY_FLOW_EDGE_LINK` | Money flows link to edges. |
| `VAL_PROFIT_POOL_NODE_LINK` | Profit pools link to nodes. |
| `VAL_PROFIT_POOL_GAPS` | Unknown profit-pool data creates gap records. |
| `VAL_PROFIT_POOL_CORROBORATION` | Major profit-pool claims require corroboration. |

### 10.9 Company and Security Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_COMPANY_UNIVERSE_EXISTS` | Company universe exists for Investable+. |
| `VAL_COMPANY_REQUIRED_FIELDS` | Company fields include ID, name, ownership type, geography, nodes, segments, description, source support, exposure status. |
| `VAL_PUBLIC_PRIVATE_SPLIT` | Public/private distinction exists. |
| `VAL_SECURITY_MASTER_EXISTS` | Security master exists where public securities exist. |
| `VAL_SECURITY_REQUIRED_FIELDS` | Security ID, ticker, exchange, issuer/company ID, country, currency, security type, liquidity where available. |
| `VAL_TICKER_EXCHANGE_FORMAT` | Ticker/exchange format validated where possible. |
| `VAL_COMPANY_EXPOSURE_LOGIC` | Exposure logic exists for Investable+. |
| `VAL_EXPOSURE_REQUIRED_FIELDS` | Company ID, node ID, segment ID, exposure type, magnitude, direction, purity, evidence, confidence. |
| `VAL_DIVERSIFIED_COMPANY_PURITY` | Diversified companies require purity logic. |
| `VAL_UNSUPPORTED_COMPANY_RANKING` | Unsupported companies excluded from ranked output or labeled hypothesis/watchlist. |
| `VAL_SECURITY_VALUATION_WARNING` | Security-linked opportunities warn when valuation context is missing. |

### 10.10 Financial and Valuation Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_FINANCIAL_BRIDGE_EXISTS` | Financial bridge exists for Investable+. |
| `VAL_FINANCIAL_DRIVER_COVERAGE` | Revenue, price, volume, margin, cost, capex, working capital, cash flow, and valuation context covered where relevant. |
| `VAL_REVENUE_FORMULA` | Revenue formulas validated where used. |
| `VAL_MARGIN_SENSITIVITY` | Margin sensitivity supported. |
| `VAL_INPUT_COST_EXPOSURE` | Input-cost exposure validated where relevant. |
| `VAL_CAPEX_INTENSITY` | Capex/capital intensity validated. |
| `VAL_VALUATION_METHOD_FIT` | Valuation method appropriate to sector/security. |
| `VAL_VALUATION_ASSUMPTIONS` | Valuation assumptions explicit. |
| `VAL_VALUATION_RANGE_DISCIPLINE` | Range-based valuation used where uncertainty is high. |
| `VAL_CONSENSUS_VALIDATION` | Consensus expectations validated if used; gap if unavailable. |
| `VAL_ACCOUNTING_RISK` | Accounting risks checked for public companies. |

### 10.11 Quantamental Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_SIGNAL_INVENTORY` | Signal inventory exists or quant gaps are explicit. |
| `VAL_SIGNAL_REQUIRED_FIELDS` | Signal ID, name, definition, formula, source, frequency, lag, current value/status, direction, confidence, backtest status. |
| `VAL_SIGNAL_FORMULA_LINEAGE` | Signal formula lineage exists. |
| `VAL_SIGNAL_FRESHNESS` | Signal freshness validated. |
| `VAL_SIGNAL_LAG_REVISION` | Lag/revision behavior captured where relevant. |
| `VAL_SIGNAL_POINT_IN_TIME` | Point-in-time status captured where possible. |
| `VAL_UNTESTED_SIGNAL_LABEL` | Untested signals labeled hypothesis. |
| `VAL_QUANT_ROLE_CAP` | Missing quant data caps quant role score. |
| `VAL_SIGNAL_CONFLICT` | Conflicting signals reduce confidence. |

### 10.12 Event and Catalyst Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_EVENT_TABLE_EXISTS` | Event table exists for Investable+ unless justified. |
| `VAL_EVENT_REQUIRED_FIELDS` | Event ID, type, date/status, source, affected node/company/security, probability/uncertainty, impact, thesis implication, evidence. |
| `VAL_EVENT_PAST_FUTURE_STATUS` | Past/future status validated. |
| `VAL_EVENT_FRESHNESS` | Event freshness validated. |
| `VAL_EVENT_PROBABILITY_LABEL` | Event probability requires source or estimate label. |
| `VAL_EVENT_SCENARIO_LINK` | Material events link to scenarios/opportunities. |
| `VAL_NEGATIVE_CATALYSTS` | Negative catalysts included. |
| `VAL_EVENT_RUMOR_CONTROL` | Rumors/weak signals cannot support confirmed catalysts. |

### 10.13 Simulation Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_SIM_REQUIRED_FOR_INSTITUTIONAL` | Valid simulation exists for Institutional+. |
| `VAL_SIM_REQUIRED_SCENARIOS` | Base, bull, bear, shock, structural transition, and custom-ready scenarios exist. |
| `VAL_SIM_ASSUMPTION_RECORDS` | Assumption records exist and are complete. |
| `VAL_SIM_ASSUMPTION_FIELDS` | Assumptions include ID, scenario, variable, value, unit, range, source status, confidence, affected nodes/companies, formula link. |
| `VAL_SIM_UNITS` | Units and conversions validated. |
| `VAL_SIM_FORMULAS` | Formula registry exists and formulas validate. |
| `VAL_SIM_OUTPUTS` | Scenario, node, company, security, opportunity, sensitivity, and thesis-break outputs exist where applicable. |
| `VAL_SIM_PROPAGATION` | Node/company/security propagation validated. |
| `VAL_SIM_SENSITIVITY` | Sensitivity outputs exist for Investable+. |
| `VAL_SIM_THESIS_BREAKS` | Thesis-break outputs exist for Investable+. |
| `VAL_SIM_MONTE_CARLO_ORDER` | Monte Carlo rejected if deterministic sensitivity missing. |
| `VAL_SIM_FAILURE_LABELING` | Incomplete/broken simulation labeled or disabled. |

### 10.14 Opportunity-Zone Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_OPPORTUNITY_STRUCTURED` | Opportunity zones exist in structured table. |
| `VAL_OPPORTUNITY_REQUIRED_FIELDS` | Zone ID, node/segment/company/security, thesis, upside, downside, catalysts, evidence strength, valuation context, risks, falsifiers, horizon, confidence. |
| `VAL_OPPORTUNITY_EVIDENCE_LINK` | Opportunities link to evidence. |
| `VAL_OPPORTUNITY_SCENARIO_LINK` | Opportunities link to scenario outputs for Investable+. |
| `VAL_OPPORTUNITY_RISK_LINK` | Opportunities link to risks/falsifiers. |
| `VAL_OPPORTUNITY_UPSIDE_DOWNSIDE` | Upside and downside both present. |
| `VAL_OPPORTUNITY_VALUATION_CONTEXT` | Security-linked opportunities include valuation context or warning. |
| `VAL_OPPORTUNITY_RANKING_FORMULA` | Ranking formula explicit. |
| `VAL_UNSUPPORTED_TOP_OPPORTUNITY` | Unsupported top-ranked opportunities hard-fail Investable+. |

### 10.15 Risk and Falsifier Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_RISK_TABLE_EXISTS` | Risk table exists for Investable+. |
| `VAL_RISK_REQUIRED_FIELDS` | Risk ID, category, mechanism, affected nodes/companies/opportunities, probability/impact where possible, evidence, mitigation/monitoring indicator. |
| `VAL_RISK_CATEGORY_COVERAGE` | Demand, supply, pricing, competition, regulation, technology, macro, rates, FX, commodity, accounting, valuation, liquidity, geopolitics, execution assessed where relevant. |
| `VAL_THESIS_FALSIFIERS` | Every thesis has falsifier. |
| `VAL_FALSIFIER_MEASURABILITY` | Falsifiers measurable where possible. |
| `VAL_RISK_RANKING_LINK` | Risks affect opportunity ranking/confidence. |
| `VAL_BEAR_CASE_EXISTS` | Missing bear case hard-fails Investable+. |
| `VAL_RISK_HTML_VISIBILITY` | Risks/falsifier gaps visible in HTML. |

### 10.16 HTML and UI Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_HTML_REQUIRED_TABS` | Required tabs from Phase 5 exist. |
| `VAL_HTML_MATURITY_BADGE` | Maturity badge visible. |
| `VAL_HTML_HARD_FAIL_BANNER` | Hard-fail banner visible when applicable. |
| `VAL_HTML_SOURCE_EVIDENCE_COUNTS` | Source/evidence counts visible. |
| `VAL_HTML_EVIDENCE_DRILLDOWNS` | Material claims have evidence drilldowns. |
| `VAL_HTML_GAP_VISIBILITY` | Gaps visible. |
| `VAL_HTML_STALE_CONFLICT_WARNINGS` | Stale/conflict warnings visible when material. |
| `VAL_HTML_UNSUPPORTED_RANKINGS` | Unsupported rankings hidden or labeled. |
| `VAL_HTML_SIM_FAILURE_STATE` | Broken/incomplete simulation disabled or labeled. |
| `VAL_HTML_DATASET_MATCH` | HTML values match canonical dataset. |
| `VAL_HTML_EXPORT_LINKS` | Export links/sections present for final packet. |
| `VAL_HTML_UI_SCORE_CAP` | UI cannot score heavily enough to rescue weak data. |

### 10.17 Export and Reproducibility Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_EXPORT_BUNDLE_EXISTS` | Final packet includes export bundle. |
| `VAL_EXPORT_REQUIRED_FILES` | JSON dataset, CSV tables, source ledger, evidence ledger, assumptions, formulas, simulation outputs, validation report, manifest. |
| `VAL_EXPORT_INTERNAL_CONSISTENCY` | JSON and CSV exports match. |
| `VAL_REPRODUCIBLE_FROM_EXPORTS` | Run can be reconstructed from exported files where feasible. |
| `VAL_VALIDATION_FILE_INVENTORY` | Validation report includes file inventory. |
| `VAL_ARCHIVE_HISTORY` | Old runs archived rather than overwritten. |
| `VAL_DRAFT_FINAL_STATE` | Draft/final state explicit. |

### 10.18 Role-Specific Validators

Every packet must expose role-specific results.

| Role validator | Required checks |
|---|---|
| `VAL_ROLE_LONG_SHORT_PM` | Opportunity zones, exposed securities, longs/shorts/pairs/baskets, catalysts, valuation, downside, liquidity/crowding where available, falsifiers. |
| `VAL_ROLE_FUNDAMENTAL_ANALYST` | Segment exposure, revenue/margin drivers, unit economics, accounting risks, valuation sensitivity, earnings bridge. |
| `VAL_ROLE_QUANTAMENTAL_LEAD` | Signal definitions, formulas, lineage, frequency, lag, freshness, point-in-time status, backtest/hypothesis label. |
| `VAL_ROLE_EVENT_DRIVEN_PM` | Event table, dates, probability/impact, affected securities, negative catalysts, event freshness, scenario branches. |
| `VAL_ROLE_PE_GROWTH_PRINCIPAL` | Private players, sponsor/M&A view, fragmentation, unit economics, exit logic, diligence questions, private-market gaps. |

Weak role coverage must be visible. Role weakness caps Institutional and World-Class maturity unless explicitly justified.

### 10.19 Anti-Gaming and Consistency Validators

Required validators:

| Validator ID | Requirement |
|---|---|
| `VAL_ANTI_CITATION_STUFFING` | Detect many irrelevant or low-relevance sources. |
| `VAL_ANTI_ONE_SOURCE_ONE_EVIDENCE` | Detect one-source-one-row extraction pattern. |
| `VAL_ANTI_DUPLICATE_EVIDENCE` | Detect duplicate evidence inflation. |
| `VAL_ANTI_WEAK_SOURCE_BACKBONE` | Detect thesis supported mainly by Tier 5/6 sources. |
| `VAL_ANTI_UNSUPPORTED_HIGH_CONFIDENCE` | Detect high-confidence claims with weak evidence. |
| `VAL_ANTI_COUNT_MISMATCH` | Detect inconsistent source/evidence counts across artifacts. |
| `VAL_ANTI_VERSION_MISMATCH` | Detect schema/source/validator version mismatch. |
| `VAL_ANTI_STALE_CURRENT_CLAIM` | Detect stale evidence used as current fact. |
| `VAL_ANTI_IMPOSSIBLE_SCENARIO` | Detect impossible or out-of-range assumptions. |
| `VAL_ANTI_CONTRADICTORY_SCENARIO` | Detect internally inconsistent scenario assumptions. |
| `VAL_ANTI_UI_TRUTH_MISMATCH` | Detect HTML claim absent from dataset. |
| `VAL_ANTI_SCORE_INFLATION` | Detect high score despite active caps/warnings. |

---

## 11. Scoring Model

### 11.1 Scoring Order

1. Run validators.
2. Apply hard fails.
3. Apply score caps.
4. Compute component scores.
5. Compute role-lens scores.
6. Compute maturity level.
7. Apply maturity cap.
8. Apply confidence cap.
9. Produce final score, maturity, confidence, failure fingerprints, and next actions.

Scoring before validation is invalid.

### 11.2 Score Components

Total score: 0–100.

| Component | Weight |
|---|---:|
| Source quality and source-family coverage | 15 |
| Atomic evidence density and evidence coverage | 15 |
| Data contract/schema compliance | 15 |
| Value chain, money flows, and economics | 10 |
| Company/security exposure quality | 10 |
| Simulation validity | 10 |
| Investment logic and opportunity ranking | 15 |
| Role-lens coverage | 5 |
| UI/artifact readiness | 5 |
| **Total** | **100** |

UI/artifact readiness is intentionally small. A beautiful interface cannot rescue bad data, weak evidence, or broken simulation.

### 11.3 Component Score Inputs

Each component score must be computed from validator outputs, not subjective impression.

Example structure:

```json
{
  "component": "Atomic evidence density and evidence coverage",
  "weight": 15,
  "raw_score": 11.2,
  "validators_used": [
    "VAL_EVIDENCE_ATOMICITY",
    "VAL_EVIDENCE_COUNT_THRESHOLD",
    "VAL_EVIDENCE_TABLE_COVERAGE",
    "VAL_UNSUPPORTED_MATERIAL_CLAIMS"
  ],
  "caps_applied": [],
  "top_weaknesses": [
    "Profit-pool evidence coverage below Institutional threshold."
  ]
}
```

### 11.4 Score Bands

| Score | Label | Conditions |
|---:|---|---|
| 0–19 | Invalid / Not Usable | Missing core artifacts, fabricated data, or catastrophic failure. |
| 20–39 | Very Preliminary / Major Gaps | Artifact exists but lacks core support. |
| 40–54 | Seed | Early sourced map with visible gaps. |
| 55–69 | Structured but Not Investable | Schema and evidence exist but investment logic not ready. |
| 70–79 | Investable Research Candidate | Basic investment research usable with warnings. |
| 80–89 | Institutional-Grade Candidate | Strong packet, no hard fails, but still not full Institutional. |
| 90–95 | Institutional-Grade | Strong validated packet with deep evidence, simulation, role coverage, and low major gaps. |
| 96–100 | World-Class / Benchmark-Ready | Requires repeated cross-industry benchmark/mass-test proof. Extremely rare. |

### 11.5 Maturity Caps

| Condition | Max maturity |
|---|---|
| Goal/spec only, no packet | Level 0 Objective Only |
| Seed sources/evidence only | Level 1 Seed |
| Core tables exist but weak investment logic | Level 2 Structured |
| No valid simulation | Level 3 Investable maximum |
| No company/security exposure where investable securities exist | Level 2 Structured maximum |
| No role-specific validation | Level 3 Investable maximum |
| No benchmark proof | Level 4 Institutional maximum |
| State inconsistency affecting truth baseline | Invalid until reconciled |

### 11.6 Confidence Level

Final confidence must be reported separately from score.

| Confidence | Meaning |
|---|---|
| High | Strong source quality, evidence density, current data, consistent lineage, validated assumptions, low unresolved conflict. |
| Medium | Good support but material limitations remain. |
| Low | Significant gaps, stale data, weak sources, unresolved conflicts, or incomplete simulation. |
| Unknown | Insufficient validated artifact bundle. |

Confidence can cap score when evidence or assumption quality is weak.

---

## 12. Maturity Computation

Maturity is computed from gates, not score alone.

| Level | Name | Required characteristics |
|---:|---|---|
| 0 | Objective Only | Goal/spec exists; no valid industry packet. |
| 1 | Seed | Minimum source/evidence threshold, industry boundary, early value-chain map, visible gaps. |
| 2 | Structured | Core tables present, required fields populated/gapped, source/evidence ledger meaningful, schema mostly valid. |
| 3 | Investable | Value chain, money flows, company/security exposure, risks, catalysts, basic scenarios, evidence support. |
| 4 | Institutional | Full validation suite mostly passes, simulation valid, role-lens coverage, opportunity ranking, quality report, low major gaps. |
| 5 | World-Class | Benchmark-tested, regression-stable, deeply sourced, few/no major gaps, repeatable across difficult sectors. |

A high numeric score cannot override missing maturity gates.

---

## 13. Failure Fingerprints

Validators must identify repeated failure patterns using named fingerprints.

| Fingerprint | Meaning | Typical fix |
|---|---|---|
| `source_count_truth_mismatch` | Source/evidence counts conflict across manifest/status/report/HTML. | Reconcile counts and regenerate manifest/validation. |
| `one_source_one_evidence_row` | Evidence extraction is shallow; one row per source. | Re-extract atomic evidence. |
| `citation_stuffing` | Many sources are irrelevant or low-value. | Remove padding sources; add field-targeted sources. |
| `unsupported_material_claim` | Material claim lacks evidence, assumption, formula, or gap. | Link evidence or downgrade to assumption/gap. |
| `random_ticker_list` | Companies/securities listed without exposure logic. | Build company/security exposure table. |
| `broken_value_chain` | Orphan nodes, missing edges, wrong direction, or no final-customer path. | Repair node/edge graph. |
| `missing_money_flow` | Physical chain exists without economics. | Add money-flow and profit-pool records. |
| `fake_simulator` | Sliders not tied to assumptions, formulas, propagation, or outputs. | Build valid simulation contract implementation. |
| `hidden_gap` | Required blank is not in gap register. | Add gap record with severity and next action. |
| `stale_current_claim` | Old evidence used as current fact. | Refresh source or mark stale. |
| `weak_source_backbone` | Thesis relies mainly on weak Tier 5/6 sources. | Replace/corroborate with primary or higher-tier sources. |
| `ui_truth_mismatch` | HTML displays claim not present in dataset. | Regenerate HTML from dataset or correct data. |
| `score_inflation` | High score despite active hard fails/warnings/caps. | Apply caps and recompute. |
| `formula_magic_number` | Derived output lacks formula lineage. | Add formula registry entry and input links. |
| `scenario_contradiction` | Scenario assumptions are internally inconsistent. | Reconcile assumptions or flag scenario invalid. |
| `role_lens_blind_spot` | Role-specific quality is hidden by blended score. | Add role-specific validator results. |
| `export_bundle_incomplete` | Final packet lacks required exported files. | Generate complete bundle. |
| `progress_theater` | Progress reported without artifact/validator state change. | Tie progress to validators and artifact diffs. |

Fingerprints must feed regression tests.

---

## 14. Regression and Benchmark Requirements

### 14.1 Regression Rule

Every material bug fix must add a regression fixture when feasible.

### 14.2 Required Bad-Packet Fixtures

The validator suite must be tested against intentionally bad packets:

1. Missing source ledger.
2. Missing atomic evidence ledger.
3. One-source-one-evidence-row extraction.
4. Broken foreign keys.
5. Broken value-chain graph.
6. Missing money flows.
7. Random ticker list.
8. Unsupported top opportunity.
9. Stale catalyst listed as future.
10. Fake simulator with disconnected sliders.
11. Formula with invalid units.
12. UI/dataset mismatch.
13. Duplicate evidence inflation.
14. Weak-source backbone.
15. Inconsistent source/evidence counts across manifest/report/HTML.
16. Missing manifest.
17. Missing role-lens validation.
18. Score inflation despite hard fail.

### 14.3 Benchmark Rule for 95+

A packet, engine, or methodology cannot claim 95+ / World-Class without:

1. Validated one-industry prototype.
2. Five-industry cross-sector test.
3. Twenty-industry mass test or approved equivalent benchmark.
4. Low false-pass rate.
5. Low repeated failure rate.
6. Stable validator version during benchmark.
7. Archived benchmark artifacts.
8. Failure taxonomy and regression proof.
9. Evidence that fixes do not break other sectors.

One excellent packet cannot prove World-Class generality.

---

## 15. Progress Reporting and Anti-Fake-Progress Rules

Progress indicators must be backed by real validator state.

Progress may measure:

1. Required artifacts generated.
2. Required validators completed.
3. Required validators passed.
4. Required fields populated or explicitly gapped.
5. Source families checked.
6. Accepted sources with metadata.
7. Atomic evidence rows extracted.
8. Broken joins resolved.
9. Gap severity reduced.
10. Simulation formulas validated.
11. Role-lens gates passed.
12. Export bundle completed.

Progress must not be based on time elapsed, vibes, or number of browsed pages without accepted sources and extracted evidence.

A packet cannot show 95%+ progress while blocker failures remain unresolved.

---

## 16. Human-Readable Validation Report Requirements

Every final packet must include `validation_report.md` and an HTML quality section understandable to a non-engineer.

The human-readable report must include:

1. Packet name and industry.
2. Run ID and validation timestamp.
3. Maturity level.
4. Final score and confidence.
5. Whether the packet is investment-grade.
6. Active hard fails.
7. Active score caps.
8. Top blockers.
9. Top major gaps.
10. Source count and source-family coverage.
11. Evidence count and evidence coverage by table.
12. Role-lens scores.
13. Simulation maturity and validity.
14. Opportunity ranking validity.
15. Stale-source warnings.
16. Unresolved conflicts.
17. Failure fingerprints.
18. What passed.
19. What failed.
20. Why score is capped.
21. Concrete next actions.

---

## 17. Machine-Readable Validation Report Requirements

Every final packet must include `validation_report.json`.

Required top-level structure:

```json
{
  "run_id": "",
  "industry_id": "",
  "validator_spec_version": "1.0.0",
  "validated_at": "",
  "artifact_state": "draft | candidate | final | diagnostic",
  "maturity_level": "Level 0 | Level 1 | Level 2 | Level 3 | Level 4 | Level 5",
  "maturity_label": "",
  "score": 0,
  "score_confidence": "high | medium | low | unknown",
  "score_components": [],
  "active_score_caps": [],
  "active_maturity_caps": [],
  "hard_fails": [],
  "warnings": [],
  "validator_results": [],
  "failure_fingerprints": [],
  "gap_summary": {},
  "source_summary": {},
  "evidence_summary": {},
  "role_lens_scores": {},
  "simulation_status": {},
  "next_actions": []
}
```

---

## 18. Final Packet Acceptance Rule

A final industry packet may be labeled:

- **Seed** only if minimum source/evidence/boundary/value-chain requirements pass and gaps are visible.
- **Structured** only if the data contract substantially validates and required fields are populated or gapped.
- **Investable Research Candidate** only if value chain, money flows, company/security exposure, risks, catalysts, basic scenarios, and opportunity logic pass without blocker failures.
- **Institutional-Grade** only if the full validation suite substantially passes, simulation is valid, role-lens coverage is strong, opportunity ranking is supported, and no unresolved blocker or disqualifying major gaps remain.
- **World-Class / Benchmark-Ready** only after cross-sector benchmark proof and regression stability.

If a packet fails, it should fail honestly, display the failure prominently, and provide concrete next actions.

---

## 19. Project Source Activation Guidance

After this file is generated and uploaded, the active Project Sources should be:

1. `INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md`
2. `INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md`
3. `INDUSTRY_RESEARCH_DATA_CONTRACT.md`
4. `INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md`
5. `INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md`
6. `INDUSTRY_HTML_PACKET_TEMPLATE_SPEC.md`
7. `INDUSTRY_SIMULATION_ENGINE_CONTRACT.md`
8. `INDUSTRY_VALIDATOR_AND_SCORING_SPEC.md`
9. `BUG_REGISTER.md`

Contradictory old project-state files should remain archived or inactive unless reconciled.

---

## 20. Next Phase Linkage

The next phase is:

```text
Phase 8 — One-Industry Prototype Execution Plan
```

Phase 8 must not skip this validator specification. The one-industry prototype must generate an artifact bundle and run the Phase 7 validation logic against it.

The prototype is allowed to fail. A failed prototype is valuable if it produces clear validator failures, failure fingerprints, and next actions.

---

## 21. Canonical Approval Statement

The approved Phase 7 law is:

> No packet may receive an investable, institutional, world-class, or 95+ label unless the validator suite proves the artifact bundle satisfies the required gates. Hard fails and maturity caps override numeric averages. The score must be decomposed, auditable, reproducible, versioned, and accompanied by concrete failure explanations and next actions.

