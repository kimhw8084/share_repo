# INDUSTRY_FIVE_INDUSTRY_CROSS_SECTOR_TEST_PLAN.md

## Document status

**Phase:** Phase 9 — Five-Industry Cross-Sector Test  
**Status:** Approved canonical project source  
**Created for:** Industry Intelligence project  
**Purpose:** Define the required method for testing the Industry Intelligence Engine across five archetype-diverse industries after the repaired Phase 8 semiconductor manufacturing equipment prototype.  
**Authority:** This file extends, but does not replace, the previously approved Project Source law stack.

---

## 1. Binding source baseline

Phase 9 must be executed only after the following Project Sources are active and treated as law:

1. `INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md`
2. `INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md`
3. `INDUSTRY_RESEARCH_DATA_CONTRACT.md`
4. `INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md`
5. `INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md`
6. `INDUSTRY_HTML_PACKET_TEMPLATE_SPEC.md`
7. `INDUSTRY_SIMULATION_ENGINE_CONTRACT.md`
8. `INDUSTRY_VALIDATOR_AND_SCORING_SPEC.md`
9. `INDUSTRY_ONE_PROTOTYPE_EXECUTION_PLAN.md`
10. `INDUSTRY_FIVE_INDUSTRY_CROSS_SECTOR_TEST_PLAN.md`
11. `BUG_REGISTER.md`

Archived or stale files must not control Phase 9. This includes prior context summaries, old status files, old manifests, old zip artifacts, obsolete README files, and prior prompt files unless explicitly reconciled and reclassified.

---

## 2. Phase 9 objective

Phase 9 creates and executes the **Five-Industry Cross-Sector Test** for the Industry Intelligence Engine.

The purpose is not to maximize score. The purpose is to determine whether the engine generalizes across materially different industry archetypes:

- physical infrastructure,
- financial networks,
- industrial/service installed-base sectors,
- commodity/policy supply chains,
- software/platform economics.

Each industry must run through the same source, evidence, data, simulation, HTML, validation, repair, and packaging workflow used in the repaired Phase 8 prototype.

Phase 9 must produce:

1. five complete industry artifact bundles,
2. before/after repair validation for each industry,
3. a cross-industry scoreboard,
4. a repeated-failure taxonomy,
5. validator false-pass / false-fail analysis,
6. source strategy patch recommendations,
7. schema patch recommendations,
8. HTML template patch recommendations,
9. simulation patch recommendations,
10. Phase 10 readiness report.

Phase 9 is a generality and reliability test. It is not a 95+ claim and not a world-class certification.

---

## 3. Relationship to Phase 8 repaired prototype

The repaired semiconductor manufacturing equipment prototype is accepted as the Phase 8 regression baseline.

### 3.1 Phase 8 baseline metrics

- **Industry:** Semiconductor manufacturing equipment
- **Disposition:** pass-with-major-gaps
- **Maturity:** Institutional-Grade Candidate prototype, not final institutional release
- **Score:** 80.5 / 100
- **Hard fails:** 0
- **Blocker gaps:** 0
- **Major gaps:** 4
- **Accepted external sources:** 33
- **Internal reference sources:** 3
- **Atomic evidence rows:** 191
- **Search log rows:** 21
- **Dataset tables:** 41
- **Required HTML tabs:** 19 / 19

### 3.2 Phase 8 remaining gap classes

The following gap classes must be tracked across Phase 9 to determine whether they are semicap-specific or engine-wide:

1. company filings depth,
2. private-market coverage,
3. live valuation / quant stack,
4. simulation calibration.

### 3.3 Regression baseline rule

The semicap repaired bundle is not one of the five new Phase 9 industries unless explicitly chosen. It remains a regression baseline used to test whether repairs in Phase 9 break or improve the Phase 8 result.

---

## 4. Phase 9 non-goals

Phase 9 must not:

1. claim 95+ quality,
2. claim world-class readiness,
3. proceed to Phase 10 automatically,
4. use average score alone as success proof,
5. create five narrative reports without bundles,
6. hide low scores,
7. skip repair passes,
8. skip cross-run failure taxonomy,
9. skip validator false-pass / false-fail tracking,
10. ignore the repaired semicap baseline.

---

## 5. Industry selection law

### 5.1 Selection principle

The five industries must be archetype-diverse. They must not be five variations of the same industrial or semiconductor-like sector.

### 5.2 Selection criteria

Each candidate industry must be scored against:

1. source availability,
2. source-type diversity,
3. value-chain complexity,
4. public-company/security exposure,
5. financial sensitivity,
6. scenario richness,
7. event/catalyst activity,
8. regulatory or policy relevance,
9. private-market / PE relevance,
10. quantamental signal availability,
11. ability to expose validator bugs,
12. cross-sector uniqueness.

### 5.3 Required portfolio composition

The five-industry set must include:

1. at least three source-rich industries,
2. at least one moderately opaque or fragmented industry,
3. at least one regulated industry,
4. at least one software/platform industry,
5. at least one consumer/service or installed-base service industry,
6. at least one industry with meaningful commodity or policy exposure,
7. at least four industries with public-company/security exposure,
8. at least one industry likely to stress private-market coverage,
9. at least one industry likely to stress live valuation / quant weaknesses.

### 5.4 Recommended Phase 9 industry set

The approved recommended set is:

1. **Data center power and thermal infrastructure**
2. **Payments infrastructure**
3. **Commercial HVAC equipment and services**
4. **Battery materials and recycling**
5. **Vertical SaaS for healthcare revenue cycle management**

### 5.5 Why these five

#### Data center power and thermal infrastructure

Tests AI infrastructure capex, equipment bottlenecks, utilities, grid constraints, power electronics, thermal management, project timing, and multi-sector capital flows.

#### Payments infrastructure

Tests financial networks, take rates, regulation, transaction volumes, fraud/risk, public securities, software-like margins, and macro/consumer sensitivity.

#### Commercial HVAC equipment and services

Tests industrial/service installed-base economics, replacement cycles, regulation, energy efficiency, contractor channels, aftermarket service, and cyclicality.

#### Battery materials and recycling

Tests commodity chains, China exposure, policy incentives, recycling economics, materials pricing, private/public mix, and technology uncertainty.

#### Vertical SaaS for healthcare revenue cycle management

Tests software/platform metrics, healthcare regulation, payer/provider workflow, PE/private-market ownership, customer concentration, retention, and KPI comparability.

---

## 6. Per-industry execution contract

Each of the five industry runs must follow the Phase 8 staged workflow unless a deviation is explicitly justified and logged.

### 6.1 Required per-industry stages

For each industry:

0. readiness check,
1. industry boundary and segmentation,
2. source plan,
3. source discovery and search logging,
4. source acceptance/rejection,
5. atomic evidence extraction,
6. data-contract population,
7. value-chain construction,
8. company/security mapping,
9. professional lens modules,
10. simulation setup,
11. HTML packet generation,
12. validation and scoring,
13. repair pass,
14. final artifact bundle,
15. human-review-ready summary.

### 6.2 Per-industry target score

Target range: **70–85**.

The score must not be forced. Honest lower scores are acceptable if the bundle is diagnostic and failure fingerprints are captured.

### 6.3 Per-industry source target

Target accepted source range: **20–35 accepted sources**, adjusted for complexity and opacity.

Source count alone is never sufficient.

### 6.4 Per-industry evidence target

Target atomic evidence rows: **150–300 rows where feasible**.

Evidence must be atomic, field-mapped, source-linked, and caveated. One-source-one-evidence-row patterns must be flagged.

### 6.5 Per-industry repair rule

Each industry must have:

1. pre-repair validation,
2. prioritized repair pass,
3. post-repair validation,
4. before/after score movement,
5. remaining gap list,
6. final disposition.

No industry run is complete without the post-repair validation report.

---

## 7. Required per-industry artifact bundle

Every industry run must produce a zipped bundle containing, at minimum:

1. `industry_dataset.json`
2. CSV exports for all major data-contract tables
3. `source_ledger.csv`
4. `source_ledger.json`
5. `atomic_evidence.csv`
6. `atomic_evidence.json`
7. `search_log.csv`
8. `search_log.json`
9. `rejected_sources.csv`
10. `rejected_sources.json`
11. `gap_register.csv`
12. `gap_register.json`
13. `scenario_assumptions.csv`
14. `scenario_assumptions.json`
15. `formula_registry.csv`
16. `formula_registry.json`
17. simulation output tables
18. value-chain output tables
19. company/security exposure tables
20. professional lens tables or sections
21. HTML packet
22. `validation_report.json`
23. `validation_report.md`
24. `manifest.json`
25. `prototype_run_log.md`
26. `failure_fingerprints.json`
27. `failure_fingerprints.md`
28. `improvement_backlog.md`
29. `final_summary.md`
30. zipped final bundle

If any required artifact is not applicable, the bundle must include a clear not-applicable reason. Unsupported omission is a failure.

---

## 8. Required cross-run outputs

After five industry runs, Phase 9 must produce:

1. `phase9_cross_industry_scoreboard.csv`
2. `phase9_cross_industry_scoreboard.json`
3. `phase9_failure_taxonomy.md`
4. `phase9_failure_taxonomy.json`
5. `phase9_validator_hardening_backlog.md`
6. `phase9_source_strategy_patch_recommendations.md`
7. `phase9_schema_patch_recommendations.md`
8. `phase9_html_template_patch_recommendations.md`
9. `phase9_simulation_patch_recommendations.md`
10. `phase9_phase10_readiness_report.md`
11. `phase9_final_human_review_package.md`
12. zipped Phase 9 meta-bundle containing all five industry bundles and cross-run outputs.

---

## 9. Cross-run comparison law

Phase 9 must compare all five runs across the following dimensions:

1. final score,
2. pre-repair score,
3. repair score delta,
4. maturity level,
5. accepted source count,
6. atomic evidence count,
7. search log count,
8. rejected source count,
9. source-family coverage,
10. source-tier distribution,
11. evidence density by table,
12. canonical table completeness,
13. value-chain completeness,
14. money-flow completeness,
15. profit-pool completeness,
16. company/security exposure quality,
17. public/private company coverage,
18. financial sensitivity readiness,
19. quantamental readiness,
20. event/catalyst readiness,
21. simulation readiness,
22. HTML completeness,
23. export completeness,
24. hard fails,
25. blocker gaps,
26. major gaps,
27. role-lens scores,
28. failure fingerprints,
29. validator false passes,
30. validator false fails,
31. progress-reporting integrity,
32. human-review disposition.

Repeated failures across more than one industry become engine defects unless clearly proven industry-specific.

---

## 10. Validator-hardening law

Phase 9 must explicitly test and harden the validator suite.

### 10.1 Mandatory validator fingerprints

Every industry run must test for:

1. `source_count_truth_mismatch`
2. `one_source_one_evidence_row`
3. `source_tier_enum_drift`
4. `weak_source_backbone`
5. `citation_stuffing`
6. `missing_canonical_table`
7. `schema_alias_drift`
8. `broken_source_id_lineage`
9. `broken_linked_table_refs`
10. `broken_node_edge_foreign_keys`
11. `missing_company_node_id`
12. `random_ticker_list`
13. `missing_money_flow`
14. `fake_simulator`
15. `unsupported_material_claim`
16. `stale_current_claim`
17. `ui_truth_mismatch`
18. `score_inflation`
19. `hidden_gap`
20. `progress_ring_not_artifact_backed`
21. `validator_false_pass`
22. `validator_false_fail`

### 10.2 Validator false-pass rule

If a validator reports pass but manual or secondary audit finds a true defect, record:

- validator ID,
- affected industry,
- missed failure,
- severity,
- reason it passed incorrectly,
- required validator patch,
- regression test fixture.

### 10.3 Validator false-fail rule

If a validator incorrectly blocks a legitimate industry-specific exception, record:

- validator ID,
- affected industry,
- false failure,
- exception rationale,
- required validator nuance,
- regression test fixture.

### 10.4 Validator patch backlog

Every repeated or severe validator issue must enter `phase9_validator_hardening_backlog.md` with:

- issue ID,
- failure fingerprint,
- affected industries,
- severity,
- root cause,
- proposed validator patch,
- required regression fixture,
- owner role / implementation lane,
- priority.

---

## 11. Source strategy evaluation

Phase 9 must test whether the Phase 3 source playbook is general enough across sectors.

For each industry, evaluate:

1. whether mandatory source families were available,
2. whether official primary sources were sufficient,
3. whether company filings were accessible and useful,
4. whether private-market data was materially missing,
5. whether current event/catalyst sources were sufficient,
6. whether quantamental/time-series sources were available,
7. whether secondary sources filled unavoidable gaps,
8. whether weak-source dependency emerged,
9. whether rejected-source patterns repeated,
10. whether source-family rules need industry-archetype modules.

If a source-family gap repeats across industries, Phase 9 must recommend a source-playbook patch.

---

## 12. Schema evaluation

Phase 9 must test whether the Phase 2 data contract generalizes.

For each industry, evaluate:

1. which required tables were naturally populated,
2. which required tables were repeatedly difficult,
3. which fields caused blank/gap patterns,
4. whether industry-specific modules were needed,
5. whether table aliases caused schema drift,
6. whether canonical table names need controlled alias mapping,
7. whether relationship keys were sufficient,
8. whether formula registry coverage was adequate,
9. whether opportunity-zone schema supported the industry,
10. whether role-lens tables need expansion.

Schema patch recommendations must not silently change the data contract. They must be proposed for review before becoming active law.

---

## 13. Simulation evaluation

Phase 9 must test whether the Phase 6 simulation engine adapts across industries.

For each industry, evaluate:

1. scenario completeness,
2. assumption quality,
3. source-backed vs analyst-estimate assumption ratio,
4. variable-to-node propagation,
5. node-to-company propagation,
6. company-to-security propagation,
7. formula availability,
8. sensitivity output quality,
9. thesis-break output quality,
10. valuation/price-target disabled-state correctness,
11. whether simulation was directional or valuation-grade,
12. whether custom-ready scenario hooks are usable,
13. whether model gaps are industry-specific or engine-wide.

The simulation patch report must separate:

- data scarcity,
- formula weakness,
- missing calibration,
- unsupported valuation,
- UI simulator limitations,
- model architecture gaps.

---

## 14. HTML template evaluation

Phase 9 must test whether the Phase 5 HTML packet template works across archetypes.

For each industry, evaluate:

1. all required tabs present,
2. maturity/score/hard-fail banner visible,
3. source/evidence counts visible,
4. evidence drilldowns available,
5. gaps visible,
6. stale/conflict warnings visible,
7. source ledger accessible,
8. validation report accessible,
9. simulation UI state correct,
10. unsupported rankings labeled or hidden,
11. export links present,
12. UI values match canonical dataset,
13. no HTML-only invented claims.

If an HTML pattern works for industrial sectors but fails for software, financial, or healthcare sectors, Phase 9 must recommend template modules.

---

## 15. Role-lens evaluation

Phase 9 must score role-lens coverage across industries:

1. long/short PM,
2. fundamental analyst,
3. quantamental data lead,
4. event-driven PM,
5. PE/growth principal.

A weak role lens must be visible and must not be hidden by aggregate score.

Phase 9 must identify which role lenses are systematically weakest across sectors.

---

## 16. Progress law

Phase 9 progress must be artifact-backed and validator-backed.

Recommended progress ledger:

- **10%** — Phase 9 plan approved and source baseline ready
- **20%** — industry selection finalized
- **30%** — run 1 completed and audited
- **40%** — run 2 completed and audited
- **50%** — run 3 completed and audited
- **60%** — run 4 completed and audited
- **70%** — run 5 completed and audited
- **80%** — cross-run failure taxonomy complete
- **88%** — validator/source/schema/simulation patch backlog complete
- **94%** — Phase 10 readiness report complete
- **100%** — final human-review package delivered

Phase 9 cannot reach 100% if any run lacks a bundle, manifest, validation report, or cross-run comparison.

---

## 17. Per-industry final disposition labels

Each industry must receive one of the following dispositions:

1. `pass`
2. `pass_with_major_gaps`
3. `fail_useful`
4. `fail_invalid`

### 17.1 Pass

The run is complete, validated, repaired, and has no blocker gaps or unresolved severe validator concerns.

### 17.2 Pass with major gaps

The run produced a real bundle and useful research output, but major gaps remain. This is acceptable in Phase 9 if gaps are explicit and diagnostic.

### 17.3 Fail useful

The run did not reach acceptable maturity but produced valuable failure fingerprints and repair information.

### 17.4 Fail invalid

The run lacks core artifacts, has untrustworthy counts, hides gaps, fabricates outputs, or fails to provide a usable validation report.

---

## 18. Phase 9 acceptance criteria

Phase 9 succeeds if:

1. five industry bundles exist,
2. every bundle has a manifest,
3. every bundle has canonical dataset and CSV exports,
4. every bundle has source and evidence ledgers,
5. every bundle has search log and rejected-source log,
6. every bundle has gap register,
7. every bundle has simulation outputs or properly disabled simulation state,
8. every bundle has HTML packet,
9. every bundle has validation report,
10. every bundle has failure fingerprints,
11. every bundle has before/after repair scoring,
12. cross-run scoreboard exists,
13. repeated failure taxonomy exists,
14. validator false-pass / false-fail analysis exists,
15. source strategy patch recommendations exist,
16. schema patch recommendations exist,
17. HTML template patch recommendations exist,
18. simulation patch recommendations exist,
19. Phase 10 readiness report exists,
20. final human-review package exists.

---

## 19. Phase 9 failure conditions

Phase 9 fails if:

1. it produces narrative reports instead of artifact bundles,
2. one or more industries lack manifest or validation report,
3. source/evidence counts do not reconcile,
4. material claims lack evidence support,
5. five runs are not compared,
6. repeated failure patterns are not captured,
7. validator false passes are ignored,
8. low scores are hidden or inflated,
9. 95+ or world-class is claimed,
10. Phase 10 is started without human review.

---

## 20. Phase 10 readiness criteria

Phase 9 may recommend moving to Phase 10 only if:

1. all five runs produced real artifact bundles,
2. no run is `fail_invalid`, unless the failure is fully explained and intentionally diagnostic,
3. count reconciliation passes across all runs,
4. repeated severe failures have patch recommendations,
5. validator false passes are identified and assigned fixes,
6. source strategy gaps are classified,
7. schema gaps are classified,
8. simulation gaps are classified,
9. HTML gaps are classified,
10. semicap regression baseline remains valid or changes are explained,
11. human review explicitly approves Phase 10 design.

Phase 10 readiness is not determined by average score alone.

---

## 21. Required Phase 9 final report structure

The Phase 9 final human-review package must include:

1. executive verdict,
2. five-industry scoreboard,
3. semicap baseline comparison,
4. score distribution,
5. maturity distribution,
6. source/evidence statistics,
7. role-lens statistics,
8. repeated failure taxonomy,
9. validator false-pass / false-fail report,
10. source strategy patch summary,
11. schema patch summary,
12. simulation patch summary,
13. HTML patch summary,
14. major unresolved gaps,
15. decision on whether Phase 10 is ready,
16. exact recommended next action.

---

## 22. Non-negotiable Phase 9 laws

1. Phase 9 tests generality, not perfection.
2. Five industries must be archetype-diverse.
3. Semicap remains the regression baseline.
4. Every industry must produce a full artifact bundle.
5. Every industry must receive before/after repair validation.
6. Every industry must expose gaps and failure fingerprints.
7. Cross-run comparison is mandatory.
8. Repeated failures become engine defects unless proven industry-specific.
9. Validator false passes and false fails must be captured.
10. Phase 9 cannot claim 95+ or world-class.
11. Phase 9 cannot proceed to Phase 10 without human review.
12. Phase 10 readiness depends on failure taxonomy, not average score alone.
13. Source count alone never proves quality.
14. Evidence must be atomic and field-mapped.
15. HTML must not invent data beyond the canonical dataset.
16. Simulation must be directional or valuation-grade with explicit status; decorative simulation is failure.
17. Low score is acceptable if diagnostic and honest.
18. Hidden gaps are worse than visible gaps.
19. Progress must be artifact-backed.
20. Every final bundle must be auditable.

---

## 23. Phase 9 execution prompt template

When starting a new Phase 9 execution chat, use the following prompt:

```text
We are inside the Industry Intelligence project. Use the active Project Sources as binding law.

Active source baseline must include:
1. INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md
2. INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md
3. INDUSTRY_RESEARCH_DATA_CONTRACT.md
4. INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md
5. INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md
6. INDUSTRY_HTML_PACKET_TEMPLATE_SPEC.md
7. INDUSTRY_SIMULATION_ENGINE_CONTRACT.md
8. INDUSTRY_VALIDATOR_AND_SCORING_SPEC.md
9. INDUSTRY_ONE_PROTOTYPE_EXECUTION_PLAN.md
10. INDUSTRY_FIVE_INDUSTRY_CROSS_SECTOR_TEST_PLAN.md
11. BUG_REGISTER.md

Current phase: Phase 9 — Five-Industry Cross-Sector Test.

Use the repaired semiconductor manufacturing equipment prototype as the Phase 8 regression baseline:
- score 80.5 / 100
- disposition pass-with-major-gaps
- hard fails 0
- blocker gaps 0
- major gaps 4
- accepted external sources 33
- atomic evidence rows 191
- required HTML tabs 19 / 19

Execute Phase 9 according to INDUSTRY_FIVE_INDUSTRY_CROSS_SECTOR_TEST_PLAN.md.

Do not run randomly. Start with Phase 9 Stage 0 readiness check and industry-selection confirmation.

Recommended five industries:
1. Data center power and thermal infrastructure
2. Payments infrastructure
3. Commercial HVAC equipment and services
4. Battery materials and recycling
5. Vertical SaaS for healthcare revenue cycle management

For each industry, produce a full artifact bundle with canonical dataset, CSV exports, source ledger, atomic evidence ledger, search log, rejected-source log, gap register, scenario assumptions, formula registry, simulation outputs, HTML packet, validation report, manifest, run log, failure fingerprints, improvement backlog, final summary, and zipped bundle.

Run validators before and after one repair pass for every industry.

After all five runs, produce cross-industry scoreboard, repeated failure taxonomy, validator-hardening backlog, source strategy patch recommendations, schema patch recommendations, HTML template patch recommendations, simulation patch recommendations, Phase 10 readiness report, and final human-review package.

Do not claim 95+ or world-class.
Do not proceed to Phase 10 automatically.
Progress must be artifact-backed and validator-backed.
```

---

## 24. Final approval state

This Phase 9 plan is approved as canonical project law after user approval.

The next operational step is to upload this file to Project Sources, then start Phase 9 execution using the prompt template above.
