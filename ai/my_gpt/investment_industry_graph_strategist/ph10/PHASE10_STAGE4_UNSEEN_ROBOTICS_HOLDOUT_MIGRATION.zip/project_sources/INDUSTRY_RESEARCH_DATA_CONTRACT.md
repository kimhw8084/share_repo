# INDUSTRY RESEARCH DATA CONTRACT

**Project:** Industry Intelligence Engine  
**File:** `INDUSTRY_RESEARCH_DATA_CONTRACT.md`  
**Version:** v1.0  
**Status:** Approved Phase 2 Law  
**Authority Level:** Canonical operating specification  
**Created:** 2026-06-29  
**Depends On:**
- `INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md`
- `INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md`
- `BUG_REGISTER.md`

**Supersedes:** Any informal, prior, partial, or chat-only data-template discussion.

---

## 1. Purpose

This document defines the universal research data contract for the Industry Intelligence Engine.

The engine accepts a single industry name and ultimately produces an institutional-grade interactive HTML intelligence and simulation packet. This data contract defines the structured dataset that must exist before narrative, HTML, simulation, opportunity ranking, validation scoring, or investment interpretation can be considered reliable.

The contract makes structured data the source of truth.

Narrative, HTML, charts, simulation, opportunity ranking, quality scoring, and investment implications must be generated from the structured dataset, not improvised from prose.

---

## 2. Phase Position

The project is currently in:

```text
Phase 2 — Research Data Contract
```

Completed and approved before this phase:

```text
Phase 0 — Source Cleanup and Canonical Goal
Phase 1 — Foundation Phase Plan
```

This phase must be completed before:

```text
Phase 3 — Source Strategy and Reference Playbook
Phase 4 — Acceptance Criteria and Validation Gates
Phase 5 — HTML Packet Template Specification
Phase 6 — Simulation Engine Contract
Phase 7 — Validator and Scoring Specification
Phase 8 — One-Industry Prototype
Phase 9 — Five-Industry Cross-Sector Test
Phase 10 — Twenty-Industry Mass Test and Regression
```

No later phase may claim institutional quality unless it conforms to this data contract.

---

## 3. Core Law

The Industry Intelligence Engine must obey these data laws:

1. Structured dataset is the source of truth.
2. Universal core schema applies to every industry.
3. Optional modules adapt to sector-specific needs.
4. Source ledger and atomic evidence ledger are separate.
5. One source can and should produce many evidence rows.
6. Every material claim must be evidence-linked, derived, assumed, or marked as a visible gap.
7. Value-chain nodes, edges, money flows, and profit pools are mandatory.
8. Company and security exposure mapping is mandatory.
9. Scenario assumptions and simulation outputs must be structured.
10. Risks, falsifiers, opportunity zones, and catalysts must be structured.
11. Missing data must appear in the gap register.
12. No HTML, mass test, scoring, or investment-grade claim can proceed without this contract.

---

## 4. Data Philosophy

### 4.1 Dataset Purpose

The dataset exists to power:

- institutional-grade industry intelligence;
- end-to-end value-chain mapping;
- node economics;
- company and security exposure;
- long/short, pair, and basket opportunity analysis;
- fundamental revenue, margin, valuation, and cash-flow sensitivity;
- quantamental signal tracking;
- event-driven catalyst analysis;
- PE and growth-equity diligence;
- scenario simulation;
- risk, falsifier, and thesis invalidation logic;
- HTML packet generation;
- acceptance criteria and validation scoring.

### 4.2 Source of Truth Rule

The narrative is not the source of truth.

The source of truth is the structured dataset, consisting of:

- canonical JSON dataset;
- table-level CSV exports;
- source ledger;
- atomic evidence ledger;
- scenario assumptions;
- simulation outputs;
- quality-gate records;
- gap register;
- manifest.

The final HTML packet is a view over this data.

### 4.3 Claim Classification Rule

Every material claim must be classified as one of:

| Claim Type | Definition | Requirement |
|---|---|---|
| `fact` | Directly supported by source evidence | Must link to evidence |
| `estimate` | Quantitative estimate based on partial evidence | Must show method and uncertainty |
| `assumption` | Analyst/model/user input used in simulation or reasoning | Must show owner and rationale |
| `derived` | Calculated from other fields | Must show formula and inputs |
| `inference` | Logical interpretation from evidence | Must link to supporting evidence |
| `hypothesis` | Plausible but not proven thesis | Must be labeled and falsifiable |
| `gap` | Missing or insufficient information | Must appear in gap register |

No material claim may exist only as freeform prose.

---

## 5. Universal Dataset Architecture

### 5.1 Required Output Bundle

Every industry run should eventually produce the following bundle:

```text
/industry_packet_<industry_slug>_<run_id>/
  manifest.json
  canonical_dataset.json
  tables/
    industry_boundary.csv
    industry_segments.csv
    source_ledger.csv
    atomic_evidence.csv
    value_chain_nodes.csv
    value_chain_edges.csv
    money_flows.csv
    profit_pools.csv
    cost_structure.csv
    demand_drivers.csv
    end_customers.csv
    supply_constraints.csv
    regulation_policy.csv
    technology_disruption.csv
    company_universe.csv
    security_master.csv
    company_segment_exposure.csv
    financial_sensitivity.csv
    quantamental_signals.csv
    event_catalysts.csv
    scenario_assumptions.csv
    simulation_outputs.csv
    opportunity_zones.csv
    risks_falsifiers.csv
    quality_gates.csv
    gap_register.csv
  reports/
    research_summary.md
    validation_report.md
    simulation_report.md
    quality_report.md
  html/
    index.html
  exports/
    evidence_export.csv
    source_export.csv
    assumptions_export.csv
```

The exact file bundle may evolve, but `manifest.json`, `canonical_dataset.json`, source ledger, atomic evidence, required core tables, gap register, and quality report are mandatory for institutional-grade status.

### 5.2 Canonical Format

The canonical dataset should be JSON because JSON supports nested structures, arrays, metadata, and machine-readable validation.

CSV exports are required for audit, spreadsheet review, and manual inspection.

Markdown reports are explanatory views.

HTML is the interactive presentation layer.

### 5.3 Naming Convention

Tables must use lowercase snake_case.

Examples:

```text
industry_boundary
atomic_evidence
value_chain_nodes
company_segment_exposure
scenario_assumptions
simulation_outputs
risks_falsifiers
```

Fields must use lowercase snake_case.

IDs must use stable prefixes:

| Entity | ID Prefix | Example |
|---|---|---|
| Industry | `ind_` | `ind_semicap_001` |
| Segment | `seg_` | `seg_lithography_001` |
| Source | `src_` | `src_annual_report_asml_2025` |
| Evidence | `ev_` | `ev_000001` |
| Claim | `claim_` | `claim_profit_pool_0007` |
| Node | `node_` | `node_wafer_fab_equipment` |
| Edge | `edge_` | `edge_000042` |
| Company | `co_` | `co_asml` |
| Security | `sec_` | `sec_asml_na` |
| Event | `event_` | `event_export_control_2026_001` |
| Scenario | `scn_` | `scn_bear_001` |
| Assumption | `asm_` | `asm_wfe_growth_base_001` |
| Simulation Output | `sim_` | `sim_000001` |
| Opportunity Zone | `opp_` | `opp_lithography_bottleneck_001` |
| Risk/Falsifier | `risk_` / `false_` | `risk_tariff_001` |
| Gap | `gap_` | `gap_private_market_pricing_001` |
| Quality Gate | `qg_` | `qg_source_coverage_001` |

---

## 6. Field Metadata Law

Every table field must be documented with the following metadata in future detailed schemas:

| Metadata Field | Required? | Meaning |
|---|---:|---|
| `field_name` | Yes | Field name in lowercase snake_case |
| `data_type` | Yes | string, number, enum, boolean, date, array, object, url |
| `requirement_level` | Yes | required, conditional, optional, derived, user_defined |
| `source_requirement` | Yes | source_required, estimate_allowed, assumption_allowed, derived_only |
| `blank_behavior` | Yes | blank_forbidden, blank_allowed_with_gap, optional_blank_allowed |
| `confidence_required` | Yes/Conditional | Whether confidence scoring is needed |
| `unit_required` | Conditional | Required for metrics |
| `currency_required` | Conditional | Required for monetary fields |
| `period_required` | Conditional | Required for metrics/events/time-series |
| `geography_required` | Conditional | Required when geographic scope matters |
| `formula_required` | Conditional | Required for derived fields |
| `downstream_consumers` | Yes | HTML, simulation, validation, scoring, investment_logic |
| `validator_hooks` | Yes | Which validators inspect the field |
| `update_frequency` | Conditional | static, annual, quarterly, monthly, daily, event_driven |

---

## 7. Controlled Enums

### 7.1 Requirement Level

```text
required
conditional
optional
derived
user_defined
```

### 7.2 Source Requirement

```text
source_required
estimate_allowed
assumption_allowed
derived_only
not_applicable
```

### 7.3 Blank Behavior

```text
blank_forbidden
blank_allowed_with_gap
optional_blank_allowed
not_applicable
```

### 7.4 Claim Type

```text
fact
estimate
assumption
derived
inference
hypothesis
gap
```

### 7.5 Confidence Level

```text
very_high
high
medium
low
very_low
unknown
```

### 7.6 Source Quality Tier

```text
tier_1a_official_regulator_or_statistical_agency
tier_1b_company_filing_or_audited_report
tier_2a_trade_association_or_standards_body
tier_2b_exchange_or_transactional_dataset
tier_3_reputable_financial_news_or_industry_publication
tier_4_broker_research_or_market_dataset
tier_5_market_research_summary_or_vendor_report
tier_6_company_marketing_or_management_claim
tier_7_blog_forum_social_or_weak_signal
unknown
```

### 7.7 Evidence Conflict Status

```text
none
conflicting_unresolved
conflicting_resolved
triangulated
needs_followup
```

### 7.8 Exposure Type

```text
direct
indirect
upstream_supplier
downstream_customer
complement
substitute
beneficiary
loser
mixed
uncertain
```

### 7.9 Exposure Direction

```text
benefits
hurt
mixed
neutral
uncertain
```

### 7.10 Materiality

```text
critical
high
medium
low
unknown
```

### 7.11 Maturity Level

```text
level_0_objective_only
level_1_seed_research
level_2_structured_dataset
level_3_investable_packet
level_4_institutional_packet
level_5_world_class_reusable_engine_output
```

### 7.12 Gap Severity

```text
blocker
major
moderate
minor
watch_item
```

### 7.13 Scenario Type

```text
base
bull
bear
shock
structural_transition
custom
```

### 7.14 Event Type

```text
earnings
guidance
investor_day
regulation
litigation
m_and_a
spin_off
restructuring
tariff
subsidy
approval
reimbursement
contract_award
contract_loss
capacity_addition
capacity_shutdown
product_launch
bankruptcy
distress
labor_action
supply_disruption
geopolitical
technology_inflection
other
```

---

## 8. Mandatory Core Tables

The following tables are mandatory for the universal contract.

Detailed table-level schemas may be expanded in later implementation files, but these tables are the canonical required architecture.

---

## 8.1 `industry_boundary`

### Purpose

Defines what industry the engine is analyzing, what is included, what is excluded, and what assumptions are being made.

No industry packet is valid without this table.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `industry_id` | string | required | Stable industry ID |
| `industry_name_input` | string | required | User-provided industry name |
| `resolved_industry_name` | string | required | Engine-resolved canonical name |
| `definition` | string | required | Operational definition |
| `included_scope` | array | required | Included products/services/activities |
| `excluded_scope` | array | required | Explicit exclusions |
| `adjacent_industries` | array | conditional | Upstream/downstream/substitute/complement areas |
| `geographic_scope` | string/array | required | Global/default or specified geography |
| `time_horizon` | string | required | Default investment horizon, usually month-to-year |
| `investability_scope` | string | required | Public, private, both, unavailable, unknown |
| `boundary_confidence` | enum | required | Confidence level |
| `source_ids` | array | conditional | Sources supporting the definition |
| `gap_ids` | array | conditional | Boundary-related gaps |

### Hard Rules

- Ambiguous industry names must be resolved with explicit assumptions.
- Excluded areas must be visible.
- Adjacent industries must not be silently mixed into the core industry.

---

## 8.2 `industry_segments`

### Purpose

Breaks the industry into economically meaningful segments.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `segment_id` | string | required | Stable segment ID |
| `industry_id` | string | required | Parent industry |
| `segment_name` | string | required | Segment name |
| `segment_dimension` | enum/string | required | product, customer, geography, channel, technology, price_tier, regulation, business_model |
| `definition` | string | required | Segment definition |
| `included_scope` | array | conditional | Segment inclusions |
| `excluded_scope` | array | conditional | Segment exclusions |
| `maturity_stage` | enum | conditional | emerging, growth, mature, declining, cyclical, disrupted |
| `attractiveness_preliminary` | enum | conditional | high, medium, low, unknown |
| `source_ids` | array | conditional | Evidence sources |
| `evidence_ids` | array | conditional | Supporting evidence |
| `gap_ids` | array | conditional | Segment gaps |

### Hard Rules

- Industries must not be treated as one homogeneous blob.
- Segments must be mapped later to value-chain nodes, companies, scenarios, and opportunities.

---

## 8.3 `source_ledger`

### Purpose

Stores durable metadata for every source used.

This is the trust backbone of the engine.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `source_id` | string | required | Stable source ID |
| `url` | url/string | required when available | Canonical URL or local source path |
| `title` | string | required | Source title |
| `publisher` | string | required | Publishing entity |
| `author` | string | optional | Author if available |
| `publication_date` | date/string | conditional | Publication date |
| `accessed_at` | date | required | Access date |
| `source_type` | enum/string | required | Filing, regulator, trade, news, market research, etc. |
| `source_quality_tier` | enum | required | Source quality tier |
| `geographic_scope` | string/array | conditional | Source geography |
| `industry_relevance` | enum | required | high, medium, low, unknown |
| `freshness_status` | enum | required | current, recent, stale_but_structural, stale, unknown |
| `snapshot_path` | string | optional | Local archived snapshot path if available |
| `source_hash` | string | optional | Hash if snapshot exists |
| `notes` | string | optional | Source caveats |

### Hard Rules

- Temporary chat references are not durable source IDs.
- URL alone is insufficient.
- Weak sources may be logged but must not serve as primary support for material investment conclusions.

---

## 8.4 `atomic_evidence`

### Purpose

Stores atomic, claim-level evidence extracted from sources.

One source can and should generate many evidence rows.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `evidence_id` | string | required | Stable evidence ID |
| `source_id` | string | required | Linked source |
| `claim_id` | string | conditional | Linked claim |
| `claim_text` | string | required | Atomic claim or data point |
| `claim_type` | enum | required | fact, estimate, assumption, derived, inference, hypothesis, gap |
| `metric_name` | string | conditional | Metric name if quantitative |
| `metric_value` | number/string | conditional | Metric value |
| `metric_unit` | string | conditional | Unit |
| `metric_period` | string/date | conditional | Period/date |
| `metric_geography` | string | conditional | Geography |
| `metric_definition` | string | conditional | Definition/denominator |
| `source_location` | string | required when possible | Page, table, section, paragraph, timestamp |
| `exact_quote_short` | string | optional | Short quote or table excerpt where compliant |
| `paraphrase` | string | required | Engine paraphrase |
| `linked_table` | string | required | Table supported by the evidence |
| `linked_field` | string | conditional | Specific field supported |
| `confidence_level` | enum | required | Evidence confidence |
| `source_quality_tier` | enum | required | Inherited from source or adjusted |
| `conflict_status` | enum | required | none, conflicting, resolved, etc. |
| `extraction_method` | enum/string | required | manual, model_extracted, table_extracted, API, calculation |
| `caveat` | string | optional | Caveat/limitation |

### Hard Rules

- One source summary is not enough.
- Material claims must link to atomic evidence.
- Conflicting evidence must be shown or resolved.
- Inferences must not be disguised as facts.

---

## 8.5 `value_chain_nodes`

### Purpose

Defines each economically meaningful node in the industry value chain.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `node_id` | string | required | Stable node ID |
| `industry_id` | string | required | Parent industry |
| `node_name` | string | required | Node name |
| `node_type` | enum/string | required | input, supplier, manufacturer, distributor, service, platform, customer, regulator, complement, substitute |
| `node_description` | string | required | What the node does |
| `segment_ids` | array | conditional | Related segments |
| `economic_role` | string | required | How value is created/captured |
| `revenue_model` | string | conditional | How node participants make money |
| `margin_profile` | string/enum | conditional | high, medium, low, variable, unknown |
| `pricing_power` | enum | conditional | high, medium, low, unknown |
| `capex_intensity` | enum | conditional | high, medium, low, unknown |
| `cyclicality` | enum | conditional | high, medium, low, unknown |
| `bottleneck_status` | enum | conditional | bottleneck, potential_bottleneck, not_bottleneck, unknown |
| `source_ids` | array | conditional | Supporting sources |
| `evidence_ids` | array | conditional | Supporting evidence |
| `gap_ids` | array | conditional | Gaps |

### Hard Rules

- Value-chain nodes must contain economics, not just labels.
- Nodes must later feed HTML graph, company exposure, scenario simulation, and opportunity ranking.

---

## 8.6 `value_chain_edges`

### Purpose

Defines relationships and flows between value-chain nodes.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `edge_id` | string | required | Stable edge ID |
| `industry_id` | string | required | Parent industry |
| `from_node_id` | string | required | Starting node |
| `to_node_id` | string | required | Ending node |
| `flow_type` | enum/string | required | physical, money, data, regulatory, service, contract, risk |
| `flow_description` | string | required | Explanation of the relationship |
| `directionality` | enum | required | one_way, two_way, circular, unknown |
| `materiality` | enum | required | critical, high, medium, low, unknown |
| `switching_cost` | enum | conditional | high, medium, low, unknown |
| `dependency_risk` | enum | conditional | high, medium, low, unknown |
| `source_ids` | array | conditional | Supporting sources |
| `evidence_ids` | array | conditional | Supporting evidence |

### Hard Rules

- Arrows must have meaning.
- Physical, money, data, regulatory, and risk flows must not be collapsed into one generic relationship.

---

## 8.7 `money_flows`

### Purpose

Maps who pays whom, for what, when, and how economic value moves through the chain.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `money_flow_id` | string | required | Stable money-flow ID |
| `industry_id` | string | required | Parent industry |
| `payer_node_id` | string | required | Paying node |
| `receiver_node_id` | string | required | Receiving node |
| `payment_for` | string | required | Product/service/payment reason |
| `revenue_model` | string | conditional | Subscription, transaction fee, unit sale, usage, project, service, licensing, etc. |
| `pricing_basis` | string | conditional | Per unit, per transaction, per seat, per ton, regulated rate, negotiated contract, etc. |
| `payment_timing` | string | conditional | Upfront, recurring, milestone, usage-based, deferred |
| `margin_implication` | string | conditional | How this flow affects margins |
| `source_ids` | array | conditional | Supporting sources |
| `evidence_ids` | array | conditional | Supporting evidence |

### Hard Rules

- Investment-grade packets cannot rely only on physical value chain.
- Cash economics must be explicit.

---

## 8.8 `profit_pools`

### Purpose

Identifies where profits accrue in the value chain and how they may shift over time.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `profit_pool_id` | string | required | Stable profit pool ID |
| `industry_id` | string | required | Parent industry |
| `node_id` | string | required | Linked value-chain node |
| `segment_id` | string | conditional | Linked segment |
| `profit_pool_description` | string | required | Description |
| `relative_attractiveness` | enum | required | high, medium, low, unknown |
| `margin_level` | enum/string | conditional | high, medium, low, variable, unknown |
| `growth_direction` | enum | conditional | expanding, stable, shrinking, volatile, unknown |
| `drivers` | array | conditional | Profit drivers |
| `risks` | array | conditional | Profit risks |
| `evidence_ids` | array | conditional | Supporting evidence |
| `gap_ids` | array | conditional | Gaps |

### Hard Rules

- Profit pools must map to nodes.
- Revenue size alone does not equal profit attractiveness.

---

## 8.9 `cost_structure`

### Purpose

Stores cost drivers and margin sensitivity by node, company, or segment.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `cost_id` | string | required | Stable cost ID |
| `industry_id` | string | required | Parent industry |
| `node_id` | string | conditional | Linked node |
| `company_id` | string | conditional | Linked company |
| `cost_category` | string | required | Labor, raw material, energy, logistics, R&D, capex, SG&A, depreciation, financing, etc. |
| `cost_behavior` | enum | conditional | fixed, variable, semi_variable, cyclical, unknown |
| `materiality` | enum | required | critical, high, medium, low, unknown |
| `sensitivity_direction` | enum | conditional | margin_positive_when_down, margin_negative_when_up, mixed, unknown |
| `source_ids` | array | conditional | Supporting sources |
| `evidence_ids` | array | conditional | Supporting evidence |

### Hard Rules

- Margin analysis cannot exist without cost structure.
- Input-cost sensitivity must be explicit where material.

---

## 8.10 `demand_drivers`

### Purpose

Captures durable and cyclical demand drivers.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `demand_driver_id` | string | required | Stable demand driver ID |
| `industry_id` | string | required | Parent industry |
| `driver_name` | string | required | Name of demand driver |
| `driver_type` | enum/string | required | structural, cyclical, regulatory, demographic, technology, replacement, macro, customer_behavior |
| `description` | string | required | Explanation |
| `affected_segments` | array | conditional | Segment IDs |
| `affected_nodes` | array | conditional | Node IDs |
| `direction` | enum | required | positive, negative, mixed, uncertain |
| `time_horizon` | string | required | 1-3m, 3-12m, 1-3y, long-term |
| `evidence_ids` | array | conditional | Supporting evidence |
| `confidence_level` | enum | required | Confidence |

### Hard Rules

- Demand claims must connect to customers, segments, and scenarios.
- Generic TAM growth is insufficient.

---

## 8.11 `end_customers`

### Purpose

Identifies final customers and their behavior, even when the direct customer is an intermediary.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `customer_id` | string | required | Stable customer ID |
| `industry_id` | string | required | Parent industry |
| `customer_group` | string | required | Final customer group |
| `direct_or_final` | enum | required | direct, final, both, unknown |
| `needs_or_jobs_to_be_done` | string | conditional | Customer need |
| `purchase_driver` | string | conditional | Why customer buys |
| `price_sensitivity` | enum | conditional | high, medium, low, unknown |
| `switching_cost` | enum | conditional | high, medium, low, unknown |
| `demand_driver_ids` | array | conditional | Linked demand drivers |
| `source_ids` | array | conditional | Sources |
| `evidence_ids` | array | conditional | Evidence |

### Hard Rules

- The packet cannot stop at the direct buyer when final demand drives the industry.

---

## 8.12 `supply_constraints`

### Purpose

Captures capacity, scarcity, bottlenecks, input limits, logistics constraints, and dependency risks.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `constraint_id` | string | required | Stable constraint ID |
| `industry_id` | string | required | Parent industry |
| `constraint_name` | string | required | Constraint name |
| `constraint_type` | enum/string | required | capacity, labor, input, technology, regulation, logistics, capital, geopolitical, supplier_concentration |
| `affected_node_id` | string | conditional | Linked node |
| `affected_segment_id` | string | conditional | Linked segment |
| `severity` | enum | required | critical, high, medium, low, unknown |
| `duration` | string | conditional | Temporary, cyclical, structural, unknown |
| `beneficiaries` | array | conditional | Companies/nodes that benefit |
| `losers` | array | conditional | Companies/nodes hurt |
| `evidence_ids` | array | conditional | Evidence |
| `gap_ids` | array | conditional | Gaps |

### Hard Rules

- Bottlenecks are central to alpha and must be structured.

---

## 8.13 `regulation_policy`

### Purpose

Tracks regulation, policy, standards, litigation, tariffs, subsidies, reimbursement, or legal frameworks that affect economics.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `regulation_id` | string | required | Stable regulation/policy ID |
| `industry_id` | string | required | Parent industry |
| `regulation_name` | string | required | Name |
| `jurisdiction` | string | required | Geography/legal authority |
| `regulation_type` | enum/string | required | rule, law, tariff, subsidy, standard, litigation, reimbursement, approval, restriction |
| `status` | enum/string | required | proposed, active, pending, expired, uncertain |
| `effective_date` | date/string | conditional | Effective date |
| `affected_nodes` | array | conditional | Node IDs |
| `affected_companies` | array | conditional | Company IDs |
| `economic_impact` | string | conditional | Impact description |
| `event_id` | string | conditional | Linked catalyst event |
| `source_ids` | array | conditional | Sources |
| `evidence_ids` | array | conditional | Evidence |

### Hard Rules

- Regulation is mandatory when material.
- Policy should be embedded in value-chain economics, not isolated as generic commentary.

---

## 8.14 `technology_disruption`

### Purpose

Tracks technologies, process changes, substitutes, and innovation cycles that can shift profit pools.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `technology_id` | string | required | Stable technology ID |
| `industry_id` | string | required | Parent industry |
| `technology_name` | string | required | Technology/disruption name |
| `description` | string | required | Explanation |
| `maturity_stage` | enum/string | conditional | emerging, scaling, mainstream, declining, unknown |
| `affected_nodes` | array | conditional | Node IDs |
| `affected_segments` | array | conditional | Segment IDs |
| `winners` | array | conditional | Beneficiary companies/nodes |
| `losers` | array | conditional | Disrupted companies/nodes |
| `time_horizon` | string | conditional | Expected timing |
| `evidence_ids` | array | conditional | Evidence |

### Hard Rules

- Technology is mandatory where it affects economics, barriers, substitution, or profit-pool migration.

---

## 8.15 `company_universe`

### Purpose

Maps material public and private companies involved in the value chain.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `company_id` | string | required | Stable company ID |
| `company_name` | string | required | Company name |
| `ownership_type` | enum/string | required | public, private, sponsor_owned, state_owned, subsidiary, unknown |
| `headquarters_country` | string | conditional | HQ country |
| `business_description` | string | required | Business description |
| `value_chain_node_ids` | array | required | Nodes where company participates |
| `segment_ids` | array | conditional | Segments |
| `industry_relevance` | enum | required | high, medium, low, unknown |
| `source_ids` | array | conditional | Sources |
| `evidence_ids` | array | conditional | Evidence |
| `gap_ids` | array | conditional | Gaps |

### Hard Rules

- Company lists without value-chain node exposure are invalid.
- Private companies must be included where material.

---

## 8.16 `security_master`

### Purpose

Maps investable securities to companies.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `security_id` | string | required | Stable security ID |
| `company_id` | string | required | Linked company |
| `ticker` | string | conditional | Ticker |
| `exchange` | string | conditional | Exchange |
| `country` | string | conditional | Listing country |
| `currency` | string | conditional | Trading/reporting currency |
| `security_type` | enum/string | required | equity, ADR, preferred, bond, ETF, private, unavailable |
| `liquidity_profile` | enum/string | optional | high, medium, low, unknown |
| `source_ids` | array | conditional | Sources |

### Hard Rules

- Security mapping must be separate from company mapping.
- One company can have multiple securities.
- Not every company is investable; unavailable securities must be labeled.

---

## 8.17 `company_segment_exposure`

### Purpose

Quantifies or qualitatively maps company exposure to industry segments and value-chain nodes.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `exposure_id` | string | required | Stable exposure ID |
| `company_id` | string | required | Company |
| `security_id` | string | conditional | Security |
| `industry_id` | string | required | Industry |
| `segment_id` | string | conditional | Segment |
| `node_id` | string | conditional | Node |
| `exposure_type` | enum | required | direct, indirect, supplier, customer, substitute, etc. |
| `exposure_direction` | enum | required | benefits, hurt, mixed, neutral, uncertain |
| `exposure_magnitude` | enum | required | high, medium, low, unknown |
| `revenue_exposure_pct` | number | optional | Revenue exposure if known |
| `margin_exposure_pct` | number | optional | Margin exposure if known |
| `geographic_exposure` | string/array | optional | Geography |
| `evidence_ids` | array | conditional | Evidence |
| `confidence_level` | enum | required | Confidence |

### Hard Rules

- Diversified companies must be exposure-scored.
- Exposure without direction and magnitude is insufficient.

---

## 8.18 `financial_sensitivity`

### Purpose

Bridges industry changes to company financial implications.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `financial_sensitivity_id` | string | required | Stable ID |
| `company_id` | string | conditional | Company |
| `security_id` | string | conditional | Security |
| `node_id` | string | conditional | Node |
| `segment_id` | string | conditional | Segment |
| `driver_name` | string | required | Revenue, price, volume, margin, cost, capex, working capital, valuation multiple, etc. |
| `driver_type` | enum/string | required | revenue, cost, margin, capex, working_capital, valuation, cash_flow |
| `sensitivity_direction` | enum | required | positive, negative, mixed, unknown |
| `sensitivity_magnitude` | enum/string | conditional | high, medium, low, numeric if known |
| `formula_or_logic` | string | conditional | Formula or reasoning |
| `linked_assumption_ids` | array | conditional | Scenario assumptions |
| `evidence_ids` | array | conditional | Evidence |
| `confidence_level` | enum | required | Confidence |

### Hard Rules

- Industry insight must bridge to earnings/cash flow when investable securities exist.
- Financial sensitivity must not be hand-wavy.

---

## 8.19 `quantamental_signals`

### Purpose

Defines measurable indicators that can support, challenge, or time the thesis.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `signal_id` | string | required | Stable signal ID |
| `industry_id` | string | required | Parent industry |
| `signal_name` | string | required | Signal name |
| `signal_definition` | string | required | What it measures |
| `formula` | string | conditional | Formula if derived |
| `source_id` | string | conditional | Data source |
| `frequency` | enum/string | conditional | daily, weekly, monthly, quarterly, annual, event_driven |
| `lag` | string | conditional | Publication/availability lag |
| `current_value` | number/string | optional | Current reading |
| `history_available` | boolean/string | required | Whether history exists |
| `point_in_time_status` | enum/string | conditional | point_in_time, revised, unknown |
| `backtest_status` | enum/string | required | tested, untested, insufficient_data, hypothesis_only |
| `expected_direction` | enum | conditional | positive, negative, mixed, unknown |
| `affected_nodes` | array | conditional | Node IDs |
| `affected_companies` | array | conditional | Company IDs |
| `confidence_level` | enum | required | Confidence |

### Hard Rules

- Signals must have definitions, freshness, and data-quality status.
- Untested signals must be labeled as untested.

---

## 8.20 `event_catalysts`

### Purpose

Captures timing events that can change valuation, expectations, economics, or thesis probability.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `event_id` | string | required | Stable event ID |
| `industry_id` | string | required | Parent industry |
| `event_name` | string | required | Event name |
| `event_type` | enum | required | earnings, regulation, M&A, tariff, subsidy, etc. |
| `announced_date` | date/string | conditional | Announced date |
| `expected_date` | date/string | conditional | Expected future date |
| `actual_date` | date/string | conditional | Actual date if happened |
| `date_uncertainty` | string | conditional | Known/estimated/unknown |
| `affected_nodes` | array | conditional | Node IDs |
| `affected_companies` | array | conditional | Company IDs |
| `probability` | number/string | conditional | Probability estimate |
| `impact_magnitude` | enum | required | high, medium, low, unknown |
| `thesis_implication` | enum/string | conditional | confirms, challenges, invalidates, accelerates, delays |
| `source_ids` | array | conditional | Sources |
| `evidence_ids` | array | conditional | Evidence |
| `falsifier_ids` | array | conditional | Related falsifiers |

### Hard Rules

- Month-to-year research requires a timing path.
- Rumors must not be treated as confirmed events.

---

## 8.21 `scenario_assumptions`

### Purpose

Stores all assumptions used in scenarios and simulation.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `assumption_id` | string | required | Stable assumption ID |
| `scenario_id` | string | required | Scenario |
| `industry_id` | string | required | Parent industry |
| `assumption_name` | string | required | Assumption name |
| `variable_name` | string | required | Variable controlled |
| `variable_value` | number/string | required | Value |
| `unit` | string | required when metric | Unit |
| `range_low` | number/string | conditional | Low range |
| `range_high` | number/string | conditional | High range |
| `assumption_owner` | enum | required | source_backed, analyst_estimate, user_defined, model_default, gap |
| `source_ids` | array | conditional | Sources |
| `evidence_ids` | array | conditional | Evidence |
| `affected_nodes` | array | conditional | Node IDs |
| `affected_companies` | array | conditional | Company IDs |
| `confidence_level` | enum | required | Confidence |

### Hard Rules

- Simulation assumptions cannot be hidden.
- Every assumption must be source-backed, estimated, user-defined, model-default, or gap-labeled.

---

## 8.22 `simulation_outputs`

### Purpose

Stores results from scenario and sensitivity logic.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `simulation_output_id` | string | required | Stable output ID |
| `scenario_id` | string | required | Scenario |
| `industry_id` | string | required | Parent industry |
| `output_type` | enum/string | required | node_ranking, company_ranking, financial_sensitivity, thesis_break, opportunity_change |
| `affected_node_id` | string | conditional | Node |
| `affected_company_id` | string | conditional | Company |
| `affected_security_id` | string | conditional | Security |
| `direction` | enum | required | positive, negative, mixed, neutral, uncertain |
| `magnitude` | enum/string | conditional | high, medium, low, numeric if available |
| `formula_or_logic` | string | required | Calculation or reasoning |
| `input_assumption_ids` | array | required | Linked assumptions |
| `output_explanation` | string | required | Narrative explanation |
| `confidence_level` | enum | required | Confidence |

### Hard Rules

- Simulation outputs must be stored, not only displayed in UI.
- Formulas or logic must be traceable.

---

## 8.23 `opportunity_zones`

### Purpose

Structures the final investment-research implications.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `opportunity_id` | string | required | Stable opportunity ID |
| `industry_id` | string | required | Parent industry |
| `opportunity_name` | string | required | Opportunity label |
| `opportunity_type` | enum/string | required | node, segment, company_group, security_basket, event_setup, pair_trade, avoid_area |
| `linked_nodes` | array | conditional | Node IDs |
| `linked_segments` | array | conditional | Segment IDs |
| `linked_companies` | array | conditional | Company IDs |
| `linked_securities` | array | conditional | Security IDs |
| `investment_implication` | enum/string | required | long_research, short_research, pair_research, basket_research, avoid, watchlist |
| `upside_logic` | string | required | Upside case |
| `downside_logic` | string | required | Downside case |
| `time_horizon` | string | required | 1-3m, 3-12m, 1-3y |
| `catalyst_ids` | array | conditional | Linked catalysts |
| `valuation_context` | string | conditional | Valuation note |
| `evidence_strength` | enum | required | high, medium, low, unknown |
| `confidence_level` | enum | required | Confidence |
| `falsifier_ids` | array | required | Kill criteria |
| `risk_ids` | array | conditional | Risks |
| `scenario_output_ids` | array | conditional | Simulation links |

### Hard Rules

- Opportunity zones are not personal financial advice.
- No opportunity zone may be upside-only.
- Falsifiers are mandatory.

---

## 8.24 `risks_falsifiers`

### Purpose

Stores structured risks and measurable thesis invalidation criteria.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `risk_falsifier_id` | string | required | Stable ID |
| `industry_id` | string | required | Parent industry |
| `record_type` | enum | required | risk, falsifier, both |
| `name` | string | required | Name |
| `risk_type` | enum/string | required | demand, supply, pricing, competition, regulation, technology, macro, rates, FX, commodity, execution, accounting, valuation, liquidity, geopolitical |
| `description` | string | required | Explanation |
| `affected_nodes` | array | conditional | Node IDs |
| `affected_companies` | array | conditional | Company IDs |
| `affected_opportunities` | array | conditional | Opportunity IDs |
| `probability` | number/string | conditional | Probability estimate |
| `impact_magnitude` | enum | required | high, medium, low, unknown |
| `measurable_threshold` | string | conditional | What would prove/falsify the thesis |
| `monitoring_signal_ids` | array | conditional | Signals to watch |
| `evidence_ids` | array | conditional | Evidence |

### Hard Rules

- Every thesis must have falsifiers.
- Falsifiers should be measurable whenever possible.

---

## 8.25 `quality_gates`

### Purpose

Stores machine-readable quality status by gate.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `quality_gate_id` | string | required | Stable gate ID |
| `industry_id` | string | required | Parent industry |
| `gate_name` | string | required | Gate name |
| `gate_category` | enum/string | required | source, evidence, schema, value_chain, company, simulation, citation, gap, investment_logic, UI |
| `status` | enum | required | pass, fail, warning, not_applicable, not_tested |
| `score` | number | conditional | Numeric score if available |
| `threshold` | number/string | conditional | Passing threshold |
| `failure_reason` | string | conditional | Reason if fail/warning |
| `affected_tables` | array | conditional | Tables affected |
| `affected_fields` | array | conditional | Fields affected |
| `gap_ids` | array | conditional | Linked gaps |
| `validator_name` | string | conditional | Validator producing status |

### Hard Rules

- No institutional score without quality gates.
- Gate failures must be visible.

---

## 8.26 `gap_register`

### Purpose

Stores missing, insufficient, stale, contradictory, or unavailable data.

### Required Fields

| Field | Type | Requirement | Description |
|---|---|---|---|
| `gap_id` | string | required | Stable gap ID |
| `industry_id` | string | required | Parent industry |
| `gap_name` | string | required | Gap name |
| `missing_table` | string | conditional | Table affected |
| `missing_field` | string | conditional | Field affected |
| `gap_reason` | string | required | Why gap exists |
| `severity` | enum | required | blocker, major, moderate, minor, watch_item |
| `affected_output` | array | required | HTML, simulation, scoring, opportunity, etc. |
| `required_source_type` | string | conditional | Source needed to close gap |
| `next_action` | string | required | How to close gap |
| `blocks_institutional_status` | boolean | required | Whether blocker |
| `created_at` | date/string | required | Created date |
| `status` | enum/string | required | open, in_progress, closed, waived |

### Hard Rules

- Missing data must never be hidden.
- Blocker gaps prevent investment-grade status.

---

## 9. Conditional Optional Modules

The universal core schema applies to all industries. Optional modules are conditionally required when material.

Examples:

| Module | Required When |
|---|---|
| `patent_landscape` | Technology/patent intensity matters |
| `clinical_trials` | Pharma, biotech, medtech, diagnostics |
| `reimbursement_codes` | Healthcare payment/reimbursement matters |
| `commodity_inputs` | Raw materials drive margins |
| `capacity_projects` | Capacity additions/shutdowns affect supply |
| `trade_flows` | Import/export, tariffs, or supply chains matter |
| `installed_base` | Replacement cycles or service revenue matter |
| `regulatory_approvals` | Approvals create catalysts or barriers |
| `reserves_resources` | Energy, mining, materials |
| `subscriber_cohorts` | Software, media, telecom, consumer subscription |
| `merchant_or_transaction_flows` | Payments, marketplaces, fintech |
| `real_estate_or_location_units` | Restaurants, retail, logistics, towers, infrastructure |
| `project_backlog` | Engineering, construction, industrial equipment |
| `order_book_shipments` | Manufacturing, aerospace, semicap, industrials |

Optional does not mean unimportant. It means conditional on materiality.

If a conditional module is material but not filled, the missing module must appear in `gap_register`.

---

## 10. Role-Specific Data Coverage

The dataset must satisfy the following professional lenses.

### 10.1 Long/Short Equity PM Lens

Required data coverage:

- opportunity zones;
- long/short/pair/basket implications;
- exposed securities;
- upside/downside logic;
- catalyst path;
- valuation context;
- crowding/liquidity where available;
- risks and falsifiers.

Reject: bullish sector story without investable mapping.

### 10.2 Fundamental Equity Analyst Lens

Required data coverage:

- segment revenue and exposure;
- margin drivers;
- unit economics;
- cost structure;
- capex intensity;
- working capital;
- accounting risk;
- earnings/cash-flow sensitivity;
- valuation sensitivity.

Reject: TAM-only analysis.

### 10.3 Senior Quantamental Data Lead Lens

Required data coverage:

- structured signal definitions;
- formulas;
- freshness;
- source quality;
- frequency;
- point-in-time status;
- backtest status;
- signal-to-node/company mapping.

Reject: narrative charting with no data lineage.

### 10.4 Event-Driven Special Situations PM Lens

Required data coverage:

- event/catalyst records;
- dates and uncertainty;
- probability and impact;
- affected nodes/companies/securities;
- thesis implication;
- falsifier logic;
- source support.

Reject: random news summary.

### 10.5 Growth Equity / PE Sector Principal Lens

Required data coverage:

- market map;
- private companies;
- fragmentation/consolidation;
- unit economics;
- retention/churn where relevant;
- pricing model;
- sponsor-owned platforms;
- strategic buyer/exit logic;
- diligence questions.

Reject: public-equity-only view.

---

## 11. Quality Hook Requirements

Every required table must eventually support machine-readable validation.

Minimum quality hooks:

| Quality Area | Required Hook |
|---|---|
| Source coverage | Count and quality tier of sources by table/claim |
| Evidence density | Atomic evidence rows by field/table/claim |
| Schema completeness | Required fields present and nonblank |
| Value-chain completeness | Nodes, edges, money flows, final customer path |
| Company exposure | Companies mapped to nodes/segments/securities |
| Simulation readiness | Assumptions and outputs present |
| Citation coverage | Material claims linked to evidence |
| Conflict handling | Contradictions logged/resolved |
| Gap visibility | Missing fields appear in gap register |
| Investment logic | Opportunities include upside, downside, catalysts, risks, falsifiers |

The detailed validator implementation belongs to `INDUSTRY_VALIDATOR_AND_SCORING_SPEC.md`, but this contract must expose the fields validators need.

---

## 12. Maturity-Level Data Expectations

### Level 0 — Objective Only

- Goal exists.
- No dataset required.
- Not research output.

### Level 1 — Seed Research

Minimum:

- industry boundary;
- preliminary segments;
- source ledger;
- atomic evidence started;
- high-level value-chain nodes;
- initial gaps.

Must be labeled incomplete.

### Level 2 — Structured Dataset

Minimum:

- required core tables exist;
- source ledger and atomic evidence populated;
- value-chain nodes and edges structured;
- gaps explicit;
- company universe started.

Not yet necessarily investable.

### Level 3 — Investable Packet

Minimum:

- company/security exposure;
- money flows;
- profit pools;
- risks/falsifiers;
- catalysts;
- preliminary financial sensitivity;
- quality gates mostly passing.

Can support research implications but not full institutional quality.

### Level 4 — Institutional Packet

Minimum:

- high source coverage;
- high atomic evidence density;
- complete value chain;
- company/security exposure;
- simulation assumptions and outputs;
- opportunity ranking;
- quantamental/event/fundamental/PE lenses;
- quality gates passing or clearly justified.

This is the first level that can be called investment-grade.

### Level 5 — World-Class Reusable Engine Output

Minimum:

- repeated cross-industry validation;
- regression-tested validators;
- durable source memory;
- reusable evidence ledger;
- mature simulation model;
- role-specific quality gates;
- benchmarked output consistency.

---

## 13. Non-Negotiable Failure Conditions

A packet cannot be investment-grade if any of the following are true:

1. No clear industry boundary.
2. No durable source ledger.
3. No atomic evidence ledger.
4. One source summary is treated as one evidence row.
5. No value-chain nodes.
6. No value-chain edges.
7. No money-flow logic.
8. No profit-pool mapping.
9. No company universe.
10. No company/security exposure logic.
11. No risk/falsifier structure.
12. No catalyst/event structure.
13. Simulation assumptions are hidden.
14. Simulation outputs are not stored.
15. Material claims are unsupported.
16. Missing data is hidden.
17. Quality score ignores evidence density.
18. Schema version is unknown.
19. State or manifest is inconsistent.
20. Output claims guaranteed profit or personal financial advice.

---

## 14. Source and Evidence Minimums

Exact thresholds are finalized in the Source Strategy and Acceptance Criteria phases, but this contract sets the baseline principle:

- Source count is not equal to evidence density.
- One source can produce many evidence rows.
- Evidence must be atomic, source-located, confidence-labeled, and field-linked.
- Material investment claims require evidence, derivation, explicit assumption, or visible gap.

Preliminary minimum guidance:

| Maturity | Source Expectation | Evidence Expectation |
|---|---:|---:|
| Seed | 8+ source candidates where possible | 30+ atomic evidence rows |
| Investable | 12–20+ sources depending on industry complexity | 100+ atomic evidence rows where possible |
| Institutional | High-quality source coverage across all material fields | 250+ atomic evidence rows where possible |

These are not final acceptance thresholds. They are structural expectations.

---

## 15. Simulation Data Hook

This contract does not define the full simulation engine. That belongs to `INDUSTRY_SIMULATION_ENGINE_CONTRACT.md`.

However, simulation readiness requires:

- `scenario_assumptions` populated;
- `simulation_outputs` populated;
- assumptions linked to sources, estimates, user inputs, or gaps;
- assumptions linked to affected nodes and companies where possible;
- outputs linked to assumptions;
- thesis invalidation thresholds stored in `risks_falsifiers`;
- formulas or model logic recorded for derived results.

Simulation may not be a decorative UI element. It must be data-backed.

---

## 16. HTML Data Hook

This contract does not define the HTML design. That belongs to `INDUSTRY_HTML_PACKET_TEMPLATE_SPEC.md`.

However, HTML packet generation must consume this dataset.

Required HTML sections must be backed by tables:

| HTML Section | Primary Tables |
|---|---|
| Executive Investment View | `opportunity_zones`, `quality_gates`, `risks_falsifiers` |
| Industry Boundary | `industry_boundary`, `industry_segments` |
| Value Chain | `value_chain_nodes`, `value_chain_edges`, `money_flows` |
| Node Economics | `value_chain_nodes`, `profit_pools`, `cost_structure` |
| Company Exposure | `company_universe`, `security_master`, `company_segment_exposure` |
| Demand | `demand_drivers`, `end_customers` |
| Supply/Bottlenecks | `supply_constraints`, `value_chain_nodes` |
| Regulation | `regulation_policy`, `event_catalysts` |
| Technology | `technology_disruption` |
| Financial Sensitivity | `financial_sensitivity`, `scenario_assumptions` |
| Quant Signals | `quantamental_signals` |
| Catalysts | `event_catalysts` |
| Scenario Simulator | `scenario_assumptions`, `simulation_outputs` |
| Opportunity Zones | `opportunity_zones`, `risks_falsifiers` |
| PE/Growth Diligence | `company_universe`, optional PE/private modules |
| Evidence | `source_ledger`, `atomic_evidence` |
| Quality Report | `quality_gates`, `gap_register` |

HTML must not hide missing data. Missing data must point to `gap_register`.

---

## 17. Output Manifest Requirements

Every output bundle must include a `manifest.json` with at least:

| Field | Required? | Description |
|---|---:|---|
| `run_id` | Yes | Unique run ID |
| `industry_id` | Yes | Industry ID |
| `industry_name` | Yes | Resolved industry name |
| `schema_version` | Yes | Data contract/schema version |
| `template_version` | Conditional | HTML template version |
| `simulation_model_version` | Conditional | Simulation model version |
| `created_at` | Yes | Creation timestamp |
| `source_count` | Yes | Count of logged sources |
| `evidence_count` | Yes | Count of atomic evidence rows |
| `required_table_count` | Yes | Number of required tables |
| `completed_required_table_count` | Yes | Completed required tables |
| `gap_count` | Yes | Count of open gaps |
| `blocker_gap_count` | Yes | Count of blocker gaps |
| `quality_gate_summary` | Yes | Pass/fail summary |
| `maturity_level` | Yes | Current maturity level |
| `artifact_paths` | Yes | Paths to generated files |

---

## 18. Schema Versioning Law

Schema changes must be versioned.

No silent schema drift is allowed.

Version changes should document:

- fields added;
- fields removed;
- fields renamed;
- data types changed;
- enum values changed;
- validator implications;
- backward compatibility notes.

Any generated packet must declare which schema version it used.

---

## 19. Compliance and Investment Integrity

This dataset supports institutional research and decision support. It must not claim guaranteed profit or give personalized financial advice.

Required integrity rules:

- no unsupported investment conclusions;
- no hidden assumptions;
- no hidden missing data;
- no nonpublic material information;
- no rumor treated as fact;
- no valuation-insensitive opportunity ranking;
- no thesis without risks and falsifiers;
- no institutional-quality claim without validation.

---

## 20. Phase 2 Completion Criteria

Phase 2 is complete when:

1. This file is generated and approved.
2. This file is uploaded to active Project Sources.
3. The active Project Sources contain:
   - `INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md`
   - `INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md`
   - `INDUSTRY_RESEARCH_DATA_CONTRACT.md`
   - `BUG_REGISTER.md`
4. Old contradictory status/context files remain archived, not active.
5. The project proceeds to Phase 3: Source Strategy and Reference Playbook.

---

## 21. Next Phase

After this file is approved and uploaded, the next phase is:

```text
Phase 3 — Source Strategy and Reference Playbook
```

The next canonical file should be:

```text
INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md
```

Its purpose will be to define:

- mandatory source families;
- dynamic industry-specific reference discovery;
- source hierarchy;
- source quality scoring;
- source freshness rules;
- evidence-density expectations;
- field-to-source mapping;
- conflict resolution;
- gap-driven follow-up research.

---

## 22. Final Law Statement

The Industry Intelligence Engine cannot be trusted unless its outputs are generated from a structured, evidence-linked, source-aware, versioned, auditable dataset.

This research data contract is the first operating law that makes the project buildable.

No HTML packet, simulation model, opportunity ranking, mass test, or institutional-quality score may bypass this contract.
