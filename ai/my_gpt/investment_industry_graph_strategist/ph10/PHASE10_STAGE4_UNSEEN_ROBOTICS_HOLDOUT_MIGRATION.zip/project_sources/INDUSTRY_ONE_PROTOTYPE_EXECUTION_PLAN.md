# Industry Intelligence Engine — One-Industry Prototype Execution Plan

**File:** `INDUSTRY_ONE_PROTOTYPE_EXECUTION_PLAN.md`  
**Phase:** 8 — One-Industry Prototype Execution Plan  
**Status:** Approved canonical project-source law  
**Version:** 1.0.0  
**Generated:** 2026-06-29  
**Authority:** This document defines how the first full industry prototype must be selected, scoped, sourced, logged, extracted, structured, simulated, rendered, validated, repaired, archived, and reviewed. It executes, but does not rewrite, the Canonical Project Goal, Foundation Phase Plan, Research Data Contract, Source Strategy and Reference Playbook, Acceptance Criteria and Validation Gates, HTML Packet Template Specification, Simulation Engine Contract, and Validator and Scoring Specification.

---

## 1. Purpose

Phase 8 is the bridge from approved project law into the first real execution run.

The purpose of the one-industry prototype is to prove whether the Industry Intelligence Engine can take **one industry name** and produce a complete, auditable artifact bundle:

1. Canonical structured dataset.
2. CSV table exports.
3. Source ledger.
4. Atomic evidence ledger.
5. Search log.
6. Rejected-source log.
7. Gap register.
8. Value-chain nodes, edges, money flows, and profit pools.
9. Company universe, security master, and exposure map.
10. Professional-lens modules.
11. Scenario assumptions and formula registry.
12. Simulation outputs and sensitivity outputs.
13. HTML packet using the approved template specification.
14. Validation report using the approved validator and scoring specification.
15. Manifest and artifact inventory.
16. Failure fingerprints.
17. Progress log.
18. Final summary.
19. Improvement backlog.
20. Human-review decision record.

The prototype is not a marketing demo. It is a controlled execution test that must expose what works, what fails, what is missing, what is unsupported, what is stale, what is contradictory, what is overconfident, and what must be repaired before Phase 9.

---

## 2. Highest Prototype Principle

> **Prototype is for truth discovery, not ego scoring.**

The first prototype must not force an impressive label. A failed prototype with clear failure fingerprints, gaps, and fix actions is more valuable than a polished artifact that hides weakness.

The target is **Institutional-Grade Candidate** quality, but the final maturity must be determined by validators only. The prototype may end as Seed, Structured, Investable Candidate, Institutional Candidate, or Fail-Useful. It may not claim World-Class or 95+ performance.

---

## 3. Relationship to Prior Phase Documents

Phase 8 executes the prior laws.

| Prior phase | File | Phase 8 responsibility |
|---|---|---|
| Phase 0 | `INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md` | Ensure the prototype serves the approved one-input industry intelligence objective. |
| Phase 1 | `INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md` | Follow the approved sequence and do-not-skip rules. |
| Phase 2 | `INDUSTRY_RESEARCH_DATA_CONTRACT.md` | Populate required and conditional data tables or gap them explicitly. |
| Phase 3 | `INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md` | Build a source plan, source ledger, search log, rejected-source log, and atomic evidence ledger. |
| Phase 4 | `INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md` | Apply maturity, hard-fail, and acceptance criteria. |
| Phase 5 | `INDUSTRY_HTML_PACKET_TEMPLATE_SPEC.md` | Generate the HTML packet from validated structured data. |
| Phase 6 | `INDUSTRY_SIMULATION_ENGINE_CONTRACT.md` | Build scenario assumptions, formulas, propagation logic, and simulation outputs or explicit disabled states. |
| Phase 7 | `INDUSTRY_VALIDATOR_AND_SCORING_SPEC.md` | Run validators, compute score/maturity, capture failure fingerprints, and produce fix actions. |
| Active bug log | `BUG_REGISTER.md` | Check known bugs before running and add new bugs/fingerprints after execution. |

If any active law files are missing, stale, or contradicted by older project files, the prototype must not proceed as a final run until the active baseline is reconciled.

---

## 4. Non-Negotiable Phase 8 Laws

1. The prototype is an execution test, not a marketing demo.
2. One industry must be selected by explicit criteria.
3. The run starts from one industry name only.
4. Active Project Source law must be checked before execution.
5. Source plan must be generated before browsing.
6. Every search/source action must be logged.
7. Accepted sources and important rejected sources must be tracked.
8. Evidence extraction must be atomic and mapped to data-contract fields.
9. Required data-contract tables must be populated or explicitly gapped.
10. Value-chain nodes, edges, money flows, and company links are mandatory.
11. Company/security exposure must be evidence-linked.
12. All five professional role lenses must be represented or visibly gapped.
13. Simulation must be built, or disabled with explicit failure reason.
14. HTML must consume the dataset and expose evidence, gaps, warnings, and validation state.
15. Validators must run before final summary.
16. One repair pass is mandatory after first validation.
17. Progress reporting must reflect real artifacts and validators.
18. Failure fingerprints must be captured.
19. Improvement backlog must be generated.
20. Human review is required before moving to Phase 9.
21. The prototype cannot claim 95+ or World-Class.
22. Hidden gaps, unsupported material claims, random ticker lists, fake simulators, and UI/data mismatches invalidate the prototype.

---

## 5. Prototype Industry Selection Law

The first industry must be selected by criteria, not convenience or randomness.

### 5.1 Required Selection Matrix

Every candidate industry must be scored before selection.

| Criterion | Requirement | Why it matters |
|---|---|---|
| Source availability | High | The first run should test engine mechanics, not fail only because sources are impossible. |
| Value-chain complexity | Medium to high | Tests nodes, edges, money flows, profit pools, and bottlenecks. |
| Public-company exposure | Preferred | Tests company/security mapping and investability. |
| Private-market exposure | Preferred | Tests PE/growth lens and gap handling. |
| Financial sensitivity | Required | Tests bridge from industry variables to revenue, margin, capex, cash flow, and valuation. |
| Scenario richness | Required | Tests simulation variables and thesis-break logic. |
| Event/catalyst activity | Preferred | Tests event-driven PM lens. |
| Regulatory/policy relevance | Useful | Tests policy source strategy and catalyst tracking. |
| Quantamental signal potential | Useful | Tests signal inventory and data-lineage rules. |
| Cross-sector relevance | Useful | Helps reveal design issues that will matter in Phase 9. |
| Difficulty balance | Must be moderate to hard | Too easy does not test the engine; too opaque can fail for data scarcity alone. |

### 5.2 Recommended Candidate Industries

The Phase 8 file does not lock the exact prototype industry unless the user explicitly chooses one after upload. Recommended first-run candidates are:

1. **Semiconductor manufacturing equipment** — source-rich, investable, complex value chain, public-company exposure, strong capex cycle, export controls, quant signals, and catalysts.
2. **Data center power and thermal infrastructure** — strong current demand, power bottlenecks, equipment suppliers, public and private players, large scenario variables.
3. **Commercial HVAC equipment and services** — tangible value chain, replacement cycle, regulation, input costs, services, public/private exposure.
4. **Payments infrastructure** — rich public filings, regulation, take rates, volume sensitivity, network economics, event/regulatory catalysts.
5. **Battery supply chain** — upstream/downstream map, commodity sensitivity, policy support, technology disruption, public/private exposure.

### 5.3 Recommended First Prototype Choice

The best default first prototype candidate is:

> **Semiconductor manufacturing equipment**

Reason: It is source-rich, investable, value-chain complex, financially sensitive, policy-exposed, and likely to expose the largest number of engine requirements without being too opaque.

However, the user may override this choice. Any override must be logged in `prototype_run_log.md` with the selection rationale.

---

## 6. Prototype Target Maturity

The target maturity is:

> **Institutional-Grade Candidate**

This is a target, not a promise.

### 6.1 Expected Score Band

The prototype should target **75–85** if the first run is strong. It must not be inflated above validator caps.

| Result | Meaning |
|---|---|
| 0–39 | Prototype invalid or very preliminary; still useful if fingerprints are captured. |
| 40–54 | Seed; basic structure exists but not investable. |
| 55–69 | Structured; useful dataset foundation but not investment-grade. |
| 70–79 | Investable Research Candidate; meaningful decision-support but not institutional. |
| 80–89 | Institutional-Grade Candidate if no hard fails. |
| 90–95 | Institutional-Grade; unlikely for first run unless extremely strong. |
| 96–100 | Not allowed for Phase 8. Requires Phase 10 mass-test proof. |

### 6.2 Failure Is Allowed

The prototype can pass as a **useful failure** if it produces:

1. Complete artifact bundle or clear missing-artifact failure report.
2. Validation report.
3. Failure fingerprints.
4. Gap register.
5. Improvement backlog.
6. Human-readable final summary.

---

## 7. Required Prototype Artifact Bundle

The prototype must produce a complete directory-style bundle. Recommended root:

```text
industry_prototype_<industry_slug>_<run_id>/
```

### 7.1 Required Files and Directories

| Artifact | Required file or directory | Requirement |
|---|---|---|
| Canonical dataset | `industry_dataset.json` | Required source of truth. |
| CSV tables | `tables/*.csv` | Required for major data-contract tables. |
| Source plan | `source_plan.md` and/or `source_plan.json` | Required before research begins. |
| Search log | `search_log.csv` or `search_log.json` | Required. |
| Source ledger | `source_ledger.csv` and/or `source_ledger.json` | Required. |
| Rejected-source log | `rejected_sources.csv` and/or `rejected_sources.json` | Required for important rejected sources. |
| Atomic evidence ledger | `atomic_evidence.csv` and/or `atomic_evidence.json` | Required. |
| Gap register | `gap_register.csv` and/or `gap_register.json` | Required. |
| Value-chain tables | `tables/value_chain_nodes.csv`, `tables/value_chain_edges.csv`, `tables/money_flows.csv`, `tables/profit_pools.csv` | Required or explicitly gapped. |
| Company/security tables | `tables/company_universe.csv`, `tables/security_master.csv`, `tables/company_segment_exposure.csv` | Required where investable exposure exists. |
| Professional-lens tables | role-specific tables or sections | Required or visibly gapped. |
| Assumptions | `scenario_assumptions.csv/json` | Required for simulation. |
| Formula registry | `formula_registry.csv/json` | Required for derived outputs. |
| Simulation outputs | `simulation_outputs/` | Required if simulation runs; disabled-state file required if not. |
| HTML packet | `index.html` | Required for final prototype artifact. |
| Validation report | `validation_report.json` and `validation_report.md` | Required. |
| Manifest | `manifest.json` | Required. |
| Progress log | `prototype_run_log.md` | Required. |
| Failure fingerprints | `failure_fingerprints.json` and/or `.md` | Required. |
| Improvement backlog | `prototype_improvement_backlog.md` | Required. |
| Final summary | `prototype_final_summary.md` | Required. |
| Human review record | `human_review_decision.md` | Required before Phase 9. |

### 7.2 Manifest Requirements

`manifest.json` must include:

| Field | Requirement |
|---|---|
| `run_id` | Stable prototype run ID. |
| `industry_id` | Stable industry ID. |
| `industry_name` | Industry display name. |
| `industry_selection_rationale` | Why this prototype industry was selected. |
| `generated_at` | Timestamp. |
| `validated_at` | Timestamp after validation. |
| `artifact_state` | `draft`, `prototype_candidate`, `prototype_final`, `diagnostic`, or `archived`. |
| `schema_version` | Phase 2 version used. |
| `source_playbook_version` | Phase 3 version used. |
| `acceptance_criteria_version` | Phase 4 version used. |
| `html_template_spec_version` | Phase 5 version used. |
| `simulation_contract_version` | Phase 6 version used. |
| `validator_spec_version` | Phase 7 version used. |
| `prototype_plan_version` | Phase 8 version used. |
| `file_inventory` | Every generated file. |
| `checksums` | Where feasible. |
| `source_counts` | Accepted, rejected, by family, by tier. |
| `evidence_counts` | Total evidence rows, by table, by confidence. |
| `validation_status` | Final validator status. |
| `maturity_label` | Final maturity label. |
| `score` | Final score after caps. |
| `known_gaps` | Blocker/major summary. |
| `failure_fingerprints` | List of active fingerprints. |

---

## 8. Execution Stage Sequence

The prototype must run in ordered stages.

| Stage | Name | Output |
|---:|---|---|
| 0 | Readiness check | Active law status, bug review, readiness status. |
| 1 | Industry selection and boundary setup | Industry boundary assumptions and selection rationale. |
| 2 | Source plan generation | Source family plan mapped to data-contract fields. |
| 3 | Source discovery and logging | Search log and source candidates. |
| 4 | Source acceptance/rejection | Source ledger and rejected-source log. |
| 5 | Atomic evidence extraction | Atomic evidence ledger. |
| 6 | Data contract population | Canonical dataset and CSV tables. |
| 7 | Value-chain construction | Nodes, edges, money flows, profit pools. |
| 8 | Company/security mapping | Company universe, security master, exposure map. |
| 9 | Professional lens modules | PM, fundamental, quantamental, event, PE/growth modules. |
| 10 | Simulation model setup | Scenarios, assumptions, formulas, outputs, thesis breaks. |
| 11 | HTML packet generation | Interactive packet using Phase 5 structure. |
| 12 | Validation and scoring | Validation report, score, maturity, fingerprints. |
| 13 | Repair pass | Updated artifacts and rerun validators. |
| 14 | Final bundle and summary | Final artifacts, manifest, final summary. |
| 15 | Human review and Phase 9 decision | Human review record and go/no-go decision. |

Stages may iterate internally, but the run log must preserve the sequence and explain any rework.

---

## 9. Stage 0 — Readiness Check

Before any prototype research, the engine must verify the active law baseline.

### 9.1 Required Active Project Sources

1. `INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md`
2. `INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md`
3. `INDUSTRY_RESEARCH_DATA_CONTRACT.md`
4. `INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md`
5. `INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md`
6. `INDUSTRY_HTML_PACKET_TEMPLATE_SPEC.md`
7. `INDUSTRY_SIMULATION_ENGINE_CONTRACT.md`
8. `INDUSTRY_VALIDATOR_AND_SCORING_SPEC.md`
9. `INDUSTRY_ONE_PROTOTYPE_EXECUTION_PLAN.md`
10. `BUG_REGISTER.md`

Older contradictory files must be archived or ignored as active truth.

### 9.2 Readiness Output

`prototype_run_log.md` must include:

```text
Stage 0 readiness: ready | ready_with_warnings | not_ready
Active law files checked: yes/no
Known bug register checked: yes/no
State conflicts detected: yes/no
Source-count mismatch guard enabled: yes/no
Decision: proceed | halt | proceed_diagnostic_only
```

If the readiness check fails, the prototype may only proceed as diagnostic, not as a final candidate.

---

## 10. Stage 1 — Industry Boundary Setup

The prototype must start from a single industry name.

### 10.1 Boundary Defaults

| Field | Default if user provides only industry name |
|---|---|
| Geography | Global, with US/EU/China/Japan/Korea splits where material. |
| Time horizons | 1–3 months, 3–12 months, 1–3 years. |
| Investability scope | Public companies, private players, suppliers, customers, substitutes, baskets where relevant. |
| Boundary status | Explicit assumption until confirmed by sources. |

### 10.2 Boundary Record Requirements

The boundary record must include:

1. Industry name.
2. Working definition.
3. Included segments.
4. Excluded areas.
5. Adjacent industries.
6. Geography.
7. Time horizon.
8. Investability scope.
9. Boundary assumptions.
10. Source/evidence links once confirmed.

Boundary must be validated before deep research. Ambiguity must be shown, not hidden.

---

## 11. Stage 2 — Source Plan Generation

Source plan must be generated before browsing.

### 11.1 Required Source Families

The plan must include, where applicable:

1. Boundary/classification sources.
2. Official statistical and government sources.
3. Regulators and policy sources.
4. Industry associations and standards bodies.
5. Public-company filings.
6. Investor presentations and earnings transcripts.
7. Market size, shipment, pricing, input-cost, capacity, and utilization sources.
8. Trade-flow and supply-chain sources.
9. Technical/patent/science sources where disruption matters.
10. News/event/catalyst sources.
11. M&A/private-market/PE-style sources.
12. Quantamental time-series or signal sources.
13. Negative/risk/controversy/failure searches.
14. Dynamic gap-driven searches.

### 11.2 Prototype Source Targets

| Target | Recommended threshold |
|---|---:|
| Accepted credible sources | 15–25 |
| Atomic evidence rows | 150–300 if source-rich |
| Source families | At least 6 meaningful families |
| Tier 1/Tier 2 sources | Required where available |
| Dynamic gap searches | Required after first data population pass |
| Negative/risk searches | Required |
| Company-specific searches | Required after company universe seed |

Source count alone cannot mark the stage complete. Source plan completeness depends on whether required data-contract fields have an evidence plan.

### 11.3 Source Plan File

`source_plan.md/json` must include:

1. Source family.
2. Target data-contract tables/fields.
3. Query patterns.
4. Expected source tier.
5. Priority.
6. Acceptance criteria.
7. Gaps targeted.
8. Stop condition.

---

## 12. Stages 3–5 — Source Discovery, Acceptance, and Atomic Evidence

### 12.1 Search Log Requirements

Every search must be logged with:

| Field | Requirement |
|---|---|
| `search_id` | Stable ID. |
| `timestamp` | Required. |
| `query` | Required. |
| `purpose` | Required. |
| `target_table` | Required where applicable. |
| `target_field` | Required where applicable. |
| `source_family` | Required. |
| `selected_sources` | IDs after acceptance. |
| `rejected_sources` | IDs or notes for important rejected sources. |
| `result_quality` | high/medium/low/none. |
| `next_gap` | What remains unresolved. |

Failed searches must be logged. They justify gaps and future source escalation.

### 12.2 Source Ledger Requirements

Every accepted source must include:

1. `source_id`
2. title
3. URL/file path
4. publisher
5. author if available
6. publication date if available
7. accessed date
8. source type
9. source tier
10. geography
11. coverage tags
12. reliability notes
13. bias notes
14. freshness status
15. extraction method
16. accepted/rejected status

### 12.3 Rejected Source Log Requirements

Rejected sources must be recorded when they were tempting, prominent, low-quality, irrelevant, stale, promotional, duplicate, or likely to be found again.

Each rejected source record must include:

1. rejected source ID.
2. title/URL if available.
3. rejection reason.
4. source family.
5. whether it can be used as weak signal.
6. related gap or target field.

### 12.4 Atomic Evidence Requirements

Evidence extraction must be atomic. One source can produce many evidence rows.

Every evidence row must include:

1. `evidence_id`
2. claim
3. metric/value where applicable
4. unit
5. period
6. geography
7. source_id
8. source location
9. caveat
10. confidence
11. linked table
12. linked field
13. conflict status
14. extraction method
15. fact/estimate/assumption/derived/interpretation/gap label

One-source-one-evidence-row behavior must be flagged as a failure fingerprint unless justified.

---

## 13. Stage 6 — Data Contract Population

The canonical dataset is the source of truth. Narrative and HTML must be generated from it.

### 13.1 Required Core Tables

At minimum, the prototype must create or explicitly gap:

1. `industry_boundary`
2. `industry_segments`
3. `source_ledger`
4. `atomic_evidence`
5. `value_chain_nodes`
6. `value_chain_edges`
7. `money_flows`
8. `profit_pools`
9. `cost_structure`
10. `demand_drivers`
11. `end_customers`
12. `supply_constraints`
13. `regulation_policy`
14. `technology_disruption`
15. `company_universe`
16. `security_master` where public securities exist
17. `company_segment_exposure`
18. `financial_sensitivity`
19. `event_catalysts`
20. `scenario_assumptions`
21. `simulation_outputs`
22. `opportunity_zones`
23. `risks_falsifiers`
24. `quality_gates`
25. `gap_register`

### 13.2 Blank Handling

Required fields cannot be silently blank.

| Situation | Required action |
|---|---|
| Required data exists | Populate field with evidence link. |
| Data is estimate | Label estimate and link to assumption/evidence. |
| Data is derived | Link formula ID. |
| Data unavailable | Add gap register row. |
| Data uncertain/conflicting | Add confidence/conflict status. |
| Data not applicable | Mark not applicable with reason. |

---

## 14. Stage 7 — Value-Chain Construction

The prototype must produce a value-chain model, not a generic diagram.

### 14.1 Required Chain Coverage

Where relevant, the chain must cover:

```text
raw inputs → components → production/service creation → distribution/channel → direct customer → final customer → aftersales/replacement
```

### 14.2 Node Requirements

Every node must include:

1. node ID.
2. node name.
3. node type.
4. segment/geography.
5. revenue model.
6. margin profile or gap.
7. cost drivers.
8. capex intensity.
9. pricing power.
10. cyclicality.
11. bottlenecks.
12. exposed companies.
13. evidence links.
14. confidence.
15. gaps.

### 14.3 Edge Requirements

Every edge must include:

1. edge ID.
2. from node.
3. to node.
4. flow type: physical, money, data, regulatory, service, contract, or risk.
5. direction.
6. materiality.
7. pass-through logic where relevant.
8. evidence links.
9. confidence.

### 14.4 Economics Requirements

Money flows and profit pools must be separated from physical flows.

A value chain without money flows cannot be Investable+. A value chain without profit-pool logic cannot be Institutional+ unless explicitly capped and gapped.

---

## 15. Stage 8 — Company and Security Mapping

The prototype must map industry structure to investable exposure.

### 15.1 Company Universe Requirements

Every material company must include:

1. company ID.
2. name.
3. ownership type: public, private, sponsor-owned, government/state-owned, subsidiary, unknown.
4. geography.
5. business description.
6. value-chain nodes.
7. segments.
8. source support.
9. exposure status.
10. confidence.

### 15.2 Security Master Requirements

Where public securities exist, each security must include:

1. security ID.
2. ticker.
3. exchange.
4. issuer/company ID.
5. country.
6. currency.
7. security type.
8. liquidity where available.
9. source support.

### 15.3 Exposure Mapping Requirements

Each company exposure record must include:

1. company ID.
2. node ID.
3. segment ID.
4. exposure type.
5. exposure magnitude.
6. exposure direction: benefits, hurt, mixed, uncertain.
7. purity score or high/medium/low/unknown.
8. revenue/margin percentage where available.
9. evidence link.
10. confidence.
11. related risks/catalysts.

Unsupported companies must not appear in ranked opportunity output except as clearly labeled hypotheses or watchlist items.

---

## 16. Stage 9 — Professional Lens Modules

The prototype must represent all five professional role lenses. Weak lenses must be visible, not hidden.

| Role lens | Required prototype coverage |
|---|---|
| Long/short PM | Opportunity zones, exposed securities, long/short/pair/basket implications, catalysts, downside, falsifiers, valuation context where available. |
| Fundamental analyst | Segment exposure, revenue/margin drivers, cost structure, accounting risks, valuation sensitivity, earnings bridge. |
| Quantamental lead | Signal inventory, data lineage, frequency, lag, freshness, point-in-time/backtest/hypothesis status. |
| Event-driven PM | Catalyst/event table, timing, probability/impact, negative catalysts, scenario branches. |
| PE/growth principal | Private players, sponsor/M&A view, fragmentation, unit economics, consolidation/exit logic, diligence questions. |

Each lens must receive a status: `strong`, `adequate`, `weak`, `gapped`, or `not_applicable_with_reason`.

---

## 17. Stage 10 — Simulation Model Setup

The prototype must include deterministic scenario/sensitivity simulation, or visibly disable simulation with reasons.

### 17.1 Required Scenarios

1. Base.
2. Bull.
3. Bear.
4. Shock.
5. Structural transition.
6. Custom-ready user scenario.

### 17.2 Assumption Requirements

Each assumption must include:

1. assumption ID.
2. scenario ID.
3. variable.
4. value.
5. unit.
6. time period.
7. geography where relevant.
8. source status.
9. evidence link or assumption label.
10. confidence.
11. allowed range.
12. default value.
13. affected nodes.
14. affected companies/securities where applicable.
15. formula link.

### 17.3 Required Simulation Outputs

At minimum:

1. scenario outputs.
2. node impact outputs.
3. company impact outputs.
4. security impact outputs where securities exist.
5. opportunity ranking outputs.
6. sensitivity outputs.
7. thesis break outputs.
8. simulation gap outputs.

Broken formulas, invalid units, hidden assumptions, or untraceable outputs hard-fail simulation.

---

## 18. Stage 11 — HTML Packet Generation

HTML must be generated after dataset and simulation artifacts exist.

The HTML packet must follow Phase 5 and include:

1. Persistent header with industry name, maturity, score, confidence, last updated, schema version, source count, evidence count, and hard-fail status.
2. Required tabs from the HTML specification.
3. Evidence drilldowns for material claims.
4. Value-chain graph with clickable nodes/edges.
5. Company/security exposure matrix.
6. Scenario simulator UI linked to assumptions and outputs.
7. Opportunity zone table with upside, downside, catalysts, risks, falsifiers, horizon, confidence, and valuation context where applicable.
8. Evidence ledger tab.
9. Quality/validation/gap tab.
10. Export links.
11. Prominent warnings for hard fails, stale data, weak-source dependence, unresolved conflicts, and unsupported/incomplete components.

HTML cannot invent data. If the canonical dataset lacks the required information, the HTML must show a diagnostic/gap state.

---

## 19. Stage 12 — Validation and Scoring

Validators must run before the final summary.

### 19.1 Required Validator Suites

All Phase 7 suites must run unless explicitly not applicable:

1. Artifact and manifest.
2. Schema and data contract.
3. Source ledger.
4. Atomic evidence.
5. Linkage and lineage.
6. Boundary and segmentation.
7. Value chain.
8. Money flows and profit pools.
9. Company and security exposure.
10. Financial and valuation.
11. Quantamental.
12. Event/catalyst.
13. Simulation.
14. Opportunity zones.
15. Risk/falsifier.
16. HTML/UI.
17. Export/reproducibility.
18. Role-specific.
19. Anti-gaming and consistency.

### 19.2 Validation Report Requirements

`validation_report.md/json` must include:

1. score.
2. maturity label.
3. confidence.
4. hard fails.
5. score caps.
6. validator results.
7. role-lens scores.
8. source/evidence stats.
9. gaps by severity.
10. failure fingerprints.
11. top weaknesses.
12. next fix actions.
13. Phase 9 readiness recommendation.

---

## 20. Stage 13 — Mandatory Repair Pass

One repair pass is mandatory after first validation.

### 20.1 Repair Priority Order

1. Blockers.
2. Hard fails.
3. Broken lineage/joins.
4. Missing required tables.
5. Fake simulator or broken formulas.
6. Unsupported material claims.
7. Random ticker/company exposure issues.
8. Hidden gaps.
9. Stale current claims.
10. UI/data mismatches.
11. Major role-lens gaps.
12. Moderate/minor improvements.

### 20.2 Repair Rules

Any repair that changes data must update:

1. canonical dataset.
2. affected CSV tables.
3. source ledger if sources changed.
4. evidence ledger if claims changed.
5. gap register.
6. simulation outputs if assumptions/formulas changed.
7. HTML if displayed outputs changed.
8. manifest.
9. validation report after rerun.
10. improvement backlog.

The repair pass may leave unresolved gaps, but they must remain visible with severity and next actions.

---

## 21. Progress Reporting Law

Progress must be tied to real artifact and validator state.

### 21.1 Recommended Progress Ring

| Progress | Completion basis |
|---:|---|
| 10% | Readiness and boundary complete. |
| 20% | Source plan generated. |
| 35% | Accepted source ledger built. |
| 50% | Atomic evidence ledger populated. |
| 60% | Core data-contract tables populated. |
| 70% | Value chain and company/security exposure built. |
| 80% | Simulation assumptions and outputs generated or explicit disabled-state file created. |
| 88% | HTML packet generated. |
| 94% | Validators run. |
| 100% | Repair pass completed, validators rerun, final bundle exported, and human-review package ready. |

### 21.2 Hard Progress Rules

1. Progress cannot reach 100% if blocker gaps remain unresolved unless the final status is `fail_useful` or `diagnostic_complete`.
2. Source visits only count when logged and evaluated.
3. Evidence progress only counts atomic rows, not source summaries.
4. HTML progress cannot exceed data/simulation readiness.
5. Validation progress cannot be claimed until validators run and reports are exported.
6. The current maturity cap must always be visible.

---

## 22. Failure Fingerprint Capture

The prototype must capture known and newly discovered failure fingerprints.

### 22.1 Required Fingerprints to Check

| Fingerprint | Meaning |
|---|---|
| `source_count_truth_mismatch` | Source/evidence counts conflict across manifest/status/report. |
| `one_source_one_evidence_row` | Evidence extraction is shallow summary extraction. |
| `citation_stuffing` | Many sources are irrelevant or low-usefulness. |
| `unsupported_material_claim` | Material claim lacks evidence/assumption/formula/gap. |
| `random_ticker_list` | Companies/securities are listed without exposure logic. |
| `broken_value_chain` | Missing nodes, edges, direction, or final-customer path. |
| `missing_money_flow` | Value chain lacks economics. |
| `fake_simulator` | Sliders or outputs do not trace to assumptions/formulas/data. |
| `hidden_gap` | Required missing data is not registered as a gap. |
| `stale_current_claim` | Old source supports current claim without warning. |
| `weak_source_backbone` | Weak sources carry major conclusions. |
| `ui_truth_mismatch` | HTML displays values or claims not present in dataset. |
| `score_inflation` | Score is too high given caps/failures. |

### 22.2 Fingerprint Record Fields

Each fingerprint record must include:

1. fingerprint ID.
2. description.
3. severity.
4. affected phase law.
5. affected artifact.
6. evidence of occurrence.
7. root cause.
8. fix action.
9. validator that should catch it.
10. regression test recommendation.

---

## 23. Improvement Backlog Law

The prototype must generate `prototype_improvement_backlog.md`.

### 23.1 Backlog Item Fields

Each backlog item must include:

| Field | Requirement |
|---|---|
| `issue_id` | Stable ID. |
| `severity` | blocker, major, moderate, minor. |
| `fingerprint` | Failure fingerprint if applicable. |
| `issue_type` | law_gap, implementation_bug, data_scarcity, source_strategy_gap, validator_false_pass, validator_false_fail, UI_issue, simulation_issue. |
| `affected_phase_law` | Phase file impacted. |
| `affected_artifact` | File/table/component impacted. |
| `root_cause` | Required. |
| `fix_proposal` | Required. |
| `validation_test` | How to prove fixed. |
| `priority` | P0–P3. |
| `phase9_relevance` | Whether it must be tested in five-industry run. |

### 23.2 Backlog Priority

| Priority | Meaning |
|---|---|
| P0 | Must fix before Phase 9. |
| P1 | Should fix before Phase 9 unless intentionally testing failure. |
| P2 | Can fix during Phase 9. |
| P3 | Enhancement or later optimization. |

---

## 24. Prototype Acceptance Criteria

### 24.1 Minimum Prototype Success

The prototype is minimally successful if:

1. A full artifact bundle exists, or missing-artifact failures are explicitly captured.
2. Source ledger exists.
3. Atomic evidence ledger exists.
4. Search log exists.
5. Gap register exists.
6. Core data tables exist or are explicitly gapped.
7. Value chain exists or hard failure is captured.
8. Company/security mapping exists where public securities exist, or hard failure is captured.
9. Simulation exists or is explicitly disabled with reason.
10. HTML packet exists or UI generation failure is captured.
11. Validators run.
12. Repair pass happens.
13. Final summary exists.
14. Failure fingerprints exist.
15. Improvement backlog exists.
16. Human review package exists.

### 24.2 Prototype Final Status Labels

| Status | Meaning |
|---|---|
| `pass` | Prototype meets target maturity without hard fails. |
| `pass_with_major_gaps` | Useful prototype; important gaps remain. |
| `fail_useful` | Prototype failed but produced clear fingerprints and backlog. |
| `fail_invalid` | Prototype failed without enough diagnostic output; must rerun or repair process. |
| `diagnostic_only` | Run was intentionally diagnostic due to missing readiness or known limitation. |

A low score does not automatically mean Phase 8 failed. A low score with clear failure fingerprints and actionable fixes can be a successful prototype execution.

---

## 25. Human Review Protocol

Human review is required before Phase 9.

### 25.1 Human Review Package

The user must be given:

1. `prototype_final_summary.md`
2. `validation_report.md`
3. HTML packet link.
4. source/evidence summary.
5. gap register summary.
6. failure fingerprints summary.
7. improvement backlog.
8. recommendation: repair more, proceed to Phase 9, or revise laws.

### 25.2 Human Review Decision Record

`human_review_decision.md` must include:

1. reviewer.
2. review date.
3. inspected artifacts.
4. decision: proceed_to_phase9, repair_phase8_more, revise_law, rerun_prototype, stop.
5. reasoning.
6. required next actions.

No automatic move to Phase 9 is allowed without this review step.

---

## 26. Phase 9 Readiness Decision

The prototype can recommend Phase 9 only if:

1. Active law baseline was used.
2. Prototype artifact bundle exists.
3. Validators ran.
4. Failure fingerprints were captured.
5. Backlog exists.
6. P0 issues are fixed or intentionally carried into Phase 9 as test targets.
7. The user has reviewed the result.
8. Phase 9 test design can use the prototype lessons.

Phase 9 must not begin as a broad mass test. It must be a five-industry cross-sector test designed around the prototype’s discovered weaknesses.

---

## 27. Recommended First Prototype Execution Summary

After this file is uploaded to Project Sources, the next concrete action should be:

```text
Select the first prototype industry using the Phase 8 selection matrix.
```

Recommended default:

```text
Semiconductor manufacturing equipment
```

Recommended run target:

```text
Institutional-Grade Candidate, score target 75–85, no forced score, failure fingerprints required.
```

Recommended first output bundle name:

```text
industry_prototype_semiconductor_manufacturing_equipment_<run_id>/
```

---

## 28. Approved Phase 8 Objective

Phase 8 creates the canonical One-Industry Prototype Execution Plan for the Industry Intelligence Engine. The plan defines how the first real industry run must be selected, scoped, sourced, logged, extracted, structured, simulated, rendered, validated, repaired, archived, and reviewed.

The prototype is not a cosmetic demo and not proof of world-class performance. It is a controlled execution test that converts the prior phase laws into one complete artifact bundle: canonical dataset, CSV tables, source ledger, atomic evidence ledger, search log, rejected-source log, gap register, value-chain map, company/security exposure map, scenario assumptions, formula registry, simulation outputs, HTML packet, validation report, manifest, failure fingerprints, progress log, final summary, and improvement backlog.

The prototype must expose whether the engine can produce a traceable, evidence-backed, simulation-ready, validator-scored industry intelligence packet from a single industry name. It must make every weakness visible: missing sources, missing fields, stale data, unsupported claims, broken joins, weak company exposure, incomplete simulation, UI/data mismatch, score caps, and unresolved gaps.

The first prototype should target Institutional-Grade Candidate quality, but it must never force a high score. Honest failure with clear fingerprints and fix actions is more valuable than fake success.

---

## 29. Next Phase Dependency

Phase 9 may begin only after:

1. This Phase 8 file is uploaded to Project Sources.
2. One prototype industry is selected.
3. The one-industry prototype is executed or intentionally marked diagnostic.
4. The artifact bundle and validation report are reviewed.
5. Failure fingerprints and improvement backlog are created.
6. Human review authorizes Phase 9 or requests repair.

Phase 9 is **Five-Industry Cross-Sector Test**. It must be designed using Phase 8 results, not started blindly.
