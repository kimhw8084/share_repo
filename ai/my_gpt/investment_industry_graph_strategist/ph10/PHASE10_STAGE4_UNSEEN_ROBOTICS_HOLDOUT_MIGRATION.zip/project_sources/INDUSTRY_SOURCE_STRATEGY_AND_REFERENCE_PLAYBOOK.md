# Industry Intelligence Engine — Source Strategy and Reference Playbook

**File name:** `INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md`  
**Project:** Industry Intelligence Engine  
**Status:** Approved canonical Phase 3 law  
**Phase:** Phase 3 — Source Strategy and Reference Playbook  
**Authority level:** Canonical operating source  
**Depends on:**
- `INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md`
- `INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md`
- `INDUSTRY_RESEARCH_DATA_CONTRACT.md`

**Supersedes:** ad hoc source collection, source-summary-only extraction, flat 8-source rules, temporary chat references as durable evidence, and any prior sourcing approach that treats URL count as research quality.

---

## 1. Purpose

This document defines the canonical sourcing law for the Industry Intelligence Engine.

The engine receives one user input: an industry name. To produce an institutional-grade industry intelligence and simulation packet, it must collect sources in a disciplined, auditable, repeatable, field-driven way. Sources are not collected to decorate a report. Sources are collected to populate the Phase 2 research data contract, support material investment claims, power simulation assumptions, expose gaps, and validate opportunity-zone reasoning.

This playbook defines:

1. Mandatory source families.
2. Dynamic gap-driven reference discovery.
3. Source hierarchy and quality tiers.
4. Minimum source and evidence thresholds.
5. Source-to-data-field mapping.
6. Freshness rules.
7. Conflict handling and triangulation.
8. Source metadata and audit trail requirements.
9. Industry-archetype source modules.
10. Role-specific source requirements.
11. Source acceptance and rejection rules.
12. Source scoring.
13. Evidence extraction expectations.
14. Source memory and reuse rules.
15. Non-negotiable source laws.

No industry packet may be called **investable**, **institutional**, or **world-class** unless its source ledger and atomic evidence ledger satisfy this playbook.

---

## 2. Core sourcing philosophy

### 2.1 Sources serve the dataset

Source gathering must follow the Phase 2 data contract. The system does not browse randomly and then write a report. It identifies required fields, collects sources to fill them, extracts atomic evidence, logs gaps, and only then generates narrative, simulation, opportunity ranking, and HTML output.

Every required dataset field must be one of the following:

- **Source-backed**: supported by one or more accepted sources.
- **Derived**: calculated from source-backed inputs with visible formula.
- **Explicitly assumed**: model-default, analyst-estimated, or user-defined assumption with label.
- **Marked as gap**: missing or unresolved, visible in the gap register.

Silent blanks are forbidden.

### 2.2 Evidence density beats URL count

Source count alone never determines readiness. A packet with many weak links can be lower quality than a packet with fewer primary sources and rich atomic evidence.

The engine must extract atomic evidence rows, not one broad summary row per source. A single high-quality filing, regulator document, trade association dataset, or technical report may generate many evidence rows.

### 2.3 Source quality changes confidence

Source quality must affect evidence confidence, maturity level, and final output confidence. Weak-source support must be visible and must reduce confidence unless corroborated.

### 2.4 Dynamic search must be gap-driven

After mandatory source-family coverage, dynamic references must be discovered by targeting specific missing fields, conflicts, stale data, weak evidence, missing company exposure, event timing, or simulation assumptions.

The system must log why each dynamic search exists.

---

## 3. Mandatory source-family sequence

Every industry run must begin with a source plan. The default source-family sequence is mandatory unless the file explicitly marks a source family as not applicable and records why.

### Step 1 — Boundary, classification, and definition sources

Purpose:
- Define industry scope.
- Identify included and excluded segments.
- Detect adjacent industries, substitutes, complements, and region-specific naming.

Source families:
- NAICS, SIC, GICS, ICB, NACE, or other classification systems where relevant.
- Industry-body definitions.
- Regulator definitions.
- Major company segment definitions.
- Technical definitions where the industry is engineering/science-heavy.

Reject:
- Wikipedia-only industry boundaries.
- Undefined scope.
- Hidden exclusions.

### Step 2 — Official, statistical, and regulatory sources

Purpose:
- Anchor market, production, trade, regulation, and policy facts in authoritative data.

Source families:
- Government statistical agencies.
- Regulators.
- Central banks and official financial/statistical bodies.
- International agencies.
- Public regulatory filings, dockets, court filings, approvals, permits, enforcement actions.

Reject:
- Skipping official sources when they exist.
- Treating old regulation as current without verification.

### Step 3 — Industry association, standards, and technical authority sources

Purpose:
- Capture industry structure, shipments, capacity, standards, procedures, terminology, and technical constraints.

Source families:
- Trade associations.
- Standards bodies.
- Technical societies.
- Certification bodies.
- Industry consortiums.
- Recognized engineering, medical, scientific, or professional authorities.

Reject:
- Relying only on market research reports.
- Ignoring technical constraints that shape economics.

### Step 4 — Public company filings and segment disclosures

Purpose:
- Build company universe, segment exposure, risk factors, margin/cost drivers, capital intensity, and financial sensitivity.

Source families:
- Annual reports.
- 10-K, 10-Q, 20-F, 40-F, equivalents.
- Segment disclosures.
- Proxy filings when relevant.
- Risk factors.
- Notes to financial statements.

Reject:
- Company/security mapping from generic articles only.
- Assuming full-company exposure without segment support.

### Step 5 — Earnings calls, investor presentations, guidance, and management commentary

Purpose:
- Capture current company signals: demand, pricing, inventory, guidance, order book, backlog, mix, costs, regulation, competitive dynamics, capital allocation.

Source families:
- Earnings call transcripts.
- Investor presentations.
- Investor day materials.
- Guidance updates.
- Official press releases.
- Management interviews when reputable and attributable.

Important caveat:
- Management commentary is useful but biased. It must be labeled as company-provided and corroborated where material.

Reject:
- Treating company slides as objective evidence without caveat.

### Step 6 — Market size, shipment, pricing, input cost, capacity, and utilization data

Purpose:
- Quantify market size, growth, volume, pricing, capacity, utilization, and margin drivers.

Source families:
- Official production/shipment datasets.
- Industry association datasets.
- Recognized pricing indices.
- Commodity/input-cost datasets.
- Capacity/utilization sources.
- Market research, if attributable and triangulated.

Reject:
- One TAM number as full market analysis.
- Market research as sole evidence backbone.

### Step 7 — Trade flow, supply chain, customer/channel, and distribution data

Purpose:
- Build value-chain edges, money flows, supply constraints, customer exposure, geographic flows, and distribution economics.

Source families:
- Import/export and customs data.
- Logistics data.
- Channel/distributor disclosures.
- Customer and supplier disclosures.
- Procurement data where public/permissioned.
- Infrastructure capacity datasets.

Reject:
- Value chain without flows.
- Physical-chain map without money-flow logic.

### Step 8 — Event and catalyst sources

Purpose:
- Build the month-to-year timing layer.

Source families:
- Regulatory calendars.
- Court filings.
- Litigation dockets.
- Company event calendars.
- Earnings and investor-day calendars.
- M&A and spin-off sources.
- Tariff, subsidy, and policy calendars.
- Product approvals and launch sources.
- Contract awards/losses.
- Capacity start-up/shutdown sources.
- Bankruptcy, labor, strike, and supply-disruption sources.

Reject:
- Static industry research with no catalyst path.
- Past events listed as future catalysts.

### Step 9 — Private-market and PE-style sources

Purpose:
- Satisfy the growth equity / PE sector principal lens.

Source families:
- Sponsor portfolio pages.
- Private company websites.
- Funding and M&A databases where available.
- Deal announcements.
- Industry publications.
- Buyer/seller databases where permissioned.
- Public materials from PE-backed platforms.
- Expert-call style question generation from source gaps.

Reject:
- Public-company-only worldview.
- Private company promotional claims as fact without caveat.

### Step 10 — Dynamic gap-driven searches

Purpose:
- Fill unpopulated required fields, resolve conflicts, refresh stale facts, and strengthen weak evidence.

Dynamic searches must be tied to:
- A specific table.
- A specific field or gap.
- A source family.
- A query purpose.
- A logged outcome.

Reject:
- Broad random searches after the mandatory source pass.

---

## 4. Source quality hierarchy

Source tiers must use controlled enums. Each source receives both a tier and a numeric score.

### Tier 1A — Primary official source

Examples:
- Government statistical agency.
- Regulator.
- Court/regulatory filing.
- Official exchange data.
- Central bank.
- Official customs/trade dataset.
- International official agency.

Use:
- Highest support for official metrics, regulation, approvals, trade flows, macro/industry statistics.

Limitations:
- May be delayed, aggregated, revised, or not aligned to investable industry definitions.

### Tier 1B — Company primary source

Examples:
- Annual report.
- 10-K / 10-Q / 20-F / equivalent.
- Investor presentation.
- Earnings transcript.
- Official press release.
- Segment disclosure.

Use:
- Company exposure, risk factors, management commentary, segment revenue, margin, capital intensity, business model.

Limitations:
- Management bias, selective disclosure, non-comparable segment definitions.

### Tier 2A — Industry association, standards body, or recognized technical authority

Examples:
- Trade associations.
- Standards organizations.
- Professional societies.
- Technical regulatory bodies.
- Certification bodies.

Use:
- Industry structure, shipments, technical constraints, standards, procedure volumes, capacity, terminology.

Limitations:
- Member bias, incomplete coverage, nonpublic methodology.

### Tier 2B — Transaction/data infrastructure source

Examples:
- Pricing indices.
- Exchange/market data.
- Customs/trade databases.
- Shipment databases.
- Official APIs.
- Recognized industry data infrastructure.

Use:
- Time-series signals, pricing, volume, capacity, trade, utilization.

Limitations:
- Cost/access constraints, methodology opacity, revisions, lag.

### Tier 3 — Reputable financial, news, or professional publication

Examples:
- Major financial news outlets.
- Reputable professional publications.
- Established industry news.

Use:
- Recent events, management moves, M&A, regulation, litigation, disruptions, market context.

Limitations:
- Secondary reporting, headline bias, incomplete technical detail.

### Tier 4 — Broker, sell-side, or market research when attributable

Examples:
- Broker research.
- Recognized market research reports.
- Consultant reports.
- Industry forecast firms.

Use:
- Market size, growth, forecasts, channel structure, customer segmentation, estimates.

Limitations:
- Paywall limits, unclear methodology, incentive bias, inconsistent definitions.

Rule:
- Market research cannot be the sole backbone for investable or institutional packets.

### Tier 5 — Vendor, company blog, SEO page, weak commercial report

Examples:
- Vendor blogs.
- Lead-generation reports.
- SEO articles.
- Non-primary commercial content.

Use:
- Weak signals, terminology, product landscape, possible lead sources.

Limitations:
- Promotional bias, poor methodology, unverifiable claims.

Rule:
- Cannot independently support final thesis or critical metric.

### Tier 6 — Social, forum, reviews, job posts, web traffic, anecdotal sources

Examples:
- Forums.
- Social media.
- Reviews.
- Job postings.
- Web traffic indicators.
- Anecdotal comments.

Use:
- Weak signal only: hiring, customer sentiment, operational pain points, product adoption anecdotes.

Limitations:
- Bias, selection effects, manipulation, non-representative samples.

Rule:
- Cannot support final thesis alone.

---

## 5. Numeric source scoring

Every accepted source receives a numeric score from 0 to 100 plus a tier label.

### 5.1 Scoring dimensions

| Dimension | Weight guidance | Meaning |
|---|---:|---|
| Authority | High | Is the source primary, official, or deeply authoritative? |
| Relevance | High | Does it directly fill the target field/table? |
| Freshness | High for current facts | Is it current enough for the claim? |
| Methodology clarity | Medium/high | Does it explain definitions, sampling, calculation, coverage? |
| Specificity | Medium/high | Does it support exact fields rather than broad commentary? |
| Corroboration | Medium | Is it consistent with other high-quality sources? |
| Bias risk | Medium | Is there promotional, management, political, or commercial bias? |
| Extractability | Medium | Can the claim/metric be extracted cleanly with unit, period, geography? |

### 5.2 Score bands

| Score | Interpretation |
|---:|---|
| 90–100 | Exceptional primary source for the target field. |
| 80–89 | Strong source; generally reliable with minor caveats. |
| 70–79 | Useful source; requires context or corroboration for major claims. |
| 60–69 | Limited source; use cautiously. |
| 40–59 | Weak source; signal only unless corroborated. |
| 0–39 | Not acceptable for material claims. |

### 5.3 Score effects

Source score must affect:
- Evidence confidence.
- Packet maturity.
- Role-specific source coverage.
- Conflict resolution.
- Required corroboration.
- Gap severity.

---

## 6. Minimum source and evidence thresholds

### 6.1 Source count thresholds

| Maturity target | Minimum credible sources | Notes |
|---|---:|---|
| Preliminary orientation | Fewer than 8 | Must be labeled preliminary; cannot be investable. |
| Seed maturity | 8+ | Basic map and initial evidence only. |
| Normal investable industry | 12+ | Required for ordinary public/investable sectors. |
| Regulated/global/complex industry | 15+ | Healthcare, financials, infrastructure, global supply chains, policy-heavy sectors. |
| Opaque/private/fragmented industry | 20+ | Private markets, fragmented services, hard-to-measure markets. |

Source count alone never passes a packet. Required fields, evidence density, and quality gates also matter.

### 6.2 Evidence density thresholds

| Maturity target | Minimum atomic evidence rows | Notes |
|---|---:|---|
| Seed | 30+ | Basic field support. |
| Investable | 100+ | Enough to support structured investment view. |
| Institutional | 250+ where feasible | Required for high-confidence, multi-role output unless limitations are disclosed. |
| World-class | Varies, often 500+ | Requires cross-source, role-specific, simulation-ready evidence. |

### 6.3 Source diversity requirements

An investable or higher packet must include multiple source families. Twelve market research links do not equal a valid source base.

At minimum, a normal investable packet should include coverage from:
- Boundary/classification.
- Official/regulatory/statistical, if available.
- Industry association/technical authority, if available.
- Company filings, if public companies are relevant.
- Market/volume/pricing/capacity data.
- Event/catalyst sources.
- Risk/negative sources.

---

## 7. Source-to-data-field mapping

Every required data-contract field must have source expectations. The following mapping is canonical.

### 7.1 `industry_boundary`

Required source support:
- Classification systems.
- Regulator/industry-body definitions.
- Company segment definitions.
- Technical definitions.

Must support:
- Included segments.
- Excluded segments.
- Geography.
- Adjacent industries.
- Investability scope.

### 7.2 `industry_segments`

Required source support:
- Industry association segmentation.
- Company reporting segments.
- Market research segmentation.
- Regulatory product/service categories.

Must support:
- Product/service segments.
- Customer segments.
- Geography.
- Channel.
- Business model.
- Technology/regulation-specific segmentation.

### 7.3 `source_ledger`

Required source support:
- Durable URL or file reference.
- Publisher metadata.
- Date/access date.
- Source type and tier.
- Coverage tags.

### 7.4 `atomic_evidence`

Required source support:
- Source location: page, table, chart, section, paragraph, timestamp where possible.
- Claim, metric, value, unit, period, geography, confidence, caveat.

### 7.5 `value_chain_nodes`

Required source support:
- Industry technical documents.
- Company filings.
- Trade association descriptions.
- Standards/regulator materials.
- Supply-chain sources.

Must support:
- Node type.
- Function.
- Economics.
- Participants.
- Bottlenecks.

### 7.6 `value_chain_edges`

Required source support:
- Supplier/customer disclosures.
- Trade-flow data.
- Channel/distribution information.
- Contracts and procurement sources.
- Technical flow descriptions.

Must support:
- Direction.
- Flow type.
- Materiality.
- Evidence strength.

### 7.7 `money_flows`

Required source support:
- Filings.
- Pricing/take-rate sources.
- Reimbursement/contracts.
- Transaction-volume/take-rate data.
- Business model disclosures.

Must support:
- Who pays whom.
- Pricing model.
- Contract model.
- Revenue recognition where relevant.

### 7.8 `profit_pools`

Required source support:
- Segment margins.
- Industry margin studies.
- Company filings.
- Pricing power evidence.
- ROIC/capital intensity data.

Must support:
- Node revenue share.
- Margin profile.
- Margin migration.
- Pricing power.

### 7.9 `cost_structure`

Required source support:
- Company filings.
- Input cost data.
- Commodity indices.
- Labor/capex/utilization sources.
- Supplier disclosures.

Must support:
- Fixed vs variable costs.
- Key input costs.
- Labor intensity.
- Capex intensity.
- Operating leverage.

### 7.10 `demand_drivers`

Required source support:
- End-market data.
- Customer behavior sources.
- Official/macro data.
- Company disclosures.
- Adoption/penetration data.

Must support:
- Demand mechanism.
- Time horizon.
- Cyclicality.
- Leading indicators.

### 7.11 `end_customers`

Required source support:
- Customer segmentation sources.
- Channel data.
- Company disclosures.
- Procurement sources.
- Surveys where credible.

Must support:
- Final customer categories.
- Purchase criteria.
- Replacement/adoption cycle.
- Price sensitivity.

### 7.12 `supply_constraints`

Required source support:
- Capacity data.
- Utilization data.
- Bottleneck reports.
- Technical constraints.
- Lead times.
- Trade/logistics data.

Must support:
- Constraint type.
- Affected nodes.
- Duration.
- Investment implication.

### 7.13 `regulation_policy`

Required source support:
- Regulators.
- Laws/rules.
- Dockets.
- Enforcement actions.
- Policy calendars.
- Company risk disclosures.

Must support:
- Rule/status.
- Jurisdiction.
- Effective date.
- Affected nodes/companies.
- Investment impact.

### 7.14 `technology_disruption`

Required source support:
- Patents.
- Standards.
- Technical papers.
- Product roadmaps.
- R&D disclosures.
- Adoption data.

Must support:
- Technology shift.
- Incumbent/challenger impact.
- Timing.
- Bottleneck or substitution effect.

### 7.15 `company_universe`

Required source support:
- Filings.
- Company websites.
- Industry association member lists.
- Market maps.
- Trade publications.
- M&A/private-market sources.

Must support:
- Company role.
- Ownership type.
- Geography.
- Value-chain node participation.

### 7.16 `security_master`

Required source support:
- Exchange data.
- Company investor relations.
- Financial data provider where available.

Must support:
- Ticker.
- Exchange.
- Country.
- Currency.
- Security type.
- Issuer.
- Liquidity where available.

### 7.17 `company_segment_exposure`

Required source support:
- Segment revenue.
- Filings.
- Investor presentations.
- Management commentary.
- Customer/supplier disclosures.

Must support:
- Direct/indirect exposure.
- Magnitude.
- Direction: benefits, hurt, mixed, uncertain.
- Evidence strength.

### 7.18 `financial_sensitivity`

Required source support:
- Filings.
- Segment disclosures.
- Management guidance.
- Input-cost data.
- Consensus/valuation sources where available.

Must support:
- Revenue drivers.
- Margin drivers.
- Capex.
- Working capital.
- Cash-flow sensitivity.
- Valuation context.

### 7.19 `event_catalysts`

Required source support:
- Company events.
- Regulatory calendars.
- Court filings.
- M&A/news sources.
- Subsidy/tariff calendars.
- Approval/contract/capacity announcements.

Must support:
- Event date.
- Date certainty.
- Probability or label as estimate.
- Impact magnitude.
- Affected companies/nodes.
- Thesis implication.

### 7.20 `scenario_assumptions`

Required source support:
- Historical ranges.
- Official forecasts.
- Management guidance.
- External forecasts.
- Analyst-estimate labels.
- User-defined inputs.

Must support:
- Assumption value.
- Unit.
- Range.
- Affected nodes/companies.
- Source status.

### 7.21 `simulation_outputs`

Required source support:
- Derived from scenario assumptions, formulas, and mapped company/node exposure.

Must support:
- Node winners/losers.
- Company winners/losers.
- Ranking changes.
- Financial sensitivity.
- Thesis-break thresholds.

### 7.22 `opportunity_zones`

Required source support:
- Multiple evidence types: value-chain economics, financial sensitivity, catalysts, valuation context, risk/falsifiers.

Must support:
- Upside.
- Downside.
- Timing.
- Catalysts.
- Evidence strength.
- Exposed companies/securities.

### 7.23 `risks_falsifiers`

Required source support:
- Risk factors.
- Negative searches.
- Historical failures.
- Regulatory/litigation data.
- Commodity/macro/competition evidence.

Must support:
- Risk mechanism.
- Probability/impact where possible.
- Measurable falsifier.
- Affected opportunity zones.

### 7.24 `gap_register`

Required source support:
- Gaps can arise from failed search, unavailable sources, unresolved conflicts, stale data, inaccessible paywalled data, or missing field support.

Must support:
- Missing field/table.
- Severity.
- Affected output.
- Required source type.
- Next action.

---

## 8. Dynamic reference discovery rules

Dynamic source discovery is required after the mandatory source-family pass.

### 8.1 Triggers

Dynamic discovery is triggered by:
- Missing required fields.
- Weak source support.
- Unresolved conflicts.
- Stale current data.
- Missing company exposure.
- Missing event dates or current verification.
- Missing simulation assumptions.
- Missing risk/falsifier support.
- Role-specific weak coverage.

### 8.2 Query design law

Every dynamic query should include:
- Target industry or segment.
- Target field/table.
- Geography where relevant.
- Time period where relevant.
- Source type or authoritative domain where possible.
- Synonyms, aliases, technical terms, and regional labels where needed.

Bad query:

```text
solar industry outlook
```

Better query:

```text
solar PV inverter gross margin pricing pressure 2024 2025 company filings investor presentation
```

Best query when field-driven:

```text
solar PV inverter value chain profit pool gross margin segment revenue source company filings 2024
```

### 8.3 Negative search requirement

Dynamic discovery must include negative searches for:
- Margin pressure.
- Overcapacity.
- Demand weakness.
- Customer loss.
- Litigation.
- Regulatory risk.
- Disruption.
- Price erosion.
- Inventory build.
- Financing stress.
- Bankruptcy/distress.

Bullish-only sourcing is forbidden.

### 8.4 Failed search logging

Failed searches must be logged when they target a required or important field. The failure must create or update a gap record.

---

## 9. Freshness and update rules

### 9.1 Required metadata

Every accepted source must include:
- Publication date when available.
- Accessed date.
- Source freshness status.
- Claim period for every metric.

### 9.2 Freshness categories

| Category | Meaning |
|---|---|
| current | Appropriate for current claims. |
| recent | Useful but may require update depending on field. |
| historical | Used for trend/history, not current state. |
| stale_current_risk | Old source being used for a current claim; must warn or replace. |
| structural_stable | Older but acceptable for stable technical/structural facts. |

### 9.3 Field-specific refresh logic

| Field type | Freshness expectation |
|---|---|
| Regulation/policy status | Must be checked current. |
| Event/catalyst status | Must be checked current. |
| Company filings | Latest annual/quarterly available plus history. |
| Market size/current growth | Usually recent 12–24 months; stricter for fast-moving sectors. |
| Pricing/input costs | Recent/monthly/quarterly where possible. |
| Technical standards | Current version when material. |
| Historical cycle analysis | Older sources acceptable if labeled. |
| Structural value-chain descriptions | Older sources acceptable if still valid and labeled. |

### 9.4 Stale evidence rule

Stale evidence may be retained, but it must not support a current claim without a freshness warning or corroborating current source.

---

## 10. Conflict handling and triangulation

### 10.1 Conflict status enums

Every evidence row should support conflict status:

- `none`
- `suspected`
- `confirmed`
- `resolved`
- `unresolved`

### 10.2 Metrics requiring triangulation

The following require triangulation for investable/institutional packets:

- Market size.
- Growth rate.
- Forecasts.
- Margin/profit pool estimates.
- Company exposure.
- Segment size.
- Financial sensitivity.
- Key risks.
- Investment thesis.
- Event impact.
- Simulation-critical assumptions.

### 10.3 Conflict resolution requirements

When sources conflict, the engine must record:
- Which sources conflict.
- Whether definitions differ.
- Whether geography differs.
- Whether period differs.
- Whether unit differs.
- Which number/range is chosen, if any.
- Why the chosen value is preferred.
- Whether unresolved conflict remains.

### 10.4 Range over fake precision

If definitions differ and multiple values are valid, show a range and explain the definitional differences. False precision is forbidden.

---

## 11. Source metadata and audit trail

Every accepted source must include durable metadata.

### 11.1 Required source metadata

| Field | Required? | Notes |
|---|---|---|
| `source_id` | Yes | Stable ID. |
| `title` | Yes | Document/page title. |
| `url_or_file_reference` | Yes | Durable link or local artifact reference. |
| `publisher` | Yes | Organization or source owner. |
| `author` | When available | Record if known. |
| `publication_date` | When available | Required for current claims where available. |
| `accessed_date` | Yes | Date source was checked. |
| `source_family` | Yes | Boundary, official, filing, etc. |
| `source_tier` | Yes | Controlled tier. |
| `source_score` | Yes | 0–100. |
| `geography` | Where relevant | Avoid global/regional mixing. |
| `language` | Where relevant | Especially for non-English sources. |
| `coverage_tags` | Yes | Boundary, market, company, event, regulation, etc. |
| `paywall_or_access_note` | When relevant | State limitations. |
| `snapshot_hash` | When possible | For reproducibility. |
| `reliability_note` | When relevant | Bias/methodology notes. |

### 11.2 Evidence-level location metadata

Every atomic evidence row should include source location when possible:
- Page number.
- Table number.
- Chart title.
- Section heading.
- Paragraph location.
- Timestamp for video/audio.
- Filing item/section.

Citation without location is weaker evidence.

### 11.3 Temporary chat references

Temporary chat references such as `turn...` IDs are not durable source references. They may be used during an active session but must be converted into durable URL/file/source_id references before becoming project evidence.

---

## 12. Role-specific source requirements

The source strategy must satisfy five professional lenses.

### 12.1 Long/short equity PM lens

Required source coverage:
- Filings.
- Earnings calls.
- Investor presentations.
- Segment data.
- Valuation/consensus where available.
- Price/liquidity/crowding where available.
- Catalysts.
- Risk/negative sources.

Must support:
- Longs, shorts, pairs, baskets, avoids.
- Upside/downside.
- Time horizon.
- Falsifiers.
- Tradability/liquidity where available.

### 12.2 Fundamental equity analyst lens

Required source coverage:
- Financial statements.
- Segment disclosures.
- KPI disclosures.
- Accounting notes.
- Risk factors.
- Competitor filings.
- Management commentary.

Must support:
- Revenue bridge.
- Margin bridge.
- Unit economics.
- Capital intensity.
- Accounting risk.
- Earnings sensitivity.

### 12.3 Quantamental data lead lens

Required source coverage:
- Structured time-series data.
- Official datasets.
- Pricing/volume/shipment/inventory datasets.
- Financial market data where available.
- Revisions/consensus data where available.
- Point-in-time or vintage metadata where available.

Must support:
- Signal definition.
- Formula.
- Frequency.
- Lag.
- Current reading.
- History availability.
- Backtest status or hypothesis label.

### 12.4 Event-driven special situations PM lens

Required source coverage:
- Regulatory dockets.
- Court filings.
- Company events.
- M&A/spin/restructuring sources.
- Tariff/subsidy calendars.
- Approval and reimbursement sources.
- Contract awards/losses.
- Bankruptcy/labor/supply disruption sources.

Must support:
- Event date.
- Probability.
- Impact.
- Affected companies/securities.
- Catalyst path.
- Falsifier.

### 12.5 Growth equity / PE sector principal lens

Required source coverage:
- Private company market maps.
- Sponsor portfolio pages.
- M&A databases or public deal announcements.
- Company websites.
- Trade publications.
- Unit economics proxies.
- Customer/channel sources.
- Exit-comp sources where available.

Must support:
- Fragmentation.
- Consolidation thesis.
- Sponsor-owned platforms.
- Private company archetypes.
- Business quality.
- Diligence questions.
- Exit attractiveness.

---

## 13. Industry-archetype source modules

The universal source sequence must branch by industry type.

### 13.1 Industrial and manufacturing

Required additional sources:
- Capacity and utilization data.
- Shipment/production data.
- Input costs.
- Equipment suppliers.
- Trade flows.
- Capex cycles.
- Standards.
- OEM filings.
- Distributor/channel data.

Key risks:
- Overcapacity.
- Input-cost shock.
- Inventory cycle.
- Customer capex cuts.
- Trade restrictions.

### 13.2 Healthcare, medtech, pharma, life sciences

Required additional sources:
- FDA/EMA/other regulators.
- Reimbursement sources.
- Clinical data.
- Procedure volumes.
- Hospital/customer economics.
- Patents.
- Product approvals.
- Filings and risk factors.

Key risks:
- Approval failure.
- Reimbursement pressure.
- Clinical trial risk.
- Product liability.
- Hospital budget pressure.

### 13.3 Financials and payments

Required additional sources:
- Central banks.
- Payment networks.
- Regulators.
- Transaction volumes.
- Take rates.
- Interchange rules.
- Bank/merchant economics.
- Filings.

Key risks:
- Regulation.
- Rate sensitivity.
- Credit cycle.
- Fraud.
- Competition/take-rate compression.

### 13.4 Software, internet, and platforms

Required additional sources:
- Company KPIs.
- Pricing pages.
- Usage metrics.
- Developer ecosystem data.
- Cloud spend.
- App marketplaces.
- Retention/churn disclosures.
- Filings.
- Privacy/security regulation.

Key risks:
- Churn.
- Platform dependency.
- Pricing pressure.
- Competition.
- AI/substitution disruption.

### 13.5 Energy and commodities

Required additional sources:
- Production data.
- Reserves/resources.
- Supply/demand balances.
- Commodity prices.
- Regulation.
- Project pipelines.
- Capex.
- Geopolitics.
- Transport/logistics.

Key risks:
- Commodity price shock.
- Project delay.
- Policy change.
- Geopolitical disruption.
- Reserve depletion.

### 13.6 Consumer and retail

Required additional sources:
- POS/sales data where available.
- Channel checks.
- Demographics.
- Pricing/promotion data.
- Inventory data.
- Brand share.
- Reviews as weak signal.
- Retailer/brand filings.

Key risks:
- Demand slowdown.
- Inventory overhang.
- Promotion intensity.
- Brand erosion.
- Channel conflict.

### 13.7 Transportation and logistics

Required additional sources:
- Volumes.
- Rates.
- Capacity.
- Fuel.
- Labor.
- Network density.
- Utilization.
- Regulation.
- Infrastructure.
- Customer verticals.

Key risks:
- Fuel shock.
- Labor disruption.
- Rate compression.
- Capacity oversupply.
- Regulatory changes.

### 13.8 Telecom and infrastructure

Required additional sources:
- Subscriber data.
- Traffic data.
- Capex.
- Spectrum.
- Regulation.
- Tower/fiber assets.
- Utilization.
- Contracts.
- Financing costs.

Key risks:
- Rate sensitivity.
- Regulatory action.
- Capex intensity.
- Tenant concentration.
- Technology substitution.

### 13.9 Media and advertising

Required additional sources:
- Ad spend.
- CPMs.
- Audience/time-spent.
- Platform KPIs.
- Privacy regulation.
- Content costs.
- Subscription/churn data.

Key risks:
- Ad cycle.
- Privacy/platform regulation.
- Content-cost inflation.
- Subscriber churn.
- Audience fragmentation.

### 13.10 Real estate and infrastructure assets

Required additional sources:
- Occupancy.
- Rents.
- Cap rates.
- Financing costs.
- Permits.
- Supply pipeline.
- Utilization.
- Tenant/customer concentration.

Key risks:
- Rate shock.
- Oversupply.
- Tenant default.
- Cap-rate expansion.
- Local regulation.

---

## 14. Search process logging

Every industry run must maintain a search log.

### 14.1 Required search log fields

| Field | Required? | Description |
|---|---|---|
| `search_id` | Yes | Stable ID. |
| `timestamp` | Yes | When search was performed. |
| `query` | Yes | Exact query or source lookup. |
| `purpose` | Yes | Why search was run. |
| `target_table` | Yes | Data-contract table. |
| `target_field_or_gap` | Yes | Specific field/gap. |
| `source_family` | Yes | Mandatory/dynamic family. |
| `results_reviewed_count` | Where feasible | Number of candidate results reviewed. |
| `sources_selected` | Yes | Accepted source IDs. |
| `sources_rejected` | Important cases | Rejected source IDs/notes. |
| `outcome` | Yes | Filled field, created gap, unresolved conflict, etc. |
| `next_action` | When needed | Follow-up search or source escalation. |

### 14.2 Stop conditions

Source gathering can stop for a maturity target only when:
- Required source families are checked or marked not applicable with reason.
- Required source threshold is met.
- Required evidence threshold is met.
- Required data fields are filled, derived, assumed, or gapped.
- Major conflicts are resolved or logged.
- Stale current claims are refreshed or warned.
- Gaps are visible with severity and next action.

It must not stop merely because a URL count was reached.

---

## 15. Gap-driven source escalation

### 15.1 Gap severity

| Severity | Meaning | Effect |
|---|---|---|
| blocker | Prevents valid packet/investment-grade status. | Must resolve or label not investment-grade. |
| major | Materially weakens one or more professional lenses. | Reduces maturity/confidence. |
| moderate | Limits completeness but does not block basic output. | Visible gap and follow-up. |
| minor | Nice-to-have missing detail. | Low score effect. |

### 15.2 Blocker source gaps

Examples:
- No boundary source.
- No durable source ledger.
- No atomic evidence ledger.
- No value-chain source support.
- No company/security exposure support where public securities exist.
- No simulation assumptions for claimed simulator.
- No support for final opportunity thesis.
- No current verification for time-sensitive catalysts.

### 15.3 Required gap fields

Every gap must include:
- Missing table/field.
- Gap reason.
- Severity.
- Affected output.
- Required source type.
- Next search action.
- Whether gap blocks maturity level.

---

## 16. Source acceptance and rejection rules

### 16.1 Accepted source requirements

A source can be accepted if it is:
- Relevant to a target field, table, source family, or gap.
- Traceable to a publisher or origin.
- Dated or clearly stable enough for the claim.
- Credible enough for its intended use.
- Extractable into source ledger and evidence ledger.

### 16.2 Rejection criteria

Reject or downgrade sources with:
- No provenance.
- No date for a current claim.
- Pure SEO content.
- Unverifiable claim.
- Copied/aggregated content without original source.
- Irrelevant scope.
- Suspicious data.
- AI-generated summary without underlying source.
- Promotional content used as objective fact.

### 16.3 Special source rules

| Source type | Rule |
|---|---|
| AI-generated summaries | Not acceptable as source; use underlying original. |
| Wikipedia | Orientation only, not primary support for investment claims. |
| Vendor blogs | Weak signal unless verifiable primary data. |
| News | Good for recent events; corroborate major structural claims. |
| Social/forums/reviews | Weak signal only. |
| Market research snippets | Useful but require methodology caveat and triangulation. |
| Company claims | Useful but biased; label and corroborate where material. |

---

## 17. Evidence extraction law

### 17.1 Atomic extraction required

Each source must be reviewed for extractable atomic evidence:
- Claims.
- Metrics.
- Values.
- Units.
- Periods.
- Geographies.
- Definitions.
- Company exposure.
- Events.
- Risks.
- Assumptions.
- Caveats.
- Contradictions.

### 17.2 Evidence row minimum fields

Each atomic evidence row should include:
- `evidence_id`
- `source_id`
- `claim_type`
- `claim_text`
- `metric_name` where applicable
- `metric_value` where applicable
- `metric_unit` where applicable
- `metric_period` where applicable
- `geography` where applicable
- `source_location`
- `linked_table`
- `linked_field`
- `confidence_score`
- `source_quality_score`
- `conflict_status`
- `caveat`
- `extraction_method`
- `analyst_interpretation` separated from fact

### 17.3 Short quotes only

Exact snippets may be preserved when useful, but excessive copying is forbidden. The evidence ledger should capture source-backed claims and locations, not reproduce long copyrighted passages.

### 17.4 Extraction must create gaps when needed

If a source was expected to contain a metric or field but does not, that absence should create or update a gap record.

---

## 18. Source memory and reuse

### 18.1 Durable source memory

Source IDs must persist across runs where possible. Source memory should support cross-industry reuse.

### 18.2 Reuse conditions

A reused source must be checked for:
- Freshness.
- Continued relevance.
- Scope alignment.
- Coverage of current field needs.
- Whether it has been superseded.

### 18.3 Source memory fields

Source memory should track:
- Source ID.
- Last checked date.
- Source tier and score.
- Fields/tables supported.
- Industry runs used in.
- Freshness status.
- Rejected-source notes where important.

### 18.4 State conflicts

Old source rows from historical artifacts may not define current truth if project state conflicts exist. They must be reconciled before reuse.

---

## 19. Current known implementation warning

Earlier project artifacts contained a disputed state count: some status files referenced 61 source/evidence rows, while newer artifact inspection found 58 rows in the latest expansion logs. This playbook forbids building new source memory from contradictory status files.

Before any mass test or continuation of historical source expansion, create a reconciled current-state file or use only verified artifact counts.

---

## 20. Non-negotiable Phase 3 laws

1. Mandatory source families must be checked before random dynamic searches.
2. Dynamic searches must be gap-driven and mapped to data-contract fields.
3. Source quality tiers must be controlled and affect confidence.
4. Source count alone never determines readiness.
5. Evidence density matters more than URL count.
6. One source can and should generate many atomic evidence rows.
7. Current claims require freshness checks.
8. Major claims require corroboration or explicit uncertainty.
9. Conflicting sources must be logged and resolved or shown.
10. Weak sources can only be weak signals unless corroborated.
11. Source metadata must be durable, not temporary chat references.
12. Missing source support must create visible gap records.
13. AI-generated summaries are not sources; use underlying originals.
14. Market research cannot be the sole backbone of institutional output.
15. Company filings are mandatory where public-company exposure exists.
16. Events/catalysts require current verification.
17. Negative/risk searches are mandatory.
18. Source reuse requires freshness and relevance checks.
19. Search logs are required for auditable research.
20. No industry packet may be called investment-grade without satisfying this playbook.

---

## 21. Phase handoff

After this file is approved and uploaded to Project Sources, the project moves to:

```text
Phase 4 — Acceptance Criteria and Validation Gates
```

The Phase 4 artifact should be:

```text
INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md
```

Phase 4 will define:
- Maturity levels.
- Hard-fail conditions.
- Required score thresholds.
- Source/evidence acceptance gates.
- Dataset completeness gates.
- Investment-grade gates.
- Simulation acceptance gates.
- HTML packet acceptance gates.
- Role-specific pass/fail criteria.

---

## 22. Active Project Source recommendation after Phase 3

After upload, active Project Sources should be:

1. `INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md`
2. `INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md`
3. `INDUSTRY_RESEARCH_DATA_CONTRACT.md`
4. `INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md`
5. `BUG_REGISTER.md`

Old ZIPs and historical artifacts should remain local audit materials unless a clean reconciled state file is generated.

---

## 23. Final approved Phase 3 objective

Phase 3 creates the canonical Source Strategy and Reference Playbook for the Industry Intelligence Engine. The playbook defines the mandatory source families, dynamic gap-driven reference discovery process, source quality hierarchy, source scoring, freshness rules, evidence density expectations, conflict handling, source metadata requirements, source-to-data-field mapping, industry-archetype source modules, and source acceptance/rejection rules required to fill the Phase 2 Research Data Contract for any industry.

The playbook makes source gathering disciplined, auditable, repeatable, and field-driven. Sources are not collected to decorate a report; they are collected to populate required dataset fields, support material investment claims, power simulation assumptions, expose gaps, and validate opportunity-zone reasoning.

No industry packet may be called investable, institutional, or world-class unless its source ledger and atomic evidence ledger satisfy this playbook.

