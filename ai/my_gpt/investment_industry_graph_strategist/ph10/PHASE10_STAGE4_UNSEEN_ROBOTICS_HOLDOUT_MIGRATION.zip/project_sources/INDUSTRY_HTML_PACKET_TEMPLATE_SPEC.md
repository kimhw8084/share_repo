# INDUSTRY HTML PACKET TEMPLATE SPEC

**Project:** Industry Intelligence Engine  
**Document:** Phase 5 — HTML Packet Template Specification  
**Status:** Canonical Phase Law — Approved  
**Version:** v1.0  
**Authority Level:** Active Project Source after upload  
**Depends On:**  
1. `INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md`  
2. `INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md`  
3. `INDUSTRY_RESEARCH_DATA_CONTRACT.md`  
4. `INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md`  
5. `INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md`  

---

## 1. Purpose

This document defines the canonical HTML packet template for the Industry Intelligence Engine.

The HTML packet is the user-facing investment cockpit generated from a validated industry dataset. It must make the research explorable, auditable, interactive, and decision-useful. It must never invent data, hide missing data, hide hard fails, make weak evidence look strong, or use UI polish to compensate for weak research.

The packet is not a static report. It is an interactive institutional-grade industry intelligence interface.

---

## 2. Phase 5 Scope

Phase 5 defines:

- Required HTML tabs and sections.
- Persistent header and packet identity.
- Navigation and interaction rules.
- Value-chain visualization behavior.
- Evidence drilldown behavior.
- Company/security exposure interface.
- Quality and validation display.
- Scenario simulator interface hooks.
- Export package expectations.
- Failure, incomplete, stale, and invalid packet states.
- Data-to-UI mapping requirements.

Phase 5 does **not** define final simulation mathematics. Final simulation logic belongs to:

```text
INDUSTRY_SIMULATION_ENGINE_CONTRACT.md
```

---

## 3. Highest-Level UI Law

```text
HTML consumes validated structured data.
HTML does not invent data.
HTML does not hide quality problems.
HTML does not upgrade maturity.
HTML is the product surface, not the source of truth.
```

The source of truth remains:

1. Structured dataset.
2. Source ledger.
3. Atomic evidence ledger.
4. Scenario assumptions.
5. Validation report.
6. Manifest.

---

## 4. Non-Negotiable Phase 5 Laws

1. HTML consumes validated structured data; it does not invent data.
2. One reusable template serves all industries.
3. Maturity level, score, source count, evidence count, and hard-fail status must be prominent.
4. Every material claim must support evidence drilldown.
5. Gaps, stale data, weak evidence, and unresolved conflicts must be visible.
6. Value chain must be interactive, node/edge-based, and evidence-linked.
7. Company/security exposure must be interactive and evidence-linked.
8. Opportunity rankings must show upside, downside, catalysts, risks, falsifiers, confidence, and valuation context where applicable.
9. Scenario simulator UI must exist, but final simulation math belongs to Phase 6.
10. Quality/validation tab is mandatory.
11. Evidence ledger tab is mandatory.
12. Role-specific UI coverage is mandatory.
13. Exports must include dataset, source ledger, evidence ledger, assumptions, validation report, and manifest.
14. Broken or incomplete components must show diagnostic state, not fake output.
15. UI beauty cannot raise maturity above data/evidence/validation quality.

---

## 5. Product Philosophy

The packet must feel like:

```text
An institutional investment cockpit, not a report.
```

It must serve both:

- Executive users who need a fast, honest investment read.
- Analyst users who need deep drilldown, evidence, audit trails, and reusable data.

The UI must expose uncertainty, gaps, hard fails, stale data, unresolved conflicts, assumptions, derived calculations, and role-specific weaknesses.

A beautiful invalid packet is still invalid.

---

## 6. Required Packet-Level Output States

Every packet must display one of the following states:

| State | Meaning |
|---|---|
| Invalid | Core hard fail prevents use as research output. |
| Preliminary | Early diagnostic output with major missing data. |
| Seed | Basic sourced map with evidence and visible gaps. |
| Structured | Required dataset exists but not yet investable. |
| Investable Candidate | Strong enough to support investment research, but not institutional. |
| Institutional Candidate | Near institutional but still has material gaps or unresolved checks. |
| Institutional | Passes institutional gates. |
| World-Class | Benchmark-proven, regression-tested, deeply validated, rare. |

The packet must never show only “done.”

---

## 7. Persistent Header Requirements

Every packet must have a persistent header visible across all major tabs.

Required header fields:

| Field | Requirement |
|---|---|
| Industry name | Required |
| Industry ID | Required |
| Maturity level | Required and prominent |
| Overall score | Required after validation |
| Score confidence | Required |
| Hard-fail status | Required |
| Source count | Required |
| Evidence count | Required |
| Last updated timestamp | Required |
| Schema version | Required |
| Source playbook version | Required |
| Validation-gate version | Required |
| HTML template version | Required |
| Simulation model version | Required when simulator is active |
| Stale-source warning | Required when material |
| Unresolved-conflict warning | Required when material |

Hard fails, stale-source warnings, and unresolved-conflict warnings must be visible globally, not buried in an appendix.

---

## 8. Required Top-Level Tabs

Every packet must use this fixed top-level tab structure.

1. Executive Investment View
2. Industry Boundary and Segmentation
3. Value Chain Map
4. Node Economics and Profit Pools
5. Company and Security Exposure
6. Demand, Customers, and End Markets
7. Supply, Bottlenecks, and Constraints
8. Competitive Structure
9. Regulation, Policy, and Geopolitics
10. Technology and Disruption
11. Financial Sensitivity and Valuation Context
12. Quantamental Signals
13. Catalysts and Event Calendar
14. Scenario Simulator
15. Opportunity Zones and Long/Short Implications
16. PE / Growth Equity Diligence View
17. Risks, Bear Case, and Falsifiers
18. Evidence Ledger
19. Quality, Validation, and Gaps

Tabs may degrade gracefully if optional data is unavailable, but the absence must be shown as an explicit gap or inactive/incomplete state.

---

## 9. Navigation and Interaction Model

The packet must include:

- Sidebar navigation for desktop.
- Top-level tabs for major modules.
- Deep links to each tab and major panel.
- Global filters where useful.
- Search across companies, sources, claims, nodes, events, and evidence.
- Sortable/filterable tables.
- Expandable executive cards.
- Drilldown from visual components to evidence.
- Consistent interaction behavior across all industries.

Recommended global filters:

| Filter | Purpose |
|---|---|
| Geography | Show global/regional differences |
| Segment | Focus by product/customer/business model |
| Value-chain node | Isolate economics and exposure |
| Company/security | Inspect investable exposure |
| Scenario | Compare base/bull/bear/shock/custom |
| Time horizon | 1–3 months, 3–12 months, 1–3 years |
| Confidence level | Filter low-confidence claims |

---

## 10. Claim-to-Evidence Interaction Law

Every material claim must be clickable or otherwise traceable to its evidence.

When a claim is clicked, the UI must open an evidence drawer/modal showing:

| Field | Requirement |
|---|---|
| Claim text | Required |
| Claim type | fact, estimate, assumption, derived output, interpretation, or gap |
| Source title | Required when sourced |
| Publisher | Required when available |
| Source URL/path | Required when available |
| Source date | Required when available |
| Accessed date | Required |
| Source tier | Required |
| Exact source location | page, table, section, paragraph, chart, timestamp when available |
| Metric/value | Required for quantitative claim |
| Unit | Required for quantitative claim |
| Period | Required for quantitative claim |
| Geography | Required where relevant |
| Confidence | Required |
| Caveat | Required where relevant |
| Conflict status | Required |
| Linked dataset table/field | Required |
| Formula | Required for derived output |
| Assumption owner | Required for assumptions |
| Gap severity | Required for gaps |

Unsupported material claims must not display as facts. They must be blocked, labeled as hypothesis, or converted into a visible gap.

---

## 11. Executive Investment View Tab

### Purpose

Give a fast, honest investment read with direct drilldown into evidence.

### Required panels

1. One-line industry thesis, if supported.
2. Maturity, score, confidence, and hard-fail summary.
3. Top opportunity zones.
4. Top avoid / short-risk zones.
5. What must be true.
6. What could break.
7. Top catalysts and event windows.
8. Top risks and falsifiers.
9. Role-lens status.
10. Top gaps and next actions.

### Required behavior

- No forced bullish thesis.
- If evidence is weak, show “Not investment-grade yet.”
- Every executive claim must drill down to evidence, assumption, model output, or gap.
- Top opportunities must show evidence strength, upside, downside, time horizon, catalyst path, risk, falsifier, and valuation context when relevant.

---

## 12. Industry Boundary and Segmentation Tab

### Required panels

1. Industry definition.
2. Included segments.
3. Excluded segments.
4. Adjacent industries.
5. Geography and time horizon.
6. Investability scope.
7. Segment table.
8. Segment attractiveness map.

### Required segment fields

| Field | Requirement |
|---|---|
| Segment name | Required |
| Segment type | Required |
| Description | Required |
| Size | Required or gap |
| Growth | Required or gap |
| Maturity | Required |
| Economics | Required or gap |
| Key companies | Required or gap |
| Risks | Required |
| Evidence strength | Required |
| Gaps | Required if incomplete |

Segments must be clickable and must link to value-chain nodes, companies, evidence, opportunity zones, risks, and scenarios.

---

## 13. Value Chain Map Tab

### Core visual

An interactive end-to-end value-chain graph.

### Minimum chain coverage

```text
Raw inputs
→ components
→ production/service creation
→ distribution/channel
→ direct customer
→ final customer
→ aftersales/replacement where relevant
```

### Node interaction

Clicking a node must open:

- Node description.
- Node type.
- Revenue model.
- Margin profile.
- Pricing power.
- Capex intensity.
- Cost drivers.
- Cyclicality.
- Bottlenecks.
- Exposed companies/securities.
- Events/catalysts.
- Risks/falsifiers.
- Scenario variables.
- Evidence.
- Gaps.

### Edge interaction

Clicking an edge must open:

- Flow direction.
- Flow type.
- Materiality.
- Source/evidence.
- Companies involved.
- Risks.
- Money/data/physical/regulatory/service/contract/risk flow details.

### Required flow types

- Physical flow
- Money flow
- Data flow
- Regulatory flow
- Service flow
- Contract flow
- Risk flow

Low-confidence nodes/edges must be visually marked. Missing chain segments must render as gaps, not disappear.

---

## 14. Node Economics and Profit Pools Tab

### Required panels

1. Profit-pool heatmap by node and segment.
2. Node economics table.
3. Money-flow map.
4. Pricing-power matrix.
5. Cost-structure matrix.
6. Bottleneck economics.
7. Margin migration view.
8. Evidence and gap drilldowns.

### Required node economics fields

| Field | Requirement |
|---|---|
| Node ID | Required |
| Node name | Required |
| Revenue model | Required |
| Margin profile | Required or gap |
| Pricing power | Required or gap |
| Profit-pool share | Required or gap |
| Cost drivers | Required |
| Capex intensity | Required or gap |
| Cyclicality | Required |
| Bottlenecks | Required or gap |
| Exposed companies | Required or gap |
| Evidence strength | Required |
| Gaps | Required if incomplete |

---

## 15. Company and Security Exposure Tab

### Core view

Company/security exposure matrix by:

- Value-chain node
- Segment
- Geography
- Exposure direction
- Exposure magnitude
- Exposure purity
- Public/private status
- Security identifier

### Required panels

1. Public company universe.
2. Private company universe.
3. Security master table.
4. Segment exposure matrix.
5. Node exposure matrix.
6. Company cards.
7. Security exposure ranking.
8. Unsupported/hypothesis company list.
9. Company evidence drilldown.

### Required company-card fields

| Field | Requirement |
|---|---|
| Company name | Required |
| Ownership type | Required |
| Public/private status | Required |
| Ticker/exchange/currency | Required where public |
| Value-chain nodes | Required |
| Segment exposure | Required |
| Exposure magnitude | Required |
| Exposure direction | Required |
| Exposure purity | Required |
| Revenue/margin exposure | Required or gap |
| Financial sensitivity | Required or gap |
| Catalyst exposure | Required or gap |
| Risk/falsifier exposure | Required |
| Evidence support | Required |
| Confidence | Required |

Unsupported companies must be labeled as unsupported/hypothesis or excluded from ranked outputs.

---

## 16. Demand, Customers, and End Markets Tab

### Required panels

1. End-customer map.
2. Demand-driver ranking.
3. Customer-segment table.
4. Adoption/penetration curve where relevant.
5. Replacement-cycle view where relevant.
6. Geographic demand view.
7. Demand cyclicality view.
8. Demand uncertainty/gap panel.

### Required behavior

- Final customer behavior must be shown.
- Demand must not stop at direct buyer.
- Demand drivers must show evidence strength and uncertainty.
- TAM/SAM/SOM numbers must show geography, period, unit, definition, source, and methodology caveat.

---

## 17. Supply, Bottlenecks, and Constraints Tab

### Required panels

1. Capacity and utilization table.
2. Supply base map.
3. Bottleneck ranking.
4. Input availability.
5. Lead-time view.
6. Labor/capex/logistics constraints.
7. Trade-flow dependency map.
8. Bottleneck winners/losers.
9. Scenario hooks for supply shocks.

### Required behavior

Bottlenecks must map to:

- Value-chain nodes.
- Value-chain edges.
- Exposed companies.
- Potential winners/losers.
- Risks.
- Scenario variables.
- Evidence.

---

## 18. Competitive Structure Tab

### Required panels

1. Market structure overview.
2. Concentration/share view where available.
3. Rivalry and pricing behavior.
4. Barriers to entry.
5. Switching costs.
6. Substitutes.
7. Complements.
8. Competitive intensity score.
9. Competitive gaps.

All moat or competitive advantage claims must be evidence-backed and must not use vague language without support.

---

## 19. Regulation, Policy, and Geopolitics Tab

### Required panels

1. Relevant regulators.
2. Current rules/policies.
3. Pending policy changes.
4. Subsidies/tariffs/export controls.
5. Litigation/regulatory proceedings.
6. Compliance burden.
7. Geopolitical exposure.
8. Policy winners/losers.
9. Policy event links.
10. Regulatory falsifiers.

### Required behavior

- Regulation must be mapped to value-chain nodes and companies.
- Current verification status must be shown.
- Pending policy must link to catalyst calendar.
- Uncertain legal/policy interpretation must be labeled.

---

## 20. Technology and Disruption Tab

### Required panels

1. Technology shift map.
2. Adoption/maturity curve.
3. R&D/patent/science signal where relevant.
4. Replacement/substitution risk.
5. Productivity shifts.
6. New entrants/platform changes.
7. Technology winners/losers.
8. Scenario hooks.
9. Evidence and uncertainty.

Technology hype is not allowed. Claims must be evidence-backed and timing-aware.

---

## 21. Financial Sensitivity and Valuation Context Tab

### Required panels

1. Revenue driver bridge.
2. Price/volume bridge.
3. Margin driver bridge.
4. Input-cost sensitivity.
5. Capex/capital-intensity view.
6. Working-capital view where relevant.
7. Cyclicality view.
8. Valuation context.
9. Consensus expectation gap where accessible.
10. Accounting-risk panel.
11. Company-level sensitivity table.

### Required behavior

- Industry facts must bridge to earnings/cash flow where possible.
- Security-linked rankings require valuation context or explicit valuation gap.
- Assumptions must be drillable.
- Driver confidence must be shown.

---

## 22. Quantamental Signals Tab

### Required panels

1. Signal inventory.
2. Signal definitions and formulas.
3. Data lineage.
4. Frequency and lag table.
5. Freshness status.
6. Point-in-time status.
7. Current signal reading.
8. Historical availability.
9. Backtest/hypothesis status.
10. Signal-to-node/company mapping.
11. Missing quant-data gaps.

### Required signal labels

| Label | Meaning |
|---|---|
| Tested | Some historical validation exists |
| Untested | Defined signal, no validation |
| Insufficient data | Not enough history |
| Hypothesis only | Conceptual signal |
| Not available | Missing data |

The UI must not imply a signal is proven unless validation exists.

---

## 23. Catalysts and Event Calendar Tab

### Required panels

1. Event timeline.
2. Event table.
3. Past vs future events.
4. Positive and negative catalysts.
5. Date status.
6. Probability/uncertainty.
7. Impact estimate.
8. Affected nodes/companies/securities.
9. Thesis implication.
10. Scenario link.
11. Evidence link.

### Required event types

- Earnings
- Guidance
- Investor day
- Regulation
- Litigation
- M&A
- Spin-off
- Tariff
- Subsidy
- Product launch
- Capacity expansion/shutdown
- Contract award/loss
- Approval/reimbursement
- Bankruptcy/distress
- Labor strike
- Supply disruption

Past events must never be displayed as future catalysts.

---

## 24. Scenario Simulator Tab

### Phase 5 scope

Phase 5 defines the simulator UI and data hooks. Phase 6 defines the final simulation math and model rules.

### Required scenario modes

- Base
- Bull
- Bear
- Shock
- Structural transition
- Custom scenario

### Required variable control groups

| Group | Variables |
|---|---|
| Demand | growth, adoption, penetration, replacement cycle |
| Pricing | price, take rate, reimbursement, ASP |
| Volume | shipment, usage, transaction volume, utilization |
| Margin | gross margin, operating margin, input costs |
| Supply | capacity, lead time, utilization, constraints |
| Macro | rates, FX, inflation, commodity prices |
| Policy | tariffs, subsidies, regulation |
| Competition | competitive intensity, share shift, margin compression |
| Financial | capex, working capital, valuation multiple |

### Required output panels

1. Node winners/losers.
2. Company winners/losers.
3. Security exposure changes.
4. Opportunity ranking changes.
5. Financial sensitivity.
6. Key driver sensitivity.
7. Thesis breakpoints.
8. Assumption/evidence drilldown.
9. Simulation warning/gap panel.

Invalid or incomplete simulations must be disabled or clearly labeled.

---

## 25. Opportunity Zones and Long/Short Implications Tab

### Required panels

1. Ranked opportunity zones.
2. Avoid / short-risk zones.
3. Long/short/pair/basket research implications.
4. Time horizon.
5. Upside/downside.
6. Catalyst path.
7. Risk/falsifier path.
8. Evidence strength.
9. Valuation context.
10. Confidence and maturity label.
11. Watchlist/hypothesis ideas.

### Required fields for each opportunity

| Field | Requirement |
|---|---|
| Opportunity ID | Required |
| Type | node, segment, company, security, basket, event setup |
| Thesis | Required |
| Upside | Required |
| Downside | Required |
| Time horizon | Required |
| Catalyst | Required or gap |
| Evidence strength | Required |
| Valuation context | Required for securities or gap |
| Risk | Required |
| Falsifier | Required |
| Confidence | Required |
| Role-lens support | Required |

This tab must avoid personalized financial advice. It may present research implications, not commands to buy/sell.

---

## 26. PE / Growth Equity Diligence View Tab

### Required panels

1. Private company map.
2. Sponsor-owned assets.
3. Fragmentation and consolidation view.
4. M&A/deal history.
5. Unit economics where available.
6. Customer/channel economics.
7. Exit attractiveness.
8. Strategic buyer universe.
9. IPO feasibility where relevant.
10. Diligence question bank.
11. PE red flags.
12. Private-market gaps.

Private-market gaps must be visible. The UI must not fake private-market completeness.

---

## 27. Risks, Bear Case, and Falsifiers Tab

### Required panels

1. Risk map.
2. Bear-case narrative.
3. Falsifier table.
4. Probability/impact matrix where possible.
5. Affected nodes.
6. Affected companies/securities.
7. Affected opportunity zones.
8. Monitoring indicators.
9. Unresolved risk panel.

### Required risk categories

- Demand
- Supply
- Pricing
- Competition
- Regulation
- Technology
- Macro
- Rates
- FX
- Commodity
- Accounting
- Valuation
- Liquidity
- Geopolitical
- Execution

Every thesis must have a falsifier. The bear case must be serious, not decorative.

---

## 28. Evidence Ledger Tab

The evidence ledger is mandatory and first-class.

### Required columns

| Column | Requirement |
|---|---|
| evidence_id | Required |
| claim | Required |
| claim type | Required |
| metric/value | Required where applicable |
| unit | Required where applicable |
| period | Required where applicable |
| geography | Required where applicable |
| source_id | Required |
| source title | Required |
| publisher | Required when available |
| source tier | Required |
| source location | Required when available |
| confidence | Required |
| caveat | Required where relevant |
| conflict status | Required |
| linked table | Required |
| linked field | Required |
| extraction method | Required |

### Required behavior

- Filter by source, table, claim type, confidence, geography, period, and conflict status.
- Link evidence back to UI claims.
- Highlight low-confidence evidence.
- Highlight unresolved conflicts.
- Display source metadata.

---

## 29. Quality, Validation, and Gaps Tab

This tab is mandatory.

### Required panels

1. Maturity level.
2. Overall score.
3. Score decomposition.
4. Hard-fail list.
5. Validator results.
6. Gap register.
7. Source/evidence statistics.
8. Role-lens scores.
9. Stale-source warnings.
10. Conflict warnings.
11. Missing table/field report.
12. Next actions.

### Score decomposition must show

- Source score.
- Evidence score.
- Data contract score.
- Value-chain score.
- Company/security score.
- Simulation score.
- Investment logic score.
- Role-lens score.
- UI/artifact readiness score.

Hard fails must appear before the user can reasonably trust the packet.

---

## 30. Visual Component Library

The template must define reusable components.

Required components:

1. KPI card.
2. Evidence-backed thesis card.
3. Maturity/quality badge.
4. Hard-fail banner.
5. Source/evidence strength badge.
6. Value-chain graph.
7. Node detail drawer.
8. Edge detail drawer.
9. Exposure matrix.
10. Company/security card.
11. Profit-pool heatmap.
12. Cost-structure matrix.
13. Event timeline.
14. Scenario control panel.
15. Sensitivity table.
16. Opportunity ranking table.
17. Risk/falsifier matrix.
18. Gap register table.
19. Validation dashboard.
20. Evidence drawer/modal.
21. Export panel.
22. Manifest panel.

Every component must define:

- Required dataset inputs.
- Optional dataset inputs.
- Missing-data behavior.
- Evidence drilldown behavior.
- Quality/failure behavior.

---

## 31. Data-to-UI Contract

Every UI component must map to the Phase 2 data contract.

### Required mapping fields for each component

| Field | Requirement |
|---|---|
| Component name | Required |
| Source tables | Required |
| Required fields | Required |
| Optional fields | Required |
| Missing-data behavior | Required |
| Validation dependencies | Required |
| Evidence dependencies | Required |
| Drilldown target | Required |
| Export behavior | Required if relevant |
| Failure behavior | Required |

HTML must not create data not present in the dataset.

---

## 32. Missing Data and Failure Behavior

### Missing mandatory data

Render:

- Warning banner.
- Gap card.
- Disabled/partial component state.
- Next action from gap register.
- Link to Quality tab.

### Missing optional data

Render:

- Optional gap note or collapsed missing module.
- No maturity penalty unless important for role/industry.

### Broken validation

Render:

- Hard-fail banner.
- Diagnostic output.
- Disable misleading charts/rankings.
- Link to validation report.

### Broken simulation

Render:

- Simulation disabled.
- Reason shown.
- Missing assumptions or formula errors shown.
- No scenario output displayed as valid.

### Unsupported ranking

Render:

- Watchlist/hypothesis label, or hide from ranked section.
- Evidence gap shown.

---

## 33. Export and Artifact Package Law

The HTML packet must not be the only artifact.

Required exports for institutional packet:

1. Canonical JSON dataset.
2. CSV table exports.
3. Source ledger.
4. Atomic evidence ledger.
5. Scenario assumptions.
6. Simulation outputs when available.
7. Validation report.
8. Gap register.
9. Manifest.
10. HTML packet.

The HTML must include export links/sections or clear file references.

The manifest must include:

- run_id
- industry_id
- generated timestamp
- schema version
- source playbook version
- validation gate version
- HTML template version
- simulation model version where applicable
- files generated
- maturity level
- score
- hard-fail status

---

## 34. Performance and Robustness

The packet should be usable as a serious analytic tool.

Requirements:

- Large tables must support pagination/search.
- Value-chain graph must support clustering/filtering for large industries.
- UI must degrade gracefully if JavaScript fails.
- Core summary and tables should remain readable when possible.
- Desktop institutional dashboard is primary.
- Mobile readability is secondary but should not be ignored.
- Accessibility should be considered: contrast, keyboard navigation where feasible, semantic structure.
- Debug/diagnostic messages should be visible in development mode.

---

## 35. Security, Compliance, and Integrity

The HTML packet must:

- Avoid personalized financial advice wording.
- Present research implications, not direct commands to buy/sell.
- Use only public/permissioned sources.
- Show source licensing/access limitations where relevant.
- Never expose credentials, API keys, secrets, or sensitive internal paths.
- Clearly label user-defined scenario assumptions.
- Display disclaimers concisely and non-intrusively.
- Warn when weak evidence could lead to overreliance.

---

## 36. Role-Specific UI Gates

The UI must satisfy the professional-role standard defined by the canonical goal.

### Long/short equity PM

Must show:

- Opportunity rankings.
- Long/short/pair/basket implications.
- Catalysts.
- Valuation context.
- Downside.
- Falsifiers.
- Liquidity/crowding where available.

### Director fundamental equity analyst

Must show:

- Segment exposure.
- Revenue/margin drivers.
- Cost structure.
- Accounting risks.
- Earnings bridge.
- Valuation sensitivity.

### Senior quantamental data lead

Must show:

- Signal definitions.
- Data lineage.
- Frequency.
- Lag.
- Freshness.
- Point-in-time status.
- Backtest/hypothesis status.

### Event-driven special situations PM

Must show:

- Event calendar.
- Probability/impact.
- Affected companies.
- Timing.
- Negative catalysts.
- Event freshness.

### Growth equity / PE sector principal

Must show:

- Private players.
- Fragmentation.
- Sponsor assets.
- M&A.
- Unit economics.
- Exit logic.
- Diligence questions.

Weak role coverage must be visible. One blended score is insufficient.

---

## 37. Phase 5 Acceptance Criteria

Phase 5 is complete only when this specification defines:

- Required tab structure.
- Required global header.
- Required navigation behavior.
- Claim-to-evidence drilldown.
- Value-chain graph behavior.
- Company/security exposure behavior.
- Scenario UI hooks.
- Quality/validation tab.
- Evidence ledger tab.
- Data-to-UI mapping law.
- Failure and missing-data behavior.
- Export bundle expectations.
- Role-specific UI requirements.
- Non-negotiable UI laws.

---

## 38. Authorized Next Phase

After this Phase 5 document is uploaded to Project Sources, the next phase is:

```text
Phase 6 — Simulation Engine Contract
```

Phase 6 will define:

- Scenario math.
- Assumption types.
- Variable ranges.
- Formula traceability.
- Sensitivity logic.
- Thesis breakpoints.
- Node/company/security impact propagation.
- Simulation report outputs.
- Simulation validation rules.

No final simulator implementation should be treated as valid until Phase 6 is approved.

---

## 39. Final Phase 5 Law

```text
The HTML packet is the institutional cockpit for the Industry Intelligence Engine. It must make the structured dataset explorable, auditable, interactive, and decision-useful. It must expose maturity, quality, evidence, assumptions, uncertainty, gaps, conflicts, hard fails, and role-specific coverage. It may never invent data, hide validation problems, display unsupported investment claims, or allow UI polish to compensate for weak source/evidence quality.
```
