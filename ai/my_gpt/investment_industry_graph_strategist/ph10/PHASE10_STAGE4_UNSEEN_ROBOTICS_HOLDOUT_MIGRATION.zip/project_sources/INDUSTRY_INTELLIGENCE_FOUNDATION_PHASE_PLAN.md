# Industry Intelligence Engine — Foundation Phase Plan

**Document status:** Canonical foundation plan  
**Version:** v1.0 approved  
**Approval basis:** User approved the full phase-plan questionnaire with no exceptions.  
**Created:** 2026-06-29  
**Authority:** This document controls the build sequence for the Industry Intelligence project after the canonical project goal.  
**Supersedes:** Any older ad hoc roadmap, status note, or project-context file that conflicts with this phase order.  

---

## 1. Purpose

This document defines the correct build sequence for the Industry Intelligence Engine.

The project goal has already been approved: given only the name of an industry, the system must generate a fully interactive, evidence-traceable, institutional-grade HTML intelligence and simulation packet that maps the complete value chain, company/security exposure, scenario logic, catalysts, risks, falsifiers, and opportunity zones for month-to-year investment research.

This foundation plan translates that goal into a disciplined execution sequence.

The purpose of this plan is to prevent the project from becoming a beautiful but unreliable report generator. The correct build logic is:

```text
Dataset first.
Evidence second.
Validation third.
HTML fourth.
Investment interpretation last.
```

The HTML packet must consume validated structured data. It must not become a cosmetic layer hiding weak evidence, hidden blanks, unsupported claims, or broken simulation logic.

---

## 2. Current Project Source Position

### 2.1 Active sources recommended now

The active GPT Project Sources should currently be limited to:

```text
1. INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md
2. INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md
3. BUG_REGISTER.md
```

### 2.2 Files to keep archived locally, not active as project law

Older artifacts and packages should be retained locally for audit/history but should not control the new build sequence:

```text
mass_test_batch1a_expansion_v2_artifacts.zip
mass_test_batch1a_progress_app_artifacts.zip
project_context_transfer_data_pull_engine.zip
```

### 2.3 Files that should not remain active unless reconciled and explicitly promoted

Older context/status files may contain overlapping instructions or disputed state such as the 58 vs 61 source/evidence count mismatch. They should not remain active as canonical project sources unless rewritten and marked as reconciled:

```text
GPT_PROJECT_CONTEXT.md
PROJECT_INSTRUCTIONS.md
CURRENT_STATUS.md
NEXT_CHAT_PROMPT.md
README.md
project_state.json
artifact_manifest.json
```

### 2.4 Source hygiene rule

Canonical source files should be few, explicit, versioned, and non-contradictory.

Run-specific outputs, raw ZIPs, progress dashboards, old manifests, and test artifacts should be kept as artifacts, not as active instruction sources, unless they are distilled into a reusable canonical rule file.

---

## 3. Master Build Sequence

The approved master sequence is:

```text
Phase 0  — Source Cleanup and Canonical Goal
Phase 1  — Foundation Phase Plan
Phase 2  — Research Data Contract
Phase 3  — Source Strategy and Reference Playbook
Phase 4  — Acceptance Criteria and Validation Gates
Phase 5  — HTML Packet Template Specification
Phase 6  — Simulation Engine Contract
Phase 7  — Validator and Scoring Specification
Phase 8  — One-Industry Prototype
Phase 9  — Five-Industry Cross-Sector Test
Phase 10 — Twenty-Industry Mass Test and Regression
```

This sequence is mandatory. The project must not jump from goal directly to HTML or mass testing.

---

## 4. Non-Negotiable Build Rules

These rules are project law:

```text
1. Do not build HTML before the data contract.
2. Do not mass test before one deep prototype.
3. Do not score without validators.
4. Do not use one source summary as one evidence row.
5. Do not hide missing data.
6. Do not keep contradictory old status files as active sources.
7. Do not call output investment-grade unless it passes gates.
8. Do not promise profit; rank risk-adjusted opportunities.
9. Do not allow unsupported investment conclusions.
10. Do not skip company/security exposure mapping.
11. Do not skip simulation and falsifier logic.
12. Do not skip source strategy and source quality hierarchy.
```

If these rules conflict with speed or convenience, the rules win.

---

## 5. Phase 0 — Source Cleanup and Canonical Goal

### Status

Mostly complete.

### Purpose

Create a clean source foundation and avoid instruction conflicts.

### Required active artifacts

```text
INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md
BUG_REGISTER.md
```

After this file is uploaded, the required active artifacts become:

```text
INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md
INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md
BUG_REGISTER.md
```

### Completion criteria

Phase 0 is complete when:

- the canonical goal file is active;
- this foundation phase plan is active;
- the bug register remains active;
- old overlapping status/context files are archived or removed from active Project Sources;
- no contradictory roadmap controls the project.

---

## 6. Phase 1 — Foundation Phase Plan

### Status

This document is the Phase 1 artifact.

### Purpose

Lock the build order, artifact names, phase dependencies, source hygiene rules, and do-not-skip gates.

### Artifact

```text
INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md
```

### Project Source instruction

Upload this file to Project Sources after generation and approval.

### Completion criteria

Phase 1 is complete when:

- this file exists;
- the file is uploaded as a Project Source;
- the project follows the sequence in this file;
- no later phase starts by bypassing the data contract, source strategy, or acceptance criteria.

---

## 7. Phase 2 — Research Data Contract

### Purpose

Define the structured dataset that every industry packet must use.

This is the next major phase after this foundation plan.

The research data contract must answer:

```text
What tables exist?
What fields exist?
Which fields are required?
Which fields are conditional?
Which fields are optional?
Which fields are derived?
Which fields require direct source evidence?
Which fields can be estimated?
Which fields are user-defined assumptions?
Which HTML sections consume each table?
Which validators check each table?
Which simulation modules use each field?
```

### Artifact name

```text
INDUSTRY_RESEARCH_DATA_CONTRACT.md
```

### Required design principles

- Narrative must be generated from structured facts, not the reverse.
- The schema must be universal across industries, with adaptive optional modules.
- Every field must have a status: required, conditional, optional, derived, assumption, or user-defined.
- Every material field must define its evidence requirement.
- Every table must include identifiers where needed for reproducible joins.

### Mandatory core IDs

```text
industry_id
segment_id
node_id
edge_id
source_id
evidence_id
claim_id
company_id
security_id
event_id
scenario_id
assumption_id
simulation_output_id
risk_id
falsifier_id
quality_gate_id
```

### Mandatory core tables

At minimum, the data contract must include these core tables:

```text
industry_boundary
industry_segments
source_ledger
atomic_evidence
value_chain_nodes
value_chain_edges
money_flows
profit_pools
cost_structure
demand_drivers
end_customers
supply_constraints
bottlenecks
regulation_policy
technology_disruption
company_universe
security_master
company_segment_exposure
financial_sensitivity
valuation_context
quantamental_signals
event_catalysts
scenario_assumptions
simulation_outputs
opportunity_zones
long_short_implications
risks_falsifiers
quality_gates
gap_register
```

### Completion criteria

Phase 2 is complete when:

- every table is defined;
- every field is defined;
- required/conditional/optional status is assigned;
- source-backed/assumption/derived status is assigned;
- each table maps to HTML sections;
- each table maps to validators;
- each simulation-relevant field maps to simulation logic;
- the file is uploaded to Project Sources.

---

## 8. Phase 3 — Source Strategy and Reference Playbook

### Purpose

Define how the system researches any industry with disciplined source coverage.

The source strategy must prevent random web searching and one-source-per-summary behavior.

### Artifact name

```text
INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md
```

### Required source strategy

Every industry must use two source layers:

#### Layer 1 — Mandatory source families

These are source categories that must be checked for every industry where applicable:

```text
industry classification sources
government/statistical sources
regulator sources
trade association sources
company filings and annual reports
investor presentations
earnings calls and management commentary
segment financial disclosures
market size / production / shipment data
pricing / commodity / input cost data
import/export / customs / trade-flow data
standards bodies and technical references
patent / technology trend sources
news / event / litigation / regulatory update sources
private company / PE / M&A sources where available
```

#### Layer 2 — Dynamic industry-specific references

After resolving the industry boundary, the system must discover sources specific to that industry’s economics, regulation, technology, and company universe.

Examples:

```text
Semiconductor equipment: SEMI, WFE data, fab capex, wafer starts, export controls, ASML/Lam/KLA/Applied disclosures.
HVAC equipment: AHRI, DOE rules, refrigerant regulation, housing starts, replacement cycles, OEM/distributor data.
Payments processing: BIS, Fed, ECB, Visa/Mastercard filings, take-rate data, interchange regulation, merchant acquiring economics.
```

### Source count guidance

Minimums are adaptive, not flat:

```text
8+ sources  = seed minimum
12+ sources = normal investable baseline
15+ sources = regulated/global/complex baseline
20+ sources = opaque/private/fragmented/complex industry baseline
```

### Evidence density guidance

Evidence rows must be atomic. One source can and should produce many evidence rows.

```text
30+ atomic evidence rows  = seed-level packet
100+ atomic evidence rows = investable packet candidate
250+ atomic evidence rows = institutional-quality packet candidate where possible
```

### Completion criteria

Phase 3 is complete when:

- mandatory source families are defined;
- dynamic source discovery rules are defined;
- source hierarchy and credibility scoring are defined;
- source freshness rules are defined;
- source conflict handling is defined;
- source metadata requirements are defined;
- required template fields map to source types;
- the file is uploaded to Project Sources.

---

## 9. Phase 4 — Acceptance Criteria and Validation Gates

### Purpose

Define when an industry packet is allowed to be considered seed-level, investable, institutional-grade, or world-class.

This phase prevents fake scoring and polished low-quality outputs.

### Artifact name

```text
INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md
```

### Maturity levels

The system must define and use maturity levels:

```text
Level 0 — Objective only
Level 1 — Seed research
Level 2 — Structured source/evidence dataset
Level 3 — Investable industry packet
Level 4 — Institutional-quality packet
Level 5 — World-class reusable engine output
```

### Hard fail criteria

An output must not be labeled investment-grade if any of these are missing or broken:

```text
clear industry boundary
durable source ledger
atomic evidence ledger
end-to-end value chain
value-chain edges and money-flow logic
company/security exposure map
scenario assumptions
simulation outputs
catalyst/event logic
risks and falsifiers
citation coverage for material claims
conflict handling
gap register
quality report
validator pass status
```

### Completion criteria

Phase 4 is complete when:

- maturity levels are defined;
- hard fails are defined;
- minimum thresholds are defined;
- scoring components are defined;
- validator dependencies are defined;
- incomplete-output labeling rules are defined;
- the file is uploaded to Project Sources.

---

## 10. Phase 5 — HTML Packet Template Specification

### Purpose

Define the consistent interactive HTML packet that consumes the validated dataset.

The HTML template must not be designed before the data contract and acceptance gates.

### Artifact name

```text
INDUSTRY_HTML_PACKET_TEMPLATE_SPEC.md
```

### Required HTML tabs/sections

The packet should include a consistent structure:

```text
Executive Investment View
Industry Boundary
Value Chain
Node Economics
Profit Pools
Company/Security Exposure
Demand and End Customers
Supply Constraints and Bottlenecks
Competition
Regulation and Policy
Technology Disruption
Financial Sensitivity
Quantamental Signals
Catalysts and Event Calendar
Scenario Simulator
Opportunity Zones
PE/Growth Diligence
Risks and Falsifiers
Evidence Ledger
Quality Report
```

### Required HTML behaviors

- Clicking a claim must reveal the supporting evidence.
- Clicking a value-chain node must reveal economics, companies, evidence, risks, and simulation variables.
- Scenario inputs must update outputs where feasible.
- Quality state must be visible.
- Missing data must appear as gaps, not be hidden.
- Evidence and assumptions should be exportable as CSV/JSON where feasible.

### Completion criteria

Phase 5 is complete when:

- tab/section structure is defined;
- data dependencies are mapped;
- interaction behavior is specified;
- evidence drilldown behavior is specified;
- simulation UI behavior is specified;
- quality-report display is specified;
- the file is uploaded to Project Sources.

---

## 11. Phase 6 — Simulation Engine Contract

### Purpose

Define the scenario and sensitivity logic behind the interactive packet.

Simulation is core to the project because the target horizon is month-to-year investment research.

### Artifact name

```text
INDUSTRY_SIMULATION_ENGINE_CONTRACT.md
```

### Mandatory scenarios

```text
Base
Bull
Bear
Shock
Structural transition
Custom user scenario
```

### Mandatory scenario variables

Variables should include, where relevant:

```text
market growth
volume
price
input costs
gross margin
operating margin
utilization
capex
working capital
interest rates
FX
tariffs
subsidies
regulation
competitive intensity
adoption speed
valuation multiple
```

### Mandatory simulation outputs

Simulation must show:

```text
which value-chain nodes win
which value-chain nodes lose
which companies benefit
which companies are hurt
which securities are most exposed
which catalysts matter more
which assumptions drive the thesis
what breaks the thesis
```

### Completion criteria

Phase 6 is complete when:

- scenario types are defined;
- variables are defined;
- assumption types are defined;
- sensitivity logic is defined;
- simulation output tables are defined;
- thesis invalidation logic is defined;
- narrative simulation report format is defined;
- the file is uploaded to Project Sources.

---

## 12. Phase 7 — Validator and Scoring Specification

### Purpose

Define the validation system that prevents unsupported, incomplete, or broken outputs from being labeled high quality.

### Artifact name

```text
INDUSTRY_VALIDATOR_AND_SCORING_SPEC.md
```

### Mandatory validators

```text
source_coverage_validator
evidence_density_validator
schema_completeness_validator
value_chain_completeness_validator
money_flow_validator
company_exposure_validator
simulation_integrity_validator
citation_coverage_validator
blank_detection_validator
conflict_handling_validator
quality_score_consistency_validator
role_lens_validator
```

### Validator output requirements

Every validator should eventually produce machine-readable output:

```text
validator_id
status: pass / warning / fail
score_component
affected_tables
affected_fields
reason
required_fix
severity
```

### Scoring principles

- No validation means no high score.
- No source/evidence traceability means no investment-grade label.
- Broken simulation is a hard fail.
- Hidden blanks are a hard fail.
- Unsupported investment conclusions are a hard fail.
- Scores must decompose by source, evidence, schema, simulation, investment logic, role-lens quality, and UI completeness.

### Completion criteria

Phase 7 is complete when:

- validator list is defined;
- validator inputs and outputs are defined;
- scoring decomposition is defined;
- hard-fail rules are mapped to validators;
- failure fingerprint logic is defined;
- regression requirements are defined;
- the file is uploaded to Project Sources.

---

## 13. Phase 8 — One-Industry Prototype

### Purpose

Test the full pipeline deeply before scaling.

A one-industry prototype should expose structural flaws in schema, sources, extraction, simulation, HTML, and validation.

### Artifact name

```text
INDUSTRY_ONE_PROTOTYPE_EXECUTION_PLAN.md
```

### Recommended prototype industry type

Use a complex, investable, data-rich industry. Strong candidates:

```text
semiconductor manufacturing equipment
HVAC equipment
payments processing
medical devices
EV charging infrastructure
```

A good prototype industry should have:

- public companies;
- private companies;
- clear value-chain nodes;
- source availability;
- company/security mapping;
- catalysts;
- scenario variables;
- real risks/falsifiers.

### Prototype requirements

The prototype must include:

```text
structured dataset
source ledger
atomic evidence ledger
value-chain map
money-flow map
company/security exposure
scenario assumptions
simulation outputs
catalyst/event logic
risks/falsifiers
HTML packet
quality report
validator output
```

### Completion criteria

Phase 8 is complete when:

- one full industry prototype is generated;
- quality report identifies pass/fail areas;
- repeated failures are logged;
- required patches are identified;
- prototype artifacts are stored but not automatically added as Project Sources unless they contain reusable rules.

---

## 14. Phase 9 — Five-Industry Cross-Sector Test

### Purpose

Test whether the schema and source strategy generalize across sectors.

### Recommended five-industry mix

Use one from each broad category:

```text
data-rich industrial
regulated healthcare
financial/payment
consumer/service
energy/infrastructure
```

### Purpose of the five-industry test

The test should identify:

```text
schema gaps
source strategy failures
extraction failures
company mapping failures
simulation weaknesses
HTML template weaknesses
validator false positives / false negatives
role-lens gaps
```

### Completion criteria

Phase 9 is complete when:

- five cross-sector industries are tested;
- each has a quality report;
- repeated failure fingerprints are summarized;
- hard-gate failures are prioritized;
- patches are planned before any 20-industry test.

---

## 15. Phase 10 — Twenty-Industry Mass Test and Regression

### Purpose

Benchmark generality and move toward world-class repeatability.

### Requirements

The 20-industry mass test should only occur after:

```text
data contract exists
source strategy exists
acceptance criteria exist
HTML spec exists
simulation contract exists
validator spec exists
one-industry prototype completed
five-industry cross-sector test completed
hard failures patched
```

### Mass-test outputs

The mass test should generate:

```text
source coverage matrix
evidence density matrix
schema completeness matrix
validator pass/fail matrix
industry quality scores
failure fingerprint register
patch priority list
regression test results
performance metrics
```

### Completion criteria

Phase 10 is complete when:

- 20 industries are tested;
- all scores are validator-backed;
- no fake high scores are assigned;
- repeated failures are patched;
- unrelated industries are regression-tested after patches;
- next-generation improvements are documented.

---

## 16. Role-Specific Quality Requirements

The project must satisfy five professional lenses.

### 16.1 Long/short equity PM lens

Required outputs:

```text
opportunity zones
long candidates
short candidates
pair/basket ideas
upside/downside logic
valuation context
catalyst path
crowding/liquidity where possible
falsifiers
```

### 16.2 Fundamental equity analyst lens

Required outputs:

```text
segment revenue exposure
margin drivers
unit economics
capital intensity
cash conversion
cyclicality
accounting risks
earnings sensitivity
valuation sensitivity
```

### 16.3 Quantamental data lead lens

Required outputs:

```text
structured data
time-series signal definitions
feature formulas
source freshness
data quality
backtest status where possible
signal confidence
anomaly flags
```

### 16.4 Event-driven special situations PM lens

Required outputs:

```text
catalyst calendar
event probability
event impact
timing path
regulatory/litigation/M&A/supply disruption tracking
scenario impact
falsifiers
```

### 16.5 Growth equity / PE sector principal lens

Required outputs:

```text
market map
private company universe
fragmentation/consolidation logic
unit economics
customer retention / sales motion where relevant
sponsor-owned assets
exit attractiveness
diligence questions
red flags
```

The final quality report should show where the packet is strong or weak by role lens.

---

## 17. Investment Integrity Rules

The project must never promise guaranteed returns.

Approved language:

```text
risk-adjusted opportunity discovery
evidence-backed opportunity zones
asymmetric setup
high-conviction research implication
investment research support
scenario-weighted expected value
```

Rejected language:

```text
guaranteed profit
no-brainer buy
100% success
risk-free trade
certain winner
```

Outputs may rank companies, securities, baskets, risks, and opportunities as research implications, but they must not become personalized financial advice.

Every major thesis must include:

```text
source support
confidence level
counterargument
falsifier
catalyst path
upside/downside logic
scenario sensitivity
```

---

## 18. Artifact Naming Convention

All core foundation files should use uppercase descriptive project-specific names.

Approved artifact names:

```text
INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md
INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md
INDUSTRY_RESEARCH_DATA_CONTRACT.md
INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md
INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md
INDUSTRY_HTML_PACKET_TEMPLATE_SPEC.md
INDUSTRY_SIMULATION_ENGINE_CONTRACT.md
INDUSTRY_VALIDATOR_AND_SCORING_SPEC.md
INDUSTRY_ONE_PROTOTYPE_EXECUTION_PLAN.md
INDUSTRY_MASS_TEST_AND_REGRESSION_PLAN.md
```

Run-specific artifacts should be stored separately from Project Sources unless distilled into reusable project law.

---

## 19. Project Source Upload Policy by Phase

| Phase artifact | Upload to Project Sources? | Reason |
|---|---:|---|
| Canonical project goal | Yes | Defines mission and quality standard |
| Foundation phase plan | Yes | Defines build order and gates |
| Bug register | Yes | Preserves known engineering risks |
| Research data contract | Yes | Defines operating schema |
| Source strategy/reference playbook | Yes | Controls research behavior |
| Acceptance criteria/validation gates | Yes | Controls quality and scoring |
| HTML packet template spec | Yes | Controls output surface |
| Simulation engine contract | Yes | Controls scenario logic |
| Validator/scoring spec | Yes | Controls pass/fail system |
| One-industry prototype output | Usually no | Run artifact, not project law |
| Mass-test raw artifacts | Usually no | Raw test output; summarize lessons instead |
| Reconciled current-state file | Yes, if needed | Volatile state, clearly marked |

---

## 20. Immediate Next Action

After this file is generated and uploaded as a Project Source, the next action is:

```text
Create INDUSTRY_RESEARCH_DATA_CONTRACT.md
```

This data contract must be created before:

```text
HTML template generation
simulation UI design
mass testing
scoring
```

The data contract is the foundation of the engine.

---

## 21. Final Approved Build Doctrine

The approved doctrine is:

```text
Do not build a beautiful dashboard first.
Build the institutional data machine first.
Then build the dashboard on top of it.
```

The project succeeds only if the final HTML packet is backed by:

```text
structured data
atomic evidence
source hierarchy
company/security mapping
simulation assumptions
validator-backed quality gates
transparent gaps
role-specific investment logic
```

Any output that lacks these elements must be labeled incomplete or not investment-grade.

---

## 22. Approval Record

The phase plan questionnaire was approved in full by the user.

Approval phrase:

```text
Approve all
```

No exceptions were requested.

Therefore, this document is the canonical foundation phase plan for the next stage of the Industry Intelligence Engine.
