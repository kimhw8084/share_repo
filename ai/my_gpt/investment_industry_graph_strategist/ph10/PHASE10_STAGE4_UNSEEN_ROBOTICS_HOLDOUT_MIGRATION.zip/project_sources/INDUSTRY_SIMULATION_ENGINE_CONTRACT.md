# Industry Intelligence Engine — Simulation Engine Contract

**Filename:** `INDUSTRY_SIMULATION_ENGINE_CONTRACT.md`  
**Project:** Industry Intelligence Engine  
**Phase:** Phase 6 — Simulation Engine Contract  
**Status:** Canonical / Approved  
**Authority:** Active project law after upload to Project Sources  
**Depends on:**
- `INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md`
- `INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md`
- `INDUSTRY_RESEARCH_DATA_CONTRACT.md`
- `INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md`
- `INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md`
- `INDUSTRY_HTML_PACKET_TEMPLATE_SPEC.md`

---

## 1. Purpose

Phase 6 defines the canonical simulation law for the Industry Intelligence Engine.

The simulation engine is not a prediction guarantee, target-price machine, or decorative dashboard feature. It is a transparent, auditable, evidence-linked decision-support model used to test how changes in assumptions alter:

- value-chain node winners and losers,
- value-chain edge and money-flow behavior,
- company and security exposure,
- financial sensitivity,
- valuation context,
- catalysts and event paths,
- risk and falsifier thresholds,
- opportunity-zone rankings,
- role-specific investment interpretation.

No industry packet may be called **Institutional** or **World-Class** if simulation logic is missing, broken, hidden, unsupported, overprecise, disconnected from the value chain, or disconnected from company/security exposure where investable securities exist.

---

## 2. Simulation philosophy

The simulation engine must obey these principles:

1. **Decision support, not prediction guarantee.** The model explores scenario implications; it does not claim to know the future.
2. **Assumptions are first-class data.** Every assumption must be visible, typed, bounded, sourced or labeled, and confidence-scored.
3. **Structured data is source of truth.** Simulation consumes the Phase 2 dataset and must not invent unsupported data.
4. **Evidence lineage is mandatory.** Every source-backed or derived assumption must link to source/evidence records.
5. **Transparency beats complexity.** Deterministic scenario and sensitivity analysis comes before probabilistic modeling.
6. **Ranges beat fake precision.** Use bands, confidence, and qualitative labels when evidence does not support exact values.
7. **Propagation is required.** Variables must flow through value-chain nodes/edges before reaching companies, securities, and opportunity zones.
8. **Downside is mandatory.** Bull, bear, shock, risks, and thesis-break logic must be present.
9. **Broken model = invalid output.** Formula errors, invalid units, missing lineage, and unsupported high-confidence outputs must fail.
10. **No personal financial advice.** Outputs are institutional research implications, not user-specific buy/sell instructions.

---

## 3. Simulation maturity levels

Simulation quality must be tracked separately from total packet maturity.

| Level | Label | Meaning | Max allowed use |
|---:|---|---|---|
| 0 | No Valid Simulation | Missing required assumptions, model structure, value-chain base, or formulas. | Diagnostic only |
| 1 | Directional Notes | Narrative scenario commentary with weak/no validated formulas. | Preliminary only |
| 2 | Basic Deterministic | Structured assumptions and directional node outputs. | Structured / early Investable |
| 3 | Investable Scenario Model | Node/company impacts, upside/downside, catalysts, risks, thesis breaks. | Investable Candidate |
| 4 | Institutional Model | Multi-variable, evidence-linked, sensitivity-ranked, scenario-complete, validation-ready. | Institutional |
| 5 | Benchmark-Ready Model | Versioned, reproducible, robust across sectors, regression-tested, uncertainty-aware. | World-Class |

Rules:

- Institutional packet maturity requires simulation maturity Level 4+.
- World-Class packet maturity requires simulation maturity Level 5 and benchmark proof.
- Simulation maturity must be visible in the HTML quality and simulator tabs.
- Low simulation maturity must cap final packet maturity even if other modules are strong.

---

## 4. Required scenario families

Every institutional-grade packet must support these canonical scenarios:

| Scenario | Required | Purpose |
|---|---:|---|
| Base | Yes | Evidence-consistent current trajectory. |
| Bull | Yes | Plausible upside case with bounded assumptions. |
| Bear | Yes | Serious downside case that challenges the thesis. |
| Shock | Yes | Sudden disruption: policy, supply, demand, rates, litigation, capacity, tariff, subsidy, etc. |
| Structural Transition | Yes | Long-term industry architecture or profit-pool change. |
| Custom User Scenario | Yes | User-modified assumptions clearly labeled as user-defined. |

Every scenario must include:

- `scenario_id`,
- scenario name,
- scenario type,
- time horizon,
- affected geography,
- affected segments,
- assumption set,
- source/evidence status,
- confidence level,
- scenario narrative,
- winners/losers,
- risks,
- thesis-break conditions,
- gaps and limitations.

Time horizons:

- 1–3 months,
- 3–12 months,
- 1–3 years.

Scenario probability is optional. If used, it must be source-backed, derived, analyst-estimated, model-default, or user-defined. Magic probabilities are forbidden.

---

## 5. Scenario construction rules

### 5.1 Base case

The base case must be built from:

- current evidence,
- latest available market/company data,
- management and industry commentary,
- current policy/regulatory status,
- current known catalysts,
- consensus expectations where accessible,
- explicit assumptions where evidence is incomplete.

The base case must not be a default optimistic scenario.

### 5.2 Bull case

Bull-case assumptions must be:

- plausible,
- bounded,
- evidence-linked or clearly labeled,
- internally consistent,
- connected to specific nodes/companies/opportunities.

Fantasy upside is forbidden.

### 5.3 Bear case

Bear-case assumptions must be:

- serious,
- specific,
- plausible,
- linked to risks/falsifiers,
- strong enough to challenge the thesis.

Token bear cases are invalid.

### 5.4 Shock case

Shock cases must be derived from known risk/event categories, such as:

- regulatory change,
- litigation,
- tariff/subsidy change,
- demand collapse,
- supply disruption,
- financing/rate shock,
- capacity oversupply,
- geopolitical disruption,
- key customer/supplier failure,
- technology substitution.

Shock scenarios must show affected nodes, companies, securities, and opportunity-zone changes.

### 5.5 Structural transition case

Structural transition cases must model long-term changes such as:

- technology displacement,
- business-model migration,
- customer behavior shift,
- capital-cycle reversal,
- profit-pool migration,
- regulatory regime shift,
- platform or ecosystem shift,
- substitution or complement expansion.

### 5.6 Custom user case

User-defined assumptions must be clearly marked as `user_defined` and separated from canonical source-backed scenarios. User input must never overwrite official base/bull/bear/shock/transition assumptions.

---

## 6. Assumption contract

Every simulation assumption must be a structured record.

Required fields:

| Field | Required | Notes |
|---|---:|---|
| `assumption_id` | Yes | Stable ID. |
| `scenario_id` | Yes | Links to scenario. |
| `variable_name` | Yes | Controlled or documented variable. |
| `variable_category` | Yes | Demand, pricing, cost, supply, capital, competitive, policy, macro, technology, event, valuation, etc. |
| `value` | Yes, unless gap | Numeric, categorical, boolean, or range. |
| `unit` | Yes | Unitless values forbidden for quantitative assumptions. |
| `period` | Yes | Time period or horizon. |
| `geography` | Conditional | Required when geography matters. |
| `segment_id` | Conditional | Required when segment-specific. |
| `node_id` | Conditional | Required when value-chain node is affected. |
| `company_id` | Conditional | Required when company impact is modeled. |
| `security_id` | Conditional | Required when security impact is modeled. |
| `source_status` | Yes | `source_backed`, `derived`, `analyst_estimate`, `model_default`, `user_defined`, `gap`. |
| `source_id` | Conditional | Required for source-backed assumptions. |
| `evidence_id` | Conditional | Required for source-backed/derived assumptions where possible. |
| `confidence_score` | Yes | Numeric and categorical recommended. |
| `allowed_min` | Conditional | Required for interactive numeric controls. |
| `allowed_max` | Conditional | Required for interactive numeric controls. |
| `default_value` | Conditional | Required for UI controls. |
| `formula_id` | Conditional | Required when used in derived output. |
| `rationale` | Yes | Explanation of why assumption exists. |
| `limitations` | Yes | Caveats, uncertainty, and data weaknesses. |

No hidden assumptions are allowed.

---

## 7. Variable taxonomy

The simulation engine must support these variable categories.

### 7.1 Demand variables

- market growth,
- unit volume,
- adoption rate,
- penetration,
- replacement cycle,
- customer budget,
- end-market demand,
- customer churn/retention,
- procedure volume where relevant,
- traffic/engagement where relevant.

### 7.2 Pricing variables

- average selling price,
- take rate,
- reimbursement rate,
- contract price,
- discounting,
- price erosion,
- inflation pass-through,
- lease/rent rate,
- CPM/ad rate where relevant.

### 7.3 Cost variables

- raw material cost,
- labor cost,
- energy cost,
- logistics cost,
- component cost,
- cloud/infrastructure cost,
- customer acquisition cost,
- compliance cost,
- financing cost where operating-cost relevant.

### 7.4 Supply variables

- capacity,
- utilization,
- lead time,
- inventory,
- yield,
- production constraint,
- supplier concentration,
- availability,
- backlog,
- shipment rate.

### 7.5 Capital variables

- capex,
- depreciation,
- working capital,
- inventory days,
- receivable days,
- payable days,
- leverage,
- interest burden,
- refinancing cost.

### 7.6 Competitive variables

- competitive intensity,
- share shift,
- new entrants,
- substitution,
- switching cost,
- concentration,
- pricing rationality,
- channel power.

### 7.7 Policy variables

- tariffs,
- subsidies,
- tax credits,
- export controls,
- reimbursement,
- compliance burden,
- permitting,
- litigation/regulatory outcome.

### 7.8 Macro variables

- interest rates,
- FX,
- GDP/industrial production,
- housing starts,
- commodity cycle,
- consumer confidence,
- unemployment,
- inflation.

### 7.9 Technology variables

- adoption curve,
- cost curve,
- learning rate,
- productivity improvement,
- replacement risk,
- platform shift,
- patent/exclusivity status,
- R&D maturity.

### 7.10 Event variables

- event occurrence,
- event timing,
- probability,
- impact magnitude,
- delay/acceleration,
- approval/rejection/partial outcome,
- affected nodes/companies/securities.

### 7.11 Valuation variables

- multiple,
- discount rate,
- terminal growth,
- risk premium,
- liquidity discount,
- crowding discount,
- sector spread,
- exit multiple.

---

## 8. Industry-adaptive simulation modules

The model must use a universal core plus adaptive industry modules.

| Industry archetype | Required module variables |
|---|---|
| Industrial / manufacturing | capacity, utilization, orders, backlog, shipments, ASP, input costs, capex cycle, lead times, inventory, trade flow. |
| Healthcare / medtech / pharma | procedure volume, reimbursement, approval probability, adoption, pricing, hospital capex, clinical risk, patent/exclusivity, regulation. |
| Financials / payments | transaction volume, take rate, interchange/regulation, credit losses, rates, fraud, merchant mix, cross-border volume. |
| Software / platform | ARR growth, retention, churn, NRR, ARPU, CAC, usage, cloud cost, seat expansion, pricing, platform risk. |
| Energy / commodities | commodity price, production, reserves, decline rate, transport cost, capex, regulation, geopolitical disruption. |
| Consumer / retail | units, traffic, basket size, pricing, promotions, inventory, gross margin, channel mix, brand demand. |
| Transportation / logistics | volume, rates, fuel, labor, utilization, capacity, network density, congestion, regulation. |
| Telecom / infrastructure | subscribers, traffic, ARPU, churn, capex, spectrum, utilization, rates, lease escalators. |
| Media / advertising | ad spend, CPM, impressions, engagement, subscription, churn, content cost, privacy rules, platform mix. |
| Real estate / infrastructure | occupancy, rent, cap rate, financing cost, supply pipeline, tenant concentration, utilization, maintenance capex. |

Unsupported module variables must become explicit gaps, not guessed values.

---

## 9. Propagation logic

The canonical propagation path is:

```text
Variable change
→ affected value-chain node / edge
→ money flow / profit pool / cost structure effect
→ company exposure effect
→ security and valuation effect where applicable
→ opportunity-zone ranking change
→ risk/falsifier/catalyst interpretation
```

### 9.1 Value-chain node propagation

Each affected node should define:

- sensitivity coefficient or qualitative sensitivity,
- direction of impact,
- materiality,
- source/evidence support,
- confidence,
- affected profit pool,
- affected bottleneck status,
- affected companies.

### 9.2 Value-chain edge propagation

Edges should model:

- physical flow,
- money flow,
- data flow,
- regulatory flow,
- service/contract flow,
- risk transmission,
- pass-through ability,
- take-rate or price mechanism,
- bottleneck amplification.

### 9.3 Pass-through logic

The model must explicitly consider who can pass cost/price/regulatory shocks downstream. Margin impact must not be guessed without pass-through assumptions.

### 9.4 Upstream/downstream transmission

- Final-customer demand shocks must propagate upstream.
- Upstream supply/input shocks must propagate downstream.
- Regulatory shocks may benefit one node while hurting another.
- Substitution and complement effects must be modeled where relevant.

---

## 10. Company and security propagation

Simulation must affect companies/securities when investable exposure exists.

Company impact must consider:

- segment exposure,
- revenue purity,
- margin exposure,
- geography,
- node participation,
- cost exposure,
- customer/supplier role,
- exposure direction,
- exposure magnitude,
- diversification,
- valuation context,
- liquidity/crowding where available.

Rules:

- Pure-plays and conglomerates must be treated differently.
- Segment purity scales scenario impact.
- Exposure direction must be explicit: benefits, hurt, mixed, uncertain.
- Company and security impacts should be range-based unless evidence supports precision.
- Missing company/security exposure must block or downgrade security-level outputs.
- Long/short/pair/basket implications are research outputs, not personal recommendations.

---

## 11. Financial statement bridge

For Investable+ packets, simulation must bridge industry variables to company financial drivers when data allows.

Minimum bridge:

```text
Revenue effect = price effect × volume effect
```

or a sector-specific equivalent.

Additional financial bridges:

- gross margin,
- operating margin,
- operating leverage,
- input-cost sensitivity,
- capex intensity,
- working capital,
- free cash flow,
- leverage/balance-sheet stress where relevant,
- accounting-risk adjustments,
- consensus/expectation gap where accessible.

Operating impact and valuation impact must be separated.

---

## 12. Valuation and expected-value logic

Valuation matters when securities are ranked.

Allowed valuation methods include:

- multiples sensitivity,
- high-level DCF bridge,
- EV/revenue,
- EV/EBITDA,
- P/E,
- P/B,
- sector-specific valuation metrics,
- exit multiple for PE/growth view.

Rules:

- Valuation method must vary by industry.
- Valuation assumptions must be explicit and bounded.
- Valuation outputs should be range-based.
- Earnings impact and multiple impact must be separated.
- Expected value is allowed only with explicit probability assumptions.
- Expected-value output must be disabled when probabilities are missing, invalid, or unlabeled.
- Security rankings without valuation context must be labeled as gaps/watchlist, not high-conviction output.

---

## 13. Sensitivity analysis

Sensitivity analysis is mandatory for Investable+ packets.

Required types:

1. **One-way sensitivity:** Change one variable while holding others constant.
2. **Two-way sensitivity:** Change two key variables together where feasible.
3. **Ranked/tornado sensitivity:** Show which assumptions most affect outputs.
4. **Breakpoint sensitivity:** Identify thresholds that break the thesis.

Sensitivity variables must be selected by:

- materiality,
- uncertainty,
- impact on value-chain nodes,
- impact on company/security outputs,
- relevance to opportunity zones,
- evidence quality.

Sensitivity outputs must include confidence and be exportable.

---

## 14. Thesis-break and falsifier logic

Every thesis and opportunity zone must have measurable or observable breakpoints.

A thesis breakpoint is a condition that invalidates or materially weakens the thesis.

Required links:

- assumption_id,
- evidence_id where applicable,
- scenario_id,
- node_id,
- company_id/security_id where applicable,
- event_id where applicable,
- opportunity_zone_id,
- risk_id,
- confidence.

User inputs that cross breakpoints must trigger visible warnings.

Breakpoints must affect opportunity rankings and confidence.

---

## 15. Event and catalyst simulation

Material catalysts must be simulated where possible.

Event variables:

- occurrence,
- timing,
- probability,
- delay/acceleration,
- impact magnitude,
- branch outcome,
- affected nodes,
- affected companies/securities,
- scenario dependency,
- source/evidence status,
- freshness.

Event branches may include:

- approve,
- reject,
- delay,
- partial outcome,
- accelerated outcome,
- unknown.

Negative catalysts are mandatory.

Past/stale events must not be simulated as future catalysts.

---

## 16. Quantamental signal integration

Quantamental signals may inform:

- base-case direction,
- variable ranges,
- confidence,
- timing,
- event probability,
- scenario selection,
- opportunity ranking.

Rules:

- Signals must not blindly override fundamentals.
- Signal lineage must be documented.
- Signal freshness and lag must be respected.
- Untested signals are hypothesis-only.
- Point-in-time status must be visible where possible.
- Conflicting signals reduce confidence.
- Signal-derived assumptions must link to signal records.
- Missing quant signals reduce quant role score but do not automatically block all simulation.

---

## 17. PE / growth equity simulation

The PE/growth view must support simulation where relevant.

Variables:

- market growth,
- pricing,
- margin,
- retention/churn,
- unit economics,
- consolidation,
- leverage,
- exit multiple,
- capex,
- working capital,
- sponsor/M&A activity,
- private-market gaps.

PE simulation outputs:

- consolidation attractiveness,
- roll-up sensitivity,
- unit-economics sensitivity,
- exit attractiveness,
- diligence questions,
- red flags,
- private-market evidence gaps.

Private-market data gaps must be visible.

---

## 18. Uncertainty and confidence

Every simulation output must include confidence.

Confidence drivers:

- source quality,
- evidence density,
- assumption provenance,
- formula validity,
- model simplicity/robustness,
- conflict status,
- data freshness,
- sensitivity concentration,
- missing gaps,
- role-specific coverage.

Confidence should be both:

- numeric, e.g. 0–100,
- categorical, e.g. high, medium, low, unknown.

Rules:

- Low-confidence outputs must be visually marked.
- Unresolved conflicts widen uncertainty.
- Stale data reduces confidence.
- Highly sensitive outputs require fragility warnings.
- Assumption quality caps output quality.
- Confidence affects opportunity ranking.

---

## 19. Probabilistic modeling and Monte Carlo

Monte Carlo is optional and advanced. It is not a Phase 6 core requirement.

Monte Carlo is allowed only when:

- distributions are explicit,
- ranges are bounded,
- correlations are considered where material,
- variable lineage exists,
- deterministic sensitivity already exists,
- output limitations are shown.

Monte Carlo cannot increase score automatically. A fancy probabilistic model with weak assumptions is inferior to a simple transparent deterministic model.

---

## 20. Formula contract

Every formula must be stored and versioned.

Required formula fields:

| Field | Required | Notes |
|---|---:|---|
| `formula_id` | Yes | Stable ID. |
| `formula_name` | Yes | Human-readable name. |
| `expression` | Yes | Formula expression or calculation logic. |
| `input_fields` | Yes | Required inputs. |
| `output_fields` | Yes | Produced outputs. |
| `units` | Yes | Input and output units. |
| `scenario_scope` | Yes | Scenario(s) where formula applies. |
| `industry_module` | Conditional | Required for archetype-specific formulas. |
| `version` | Yes | Formula version. |
| `limitations` | Yes | What formula does not capture. |
| `source_or_theory_reference` | Conditional | Required where externally based. |

Rules:

- Formula units must be checked.
- Unit conversions must be explicit.
- Formula errors hard-fail simulation.
- Derived outputs must link to formula_id.
- Prefer simple transparent formulas before complex opaque formulas.

---

## 21. Simulation output reports

Every scenario must produce a human-readable and machine-readable report.

Scenario report must include:

- scenario identity,
- assumptions changed,
- assumption source status,
- affected nodes,
- affected edges/money flows,
- company/security impacts,
- financial impacts,
- valuation impacts where applicable,
- opportunity ranking changes,
- winners and why,
- losers and why,
- top sensitivities,
- confidence and limitations,
- thesis-break conditions,
- gaps blocking better simulation.

Scenario reports must be exportable.

---

## 22. Required simulation output tables

Simulation outputs must be stored as structured data, not only UI state.

Required output tables:

| Table | Required | Purpose |
|---|---:|---|
| `scenario_outputs` | Yes | Scenario-level results. |
| `node_impact_outputs` | Yes | Value-chain node impact. |
| `edge_impact_outputs` | Yes | Flow and propagation impact. |
| `company_impact_outputs` | Conditional | Required where company universe exists. |
| `security_impact_outputs` | Conditional | Required where securities exist. |
| `financial_sensitivity_outputs` | Conditional | Required for Investable+. |
| `valuation_outputs` | Conditional | Required where securities are ranked. |
| `opportunity_ranking_outputs` | Yes | Scenario-adjusted opportunity rankings. |
| `sensitivity_outputs` | Yes | One-way/two-way/tornado sensitivity. |
| `thesis_break_outputs` | Yes | Falsifier and breakpoint results. |
| `event_simulation_outputs` | Conditional | Required when catalysts are modeled. |
| `simulation_gap_outputs` | Yes | Missing data/model gaps. |

Every output row must include:

- `run_id`,
- `scenario_id`,
- output ID,
- confidence,
- assumption lineage,
- formula lineage where applicable,
- source/evidence lineage where applicable,
- limitation/gap notes.

---

## 23. Custom user scenario behavior

Users may modify assumptions, but custom scenarios must obey guardrails.

Rules:

- User changes are labeled `user_defined`.
- User scenario results are separate from canonical scenarios.
- User inputs must have allowed ranges.
- Out-of-range inputs trigger warnings.
- Thesis-break inputs trigger warnings.
- Missing-propagation inputs trigger warnings.
- User scenarios can be exported where feasible.
- User inputs do not change official packet quality score.

---

## 24. Simulation failure behavior

Simulation must be disabled when:

- core assumptions are missing,
- formulas are broken,
- units are invalid,
- value chain is missing,
- company/security exposure is missing where required,
- core propagation links are broken,
- unsupported assumptions drive high-confidence outputs,
- stale events are treated as future catalysts,
- thesis-break logic is absent for claimed opportunity rankings.

Simulation must be labeled incomplete when:

- data is partial,
- evidence density is weak,
- company mapping is incomplete,
- valuation context is missing,
- quant signals are missing,
- non-blocker conflicts remain unresolved,
- private-market information is incomplete.

Failure states must explain why and identify next actions.

---

## 25. Compliance and safety behavior

Simulation outputs must:

- avoid personalized financial advice,
- avoid prediction guarantees,
- avoid certainty language,
- use public/permissioned data only,
- separate sourced data from user-defined assumptions,
- display uncertainty,
- warn about valuation, liquidity, crowding, and data limitations where relevant.

Forbidden language:

- “guaranteed profit,”
- “will definitely happen,”
- “buy this now,”
- “risk-free,”
- “no-brainer return,”
- any unsupported certainty claim.

Allowed language:

- “research implication,”
- “risk-adjusted opportunity zone,”
- “scenario-sensitive,”
- “evidence-backed but uncertain,”
- “watchlist / hypothesis,”
- “not investment-grade yet.”

---

## 26. Role-specific simulation gates

### 26.1 Long/short equity PM

Simulation must show:

- impact on long/short/pair/basket implications,
- upside/downside,
- catalyst sensitivity,
- valuation sensitivity,
- thesis breaks,
- liquidity/crowding warnings where available.

### 26.2 Fundamental equity analyst

Simulation must show:

- revenue bridge,
- margin bridge,
- cost sensitivity,
- capex/working-capital sensitivity,
- accounting-risk implications,
- earnings/valuation sensitivity.

### 26.3 Quantamental data lead

Simulation must show:

- signal-linked assumptions,
- data lineage,
- freshness,
- formula definitions,
- lag/point-in-time status,
- tested vs hypothesis status.

### 26.4 Event-driven PM

Simulation must show:

- event branches,
- probability/impact/timing,
- affected companies/securities,
- negative catalysts,
- delays/approval/rejection outcomes.

### 26.5 PE / growth equity sector principal

Simulation must show:

- unit economics,
- consolidation sensitivity,
- retention/churn,
- leverage/exit sensitivity,
- private-market gaps,
- diligence questions.

Role-specific simulation gaps must be visible.

---

## 27. Non-negotiable laws

1. Simulation is a decision-support model, not a prediction guarantee.
2. Every assumption must be visible, bounded, typed, sourced/labeled, and confidence-scored.
3. Required scenarios are base, bull, bear, shock, structural transition, and custom.
4. Simulation must propagate through value-chain nodes and edges.
5. Simulation must propagate to company/security exposure where investable securities exist.
6. Financial sensitivity must bridge industry variables to revenue, margins, capex, cash flow, and valuation where possible.
7. Opportunity rankings must change by scenario and show upside, downside, catalysts, risks, and falsifiers.
8. Thesis-break thresholds are mandatory.
9. Sensitivity analysis is mandatory before advanced probabilistic modeling.
10. Monte Carlo is optional later, never first.
11. Event/catalyst simulation must include probability/impact/timing when used.
12. Low-confidence or incomplete simulations must be visibly labeled.
13. Broken formulas or invalid units hard-fail simulation.
14. Simulation outputs must be stored/exported as structured data.
15. Simulation cannot produce personal financial advice or fake certainty.

---

## 28. Phase 6 completion definition

Phase 6 is complete when this file is uploaded to Project Sources and accepted as the canonical simulation law.

The next phase is:

```text
Phase 7 — Validator and Scoring Specification
```

Phase 7 must define executable validator behavior that checks compliance with this simulation contract, including assumption integrity, formula validity, unit consistency, lineage, confidence, output completeness, failure states, and score caps.
