# Industry Intelligence — Canonical Project Goal and Product Specification

**Version:** v2.0 canonical objective  
**Approved by user:** 2026-06-29  
**Purpose:** This file is the canonical high-level project goal for the Industry Intelligence engine. It should replace fragmented or outdated high-level mission/objective files. It should not be used as the live progress tracker.

---

## 1. Canonical One-Sentence Objective

Given only the name of an industry, the system generates a fully interactive, evidence-traceable, institutional-grade HTML intelligence and simulation packet that maps the industry end-to-end, simulates future scenarios, identifies risk-adjusted long-term opportunity zones, ranks exposed companies and securities, and explains exactly what must be true, what could go wrong, what would invalidate the thesis, and what evidence supports every material conclusion.

---

## 2. Product Identity

The project is not a generic report generator.

The project is a **one-input institutional industry intelligence and simulation engine**.

The user provides only an industry name by default, for example:

```text
Semiconductor manufacturing equipment
Payments processing
HVAC equipment
Pharmaceutical CDMO
Telecom towers
```

The engine returns a complete interactive HTML packet that behaves like an investment cockpit, not a static report.

---

## 3. Professional Standard

The packet must reflect the combined work product of these institutional roles:

1. **Partner-level long/short equity portfolio manager**  
   Focus: risk-adjusted opportunity, variant perception, upside/downside, catalyst path, falsifiers, portfolio relevance, long/short and pair/basket implications.

2. **Director-level fundamental equity analyst**  
   Focus: company exposure, revenue drivers, margin drivers, unit economics, valuation, accounting quality, earnings sensitivity, competitive advantage, management commentary, and consensus gap.

3. **Senior quantamental data lead**  
   Focus: structured data, point-in-time discipline, alternative data, signal definitions, feature quality, data freshness, backtestability, signal decay, and measurable leading indicators.

4. **Event-driven / special situations PM**  
   Focus: catalysts, regulation, litigation, M&A, restructuring, tariff/subsidy changes, product launches, approvals, capacity shocks, and probability-weighted event impact.

5. **Growth equity / PE sector principal**  
   Focus: market maps, private company universe, business quality, unit economics, retention, sales motion, pricing power, consolidation potential, sponsor assets, diligence questions, and exit attractiveness.

The engine must not merely summarize what is happening. It must explain where economic value is created, where it is captured, which entities benefit or lose, and what changes the investment view over month-to-year horizons.

---

## 4. Core Product Promise

The engine must maximize **investment decision quality**, not promise guaranteed returns.

The correct institutional framing is:

```text
Find the highest-quality, highest-conviction, risk-adjusted, evidence-backed opportunity zones within an industry, with explicit upside, downside, catalysts, counterarguments, falsifiers, and uncertainty.
```

The engine must never claim guaranteed profit, no-risk opportunity, or certainty that cannot be supported by evidence.

---

## 5. Non-Negotiable Operating Law

The project must obey this sequence:

```text
Structured dataset first.
Evidence and validation second.
Narrative and visualization third.
Investment interpretation last.
```

No output may be considered institutional-grade unless it has:

1. Durable source ledger.
2. Atomic evidence extraction.
3. Complete value-chain mapping.
4. Company and security exposure mapping.
5. Financial and scenario logic.
6. Catalyst/event layer.
7. Quantamental signal layer.
8. PE/growth diligence layer.
9. Quality-control report.
10. Explicit gaps, uncertainties, and falsifiers.

---

## 6. Required Final Output

For each industry, the final deliverable is a **single self-contained interactive HTML packet**, plus optional structured exports.

### 6.1 Required HTML packet tabs

The packet must contain these tabs or equivalent navigation sections:

1. **Executive Investment View**
2. **Industry Definition and Boundaries**
3. **End-to-End Value Chain**
4. **Node Economics and Profit Pools**
5. **Company and Security Exposure**
6. **Demand Drivers and End Customers**
7. **Supply Constraints and Bottlenecks**
8. **Competitive Structure**
9. **Regulation, Policy, and Geopolitics**
10. **Technology and Disruption Map**
11. **Financial Model Implications**
12. **Quantamental Signals**
13. **Catalyst and Event Calendar**
14. **Scenario Simulator**
15. **Long/Short Opportunity Ranking**
16. **PE / Growth Equity Diligence View**
17. **Risks, Bear Case, and Falsifiers**
18. **Evidence Ledger**
19. **Quality-Control Report**
20. **Export / Reproducibility Section**

### 6.2 Required interactive elements

The HTML packet must include, where relevant:

- Clickable value-chain graph.
- Node-level economics cards.
- Company exposure matrix.
- Profit-pool heatmap.
- Bottleneck and constraint map.
- Catalyst/event timeline.
- Simulation sliders and scenario controls.
- Sensitivity tables.
- Quantamental signal panel.
- Evidence drilldowns.
- Quality scorecard with hard-gate status.
- Downloadable assumptions/evidence exports.

The design must be consistent across industries. The structure should be fixed; the content depth should adapt to industry complexity.

---

## 7. Industry Boundary Rules

When the user provides an industry name, the engine must first resolve the industry boundary.

The engine must define:

1. Core products and services.
2. Upstream inputs.
3. Downstream customers.
4. End markets.
5. Geographic scope.
6. Public and private company universe.
7. Adjacent industries.
8. Substitutes and complements.
9. In-scope segments.
10. Out-of-scope exclusions.

If the industry name is ambiguous, the engine should proceed using the most likely institutional interpretation and display the boundary assumptions clearly. It should not block progress with excessive clarification unless the ambiguity would make the output materially wrong.

Default geography is global, with regional drilldowns for the United States, Europe, China, Asia ex-China, and emerging markets when relevant.

---

## 8. End-to-End Value-Chain Requirements

The minimum value-chain map must cover:

```text
Raw inputs → Components → Production / operations → Distribution / channel → Direct customers → Final end customers → Replacement / aftermarket / lifecycle
```

For each value-chain node, the engine must capture:

1. Role in the chain.
2. Products/services provided.
3. Buyers and sellers.
4. Revenue model.
5. Margin profile.
6. Pricing power.
7. Cost structure.
8. Capital intensity.
9. Working capital intensity.
10. Cyclicality.
11. Utilization sensitivity.
12. Supply constraints.
13. Demand drivers.
14. Substitutes.
15. Switching costs.
16. Regulatory exposure.
17. Technology disruption risk.
18. Representative companies.
19. Evidence support.
20. Confidence and data gaps.

The engine must map physical flows, financial flows, data flows, regulatory flows, and service/aftermarket flows where relevant.

---

## 9. Money-Flow and Profit-Pool Requirements

The engine must answer:

1. Who pays whom?
2. For what product, service, access, license, capacity, data, or risk transfer?
3. How is pricing determined?
4. Which node captures gross profit?
5. Which node captures operating profit?
6. Which node is commoditized?
7. Which node has pricing power?
8. Which node is capacity constrained?
9. Which node has recurring revenue?
10. Which node has margin expansion or compression risk?

A value-chain diagram without money-flow economics is insufficient.

---

## 10. Evidence Standard

The project must use **atomic evidence rows**, not source summaries.

One source may generate many evidence rows.

Each material evidence row must include:

1. `evidence_id`
2. `source_id`
3. `claim_id`
4. `industry_id`
5. `node_id`, if applicable
6. `company_id`, if applicable
7. `security_id`, if applicable
8. Claim or extracted fact
9. Metric value, if numeric
10. Unit
11. Period
12. Geography
13. Source title
14. Publisher
15. Author, if available
16. Publication date
17. Access date
18. URL or durable source locator
19. Source section/table/page location
20. Exact quote or table reference where allowed
21. Paraphrased extraction
22. Source quality tier
23. Confidence score
24. Caveat or limitation
25. Conflict status
26. Linked schema table and field
27. Analyst note
28. Validation status

Material investment conclusions must be traceable back to evidence rows.

---

## 11. Source Coverage Rules

The engine must adapt source depth to industry complexity.

Minimum source thresholds:

| Industry Type | Minimum Sources Before Packet Can Be Considered Investable |
|---|---:|
| Simple/public industry | 8+ seed sources, 12+ preferred |
| Normal investable industry | 12+ |
| Regulated/global industry | 15+ |
| Opaque/private/complex industry | 20+ |
| Institutional deep-diligence packet | 25+ where available |

Evidence thresholds:

| Maturity Level | Minimum Evidence Rows |
|---|---:|
| Seed packet | 30+ |
| Investable packet | 100+ |
| Institutional packet | 250+ |
| Deep diligence packet | 500+ where available |

The system may produce a partial packet below these levels, but it must label the packet as incomplete and not investment-grade yet.

---

## 12. Source Quality Hierarchy

Source tiers must be controlled and explicit.

Recommended source hierarchy:

1. **Tier 1A — Regulators, statistical agencies, official datasets.**
2. **Tier 1B — Company filings, annual reports, 10-K/20-F, investor presentations, earnings transcripts.**
3. **Tier 2A — Industry associations with primary data.**
4. **Tier 2B — Standards bodies, exchanges, official trade groups.**
5. **Tier 3 — Reputable financial/news publications.**
6. **Tier 4 — Sell-side/broker reports or professional datasets, where available and permissioned.**
7. **Tier 5 — Market research reports, useful but often requiring corroboration.**
8. **Tier 6 — Company marketing pages and vendor claims, used with bias warning.**
9. **Tier 7 — Blogs, forums, social media, weak-signal only unless corroborated.**

Weak sources may be used only as weak signals, not as primary evidence for major conclusions.

---

## 13. Company and Security Mapping Requirements

The engine must map industry intelligence to investable and strategically relevant entities.

For each relevant company, capture:

1. Company name.
2. Public/private status.
3. Ticker, exchange, currency, and security type if public.
4. Parent/subsidiary relationships.
5. Segment exposure.
6. Revenue exposure.
7. Margin exposure.
8. Geographic exposure.
9. Customer exposure.
10. Supplier exposure.
11. Node exposure in value chain.
12. Sensitivity to industry variables.
13. Competitive position.
14. Balance sheet and capital intensity relevance.
15. Valuation relevance where available.
16. Liquidity and crowding considerations where available.
17. Evidence support.
18. Confidence and data gaps.

Diversified companies must not be treated as pure plays unless the evidence supports it. Segment exposure matters more than company headline.

---

## 14. Fundamental Equity Analysis Requirements

The engine must connect industry facts to company financial implications.

For each material exposed company or company archetype, analyze:

1. Revenue drivers.
2. Volume drivers.
3. Price drivers.
4. Gross margin drivers.
5. Operating leverage.
6. Capex intensity.
7. Working capital needs.
8. Cash conversion.
9. Unit economics.
10. Backlog/order book relevance.
11. Customer concentration.
12. Supplier concentration.
13. Input cost exposure.
14. Foreign exchange exposure.
15. Interest-rate exposure.
16. Accounting quality issues.
17. Consensus expectation gap, where available.
18. Valuation sensitivity.
19. Earnings revision risk.
20. Downside/failure modes.

“TAM is large” is never sufficient. The engine must explain how industry structure flows into earnings, cash flow, and valuation.

---

## 15. Quantamental Data Requirements

The engine must include a quantamental layer when data exists.

Required signal categories include, where relevant:

1. Price indicators.
2. Volume indicators.
3. Shipment indicators.
4. Order/backlog indicators.
5. Inventory indicators.
6. Utilization indicators.
7. Pricing surveys or market price data.
8. Input cost signals.
9. Macro indicators.
10. Rates and FX indicators.
11. Earnings estimate revisions.
12. Web/search/news intensity.
13. Regulatory-event signals.
14. Alternative data signals.
15. Company guidance changes.
16. Customer demand proxies.
17. Supply-chain stress signals.
18. Capacity expansion/shutdown signals.

Each signal must define:

1. Feature name.
2. Formula or construction logic.
3. Source.
4. Frequency.
5. Data vintage.
6. Reporting lag.
7. Expected direction.
8. Affected nodes/companies.
9. Historical relevance, if known.
10. Confidence and caveats.

If no backtest exists, the signal must be labeled as an untested hypothesis.

---

## 16. Event-Driven and Catalyst Requirements

The engine must include an event/catalyst calendar.

Catalyst types include:

1. Earnings.
2. Guidance.
3. Investor days.
4. Product launches.
5. Regulatory decisions.
6. Litigation.
7. M&A.
8. Spin-offs.
9. Restructurings.
10. Tariffs.
11. Subsidies.
12. Policy deadlines.
13. Contract awards/losses.
14. Capacity additions/shutdowns.
15. Bankruptcies/distress.
16. Labor strikes.
17. Supply disruptions.
18. Technology transitions.
19. Approval/reimbursement events.
20. Index/ownership/crowding events where relevant.

Each catalyst must include:

1. Event description.
2. Date or expected window.
3. Status: confirmed, likely, speculative.
4. Probability.
5. Expected impact.
6. Affected nodes.
7. Affected companies/securities.
8. Evidence support.
9. Scenario implication.
10. Falsifier.

---

## 17. PE / Growth Equity Diligence Requirements

The engine must include a PE/growth diligence view.

Required outputs include:

1. Market map.
2. Private company universe.
3. Sponsor-owned assets.
4. Strategic acquirer universe.
5. Roll-up/consolidation potential.
6. Fragmentation analysis.
7. Business-model archetypes.
8. Revenue quality.
9. Recurring revenue profile.
10. Retention/churn where relevant.
11. Sales motion.
12. Customer acquisition economics where relevant.
13. Pricing model.
14. Gross margin and contribution margin logic.
15. Capex and working capital intensity.
16. Customer concentration.
17. Vendor concentration.
18. Regulatory risks.
19. Exit attractiveness.
20. Diligence red flags.
21. Expert-call question bank.
22. Management-call question bank.

The PE view must evaluate business quality, not only market growth.

---

## 18. Scenario Simulation Requirements

Simulation is core to the product, not an optional feature.

Required scenarios:

1. Base case.
2. Bull case.
3. Bear case.
4. Shock case.
5. Structural transition case.
6. Custom user scenario.

Required adjustable variables include, where relevant:

1. Market growth.
2. Volume.
3. Pricing.
4. Mix shift.
5. Input costs.
6. Labor costs.
7. Utilization.
8. Capex.
9. Working capital.
10. FX.
11. Interest rates.
12. Tariffs.
13. Subsidies.
14. Regulation.
15. Adoption speed.
16. Competitive intensity.
17. Margin compression/expansion.
18. Valuation multiples.
19. Technology substitution.
20. Customer churn/retention where relevant.

Each simulation must show:

1. Which value-chain nodes win.
2. Which nodes lose.
3. Which companies benefit.
4. Which companies are hurt.
5. Which securities have higher/lower exposure.
6. Which assumptions matter most.
7. Which thesis is invalidated under which condition.
8. What evidence supports the assumptions.
9. Which assumptions are user-defined or estimated.
10. A written simulation report for each scenario.

Monte Carlo may be added later, but deterministic sensitivity and transparent assumptions are mandatory first.

---

## 19. Long/Short Opportunity Ranking Requirements

The final decision layer must rank:

1. Opportunity zones.
2. Value-chain nodes.
3. Companies.
4. Securities.
5. Long baskets.
6. Short baskets.
7. Pair candidates.
8. Avoid areas.
9. Catalyst setups.
10. Key risks and falsifiers.

Ranking dimensions include:

1. Upside potential.
2. Downside risk.
3. Evidence quality.
4. Timing.
5. Catalyst strength.
6. Valuation support.
7. Moat/pricing power.
8. Financial sensitivity.
9. Liquidity.
10. Crowding.
11. Risk concentration.
12. Falsifiability.
13. Data confidence.
14. Scenario resilience.

The packet must distinguish research implications from personalized financial advice. It may rank opportunity zones and securities for research, but it must not promise returns.

---

## 20. Required Quality Gates

The packet must fail or be labeled incomplete if any hard gate fails.

Hard-fail conditions:

1. No source ledger.
2. No atomic evidence extraction.
3. Missing industry boundary.
4. Missing end-to-end value chain.
5. Missing company/security exposure map.
6. Unsupported investment thesis.
7. Broken or missing simulation logic.
8. Hidden blanks.
9. Inconsistent state or manifest.
10. Fake scores or unsupported quality claims.
11. Missing counterarguments.
12. Missing falsifiers.
13. Material numeric claims without source or data-status label.
14. Contradictory evidence ignored.
15. No quality-control report.

If the packet fails a hard gate, it must display:

```text
Not investment-grade yet.
```

Then it must list the exact gaps required to reach investment-grade quality.

---

## 21. Validation Requirements

Validation must be executable, not only prose.

Required validators:

1. Source coverage validator.
2. Evidence density validator.
3. Source quality validator.
4. Citation/claim coverage validator.
5. Value-chain completeness validator.
6. Node economics validator.
7. Money-flow validator.
8. Final-customer path validator.
9. Company/security mapping validator.
10. Financial-sensitivity validator.
11. Scenario-integrity validator.
12. Catalyst/event validator.
13. Quantamental signal validator.
14. PE diligence validator.
15. Conflict-handling validator.
16. Blank/null validator.
17. Data-status validator.
18. Scoring-consistency validator.
19. State/manifest consistency validator.
20. HTML packet integrity validator.

Every validation failure must produce a failure fingerprint, severity, affected table/section, and repair instruction.

---

## 22. Scoring Philosophy

Scoring must be honest and strict.

A high score is not allowed unless the proof chain exists.

No source trail → no score.  
No evidence matrix → no score.  
No company/security mapping → no investment-grade claim.  
No scenario validation → no simulation-grade claim.  
No validation report → no release-grade claim.  
No falsifiers → no high-conviction claim.  

Scores must be based on validated data quality, not presentation quality.

Recommended scoring components:

1. Source coverage.
2. Source quality.
3. Evidence density.
4. Value-chain completeness.
5. Node economics completeness.
6. Company/security mapping completeness.
7. Financial logic quality.
8. Scenario logic quality.
9. Catalyst/event quality.
10. Quantamental signal quality.
11. PE diligence quality.
12. Risk/falsifier quality.
13. Citation traceability.
14. Conflict handling.
15. Reproducibility.
16. HTML usability.

A beautiful packet with weak evidence must score poorly.

---

## 23. Data Architecture Requirements

The engine must be structured-data first.

Required normalized IDs:

1. `industry_id`
2. `segment_id`
3. `node_id`
4. `edge_id`
5. `company_id`
6. `security_id`
7. `source_id`
8. `evidence_id`
9. `claim_id`
10. `metric_id`
11. `event_id`
12. `signal_id`
13. `scenario_id`
14. `assumption_id`
15. `thesis_id`
16. `risk_id`
17. `falsifier_id`
18. `validation_id`
19. `packet_id`
20. `run_id`

Narrative must be generated from structured data, not used as the primary data store.

---

## 24. Recommended Universal Schema Families

The historical 25-table schema should be retained as a base but upgraded into broader schema families.

Required schema families:

1. Industry metadata.
2. Source ledger.
3. Evidence ledger.
4. Claims ledger.
5. Metrics and time series.
6. Value-chain nodes.
7. Value-chain edges.
8. Money flows.
9. Products and services.
10. Final customers and demand segments.
11. Companies.
12. Securities.
13. Company exposure mapping.
14. Market structure.
15. Cost structure.
16. Capacity and supply.
17. Demand drivers.
18. Current signals.
19. Quantamental features.
20. Risks and bottlenecks.
21. Regulation and policy.
22. Technology substitution.
23. Events and catalysts.
24. Scenarios.
25. Simulation assumptions.
26. Simulation outputs.
27. Investment themes.
28. Theme traceability.
29. Falsifiers.
30. PE diligence.
31. Watchlist.
32. Validation results.
33. Quality scorecard.
34. Packet manifest.
35. Reusable snapshot.

The exact physical table count may evolve, but these data domains must exist.

---

## 25. Workflow from One Industry Input

The engine must follow this workflow:

1. Receive industry name.
2. Resolve industry boundary and aliases.
3. Classify industry archetype and complexity.
4. Generate adaptive source plan.
5. Gather sources by hierarchy and coverage gap.
6. Extract atomic evidence rows.
7. Build source and evidence ledgers.
8. Build value-chain nodes and edges.
9. Map money flows and profit pools.
10. Map final customers and demand drivers.
11. Map public and private companies.
12. Map securities and exposure sensitivity.
13. Build market structure and competitive analysis.
14. Build regulation, policy, and technology-disruption layers.
15. Build quantamental signal panel.
16. Build catalyst/event calendar.
17. Build PE/growth diligence view.
18. Build scenario assumptions.
19. Run scenario simulations.
20. Generate simulation reports.
21. Generate opportunity ranking and thesis/falsifier set.
22. Run validation gates.
23. Generate quality-control report.
24. Generate interactive HTML packet.
25. Export evidence, assumptions, and manifest.
26. Save reusable snapshot for future updates.

The engine must be resumable from durable state.

---

## 26. Output Maturity Levels

The engine should support maturity labels.

### Seed Packet
- Basic source capture.
- Preliminary value-chain map.
- Initial companies and opportunity zones.
- Clearly incomplete.
- Not investment-grade.

### Investable Packet
- Sufficient source coverage.
- Complete core value chain.
- Company/security exposure map.
- Initial simulation logic.
- Evidence-backed thesis and risks.
- Validation mostly passed.

### Institutional Packet
- High source density.
- Atomic evidence depth.
- Complete structured schema.
- Robust simulation.
- Catalyst and quantamental layers.
- PE diligence view.
- Full quality-control report.
- Suitable as a professional research cockpit.

### Deep Diligence Packet
- Maximum available evidence.
- Expert-call question bank.
- Private company mapping.
- Advanced scenario analysis.
- Full diligence-grade risk and exit analysis.
- Best available institutional output.

Partial packets are acceptable only when honestly labeled.

---

## 27. Progress Reporting Rules

Progress must be real, not cosmetic.

Do not inflate progress with administrative tasks.

Recommended progress components:

```text
source_progress = min(sources_logged / target_sources, 1)
evidence_progress = min(evidence_rows / target_evidence_rows, 1)
table_fill_progress = completed_required_fields / total_required_fields
validation_progress = passed_validators / total_validators

phase_progress =
0.30 * source_progress +
0.30 * evidence_progress +
0.25 * table_fill_progress +
0.15 * validation_progress
```

Gap logging, packaging, and UI generation should be displayed separately from research completion.

---

## 28. State and Artifact Governance

This file is the canonical objective/specification file.

It must not be used as the live progress tracker.

Recommended project artifact roles:

1. **Canonical objective/spec** — this file.
2. **Current status** — separate volatile file with exact current counts.
3. **Project state JSON** — machine-readable live state.
4. **Bug register** — known bugs and regression requirements.
5. **Source/evidence artifacts** — raw logs, CSVs, JSON, HTML packets.
6. **Manifest** — generated artifact list and lineage.
7. **Next-chat prompt** — temporary continuation helper.

The canonical objective should change rarely. Progress files should change every run.

---

## 29. Known Non-Negotiable UI / Control Issue

The known shift-selection random range bug must remain tracked until fixed and regression-tested.

Rule:

```text
Do not rely on Shift-select for critical bulk operations.
```

Any UI involving evidence rows, source rows, monitoring, services, external items, or bulk updates must use deterministic ID-based selection scoped to the current visible/filter/sorted list.

Required selection state:

1. `last_anchor_id`
2. `current_clicked_id`
3. `visible_ordered_ids`
4. `filtered_ordered_ids`
5. `selection_scope`
6. `section_id`
7. `sort_state`
8. `filter_state`

Bulk actions require preview of exact selected IDs before execution.

---

## 30. Honesty and Safety Requirements

The engine must obey these rules:

1. Do not present research implications as personalized financial advice.
2. Do not imply access to illegal or nonpublic information.
3. Do not fabricate sources, numbers, or confidence.
4. Do not hide uncertainty.
5. Do not treat rumors as facts.
6. Do not overfit quantamental findings.
7. Do not claim a packet is complete when evidence or validation is missing.
8. Do not claim 95+ quality without full proof chain.
9. Do not let UI polish disguise weak data.
10. Do not let a single source drive a major investment conclusion unless clearly labeled as low-confidence.

---

## 31. Final Approved Objective Block

The approved project goal is:

```text
Given only the name of an industry, the system generates a fully interactive, evidence-traceable, institutional-grade HTML intelligence and simulation packet that maps the industry end-to-end, from upstream inputs through final customers, profit pools, companies, securities, catalysts, risks, and long-term structural changes.

The packet must operate like the combined work product of a partner-level long/short equity PM, director fundamental equity analyst, senior quantamental data lead, event-driven special situations PM, and growth equity / PE sector principal.

The system must not produce a generic report. It must produce a decision-grade investment research cockpit that identifies the highest-quality, highest-conviction, risk-adjusted opportunity zones within the industry for month-to-year investment horizons.

Every major conclusion must be traceable to atomic evidence. Every thesis must include source support, confidence level, scenario sensitivity, counterargument, falsifier, catalyst path, and company/security exposure. The system must explicitly distinguish facts, estimates, assumptions, model outputs, and analyst interpretation.

The interactive packet must include complete value-chain mapping, node economics, money-flow analysis, company and security exposure mapping, market and demand analysis, supply constraints, competitive structure, regulation, technology disruption, quantamental signals, event/catalyst tracking, PE-style diligence, scenario simulation, sensitivity reports, long/short opportunity ranking, and a full quality-control report.

The system has zero tolerance for hallucinated data, unsupported claims, fake certainty, hidden blanks, broken calculations, inconsistent state, cosmetic scoring, and unvalidated outputs. If the evidence or validation is insufficient, the packet must clearly label itself as not investment-grade yet and show the exact gaps required to reach institutional quality.

The ultimate goal is to maximize investment decision quality: finding asymmetric, evidence-backed, risk-adjusted opportunity zones while clearly showing what must be true, what could go wrong, what would invalidate the thesis, and how each scenario changes the value-chain winners and losers.
```

---

## 32. Immediate Next Project Direction After Approval

After this objective is accepted as canonical, the next implementation priorities are:

1. Reconcile current project state and correct any inconsistent source/evidence counts.
2. Preserve raw artifacts and logs for audit.
3. Replace fragmented high-level objective files with this canonical objective.
4. Upgrade source/evidence schema from source summaries to atomic evidence rows.
5. Upgrade source thresholds by industry complexity.
6. Build executable validators.
7. Redesign progress calculation to avoid inflated administrative completion.
8. Continue source expansion only after state reconciliation.
9. Start 25-table or upgraded schema fill only after sufficient source/evidence density.
10. Generate the first institutional HTML packet only after data, simulation, and validation gates pass.

---

## 33. File Governance Recommendation

Use this file as the **single canonical project goal/specification**.

Do not store volatile progress counts in this file.

Keep separate files for:

- live status,
- machine-readable state,
- bug register,
- source/evidence logs,
- manifests,
- generated packets,
- next-run prompts.

Old files that duplicate mission, objective, or high-level instructions should be replaced or archived after their unique operational details are migrated.

