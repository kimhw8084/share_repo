# Phase 16 Stage 1 — One-Input Run Contract and Durable Orchestrator

## Input

One industry name, with optional geography, horizon, and investability scope.

## Durable outputs

- run request and request hash
- source-law lock
- pre-research industry boundary hypothesis
- archetype and complexity classification
- adaptive mandatory source-family plan
- canonical artifact graph including exact 19 HTML tabs
- empty source/evidence/search/rejection ledgers
- explicit blocker gap
- artifact-backed progress ledger
- durable run state and transition history

## Fail-closed rule

When no approved real search provider is configured, the run stops at `blocked_source_collection`, accepted source count remains zero, eligible evidence count remains zero, and no HTML or investment conclusion is generated.

## Nonclaims

Stage 1 does not claim source collection, real research, analytical completeness, simulation calibration, dynamic HTML, valuation/live quant, institutional quality, or production completion.
