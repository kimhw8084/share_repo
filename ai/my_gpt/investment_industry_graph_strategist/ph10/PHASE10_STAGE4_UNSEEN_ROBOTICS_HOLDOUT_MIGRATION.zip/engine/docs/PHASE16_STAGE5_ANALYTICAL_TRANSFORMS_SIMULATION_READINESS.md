# Phase 16 Stage 5 — Analytical Transforms and Simulation Readiness

## Purpose

Stage 5 converts the evidence-backed canonical dataset into deterministic, auditable scenario outputs. It does not browse, infer hidden assumptions, generate price targets, or present a decorative simulator.

## Command

```bash
industry-intel-engine prepare-simulation --workspace ./run
```

## Input law

The command reads the synchronized `industry_dataset.json` and canonical JSON tables. It refuses execution if the dataset and table files differ.

An executable assumption must include:

- a canonical scenario type;
- numeric value, baseline, unit, and explicit sensitivity coefficient;
- allowed or bounded ranges where interactive sensitivity is used;
- assumption owner and source/evidence lineage, or explicit model/analyst/user rationale and limitations;
- at least one valid affected value-chain node;
- a valid active `formula_id`.

An active formula must include:

- stable ID and version;
- safe arithmetic expression;
- declared input and output fields;
- units for every input and the output;
- scenario scope;
- limitations;
- active/disabled status.

Python attribute access, imports, comprehensions, strings, arbitrary functions, and undeclared names are prohibited.

## Deterministic propagation

The engine creates structured outputs for:

1. scenario summaries;
2. node impacts;
3. edge impacts;
4. company impacts;
5. security directional impacts;
6. financial sensitivities;
7. opportunity changes;
8. one-way sensitivity ranges;
9. thesis-break/falsifier evaluation;
10. simulation gaps.

Built-in bridge formulas are stored and versioned in `simulation/formula_registry_compiled.json`. They use only explicit node impacts, edge materiality, company exposure direction/magnitude, and equal-weight opportunity links. They do not infer missing pass-through, portfolio weights, probabilities, or valuation.

## Readiness states

### Level 0 — No Valid Simulation

The engine writes `disabled_insufficient_inputs` and removes all usable analytical outputs when a mandatory gate is missing, including canonical scenarios, value-chain nodes/edges, money flows, formulas, company exposure where required, or risks/falsifiers.

Simulation gap rows remain visible so the disabled state is auditable.

### Level 2 — Basic Deterministic

The engine writes `ready_basic_deterministic` only when:

- base, bull, bear, shock, and structural-transition assumptions are present;
- formula and unit validation passes;
- node and economic propagation structures exist;
- company/security exposure propagates where investable entities exist;
- opportunity and falsifier links exist;
- no simulation blocker remains.

Level 2 does not imply institutional or production readiness.

## Valuation and expected value

Valuation, price-target, and expected-value outputs remain disabled unless separate downstream gates prove current market-data provenance, bounded valuation methodology, valid probabilities, and human approval. Stage 5 never synthesizes these inputs.

## Artifacts

- `simulation_readiness.json`
- `simulation_transaction_journal.json`
- `simulation/formula_registry_compiled.json`
- `simulation/scenario_reports.json`
- all required structured simulation output tables under `simulation/`
- canonical `tables/simulation_outputs.json`
- updated `industry_dataset.json`
- updated `gap_register.json`
- updated run state, progress ledger, artifact graph, and final summary
