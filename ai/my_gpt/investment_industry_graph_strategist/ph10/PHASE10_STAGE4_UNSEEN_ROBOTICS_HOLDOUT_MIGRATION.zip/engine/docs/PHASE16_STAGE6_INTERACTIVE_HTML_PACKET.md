# Phase 16 Stage 6 — Interactive HTML Packet

## Purpose

Generate the exact 19-tab Industry Intelligence HTML packet from synchronized canonical JSON tables and Stage 5 analytical outputs without creating any claim that is absent from the canonical run artifacts.

## Commands

```bash
industry-intel-engine generate-html --workspace ./run
industry-intel-engine verify-html --workspace ./run --browser /usr/bin/chromium
```

`verify-html` requires Chromium/Chrome plus the optional Playwright Python package for browser interaction testing. `--allow-static-only` permits a non-browser structural check, but leaves the packet in `interactive_pending_browser_test` mode.

## Generated artifacts

- `index.html`
- `packet_data.json`
- `html_packet_audit.json`
- `exports_manifest.json`
- `exports/*.csv`

## Integrity rules

1. All 27 canonical table JSON files must exactly match `industry_dataset.json`.
2. The 19 tab names are fixed and exact.
3. Material fact rows must resolve to source or atomic-evidence lineage.
4. Derived simulation rows retain formula and assumption identifiers.
5. Empty modules render explicit gaps; they are not silently hidden.
6. Score and hard-fail fields remain pending until Stage 7 validation.
7. Valuation and probability outputs remain disabled unless separately supported and approved.
8. The packet is self-contained and uses no external JavaScript or CSS.
9. Browser verification exercises tab activation, search, evidence drawer, scenario controls, exports, and disabled-state behavior.
10. Generation and verification never set a production claim.
