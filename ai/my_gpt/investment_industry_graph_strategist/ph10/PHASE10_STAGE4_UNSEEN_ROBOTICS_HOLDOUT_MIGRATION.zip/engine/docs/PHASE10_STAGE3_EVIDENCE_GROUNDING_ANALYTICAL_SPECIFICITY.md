# Phase 10 Stage 3 — Evidence Grounding and Analytical Specificity

Engine version: 0.10.0

This stage makes institutional evidence grounding fail closed.

## Mandatory controls

- Immutable source-native captures or verifiable source-document spans.
- Explicit capture type, acquisition method, collector, source URL and native attestation.
- Generated, provider-normalized, fixture-only and output-derived text cannot qualify as source evidence.
- Every accepted evidence row stores an exact extraction span and deterministic semantic-support audit.
- Events require event-specific evidence, timing, affected entities and causal chains.
- Company sensitivities require company/security-specific evidence and causal bridges.
- Excessive evidence-set overlap across distinct events or companies is rejected.
- Falsifiers require machine-readable monitor variables, operators and thresholds.
- Solar-class holdouts require at least 85% recall against a frozen authoritative-domain registry.
- Research stopping requires a final freshness sweep and geography/local-language coverage.
- Role-lens scores reconcile to the canonical professional-lens table.

The sealed Phase 10 Stage 1 solar holdout is retained unchanged as a regression fixture. Under this stage it must hard-fail source-native grounding rather than be silently re-approved.
