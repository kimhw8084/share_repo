# Phase 16 Stage 4 — Canonical Dataset Population

## Purpose

Stage 4 converts eligible snapshot-backed atomic evidence into the canonical research dataset. It does not generate unsupported narrative or infer missing analytical records.

## Input contract

Use `industry-intel-engine populate-dataset --workspace <run> --records <proposal.json>`.

The proposal must contain:

- `analyst`: named accountable analyst;
- `records`: table/record/field-lineage proposals;
- optional `replace_tables`: canonical tables intentionally replaced as one transaction.

Every substantive required field must map to one or more eligible evidence IDs. Each evidence ID must:

- resolve to exactly one eligible atomic-evidence row;
- resolve to an accepted source;
- support the same canonical table;
- support the exact canonical field.

## Materialized outputs

- all canonical `tables/*.json` files;
- `industry_dataset.json`;
- `field_lineage.json`;
- `completeness_report.json`;
- `tables/professional_lenses.json`;
- reconciled `gap_register.json`;
- updated artifact graph, run state, progress ledger, and final summary.

## Integrity gates

Stage 4 rejects:

- unsupported tables;
- missing required fields;
- missing field-level lineage;
- unresolved/ineligible evidence;
- evidence-to-table or evidence-to-field mismatch;
- duplicate record IDs;
- cross-industry records;
- broken node, segment, company, security, assumption, event, opportunity, risk, or source references;
- symlinked proposal inputs;
- dataset population before a real source and eligible evidence exist.

## Completeness law

A table is `minimum_complete` only when it has at least one record, all required fields are present, and all lineage-required fields are resolved. Empty or lineage-deficient tables create visible gap records. The dataset remains non-production and HTML/simulation/final validation remain blocked.
