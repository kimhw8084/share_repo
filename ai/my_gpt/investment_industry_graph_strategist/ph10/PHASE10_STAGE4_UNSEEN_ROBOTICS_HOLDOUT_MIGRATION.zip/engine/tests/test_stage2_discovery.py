from __future__ import annotations

import json
from pathlib import Path

import pytest

from industry_intel_engine.discovery import import_search_results, normalize_url
from industry_intel_engine.models import RunRequest
from industry_intel_engine.orchestrator import initialize_run
from industry_intel_engine.snapshots import import_content_snapshot


def init(tmp_path: Path) -> Path:
    root = tmp_path / "run"
    initialize_run(RunRequest("Commercial HVAC equipment and services"), root)
    return root


def write_json(path: Path, payload: object) -> Path:
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def provider(tmp_path: Path, **extra) -> Path:
    payload = {"provider_id": "approved_import", "terms_accepted": True, "credential_ref": "env:SEARCH_TOKEN"}
    payload.update(extra)
    return write_json(tmp_path / "provider.json", payload)


def test_normalize_url_removes_tracking_and_fragment():
    assert normalize_url("HTTPS://Example.COM:443/a//b/?utm_source=x&z=2&a=1#frag") == "https://example.com/a/b?a=1&z=2"


def test_import_accepts_real_candidate_and_logs_query(tmp_path: Path):
    root = init(tmp_path)
    results = write_json(tmp_path / "results.json", {
        "query": "commercial HVAC annual report market",
        "source_family": "company_filings",
        "results": [{"url": "https://investor.carrier.com/financials/annual-reports", "title": "Annual Reports", "publisher": "Carrier Global", "publication_date": "2025-02-01"}],
    })
    out = import_search_results(root, results, provider(tmp_path))
    assert out["accepted_count"] == 1
    ledger = json.loads((root / "source_ledger.json").read_text())
    assert ledger[0]["eligible_for_evidence"] is False
    assert ledger[0]["status"] == "candidate_accepted_pending_snapshot"
    assert len(json.loads((root / "search_log.json").read_text())) == 1


def test_duplicate_canonical_url_rejected(tmp_path: Path):
    root = init(tmp_path)
    results = write_json(tmp_path / "results.json", {
        "query": "q", "results": [
            {"url": "https://example-news.test/report?utm_source=a", "title": "A", "publisher": "P"},
            {"url": "https://example-news.test/report", "title": "B", "publisher": "P"},
        ]})
    out = import_search_results(root, results, provider(tmp_path))
    assert out["accepted_count"] == 1
    assert out["rejected_count"] == 1
    assert "duplicate_canonical_url" in json.loads((root / "rejected_sources.json").read_text())[0]["reasons"]


def test_placeholder_source_rejected(tmp_path: Path):
    root = init(tmp_path)
    results = write_json(tmp_path / "results.json", {"query": "q", "results": [{"url": "https://example.com/report", "title": "A", "publisher": "P"}]})
    out = import_search_results(root, results, provider(tmp_path))
    assert out["accepted_count"] == 0
    assert "placeholder_or_local_host" in json.loads((root / "rejected_sources.json").read_text())[0]["reasons"]


def test_terms_must_be_accepted(tmp_path: Path):
    root = init(tmp_path)
    results = write_json(tmp_path / "results.json", {"query": "q", "results": []})
    with pytest.raises(ValueError, match="terms"):
        import_search_results(root, results, provider(tmp_path, terms_accepted=False))


def test_raw_credentials_prohibited(tmp_path: Path):
    root = init(tmp_path)
    results = write_json(tmp_path / "results.json", {"query": "q", "results": []})
    with pytest.raises(ValueError, match="raw credentials"):
        import_search_results(root, results, provider(tmp_path, api_key="secret"))


def test_bad_credential_reference_rejected(tmp_path: Path):
    root = init(tmp_path)
    results = write_json(tmp_path / "results.json", {"query": "q", "results": []})
    with pytest.raises(ValueError, match="credential_ref"):
        import_search_results(root, results, provider(tmp_path, credential_ref="plaintext"))


def test_snapshot_attaches_hash_but_not_evidence_eligibility(tmp_path: Path):
    root = init(tmp_path)
    results = write_json(tmp_path / "results.json", {"query": "q", "results": [{"url": "https://sec.gov/Archives/example", "title": "Filing", "publisher": "SEC"}]})
    import_search_results(root, results, provider(tmp_path))
    source_id = json.loads((root / "source_ledger.json").read_text())[0]["source_id"]
    content = tmp_path / "filing.html"
    content.write_text("<html>real filing snapshot</html>", encoding="utf-8")
    out = import_content_snapshot(root, source_id=source_id, content_file=content, source_native_attested=True)
    assert out["byte_size"] > 0
    row = json.loads((root / "source_ledger.json").read_text())[0]
    assert row["snapshot"]["sha256"] == out["snapshot_sha256"]
    assert row["eligible_for_evidence"] is False


def test_empty_snapshot_rejected(tmp_path: Path):
    root = init(tmp_path)
    results = write_json(tmp_path / "results.json", {"query": "q", "results": [{"url": "https://sec.gov/Archives/example", "title": "Filing", "publisher": "SEC"}]})
    import_search_results(root, results, provider(tmp_path))
    source_id = json.loads((root / "source_ledger.json").read_text())[0]["source_id"]
    content = tmp_path / "empty.txt"
    content.write_bytes(b"")
    with pytest.raises(ValueError, match="empty"):
        import_content_snapshot(root, source_id=source_id, content_file=content, source_native_attested=True)


def test_unknown_source_id_rejected(tmp_path: Path):
    root = init(tmp_path)
    content = tmp_path / "x.txt"
    content.write_text("x", encoding="utf-8")
    with pytest.raises(ValueError, match="exactly one"):
        import_content_snapshot(root, source_id="src_missing", content_file=content)
