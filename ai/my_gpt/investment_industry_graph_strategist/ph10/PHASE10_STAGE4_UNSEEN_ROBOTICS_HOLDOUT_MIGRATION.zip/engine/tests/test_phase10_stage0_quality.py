from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

import pytest

from industry_intel_engine.models import RunRequest
from industry_intel_engine.orchestrator import initialize_run
from industry_intel_engine.discovery import import_search_results
from industry_intel_engine.quality import continuous_saturation, record_stop_decision, source_funnel
from industry_intel_engine.validation import validate_run, _write_final_state_reconciliation
from test_stage5_simulation import _ready_workspace
from test_stage6_html import generate_html_packet, verify_html_packet


def _write(path: Path, payload: object) -> Path:
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def test_candidate_universe_persists_accept_reject_and_duplicate(tmp_path: Path):
    ws = tmp_path / "run"
    initialize_run(RunRequest(industry_name="Solar panel industry"), ws)
    provider = _write(tmp_path / "provider.json", {"provider_id": "test", "terms_accepted": True, "credential_ref": "env:TEST"})
    results = _write(tmp_path / "results.json", {
        "query": "solar official statistics",
        "source_family": "official_statistics",
        "results": [
            {"url": "https://energy.gov/solar?utm_source=x", "title": "Solar report", "publisher": "DOE"},
            {"url": "https://energy.gov/solar", "title": "Solar duplicate", "publisher": "DOE"},
            {"url": "https://example.com/fake", "title": "Fake", "publisher": "Example"},
        ],
    })
    result = import_search_results(ws, results, provider)
    assert result["accepted_count"] == 1
    assert result["rejected_count"] == 2
    funnel = source_funnel(ws)
    assert funnel["discovered_candidate_count"] == 3
    assert funnel["duplicate_candidate_count"] == 1
    assert funnel["pre_snapshot_rejected_count"] == 2
    assert funnel["rejection_observability_passed"] is True


def test_gap_driven_stop_decision_requires_low_yield_and_closed_material_gaps(tmp_path: Path):
    ws = tmp_path / "run"
    initialize_run(RunRequest(industry_name="Solar panel industry"), ws)
    plan = json.loads((ws / "source_plan.json").read_text())
    families = [
        {"source_family": row["source_family"], "mandatory": row["mandatory"], "status": "covered" if row["mandatory"] else "not_required"}
        for row in plan["items"]
    ]
    invalid = {
        "decision": "stop_approved", "reviewer": "analyst", "reviewer_role": "research_lead",
        "rationale": "Material research is complete but this rationale must still fail due to unresolved gaps.",
        "marginal_yield": {"queries_reviewed": 5, "new_accepted_sources": 0, "new_evidence_rows": 2, "material_gaps_closed": 0, "new_source_families": 0},
        "mandatory_family_status": families, "unresolved_material_gap_ids": ["gap_material"],
        "source_family_saturation_percent": 100,
        "freshness_sweep": {"completed": True, "queries_reviewed": 5, "latest_report_cutoff_date": "2026-07-28", "new_accepted_sources": 0},
        "geography_language_coverage": [{"geography": "Global", "languages": ["en"], "material": True, "status": "covered"}],
    }
    with pytest.raises(ValueError, match="stop_approved"):
        record_stop_decision(ws, _write(tmp_path / "invalid.json", invalid))
    (ws / "authoritative_source_recall.json").write_text(json.dumps({"passed": True, "recall_percent": 88.89, "target_domain_count": 18}), encoding="utf-8")
    valid = dict(invalid)
    valid["unresolved_material_gap_ids"] = []
    valid["rationale"] = "All mandatory source families are covered and the last five searches produced negligible marginal evidence yield."
    out = record_stop_decision(ws, _write(tmp_path / "valid.json", valid))
    assert out["approved"] is True
    assert out["decision"] == "stop_approved"


def test_continuous_evidence_curve_has_no_250_row_cliff():
    below = continuous_saturation(249, half_saturation=110)
    above = continuous_saturation(250, half_saturation=110)
    assert above > below
    assert above - below < 0.002


def _resize_research(ws: Path, source_count: int, evidence_count: int) -> None:
    dataset = json.loads((ws / "industry_dataset.json").read_text())
    base_source = deepcopy(dataset["tables"]["source_ledger"][0])
    sources = []
    for i in range(source_count):
        row = deepcopy(base_source)
        row["source_id"] = f"src_quality_{i}"
        row["url"] = f"https://authority{i}.gov/report"
        row["publisher"] = f"Authority {i}"
        row["source_family"] = ["official_statistics", "regulator_policy", "company_filings", "technical_standards", "industry_association", "academic_technical", "market_quant", "negative_risk"][i % 8]
        row["source_quality_tier"] = "tier_1_primary" if i % 3 else "tier_2_authoritative"
        row["freshness_status"] = "current"
        sources.append(row)
    base_evidence = deepcopy(dataset["tables"]["atomic_evidence"][0])
    evidence = []
    table_names = [name for name, rows in dataset["tables"].items() if rows and name not in {"source_ledger", "atomic_evidence"}]
    for i in range(evidence_count):
        row = deepcopy(base_evidence)
        row["evidence_id"] = f"ev_quality_{i}"
        row["source_id"] = sources[i % source_count]["source_id"]
        row["exact_quote_short"] = f"Distinct authoritative evidence statement number {i} with sufficient detail."
        row["claim_text"] = f"Distinct claim {i}"
        row["linked_table"] = table_names[i % len(table_names)]
        row["linked_field"] = f"field_{i}"
        row["freshness_status"] = "current"
        row["conflict_status"] = "none"
        evidence.append(row)
    dataset["tables"]["source_ledger"] = sources
    dataset["tables"]["atomic_evidence"] = evidence
    (ws / "industry_dataset.json").write_text(json.dumps(dataset), encoding="utf-8")
    (ws / "source_ledger.json").write_text(json.dumps(sources), encoding="utf-8")
    (ws / "atomic_evidence.json").write_text(json.dumps(evidence), encoding="utf-8")
    state = json.loads((ws / "run_state.json").read_text())
    state["source_count"] = source_count
    state["eligible_evidence_count"] = evidence_count
    (ws / "run_state.json").write_text(json.dumps(state), encoding="utf-8")
    audit = json.loads((ws / "html_packet_audit.json").read_text())
    audit["source_count"] = source_count
    audit["evidence_count"] = evidence_count
    (ws / "html_packet_audit.json").write_text(json.dumps(audit), encoding="utf-8")
    (ws / "search_log.json").write_text("[]", encoding="utf-8")
    (ws / "source_candidate_ledger.json").write_text("[]", encoding="utf-8")
    (ws / "research_stop_decision.json").write_text(json.dumps({"decision": "stop_approved", "approved": True}), encoding="utf-8")


def test_weak_medium_strong_bundles_do_not_collapse_to_one_score(tmp_path: Path):
    scores = []
    qualities = []
    for label, src, ev in (("weak", 8, 60), ("medium", 16, 150), ("strong", 28, 320)):
        ws = _ready_workspace(tmp_path / label)
        generate_html_packet(ws)
        verify_html_packet(ws, browser="/missing", require_browser=False)
        audit = json.loads((ws / "html_packet_audit.json").read_text())
        audit["browser_status"] = "passed"; audit["mode"] = "interactive_tested"
        (ws / "html_packet_audit.json").write_text(json.dumps(audit), encoding="utf-8")
        _resize_research(ws, src, ev)
        report = validate_run(ws)
        scores.append(report["overall_score"])
        qualities.append(report["research_quality_score"])
    assert len(set(scores)) == 3
    assert qualities[0] < qualities[1] < qualities[2]


def test_final_state_reconciliation_detects_post_finalize_mutation(tmp_path: Path):
    ws = _ready_workspace(tmp_path)
    generate_html_packet(ws)
    verify_html_packet(ws, browser="/missing", require_browser=False)
    audit = json.loads((ws / "html_packet_audit.json").read_text())
    audit["browser_status"] = "passed"; audit["mode"] = "interactive_tested"
    (ws / "html_packet_audit.json").write_text(json.dumps(audit), encoding="utf-8")
    state = json.loads((ws / "run_state.json").read_text())
    state["status"] = "validated_final_candidate"
    (ws / "run_state.json").write_text(json.dumps(state), encoding="utf-8")
    report = validate_run(ws)
    _write_final_state_reconciliation(ws, report)
    progress = json.loads((ws / "progress_ledger.json").read_text())
    progress["progress_percent"] = 99
    (ws / "progress_ledger.json").write_text(json.dumps(progress), encoding="utf-8")
    report = validate_run(ws)
    assert "final_state_atomicity" in report["failure_fingerprints"]
    assert report["hard_fail_status"] == "hard_fail"


def test_legacy_quality_migration_does_not_fabricate_stop_approval(tmp_path: Path):
    from industry_intel_engine.migration import migrate_phase9_quality_artifacts
    ws = _ready_workspace(tmp_path)
    # Remove new artifacts to simulate an accepted legacy Phase 9 bundle.
    for name in ("source_candidate_ledger.json", "research_stop_decision.json", "independent_corroboration_graph.json"):
        path = ws / name
        if path.exists(): path.unlink()
    out = migrate_phase9_quality_artifacts(ws)
    assert out["stop_reapproval_required"] is True
    stop = json.loads((ws / "research_stop_decision.json").read_text())
    assert stop["approved"] is False
    lenses = json.loads((ws / "tables" / "professional_lenses.json").read_text())
    assert all("quality_score" in row for row in lenses)
    completeness = json.loads((ws / "completeness_report.json").read_text())
    assert "direct_evidence_table_completeness_percent" in completeness


def test_cross_run_audit_detects_old_score_compression_and_target_convergence(tmp_path: Path):
    from industry_intel_engine.cross_run import audit_cross_run
    rows = [
        {"industry": "a", "overall_score": 79, "weighted_score_before_caps": 96.0, "accepted_sources": 24, "evidence": 240, "role_lens_quality": 100},
        {"industry": "b", "overall_score": 79, "weighted_score_before_caps": 97.0, "accepted_sources": 24, "evidence": 240, "role_lens_quality": 100},
        {"industry": "c", "overall_score": 79, "weighted_score_before_caps": 98.0, "accepted_sources": 24, "evidence": 240, "role_lens_quality": 100},
    ]
    result = audit_cross_run(_write(tmp_path / "scoreboard.json", rows))
    assert "reported_score_compression" in result["failure_fingerprints"]
    assert "source_evidence_target_convergence" in result["failure_fingerprints"]
    assert "role_lens_coverage_saturation" in result["failure_fingerprints"]


def test_cross_run_audit_passes_differentiated_scores_without_count_convergence(tmp_path: Path):
    from industry_intel_engine.cross_run import audit_cross_run
    rows = [
        {"industry": "a", "overall_score": 72, "research_quality_score": 70, "accepted_sources": 13, "eligible_evidence": 110, "role_lens_quality": 62},
        {"industry": "b", "overall_score": 82, "research_quality_score": 84, "accepted_sources": 20, "eligible_evidence": 190, "role_lens_quality": 76},
        {"industry": "c", "overall_score": 90, "research_quality_score": 92, "accepted_sources": 31, "eligible_evidence": 330, "role_lens_quality": 88},
    ]
    result = audit_cross_run(_write(tmp_path / "scoreboard.json", rows))
    assert result["status"] == "passed"
    assert result["failure_fingerprints"] == []
