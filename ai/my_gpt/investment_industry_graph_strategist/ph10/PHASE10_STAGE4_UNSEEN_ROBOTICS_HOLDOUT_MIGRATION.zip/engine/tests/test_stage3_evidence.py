import json
from pathlib import Path
import pytest
from industry_intel_engine.orchestrator import initialize_run
from industry_intel_engine.models import RunRequest
from industry_intel_engine.discovery import import_search_results
from industry_intel_engine.snapshots import import_content_snapshot
from industry_intel_engine.evidence import review_source, extract_evidence


def setup_run(tmp_path):
    ws=tmp_path/'run'; initialize_run(RunRequest(industry_name='Commercial HVAC equipment and services'), ws)
    pc=tmp_path/'provider.json'; pc.write_text(json.dumps({'provider_id':'test','terms_accepted':True,'credential_ref':'env:KEY'}))
    rs=tmp_path/'results.json'; rs.write_text(json.dumps({'query':'hvac market','results':[{'url':'https://agency.gov/report','title':'Official report','publisher':'Agency','publication_date':'2026-01-01','source_family':'government'}]}))
    import_search_results(ws,rs,pc); sid=json.loads((ws/'source_ledger.json').read_text())[0]['source_id']
    snap=tmp_path/'report.txt'; snap.write_text('Official analysis shows commercial HVAC replacement demand increased 12 percent in 2025 due to efficiency rules. Additional details follow.')
    import_content_snapshot(ws,source_id=sid,content_file=snap,content_type='text/plain',source_native_attested=True)
    return ws,sid

def test_accept_and_extract(tmp_path):
    ws,sid=setup_run(tmp_path)
    d=tmp_path/'d.json'; d.write_text(json.dumps({'source_id':sid,'decision':'accept','reviewer':'analyst@example.com','rationale':'Official primary publication with directly relevant market data.','source_tier':'tier_1_primary','source_type':'government_report','source_native_attestation':True}))
    assert review_source(ws,d)['eligible_for_evidence'] is True
    p=tmp_path/'p.json'; p.write_text(json.dumps({'evidence':[{'source_id':sid,'claim':'Commercial HVAC replacement demand increased in 2025.','quote':'Official analysis shows commercial HVAC replacement demand increased 12 percent in 2025 due to efficiency rules.','linked_table':'demand_drivers','linked_field':'replacement_growth_2025','evidence_type':'quantitative_fact','as_of_date':'2026-01-01','conflict_status':'none'}]}))
    out=extract_evidence(ws,p); assert out['accepted_evidence_count']==1
    row=json.loads((ws/'atomic_evidence.json').read_text())[0]; assert row['source_id']==sid and row['eligible'] is True

def test_reject_without_snapshot(tmp_path):
    ws=tmp_path/'run'; initialize_run(RunRequest(industry_name='Payments infrastructure'),ws)
    d=tmp_path/'d.json'; d.write_text(json.dumps({'source_id':'none','decision':'accept','reviewer':'x','rationale':'long enough rationale','source_tier':'tier_1_primary','source_type':'filing','source_native_attestation':True}))
    with pytest.raises(ValueError): review_source(ws,d)

def test_boilerplate_and_missing_quote_rejected(tmp_path):
    ws,sid=setup_run(tmp_path)
    d=tmp_path/'d.json'; d.write_text(json.dumps({'source_id':sid,'decision':'accept','reviewer':'a','rationale':'Relevant authoritative source accepted after snapshot review.','source_tier':'tier_2_authoritative','source_type':'report','source_native_attestation':True})); review_source(ws,d)
    p=tmp_path/'p.json'; p.write_text(json.dumps({'evidence':[{'source_id':sid,'claim':'A substantive claim that is sufficiently long.','quote':'Cookie policy and all rights reserved for this website.','linked_table':'demand_drivers','linked_field':'x_value','evidence_type':'direct_quote','conflict_status':'none'}]}))
    out=extract_evidence(ws,p); assert out['accepted_evidence_count']==0 and 'boilerplate_prohibited' in out['rejections'][0]['reasons']

def test_unaccepted_source_cannot_emit_evidence(tmp_path):
    ws,sid=setup_run(tmp_path)
    p=tmp_path/'p.json'; p.write_text(json.dumps({'evidence':[{'source_id':sid,'claim':'A substantive claim that is sufficiently long.','quote':'Official analysis shows commercial HVAC replacement demand increased 12 percent in 2025 due to efficiency rules.','linked_table':'demand_drivers','linked_field':'growth','evidence_type':'direct_quote','conflict_status':'none'}]}))
    out=extract_evidence(ws,p); assert out['accepted_evidence_count']==0
