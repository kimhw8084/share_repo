from __future__ import annotations

import json
from pathlib import Path

import pytest

from industry_intel_engine.discovery import import_search_results
from industry_intel_engine.evidence import extract_evidence, review_source
from industry_intel_engine.models import RunRequest
from industry_intel_engine.orchestrator import initialize_run
from industry_intel_engine.quality import record_stop_decision
from industry_intel_engine.snapshots import import_content_snapshot
from industry_intel_engine.source_quality import evaluate_authoritative_recall
from industry_intel_engine.specificity import validate_analytical_specificity
from industry_intel_engine.validation import validate_run
from test_stage5_simulation import _ready_workspace


def _write(path: Path, payload: object) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def _discovered(tmp_path: Path, *, url: str = "https://agency.gov/native-report") -> tuple[Path, str]:
    ws = tmp_path / "run"
    initialize_run(RunRequest("Solar panel industry"), ws)
    provider = _write(tmp_path / "provider.json", {"provider_id": "test", "terms_accepted": True, "credential_ref": "env:KEY"})
    results = _write(tmp_path / "results.json", {"query": "solar authoritative", "results": [{"url": url, "title": "Native report", "publisher": "Agency", "publication_date": "2026-07-01", "source_family": "official_statistics"}]})
    import_search_results(ws, results, provider)
    sid = json.loads((ws / "source_ledger.json").read_text())[0]["source_id"]
    return ws, sid


def test_provider_normalized_capture_cannot_be_accepted(tmp_path: Path):
    ws, sid = _discovered(tmp_path)
    content = tmp_path / "summary.txt"
    content.write_text("Provider-normalized authoritative evidence supports a solar capacity claim.", encoding="utf-8")
    out = import_content_snapshot(ws, source_id=sid, content_file=content, source_native_attested=True)
    assert out["source_native_capture_eligible"] is False
    decision = _write(tmp_path / "review.json", {"source_id": sid, "decision": "accept", "reviewer": "reviewer", "reviewer_role": "source_reviewer", "rationale": "This should fail because the capture is generated rather than source native.", "source_tier": "tier_1_primary", "source_type": "government_report", "source_native_attestation": True})
    with pytest.raises(ValueError, match="not source-native eligible"):
        review_source(ws, decision)


def test_source_native_span_and_semantic_support_are_persisted(tmp_path: Path):
    ws, sid = _discovered(tmp_path)
    quote = "The agency reported 45 gigawatts of solar capacity additions in 2026."
    content = tmp_path / "native.txt"; content.write_text("Header. " + quote + " End.", encoding="utf-8")
    import_content_snapshot(ws, source_id=sid, content_file=content, capture_type="source_native_text", acquisition_method="https_download", collector="test_collector", source_native_attested=True)
    review_source(ws, _write(tmp_path / "review.json", {"source_id": sid, "decision": "accept", "reviewer": "reviewer", "reviewer_role": "source_reviewer", "rationale": "Immutable source-native agency document with an exact attributable statement.", "source_tier": "tier_1_primary", "source_type": "government_report", "source_native_attestation": True}))
    out = extract_evidence(ws, _write(tmp_path / "evidence.json", {"evidence": [{"source_id": sid, "claim": "The agency reported 45 gigawatts of solar capacity additions in 2026.", "quote": quote, "linked_table": "demand_drivers", "linked_field": "capacity_additions_2026", "evidence_type": "quantitative_fact", "as_of_date": "2026-07-01", "conflict_status": "none"}]}))
    assert out["accepted_evidence_count"] == 1
    row = json.loads((ws / "atomic_evidence.json").read_text())[0]
    assert row["grounding_status"] == "source_native_span_verified"
    assert row["source_span"]["document_sha256"] == row["snapshot_sha256"]
    assert row["semantic_support"]["semantic_score"] > 0.9


def test_semantically_unsupported_claim_is_rejected(tmp_path: Path):
    ws, sid = _discovered(tmp_path)
    quote = "The report describes module efficiency testing and certification procedures."
    content = tmp_path / "native.txt"; content.write_text(quote, encoding="utf-8")
    import_content_snapshot(ws, source_id=sid, content_file=content, source_native_attested=True)
    review_source(ws, _write(tmp_path / "review.json", {"source_id": sid, "decision": "accept", "reviewer": "reviewer", "reviewer_role": "source_reviewer", "rationale": "Immutable source-native technical document with relevant procedures.", "source_tier": "tier_2_authoritative", "source_type": "technical_report", "source_native_attestation": True}))
    out = extract_evidence(ws, _write(tmp_path / "evidence.json", {"evidence": [{"source_id": sid, "claim": "First Solar revenue will increase 40 percent next year.", "quote": quote, "linked_table": "financial_sensitivity", "linked_field": "driver_name", "evidence_type": "company_disclosure", "as_of_date": "2026-07-01", "conflict_status": "none"}]}))
    assert out["accepted_evidence_count"] == 0
    assert "semantic_support_below_table_threshold" in out["rejections"][0]["reasons"]


def test_event_and_company_specificity_detects_reused_generic_evidence():
    evidence = [{"evidence_id": "ev_generic", "claim_text": "Generic solar demand may grow."}]
    tables = {
        "atomic_evidence": evidence,
        "company_universe": [{"company_id": "co_a", "company_name": "Alpha Solar"}, {"company_id": "co_b", "company_name": "Beta Solar"}],
        "security_master": [],
        "event_catalysts": [
            {"event_id": "e1", "event_name": "Trade duty decision", "event_date": "2026-10-01", "affected_companies": ["co_a"], "causal_chain": "Duty changes landed cost.", "evidence_ids": ["ev_generic"]},
            {"event_id": "e2", "event_name": "Factory ramp", "event_date": "2026-11-01", "affected_companies": ["co_b"], "causal_chain": "Ramp changes supply.", "evidence_ids": ["ev_generic"]},
        ],
        "financial_sensitivity": [
            {"financial_sensitivity_id": "f1", "company_id": "co_a", "driver_name": "revenue", "formula_or_logic": "Demand to revenue bridge", "evidence_ids": ["ev_generic"]},
        ],
        "risks_falsifiers": [],
    }
    audit = validate_analytical_specificity(tables)
    codes = {row["code"] for row in audit["failures"]}
    assert "event_evidence_overlap_excessive" in codes
    assert "company_specific_sensitivity_evidence_missing" in codes


def test_falsifier_requires_machine_readable_threshold():
    audit = validate_analytical_specificity({"atomic_evidence": [], "company_universe": [], "security_master": [], "event_catalysts": [], "financial_sensitivity": [], "risks_falsifiers": [{"risk_falsifier_id": "r1", "record_type": "falsifier", "name": "Demand break"}]})
    assert any(row["code"] == "falsifier_machine_threshold_missing" for row in audit["failures"])


def test_frozen_solar_recall_requires_at_least_85_percent(tmp_path: Path):
    ws, _ = _discovered(tmp_path)
    registry = Path(__file__).parents[1] / "registries" / "solar_authoritative_domains_v1.json"
    result = evaluate_authoritative_recall(ws, registry)
    assert result["passed"] is False
    assert result["recall_percent"] < 85


def test_stop_requires_freshness_geography_and_configured_recall(tmp_path: Path):
    ws, _ = _discovered(tmp_path)
    registry = Path(__file__).parents[1] / "registries" / "solar_authoritative_domains_v1.json"
    evaluate_authoritative_recall(ws, registry)
    plan = json.loads((ws / "source_plan.json").read_text())
    payload = {
        "decision": "stop_approved", "reviewer": "lead", "reviewer_role": "research_lead",
        "rationale": "All research families are covered and the final freshness sweep produced no material new evidence.",
        "marginal_yield": {"queries_reviewed": 5, "new_accepted_sources": 0, "new_evidence_rows": 0, "material_gaps_closed": 0, "new_source_families": 0},
        "mandatory_family_status": [{"source_family": row["source_family"], "mandatory": row["mandatory"], "status": "covered" if row["mandatory"] else "not_required"} for row in plan["items"]],
        "unresolved_material_gap_ids": [], "source_family_saturation_percent": 100,
        "freshness_sweep": {"completed": True, "queries_reviewed": 5, "latest_report_cutoff_date": "2026-07-28"},
        "geography_language_coverage": [{"geography": "China", "languages": ["zh", "en"], "material": True, "status": "covered"}],
    }
    with pytest.raises(ValueError, match="authoritative-recall"):
        record_stop_decision(ws, _write(tmp_path / "stop.json", payload))


def test_role_lens_report_reconciles_with_canonical_lens_table(tmp_path: Path):
    ws = _ready_workspace(tmp_path)
    from industry_intel_engine.simulation import prepare_simulation
    from industry_intel_engine.html_packet import generate_html_packet, verify_html_packet
    prepare_simulation(ws); generate_html_packet(ws); verify_html_packet(ws, browser="/missing", require_browser=False)
    audit = json.loads((ws / "html_packet_audit.json").read_text()); audit["browser_status"] = "passed"; audit["mode"] = "interactive_tested"; (ws / "html_packet_audit.json").write_text(json.dumps(audit), encoding="utf-8")
    report = validate_run(ws)
    canonical = json.loads((ws / "tables" / "professional_lenses.json").read_text())
    expected = round(sum(row["quality_score"] for row in canonical) / len(canonical), 2)
    assert report["role_lens_scores"]["average_quality_score"] == expected
    assert all(item["status"] != "legacy_derived" for item in report["role_lens_scores"]["roles"].values())
