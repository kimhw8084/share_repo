from __future__ import annotations
import json
from pathlib import Path
from industry_intel_engine.dataset import populate_dataset
from industry_intel_engine.discovery import import_search_results
from industry_intel_engine.snapshots import import_content_snapshot
from industry_intel_engine.evidence import review_source, extract_evidence
from test_stage4_dataset import _accepted_run, _fields_for_payload, _full_stage4_payload, _write


def test_incremental_repair_preserves_canonical_source_and_evidence_rows(tmp_path: Path):
    ws, ev = _accepted_run(tmp_path, _fields_for_payload())
    populate_dataset(ws, _write(tmp_path / 'initial_records.json', _full_stage4_payload(ev)))
    before_sources = len(json.loads((ws / 'source_ledger.json').read_text()))
    before_evidence = len(json.loads((ws / 'atomic_evidence.json').read_text()))
    provider = _write(tmp_path / 'provider.json', {'provider_id':'repair-test','terms_accepted':True,'credential_ref':'env:TEST'})
    results = _write(tmp_path / 'results.json', {'query':'repair source','source_family':'official_statistics','executed_at':'2026-07-27T00:00:00Z','results':[{'url':'https://agency.example.gov/report','title':'Repair report','publisher':'Agency','publication_date':'2026-07-01','source_family':'official_statistics','provider_result_id':'repair-source','snippet':'Repair demand increased.','metadata':{'industry_relevance':'high'}}]})
    import_search_results(ws, results, provider)
    ledger = json.loads((ws / 'source_ledger.json').read_text())
    raw = next(row for row in ledger if row.get('provider_result_id') == 'repair-source')
    snap = tmp_path / 'snapshot.txt'; snap.write_text('Repair demand increased.', encoding='utf-8')
    import_content_snapshot(ws, source_id=raw['source_id'], content_file=snap, final_url=raw['canonical_url'], fetched_at='2026-07-27T00:01:00Z', content_type='text/plain', source_native_attested=True)
    review_source(ws, _write(tmp_path / 'review.json', {'source_id':raw['source_id'],'decision':'accept','reviewer':'tester','rationale':'authoritative repair source','source_tier':'tier_1_primary','source_type':'government_report','source_native_attestation':True,'reviewed_at':'2026-07-27T00:02:00Z'}))
    extract_evidence(ws, _write(tmp_path / 'evidence.json', {'evidence':[{'source_id':raw['source_id'],'claim':'Repair demand driver.','quote':'Repair demand increased.','linked_table':'demand_drivers','linked_field':'driver_name','evidence_type':'quantitative_fact','as_of_date':'2026-07-01','conflict_status':'none'}]}))
    rows=json.loads((ws / 'atomic_evidence.json').read_text())
    new_ev=next(row['evidence_id'] for row in rows if row.get('eligible') is True and row.get('source_id')==raw['source_id'])
    payload={'analyst':'repair-test','records':[{'table':'demand_drivers','record':{'demand_driver_id':'demand_repair','industry_id':json.loads((ws/'tables/industry_boundary.json').read_text())[0]['industry_id'],'driver_name':'Repair demand','driver_type':'structural','description':'Repair demand increased.','direction':'positive','time_horizon':'1-3y','confidence_level':'high'},'field_lineage':{'driver_name':[new_ev],'driver_type':[new_ev],'description':[new_ev],'direction':[new_ev],'time_horizon':[new_ev],'confidence_level':[new_ev]}}]}
    # Add evidence mappings for all required fields by reusing the exact source quote with unique table/field keys.
    extra=[]
    for field in ['driver_type','description','direction','time_horizon','confidence_level']:
        extra.append({'source_id':raw['source_id'],'claim':'Repair demand increased.','quote':'Repair demand increased.','linked_table':'demand_drivers','linked_field':field,'evidence_type':'direct_quote','as_of_date':'2026-07-01','conflict_status':'none'})
    extract_evidence(ws, _write(tmp_path / 'extra_evidence.json', {'evidence':extra}))
    rows=json.loads((ws / 'atomic_evidence.json').read_text())
    for field in ['driver_type','description','direction','time_horizon','confidence_level']:
        payload['records'][0]['field_lineage'][field]=[next(row['evidence_id'] for row in rows if row.get('source_id')==raw['source_id'] and row.get('linked_field')==field)]
    populate_dataset(ws, _write(tmp_path / 'repair_records.json', payload))
    assert len(json.loads((ws / 'source_ledger.json').read_text())) == before_sources + 1
    assert len(json.loads((ws / 'atomic_evidence.json').read_text())) == before_evidence + 6
