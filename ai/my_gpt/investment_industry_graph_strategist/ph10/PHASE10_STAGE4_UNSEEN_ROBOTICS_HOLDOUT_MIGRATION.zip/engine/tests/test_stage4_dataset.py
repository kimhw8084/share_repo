from __future__ import annotations

import json
from pathlib import Path

import pytest

from industry_intel_engine.dataset import populate_dataset
from industry_intel_engine.discovery import import_search_results
from industry_intel_engine.evidence import extract_evidence, review_source
from industry_intel_engine.models import RunRequest
from industry_intel_engine.orchestrator import initialize_run
from industry_intel_engine.snapshots import import_content_snapshot


def _write(path: Path, payload: object) -> Path:
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def _accepted_run(tmp_path: Path, evidence_fields: list[tuple[str, str]]) -> tuple[Path, dict[tuple[str, str], str]]:
    ws = tmp_path / "run"
    initialize_run(RunRequest(industry_name="Commercial HVAC equipment and services"), ws)
    provider = _write(tmp_path / "provider.json", {"provider_id": "test", "terms_accepted": True, "credential_ref": "env:KEY"})
    results = _write(tmp_path / "results.json", {
        "query": "commercial HVAC authoritative economics",
        "source_family": "government",
        "results": [{
            "url": "https://agency.gov/hvac-economics",
            "title": "Commercial HVAC Economics",
            "publisher": "Energy Agency",
            "publication_date": "2026-01-01",
            "metadata": {"industry_relevance": "high", "geographic_scope": "Global"},
        }],
    })
    import_search_results(ws, results, provider)
    sid = json.loads((ws / "source_ledger.json").read_text())[0]["source_id"]
    quotes = {
        key: (
            f"Alpha HVAC company-specific disclosure for financial sensitivity field {key[1]} confirms the revenue driver and sensitivity mechanism."
            if key[0] == "financial_sensitivity"
            else f"Authoritative evidence for {key[0]} field {key[1]} confirms a specific economic fact for this industry."
        )
        for key in evidence_fields
    }
    snapshot = tmp_path / "source.txt"
    snapshot.write_text("\n".join(quotes.values()), encoding="utf-8")
    import_content_snapshot(ws, source_id=sid, content_file=snapshot, content_type="text/plain", source_native_attested=True)
    decision = _write(tmp_path / "decision.json", {
        "source_id": sid,
        "decision": "accept",
        "reviewer": "analyst@example.com",
        "rationale": "Authoritative primary source with direct industry economics and company mapping evidence.",
        "source_tier": "tier_1_primary",
        "source_type": "government_report",
        "source_native_attestation": True,
    })
    review_source(ws, decision)
    proposals = []
    for (table, field), quote in quotes.items():
        proposals.append({
            "source_id": sid,
            "claim": quote,
            "quote": quote,
            "linked_table": table,
            "linked_field": field,
            "evidence_type": "direct_quote",
            "as_of_date": "2026-01-01",
            "conflict_status": "none",
        })
    proposal_file = _write(tmp_path / "evidence.json", {"evidence": proposals})
    out = extract_evidence(ws, proposal_file)
    assert out["accepted_evidence_count"] == len(evidence_fields)
    rows = json.loads((ws / "atomic_evidence.json").read_text())
    evidence_map = {(row["linked_table"], row["linked_field"]): row["evidence_id"] for row in rows}
    return ws, evidence_map


def _lineage(ev: dict[tuple[str, str], str], table: str, fields: list[str]) -> dict[str, list[str]]:
    return {field: [ev[(table, field)]] for field in fields}


def _full_stage4_payload(ev: dict[tuple[str, str], str]) -> dict:
    industry_id = "ind_a6c2586819d4"  # overwritten/validated by the engine where required
    return {
        "analyst": "dataset.analyst@example.com",
        "replace_tables": ["industry_boundary"],
        "records": [
            {
                "table": "industry_boundary",
                "record": {
                    "industry_id": industry_id,
                    "industry_name_input": "Commercial HVAC equipment and services",
                    "resolved_industry_name": "Commercial HVAC Equipment and Services",
                    "definition": "Equipment, controls, distribution, installation, maintenance, and replacement services for commercial HVAC systems.",
                    "included_scope": ["equipment", "controls", "distribution", "service"],
                    "excluded_scope": ["residential-only systems"],
                    "geographic_scope": "Global",
                    "time_horizon": "1m-1y",
                    "investability_scope": "public_and_private",
                    "boundary_confidence": "high",
                },
                "field_lineage": _lineage(ev, "industry_boundary", ["resolved_industry_name", "definition", "included_scope", "excluded_scope", "boundary_confidence"]),
            },
            {
                "table": "industry_segments",
                "record": {
                    "segment_id": "seg_equipment",
                    "segment_name": "Commercial equipment",
                    "segment_dimension": "product",
                    "definition": "Packaged and applied commercial HVAC equipment.",
                },
                "field_lineage": _lineage(ev, "industry_segments", ["segment_name", "segment_dimension", "definition"]),
            },
            {
                "table": "value_chain_nodes",
                "record": {
                    "node_id": "node_oem",
                    "node_name": "Equipment OEMs",
                    "node_type": "manufacturer",
                    "node_description": "Design and manufacture commercial HVAC equipment.",
                    "economic_role": "Capture equipment revenue and aftermarket pull-through.",
                    "segment_ids": ["seg_equipment"],
                },
                "field_lineage": _lineage(ev, "value_chain_nodes", ["node_name", "node_type", "node_description", "economic_role"]),
            },
            {
                "table": "value_chain_nodes",
                "record": {
                    "node_id": "node_customer",
                    "node_name": "Commercial building owners",
                    "node_type": "customer",
                    "node_description": "Purchase equipment and recurring service for commercial buildings.",
                    "economic_role": "Fund capital replacement and service spending.",
                    "segment_ids": ["seg_equipment"],
                },
                "field_lineage": _lineage(ev, "value_chain_nodes", ["node_name", "node_type", "node_description", "economic_role"]),
            },
            {
                "table": "value_chain_edges",
                "record": {
                    "edge_id": "edge_oem_customer",
                    "from_node_id": "node_oem",
                    "to_node_id": "node_customer",
                    "flow_type": "physical",
                    "flow_description": "Equipment and service capabilities flow to building owners.",
                    "directionality": "one_way",
                    "materiality": "critical",
                },
                "field_lineage": _lineage(ev, "value_chain_edges", ["flow_type", "flow_description", "directionality", "materiality"]),
            },
            {
                "table": "money_flows",
                "record": {
                    "money_flow_id": "mflow_customer_oem",
                    "payer_node_id": "node_customer",
                    "receiver_node_id": "node_oem",
                    "payment_for": "Commercial HVAC equipment and associated service.",
                },
                "field_lineage": _lineage(ev, "money_flows", ["payment_for"]),
            },
            {
                "table": "company_universe",
                "record": {
                    "company_id": "co_alpha",
                    "company_name": "Alpha HVAC",
                    "ownership_type": "public",
                    "business_description": "Commercial HVAC equipment and services provider.",
                    "value_chain_node_ids": ["node_oem"],
                    "segment_ids": ["seg_equipment"],
                    "industry_relevance": "high",
                },
                "field_lineage": _lineage(ev, "company_universe", ["company_name", "ownership_type", "business_description", "industry_relevance"]),
            },
            {
                "table": "security_master",
                "record": {"security_id": "sec_alpha", "company_id": "co_alpha", "ticker": "AHVC", "exchange": "NYSE", "security_type": "equity"},
                "field_lineage": _lineage(ev, "security_master", ["security_type"]),
            },
            {
                "table": "company_segment_exposure",
                "record": {
                    "exposure_id": "exp_alpha",
                    "company_id": "co_alpha",
                    "security_id": "sec_alpha",
                    "segment_id": "seg_equipment",
                    "node_id": "node_oem",
                    "exposure_type": "direct",
                    "exposure_direction": "benefits",
                    "exposure_magnitude": "high",
                    "confidence_level": "high",
                },
                "field_lineage": _lineage(ev, "company_segment_exposure", ["exposure_type", "exposure_direction", "exposure_magnitude", "confidence_level"]),
            },
            {
                "table": "risks_falsifiers",
                "record": {
                    "risk_falsifier_id": "risk_demand",
                    "record_type": "falsifier",
                    "name": "Replacement demand stalls",
                    "risk_type": "demand",
                    "description": "A sustained decline in replacement orders would invalidate the growth thesis.",
                    "impact_magnitude": "high",
                },
                "field_lineage": _lineage(ev, "risks_falsifiers", ["record_type", "name", "risk_type", "description", "impact_magnitude"]),
            },
        ],
    }


def _fields_for_payload() -> list[tuple[str, str]]:
    return [
        ("industry_boundary", field) for field in ["resolved_industry_name", "definition", "included_scope", "excluded_scope", "boundary_confidence"]
    ] + [
        ("industry_segments", field) for field in ["segment_name", "segment_dimension", "definition"]
    ] + [
        ("value_chain_nodes", field) for field in ["node_name", "node_type", "node_description", "economic_role"]
    ] + [
        ("value_chain_edges", field) for field in ["flow_type", "flow_description", "directionality", "materiality"]
    ] + [
        ("money_flows", "payment_for"),
    ] + [
        ("company_universe", field) for field in ["company_name", "ownership_type", "business_description", "industry_relevance"]
    ] + [
        ("security_master", "security_type"),
    ] + [
        ("company_segment_exposure", field) for field in ["exposure_type", "exposure_direction", "exposure_magnitude", "confidence_level"]
    ] + [
        ("risks_falsifiers", field) for field in ["record_type", "name", "risk_type", "description", "impact_magnitude"]
    ]


def test_populates_canonical_dataset_and_lenses(tmp_path: Path):
    ws, ev = _accepted_run(tmp_path, _fields_for_payload())
    proposal = _write(tmp_path / "records.json", _full_stage4_payload(ev))
    out = populate_dataset(ws, proposal)
    assert out["accepted_record_count"] == 10
    assert out["populated_required_table_count"] >= 11
    assert out["professional_lens_count"] == 5
    dataset = json.loads((ws / "industry_dataset.json").read_text())
    assert dataset["production_claim"] is False
    assert dataset["tables"]["money_flows"][0]["payer_node_id"] == "node_customer"
    assert dataset["tables"]["company_universe"][0]["value_chain_node_ids"] == ["node_oem"]
    assert len(json.loads((ws / "field_lineage.json").read_text())) > 0
    assert len(json.loads((ws / "tables" / "professional_lenses.json").read_text())) == 5
    assert dataset["gap_summary"]["open"] > 0
    boundary_status = next(x for x in dataset["completeness"]["tables"] if x["table"] == "industry_boundary")
    assert boundary_status["status"] == "minimum_complete"


def test_missing_lineage_is_rejected(tmp_path: Path):
    ws, ev = _accepted_run(tmp_path, [("value_chain_nodes", "node_name")])
    payload = {"analyst": "a@example.com", "records": [{
        "table": "value_chain_nodes",
        "record": {"node_id": "n1", "node_name": "OEM", "node_type": "manufacturer", "node_description": "Makes equipment.", "economic_role": "Captures sales."},
        "field_lineage": {"node_name": [ev[("value_chain_nodes", "node_name")]]},
    }]}
    with pytest.raises(ValueError, match="lacks field-level lineage"):
        populate_dataset(ws, _write(tmp_path / "records.json", payload))


def test_mismatched_evidence_field_is_rejected(tmp_path: Path):
    ws, ev = _accepted_run(tmp_path, [("value_chain_nodes", "node_name")])
    eid = ev[("value_chain_nodes", "node_name")]
    payload = {"analyst": "a@example.com", "records": [{
        "table": "industry_segments",
        "record": {"segment_id": "s1", "segment_name": "Equipment", "segment_dimension": "product", "definition": "Equipment segment."},
        "field_lineage": {"segment_name": [eid], "segment_dimension": [eid], "definition": [eid]},
    }]}
    with pytest.raises(ValueError, match="supports value_chain_nodes"):
        populate_dataset(ws, _write(tmp_path / "records.json", payload))


def test_broken_foreign_key_is_rejected(tmp_path: Path):
    fields = [("value_chain_nodes", field) for field in ["node_name", "node_type", "node_description", "economic_role"]]
    ws, ev = _accepted_run(tmp_path, fields)
    payload = {"analyst": "a@example.com", "records": [{
        "table": "value_chain_nodes",
        "record": {"node_id": "n1", "node_name": "OEM", "node_type": "manufacturer", "node_description": "Makes equipment.", "economic_role": "Captures sales.", "segment_ids": ["missing_segment"]},
        "field_lineage": _lineage(ev, "value_chain_nodes", ["node_name", "node_type", "node_description", "economic_role"]),
    }]}
    with pytest.raises(ValueError, match="unresolved references"):
        populate_dataset(ws, _write(tmp_path / "records.json", payload))


def test_duplicate_record_id_is_rejected(tmp_path: Path):
    fields = [("value_chain_nodes", field) for field in ["node_name", "node_type", "node_description", "economic_role"]]
    ws, ev = _accepted_run(tmp_path, fields)
    record = {"node_id": "n1", "node_name": "OEM", "node_type": "manufacturer", "node_description": "Makes equipment.", "economic_role": "Captures sales."}
    proposal = {"table": "value_chain_nodes", "record": record, "field_lineage": _lineage(ev, "value_chain_nodes", ["node_name", "node_type", "node_description", "economic_role"])}
    with pytest.raises(ValueError, match="duplicate record ID"):
        populate_dataset(ws, _write(tmp_path / "records.json", {"analyst": "a@example.com", "records": [proposal, proposal]}))


def test_pre_research_boundary_remains_visible_as_lineage_gap(tmp_path: Path):
    fields = [("value_chain_nodes", field) for field in ["node_name", "node_type", "node_description", "economic_role"]]
    ws, ev = _accepted_run(tmp_path, fields)
    payload = {"analyst": "a@example.com", "records": [{
        "table": "value_chain_nodes",
        "record": {"node_id": "n1", "node_name": "OEM", "node_type": "manufacturer", "node_description": "Makes equipment.", "economic_role": "Captures sales."},
        "field_lineage": _lineage(ev, "value_chain_nodes", ["node_name", "node_type", "node_description", "economic_role"]),
    }]}
    populate_dataset(ws, _write(tmp_path / "records.json", payload))
    gaps = json.loads((ws / "gap_register.json").read_text())
    assert any(gap.get("missing_table") == "industry_boundary" and "lineage" in gap["gap_name"].lower() for gap in gaps)


def test_requires_real_accepted_evidence(tmp_path: Path):
    ws = tmp_path / "run"
    initialize_run(RunRequest(industry_name="Payments infrastructure"), ws)
    with pytest.raises(ValueError, match="accepted source and eligible evidence"):
        populate_dataset(ws, _write(tmp_path / "records.json", {"analyst": "a@example.com", "records": []}))


def test_active_population_lock_blocks_execution(tmp_path: Path):
    ws, _ = _accepted_run(tmp_path, [("value_chain_nodes", "node_name")])
    (ws / ".dataset_population.lock").write_text("active", encoding="utf-8")
    with pytest.raises(ValueError, match="transaction is active"):
        populate_dataset(ws, _write(tmp_path / "records.json", {"analyst": "a@example.com", "records": []}))


def test_failed_transaction_is_journaled_and_lock_removed(tmp_path: Path):
    ws, _ = _accepted_run(tmp_path, [("value_chain_nodes", "node_name")])
    with pytest.raises(ValueError):
        populate_dataset(ws, _write(tmp_path / "bad.json", {"analyst": "a@example.com", "records": [{"table": "bad", "record": {}, "field_lineage": {}}]}))
    journal = json.loads((ws / "dataset_population_journal.json").read_text())
    assert journal["status"] == "failed"
    assert not (ws / ".dataset_population.lock").exists()
