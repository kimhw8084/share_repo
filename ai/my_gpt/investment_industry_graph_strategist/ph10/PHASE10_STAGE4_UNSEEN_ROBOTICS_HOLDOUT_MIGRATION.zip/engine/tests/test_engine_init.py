from __future__ import annotations

import json
from pathlib import Path

import pytest

from industry_intel_engine.archetypes import classify_archetype
from industry_intel_engine.artifact_graph import REQUIRED_HTML_TABS
from industry_intel_engine.errors import ProviderUnavailable
from industry_intel_engine.models import RunRequest
from industry_intel_engine.orchestrator import initialize_run
from industry_intel_engine.providers import NullSearchProvider
from industry_intel_engine.source_plan import build_source_plan
from industry_intel_engine.boundary import resolve_boundary


def test_blank_industry_rejected(tmp_path: Path):
    with pytest.raises(ValueError):
        initialize_run(RunRequest(industry_name="   "), tmp_path / "run")


def test_payments_archetype():
    result = classify_archetype("Payments infrastructure")
    assert result.primary_archetype == "financial_network"
    assert result.regulated is True
    assert result.live_quant_stress_expected is True


def test_source_plan_has_mandatory_negative_search():
    boundary = resolve_boundary(RunRequest(industry_name="Commercial HVAC equipment and services"))
    plan = build_source_plan(boundary, classify_archetype(boundary.resolved_industry_name))
    negative = next(item for item in plan if item.source_family == "negative_risk")
    assert negative.mandatory is True
    assert any("bear case" in q or "risks" in q for q in negative.query_templates)


def test_init_creates_durable_blocked_run_without_fake_counts(tmp_path: Path):
    root = tmp_path / "run"
    state = initialize_run(RunRequest(industry_name="Data center power and thermal infrastructure"), root, run_id="run_test")
    assert state["status"] == "blocked_source_collection"
    assert json.loads((root / "source_ledger.json").read_text()) == []
    assert json.loads((root / "atomic_evidence.json").read_text()) == []
    progress = json.loads((root / "progress_ledger.json").read_text())
    assert progress["source_count"] == 0
    assert progress["eligible_evidence_count"] == 0
    assert progress["progress_percent"] == 8
    assert (root / "source_plan.json").exists()
    assert (root / "artifact_graph.json").exists()


def test_resume_is_idempotent(tmp_path: Path):
    root = tmp_path / "run"
    first = initialize_run(RunRequest(industry_name="Battery materials and recycling"), root, run_id="run_fixed")
    second = initialize_run(RunRequest(industry_name="Battery materials and recycling"), root, run_id="other")
    assert first == second
    assert second["run_id"] == "run_fixed"


def test_workspace_reuse_with_different_request_blocked(tmp_path: Path):
    root = tmp_path / "run"
    initialize_run(RunRequest(industry_name="Payments infrastructure"), root)
    with pytest.raises(ValueError, match="different run request"):
        initialize_run(RunRequest(industry_name="Commercial HVAC"), root)


def test_symlink_workspace_rejected(tmp_path: Path):
    target = tmp_path / "target"
    target.mkdir()
    link = tmp_path / "link"
    try:
        link.symlink_to(target, target_is_directory=True)
    except OSError:
        pytest.skip("symlink unsupported")
    with pytest.raises(Exception, match="symlink"):
        initialize_run(RunRequest(industry_name="Payments"), link)


def test_null_provider_fails_closed():
    with pytest.raises(ProviderUnavailable):
        NullSearchProvider().search("test")


def test_exact_nineteen_html_tabs():
    assert len(REQUIRED_HTML_TABS) == 19
    assert REQUIRED_HTML_TABS[0] == "Executive Investment View"
    assert REQUIRED_HTML_TABS[-1] == "Quality, Validation, and Gaps"


def test_boundary_is_explicitly_pre_research():
    boundary = resolve_boundary(RunRequest(industry_name="Vertical SaaS for healthcare revenue cycle management"))
    assert boundary.boundary_confidence == "low"
    assert boundary.source_ids == []
    assert boundary.gap_ids
    assert any("pre-research" in item.lower() for item in boundary.assumptions)
