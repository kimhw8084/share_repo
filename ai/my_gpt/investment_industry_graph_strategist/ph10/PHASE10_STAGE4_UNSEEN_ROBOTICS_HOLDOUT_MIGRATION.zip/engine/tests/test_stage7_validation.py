from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from industry_intel_engine.html_packet import generate_html_packet, verify_html_packet
from industry_intel_engine.simulation import prepare_simulation
from industry_intel_engine.validation import finalize_run, validate_run
from test_stage5_simulation import _ready_workspace


def _validated_workspace(tmp_path: Path) -> Path:
    ws = _ready_workspace(tmp_path)
    prepare_simulation(ws)
    generate_html_packet(ws)
    browser = shutil.which("chromium") or shutil.which("google-chrome")
    if browser:
        verify_html_packet(ws, browser=browser)
    else:
        verify_html_packet(ws, browser="/missing", require_browser=False)
        audit = json.loads((ws / "html_packet_audit.json").read_text())
        audit["browser_status"] = "passed"
        audit["mode"] = "interactive_tested"
        (ws / "html_packet_audit.json").write_text(json.dumps(audit), encoding="utf-8")
    return ws


def test_validation_report_is_decomposed_and_fixture_capped(tmp_path: Path):
    ws = _validated_workspace(tmp_path)
    (ws / "FIXTURE_ONLY.md").write_text("fixture-only", encoding="utf-8")
    report = validate_run(ws)
    assert len(report["score_components"]) == 9
    assert sum(row["weight"] for row in report["score_components"]) == 100
    assert report["fixture_only"] is True
    assert report["overall_score"] <= 54
    assert "fixture_only_not_real_provider" in report["failure_fingerprints"]
    assert report["production_claim"] is False


def test_count_truth_mismatch_hard_fails(tmp_path: Path):
    ws = _validated_workspace(tmp_path)
    state = json.loads((ws / "run_state.json").read_text())
    state["source_count"] = 999
    (ws / "run_state.json").write_text(json.dumps(state), encoding="utf-8")
    report = validate_run(ws)
    assert report["hard_fail_status"] == "hard_fail"
    assert "source_count_truth_mismatch" in report["failure_fingerprints"]
    assert report["overall_score"] <= 19


def test_finalize_writes_reports_and_manifest(tmp_path: Path):
    browser = shutil.which("chromium") or shutil.which("google-chrome")
    if not browser:
        pytest.skip("Chromium is required for final Stage 7 interactive acceptance")
    ws = _ready_workspace(tmp_path)
    prepare_simulation(ws)
    generate_html_packet(ws)
    verify_html_packet(ws, browser=browser)
    out = finalize_run(ws, browser=browser, artifact_state="diagnostic")
    assert out["manifest_file_count"] > 40
    report = json.loads((ws / "validation_report.json").read_text())
    manifest = json.loads((ws / "manifest.json").read_text())
    assert report["overall_score"] == out["overall_score"]
    assert manifest["score"] == report["overall_score"]
    assert manifest["artifact_state"] == "diagnostic"
    assert "validation_report.json" in manifest["checksums"]
    assert "manifest.json" not in manifest["checksums"]
    packet = json.loads((ws / "packet_data.json").read_text())
    assert packet["header"]["overall_score"] == report["overall_score"]
    progress = json.loads((ws / "progress_ledger.json").read_text())
    assert progress["progress_percent"] == 100
    assert progress["blocked_steps"] == []
    summary = (ws / "final_summary.md").read_text()
    assert "generated and browser verified" in summary
    assert f"{report['overall_score']} / 100" in summary


def test_missing_simulation_applies_cap(tmp_path: Path):
    ws = _validated_workspace(tmp_path)
    readiness = json.loads((ws / "simulation_readiness.json").read_text())
    readiness["simulation_maturity_level"] = 0
    readiness["status"] = "disabled_insufficient_inputs"
    (ws / "simulation_readiness.json").write_text(json.dumps(readiness), encoding="utf-8")
    report = validate_run(ws)
    assert 79 in report["active_score_caps"]
    assert report["overall_score"] <= 54  # fixture cap remains more restrictive
