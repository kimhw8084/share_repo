from __future__ import annotations

import csv
import json
from pathlib import Path

import pytest

from industry_intel_engine.artifact_graph import REQUIRED_HTML_TABS
from industry_intel_engine.html_packet import generate_html_packet, verify_html_packet
from industry_intel_engine.simulation import prepare_simulation
from test_stage4_dataset import _accepted_run, _fields_for_payload, _full_stage4_payload, _write
from test_stage5_simulation import _ready_workspace
from industry_intel_engine.dataset import populate_dataset


def test_generates_exact_19_tab_packet_and_synchronized_exports(tmp_path: Path):
    ws = _ready_workspace(tmp_path)
    prepare_simulation(ws)
    result = generate_html_packet(ws)
    assert result["status"] == "generated_pending_browser_verification"
    assert result["tab_count"] == 19
    html = (ws / "index.html").read_text(encoding="utf-8")
    assert html.count('class="tab-link"') == 19
    for tab in REQUIRED_HTML_TABS:
        assert f'data-tab-name="{tab}"' in html
    packet = json.loads((ws / "packet_data.json").read_text())
    assert packet["required_tabs"] == REQUIRED_HTML_TABS
    assert packet["header"]["overall_score"] is None
    assert packet["header"]["production_claim"] is False
    assert packet["warnings"]["not_investment_grade"] is True
    assert len(packet["exports"]) >= 40
    source_export = next(row for row in packet["exports"] if row["name"] == "source_ledger")
    with (ws / source_export["csv_path"]).open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == len(packet["tables"]["source_ledger"])


def test_static_verification_marks_interactive_without_browser_when_explicitly_allowed(tmp_path: Path):
    ws = _ready_workspace(tmp_path)
    prepare_simulation(ws)
    generate_html_packet(ws)
    result = verify_html_packet(ws, browser="/definitely/missing/chromium", require_browser=False)
    assert result["status"] == "static_verified_browser_pending"
    assert result["browser_check_count"] == 0
    audit = json.loads((ws / "html_packet_audit.json").read_text())
    assert audit["mode"] == "interactive_pending_browser_test"
    assert all(row["passed"] for row in audit["static_checks"])


def test_disabled_simulation_renders_explicit_disabled_state(tmp_path: Path):
    ws, ev = _accepted_run(tmp_path, _fields_for_payload())
    populate_dataset(ws, _write(tmp_path / "records.json", _full_stage4_payload(ev)))
    prepare_simulation(ws)
    result = generate_html_packet(ws)
    assert result["simulation_status"] == "disabled_insufficient_inputs"
    html = (ws / "index.html").read_text(encoding="utf-8")
    assert "Scenario controls disabled" in html
    packet = json.loads((ws / "packet_data.json").read_text())
    assert packet["simulation_readiness"]["simulation_maturity_level"] == 0
    assert packet["simulation"]["valuation_outputs"] == []


def test_fails_closed_on_canonical_dataset_export_drift(tmp_path: Path):
    ws = _ready_workspace(tmp_path)
    prepare_simulation(ws)
    rows = json.loads((ws / "tables" / "company_universe.json").read_text())
    rows[0]["company_name"] = "Tampered Company"
    (ws / "tables" / "company_universe.json").write_text(json.dumps(rows), encoding="utf-8")
    with pytest.raises(ValueError, match="synchronized canonical table drift"):
        generate_html_packet(ws)


def test_claim_inventory_has_no_unresolved_material_fact_claims(tmp_path: Path):
    ws = _ready_workspace(tmp_path)
    prepare_simulation(ws)
    generate_html_packet(ws)
    packet = json.loads((ws / "packet_data.json").read_text())
    unresolved = [
        claim for claim in packet["claims"]
        if claim["claim_kind"] == "fact_or_interpretation"
        and not claim["evidence_ids"] and not claim["source_ids"]
    ]
    assert unresolved == []
    assert any(claim["claim_kind"] == "derived_output" and claim["formula_ids"] for claim in packet["claims"])
    assert any(claim["claim_kind"] == "gap" for claim in packet["claims"])


def test_rejects_symlinked_index_target(tmp_path: Path):
    ws = _ready_workspace(tmp_path)
    prepare_simulation(ws)
    target = tmp_path / "outside.html"
    target.write_text("outside", encoding="utf-8")
    (ws / "index.html").symlink_to(target)
    with pytest.raises(ValueError, match="index.html must not be a symlink"):
        generate_html_packet(ws)
