from __future__ import annotations

import json
from pathlib import Path

import pytest

from industry_intel_engine.dataset import populate_dataset
from industry_intel_engine.simulation import CANONICAL_SCENARIOS, prepare_simulation
from test_stage4_dataset import _accepted_run, _fields_for_payload, _full_stage4_payload, _lineage, _write


def _stage5_fields() -> list[tuple[str, str]]:
    fields = list(_fields_for_payload())
    fields += [("formula_registry", field) for field in ["formula_name", "formula_expression", "output_field", "input_fields", "status"]]
    fields += [("scenario_assumptions", field) for field in ["assumption_name", "variable_name", "variable_value", "assumption_owner", "confidence_level"]]
    fields += [("financial_sensitivity", field) for field in ["driver_name", "driver_type", "sensitivity_direction", "confidence_level"]]
    fields += [("opportunity_zones", field) for field in [
        "opportunity_name", "opportunity_type", "investment_implication", "upside_logic", "downside_logic",
        "time_horizon", "evidence_strength", "confidence_level",
    ]]
    return fields


def _stage5_payload(ev: dict[tuple[str, str], str]) -> dict:
    payload = _full_stage4_payload(ev)
    risk = next(item for item in payload["records"] if item["table"] == "risks_falsifiers")
    risk["record"].update({
        "affected_nodes": ["node_oem"],
        "affected_companies": ["co_alpha"],
        "affected_opportunities": ["opp_oem"],
        "measurable_threshold": "Replacement demand growth at or below -20%.",
        "monitor_variable": "replacement_demand_growth",
        "threshold_operator": "lte",
        "threshold_value": -0.20,
    })
    payload["records"].append({
        "table": "formula_registry",
        "record": {
            "formula_id": "formula_node_impact",
            "formula_name": "Demand growth to node impact",
            "formula_expression": "(variable_value - baseline_value) * sensitivity_coefficient",
            "output_field": "node_impact_score",
            "input_fields": ["variable_value", "baseline_value", "sensitivity_coefficient"],
            "input_units": {"variable_value": "ratio", "baseline_value": "ratio", "sensitivity_coefficient": "unitless"},
            "output_unit": "score",
            "scenario_scope": list(CANONICAL_SCENARIOS),
            "version": "1.0.0",
            "limitations": "Fixture-only linear directional formula; no valuation or probability output.",
            "status": "active",
        },
        "field_lineage": _lineage(ev, "formula_registry", ["formula_name", "formula_expression", "output_field", "input_fields", "status"]),
    })
    values = {"base": 0.02, "bull": 0.15, "bear": -0.10, "shock": -0.30, "structural_transition": 0.25}
    for scenario, value in values.items():
        payload["records"].append({
            "table": "scenario_assumptions",
            "record": {
                "assumption_id": f"assumption_{scenario}",
                "scenario_id": f"scenario_{scenario}",
                "scenario_name": scenario.replace("_", " ").title(),
                "scenario_type": scenario,
                "assumption_name": f"{scenario} replacement demand",
                "variable_name": "replacement_demand_growth",
                "variable_value": value,
                "baseline_value": 0.0,
                "unit": "ratio",
                "range_low": -0.40,
                "range_high": 0.40,
                "allowed_min": -0.50,
                "allowed_max": 0.50,
                "sensitivity_coefficient": 1.0,
                "sensitivity_unit": "unitless",
                "assumption_owner": "source_backed",
                "affected_nodes": ["node_oem"],
                "affected_companies": ["co_alpha"],
                "formula_id": "formula_node_impact",
                "confidence_level": "high",
                "period": "3-12m" if scenario != "structural_transition" else "1-3y",
                "rationale": "Fixture-only evidence-backed scenario input.",
                "limitations": "Linear directional fixture; not a forecast.",
            },
            "field_lineage": _lineage(ev, "scenario_assumptions", ["assumption_name", "variable_name", "variable_value", "assumption_owner", "confidence_level"]),
        })
    payload["records"].append({
        "table": "financial_sensitivity",
        "record": {
            "financial_sensitivity_id": "fsens_alpha_revenue",
            "company_id": "co_alpha",
            "security_id": "sec_alpha",
            "node_id": "node_oem",
            "segment_id": "seg_equipment",
            "driver_name": "revenue growth",
            "driver_type": "revenue",
            "sensitivity_direction": "positive",
            "sensitivity_magnitude": "high",
            "formula_or_logic": "Directional revenue bridge from replacement demand through explicit company exposure.",
            "linked_assumption_ids": [f"assumption_{s}" for s in CANONICAL_SCENARIOS],
            "confidence_level": "high",
        },
        "field_lineage": _lineage(ev, "financial_sensitivity", ["driver_name", "driver_type", "sensitivity_direction", "confidence_level"]),
    })
    payload["records"].append({
        "table": "opportunity_zones",
        "record": {
            "opportunity_id": "opp_oem",
            "opportunity_name": "Commercial HVAC replacement cycle",
            "opportunity_type": "company_group",
            "linked_nodes": ["node_oem"],
            "linked_segments": ["seg_equipment"],
            "linked_companies": ["co_alpha"],
            "linked_securities": ["sec_alpha"],
            "investment_implication": "watchlist",
            "upside_logic": "Replacement demand and service pull-through can support earnings.",
            "downside_logic": "Demand deferral and input-cost pressure can weaken earnings.",
            "time_horizon": "3-12m",
            "valuation_context": "Valuation output disabled pending live market provenance.",
            "evidence_strength": "medium",
            "confidence_level": "medium",
            "falsifier_ids": ["risk_demand"],
            "risk_ids": ["risk_demand"],
        },
        "field_lineage": _lineage(ev, "opportunity_zones", [
            "opportunity_name", "opportunity_type", "investment_implication", "upside_logic", "downside_logic",
            "time_horizon", "evidence_strength", "confidence_level",
        ]),
    })
    return payload


def _ready_workspace(tmp_path: Path, mutate=None) -> Path:
    ws, ev = _accepted_run(tmp_path, _stage5_fields())
    payload = _stage5_payload(ev)
    if mutate:
        mutate(payload)
    populate_dataset(ws, _write(tmp_path / "records.json", payload))
    return ws


def test_missing_inputs_create_explicit_disabled_state(tmp_path: Path):
    ws, ev = _accepted_run(tmp_path, _fields_for_payload())
    populate_dataset(ws, _write(tmp_path / "records.json", _full_stage4_payload(ev)))
    out = prepare_simulation(ws)
    assert out["status"] == "disabled_insufficient_inputs"
    assert out["simulation_maturity_level"] == 0
    assert out["usable_simulation_output_count"] == 0
    readiness = json.loads((ws / "simulation_readiness.json").read_text())
    assert readiness["blocker_count"] > 0
    assert readiness["valuation_status"].startswith("disabled")
    assert json.loads((ws / "simulation" / "node_impact_outputs.json").read_text()) == []
    assert len(json.loads((ws / "simulation" / "simulation_gap_outputs.json").read_text())) > 0


def test_generates_basic_deterministic_propagation_outputs(tmp_path: Path):
    ws = _ready_workspace(tmp_path)
    out = prepare_simulation(ws)
    assert out["status"] == "ready_basic_deterministic"
    assert out["simulation_maturity_level"] == 2
    assert out["canonical_scenarios_present"] == 5
    assert out["node_output_count"] == 5
    assert out["company_output_count"] == 5
    assert out["security_output_count"] == 5
    assert out["opportunity_output_count"] == 5
    assert out["thesis_break_output_count"] == 5
    assert out["usable_simulation_output_count"] > 0
    readiness = json.loads((ws / "simulation_readiness.json").read_text())
    assert readiness["production_claim"] is False
    assert readiness["valuation_status"] == "disabled_missing_live_market_data_and_human_approval"
    compiled = json.loads((ws / "simulation" / "formula_registry_compiled.json").read_text())
    assert any(row["formula_id"] == "formula_node_impact" for row in compiled)
    assert any(row["formula_id"] == "builtin_company_exposure_v1" for row in compiled)
    dataset = json.loads((ws / "industry_dataset.json").read_text())
    assert dataset["maturity"] == "basic_deterministic_with_visible_gaps"
    assert len(dataset["tables"]["simulation_outputs"]) == out["aggregate_simulation_output_count"]
    completeness = json.loads((ws / "completeness_report.json").read_text())
    simulation_row = next(row for row in completeness["tables"] if row["table"] == "simulation_outputs")
    assert simulation_row["row_count"] == out["aggregate_simulation_output_count"]
    assert completeness["populated_required_table_count"] >= 17


def test_falsifier_threshold_is_evaluated(tmp_path: Path):
    ws = _ready_workspace(tmp_path)
    prepare_simulation(ws)
    rows = json.loads((ws / "simulation" / "thesis_break_outputs.json").read_text())
    shock = next(row for row in rows if row["scenario_type"] == "shock")
    bear = next(row for row in rows if row["scenario_type"] == "bear")
    assert shock["trigger_status"] == "triggered"
    assert bear["trigger_status"] == "not_triggered"


def test_missing_canonical_scenario_disables_outputs(tmp_path: Path):
    def mutate(payload):
        payload["records"] = [row for row in payload["records"] if not (row["table"] == "scenario_assumptions" and row["record"]["scenario_type"] == "bear")]
        financial = next(row for row in payload["records"] if row["table"] == "financial_sensitivity")
        financial["record"]["linked_assumption_ids"].remove("assumption_bear")
    ws = _ready_workspace(tmp_path, mutate)
    out = prepare_simulation(ws)
    assert out["status"] == "disabled_insufficient_inputs"
    assert out["usable_simulation_output_count"] == 0
    readiness = json.loads((ws / "simulation_readiness.json").read_text())
    assert any(gap["gap_code"] == "missing_bear_scenario" for gap in readiness["gaps"])


def test_company_without_exposure_disables_security_propagation(tmp_path: Path):
    def mutate(payload):
        payload["records"] = [row for row in payload["records"] if row["table"] != "company_segment_exposure"]
    ws = _ready_workspace(tmp_path, mutate)
    out = prepare_simulation(ws)
    assert out["status"] == "disabled_insufficient_inputs"
    readiness = json.loads((ws / "simulation_readiness.json").read_text())
    assert any(gap["gap_code"] == "missing_company_exposure" for gap in readiness["gaps"])


def test_unsafe_formula_is_rejected_and_journaled(tmp_path: Path):
    def mutate(payload):
        formula = next(row for row in payload["records"] if row["table"] == "formula_registry")
        formula["record"]["formula_expression"] = "__import__('os').system('echo unsafe')"
    ws = _ready_workspace(tmp_path, mutate)
    with pytest.raises(ValueError, match="prohibited|undeclared"):
        prepare_simulation(ws)
    journal = json.loads((ws / "simulation_transaction_journal.json").read_text())
    assert journal["status"] == "failed"
    assert not (ws / ".simulation.lock").exists()


def test_formula_unit_mismatch_is_rejected(tmp_path: Path):
    def mutate(payload):
        formula = next(row for row in payload["records"] if row["table"] == "formula_registry")
        formula["record"]["input_units"]["variable_value"] = "percent"
    ws = _ready_workspace(tmp_path, mutate)
    with pytest.raises(ValueError, match="unit mismatch"):
        prepare_simulation(ws)


def test_active_simulation_lock_blocks_execution(tmp_path: Path):
    ws = _ready_workspace(tmp_path)
    (ws / ".simulation.lock").write_text("active", encoding="utf-8")
    with pytest.raises(ValueError, match="transaction is active"):
        prepare_simulation(ws)
