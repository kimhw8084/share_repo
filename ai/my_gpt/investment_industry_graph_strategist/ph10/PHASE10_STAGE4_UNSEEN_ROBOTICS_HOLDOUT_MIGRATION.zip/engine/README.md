# Industry Intelligence Engine — Phase 16 Stage 6

This package implements the evidence-backed one-input research foundation through deterministic analytical transforms and simulation readiness.

## Commands

```bash
industry-intel-engine init --industry "Commercial HVAC equipment and services" --workspace ./run
industry-intel-engine import-search --workspace ./run --results results.json --provider-config provider.json
industry-intel-engine import-snapshot --workspace ./run --source-id src_... --content-file source.html
industry-intel-engine review-source --workspace ./run --decision-file review.json
industry-intel-engine extract-evidence --workspace ./run --proposals evidence.json
industry-intel-engine populate-dataset --workspace ./run --records dataset_records.json
industry-intel-engine prepare-simulation --workspace ./run
```

## Stage 6 guarantees

- formulas are safe-parsed, unit-checked, versioned, and scenario-scoped;
- assumptions are explicit, bounded, source/owner-labeled, and node-linked;
- scenario changes propagate to nodes, edges, companies, securities, financial sensitivities, opportunities, and falsifiers;
- output tables are persisted rather than existing only as UI state;
- missing canonical scenarios or propagation structures disable usable simulation outputs;
- valuation, price-target, and expected-value outputs remain disabled without their separate evidence and approval gates;
- all outputs remain non-production and non-advisory.

See `docs/PHASE16_STAGE5_ANALYTICAL_TRANSFORMS_SIMULATION_READINESS.md`.


## Stage 6 HTML packet

```bash
industry-intel-engine generate-html --workspace ./run
industry-intel-engine verify-html --workspace ./run --browser /usr/bin/chromium
```

The packet uses the exact 19 canonical tabs, synchronized CSV exports, evidence drilldowns, bounded deterministic scenario controls, and explicit gap/disabled states. Overall score and final maturity remain pending Stage 7 validation.

## Phase 10 Stage 3 controls

Version 0.10.0 adds source-native capture contracts, exact source spans, semantic support checks, event/company analytical specificity, authoritative-source recall, freshness and geography stopping gates, machine-readable falsifiers, and reconciled role-lens scoring. See `docs/PHASE10_STAGE3_EVIDENCE_GROUNDING_ANALYTICAL_SPECIFICITY.md`.
