from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class RunRequest:
    industry_name: str
    geography: str = "Global"
    horizon: str = "1m-1y"
    investability_scope: str = "public_and_private"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class BoundaryResolution:
    industry_id: str
    industry_name_input: str
    resolved_industry_name: str
    definition: str
    included_scope: list[str]
    excluded_scope: list[str]
    adjacent_industries: list[str]
    geographic_scope: str
    time_horizon: str
    investability_scope: str
    boundary_confidence: str
    assumptions: list[str] = field(default_factory=list)
    source_ids: list[str] = field(default_factory=list)
    gap_ids: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ArchetypeResolution:
    primary_archetype: str
    secondary_archetypes: list[str]
    complexity: str
    regulated: bool
    commodity_exposure: bool
    software_platform: bool
    public_company_exposure_expected: bool
    private_market_stress_expected: bool
    live_quant_stress_expected: bool
    matched_keywords: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SourcePlanItem:
    plan_item_id: str
    source_family: str
    priority: int
    mandatory: bool
    purpose: str
    target_tables: list[str]
    target_fields: list[str]
    query_templates: list[str]
    acceptance_requirements: list[str]
    stop_condition: str
    status: str = "planned"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
