from __future__ import annotations

import csv
import json
import statistics
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .atomic import write_json_atomic


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _number(row: dict[str, Any], *keys: str) -> float | None:
    for key in keys:
        value = row.get(key)
        if value not in (None, ""):
            try:
                return float(value)
            except (TypeError, ValueError):
                continue
    return None


def _load(path: Path) -> list[dict[str, Any]]:
    if path.is_symlink() or not path.is_file():
        raise ValueError("scoreboard must be a regular non-symlink file")
    if path.suffix.lower() == ".csv":
        with path.open(newline="", encoding="utf-8") as handle:
            return [dict(row) for row in csv.DictReader(handle)]
    payload = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(payload, dict):
        for key in ("rows", "industries", "scoreboard"):
            if isinstance(payload.get(key), list):
                payload = payload[key]
                break
    if not isinstance(payload, list):
        raise ValueError("scoreboard JSON must contain an array")
    return [row for row in payload if isinstance(row, dict)]


def audit_cross_run(scoreboard_file: str | Path, output_file: str | Path | None = None) -> dict[str, Any]:
    rows = _load(Path(scoreboard_file))
    if len(rows) < 3:
        raise ValueError("cross-run audit requires at least three runs")
    reported = [v for row in rows if (v := _number(row, "overall_score", "final_score", "reported_score", "post_score")) is not None]
    quality = [v for row in rows if (v := _number(row, "research_quality_score", "weighted_score_before_caps", "uncapped_score", "post_weighted_score")) is not None]
    pairs = []
    for row in rows:
        sources = _number(row, "accepted_source_count", "accepted_sources", "sources")
        evidence = _number(row, "eligible_evidence_count", "atomic_evidence_count", "eligible_evidence", "evidence")
        if sources is not None and evidence is not None:
            pairs.append((int(sources), int(evidence)))
    pair_counts = Counter(pairs)
    most_common_pair, most_common_count = pair_counts.most_common(1)[0] if pair_counts else ((None, None), 0)
    lens_quality = [v for row in rows if (v := _number(row, "average_role_lens_quality", "role_lens_quality", "role_lens_average", "role_lens_average_coverage")) is not None]
    reported_stddev = statistics.pstdev(reported) if len(reported) >= 2 else 0.0
    quality_stddev = statistics.pstdev(quality) if len(quality) >= 2 else 0.0
    fingerprints = []
    if len(reported) >= 3 and reported_stddev < 0.5:
        fingerprints.append("reported_score_compression")
    if most_common_count >= 3:
        fingerprints.append("source_evidence_target_convergence")
    if len(lens_quality) >= 3 and statistics.mean(lens_quality) >= 98 and statistics.pstdev(lens_quality) < 0.5:
        fingerprints.append("role_lens_coverage_saturation")
    result = {
        "schema_version": "phase10-stage0-cross-run-audit-v1",
        "generated_at": _now(),
        "run_count": len(rows),
        "reported_score_stddev": round(reported_stddev, 4),
        "research_quality_score_stddev": round(quality_stddev, 4),
        "most_common_source_evidence_pair": {"accepted_sources": most_common_pair[0], "eligible_evidence": most_common_pair[1], "run_count": most_common_count},
        "failure_fingerprints": fingerprints,
        "status": "review_required" if fingerprints else "passed",
    }
    if output_file:
        write_json_atomic(Path(output_file), result)
    return result
