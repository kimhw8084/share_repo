from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TableSpec:
    id_field: str
    required_fields: tuple[str, ...]
    lineage_required_fields: tuple[str, ...]


# Stage 4 implements the canonical analytical table contract.  Relationship IDs and
# engine-generated stable IDs do not require source evidence, but every substantive
# required field must carry exact field-level evidence lineage.
TABLE_SPECS: dict[str, TableSpec] = {
    "industry_boundary": TableSpec(
        "industry_id",
        ("industry_id", "industry_name_input", "resolved_industry_name", "definition", "included_scope", "excluded_scope", "geographic_scope", "time_horizon", "investability_scope", "boundary_confidence"),
        ("resolved_industry_name", "definition", "included_scope", "excluded_scope", "boundary_confidence"),
    ),
    "industry_segments": TableSpec(
        "segment_id",
        ("segment_id", "industry_id", "segment_name", "segment_dimension", "definition"),
        ("segment_name", "segment_dimension", "definition"),
    ),
    "source_ledger": TableSpec(
        "source_id",
        ("source_id", "title", "publisher", "accessed_at", "source_type", "source_quality_tier", "industry_relevance", "freshness_status"),
        (),
    ),
    "atomic_evidence": TableSpec(
        "evidence_id",
        ("evidence_id", "source_id", "claim_text", "claim_type", "paraphrase", "linked_table", "confidence_level", "source_quality_tier", "conflict_status", "extraction_method"),
        (),
    ),
    "value_chain_nodes": TableSpec(
        "node_id",
        ("node_id", "industry_id", "node_name", "node_type", "node_description", "economic_role"),
        ("node_name", "node_type", "node_description", "economic_role"),
    ),
    "value_chain_edges": TableSpec(
        "edge_id",
        ("edge_id", "industry_id", "from_node_id", "to_node_id", "flow_type", "flow_description", "directionality", "materiality"),
        ("flow_type", "flow_description", "directionality", "materiality"),
    ),
    "money_flows": TableSpec(
        "money_flow_id",
        ("money_flow_id", "industry_id", "payer_node_id", "receiver_node_id", "payment_for"),
        ("payment_for",),
    ),
    "profit_pools": TableSpec(
        "profit_pool_id",
        ("profit_pool_id", "industry_id", "node_id", "profit_pool_description", "relative_attractiveness"),
        ("profit_pool_description", "relative_attractiveness"),
    ),
    "cost_structure": TableSpec(
        "cost_id",
        ("cost_id", "industry_id", "cost_category", "materiality"),
        ("cost_category", "materiality"),
    ),
    "demand_drivers": TableSpec(
        "demand_driver_id",
        ("demand_driver_id", "industry_id", "driver_name", "driver_type", "description", "direction", "time_horizon", "confidence_level"),
        ("driver_name", "driver_type", "description", "direction", "time_horizon", "confidence_level"),
    ),
    "end_customers": TableSpec(
        "customer_id",
        ("customer_id", "industry_id", "customer_group", "direct_or_final"),
        ("customer_group", "direct_or_final"),
    ),
    "supply_constraints": TableSpec(
        "constraint_id",
        ("constraint_id", "industry_id", "constraint_name", "constraint_type", "severity"),
        ("constraint_name", "constraint_type", "severity"),
    ),
    "competitive_structure": TableSpec(
        "competitive_structure_id",
        ("competitive_structure_id", "industry_id", "market_structure", "competitive_description", "concentration_level", "barriers_to_entry", "rivalry_intensity"),
        ("market_structure", "competitive_description", "concentration_level", "barriers_to_entry", "rivalry_intensity"),
    ),
    "regulation_policy": TableSpec(
        "regulation_id",
        ("regulation_id", "industry_id", "regulation_name", "jurisdiction", "regulation_type", "status"),
        ("regulation_name", "jurisdiction", "regulation_type", "status"),
    ),
    "technology_disruption": TableSpec(
        "technology_id",
        ("technology_id", "industry_id", "technology_name", "description"),
        ("technology_name", "description"),
    ),
    "company_universe": TableSpec(
        "company_id",
        ("company_id", "company_name", "ownership_type", "business_description", "value_chain_node_ids", "industry_relevance"),
        ("company_name", "ownership_type", "business_description", "industry_relevance"),
    ),
    "security_master": TableSpec(
        "security_id",
        ("security_id", "company_id", "security_type"),
        ("security_type",),
    ),
    "company_segment_exposure": TableSpec(
        "exposure_id",
        ("exposure_id", "company_id", "industry_id", "exposure_type", "exposure_direction", "exposure_magnitude", "confidence_level"),
        ("exposure_type", "exposure_direction", "exposure_magnitude", "confidence_level"),
    ),
    "financial_sensitivity": TableSpec(
        "financial_sensitivity_id",
        ("financial_sensitivity_id", "driver_name", "driver_type", "sensitivity_direction", "confidence_level"),
        ("driver_name", "driver_type", "sensitivity_direction", "confidence_level"),
    ),
    "quantamental_signals": TableSpec(
        "signal_id",
        ("signal_id", "industry_id", "signal_name", "signal_definition", "history_available", "backtest_status", "confidence_level"),
        ("signal_name", "signal_definition", "history_available", "backtest_status", "confidence_level"),
    ),
    "event_catalysts": TableSpec(
        "event_id",
        ("event_id", "industry_id", "event_name", "event_type", "impact_magnitude"),
        ("event_name", "event_type", "impact_magnitude"),
    ),
    "scenario_assumptions": TableSpec(
        "assumption_id",
        ("assumption_id", "scenario_id", "industry_id", "assumption_name", "variable_name", "variable_value", "assumption_owner", "confidence_level"),
        ("assumption_name", "variable_name", "variable_value", "assumption_owner", "confidence_level"),
    ),
    "formula_registry": TableSpec(
        "formula_id",
        ("formula_id", "formula_name", "formula_expression", "output_field", "input_fields", "status"),
        ("formula_name", "formula_expression", "output_field", "input_fields", "status"),
    ),
    "simulation_outputs": TableSpec(
        "simulation_output_id",
        ("simulation_output_id", "scenario_id", "industry_id", "output_type", "direction", "formula_or_logic", "input_assumption_ids", "output_explanation", "confidence_level"),
        ("output_type", "direction", "formula_or_logic", "output_explanation", "confidence_level"),
    ),
    "opportunity_zones": TableSpec(
        "opportunity_id",
        ("opportunity_id", "industry_id", "opportunity_name", "opportunity_type", "investment_implication", "upside_logic", "downside_logic", "time_horizon", "evidence_strength", "confidence_level", "falsifier_ids"),
        ("opportunity_name", "opportunity_type", "investment_implication", "upside_logic", "downside_logic", "time_horizon", "evidence_strength", "confidence_level"),
    ),
    "risks_falsifiers": TableSpec(
        "risk_falsifier_id",
        ("risk_falsifier_id", "industry_id", "record_type", "name", "risk_type", "description", "impact_magnitude"),
        ("record_type", "name", "risk_type", "description", "impact_magnitude"),
    ),
    "gap_register": TableSpec(
        "gap_id",
        ("gap_id", "industry_id", "gap_name", "gap_reason", "severity", "affected_output", "next_action", "blocks_institutional_status", "created_at", "status"),
        (),
    ),
}

PROPOSABLE_TABLES = tuple(
    name for name in TABLE_SPECS
    if name not in {"source_ledger", "atomic_evidence", "gap_register"}
)

ROLE_LENSES: dict[str, tuple[str, ...]] = {
    "long_short_equity_pm": (
        "opportunity_zones", "security_master", "company_segment_exposure",
        "event_catalysts", "risks_falsifiers", "financial_sensitivity",
    ),
    "fundamental_equity_analyst": (
        "company_universe", "company_segment_exposure", "profit_pools",
        "cost_structure", "financial_sensitivity",
    ),
    "quantamental_data_lead": (
        "quantamental_signals", "source_ledger", "atomic_evidence",
    ),
    "event_driven_pm": (
        "event_catalysts", "company_universe", "security_master", "risks_falsifiers",
    ),
    "growth_equity_pe_principal": (
        "industry_segments", "value_chain_nodes", "money_flows", "profit_pools",
        "cost_structure", "competitive_structure", "company_universe",
    ),
}

# Reference validation. Each entry maps a field to its target table.
FOREIGN_KEY_FIELDS: dict[str, dict[str, str]] = {
    "industry_segments": {"industry_id": "industry_boundary"},
    "value_chain_nodes": {"industry_id": "industry_boundary", "segment_ids": "industry_segments"},
    "value_chain_edges": {"industry_id": "industry_boundary", "from_node_id": "value_chain_nodes", "to_node_id": "value_chain_nodes"},
    "money_flows": {"industry_id": "industry_boundary", "payer_node_id": "value_chain_nodes", "receiver_node_id": "value_chain_nodes"},
    "profit_pools": {"industry_id": "industry_boundary", "node_id": "value_chain_nodes", "segment_id": "industry_segments"},
    "cost_structure": {"industry_id": "industry_boundary", "node_id": "value_chain_nodes", "company_id": "company_universe"},
    "demand_drivers": {"industry_id": "industry_boundary", "affected_segments": "industry_segments", "affected_nodes": "value_chain_nodes"},
    "end_customers": {"industry_id": "industry_boundary", "demand_driver_ids": "demand_drivers"},
    "supply_constraints": {"industry_id": "industry_boundary", "affected_node_id": "value_chain_nodes", "affected_segment_id": "industry_segments"},
    "competitive_structure": {"industry_id": "industry_boundary", "affected_node_ids": "value_chain_nodes", "affected_company_ids": "company_universe"},
    "regulation_policy": {"industry_id": "industry_boundary", "affected_nodes": "value_chain_nodes", "affected_companies": "company_universe", "event_id": "event_catalysts"},
    "technology_disruption": {"industry_id": "industry_boundary", "affected_nodes": "value_chain_nodes", "affected_segments": "industry_segments"},
    "company_universe": {"value_chain_node_ids": "value_chain_nodes", "segment_ids": "industry_segments"},
    "security_master": {"company_id": "company_universe"},
    "company_segment_exposure": {"company_id": "company_universe", "security_id": "security_master", "industry_id": "industry_boundary", "segment_id": "industry_segments", "node_id": "value_chain_nodes"},
    "financial_sensitivity": {"company_id": "company_universe", "security_id": "security_master", "node_id": "value_chain_nodes", "segment_id": "industry_segments", "linked_assumption_ids": "scenario_assumptions"},
    "quantamental_signals": {"industry_id": "industry_boundary", "source_id": "source_ledger", "affected_nodes": "value_chain_nodes", "affected_companies": "company_universe"},
    "event_catalysts": {"industry_id": "industry_boundary", "affected_nodes": "value_chain_nodes", "affected_companies": "company_universe", "falsifier_ids": "risks_falsifiers"},
    "scenario_assumptions": {"industry_id": "industry_boundary", "source_ids": "source_ledger", "affected_nodes": "value_chain_nodes", "affected_companies": "company_universe"},
    "simulation_outputs": {"industry_id": "industry_boundary", "affected_node_id": "value_chain_nodes", "affected_company_id": "company_universe", "affected_security_id": "security_master", "input_assumption_ids": "scenario_assumptions"},
    "opportunity_zones": {"industry_id": "industry_boundary", "linked_nodes": "value_chain_nodes", "linked_segments": "industry_segments", "linked_companies": "company_universe", "linked_securities": "security_master", "catalyst_ids": "event_catalysts", "falsifier_ids": "risks_falsifiers", "risk_ids": "risks_falsifiers", "scenario_output_ids": "simulation_outputs"},
    "risks_falsifiers": {"industry_id": "industry_boundary", "affected_nodes": "value_chain_nodes", "affected_companies": "company_universe", "affected_opportunities": "opportunity_zones", "monitoring_signal_ids": "quantamental_signals"},
}
