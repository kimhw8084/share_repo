from __future__ import annotations

from .base import SearchProvider, SourceCandidate
from ..errors import ProviderUnavailable


class NullSearchProvider(SearchProvider):
    def search(self, query: str, *, max_results: int = 10) -> list[SourceCandidate]:
        raise ProviderUnavailable(
            "No real search provider is configured. Source collection is blocked; no synthetic sources were created."
        )
