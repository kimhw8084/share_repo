from __future__ import annotations

from pathlib import Path

from .errors import ConfigurationError


def validate_workspace_path(path: str | Path) -> Path:
    supplied = Path(path)
    # Check the supplied path before resolution so symlinks cannot disappear.
    if supplied.exists() and supplied.is_symlink():
        raise ConfigurationError(f"Workspace path must not be a symlink: {supplied}")
    parent = supplied.parent
    if parent.exists() and parent.is_symlink():
        raise ConfigurationError(f"Workspace parent must not be a symlink: {parent}")
    resolved = supplied.resolve(strict=False)
    return resolved
