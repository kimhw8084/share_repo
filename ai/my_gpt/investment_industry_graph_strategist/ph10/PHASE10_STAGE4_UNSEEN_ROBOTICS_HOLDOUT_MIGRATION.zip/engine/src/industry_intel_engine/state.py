from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from .atomic import write_json_atomic
from .errors import StateTransitionError


_ALLOWED = {
    "initialized": {"boundary_resolved"},
    "boundary_resolved": {"source_plan_ready"},
    "source_plan_ready": {"blocked_source_collection", "collecting_sources"},
    "blocked_source_collection": {"collecting_sources"},
    "collecting_sources": {"sources_collected", "blocked_source_collection"},
    "sources_collected": {"extracting_evidence"},
}


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def transition(state: dict, next_status: str, *, reason: str, artifact: str | None = None) -> dict:
    current = state["status"]
    if next_status not in _ALLOWED.get(current, set()):
        raise StateTransitionError(f"Invalid transition: {current} -> {next_status}")
    state = dict(state)
    state["status"] = next_status
    state["updated_at"] = now()
    history = list(state.get("history", []))
    history.append({"from": current, "to": next_status, "at": state["updated_at"], "reason": reason, "artifact": artifact})
    state["history"] = history
    return state


def save_state(path: Path, state: dict) -> None:
    write_json_atomic(path, state)
