from __future__ import annotations

import hashlib
import json
import os
from contextlib import contextmanager
from copy import deepcopy
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

from .artifact_graph import CORE_TABLES
from .atomic import write_json_atomic, write_text_atomic
from .data_contract import FOREIGN_KEY_FIELDS, PROPOSABLE_TABLES, ROLE_LENSES, TABLE_SPECS
from .ids import stable_id
from .safety import validate_workspace_path
from .quality import role_lens_quality, build_corroboration_graph
from .specificity import validate_analytical_specificity


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load(path: Path) -> Any:
    if path.is_symlink():
        raise ValueError(f"symlink input is prohibited: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


@contextmanager
def _population_lock(root: Path):
    path = root / ".dataset_population.lock"
    if path.is_symlink():
        raise ValueError("dataset population lock must not be a symlink")
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise ValueError("another dataset population transaction is active") from exc
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(json.dumps({"pid": os.getpid(), "created_at": _now()}, sort_keys=True))
            handle.flush()
            os.fsync(handle.fileno())
        yield
    finally:
        try:
            path.unlink()
        except FileNotFoundError:
            pass


def _is_blank(value: Any) -> bool:
    return value is None or value == "" or value == [] or value == {}


def _industry_id(root: Path) -> str:
    boundary = _load(root / "tables" / "industry_boundary.json")
    if not isinstance(boundary, list) or len(boundary) != 1 or not boundary[0].get("industry_id"):
        raise ValueError("industry boundary must contain exactly one industry_id")
    return str(boundary[0]["industry_id"])


def _canonical_source_rows(root: Path) -> list[dict[str, Any]]:
    ledger = _load(root / "source_ledger.json")
    if not isinstance(ledger, list):
        raise ValueError("source ledger is malformed")
    rows_by_id: dict[str, dict[str, Any]] = {}
    today = date.today()
    for source in ledger:
        if not isinstance(source, dict):
            continue
        source_id = str(source.get("source_id") or "")
        # Incremental repair may append raw Stage 2 records to an already
        # canonicalized Stage 4+ ledger. Preserve validated canonical rows.
        if source_id and source.get("source_quality_tier") and source.get("source_hash") and source.get("snapshot_path"):
            required = ("url", "title", "publisher", "publication_date", "source_type", "source_family")
            if any(_is_blank(source.get(field)) for field in required):
                raise ValueError(f"canonical source row is incomplete: {source_id}")
            rows_by_id[source_id] = deepcopy(source)
            continue
        review = source.get("acceptance_review") or {}
        if source.get("status") != "accepted_for_evidence_extraction" or source.get("eligible_for_evidence") is not True:
            continue
        snapshot = source.get("snapshot") or {}
        publication = source.get("publication_date")
        freshness = "unknown"
        if publication:
            try:
                age = (today - date.fromisoformat(str(publication)[:10])).days
                freshness = "current" if age <= 365 else "stale_but_structural"
            except ValueError:
                freshness = "unknown"
        if not source_id:
            raise ValueError("accepted source lacks source_id")
        rows_by_id[source_id] = {
            "source_id": source_id,
            "url": source.get("canonical_url") or source.get("url"),
            "title": source.get("title"),
            "publisher": source.get("publisher"),
            "author": (source.get("metadata") or {}).get("author"),
            "publication_date": publication,
            "accessed_at": snapshot.get("fetched_at") or source.get("discovered_at"),
            "source_type": source.get("source_type"),
            "source_family": source.get("source_family"),
            "source_quality_tier": source.get("source_tier"),
            "geographic_scope": (source.get("metadata") or {}).get("geographic_scope"),
            "industry_relevance": (source.get("metadata") or {}).get("industry_relevance", "unknown"),
            "freshness_status": freshness,
            "snapshot_path": snapshot.get("relative_path"),
            "source_hash": snapshot.get("sha256"),
            "notes": review.get("rationale"),
            "capture_contract": snapshot.get("capture_contract"),
            "source_native_review": source.get("source_native_review"),
            "record_origin_type": "direct_evidence",
        }
    return [rows_by_id[key] for key in sorted(rows_by_id)]


def _claim_type(evidence_type: str) -> str:
    return {
        "analyst_inference": "inference",
        "quantitative_fact": "fact",
        "policy_fact": "fact",
        "company_disclosure": "fact",
        "direct_quote": "fact",
    }.get(evidence_type, "fact")


def _confidence(source_tier: str | None, conflict: str | None, freshness: str | None) -> str:
    if conflict == "conflicting":
        return "low"
    if source_tier in {"tier_1_primary", "tier_2_authoritative"} and freshness != "stale_review_required":
        return "high"
    return "medium"


def _canonical_evidence_rows(root: Path, source_map: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    raw = _load(root / "atomic_evidence.json")
    if not isinstance(raw, list):
        raise ValueError("atomic evidence ledger is malformed")
    rows_by_id: dict[str, dict[str, Any]] = {}
    for ev in raw:
        if not isinstance(ev, dict):
            continue
        evidence_id = str(ev.get("evidence_id") or "")
        # Preserve canonical Stage 4+ rows during an incremental repair pass.
        if evidence_id and ev.get("exact_quote_short") and ev.get("claim_text") and ev.get("source_quality_tier"):
            source_id = str(ev.get("source_id") or "")
            if source_id not in source_map:
                raise ValueError(f"canonical evidence has unresolved accepted source: {evidence_id}")
            rows_by_id[evidence_id] = deepcopy(ev)
            continue
        if ev.get("eligible") is not True:
            continue
        source = source_map.get(str(ev.get("source_id")))
        if not source:
            raise ValueError(f"eligible evidence has unresolved accepted source: {ev.get('evidence_id')}")
        if not evidence_id:
            raise ValueError("eligible evidence lacks evidence_id")
        rows_by_id[evidence_id] = {
            "evidence_id": evidence_id,
            "source_id": ev.get("source_id"),
            "claim_id": stable_id("claim", evidence_id),
            "claim_text": ev.get("claim"),
            "claim_type": _claim_type(str(ev.get("evidence_type", ""))),
            "metric_name": ev.get("metric_name"),
            "metric_value": ev.get("metric_value"),
            "metric_unit": ev.get("metric_unit"),
            "metric_period": ev.get("as_of_date"),
            "metric_geography": ev.get("metric_geography"),
            "metric_definition": ev.get("metric_definition"),
            "source_location": ev.get("source_location") or "verified_snapshot_exact_text_match",
            "exact_quote_short": ev.get("quote"),
            "paraphrase": ev.get("claim"),
            "linked_table": ev.get("linked_table"),
            "linked_field": ev.get("linked_field"),
            "confidence_level": _confidence(source.get("source_quality_tier"), ev.get("conflict_status"), ev.get("freshness_status")),
            "source_quality_tier": source.get("source_quality_tier"),
            "conflict_status": ev.get("conflict_status"),
            "extraction_method": "proposal_validated_source_native_span_and_semantic_support",
            "caveat": ev.get("analyst_note"),
            "snapshot_sha256": ev.get("snapshot_sha256"),
            "source_span": ev.get("source_span"),
            "semantic_support": ev.get("semantic_support"),
            "grounding_status": ev.get("grounding_status"),
            "freshness_status": ev.get("freshness_status"),
            "record_origin_type": "direct_evidence",
        }
    return [rows_by_id[key] for key in sorted(rows_by_id)]


def _validate_required(table: str, row: dict[str, Any]) -> None:
    missing = [field for field in TABLE_SPECS[table].required_fields if _is_blank(row.get(field))]
    if missing:
        raise ValueError(f"{table} record is missing required fields: {', '.join(missing)}")


def _normalize_lineage(raw: Any) -> dict[str, list[str]]:
    if not isinstance(raw, dict):
        raise ValueError("field_lineage must be an object")
    out: dict[str, list[str]] = {}
    for field, ids in raw.items():
        if not isinstance(field, str) or not field:
            raise ValueError("field_lineage keys must be field names")
        if not isinstance(ids, list) or not ids or any(not isinstance(x, str) or not x for x in ids):
            raise ValueError(f"field_lineage for {field} must contain evidence IDs")
        if len(ids) != len(set(ids)):
            raise ValueError(f"field_lineage for {field} contains duplicate evidence IDs")
        out[field] = ids
    return out


def _validate_lineage(
    table: str,
    row: dict[str, Any],
    lineage: dict[str, list[str]],
    evidence_map: dict[str, dict[str, Any]],
    source_map: dict[str, dict[str, Any]],
) -> tuple[list[str], list[str], list[dict[str, Any]]]:
    required = TABLE_SPECS[table].lineage_required_fields
    missing = [field for field in required if field not in lineage]
    if missing:
        raise ValueError(f"{table} record lacks field-level lineage for: {', '.join(missing)}")
    evidence_ids: list[str] = []
    source_ids: list[str] = []
    entries: list[dict[str, Any]] = []
    for field, ids in lineage.items():
        if field not in row:
            raise ValueError(f"lineage field is not present in {table} record: {field}")
        for eid in ids:
            ev = evidence_map.get(eid)
            if not ev:
                raise ValueError(f"unresolved or ineligible evidence_id: {eid}")
            if ev.get("linked_table") != table:
                raise ValueError(f"evidence {eid} supports {ev.get('linked_table')}, not {table}")
            if ev.get("linked_field") != field:
                raise ValueError(f"evidence {eid} supports field {ev.get('linked_field')}, not {field}")
            sid = str(ev.get("source_id"))
            if sid not in source_map:
                raise ValueError(f"evidence {eid} has unresolved accepted source")
            evidence_ids.append(eid)
            source_ids.append(sid)
        entries.append({
            "table": table,
            "record_id": row[TABLE_SPECS[table].id_field],
            "field": field,
            "evidence_ids": sorted(ids),
            "source_ids": sorted({str(evidence_map[eid]["source_id"]) for eid in ids}),
            "lineage_status": "resolved",
        })
    return sorted(set(evidence_ids)), sorted(set(source_ids)), entries


def _generate_id(table: str, row: dict[str, Any], industry_id: str) -> str:
    id_field = TABLE_SPECS[table].id_field
    prefix = {
        "industry_segments": "seg", "value_chain_nodes": "node", "value_chain_edges": "edge",
        "money_flows": "mflow", "profit_pools": "pool", "cost_structure": "cost",
        "demand_drivers": "demand", "end_customers": "cust", "supply_constraints": "constraint",
        "competitive_structure": "competition", "regulation_policy": "reg", "technology_disruption": "tech",
        "company_universe": "co", "security_master": "sec", "company_segment_exposure": "exposure",
        "financial_sensitivity": "fsens", "quantamental_signals": "signal", "event_catalysts": "event",
        "scenario_assumptions": "assumption", "formula_registry": "formula", "simulation_outputs": "sim",
        "opportunity_zones": "opp", "risks_falsifiers": "risk",
    }.get(table, "row")
    content = {k: v for k, v in row.items() if k not in {id_field, "field_lineage", "evidence_ids", "source_ids"}}
    return stable_id(prefix, industry_id, table, json.dumps(content, sort_keys=True, separators=(",", ":"), ensure_ascii=False), length=20)


def _table_ids(tables: dict[str, list[dict[str, Any]]]) -> dict[str, set[str]]:
    ids: dict[str, set[str]] = {}
    for table, rows in tables.items():
        spec = TABLE_SPECS.get(table)
        if not spec:
            continue
        ids[table] = {str(row.get(spec.id_field)) for row in rows if row.get(spec.id_field)}
    return ids


def _validate_foreign_keys(tables: dict[str, list[dict[str, Any]]]) -> None:
    ids = _table_ids(tables)
    for table, mapping in FOREIGN_KEY_FIELDS.items():
        for row in tables.get(table, []):
            rid = row.get(TABLE_SPECS[table].id_field)
            for field, target in mapping.items():
                value = row.get(field)
                if _is_blank(value):
                    continue
                values = value if isinstance(value, list) else [value]
                unresolved = sorted(str(item) for item in values if str(item) not in ids.get(target, set()))
                if unresolved:
                    raise ValueError(f"{table}.{field} has unresolved references for {rid}: {', '.join(unresolved)}")


def _canonical_existing_boundary(root: Path) -> list[dict[str, Any]]:
    rows = _load(root / "tables" / "industry_boundary.json")
    if not isinstance(rows, list):
        raise ValueError("industry boundary table is malformed")
    return rows


def _gap_severity(table: str) -> tuple[str, bool]:
    blockers = {
        "industry_boundary", "industry_segments", "value_chain_nodes", "value_chain_edges", "money_flows",
        "company_universe", "company_segment_exposure", "risks_falsifiers",
    }
    if table in blockers:
        return "blocker", True
    return "major", False


def _normalize_prior_gap(industry_id: str, old: dict[str, Any], now: str) -> dict[str, Any]:
    if all(field in old for field in TABLE_SPECS["gap_register"].required_fields):
        return deepcopy(old)
    category = str(old.get("category", "research_gap"))
    description = str(old.get("description") or old.get("gap_reason") or "Unresolved research gap")
    severity = str(old.get("severity", "major"))
    return {
        "gap_id": old.get("gap_id") or stable_id("gap", industry_id, category, description),
        "industry_id": industry_id,
        "gap_name": old.get("gap_name") or category.replace("_", " ").title(),
        "missing_table": old.get("missing_table"),
        "missing_field": old.get("missing_field"),
        "gap_reason": description,
        "severity": severity,
        "affected_output": old.get("affected_output") or ["industry_dataset", "html", "scoring"],
        "required_source_type": old.get("required_source_type"),
        "next_action": old.get("next_action") or "Collect and review authoritative evidence.",
        "blocks_institutional_status": old.get("blocks_institutional_status", severity == "blocker"),
        "created_at": old.get("created_at") or now,
        "status": old.get("status", "open"),
        "category": category,
    }


def _build_gaps(
    industry_id: str,
    tables: dict[str, list[dict[str, Any]]],
    prior: list[dict[str, Any]],
    lineage_entries: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    now = _now()
    gaps: list[dict[str, Any]] = []
    lineage_keys = {(entry.get("table"), entry.get("record_id"), entry.get("field")) for entry in lineage_entries}

    def missing_lineage_for(table: str) -> list[str]:
        spec = TABLE_SPECS[table]
        missing: list[str] = []
        for row in tables.get(table, []):
            rid = str(row.get(spec.id_field))
            for field in spec.lineage_required_fields:
                if (table, rid, field) not in lineage_keys:
                    missing.append(f"{rid}.{field}")
        return missing

    for old in prior:
        if not isinstance(old, dict):
            continue
        item = _normalize_prior_gap(industry_id, old, now)
        table = str(item.get("missing_table") or "")
        name = str(item.get("gap_name") or "")
        should_close = False
        if item.get("category") == "source_collection" and tables.get("source_ledger") and tables.get("atomic_evidence"):
            should_close = True
        elif table in TABLE_SPECS and name.startswith("Missing canonical table:") and tables.get(table):
            should_close = True
        elif table in TABLE_SPECS and name.startswith("Incomplete field lineage:") and tables.get(table) and not missing_lineage_for(table):
            should_close = True
        if should_close and item.get("status") != "closed":
            item["status"] = "closed"
            item["closed_at"] = now
        gaps.append(item)

    existing_ids = {str(item.get("gap_id")) for item in gaps}
    for table in CORE_TABLES:
        if table == "gap_register":
            continue
        if not tables.get(table):
            severity, blocks = _gap_severity(table)
            gap_id = stable_id("gap", industry_id, "missing_table", table)
            if gap_id not in existing_ids:
                gaps.append({
                    "gap_id": gap_id,
                    "industry_id": industry_id,
                    "gap_name": f"Missing canonical table: {table}",
                    "missing_table": table,
                    "gap_reason": "No evidence-backed records have been populated for this required canonical table.",
                    "severity": severity,
                    "affected_output": ["industry_dataset", "html", "scoring", "investment_logic"],
                    "required_source_type": "table-specific authoritative or primary evidence",
                    "next_action": f"Collect and review evidence mapped to {table}, then submit evidence-backed records.",
                    "blocks_institutional_status": blocks,
                    "created_at": now,
                    "status": "open",
                })
            continue
        missing_lineage = missing_lineage_for(table)
        if missing_lineage:
            severity, blocks = _gap_severity(table)
            gap_id = stable_id("gap", industry_id, "missing_lineage", table)
            if gap_id not in existing_ids:
                gaps.append({
                    "gap_id": gap_id,
                    "industry_id": industry_id,
                    "gap_name": f"Incomplete field lineage: {table}",
                    "missing_table": table,
                    "gap_reason": "One or more substantive required fields lack exact atomic-evidence lineage: " + ", ".join(missing_lineage[:20]),
                    "severity": severity,
                    "affected_output": ["industry_dataset", "html", "scoring", "investment_logic"],
                    "required_source_type": "accepted snapshot-backed atomic evidence",
                    "next_action": f"Replace or enrich {table} records with exact field-level evidence mappings.",
                    "blocks_institutional_status": blocks,
                    "created_at": now,
                    "status": "open",
                })
    return gaps


def _role_lenses(tables: dict[str, list[dict[str, Any]]], gaps: list[dict[str, Any]], lineage_entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    table_gap_ids: dict[str, list[str]] = {}
    for gap in gaps:
        table = gap.get("missing_table")
        if table and gap.get("status") == "open":
            table_gap_ids.setdefault(str(table), []).append(str(gap.get("gap_id")))
    rows = role_lens_quality(tables, lineage_entries)
    for row in rows:
        record_ids: dict[str, list[str]] = {}
        for table in row.get("populated_tables", []):
            spec = TABLE_SPECS[table]
            record_ids[table] = [str(item.get(spec.id_field)) for item in tables.get(table, []) if item.get(spec.id_field)]
        row["record_ids_by_table"] = record_ids
        row["gap_ids"] = sorted({gid for table in row.get("missing_tables", []) for gid in table_gap_ids.get(table, [])})
    return rows


def _completeness(tables: dict[str, list[dict[str, Any]]], lineage_entries: list[dict[str, Any]]) -> dict[str, Any]:
    table_rows = []
    complete = 0
    directly_evidenced_tables = 0
    derived_tables = 0
    origin_counts = {"direct_evidence": 0, "formula_derived": 0, "analyst_assumption": 0, "system_metadata": 0, "gap_placeholder": 0}
    for table in CORE_TABLES:
        rows = tables.get(table, [])
        spec = TABLE_SPECS[table]
        required_cells = len(rows) * len(spec.required_fields)
        present_cells = sum(1 for row in rows for field in spec.required_fields if not _is_blank(row.get(field)))
        lineage_required = len(rows) * len(spec.lineage_required_fields)
        lineage_present = sum(1 for entry in lineage_entries if entry["table"] == table and entry["field"] in spec.lineage_required_fields)
        field_coverage = round(100 * present_cells / required_cells, 2) if required_cells else 0.0
        lineage_coverage = round(100 * lineage_present / lineage_required, 2) if lineage_required else (100.0 if rows else 0.0)
        row_origins = []
        for row in rows:
            origin = str(row.get("record_origin_type") or ("formula_derived" if table in {"formula_registry", "simulation_outputs"} else "direct_evidence"))
            if origin not in origin_counts:
                origin = "system_metadata"
            origin_counts[origin] += 1
            row_origins.append(origin)
        direct_ratio = round(100 * sum(1 for origin in row_origins if origin == "direct_evidence") / max(1, len(row_origins)), 2) if rows else 0.0
        if rows and direct_ratio > 0:
            directly_evidenced_tables += 1
        if rows and any(origin in {"formula_derived", "analyst_assumption"} for origin in row_origins):
            derived_tables += 1
        if not rows:
            status = "empty_with_gap"
        elif field_coverage == 100.0 and lineage_coverage == 100.0:
            status = "minimum_complete"
            complete += 1
        else:
            status = "partial_with_gap"
        table_rows.append({
            "table": table, "row_count": len(rows), "status": status,
            "required_field_coverage_percent": field_coverage,
            "lineage_coverage_percent": lineage_coverage,
            "direct_evidence_row_percent": direct_ratio,
            "origin_type_distribution": {key: row_origins.count(key) for key in origin_counts if row_origins.count(key)},
        })
    populated = sum(1 for item in table_rows if item["row_count"] > 0)
    return {
        "schema_version": "phase10-stage3-completeness-v1",
        "required_table_count": len(CORE_TABLES),
        "populated_required_table_count": populated,
        "minimum_complete_required_table_count": complete,
        "directly_evidenced_table_count": directly_evidenced_tables,
        "derived_or_assumption_table_count": derived_tables,
        "required_table_completeness_percent": round(100 * populated / len(CORE_TABLES), 2),
        "minimum_complete_table_percent": round(100 * complete / len(CORE_TABLES), 2),
        "direct_evidence_table_completeness_percent": round(100 * directly_evidenced_tables / len(CORE_TABLES), 2),
        "derived_output_table_percent": round(100 * derived_tables / len(CORE_TABLES), 2),
        "record_origin_type_counts": origin_counts,
        "tables": table_rows,
    }


def _update_artifact_graph(root: Path, tables: dict[str, list[dict[str, Any]]], completeness: dict[str, Any]) -> dict[str, Any]:
    graph = _load(root / "artifact_graph.json")
    completeness_map = {row["table"]: row for row in completeness["tables"]}
    for item in graph.get("canonical_tables", []):
        table = Path(str(item.get("artifact", ""))).stem
        item["status"] = completeness_map.get(table, {}).get("status", "initialized_empty_with_gap")
        item["row_count"] = len(tables.get(table, []))
    for item in graph.get("package", []):
        if item.get("artifact") == "industry_dataset.json":
            item["status"] = "populated_partial"
    graph["professional_lenses"] = {
        "artifact": "tables/professional_lenses.json",
        "required": True,
        "status": "populated",
    }
    graph["lineage"] = {
        "artifact": "field_lineage.json",
        "required": True,
        "status": "populated",
    }
    write_json_atomic(root / "artifact_graph.json", graph)
    return graph


def _populate_dataset_unlocked(workspace: str | Path, records_file: str | Path) -> dict[str, Any]:
    root = validate_workspace_path(workspace)
    payload = _load(Path(records_file))
    if not isinstance(payload, dict) or not isinstance(payload.get("records"), list):
        raise ValueError("dataset proposal must be an object with a records array")
    analyst = str(payload.get("analyst", "")).strip()
    if not analyst:
        raise ValueError("dataset proposal requires analyst")
    industry_id = _industry_id(root)

    canonical_sources = _canonical_source_rows(root)
    source_map = {str(row["source_id"]): row for row in canonical_sources}
    canonical_evidence = _canonical_evidence_rows(root, source_map)
    evidence_map = {str(row["evidence_id"]): row for row in canonical_evidence}
    if not canonical_sources or not canonical_evidence:
        raise ValueError("at least one accepted source and eligible evidence row are required")

    tables: dict[str, list[dict[str, Any]]] = {table: [] for table in CORE_TABLES}
    tables["industry_boundary"] = _canonical_existing_boundary(root)
    tables["source_ledger"] = canonical_sources
    tables["atomic_evidence"] = canonical_evidence
    tables_dir = root / "tables"
    for table in CORE_TABLES:
        path = tables_dir / f"{table}.json"
        if path.exists() and table not in {"industry_boundary", "source_ledger", "atomic_evidence", "gap_register"}:
            existing = _load(path)
            if not isinstance(existing, list):
                raise ValueError(f"existing table is malformed: {table}")
            tables[table] = existing

    replace_tables_raw = payload.get("replace_tables", [])
    if not isinstance(replace_tables_raw, list) or any(table not in PROPOSABLE_TABLES for table in replace_tables_raw):
        raise ValueError("replace_tables must contain only Stage 4 proposable tables")
    replace_tables = set(replace_tables_raw)
    for table in replace_tables:
        tables[table] = []

    lineage_entries: list[dict[str, Any]] = []
    lineage_path = root / "field_lineage.json"
    if lineage_path.exists():
        prior_lineage = _load(lineage_path)
        if not isinstance(prior_lineage, list):
            raise ValueError("field_lineage.json is malformed")
        lineage_entries.extend(entry for entry in prior_lineage if entry.get("table") not in replace_tables)

    proposed_keys: set[tuple[str, str]] = set()
    accepted_records = 0
    for index, proposal in enumerate(payload["records"]):
        if not isinstance(proposal, dict):
            raise ValueError(f"record proposal {index} must be an object")
        table = str(proposal.get("table", ""))
        if table not in PROPOSABLE_TABLES:
            raise ValueError(f"table is not Stage 4 proposable: {table}")
        record = proposal.get("record")
        if not isinstance(record, dict):
            raise ValueError(f"record proposal {index} lacks record object")
        row = deepcopy(record)
        spec = TABLE_SPECS[table]
        if table == "industry_boundary":
            row["industry_id"] = industry_id
        elif "industry_id" in spec.required_fields:
            supplied_industry = row.get("industry_id")
            if supplied_industry not in {None, industry_id}:
                raise ValueError(f"{table} record belongs to another industry")
            row["industry_id"] = industry_id
        if _is_blank(row.get(spec.id_field)):
            row[spec.id_field] = _generate_id(table, row, industry_id)
        row_id = str(row[spec.id_field])
        key = (table, row_id)
        if key in proposed_keys or any(str(existing.get(spec.id_field)) == row_id for existing in tables[table]):
            raise ValueError(f"duplicate record ID in {table}: {row_id}")
        proposed_keys.add(key)
        _validate_required(table, row)
        lineage = _normalize_lineage(proposal.get("field_lineage"))
        evidence_ids, source_ids, new_lineage = _validate_lineage(table, row, lineage, evidence_map, source_map)
        supplied_origin = str(proposal.get("record_origin_type") or row.get("record_origin_type") or "").strip()
        allowed_origins = {"direct_evidence", "formula_derived", "analyst_assumption", "system_metadata", "gap_placeholder"}
        if supplied_origin and supplied_origin not in allowed_origins:
            raise ValueError(f"invalid record_origin_type: {supplied_origin}")
        if not supplied_origin:
            supplied_origin = "analyst_assumption" if table == "scenario_assumptions" else ("formula_derived" if table == "formula_registry" else "direct_evidence")
        row["record_origin_type"] = supplied_origin
        row["evidence_ids"] = evidence_ids
        row["source_ids"] = source_ids
        row["field_lineage"] = {field: sorted(ids) for field, ids in sorted(lineage.items())}
        row["record_metadata"] = {
            "analyst": analyst,
            "populated_at": payload.get("populated_at") or _now(),
            "lineage_status": "resolved",
        }
        tables[table].append(row)
        lineage_entries.extend(new_lineage)
        accepted_records += 1

    _validate_foreign_keys(tables)
    specificity = validate_analytical_specificity(tables)
    write_json_atomic(root / "analytical_specificity_audit.json", specificity)
    critical_specificity_codes = {
        "event_timing_missing", "event_affected_entities_missing", "event_causal_chain_missing",
        "event_specific_evidence_missing", "event_evidence_overlap_excessive",
        "financial_sensitivity_company_missing", "financial_sensitivity_company_unresolved",
        "financial_sensitivity_security_unresolved", "financial_sensitivity_causal_bridge_missing",
        "company_specific_sensitivity_evidence_missing", "company_sensitivity_evidence_overlap_excessive",
    }
    critical_failures = [failure for failure in specificity["failures"] if failure.get("code") in critical_specificity_codes]
    if critical_failures:
        raise ValueError("analytical specificity validation failed: " + json.dumps(critical_failures, sort_keys=True))
    prior_gaps = _load(root / "gap_register.json")
    if not isinstance(prior_gaps, list):
        raise ValueError("gap register is malformed")
    gaps = _build_gaps(industry_id, tables, prior_gaps, lineage_entries)
    tables["gap_register"] = gaps
    role_lenses = _role_lenses(tables, gaps, lineage_entries)
    completeness = _completeness(tables, lineage_entries)

    for table in CORE_TABLES:
        write_json_atomic(tables_dir / f"{table}.json", tables[table])
    write_json_atomic(root / "field_lineage.json", lineage_entries)
    write_json_atomic(tables_dir / "professional_lenses.json", role_lenses)
    write_json_atomic(root / "gap_register.json", gaps)
    corroboration = build_corroboration_graph(tables)
    write_json_atomic(root / "independent_corroboration_graph.json", corroboration)

    dataset = {
        "schema_version": "phase10-stage3-dataset-v1",
        "run_id": _load(root / "run_state.json").get("run_id"),
        "industry_id": industry_id,
        "generated_at": _now(),
        "production_claim": False,
        "maturity": "structured_dataset_partial",
        "tables": tables,
        "professional_lenses": role_lenses,
        "field_lineage": lineage_entries,
        "completeness": completeness,
        "independent_corroboration": corroboration,
        "analytical_specificity": specificity,
        "gap_summary": {
            "open": sum(1 for gap in gaps if gap.get("status") == "open"),
            "blockers": sum(1 for gap in gaps if gap.get("status") == "open" and gap.get("blocks_institutional_status") is True),
            "major": sum(1 for gap in gaps if gap.get("status") == "open" and gap.get("severity") == "major"),
        },
    }
    dataset_bytes = json.dumps(dataset, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    dataset["dataset_sha256"] = hashlib.sha256(dataset_bytes).hexdigest()
    write_json_atomic(root / "industry_dataset.json", dataset)
    write_json_atomic(root / "completeness_report.json", completeness)
    _update_artifact_graph(root, tables, completeness)

    state_path = root / "run_state.json"
    state = _load(state_path)
    state["status"] = "canonical_dataset_populated_with_gaps"
    state["maturity"] = "structured_dataset_partial"
    state["accepted_source_count"] = len(canonical_sources)
    state["eligible_evidence_count"] = len(canonical_evidence)
    state["populated_required_table_count"] = completeness["populated_required_table_count"]
    state["open_gap_count"] = dataset["gap_summary"]["open"]
    state["blocker_gap_count"] = dataset["gap_summary"]["blockers"]
    state["updated_at"] = _now()
    write_json_atomic(state_path, state)

    progress = _load(root / "progress_ledger.json")
    populated_ratio = completeness["required_table_completeness_percent"]
    progress.update({
        "status": state["status"],
        "source_count": len(canonical_sources),
        "eligible_evidence_count": len(canonical_evidence),
        "populated_required_table_count": completeness["populated_required_table_count"],
        "required_table_count": completeness["required_table_count"],
        "open_gap_count": dataset["gap_summary"]["open"],
        "blocker_gap_count": dataset["gap_summary"]["blockers"],
        "progress_percent": min(55, 15 + round(populated_ratio * 0.4)),
        "progress_basis": "Artifact-backed dataset progress derived from populated canonical tables; HTML, simulation and final validation remain blocked.",
        "blocked_steps": ["simulation", "validation", "html_packet", "final_packaging"],
    })
    completed = list(progress.get("completed_steps", []))
    for step in ["accepted_sources_canonicalized", "atomic_evidence_canonicalized", "canonical_tables_materialized", "field_lineage_materialized", "role_lenses_scored", "gaps_reconciled", "industry_dataset_written"]:
        if step not in completed:
            completed.append(step)
    progress["completed_steps"] = completed
    write_json_atomic(root / "progress_ledger.json", progress)

    write_text_atomic(root / "final_summary.md", f"""# Industry Intelligence run summary

- **Run ID:** `{state.get('run_id')}`
- **Status:** `{state['status']}`
- **Maturity:** `{state['maturity']}`
- **Accepted sources:** {len(canonical_sources)}
- **Eligible atomic evidence:** {len(canonical_evidence)}
- **Populated canonical tables:** {completeness['populated_required_table_count']} / {completeness['required_table_count']}
- **Open gaps:** {dataset['gap_summary']['open']}
- **Blocker gaps:** {dataset['gap_summary']['blockers']}
- **HTML packet:** not generated
- **Production claim:** false

Canonical table records were populated only from eligible snapshot-backed evidence with exact field-level lineage. Empty required tables remain visible in the gap register. Simulation, validation, HTML generation, and production claims remain blocked.
""")

    return {
        "status": state["status"],
        "accepted_record_count": accepted_records,
        "accepted_source_count": len(canonical_sources),
        "eligible_evidence_count": len(canonical_evidence),
        "populated_required_table_count": completeness["populated_required_table_count"],
        "required_table_count": completeness["required_table_count"],
        "required_table_completeness_percent": completeness["required_table_completeness_percent"],
        "open_gap_count": dataset["gap_summary"]["open"],
        "blocker_gap_count": dataset["gap_summary"]["blockers"],
        "professional_lens_count": len(role_lenses),
        "dataset_sha256": dataset["dataset_sha256"],
    }


def populate_dataset(workspace: str | Path, records_file: str | Path) -> dict[str, Any]:
    root = validate_workspace_path(workspace)
    proposal_path = Path(records_file)
    if proposal_path.is_symlink() or not proposal_path.is_file():
        raise ValueError("dataset proposal must be a regular non-symlink file")
    proposal_sha = hashlib.sha256(proposal_path.read_bytes()).hexdigest()
    transaction_id = stable_id("dataset_txn", str(root.resolve()), proposal_sha, _now(), length=20)
    journal_path = root / "dataset_population_journal.json"
    with _population_lock(root):
        write_json_atomic(journal_path, {
            "transaction_id": transaction_id,
            "status": "started",
            "proposal_sha256": proposal_sha,
            "started_at": _now(),
        })
        try:
            result = _populate_dataset_unlocked(root, proposal_path)
        except Exception as exc:
            write_json_atomic(journal_path, {
                "transaction_id": transaction_id,
                "status": "failed",
                "proposal_sha256": proposal_sha,
                "failed_at": _now(),
                "error": str(exc),
            })
            raise
        write_json_atomic(journal_path, {
            "transaction_id": transaction_id,
            "status": "completed",
            "proposal_sha256": proposal_sha,
            "completed_at": _now(),
            "result": result,
        })
        return result
