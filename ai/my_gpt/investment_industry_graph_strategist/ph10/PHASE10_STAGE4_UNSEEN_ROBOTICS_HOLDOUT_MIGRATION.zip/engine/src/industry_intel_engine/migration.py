from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .atomic import write_json_atomic
from .dataset import _completeness
from .quality import build_corroboration_graph, role_lens_quality
from .safety import validate_workspace_path


def _load(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    if path.is_symlink():
        raise ValueError(f"symlink input is prohibited: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def _origin(table: str, row: dict[str, Any]) -> str:
    current = row.get("record_origin_type")
    if current in {"direct_evidence", "formula_derived", "analyst_assumption", "system_metadata", "gap_placeholder"}:
        return str(current)
    if table in {"source_ledger", "atomic_evidence"}:
        return "direct_evidence"
    if table in {"formula_registry", "simulation_outputs"}:
        return "formula_derived"
    if table == "scenario_assumptions":
        return "analyst_assumption"
    if table == "gap_register":
        return "gap_placeholder"
    if row.get("evidence_ids") or row.get("source_ids") or row.get("field_lineage"):
        return "direct_evidence"
    return "analyst_assumption"


def migrate_phase9_quality_artifacts(workspace: str | Path) -> dict[str, Any]:
    root = validate_workspace_path(workspace)
    dataset_path = root / "industry_dataset.json"
    dataset = _load(dataset_path, None)
    if not isinstance(dataset, dict) or not isinstance(dataset.get("tables"), dict):
        raise ValueError("industry_dataset.json with canonical tables is required")
    tables = dataset["tables"]
    for table, rows in tables.items():
        if not isinstance(rows, list):
            continue
        for row in rows:
            if isinstance(row, dict):
                row["record_origin_type"] = _origin(table, row)
        table_path = root / "tables" / f"{table}.json"
        if table_path.exists():
            write_json_atomic(table_path, rows)

    lineage = _load(root / "field_lineage.json", dataset.get("field_lineage", []))
    if not isinstance(lineage, list):
        lineage = []
    lenses = role_lens_quality(tables, lineage)
    write_json_atomic(root / "tables" / "professional_lenses.json", lenses)
    dataset["professional_lenses"] = lenses
    tables["professional_lenses"] = lenses

    completeness = _completeness(tables, lineage)
    dataset["completeness"] = completeness
    dataset["schema_version"] = "phase10-stage0-dataset-v1"
    write_json_atomic(root / "completeness_report.json", completeness)

    candidate_path = root / "source_candidate_ledger.json"
    if not candidate_path.exists():
        candidates = []
        for index, source in enumerate(tables.get("source_ledger", [])):
            if not isinstance(source, dict):
                continue
            candidates.append({
                "candidate_id": f"legacy_candidate_{index+1}",
                "source_id": source.get("source_id"),
                "provider_rank": index + 1,
                "canonical_url": source.get("url"),
                "title": source.get("title"),
                "publisher": source.get("publisher"),
                "source_family": source.get("source_family"),
                "candidate_status": "accepted_for_evidence",
                "dedupe_status": "unique",
                "access_status": "fetched_success",
                "migration_note": "Reconstructed from accepted Phase 9 source ledger; rejected-candidate recall remains unavailable.",
            })
        for rejection in _load(root / "rejected_sources.json", []):
            if isinstance(rejection, dict):
                candidates.append({
                    "candidate_id": rejection.get("candidate_id") or rejection.get("rejection_id"),
                    "source_id": rejection.get("source_id"),
                    "canonical_url": rejection.get("canonical_url") or rejection.get("url"),
                    "title": rejection.get("title"),
                    "publisher": rejection.get("publisher"),
                    "candidate_status": "rejected_legacy",
                    "dedupe_status": "duplicate" if "duplicate_canonical_url" in (rejection.get("reasons") or []) else "unique",
                    "access_status": "unknown_legacy",
                    "decision_reasons": rejection.get("reasons", []),
                })
        write_json_atomic(candidate_path, candidates)

    exports_manifest_path = root / "exports_manifest.json"
    if not exports_manifest_path.exists():
        exports = []
        exports_dir = root / "exports"
        if exports_dir.is_dir():
            for csv_path in sorted(exports_dir.glob("*.csv")):
                if csv_path.is_symlink() or not csv_path.is_file():
                    continue
                row_count = max(0, len(csv_path.read_text(encoding="utf-8", errors="replace").splitlines()) - 1)
                exports.append({
                    "name": csv_path.stem,
                    "csv_path": csv_path.relative_to(root).as_posix(),
                    "row_count": row_count,
                    "migration_note": "Reconstructed from an existing synchronized CSV export; no data rows were created.",
                })
        write_json_atomic(exports_manifest_path, {
            "schema_version": "phase10-stage0-legacy-export-inventory-v1",
            "exports": exports,
            "migration_note": "Manifest reconstructed only from files already present in the accepted legacy bundle.",
        })

    stop_path = root / "research_stop_decision.json"
    if not stop_path.exists():
        write_json_atomic(stop_path, {
            "schema_version": "phase10-stage0-stop-v1",
            "decision": "legacy_phase9_stop_pending_reapproval",
            "approved": False,
            "rationale": "Phase 9 completed before marginal-yield and source-family saturation controls existed. No stop approval is inferred.",
        })

    corroboration = build_corroboration_graph(tables)
    write_json_atomic(root / "independent_corroboration_graph.json", corroboration)
    dataset["independent_corroboration"] = corroboration
    write_json_atomic(dataset_path, dataset)

    state_path = root / "run_state.json"
    state = _load(state_path, {})
    state.update({
        "status": "phase10_quality_schema_migrated_pending_stop_reapproval",
        "source_count": len(tables.get("source_ledger", [])),
        "eligible_evidence_count": len(tables.get("atomic_evidence", [])),
        "research_stop_approved": False,
        "production_claim": False,
    })
    write_json_atomic(state_path, state)
    return {
        "status": state["status"],
        "source_count": state["source_count"],
        "evidence_count": state["eligible_evidence_count"],
        "role_lens_count": len(lenses),
        "average_role_lens_quality": round(sum(row["quality_score"] for row in lenses) / max(1, len(lenses)), 2),
        "direct_evidence_table_completeness_percent": completeness["direct_evidence_table_completeness_percent"],
        "corroboration_group_count": corroboration["claim_group_count"],
        "stop_reapproval_required": True,
    }
