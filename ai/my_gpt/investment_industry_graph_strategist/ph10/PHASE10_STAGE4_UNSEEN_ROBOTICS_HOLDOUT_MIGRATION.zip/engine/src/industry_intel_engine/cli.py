from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .discovery import import_search_results
from .models import RunRequest
from .orchestrator import initialize_run
from .snapshots import import_content_snapshot
from .evidence import review_source, extract_evidence
from .dataset import populate_dataset
from .simulation import prepare_simulation
from .html_packet import generate_html_packet, verify_html_packet
from .validation import finalize_run
from .quality import record_stop_decision
from .migration import migrate_phase9_quality_artifacts
from .cross_run import audit_cross_run
from .source_quality import evaluate_authoritative_recall


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="industry-intel-engine")
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init", help="Initialize a durable one-input industry research run")
    init.add_argument("--industry", required=True)
    init.add_argument("--workspace", required=True)
    init.add_argument("--geography", default="Global")
    init.add_argument("--horizon", default="1m-1y")
    init.add_argument("--investability-scope", default="public_and_private")
    init.add_argument("--run-id")

    imp = sub.add_parser("import-search", help="Import normalized provider search results into an initialized run")
    imp.add_argument("--workspace", required=True)
    imp.add_argument("--results", required=True)
    imp.add_argument("--provider-config", required=True)

    snap = sub.add_parser("import-snapshot", help="Attach a real content snapshot to one discovered source")
    snap.add_argument("--workspace", required=True)
    snap.add_argument("--source-id", required=True)
    snap.add_argument("--content-file", required=True)
    snap.add_argument("--final-url")
    snap.add_argument("--fetched-at")
    snap.add_argument("--content-type")
    snap.add_argument("--status-code", type=int, default=200)
    snap.add_argument("--capture-metadata-file")
    snap.add_argument("--capture-type", default="source_native_document")
    snap.add_argument("--acquisition-method", default="direct_file_import")
    snap.add_argument("--collector", default="cli_import")
    snap.add_argument("--source-native-attested", action=argparse.BooleanOptionalAction, default=False)
    snap.add_argument("--transformed", action="store_true")
    review = sub.add_parser("review-source", help="Accept or reject one captured source after human or policy review")
    review.add_argument("--workspace", required=True)
    review.add_argument("--decision-file", required=True)

    ev = sub.add_parser("extract-evidence", help="Validate and import atomic evidence proposals from accepted snapshots")
    ev.add_argument("--workspace", required=True)
    ev.add_argument("--proposals", required=True)

    data = sub.add_parser("populate-dataset", help="Populate canonical evidence-backed research tables")
    data.add_argument("--workspace", required=True)
    data.add_argument("--records", required=True)

    audit = sub.add_parser("audit-cross-run", help="Audit a multi-industry scoreboard for score compression and target convergence")
    audit.add_argument("--scoreboard", required=True)
    audit.add_argument("--output")

    migrate = sub.add_parser("migrate-quality", help="Migrate a Phase 9 bundle to the Phase 10 quality schema without approving its research stop")
    migrate.add_argument("--workspace", required=True)

    recall = sub.add_parser("evaluate-recall", help="Evaluate accepted source domains against a frozen authoritative benchmark registry")
    recall.add_argument("--workspace", required=True)
    recall.add_argument("--registry", required=True)

    stop = sub.add_parser("record-stop", help="Record a gap-driven research stop or continue decision")
    stop.add_argument("--workspace", required=True)
    stop.add_argument("--decision-file", required=True)

    sim = sub.add_parser("prepare-simulation", help="Validate formulas and generate fail-closed deterministic scenario outputs")
    sim.add_argument("--workspace", required=True)

    html_cmd = sub.add_parser("generate-html", help="Generate the exact 19-tab synchronized interactive HTML packet")
    html_cmd.add_argument("--workspace", required=True)

    html_verify = sub.add_parser("verify-html", help="Verify exact tabs and exercise packet interactions in headless Chromium")
    html_verify.add_argument("--workspace", required=True)
    html_verify.add_argument("--browser")
    html_verify.add_argument("--allow-static-only", action="store_true")

    final = sub.add_parser("finalize-run", help="Validate, score, reconcile, and manifest a complete industry run")
    final.add_argument("--workspace", required=True)
    final.add_argument("--browser")
    final.add_argument("--artifact-state", default="candidate", choices=["draft", "candidate", "final", "archived", "diagnostic"])
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "init":
            result = initialize_run(
                RunRequest(
                    industry_name=args.industry,
                    geography=args.geography,
                    horizon=args.horizon,
                    investability_scope=args.investability_scope,
                ),
                Path(args.workspace),
                run_id=args.run_id,
            )
        elif args.command == "import-search":
            result = import_search_results(args.workspace, args.results, args.provider_config)
        elif args.command == "import-snapshot":
            result = import_content_snapshot(
                args.workspace,
                source_id=args.source_id,
                content_file=args.content_file,
                final_url=args.final_url,
                fetched_at=args.fetched_at,
                content_type=args.content_type,
                status_code=args.status_code,
                capture_metadata_file=args.capture_metadata_file,
                capture_type=args.capture_type,
                acquisition_method=args.acquisition_method,
                collector=args.collector,
                source_native_attested=args.source_native_attested,
                transformed=args.transformed,
            )
        elif args.command == "review-source":
            result = review_source(args.workspace, args.decision_file)
        elif args.command == "extract-evidence":
            result = extract_evidence(args.workspace, args.proposals)
        elif args.command == "populate-dataset":
            result = populate_dataset(args.workspace, args.records)
        elif args.command == "audit-cross-run":
            result = audit_cross_run(args.scoreboard, args.output)
        elif args.command == "migrate-quality":
            result = migrate_phase9_quality_artifacts(args.workspace)
        elif args.command == "evaluate-recall":
            result = evaluate_authoritative_recall(args.workspace, args.registry)
        elif args.command == "record-stop":
            result = record_stop_decision(args.workspace, args.decision_file)
        elif args.command == "prepare-simulation":
            result = prepare_simulation(args.workspace)
        elif args.command == "generate-html":
            result = generate_html_packet(args.workspace)
        elif args.command == "verify-html":
            result = verify_html_packet(args.workspace, browser=args.browser, require_browser=not args.allow_static_only)
        elif args.command == "finalize-run":
            result = finalize_run(args.workspace, browser=args.browser, artifact_state=args.artifact_state)
        else:
            return 2
    except Exception as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, sort_keys=True), file=sys.stderr)
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
