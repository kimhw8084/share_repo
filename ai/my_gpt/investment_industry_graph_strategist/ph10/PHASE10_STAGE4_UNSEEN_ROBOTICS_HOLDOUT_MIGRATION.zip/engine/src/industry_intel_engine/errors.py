class EngineError(Exception):
    """Base engine exception."""


class ConfigurationError(EngineError):
    """Invalid or unsafe configuration."""


class ProviderUnavailable(EngineError):
    """A real source provider is required but unavailable."""


class StateTransitionError(EngineError):
    """Invalid durable-state transition."""
