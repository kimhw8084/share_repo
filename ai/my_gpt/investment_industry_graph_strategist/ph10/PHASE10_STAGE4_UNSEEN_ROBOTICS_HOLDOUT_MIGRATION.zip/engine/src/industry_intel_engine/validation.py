from __future__ import annotations

import hashlib
import json
import math
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .atomic import write_json_atomic, write_text_atomic
from .data_contract import ROLE_LENSES, TABLE_SPECS
from .html_packet import generate_html_packet, verify_html_packet
from .safety import validate_workspace_path
from .quality import continuous_saturation, source_funnel
from .grounding import source_native_grounding_stats
from .specificity import validate_analytical_specificity

VALIDATOR_VERSION = "phase10-stage3-v1"
SCHEMA_VERSION = "phase10-stage3-dataset-v1"
SOURCE_PLAYBOOK_VERSION = "project-source-current"
ACCEPTANCE_VERSION = "project-source-current"
HTML_TEMPLATE_VERSION = "phase10-stage3-html-v1"
SIMULATION_CONTRACT_VERSION = "project-source-current"

COMPONENT_WEIGHTS = {
    "source_quality_and_coverage": 15,
    "atomic_evidence_and_field_coverage": 15,
    "data_contract_and_relationship_integrity": 15,
    "value_chain_money_flows_and_economics": 10,
    "company_and_security_exposure": 10,
    "simulation_validity": 10,
    "investment_logic_and_opportunity_ranking": 15,
    "role_lens_coverage": 5,
    "ui_and_artifact_readiness": 5,
}

CORE_REQUIRED = (
    "industry_boundary", "industry_segments", "source_ledger", "atomic_evidence",
    "value_chain_nodes", "value_chain_edges", "money_flows", "company_universe",
    "security_master", "company_segment_exposure", "event_catalysts",
    "scenario_assumptions", "opportunity_zones", "risks_falsifiers",
)

SOURCE_FAMILY_TARGETS = {
    "official_statistics", "regulator_policy", "company_filings", "company_disclosures",
    "technical_standards", "industry_association", "academic_technical",
    "market_quant", "negative_risk",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    if path.is_symlink():
        raise ValueError(f"symlink input is prohibited: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def _ratio(value: float, target: float) -> float:
    if target <= 0:
        return 0.0
    return _clamp(value / target)


def _rows(dataset: dict[str, Any], table: str) -> list[dict[str, Any]]:
    tables = dataset.get("tables") if isinstance(dataset.get("tables"), dict) else {}
    value = tables.get(table, [])
    return [row for row in value if isinstance(row, dict)] if isinstance(value, list) else []


def _validator_result(
    validator_id: str,
    name: str,
    status: str,
    severity: str = "info",
    message: str = "",
    *,
    score_cap: int | None = None,
    maturity_cap: int | None = None,
    failure_code: str | None = None,
    affected_tables: Iterable[str] = (),
    evidence_refs: Iterable[str] = (),
    source_refs: Iterable[str] = (),
    gap_refs: Iterable[str] = (),
    fix_actions: list[dict[str, Any]] | None = None,
    requires_human_review: bool = False,
) -> dict[str, Any]:
    return {
        "validator_id": validator_id,
        "validator_name": name,
        "validator_version": VALIDATOR_VERSION,
        "status": status,
        "severity": severity,
        "score_delta": 0,
        "score_cap": score_cap,
        "maturity_cap": maturity_cap,
        "affected_tables": list(affected_tables),
        "affected_fields": [],
        "affected_outputs": [],
        "failure_code": failure_code,
        "message": message,
        "evidence_refs": list(evidence_refs),
        "source_refs": list(source_refs),
        "gap_refs": list(gap_refs),
        "fix_actions": fix_actions or [],
        "requires_human_review": requires_human_review,
    }


def _fix(fix_id: str, priority: str, action: str, target_table: str, validator: str) -> dict[str, Any]:
    return {
        "fix_id": fix_id,
        "priority": priority,
        "action": action,
        "target_table": target_table,
        "target_field": None,
        "expected_artifact_change": f"Update {target_table} and regenerate synchronized outputs.",
        "validator_to_rerun": validator,
    }


def _source_family(row: dict[str, Any]) -> str:
    raw = str(row.get("source_family") or row.get("source_type") or "").lower()
    mappings = (
        (("statistic", "energy_agency", "government_report"), "official_statistics"),
        (("regulat", "policy", "government"), "regulator_policy"),
        (("10-k", "10q", "filing", "annual_report"), "company_filings"),
        (("press_release", "investor", "company_disclosure"), "company_disclosures"),
        (("standard", "technical_guide", "best_practice"), "technical_standards"),
        (("association", "trade_group"), "industry_association"),
        (("academic", "research", "laboratory", "technical_report"), "academic_technical"),
        (("market_data", "time_series", "quant"), "market_quant"),
        (("risk", "negative", "bear", "reliability"), "negative_risk"),
    )
    for tokens, family in mappings:
        if any(token in raw for token in tokens):
            return family
    return str(row.get("source_family") or "unclassified")


def _source_stats(dataset: dict[str, Any]) -> dict[str, Any]:
    sources = _rows(dataset, "source_ledger")
    tiers = {"tier_1_primary": 1.0, "tier_2_authoritative": 0.85, "tier_3_reputable_secondary": 0.6, "tier_4_context_only": 0.25}
    families = {_source_family(row) for row in sources}
    freshness = [row for row in sources if row.get("freshness_status") == "current"]
    tier_score = sum(tiers.get(str(row.get("source_quality_tier")), 0.25) for row in sources) / max(1, len(sources))
    return {
        "accepted_source_count": len(sources),
        "source_family_count": len(families - {"unclassified", ""}),
        "source_families": sorted(families),
        "tier_distribution": {tier: sum(1 for row in sources if row.get("source_quality_tier") == tier) for tier in tiers},
        "tier_quality_ratio": round(tier_score, 4),
        "current_source_ratio": round(len(freshness) / max(1, len(sources)), 4),
    }


def _evidence_stats(dataset: dict[str, Any]) -> dict[str, Any]:
    evidence = _rows(dataset, "atomic_evidence")
    tables = {str(row.get("linked_table")) for row in evidence if row.get("linked_table")}
    current = [row for row in evidence if row.get("freshness_status") == "current"]
    conflicts = [row for row in evidence if row.get("conflict_status") not in (None, "", "none", "corroborated", "resolved")]
    duplicates = len(evidence) - len({(row.get("source_id"), row.get("exact_quote_short"), row.get("linked_table"), row.get("linked_field")) for row in evidence})
    return {
        "eligible_evidence_count": len(evidence),
        "covered_table_count": len(tables),
        "covered_tables": sorted(tables),
        "current_evidence_ratio": round(len(current) / max(1, len(evidence)), 4),
        "unresolved_conflict_count": len(conflicts),
        "exact_duplicate_count": duplicates,
    }


def _artifact_counts(root: Path, dataset: dict[str, Any]) -> dict[str, Any]:
    state = _load(root / "run_state.json", {})
    audit = _load(root / "html_packet_audit.json", {})
    exports = _load(root / "exports_manifest.json", {})
    sources = len(_rows(dataset, "source_ledger"))
    evidence = len(_rows(dataset, "atomic_evidence"))
    return {
        "canonical": {"source_count": sources, "evidence_count": evidence},
        "run_state": {"source_count": state.get("source_count"), "evidence_count": state.get("eligible_evidence_count")},
        "html_audit": {"source_count": audit.get("source_count"), "evidence_count": audit.get("evidence_count")},
        "export_count": len(exports.get("exports", [])) if isinstance(exports.get("exports"), list) else 0,
    }


def _role_stats(dataset: dict[str, Any]) -> dict[str, Any]:
    rows = _rows(dataset, "professional_lenses")
    if not rows and isinstance(dataset.get("professional_lenses"), list):
        rows = [row for row in dataset["professional_lenses"] if isinstance(row, dict)]
    result: dict[str, Any] = {}
    if rows:
        for row in rows:
            lens = str(row.get("lens_id") or row.get("lens_name") or "unknown")
            coverage = float(row.get("coverage_percent", 0) or 0)
            quality = float(row.get("quality_score", coverage * 0.55) or 0)
            result[lens] = {
                "coverage_percent": round(_clamp(coverage / 100.0) * 100, 2),
                "quality_score": round(_clamp(quality / 100.0) * 100, 2),
                "evidence_density_score": row.get("evidence_density_score", 0),
                "currentness_score": row.get("currentness_score", 0),
                "causal_chain_depth_score": row.get("causal_chain_depth_score", 0),
                "actionability_score": row.get("actionability_score", 0),
                "status": row.get("status"),
                "missing_tables": row.get("missing_tables", []),
            }
    else:
        for lens, tables in ROLE_LENSES.items():
            populated = sum(1 for table in tables if _rows(dataset, table))
            coverage = round(100 * populated / len(tables), 2)
            result[lens] = {
                "coverage_percent": coverage, "quality_score": round(coverage * 0.55, 2),
                "evidence_density_score": 0, "currentness_score": 0,
                "causal_chain_depth_score": 0, "actionability_score": 0,
                "status": "legacy_derived", "missing_tables": [t for t in tables if not _rows(dataset, t)],
            }
    average_coverage = sum(item["coverage_percent"] for item in result.values()) / max(1, len(result))
    average_quality = sum(item["quality_score"] for item in result.values()) / max(1, len(result))
    return {"roles": result, "average_coverage_percent": round(average_coverage, 2), "average_quality_score": round(average_quality, 2)}


def _component(name: str, ratio: float, validators: list[str], weaknesses: list[str]) -> dict[str, Any]:
    weight = COMPONENT_WEIGHTS[name]
    raw = round(weight * _clamp(ratio), 2)
    return {"component": name, "weight": weight, "raw_score": raw, "validators_used": validators, "caps_applied": [], "top_weaknesses": weaknesses}


def _maturity(maturity_score: float, dataset: dict[str, Any], blockers: list[dict[str, Any]], hard_fail: bool) -> tuple[int, str, int]:
    if hard_fail or not _rows(dataset, "industry_boundary"):
        return 0, "Objective Only / Invalid", 19
    if maturity_score < 40:
        return 1, "Seed", 54
    if maturity_score < 60:
        return 2, "Structured", 69
    if blockers or maturity_score < 75:
        return 3, "Investable Research Candidate" + (" with Blockers" if blockers else ""), 84
    if maturity_score < 88:
        return 4, "Institutional-Grade Candidate", 92
    return 5, "Institutional-Grade", 95


def _final_state_reconciliation(root: Path) -> tuple[str, list[str]]:
    state = _load(root / "run_state.json", {})
    path = root / "final_state_reconciliation.json"
    if not path.exists():
        if str(state.get("status", "")).startswith("validated_"):
            return "fail", ["final_state_reconciliation.json is missing after validation"]
        return "pending", []
    payload = _load(path, {})
    tracked = payload.get("tracked_artifacts") if isinstance(payload.get("tracked_artifacts"), list) else []
    mismatches: list[str] = []
    for row in tracked:
        if not isinstance(row, dict) or not row.get("path"):
            continue
        target = root / str(row["path"])
        if not target.is_file() or target.is_symlink():
            mismatches.append(f"missing_or_unsafe:{row['path']}")
            continue
        if _sha256(target) != row.get("sha256"):
            mismatches.append(f"hash_mismatch:{row['path']}")
    return ("fail" if mismatches else "pass"), mismatches


def validate_run(workspace: str | Path) -> dict[str, Any]:
    root = validate_workspace_path(workspace)
    dataset = _load(root / "industry_dataset.json", {})
    completeness = _load(root / "completeness_report.json", {})
    readiness = _load(root / "simulation_readiness.json", {})
    audit = _load(root / "html_packet_audit.json", {})
    gaps = [row for row in _load(root / "gap_register.json", []) if isinstance(row, dict)]
    open_gaps = [row for row in gaps if row.get("status") != "closed"]
    blockers = [row for row in open_gaps if row.get("severity") == "blocker" or row.get("blocks_institutional_status")]
    fixture_only = (root / "FIXTURE_ONLY.md").exists()
    source = _source_stats(dataset)
    evidence = _evidence_stats(dataset)
    roles = _role_stats(dataset)
    counts = _artifact_counts(root, dataset)
    funnel = source_funnel(root)
    stop_decision = _load(root / "research_stop_decision.json", {"decision": "not_recorded", "approved": False})
    corroboration = _load(root / "independent_corroboration_graph.json", {"claim_group_count": 0, "independently_corroborated_count": 0})
    grounding = source_native_grounding_stats(_rows(dataset, "source_ledger"), _rows(dataset, "atomic_evidence"))
    specificity = _load(root / "analytical_specificity_audit.json", None)
    if not isinstance(specificity, dict):
        specificity = validate_analytical_specificity(dataset.get("tables", {}) if isinstance(dataset.get("tables"), dict) else {})
    recall = _load(root / "authoritative_source_recall.json", {})
    results: list[dict[str, Any]] = []

    required = ["industry_dataset.json", "source_candidate_ledger.json", "source_ledger.json", "atomic_evidence.json", "evidence_extraction_audit.json", "analytical_specificity_audit.json", "gap_register.json", "research_stop_decision.json", "independent_corroboration_graph.json", "index.html", "html_packet_audit.json", "exports_manifest.json"]
    missing = [name for name in required if not (root / name).is_file()]
    results.append(_validator_result(
        "VAL_ARTIFACT_REQUIRED_FILES", "Required final artifacts", "fail" if missing else "pass",
        "blocker" if missing else "info", f"Missing required artifacts: {', '.join(missing)}" if missing else "Required pre-finalization artifacts are present.",
        score_cap=39 if missing else None, maturity_cap=1 if missing else None,
        failure_code="missing_required_artifact" if missing else None,
        fix_actions=[_fix("FIX_REQUIRED_ARTIFACTS", "P0", "Generate every required final artifact.", "artifact_graph", "VAL_ARTIFACT_REQUIRED_FILES")] if missing else [],
    ))

    canonical_counts = counts["canonical"]
    mismatches = []
    for surface in ("run_state", "html_audit"):
        for key, value in canonical_counts.items():
            observed = counts[surface].get(key)
            if observed is not None and int(observed) != int(value):
                mismatches.append(f"{surface}.{key}={observed} vs canonical={value}")
    results.append(_validator_result(
        "VAL_STATE_COUNT_CONSISTENCY", "Cross-artifact count reconciliation", "fail" if mismatches else "pass",
        "blocker" if mismatches else "info", "; ".join(mismatches) if mismatches else "Source and evidence counts reconcile across canonical dataset, state, and HTML audit.",
        score_cap=39 if mismatches else None, maturity_cap=0 if mismatches else None,
        failure_code="source_count_truth_mismatch" if mismatches else None,
        fix_actions=[_fix("FIX_COUNT_RECONCILIATION", "P0", "Regenerate state, HTML, exports, and validation from canonical dataset counts.", "industry_dataset", "VAL_STATE_COUNT_CONSISTENCY")] if mismatches else [],
    ))

    duplicate = evidence["exact_duplicate_count"]
    conflicts = evidence["unresolved_conflict_count"]
    results.append(_validator_result(
        "VAL_EVIDENCE_INTEGRITY", "Atomic evidence integrity", "fail" if duplicate else ("warning" if conflicts else "pass"),
        "blocker" if duplicate else ("major" if conflicts else "info"),
        f"Evidence rows={evidence['eligible_evidence_count']}; exact duplicates={duplicate}; unresolved conflicts={conflicts}.",
        score_cap=54 if duplicate else None, failure_code="exact_duplicate_evidence_counted_as_distinct" if duplicate else ("unresolved_evidence_conflict" if conflicts else None),
        fix_actions=[_fix("FIX_EVIDENCE_INTEGRITY", "P0" if duplicate else "P1", "Deduplicate evidence and resolve material conflicts.", "atomic_evidence", "VAL_EVIDENCE_INTEGRITY")] if duplicate or conflicts else [],
    ))

    grounding_fail = (
        grounding["source_count"] > 0 and grounding["source_native_eligible_ratio"] < 1.0
        or grounding["evidence_count"] > 0 and grounding["source_span_grounded_ratio"] < 1.0
        or grounding["generated_quote_count"] > 0
        or grounding["weak_semantic_support_count"] > 0
    )
    results.append(_validator_result(
        "VAL_SOURCE_NATIVE_GROUNDING", "Source-native capture, extraction-span, and semantic support",
        "fail" if grounding_fail else "pass", "blocker" if grounding_fail else "info",
        f"Source-native captures={grounding['source_native_eligible_count']}/{grounding['source_count']}; span-grounded evidence={grounding['source_span_grounded_count']}/{grounding['evidence_count']}; generated quotes={grounding['generated_quote_count']}; weak semantic support={grounding['weak_semantic_support_count']}.",
        score_cap=39 if grounding_fail else None, maturity_cap=1 if grounding_fail else None,
        failure_code="source_native_grounding_failure" if grounding_fail else None,
        fix_actions=[_fix("FIX_SOURCE_NATIVE_GROUNDING", "P0", "Replace generated/provider-normalized captures with immutable source-native documents and exact extraction spans; rerun semantic support validation.", "atomic_evidence", "VAL_SOURCE_NATIVE_GROUNDING")] if grounding_fail else [],
    ))

    specificity_critical_codes = {
        "event_timing_missing", "event_affected_entities_missing", "event_causal_chain_missing",
        "event_specific_evidence_missing", "event_evidence_overlap_excessive",
        "financial_sensitivity_company_missing", "financial_sensitivity_company_unresolved",
        "financial_sensitivity_security_unresolved", "financial_sensitivity_causal_bridge_missing",
        "company_specific_sensitivity_evidence_missing", "company_sensitivity_evidence_overlap_excessive",
    }
    specificity_critical = [row for row in specificity.get("failures", []) if row.get("code") in specificity_critical_codes]
    specificity_threshold = [row for row in specificity.get("failures", []) if row.get("code") == "falsifier_machine_threshold_missing"]
    specificity_fail = bool(specificity_critical)
    specificity_warning = bool(specificity_threshold) and not specificity_fail
    results.append(_validator_result(
        "VAL_ANALYTICAL_SPECIFICITY", "Event, company-sensitivity, evidence-overlap, and falsifier specificity",
        "fail" if specificity_fail else ("warning" if specificity_warning else "pass"),
        "blocker" if specificity_fail else ("major" if specificity_warning else "info"),
        f"Specificity failures={len(specificity.get('failures', []))}; critical={len(specificity_critical)}; missing machine-readable falsifier thresholds={len(specificity_threshold)}.",
        score_cap=54 if specificity_fail else (89 if specificity_warning else None), maturity_cap=2 if specificity_fail else None,
        failure_code=(specificity_critical[0].get("code") if specificity_fail else ("falsifier_machine_threshold_missing" if specificity_warning else None)),
        fix_actions=[_fix("FIX_ANALYTICAL_SPECIFICITY", "P0" if specificity_fail else "P1", "Add event-specific evidence/timing/entities, company-specific sensitivity evidence and causal bridges, non-templated evidence sets, and machine-readable falsifier thresholds.", "industry_dataset", "VAL_ANALYTICAL_SPECIFICITY")] if specificity_fail or specificity_warning else [],
    ))

    boundary_rows = _rows(dataset, "industry_boundary")
    resolved_name = str((boundary_rows[0] if boundary_rows else {}).get("resolved_industry_name") or "").lower()
    recall_required = "solar" in resolved_name or bool(recall)
    recall_percent = float(recall.get("recall_percent", 0) or 0)
    recall_fail = recall_required and (not recall or recall.get("passed") is not True or recall_percent < 85)
    results.append(_validator_result(
        "VAL_AUTHORITATIVE_SOURCE_RECALL", "Frozen authoritative-source recall benchmark",
        "warning" if recall_fail else "pass", "major" if recall_fail else "info",
        f"Recall={recall_percent:.2f}% against {recall.get('target_domain_count', 0)} frozen domains; required >=85%." if recall_required else "No industry-specific frozen authoritative registry is configured.",
        score_cap=89 if recall_fail else None, failure_code="authoritative_source_recall_below_85" if recall_fail else None,
        fix_actions=[_fix("FIX_AUTHORITATIVE_RECALL", "P1", "Execute current-report and local-language source modules until frozen authoritative recall is at least 85%, without retroactive holdout editing.", "source_ledger", "VAL_AUTHORITATIVE_SOURCE_RECALL")] if recall_fail else [],
    ))

    table_reports = completeness.get("tables", []) if isinstance(completeness.get("tables"), list) else []
    required_pct = float(completeness.get("required_table_completeness_percent", 0) or 0)
    minimum_pct = float(completeness.get("minimum_complete_table_percent", 0) or 0)
    missing_core = [table for table in CORE_REQUIRED if not _rows(dataset, table)]
    results.append(_validator_result(
        "VAL_SCHEMA_REQUIRED_TABLES", "Canonical table completeness", "warning" if missing_core else "pass",
        "major" if missing_core else "info", f"Required-table population={required_pct:.2f}%; minimum-complete={minimum_pct:.2f}%; missing core={missing_core}.",
        score_cap=69 if any(t in missing_core for t in ("company_universe", "security_master", "money_flows", "risks_falsifiers")) else None,
        failure_code="missing_canonical_table" if missing_core else None, affected_tables=missing_core,
        fix_actions=[_fix("FIX_CORE_TABLES", "P1", "Populate missing core tables with field-level evidence lineage or explicit not-applicable determinations.", "industry_dataset", "VAL_SCHEMA_REQUIRED_TABLES")] if missing_core else [],
    ))

    families = set(source["source_families"])
    family_coverage = len(families & SOURCE_FAMILY_TARGETS)
    weak_backbone = source["accepted_source_count"] and source["tier_distribution"].get("tier_4_context_only", 0) / source["accepted_source_count"] > 0.25
    results.append(_validator_result(
        "VAL_SOURCE_FAMILY_COVERAGE", "Source quality and family coverage", "warning" if source["accepted_source_count"] < 12 or family_coverage < 5 or weak_backbone else "pass",
        "major" if source["accepted_source_count"] < 8 else ("moderate" if source["accepted_source_count"] < 12 or family_coverage < 5 else "minor"),
        f"Accepted sources={source['accepted_source_count']}; recognized source families={family_coverage}; tier quality ratio={source['tier_quality_ratio']:.2f}.",
        score_cap=54 if source["accepted_source_count"] < 8 else None,
        failure_code="weak_source_backbone" if weak_backbone else ("insufficient_source_family_coverage" if family_coverage < 5 else None),
        fix_actions=[_fix("FIX_SOURCE_COVERAGE", "P1", "Add missing primary/authoritative source families and refresh stale sources.", "source_ledger", "VAL_SOURCE_FAMILY_COVERAGE")] if source["accepted_source_count"] < 12 or family_coverage < 5 or weak_backbone else [],
    ))

    funnel_problem = funnel["search_execution_count"] > 0 and (
        funnel["discovered_candidate_count"] == 0 or not funnel["rejection_observability_passed"]
    )
    results.append(_validator_result(
        "VAL_SOURCE_CANDIDATE_FUNNEL", "Source candidate and rejection funnel",
        "warning" if funnel_problem else "pass", "major" if funnel_problem else "info",
        f"Discovered={funnel['discovered_candidate_count']}; duplicates={funnel['duplicate_candidate_count']}; pre-review rejected={funnel['pre_snapshot_rejected_count']}; accepted={funnel['review_accepted_source_count']}; evidence-eligible sources={funnel['evidence_eligible_source_count']}.",
        score_cap=89 if funnel_problem else None,
        failure_code="rejected_source_observability_zero" if funnel_problem else None,
        fix_actions=[_fix("FIX_SOURCE_FUNNEL", "P0", "Persist every discovered candidate, dedupe decision, access result, and rejection reason.", "source_candidate_ledger", "VAL_SOURCE_CANDIDATE_FUNNEL")] if funnel_problem else [],
    ))

    stop_approved = stop_decision.get("decision") == "stop_approved" and stop_decision.get("approved") is True
    stop_problem = not stop_approved
    results.append(_validator_result(
        "VAL_RESEARCH_STOP_DECISION", "Gap-driven research stop decision",
        "warning" if stop_problem else "pass", "major" if stop_problem else "info",
        "Research stop is approved with marginal-yield and gap-closure evidence." if stop_approved else "Research stop is not approved; fixed count targets cannot establish source saturation.",
        score_cap=89 if stop_problem else None,
        failure_code="research_stop_not_gap_driven" if stop_problem else None,
        fix_actions=[_fix("FIX_RESEARCH_STOP", "P0", "Record mandatory-family saturation, marginal yield, unresolved material gaps, independent corroboration, and reviewer approval.", "research_stop_decision", "VAL_RESEARCH_STOP_DECISION")] if stop_problem else [],
        requires_human_review=stop_problem,
    ))

    role_problem = roles["average_coverage_percent"] >= 95 and roles["average_quality_score"] < 75
    results.append(_validator_result(
        "VAL_ROLE_LENS_DEPTH", "Professional-lens depth and actionability",
        "warning" if role_problem else "pass", "major" if role_problem else "info",
        f"Average table coverage={roles['average_coverage_percent']:.2f}%; depth/actionability quality={roles['average_quality_score']:.2f}.",
        score_cap=89 if roles["average_quality_score"] < 55 else None,
        failure_code="role_lens_coverage_saturation" if role_problem else None,
        fix_actions=[_fix("FIX_ROLE_LENS_DEPTH", "P0", "Add lens-specific evidence density, currentness, causal depth, catalyst specificity, signal quality, private-market depth, and actionability.", "professional_lenses", "VAL_ROLE_LENS_DEPTH")] if role_problem else [],
    ))

    final_state_status, final_state_mismatches = _final_state_reconciliation(root)
    results.append(_validator_result(
        "VAL_FINAL_STATE_ATOMICITY", "Final-state atomic reconciliation",
        "fail" if final_state_status == "fail" else ("warning" if final_state_status == "pending" else "pass"),
        "blocker" if final_state_status == "fail" else ("minor" if final_state_status == "pending" else "info"),
        "; ".join(final_state_mismatches) if final_state_mismatches else ("Final tracked artifacts reconcile by hash." if final_state_status == "pass" else "Final reconciliation is pending until finalization."),
        score_cap=39 if final_state_status == "fail" else None, maturity_cap=0 if final_state_status == "fail" else None,
        failure_code="final_state_atomicity" if final_state_status == "fail" else None,
        fix_actions=[_fix("FIX_FINAL_STATE_ATOMICITY", "P0", "Regenerate final state in one finalize transaction and rebuild reconciliation hashes.", "final_state_reconciliation", "VAL_FINAL_STATE_ATOMICITY")] if final_state_status == "fail" else [],
    ))

    sim_level = int(readiness.get("simulation_maturity_level", 0) or 0)
    sim_outputs = sum(len(_rows(dataset, table)) for table in ("scenario_assumptions", "formula_registry", "simulation_outputs"))
    results.append(_validator_result(
        "VAL_SIMULATION_VALIDITY", "Simulation validity and disabled-state integrity", "pass" if sim_level >= 2 else "warning",
        "info" if sim_level >= 2 else "major", f"Simulation level={sim_level}; canonical simulation records={sim_outputs}; status={readiness.get('status')}.",
        score_cap=79 if sim_level < 2 else None, failure_code="simulation_disabled_insufficient_inputs" if sim_level < 2 else None,
        fix_actions=[_fix("FIX_SIMULATION_INPUTS", "P1", "Populate source-backed assumptions, propagation links, formulas, and falsifiers.", "scenario_assumptions", "VAL_SIMULATION_VALIDITY")] if sim_level < 2 else [],
    ))

    html_pass = audit.get("browser_status") == "passed" and audit.get("exact_tab_names_passed") is True and int(audit.get("rendered_tab_count", 0) or 0) == 19
    unresolved_html_claims = int(audit.get("unresolved_material_fact_claims", 0) or 0)
    results.append(_validator_result(
        "VAL_HTML_PACKET_TRUTH", "HTML packet identity, interaction, and claim truth", "fail" if not html_pass or unresolved_html_claims else "pass",
        "blocker" if not html_pass else ("major" if unresolved_html_claims else "info"),
        f"HTML exact tabs={audit.get('rendered_tab_count')}; browser={audit.get('browser_status')}; unresolved material claims={unresolved_html_claims}; exports={counts['export_count']}.",
        score_cap=69 if not html_pass or unresolved_html_claims else None,
        failure_code="static_html_mislabeled_interactive" if audit.get("browser_status") != "passed" else ("unsupported_material_claim" if unresolved_html_claims else None),
        fix_actions=[_fix("FIX_HTML_TRUTH", "P0", "Regenerate and browser-verify the synchronized HTML packet.", "index.html", "VAL_HTML_PACKET_TRUTH")] if not html_pass or unresolved_html_claims else [],
    ))

    if fixture_only:
        results.append(_validator_result(
            "VAL_REAL_PROVIDER_ACCEPTANCE", "Real-provider acceptance", "fail", "blocker",
            "FIXTURE_ONLY.md is present; fixture data cannot prove a genuine provider-backed run.", score_cap=54, maturity_cap=1,
            failure_code="fixture_only_not_real_provider", fix_actions=[_fix("FIX_REAL_PROVIDER_RUN", "P0", "Execute the complete pipeline with genuine provider results and captured source content.", "source_ledger", "VAL_REAL_PROVIDER_ACCEPTANCE")],
        ))
    else:
        results.append(_validator_result("VAL_REAL_PROVIDER_ACCEPTANCE", "Real-provider acceptance", "pass", "info", "No fixture-only marker is present and all evidence resolves to accepted captured snapshots."))

    # Phase 10 scoring: publish separate Research Quality, Maturity, and Operational Integrity scores.
    family_ratio = _ratio(family_coverage, 8)
    source_count_saturation = continuous_saturation(source["accepted_source_count"], half_saturation=14)
    funnel_ratio = 1.0 if funnel["rejection_observability_passed"] else 0.35
    corroboration_groups = int(corroboration.get("claim_group_count", 0) or 0)
    corroborated_groups = int(corroboration.get("independently_corroborated_count", 0) or 0)
    corroboration_ratio = corroborated_groups / max(1, corroboration_groups) if corroboration_groups else 0.35
    source_component_ratio = (
        0.22 * source_count_saturation + 0.22 * family_ratio + 0.22 * source["tier_quality_ratio"] +
        0.12 * source["current_source_ratio"] + 0.10 * funnel_ratio + 0.12 * corroboration_ratio
    )
    source_weakness = []
    if source["accepted_source_count"] < 12: source_weakness.append("Accepted-source depth remains limited.")
    if family_coverage < 6: source_weakness.append("Source-family diversity is incomplete.")
    if not funnel["rejection_observability_passed"]: source_weakness.append("Source-candidate rejection funnel is not observable.")
    if corroboration_ratio < 0.35: source_weakness.append("Independent corroboration is thin.")

    evidence_count_saturation = continuous_saturation(evidence["eligible_evidence_count"], half_saturation=110)
    evidence_table_ratio = _ratio(evidence["covered_table_count"], 23)
    lineage_pct = float(completeness.get("minimum_complete_table_percent", 0) or 0) / 100
    direct_table_pct = float(completeness.get("direct_evidence_table_completeness_percent", 0) or 0) / 100
    evidence_component_ratio = (
        0.32 * evidence_count_saturation + 0.22 * evidence_table_ratio + 0.18 * lineage_pct +
        0.13 * direct_table_pct + 0.10 * evidence["current_evidence_ratio"] +
        0.05 * (1.0 if evidence["unresolved_conflict_count"] == 0 else 0.0)
    )
    evidence_weakness = []
    if evidence["eligible_evidence_count"] < 100: evidence_weakness.append("Atomic evidence depth remains below a robust institutional candidate level.")
    if evidence["covered_table_count"] < 18: evidence_weakness.append("Evidence is concentrated in too few canonical tables.")
    if direct_table_pct < 0.70: evidence_weakness.append("Direct-evidence completeness is materially below total populated-table completeness.")

    table_ratio = required_pct / 100
    minimum_ratio = minimum_pct / 100
    schema_component_ratio = 0.48 * table_ratio + 0.27 * minimum_ratio + 0.15 * direct_table_pct + 0.10 * (0 if mismatches else 1)
    schema_weakness = [f"{len(missing_core)} core tables remain empty or incomplete."] if missing_core else []

    vc_tables = ("value_chain_nodes", "value_chain_edges", "money_flows", "profit_pools", "cost_structure")
    vc_population = sum(1 for table in vc_tables if _rows(dataset, table)) / len(vc_tables)
    vc_lineage = sum(1 for table in vc_tables if any(row.get("evidence_ids") for row in _rows(dataset, table))) / len(vc_tables)
    vc_component_ratio = 0.55 * vc_population + 0.45 * vc_lineage
    vc_weakness = [f"Missing or unlinked {table}." for table in vc_tables if not _rows(dataset, table)]

    company_tables = ("company_universe", "security_master", "company_segment_exposure", "financial_sensitivity")
    company_population = sum(1 for table in company_tables if _rows(dataset, table)) / len(company_tables)
    company_lineage = sum(1 for table in company_tables if any(row.get("evidence_ids") for row in _rows(dataset, table))) / len(company_tables)
    company_component_ratio = 0.55 * company_population + 0.45 * company_lineage
    company_weakness = [f"Missing or unlinked {table}." for table in company_tables if not _rows(dataset, table)]

    simulation_component_ratio = 0.88 if sim_level == 2 else (1.0 if sim_level >= 3 else (0.42 if sim_level == 1 else 0.0))
    if sim_level == 2:
        simulation_weakness = ["Simulation is deterministic and directional; historical calibration is absent."]
    elif sim_level < 2:
        simulation_weakness = ["Simulation is disabled or below basic deterministic readiness."]
    else:
        simulation_weakness = []

    investment_tables = ("opportunity_zones", "risks_falsifiers", "event_catalysts", "regulation_policy", "technology_disruption", "financial_sensitivity")
    investment_population = sum(1 for table in investment_tables if _rows(dataset, table)) / len(investment_tables)
    investment_actionability = roles["roles"].get("long_short_equity_pm", {}).get("actionability_score", 0) / 100
    investment_component_ratio = 0.65 * investment_population + 0.35 * investment_actionability
    investment_weakness = [f"Missing {table}." for table in investment_tables if not _rows(dataset, table)]
    if investment_actionability < 0.6: investment_weakness.append("Investment implications lack sufficient catalyst/falsifier/actionability depth.")

    role_component_ratio = roles["average_quality_score"] / 100
    role_weakness = ["Professional-lens depth/actionability is below 75."] if roles["average_quality_score"] < 75 else []

    ui_component_ratio = (0.35 if html_pass else 0) + (0.20 if counts["export_count"] >= 40 else _ratio(counts["export_count"], 40) * 0.20) + (0.15 if not unresolved_html_claims else 0) + (0.15 if not missing else 0) + (0.15 if final_state_status in {"pass", "pending"} else 0)
    ui_weakness = [] if ui_component_ratio >= 0.9 else ["HTML, export, final-state, or artifact readiness is incomplete."]

    components = [
        _component("source_quality_and_coverage", source_component_ratio, ["VAL_SOURCE_FAMILY_COVERAGE", "VAL_SOURCE_CANDIDATE_FUNNEL"], source_weakness),
        _component("atomic_evidence_and_field_coverage", evidence_component_ratio, ["VAL_EVIDENCE_INTEGRITY", "VAL_SOURCE_NATIVE_GROUNDING", "VAL_SCHEMA_REQUIRED_TABLES"], evidence_weakness),
        _component("data_contract_and_relationship_integrity", schema_component_ratio, ["VAL_SCHEMA_REQUIRED_TABLES", "VAL_STATE_COUNT_CONSISTENCY", "VAL_FINAL_STATE_ATOMICITY"], schema_weakness),
        _component("value_chain_money_flows_and_economics", vc_component_ratio, ["VAL_SCHEMA_REQUIRED_TABLES"], vc_weakness),
        _component("company_and_security_exposure", company_component_ratio, ["VAL_SCHEMA_REQUIRED_TABLES", "VAL_ANALYTICAL_SPECIFICITY"], company_weakness),
        _component("simulation_validity", simulation_component_ratio, ["VAL_SIMULATION_VALIDITY"], simulation_weakness),
        _component("investment_logic_and_opportunity_ranking", investment_component_ratio, ["VAL_SCHEMA_REQUIRED_TABLES", "VAL_ROLE_LENS_DEPTH", "VAL_ANALYTICAL_SPECIFICITY"], investment_weakness),
        _component("role_lens_coverage", role_component_ratio, ["VAL_ROLE_LENS_DEPTH"], role_weakness),
        _component("ui_and_artifact_readiness", ui_component_ratio, ["VAL_HTML_PACKET_TRUTH", "VAL_ARTIFACT_REQUIRED_FILES", "VAL_FINAL_STATE_ATOMICITY"], ui_weakness),
    ]
    research_quality_score = round(sum(row["raw_score"] for row in components), 2)

    maturity_score = round(100 * (
        0.16 * continuous_saturation(source["accepted_source_count"], half_saturation=12) +
        0.24 * continuous_saturation(evidence["eligible_evidence_count"], half_saturation=95) +
        0.20 * table_ratio + 0.12 * minimum_ratio + 0.08 * direct_table_pct +
        0.10 * (1.0 if sim_level >= 2 else 0.0) + 0.10 * (1.0 if html_pass else 0.0)
    ), 2)

    validator_values = []
    for row in results:
        if row["status"] == "pass": validator_values.append(1.0)
        elif row["status"] == "warning": validator_values.append(0.55)
        else: validator_values.append(0.0)
    operational_integrity_score = round(100 * sum(validator_values) / max(1, len(validator_values)), 2)
    combined_score_before_caps = round(0.65 * research_quality_score + 0.20 * maturity_score + 0.15 * operational_integrity_score, 2)

    active_caps = [row["score_cap"] for row in results if row.get("score_cap") is not None]
    hard_fail = any(row["status"] == "fail" and row["severity"] == "blocker" for row in results)
    maturity_level, maturity_label, maturity_cap = _maturity(maturity_score, dataset, blockers, hard_fail)
    active_caps.append(maturity_cap)
    if fixture_only:
        active_caps.append(54)
    if roles["average_quality_score"] < 40:
        active_caps.append(69)
    if not stop_approved:
        active_caps.append(89)
    active_caps.append(95)  # benchmark/world-class proof remains external to a single run
    final_score = round(min([combined_score_before_caps, *active_caps]), 2)
    if final_score <= 19: score_label = "Invalid / Not Usable"
    elif final_score <= 39: score_label = "Very Preliminary / Major Gaps"
    elif final_score <= 54: score_label = "Seed"
    elif final_score <= 69: score_label = "Structured but Not Investable"
    elif final_score <= 79: score_label = "Investable Research Candidate"
    elif final_score <= 89: score_label = "Institutional-Grade Candidate"
    elif final_score <= 95: score_label = "Institutional-Grade"
    else: score_label = "World-Class / Benchmark-Ready"

    if hard_fail or source["accepted_source_count"] < 8 or evidence["eligible_evidence_count"] < 30:
        confidence = "low"
    elif blockers or not stop_approved or source["accepted_source_count"] < 12 or evidence["eligible_evidence_count"] < 80:
        confidence = "medium"
    else:
        confidence = "high" if evidence["unresolved_conflict_count"] == 0 and source["tier_quality_ratio"] >= 0.75 else "medium"

    fingerprints = sorted({row["failure_code"] for row in results if row.get("failure_code")})
    weaknesses = []
    for component in sorted(components, key=lambda row: row["raw_score"] / row["weight"]):
        weaknesses.extend(component["top_weaknesses"])
    for row in results:
        if row["status"] in {"fail", "warning"} and row["message"]:
            weaknesses.append(row["message"])
    top_weaknesses = []
    for item in weaknesses:
        if item and item not in top_weaknesses:
            top_weaknesses.append(item)
        if len(top_weaknesses) >= 5:
            break
    next_actions = []
    for row in results:
        next_actions.extend(row.get("fix_actions", []))

    boundary = _rows(dataset, "industry_boundary")
    industry = boundary[0] if boundary else {}
    report = {
        "schema_version": "phase10-stage3-validation-report-v1",
        "validator_version": VALIDATOR_VERSION,
        "generated_at": _now(),
        "run_id": dataset.get("run_id") or _load(root / "run_state.json", {}).get("run_id"),
        "industry_id": dataset.get("industry_id") or industry.get("industry_id"),
        "packet_title": industry.get("resolved_industry_name") or _load(root / "run_request.json", {}).get("industry_name"),
        "maturity_level_number": maturity_level,
        "maturity_level": maturity_label,
        "overall_score": final_score,
        "research_quality_score": research_quality_score,
        "maturity_score": maturity_score,
        "operational_integrity_score": operational_integrity_score,
        "combined_score_before_caps": combined_score_before_caps,
        "weighted_score_before_caps": combined_score_before_caps,
        "score_label": score_label,
        "score_confidence": confidence,
        "hard_fail_status": "hard_fail" if hard_fail else "none",
        "hard_fail_list": [row["failure_code"] or row["validator_id"] for row in results if row["status"] == "fail" and row["severity"] == "blocker"],
        "active_score_caps": sorted(set(active_caps)),
        "score_components": components,
        "validator_results": results,
        "failure_fingerprints": fingerprints,
        "gap_summary": {
            "open_gap_count": len(open_gaps),
            "blocker_gap_count": len(blockers),
            "major_gap_count": sum(1 for row in open_gaps if row.get("severity") == "major"),
            "gap_ids": [row.get("gap_id") for row in open_gaps if row.get("gap_id")],
        },
        "source_statistics": source,
        "source_funnel": funnel,
        "research_stop_decision": stop_decision,
        "independent_corroboration": corroboration,
        "source_native_grounding": grounding,
        "analytical_specificity": specificity,
        "authoritative_source_recall": recall if recall else {"status": "not_configured"},
        "evidence_statistics": evidence,
        "completeness_statistics": completeness,
        "artifact_count_reconciliation": counts,
        "role_lens_scores": roles,
        "unresolved_conflicts": evidence["unresolved_conflict_count"],
        "stale_source_warnings": source["accepted_source_count"] - round(source["accepted_source_count"] * source["current_source_ratio"]),
        "weak_source_warnings": source["tier_distribution"].get("tier_4_context_only", 0),
        "top_weaknesses": top_weaknesses,
        "next_actions": next_actions,
        "versions": {
            "schema": dataset.get("schema_version", SCHEMA_VERSION),
            "source_playbook": SOURCE_PLAYBOOK_VERSION,
            "acceptance_criteria": ACCEPTANCE_VERSION,
            "html_template": HTML_TEMPLATE_VERSION,
            "simulation_contract": SIMULATION_CONTRACT_VERSION,
            "validator": VALIDATOR_VERSION,
        },
        "fixture_only": fixture_only,
        "production_claim": bool(not fixture_only and not hard_fail and not blockers and stop_approved and final_state_status == "pass" and final_score >= 80 and maturity_level >= 4),
        "disposition": ("fail_invalid" if hard_fail else ("pass_with_major_gaps" if blockers or any(row.get("severity") == "major" for row in open_gaps) else "pass")),
    }
    return report


def _report_markdown(report: dict[str, Any]) -> str:
    component_lines = "\n".join(
        f"| {row['component']} | {row['raw_score']:.2f} | {row['weight']} |"
        for row in report["score_components"]
    )
    validator_lines = "\n".join(
        f"| {row['validator_id']} | {row['status']} | {row['severity']} | {row['message'].replace('|', '/')} |"
        for row in report["validator_results"]
    )
    weaknesses = "\n".join(f"- {item}" for item in report["top_weaknesses"]) or "- None recorded."
    actions = "\n".join(f"- **{item['priority']}** {item['action']}" for item in report["next_actions"]) or "- None required."
    return f"""# Validation Report — {report.get('packet_title') or 'Industry Packet'}

- **Run ID:** `{report.get('run_id')}`
- **Industry ID:** `{report.get('industry_id')}`
- **Validated at:** {report.get('generated_at')}
- **Disposition:** `{report.get('disposition')}`
- **Maturity:** {report.get('maturity_level')}
- **Score:** **{report.get('overall_score')} / 100** ({report.get('score_label')})
- **Research Quality score:** {report.get('research_quality_score')}
- **Maturity score:** {report.get('maturity_score')}
- **Operational Integrity score:** {report.get('operational_integrity_score')}
- **Combined score before caps:** {report.get('combined_score_before_caps')}
- **Confidence:** {report.get('score_confidence')}
- **Hard-fail status:** `{report.get('hard_fail_status')}`
- **Production claim:** `{str(report.get('production_claim')).lower()}`

## Score decomposition

| Component | Score | Weight |
|---|---:|---:|
{component_lines}

## Validator results

| Validator | Status | Severity | Result |
|---|---|---|---|
{validator_lines}

## Source and evidence statistics

- Discovered source candidates: **{report['source_funnel']['discovered_candidate_count']}**
- Rejected or duplicate candidates: **{report['source_funnel']['pre_snapshot_rejected_count'] + report['source_funnel']['duplicate_candidate_count']}**
- Accepted sources: **{report['source_statistics']['accepted_source_count']}**
- Recognized source families: **{report['source_statistics']['source_family_count']}**
- Eligible atomic evidence: **{report['evidence_statistics']['eligible_evidence_count']}**
- Evidence-covered tables: **{report['evidence_statistics']['covered_table_count']}**
- Unresolved conflicts: **{report['evidence_statistics']['unresolved_conflict_count']}**

## Professional-lens quality

- Average table coverage: **{report['role_lens_scores']['average_coverage_percent']}%**
- Average depth/actionability quality: **{report['role_lens_scores']['average_quality_score']} / 100**

## Research stop decision

- Decision: `{report['research_stop_decision'].get('decision')}`
- Approved: `{str(report['research_stop_decision'].get('approved', False)).lower()}`

## Gaps

- Open gaps: **{report['gap_summary']['open_gap_count']}**
- Blocker gaps: **{report['gap_summary']['blocker_gap_count']}**
- Major gaps: **{report['gap_summary']['major_gap_count']}**

## Top weaknesses

{weaknesses}

## Required next actions

{actions}

## Active score caps

`{report.get('active_score_caps')}`

The score is subordinate to hard-fail, maturity, evidence, and benchmark gates. It is not an investment recommendation.
"""


def _manifest(root: Path, report: dict[str, Any], artifact_state: str) -> dict[str, Any]:
    excluded = {"manifest.json"}
    files = []
    checksums: dict[str, str] = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        rel = path.relative_to(root).as_posix()
        if rel in excluded or rel.startswith(".finalize"):
            continue
        digest = _sha256(path)
        checksums[rel] = digest
        files.append({"path": rel, "sha256": digest, "byte_size": path.stat().st_size})
    source_dates = []
    dataset = _load(root / "industry_dataset.json", {})
    for row in _rows(dataset, "source_ledger"):
        value = row.get("accessed_at") or row.get("publication_date")
        if value:
            source_dates.append(str(value))
    return {
        "manifest_version": "phase10-stage0-manifest-v1",
        "run_id": report.get("run_id"),
        "industry_id": report.get("industry_id"),
        "industry_name": report.get("packet_title"),
        "generated_at": _now(),
        "validated_at": report.get("generated_at"),
        "schema_version": report["versions"]["schema"],
        "source_playbook_version": report["versions"]["source_playbook"],
        "acceptance_criteria_version": report["versions"]["acceptance_criteria"],
        "html_template_spec_version": report["versions"]["html_template"],
        "simulation_contract_version": report["versions"]["simulation_contract"],
        "validator_spec_version": report["versions"]["validator"],
        "template_version": report["versions"]["html_template"],
        "source_accessed_range": {"min": min(source_dates) if source_dates else None, "max": max(source_dates) if source_dates else None},
        "file_inventory": files,
        "files": [{"path": item["path"], "sha256": item["sha256"], "byte_size": item["byte_size"]} for item in files],
        "entries": [{"path": item["path"], "sha256": item["sha256"], "byte_size": item["byte_size"]} for item in files],
        "checksums": checksums,
        "artifact_state": artifact_state,
        "known_state_conflicts": [],
        "score": report.get("overall_score"),
        "maturity": report.get("maturity_level"),
        "hard_fail_status": report.get("hard_fail_status"),
        "production_claim": report.get("production_claim"),
    }



def _write_final_state_reconciliation(root: Path, report: dict[str, Any]) -> dict[str, Any]:
    tracked_names = [
        "industry_dataset.json", "source_candidate_ledger.json", "source_ledger.json",
        "atomic_evidence.json", "gap_register.json", "research_stop_decision.json",
        "independent_corroboration_graph.json", "completeness_report.json",
        "simulation_readiness.json", "packet_data.json", "index.html",
        "html_packet_audit.json", "exports_manifest.json", "run_state.json",
        "progress_ledger.json", "artifact_graph.json", "final_summary.md",
    ]
    tracked = []
    for name in tracked_names:
        path = root / name
        if not path.is_file() or path.is_symlink():
            continue
        tracked.append({"path": name, "sha256": _sha256(path), "byte_size": path.stat().st_size})
    payload = {
        "schema_version": "phase10-stage0-final-state-v1",
        "generated_at": _now(),
        "run_id": report.get("run_id"),
        "industry_id": report.get("industry_id"),
        "overall_score": report.get("overall_score"),
        "research_quality_score": report.get("research_quality_score"),
        "maturity_score": report.get("maturity_score"),
        "operational_integrity_score": report.get("operational_integrity_score"),
        "tracked_artifact_count": len(tracked),
        "tracked_artifacts": tracked,
    }
    write_json_atomic(root / "final_state_reconciliation.json", payload)
    return payload

def finalize_run(workspace: str | Path, *, browser: str | None = None, artifact_state: str = "candidate") -> dict[str, Any]:
    if artifact_state not in {"draft", "candidate", "final", "archived", "diagnostic"}:
        raise ValueError("artifact_state is invalid")
    root = validate_workspace_path(workspace)
    if not (root / "industry_dataset.json").exists():
        raise ValueError("populate-dataset must complete before finalization")
    if not (root / "index.html").exists():
        generate_html_packet(root)
    verify_html_packet(root, browser=browser, require_browser=bool(browser))

    # Provisional score is needed so the packet can render score/cap diagnostics.
    report = validate_run(root)
    write_json_atomic(root / "validation_report.json", report)
    write_text_atomic(root / "validation_report.md", _report_markdown(report))
    generate_html_packet(root)
    verify_html_packet(root, browser=browser, require_browser=bool(browser))
    report = validate_run(root)

    def sync_state(current_report: dict[str, Any]) -> None:
        state_path = root / "run_state.json"
        state = _load(state_path, {})
        state.update({
            "status": "validated_final_candidate" if not current_report["production_claim"] else "validated_production_candidate",
            "maturity": current_report["maturity_level"],
            "overall_score": current_report["overall_score"],
            "research_quality_score": current_report["research_quality_score"],
            "maturity_score": current_report["maturity_score"],
            "operational_integrity_score": current_report["operational_integrity_score"],
            "hard_fail_status": current_report["hard_fail_status"],
            "score_confidence": current_report["score_confidence"],
            "production_claim": current_report["production_claim"],
            "source_count": current_report["source_statistics"]["accepted_source_count"],
            "accepted_source_count": current_report["source_statistics"]["accepted_source_count"],
            "discovered_candidate_count": current_report["source_funnel"]["discovered_candidate_count"],
            "eligible_evidence_count": current_report["evidence_statistics"]["eligible_evidence_count"],
            "open_gap_count": current_report["gap_summary"]["open_gap_count"],
            "blocker_gap_count": current_report["gap_summary"]["blocker_gap_count"],
            "research_stop_approved": current_report["research_stop_decision"].get("approved", False),
            "validated_at": current_report["generated_at"],
            "updated_at": _now(),
        })
        write_json_atomic(state_path, state)

        progress_path = root / "progress_ledger.json"
        progress = _load(progress_path, {})
        completed = list(progress.get("completed_steps", []))
        for step in [
            "html_packet_generated", "browser_interactions_verified", "validation_completed",
            "source_funnel_reconciled", "research_stop_decision_evaluated",
            "final_state_reconciled", "manifest_generated", "final_bundle_ready",
        ]:
            if step not in completed:
                completed.append(step)
        progress.update({
            "status": state["status"],
            "progress_percent": 100,
            "progress_basis": "Artifact-backed per-run completion: candidate funnel, gap-driven stop decision, canonical dataset, deterministic simulation, browser-verified HTML, quality/maturity/integrity scoring, final-state reconciliation, and manifest are present.",
            "source_count": state["source_count"],
            "discovered_candidate_count": state["discovered_candidate_count"],
            "eligible_evidence_count": state["eligible_evidence_count"],
            "open_gap_count": state["open_gap_count"],
            "blocker_gap_count": state["blocker_gap_count"],
            "blocked_steps": [],
            "completed_steps": completed,
        })
        write_json_atomic(progress_path, progress)
        write_text_atomic(root / "final_summary.md", f"""# Industry Intelligence run summary

- **Run ID:** `{current_report['run_id']}`
- **Status:** `{state['status']}`
- **Maturity:** {current_report['maturity_level']}
- **Overall score:** **{current_report['overall_score']} / 100**
- **Research Quality:** {current_report['research_quality_score']} / 100
- **Maturity score:** {current_report['maturity_score']} / 100
- **Operational Integrity:** {current_report['operational_integrity_score']} / 100
- **Active score caps:** {current_report['active_score_caps']}
- **Discovered source candidates:** {current_report['source_funnel']['discovered_candidate_count']}
- **Accepted sources:** {current_report['source_statistics']['accepted_source_count']}
- **Eligible atomic evidence:** {current_report['evidence_statistics']['eligible_evidence_count']}
- **Research stop approved:** {str(current_report['research_stop_decision'].get('approved', False)).lower()}
- **Average professional-lens depth:** {current_report['role_lens_scores']['average_quality_score']} / 100
- **Simulation maturity:** Level {_load(root / 'simulation_readiness.json', {}).get('simulation_maturity_level', 0)}
- **HTML packet:** generated and browser verified
- **Open gaps:** {current_report['gap_summary']['open_gap_count']}
- **Blocker gaps:** {current_report['gap_summary']['blocker_gap_count']}
- **Hard fails:** {len(current_report['hard_fail_list'])}
- **Valuation output:** disabled without live market provenance and human approval
- **Production claim:** {str(current_report['production_claim']).lower()}

This summary is synchronized with the Phase 10 quality, maturity, operational-integrity, stop-decision, and final-state controls. It is not an investment recommendation.
""")

        graph = _load(root / "artifact_graph.json", {})
        validation_entries = graph.get("validation")
        if not isinstance(validation_entries, list):
            validation_entries = []
        by_artifact = {str(item.get("artifact")): item for item in validation_entries if isinstance(item, dict)}
        for artifact in ("validation_report.json", "validation_report.md", "final_state_reconciliation.json"):
            item = by_artifact.get(artifact) or {"artifact": artifact, "required": True}
            item.update({
                "status": "passed" if current_report["hard_fail_status"] == "none" else "failed",
                "score": current_report["overall_score"],
                "maturity": current_report["maturity_level"],
                "hard_fail_status": current_report["hard_fail_status"],
            })
            by_artifact[artifact] = item
        graph["validation"] = [by_artifact[key] for key in sorted(by_artifact)]
        graph.setdefault("packet", {})["blocked_by"] = [] if current_report["production_claim"] else ["remaining_quality_or_benchmark_gates"]
        write_json_atomic(root / "artifact_graph.json", graph)

    sync_state(report)
    generate_html_packet(root)
    verify_html_packet(root, browser=browser, require_browser=bool(browser))
    _write_final_state_reconciliation(root, report)

    # Final report observes the completed reconciliation gate.
    report = validate_run(root)
    sync_state(report)
    write_json_atomic(root / "validation_report.json", report)
    write_text_atomic(root / "validation_report.md", _report_markdown(report))
    generate_html_packet(root)
    verify_html_packet(root, browser=browser, require_browser=bool(browser))
    _write_final_state_reconciliation(root, report)

    # Confirm reconciliation after final packet/state regeneration. Score should be stable.
    confirmed = validate_run(root)
    report = confirmed
    write_json_atomic(root / "validation_report.json", report)
    write_text_atomic(root / "validation_report.md", _report_markdown(report))

    write_json_atomic(root / "failure_fingerprints.json", {
        "schema_version": "phase10-stage0-fingerprints-v1",
        "generated_at": _now(),
        "run_id": report["run_id"],
        "fingerprints": report["failure_fingerprints"],
        "hard_fail_list": report["hard_fail_list"],
    })
    write_text_atomic(root / "failure_fingerprints.md", "# Failure Fingerprints\n\n" + ("\n".join(f"- `{x}`" for x in report["failure_fingerprints"]) or "- None.\n"))
    write_text_atomic(root / "improvement_backlog.md", "# Improvement Backlog\n\n" + ("\n".join(f"- **{x['priority']}** {x['action']}" for x in report["next_actions"]) or "- No active actions.\n"))

    manifest = _manifest(root, report, artifact_state)
    write_json_atomic(root / "manifest.json", manifest)
    return {
        "status": _load(root / "run_state.json", {}).get("status"),
        "run_id": report["run_id"],
        "industry_id": report["industry_id"],
        "overall_score": report["overall_score"],
        "research_quality_score": report["research_quality_score"],
        "maturity_score": report["maturity_score"],
        "operational_integrity_score": report["operational_integrity_score"],
        "score_label": report["score_label"],
        "maturity": report["maturity_level"],
        "hard_fail_status": report["hard_fail_status"],
        "disposition": report["disposition"],
        "source_count": report["source_statistics"]["accepted_source_count"],
        "candidate_count": report["source_funnel"]["discovered_candidate_count"],
        "evidence_count": report["evidence_statistics"]["eligible_evidence_count"],
        "open_gap_count": report["gap_summary"]["open_gap_count"],
        "blocker_gap_count": report["gap_summary"]["blocker_gap_count"],
        "research_stop_approved": report["research_stop_decision"].get("approved", False),
        "production_claim": report["production_claim"],
        "manifest_file_count": len(manifest["file_inventory"]),
    }
