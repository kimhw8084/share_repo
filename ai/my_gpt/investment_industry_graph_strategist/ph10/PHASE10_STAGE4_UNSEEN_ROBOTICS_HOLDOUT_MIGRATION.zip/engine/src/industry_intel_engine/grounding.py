from __future__ import annotations

import hashlib
import re
from collections import Counter
from typing import Any
from urllib.parse import urlsplit

GROUNDING_SCHEMA_VERSION = "phase10-stage3-grounding-v1"

_NATIVE_CAPTURE_TYPES = {
    "source_native_html",
    "source_native_pdf_text",
    "source_native_text",
    "source_native_api_response",
    "source_native_document",
}

_GENERATED_PATTERNS = (
    re.compile(r"provider[- ]normalized", re.I),
    re.compile(r"authoritative evidence supports", re.I),
    re.compile(r"generated summary", re.I),
    re.compile(r"model[- ]generated", re.I),
    re.compile(r"assistant summary", re.I),
    re.compile(r"output[- ]derived", re.I),
    re.compile(r"synthetic evidence", re.I),
    re.compile(r"fixture[- ]only evidence", re.I),
)

_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "been", "by", "for", "from",
    "has", "have", "in", "into", "is", "it", "its", "of", "on", "or", "that",
    "the", "their", "this", "to", "was", "were", "will", "with", "would", "could",
    "should", "may", "can", "more", "less", "than", "about", "approximately",
}


def normalize_text(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def contains_generated_language(value: str) -> bool:
    text = normalize_text(value)
    return any(pattern.search(text) for pattern in _GENERATED_PATTERNS)


def _same_origin(left: str, right: str) -> bool:
    try:
        a, b = urlsplit(left), urlsplit(right)
        return bool(a.hostname and b.hostname and a.hostname.lower() == b.hostname.lower())
    except Exception:
        return False


def build_capture_contract(
    *,
    canonical_url: str,
    final_url: str,
    capture_type: str,
    acquisition_method: str,
    collector: str,
    source_native_attested: bool,
    transformed: bool,
    content_text: str,
) -> dict[str, Any]:
    capture_type = str(capture_type or "").strip()
    acquisition_method = str(acquisition_method or "").strip()
    collector = str(collector or "").strip()
    reasons: list[str] = []
    if capture_type not in _NATIVE_CAPTURE_TYPES:
        reasons.append("capture_type_not_source_native")
    if not acquisition_method:
        reasons.append("acquisition_method_missing")
    if not collector:
        reasons.append("collector_missing")
    if not source_native_attested:
        reasons.append("source_native_attestation_missing")
    if transformed:
        reasons.append("transformed_capture_prohibited")
    if not _same_origin(canonical_url, final_url):
        reasons.append("capture_origin_mismatch")
    if contains_generated_language(content_text):
        reasons.append("generated_or_output_derived_capture")
    return {
        "schema_version": GROUNDING_SCHEMA_VERSION,
        "capture_type": capture_type,
        "acquisition_method": acquisition_method,
        "collector": collector,
        "source_native_attested": bool(source_native_attested),
        "transformed": bool(transformed),
        "canonical_url": canonical_url,
        "final_url": final_url,
        "origin_match": _same_origin(canonical_url, final_url),
        "generated_language_detected": contains_generated_language(content_text),
        "eligible_for_source_quotation": not reasons,
        "failure_reasons": reasons,
    }


def verify_capture_contract(source_row: dict[str, Any]) -> tuple[bool, list[str]]:
    snapshot = source_row.get("snapshot") or {}
    contract = snapshot.get("capture_contract") or source_row.get("capture_contract") or {}
    reasons = list(contract.get("failure_reasons") or [])
    if contract.get("schema_version") != GROUNDING_SCHEMA_VERSION:
        reasons.append("capture_contract_missing_or_legacy")
    if contract.get("eligible_for_source_quotation") is not True:
        reasons.append("capture_not_eligible_for_source_quotation")
    if source_row.get("source_native_review", {}).get("approved") is not True:
        reasons.append("source_native_review_not_approved")
    return not reasons, sorted(set(reasons))


def locate_exact_span(document_text: str, quote: str, proposed_span: dict[str, Any] | None = None) -> tuple[dict[str, Any] | None, list[str]]:
    reasons: list[str] = []
    quote = normalize_text(quote)
    if not quote:
        return None, ["quote_empty"]
    if contains_generated_language(quote):
        return None, ["generated_or_output_derived_quote"]

    if proposed_span:
        try:
            start = int(proposed_span.get("start_char"))
            end = int(proposed_span.get("end_char"))
        except (TypeError, ValueError):
            return None, ["invalid_source_span"]
        if start < 0 or end <= start or end > len(document_text):
            return None, ["source_span_out_of_bounds"]
        raw_span = document_text[start:end]
        if normalize_text(raw_span) != quote:
            return None, ["source_span_quote_mismatch"]
    else:
        # Exact raw-text matching is intentionally required. Normalized provider summaries
        # cannot create a verifiable native span against the original document.
        starts = [m.start() for m in re.finditer(re.escape(quote), document_text)]
        if not starts:
            return None, ["quote_not_found_in_source_native_capture"]
        if len(starts) > 1:
            return None, ["quote_span_ambiguous"]
        start = starts[0]
        end = start + len(quote)
        raw_span = document_text[start:end]

    return {
        "schema_version": GROUNDING_SCHEMA_VERSION,
        "start_char": start,
        "end_char": end,
        "raw_text_sha256": hashlib.sha256(raw_span.encode("utf-8")).hexdigest(),
        "normalized_quote_sha256": hashlib.sha256(quote.encode("utf-8")).hexdigest(),
    }, reasons


def _tokens(value: str) -> list[str]:
    words = re.findall(r"[a-z0-9][a-z0-9%.$/_-]*", value.lower())
    return [word for word in words if word not in _STOPWORDS and len(word) > 1]


def semantic_support(claim: str, quote: str) -> dict[str, Any]:
    claim_tokens = _tokens(claim)
    quote_tokens = _tokens(quote)
    claim_set, quote_set = set(claim_tokens), set(quote_tokens)
    overlap = claim_set & quote_set
    recall = len(overlap) / max(1, len(claim_set))
    precision = len(overlap) / max(1, len(quote_set))
    score = (2 * precision * recall / (precision + recall)) if precision + recall else 0.0
    claim_numbers = set(re.findall(r"\b\d+(?:\.\d+)?%?\b", claim))
    quote_numbers = set(re.findall(r"\b\d+(?:\.\d+)?%?\b", quote))
    missing_numbers = sorted(claim_numbers - quote_numbers)
    # Named-token proxy: capitalized multi-character tokens and all-caps tickers/acronyms.
    named = {
        token.lower() for token in re.findall(r"\b(?:[A-Z][A-Za-z0-9&.-]{2,}|[A-Z]{2,})\b", claim)
        if token.lower() not in _STOPWORDS
    }
    missing_named = sorted(named - quote_set)
    return {
        "schema_version": GROUNDING_SCHEMA_VERSION,
        "semantic_score": round(score, 4),
        "claim_token_recall": round(recall, 4),
        "quote_token_precision": round(precision, 4),
        "overlap_tokens": sorted(overlap),
        "missing_numeric_tokens": missing_numbers,
        "missing_named_tokens": missing_named,
    }


def minimum_support_threshold(table: str) -> float:
    if table in {"event_catalysts", "financial_sensitivity", "opportunity_zones", "risks_falsifiers"}:
        return 0.28
    if table in {"company_universe", "company_segment_exposure", "security_master"}:
        return 0.24
    return 0.18


def evidence_set_overlap(rows: list[dict[str, Any]], *, identity_fields: tuple[str, ...]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for i, left in enumerate(rows):
        left_ids = set(map(str, left.get("evidence_ids") or []))
        if not left_ids:
            continue
        left_identity = "|".join(str(left.get(field) or "") for field in identity_fields)
        for right in rows[i + 1 :]:
            right_ids = set(map(str, right.get("evidence_ids") or []))
            if not right_ids:
                continue
            right_identity = "|".join(str(right.get(field) or "") for field in identity_fields)
            if left_identity == right_identity:
                continue
            union = left_ids | right_ids
            jaccard = len(left_ids & right_ids) / max(1, len(union))
            if jaccard >= 0.80:
                findings.append({
                    "left_id": left_identity,
                    "right_id": right_identity,
                    "overlap_ratio": round(jaccard, 4),
                    "shared_evidence_ids": sorted(left_ids & right_ids),
                })
    return findings


def source_native_grounding_stats(source_rows: list[dict[str, Any]], evidence_rows: list[dict[str, Any]]) -> dict[str, Any]:
    source_map = {str(row.get("source_id")): row for row in source_rows if row.get("source_id")}
    eligible_sources = 0
    for row in source_rows:
        ok, _ = verify_capture_contract(row)
        if ok:
            eligible_sources += 1
    grounded = 0
    generated = 0
    weak_semantic = 0
    for row in evidence_rows:
        source = source_map.get(str(row.get("source_id")))
        ok, _ = verify_capture_contract(source or {})
        span = row.get("source_span") or {}
        semantic = row.get("semantic_support") or {}
        if contains_generated_language(str(row.get("exact_quote_short") or row.get("quote") or "")):
            generated += 1
        if float(semantic.get("semantic_score", 0) or 0) < minimum_support_threshold(str(row.get("linked_table") or "")):
            weak_semantic += 1
        if ok and span.get("raw_text_sha256") and semantic.get("semantic_score") is not None:
            grounded += 1
    return {
        "schema_version": GROUNDING_SCHEMA_VERSION,
        "source_count": len(source_rows),
        "source_native_eligible_count": eligible_sources,
        "source_native_eligible_ratio": round(eligible_sources / max(1, len(source_rows)), 4),
        "evidence_count": len(evidence_rows),
        "source_span_grounded_count": grounded,
        "source_span_grounded_ratio": round(grounded / max(1, len(evidence_rows)), 4),
        "generated_quote_count": generated,
        "weak_semantic_support_count": weak_semantic,
    }
