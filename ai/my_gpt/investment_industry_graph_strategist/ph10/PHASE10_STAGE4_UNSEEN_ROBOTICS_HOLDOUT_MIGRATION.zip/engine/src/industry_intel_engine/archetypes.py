from __future__ import annotations

from .models import ArchetypeResolution


_RULES: list[tuple[str, set[str]]] = [
    ("financial_network", {"payment", "payments", "bank", "insurance", "fintech", "exchange", "clearing"}),
    ("software_platform", {"software", "saas", "platform", "cloud", "cybersecurity", "data"}),
    ("healthcare_regulated", {"healthcare", "medical", "medtech", "pharma", "biotech", "hospital"}),
    ("energy_commodity", {"energy", "oil", "gas", "battery", "lithium", "mining", "commodity", "power"}),
    ("industrial_manufacturing", {"manufacturing", "equipment", "machinery", "hvac", "semiconductor", "automation"}),
    ("infrastructure_asset", {"infrastructure", "utility", "grid", "data center", "telecom", "tower", "real estate"}),
    ("consumer_service", {"consumer", "retail", "restaurant", "travel", "service", "education"}),
    ("transport_logistics", {"transport", "logistics", "shipping", "airline", "rail", "freight"}),
    ("media_advertising", {"media", "advertising", "streaming", "publishing", "gaming"}),
]


def classify_archetype(industry_name: str) -> ArchetypeResolution:
    text = industry_name.lower()
    matches: list[tuple[str, list[str]]] = []
    for archetype, keywords in _RULES:
        hit = sorted(k for k in keywords if k in text)
        if hit:
            matches.append((archetype, hit))
    if not matches:
        matches = [("cross_sector_other", [])]
    primary = matches[0][0]
    secondary = [item[0] for item in matches[1:]]
    hit_words = sorted({word for _, words in matches for word in words})
    regulated = primary in {"financial_network", "healthcare_regulated", "energy_commodity", "infrastructure_asset"}
    commodity = primary == "energy_commodity" or "battery" in text or "materials" in text
    software = primary == "software_platform" or "platform" in text or "saas" in text
    complexity = "high" if regulated or len(matches) > 1 or commodity else "medium"
    return ArchetypeResolution(
        primary_archetype=primary,
        secondary_archetypes=secondary,
        complexity=complexity,
        regulated=regulated,
        commodity_exposure=commodity,
        software_platform=software,
        public_company_exposure_expected=True,
        private_market_stress_expected=software or "service" in text or "healthcare" in text,
        live_quant_stress_expected=primary in {"financial_network", "energy_commodity"},
        matched_keywords=hit_words,
    )
