from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from .atomic import write_json_atomic
from .ids import stable_id
from .providers.base import SourceCandidate
from .safety import validate_workspace_path

_PLACEHOLDER_HOSTS = {
    "example.com", "example.org", "example.net", "localhost", "127.0.0.1", "0.0.0.0",
}
_TRACKING_KEYS = {"fbclid", "gclid", "mc_cid", "mc_eid", "ref", "ref_src"}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalize_url(raw: str) -> str:
    value = raw.strip()
    parts = urlsplit(value)
    if parts.scheme.lower() not in {"http", "https"}:
        raise ValueError("source URL must use http or https")
    host = (parts.hostname or "").lower().rstrip(".")
    if not host:
        raise ValueError("source URL is missing a host")
    port = parts.port
    netloc = host
    if port and not ((parts.scheme.lower() == "http" and port == 80) or (parts.scheme.lower() == "https" and port == 443)):
        netloc = f"{host}:{port}"
    path = re.sub(r"/{2,}", "/", parts.path or "/")
    if path != "/":
        path = path.rstrip("/")
    query_pairs = []
    for key, val in parse_qsl(parts.query, keep_blank_values=True):
        lower = key.lower()
        if lower.startswith("utm_") or lower in _TRACKING_KEYS:
            continue
        query_pairs.append((key, val))
    query_pairs.sort()
    return urlunsplit((parts.scheme.lower(), netloc, path, urlencode(query_pairs, doseq=True), ""))


def _load_json(path: Path) -> object:
    if path.is_symlink():
        raise ValueError(f"symlink input is prohibited: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def _validate_provider_config(payload: object) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("provider configuration must be a JSON object")
    if payload.get("terms_accepted") is not True:
        raise ValueError("provider terms must be explicitly accepted")
    provider_id = str(payload.get("provider_id", "")).strip()
    if not provider_id:
        raise ValueError("provider_id is required")
    if payload.get("credential") or payload.get("api_key") or payload.get("token"):
        raise ValueError("raw credentials must not be stored in provider configuration")
    credential_ref = payload.get("credential_ref")
    if credential_ref is not None and not str(credential_ref).startswith(("env:", "secret:")):
        raise ValueError("credential_ref must use env: or secret: indirection")
    return payload


def _candidate_from_dict(row: object) -> SourceCandidate:
    if not isinstance(row, dict):
        raise ValueError("each result must be a JSON object")
    return SourceCandidate(
        url=str(row.get("url", "")),
        title=str(row.get("title", "")),
        publisher=str(row.get("publisher", "")),
        publication_date=row.get("publication_date"),
        snippet=row.get("snippet"),
        source_family=row.get("source_family"),
        provider_result_id=row.get("provider_result_id"),
        metadata=row.get("metadata") if isinstance(row.get("metadata"), dict) else {},
    )


def import_search_results(workspace: str | Path, results_file: str | Path, provider_config_file: str | Path) -> dict:
    root = validate_workspace_path(workspace)
    if not (root / "run_state.json").exists():
        raise ValueError("workspace is not an initialized engine run")
    provider = _validate_provider_config(_load_json(Path(provider_config_file)))
    payload = _load_json(Path(results_file))
    if not isinstance(payload, dict):
        raise ValueError("search result import must be a JSON object")
    query = str(payload.get("query", "")).strip()
    if not query:
        raise ValueError("search result import requires query")
    rows = payload.get("results")
    if not isinstance(rows, list):
        raise ValueError("search result import requires a results array")

    ledger_path = root / "source_ledger.json"
    candidate_path = root / "source_candidate_ledger.json"
    rejected_path = root / "rejected_sources.json"
    log_path = root / "search_log.json"
    ledger = _load_json(ledger_path)
    candidates = _load_json(candidate_path) if candidate_path.exists() else []
    rejected = _load_json(rejected_path)
    logs = _load_json(log_path)
    if not all(isinstance(x, list) for x in (ledger, candidates, rejected, logs)):
        raise ValueError("run ledgers are malformed")
    existing_urls = {
        str(row.get("canonical_url") or row.get("source_url") or row.get("url"))
        for row in ledger if isinstance(row, dict) and (row.get("canonical_url") or row.get("source_url") or row.get("url"))
    }
    batch_seen: set[str] = set()
    accepted_count = 0
    rejected_count = 0
    duplicate_count = 0
    imported_at = utc_now()
    search_id = stable_id("search", provider["provider_id"], query, imported_at, length=20)

    for index, raw in enumerate(rows):
        candidate = _candidate_from_dict(raw)
        reasons: list[str] = []
        canonical_url = ""
        try:
            canonical_url = normalize_url(candidate.url)
            host = (urlsplit(canonical_url).hostname or "").lower()
            if host in _PLACEHOLDER_HOSTS or host.endswith(".example.com"):
                reasons.append("placeholder_or_local_host")
        except Exception as exc:
            reasons.append(f"invalid_url:{exc}")
        if not candidate.title.strip():
            reasons.append("missing_title")
        if not candidate.publisher.strip():
            reasons.append("missing_publisher")
        duplicate = bool(canonical_url and (canonical_url in existing_urls or canonical_url in batch_seen))
        if duplicate:
            reasons.append("duplicate_canonical_url")
            duplicate_count += 1
        candidate_id = stable_id("cand", provider["provider_id"], query, str(index), candidate.url, length=24)
        candidate_row = {
            "candidate_id": candidate_id,
            "search_id": search_id,
            "provider_id": provider["provider_id"],
            "provider_result_id": candidate.provider_result_id,
            "provider_rank": index + 1,
            "query": query,
            "source_family": candidate.source_family or payload.get("source_family") or "unclassified",
            "url": candidate.url,
            "canonical_url": canonical_url or None,
            "title": candidate.title,
            "publisher": candidate.publisher,
            "publication_date": candidate.publication_date,
            "snippet_present": bool(candidate.snippet),
            "discovered_at": imported_at,
            "access_status": "not_fetched",
            "dedupe_status": "duplicate" if duplicate else "unique",
            "candidate_status": "rejected_pre_snapshot" if reasons else "accepted_pending_snapshot",
            "decision_reasons": sorted(set(reasons)),
            "source_id": None,
            "metadata": candidate.metadata,
        }
        if reasons:
            rejection_id = stable_id("rej", query, str(index), candidate.url)
            candidate_row["rejection_id"] = rejection_id
            rejected.append({
                "rejection_id": rejection_id,
                "candidate_id": candidate_id,
                "search_id": search_id,
                "provider_id": provider["provider_id"],
                "provider_rank": index + 1,
                "query": query,
                "url": candidate.url,
                "canonical_url": canonical_url or None,
                "title": candidate.title,
                "publisher": candidate.publisher,
                "reasons": sorted(set(reasons)),
                "rejected_at": imported_at,
            })
            candidates.append(candidate_row)
            rejected_count += 1
            continue
        batch_seen.add(canonical_url)
        existing_urls.add(canonical_url)
        source_id = stable_id("src", canonical_url, length=20)
        candidate_row["source_id"] = source_id
        candidates.append(candidate_row)
        ledger.append({
            "source_id": source_id,
            "candidate_id": candidate_id,
            "search_id": search_id,
            "provider_rank": index + 1,
            "status": "candidate_accepted_pending_snapshot",
            "provider_id": provider["provider_id"],
            "provider_result_id": candidate.provider_result_id,
            "query": query,
            "source_family": candidate.source_family or payload.get("source_family") or "unclassified",
            "url": candidate.url,
            "canonical_url": canonical_url,
            "title": candidate.title.strip(),
            "publisher": candidate.publisher.strip(),
            "publication_date": candidate.publication_date,
            "snippet": candidate.snippet,
            "discovered_at": imported_at,
            "freshness": {
                "publication_date": candidate.publication_date,
                "discovered_at": imported_at,
                "stale_status": "unknown_pending_snapshot",
            },
            "snapshot": None,
            "eligible_for_evidence": False,
            "metadata": candidate.metadata,
        })
        accepted_count += 1

    logs.append({
        "search_id": search_id,
        "provider_id": provider["provider_id"],
        "query": query,
        "source_family": payload.get("source_family"),
        "executed_at": payload.get("executed_at") or imported_at,
        "imported_at": imported_at,
        "result_count": len(rows),
        "canonicalized_count": sum(1 for row in candidates if row.get("search_id") == search_id and row.get("canonical_url")),
        "accepted_count": accepted_count,
        "rejected_count": rejected_count,
        "duplicate_count": duplicate_count,
        "terms_accepted": True,
        "credential_ref_present": bool(provider.get("credential_ref")),
        "results_sha256": hashlib.sha256(Path(results_file).read_bytes()).hexdigest(),
    })
    write_json_atomic(ledger_path, ledger)
    write_json_atomic(candidate_path, candidates)
    write_json_atomic(rejected_path, rejected)
    write_json_atomic(log_path, logs)

    state_path = root / "run_state.json"
    state = _load_json(state_path)
    state["source_count"] = len(ledger)
    state["discovered_candidate_count"] = len(candidates)
    state["rejected_candidate_count"] = len(rejected)
    state["status"] = "sources_discovered_pending_snapshots" if ledger else "blocked_source_collection"
    state["updated_at"] = imported_at
    write_json_atomic(state_path, state)
    return {
        "status": state["status"],
        "search_id": search_id,
        "accepted_count": accepted_count,
        "rejected_count": rejected_count,
        "duplicate_count": duplicate_count,
        "total_candidate_count": len(candidates),
        "total_source_count": len(ledger),
        "eligible_evidence_count": 0,
    }
