from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from .atomic import write_json_atomic
from .safety import validate_workspace_path


def _load(path: Path) -> Any:
    if path.is_symlink():
        raise ValueError(f"symlink input is prohibited: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def _domain(url: str) -> str:
    host = (urlsplit(url).hostname or "").lower()
    return host[4:] if host.startswith("www.") else host


def evaluate_authoritative_recall(workspace: str | Path, registry_file: str | Path) -> dict[str, Any]:
    root = validate_workspace_path(workspace)
    registry = _load(Path(registry_file))
    if not isinstance(registry, dict) or not isinstance(registry.get("domains"), list):
        raise ValueError("authoritative registry must contain a domains array")
    target_rows = [row if isinstance(row, dict) else {"domain": str(row)} for row in registry["domains"]]
    targets = {str(row.get("domain") or "").lower().removeprefix("www.") for row in target_rows if row.get("domain")}
    if not targets:
        raise ValueError("authoritative registry contains no domains")
    source_rows = _load(root / "source_ledger.json")
    observed = {
        _domain(str(row.get("canonical_url") or row.get("url") or ""))
        for row in source_rows if isinstance(row, dict)
    }
    recalled = sorted(domain for domain in targets if domain in observed or any(host.endswith("." + domain) for host in observed))
    missed = sorted(targets - set(recalled))
    recall = round(100 * len(recalled) / len(targets), 2)
    result = {
        "schema_version": "phase10-stage3-authoritative-recall-v1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "registry_id": registry.get("registry_id"),
        "industry": registry.get("industry"),
        "target_domain_count": len(targets),
        "recalled_domain_count": len(recalled),
        "recall_percent": recall,
        "minimum_required_percent": float(registry.get("minimum_required_percent", 85) or 85),
        "passed": recall >= float(registry.get("minimum_required_percent", 85) or 85),
        "recalled_domains": recalled,
        "missed_domains": missed,
        "observed_domains": sorted(observed),
    }
    write_json_atomic(root / "authoritative_source_recall.json", result)
    return result
