from __future__ import annotations

import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .atomic import write_json_atomic
from .data_contract import ROLE_LENSES, TABLE_SPECS
from .safety import validate_workspace_path

STOP_SCHEMA_VERSION = "phase10-stage3-stop-v1"
QUALITY_SCHEMA_VERSION = "phase10-stage3-quality-v1"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    if path.is_symlink():
        raise ValueError(f"symlink input is prohibited: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def continuous_saturation(count: int, *, half_saturation: float = 90.0) -> float:
    """Smooth evidence/source sufficiency curve with no maturity cliff."""
    if count <= 0:
        return 0.0
    # count=half_saturation -> 0.5 and asymptotically approaches 1.
    return _clamp(count / (count + half_saturation))


def source_funnel(root: str | Path) -> dict[str, Any]:
    base = validate_workspace_path(root)
    candidates = _load(base / "source_candidate_ledger.json", [])
    sources = _load(base / "source_ledger.json", [])
    rejected = _load(base / "rejected_sources.json", [])
    evidence = _load(base / "atomic_evidence.json", [])
    searches = _load(base / "search_log.json", [])
    candidates = [row for row in candidates if isinstance(row, dict)]
    sources = [row for row in sources if isinstance(row, dict)]
    rejected = [row for row in rejected if isinstance(row, dict)]
    evidence = [row for row in evidence if isinstance(row, dict)]
    statuses: dict[str, int] = {}
    for row in candidates:
        key = str(row.get("candidate_status") or row.get("status") or "unknown")
        statuses[key] = statuses.get(key, 0) + 1
    accepted_ids = {
        str(row.get("source_id")) for row in sources
        if row.get("source_id") and (
            row.get("status") in {"accepted_for_evidence_extraction", "accepted"}
            or bool(row.get("source_quality_tier") and row.get("source_hash"))
        )
    }
    snapshotted_ids = {
        str(row.get("source_id")) for row in sources
        if row.get("source_id") and isinstance(row.get("snapshot"), dict) and row.get("snapshot")
    }
    evidence_source_ids = {
        str(row.get("source_id")) for row in evidence
        if row.get("source_id") and (row.get("eligible") is True or row.get("exact_quote_short"))
    }
    discovered = len(candidates)
    deduped = sum(1 for row in candidates if row.get("dedupe_status") == "duplicate")
    invalid = sum(1 for row in candidates if row.get("candidate_status") == "rejected_pre_snapshot")
    accepted_candidates = sum(1 for row in candidates if row.get("candidate_status") in {"accepted_pending_snapshot", "snapshotted", "accepted_for_evidence"})
    return {
        "schema_version": QUALITY_SCHEMA_VERSION,
        "generated_at": _now(),
        "search_execution_count": len(searches) if isinstance(searches, list) else 0,
        "discovered_candidate_count": discovered,
        "canonicalized_candidate_count": sum(1 for row in candidates if row.get("canonical_url")),
        "duplicate_candidate_count": deduped,
        "pre_snapshot_rejected_count": invalid,
        "review_rejected_count": sum(1 for row in rejected if "rejected_after_snapshot_review" in (row.get("reasons") or [])),
        "accepted_candidate_count": accepted_candidates,
        "snapshotted_source_count": len(snapshotted_ids),
        "review_accepted_source_count": len(accepted_ids),
        "evidence_eligible_source_count": len(evidence_source_ids & accepted_ids),
        "eligible_evidence_count": sum(1 for row in evidence if row.get("eligible") is True or row.get("exact_quote_short")),
        "candidate_status_distribution": statuses,
        "acceptance_precision": round(len(accepted_ids) / max(1, discovered - deduped), 4),
        "rejection_observability_passed": discovered == 0 or bool(rejected) or invalid > 0 or deduped > 0,
    }


def _row_actionability(lens: str, table: str, row: dict[str, Any]) -> float:
    keys = set(row)
    nonblank = {k for k, v in row.items() if v not in (None, "", [], {})}
    if lens == "long_short_equity_pm":
        desired = {"investment_implication", "upside_logic", "downside_logic", "catalyst_ids", "falsifier_ids", "linked_securities", "impact_magnitude"}
    elif lens == "fundamental_equity_analyst":
        desired = {"driver_name", "sensitivity_direction", "cost_category", "materiality", "relative_attractiveness", "company_id"}
    elif lens == "quantamental_data_lead":
        desired = {"signal_definition", "frequency", "history_available", "backtest_status", "source_id", "formula_id"}
    elif lens == "event_driven_pm":
        desired = {"event_name", "event_type", "event_date", "timing", "impact_magnitude", "affected_companies", "falsifier_ids"}
    else:
        desired = {"ownership_type", "profit_pool_description", "barriers_to_entry", "market_structure", "strategic_buyers", "exit_pathways", "materiality"}
    present = len(desired & nonblank)
    possible = len(desired & keys) or len(desired)
    return _clamp(present / max(1, possible))


def role_lens_quality(
    tables: dict[str, list[dict[str, Any]]],
    lineage_entries: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    evidence = [row for row in tables.get("atomic_evidence", []) if isinstance(row, dict)]
    evidence_map = {str(row.get("evidence_id")): row for row in evidence if row.get("evidence_id")}
    lineage_by_table: dict[str, set[str]] = {}
    for entry in lineage_entries:
        if not isinstance(entry, dict):
            continue
        table = str(entry.get("table") or "")
        for eid in entry.get("evidence_ids", []) if isinstance(entry.get("evidence_ids"), list) else []:
            lineage_by_table.setdefault(table, set()).add(str(eid))
        eid = entry.get("evidence_id")
        if eid:
            lineage_by_table.setdefault(table, set()).add(str(eid))
    out: list[dict[str, Any]] = []
    for lens, required_tables in ROLE_LENSES.items():
        populated = [t for t in required_tables if tables.get(t)]
        missing = [t for t in required_tables if not tables.get(t)]
        table_coverage = len(populated) / max(1, len(required_tables))
        lens_evidence_ids: set[str] = set()
        action_values: list[float] = []
        causal_rows = 0
        total_rows = 0
        for table in populated:
            lens_evidence_ids.update(lineage_by_table.get(table, set()))
            for row in tables.get(table, []):
                if not isinstance(row, dict):
                    continue
                total_rows += 1
                action_values.append(_row_actionability(lens, table, row))
                causal_keys = {
                    "direction", "sensitivity_direction", "formula_or_logic", "impact_magnitude",
                    "upside_logic", "downside_logic", "description", "payment_for", "edge_type",
                    "from_node_id", "to_node_id", "driver_type", "falsifier_ids", "catalyst_ids",
                }
                if len({k for k in causal_keys if row.get(k) not in (None, "", [], {})}) >= 2:
                    causal_rows += 1
        target_evidence = max(12, 4 * len(required_tables))
        evidence_density = _clamp(len(lens_evidence_ids) / target_evidence)
        lens_evidence = [evidence_map[eid] for eid in lens_evidence_ids if eid in evidence_map]
        currentness = (
            sum(1 for row in lens_evidence if row.get("freshness_status") == "current") / max(1, len(lens_evidence))
            if lens_evidence else 0.0
        )
        causal_depth = causal_rows / max(1, total_rows)
        actionability = sum(action_values) / max(1, len(action_values))
        quality_score = round(100 * (
            0.25 * table_coverage + 0.25 * evidence_density + 0.15 * currentness +
            0.15 * causal_depth + 0.20 * actionability
        ), 2)
        out.append({
            "lens_id": lens,
            "required_tables": list(required_tables),
            "populated_tables": populated,
            "missing_tables": missing,
            "coverage_percent": round(100 * table_coverage, 2),
            "quality_score": quality_score,
            "evidence_density_score": round(100 * evidence_density, 2),
            "currentness_score": round(100 * currentness, 2),
            "causal_chain_depth_score": round(100 * causal_depth, 2),
            "actionability_score": round(100 * actionability, 2),
            "evidence_row_count": len(lens_evidence_ids),
            "status": "strong" if quality_score >= 80 else ("usable" if quality_score >= 65 else ("partial" if quality_score >= 40 else "not_ready")),
            "gap_ids": [],
        })
    return out


def build_corroboration_graph(tables: dict[str, list[dict[str, Any]]]) -> dict[str, Any]:
    evidence = [row for row in tables.get("atomic_evidence", []) if isinstance(row, dict)]
    sources = {str(row.get("source_id")): row for row in tables.get("source_ledger", []) if isinstance(row, dict)}
    groups: dict[str, dict[str, Any]] = {}
    for row in evidence:
        claim = str(row.get("claim_text") or row.get("paraphrase") or "").lower()
        metric = f"{row.get('metric_name')}|{row.get('metric_value')}|{row.get('metric_period')}"
        normalized = " ".join(claim.split())[:240]
        key_raw = f"{row.get('linked_table')}|{row.get('linked_field')}|{metric}|{normalized}"
        key = hashlib.sha256(key_raw.encode("utf-8")).hexdigest()[:20]
        group = groups.setdefault(key, {
            "corroboration_id": f"corr_{key}",
            "linked_table": row.get("linked_table"),
            "linked_field": row.get("linked_field"),
            "claim_summary": row.get("claim_text") or row.get("paraphrase"),
            "evidence_ids": [], "source_ids": [], "publishers": [], "source_families": [],
        })
        eid = row.get("evidence_id")
        sid = str(row.get("source_id") or "")
        if eid and eid not in group["evidence_ids"]:
            group["evidence_ids"].append(eid)
        if sid and sid not in group["source_ids"]:
            group["source_ids"].append(sid)
        source = sources.get(sid, {})
        publisher = source.get("publisher")
        family = source.get("source_family") or source.get("source_type")
        if publisher and publisher not in group["publishers"]:
            group["publishers"].append(publisher)
        if family and family not in group["source_families"]:
            group["source_families"].append(family)
    rows = []
    for group in groups.values():
        group["independent_publisher_count"] = len(group["publishers"])
        group["independent_source_family_count"] = len(group["source_families"])
        group["corroboration_status"] = "independently_corroborated" if len(group["publishers"]) >= 2 else "single_publisher_support"
        rows.append(group)
    rows.sort(key=lambda row: row["corroboration_id"])
    return {
        "schema_version": QUALITY_SCHEMA_VERSION,
        "generated_at": _now(),
        "claim_group_count": len(rows),
        "independently_corroborated_count": sum(1 for row in rows if row["corroboration_status"] == "independently_corroborated"),
        "groups": rows,
    }


def record_stop_decision(workspace: str | Path, decision_file: str | Path) -> dict[str, Any]:
    root = validate_workspace_path(workspace)
    payload = _load(Path(decision_file), None)
    if not isinstance(payload, dict):
        raise ValueError("research stop decision must be a JSON object")
    decision = str(payload.get("decision") or "").strip()
    if decision not in {"stop_approved", "continue_research"}:
        raise ValueError("decision must be stop_approved or continue_research")
    reviewer = str(payload.get("reviewer") or "").strip()
    reviewer_role = str(payload.get("reviewer_role") or "").strip()
    rationale = str(payload.get("rationale") or "").strip()
    if not reviewer or not reviewer_role or len(rationale) < 20:
        raise ValueError("reviewer, reviewer_role and substantive rationale are required")
    marginal = payload.get("marginal_yield")
    if not isinstance(marginal, dict):
        raise ValueError("marginal_yield object is required")
    required_marginal = {"queries_reviewed", "new_accepted_sources", "new_evidence_rows", "material_gaps_closed", "new_source_families"}
    if not required_marginal.issubset(marginal):
        raise ValueError("marginal_yield is missing required fields")
    family_status = payload.get("mandatory_family_status")
    if not isinstance(family_status, list) or not family_status:
        raise ValueError("mandatory_family_status must be a non-empty array")
    incomplete = [row for row in family_status if not isinstance(row, dict) or row.get("mandatory") is True and row.get("status") not in {"saturated", "covered", "explicit_gap"}]
    unresolved = payload.get("unresolved_material_gap_ids", [])
    if not isinstance(unresolved, list):
        raise ValueError("unresolved_material_gap_ids must be an array")
    low_yield = (
        int(marginal.get("new_accepted_sources", 0) or 0) <= 1 and
        int(marginal.get("new_evidence_rows", 0) or 0) <= 8 and
        int(marginal.get("new_source_families", 0) or 0) == 0
    )
    freshness_sweep = payload.get("freshness_sweep")
    if not isinstance(freshness_sweep, dict):
        raise ValueError("freshness_sweep object is required")
    freshness_ok = (
        freshness_sweep.get("completed") is True
        and int(freshness_sweep.get("queries_reviewed", 0) or 0) >= 3
        and bool(freshness_sweep.get("latest_report_cutoff_date"))
    )
    geography = payload.get("geography_language_coverage")
    if not isinstance(geography, list) or not geography:
        raise ValueError("geography_language_coverage must be a non-empty array")
    geography_incomplete = [
        row for row in geography
        if not isinstance(row, dict) or row.get("material") is True and row.get("status") not in {"covered", "explicit_gap"}
    ]
    recall = _load(root / "authoritative_source_recall.json", {})
    run_request = _load(root / "run_request.json", {})
    industry_name = str(run_request.get("industry_name") or run_request.get("industry_name_input") or "").lower()
    recall_required = "solar" in industry_name or (root / "authoritative_source_recall.json").exists()
    recall_ok = not recall_required or recall.get("passed") is True and float(recall.get("recall_percent", 0) or 0) >= 85
    approved = decision == "stop_approved" and not incomplete and not unresolved and low_yield and freshness_ok and not geography_incomplete and recall_ok
    if decision == "stop_approved" and not approved:
        raise ValueError("stop_approved requires saturated mandatory families, no unresolved material gaps, low marginal yield, a current-report freshness sweep, geography/language coverage, and any configured authoritative-recall threshold")
    result = {
        "schema_version": STOP_SCHEMA_VERSION,
        "run_id": _load(root / "run_state.json", {}).get("run_id"),
        "industry_id": _load(root / "industry_dataset.json", {}).get("industry_id"),
        "decision": decision,
        "approved": approved,
        "reviewer": reviewer,
        "reviewer_role": reviewer_role,
        "decided_at": payload.get("decided_at") or _now(),
        "rationale": rationale,
        "marginal_yield": marginal,
        "mandatory_family_status": family_status,
        "source_family_saturation_percent": float(payload.get("source_family_saturation_percent", 0) or 0),
        "independent_corroboration_status": payload.get("independent_corroboration_status") or "not_assessed",
        "unresolved_material_gap_ids": unresolved,
        "freshness_sweep": freshness_sweep,
        "geography_language_coverage": geography,
        "authoritative_source_recall": recall if recall_required else {"status": "not_configured"},
        "candidate_funnel": source_funnel(root),
    }
    write_json_atomic(root / "research_stop_decision.json", result)
    return result
