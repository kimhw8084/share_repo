from __future__ import annotations

import hashlib
import json
import mimetypes
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .atomic import write_json_atomic
from .grounding import build_capture_contract
from .safety import validate_workspace_path


def _load_capture_metadata(path: str | Path | None) -> dict[str, Any]:
    if not path:
        return {}
    meta_path = Path(path)
    if meta_path.is_symlink() or not meta_path.is_file():
        raise ValueError("capture metadata must be a regular non-symlink JSON file")
    payload = json.loads(meta_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("capture metadata must be a JSON object")
    return payload


def import_content_snapshot(
    workspace: str | Path,
    *,
    source_id: str,
    content_file: str | Path,
    final_url: str | None = None,
    fetched_at: str | None = None,
    content_type: str | None = None,
    status_code: int = 200,
    capture_metadata_file: str | Path | None = None,
    capture_type: str = "source_native_document",
    acquisition_method: str = "direct_file_import",
    collector: str = "cli_import",
    source_native_attested: bool = False,
    transformed: bool = False,
) -> dict:
    root = validate_workspace_path(workspace)
    content_path = Path(content_file)
    if content_path.is_symlink() or not content_path.is_file():
        raise ValueError("snapshot content must be a regular non-symlink file")
    if status_code < 200 or status_code >= 400:
        raise ValueError("only successful snapshot status codes are accepted")
    data = content_path.read_bytes()
    if not data:
        raise ValueError("empty snapshots are prohibited")
    ledger_path = root / "source_ledger.json"
    ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
    matches = [row for row in ledger if isinstance(row, dict) and row.get("source_id") == source_id]
    if len(matches) != 1:
        raise ValueError("source_id must resolve to exactly one source ledger row")
    row = matches[0]
    fetched = fetched_at or datetime.now(timezone.utc).isoformat()
    snapshots = root / "snapshots"
    snapshots.mkdir(parents=True, exist_ok=True)
    suffix = content_path.suffix.lower() or ".bin"
    target = snapshots / f"{source_id}{suffix}"
    if target.is_symlink():
        raise ValueError("snapshot target must not be a symlink")
    target.write_bytes(data)
    digest = hashlib.sha256(data).hexdigest()
    resolved_final_url = final_url or row["canonical_url"]
    metadata = _load_capture_metadata(capture_metadata_file)
    capture_type = str(metadata.get("capture_type") or capture_type)
    acquisition_method = str(metadata.get("acquisition_method") or acquisition_method)
    collector = str(metadata.get("collector") or collector)
    source_native_attested = bool(metadata.get("source_native_attested", source_native_attested))
    transformed = bool(metadata.get("transformed", transformed))
    text = data.decode("utf-8", errors="replace")
    capture_contract = build_capture_contract(
        canonical_url=str(row.get("canonical_url") or row.get("url") or ""),
        final_url=resolved_final_url,
        capture_type=capture_type,
        acquisition_method=acquisition_method,
        collector=collector,
        source_native_attested=source_native_attested,
        transformed=transformed,
        content_text=text,
    )
    row["snapshot"] = {
        "relative_path": str(target.relative_to(root)),
        "sha256": digest,
        "byte_size": len(data),
        "content_type": content_type or mimetypes.guess_type(content_path.name)[0] or "application/octet-stream",
        "fetched_at": fetched,
        "final_url": resolved_final_url,
        "status_code": status_code,
        "capture_contract": capture_contract,
    }
    row["status"] = "snapshot_captured_pending_acceptance_review"
    row["freshness"]["snapshot_fetched_at"] = fetched
    row["freshness"]["stale_status"] = "review_required"
    row["eligible_for_evidence"] = False
    row["source_native_review"] = {"approved": False, "status": "pending"}
    write_json_atomic(ledger_path, ledger)
    candidate_path = root / "source_candidate_ledger.json"
    if candidate_path.exists():
        candidates = json.loads(candidate_path.read_text(encoding="utf-8"))
        for candidate in candidates:
            if isinstance(candidate, dict) and candidate.get("source_id") == source_id:
                candidate["candidate_status"] = "snapshotted"
                candidate["access_status"] = "fetched_success"
                candidate["snapshot_sha256"] = digest
                candidate["fetched_at"] = fetched
                candidate["capture_type"] = capture_type
                candidate["source_native_capture_eligible"] = capture_contract["eligible_for_source_quotation"]
        write_json_atomic(candidate_path, candidates)
    return {
        "status": row["status"],
        "source_id": source_id,
        "snapshot_sha256": digest,
        "byte_size": len(data),
        "capture_type": capture_type,
        "source_native_capture_eligible": capture_contract["eligible_for_source_quotation"],
        "capture_failure_reasons": capture_contract["failure_reasons"],
    }
