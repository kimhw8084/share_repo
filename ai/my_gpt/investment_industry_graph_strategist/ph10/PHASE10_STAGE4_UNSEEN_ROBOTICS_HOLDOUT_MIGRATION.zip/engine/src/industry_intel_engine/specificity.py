from __future__ import annotations

from typing import Any

from .grounding import evidence_set_overlap


def _nonblank(row: dict[str, Any], *fields: str) -> bool:
    return any(row.get(field) not in (None, "", [], {}) for field in fields)


def _evidence_text(evidence_map: dict[str, dict[str, Any]], evidence_ids: list[str]) -> str:
    return " ".join(
        str(evidence_map[eid].get("claim_text") or evidence_map[eid].get("paraphrase") or evidence_map[eid].get("exact_quote_short") or "")
        for eid in evidence_ids if eid in evidence_map
    ).lower()


def validate_analytical_specificity(tables: dict[str, list[dict[str, Any]]]) -> dict[str, Any]:
    evidence_map = {
        str(row.get("evidence_id")): row
        for row in tables.get("atomic_evidence", [])
        if isinstance(row, dict) and row.get("evidence_id")
    }
    companies = {
        str(row.get("company_id")): row
        for row in tables.get("company_universe", [])
        if isinstance(row, dict) and row.get("company_id")
    }
    securities = {
        str(row.get("security_id")): row
        for row in tables.get("security_master", [])
        if isinstance(row, dict) and row.get("security_id")
    }
    failures: list[dict[str, Any]] = []

    events = [row for row in tables.get("event_catalysts", []) if isinstance(row, dict)]
    for row in events:
        rid = str(row.get("event_id") or "unknown")
        if not _nonblank(row, "event_date", "timing", "expected_date", "date_range"):
            failures.append({"code": "event_timing_missing", "record_id": rid})
        if not _nonblank(row, "affected_companies", "affected_securities", "affected_nodes", "affected_segments"):
            failures.append({"code": "event_affected_entities_missing", "record_id": rid})
        if not _nonblank(row, "causal_chain", "impact_description", "mechanism", "description"):
            failures.append({"code": "event_causal_chain_missing", "record_id": rid})
        evidence_ids = list(map(str, row.get("evidence_ids") or []))
        text = _evidence_text(evidence_map, evidence_ids)
        event_name = str(row.get("event_name") or "").lower()
        significant = [token for token in event_name.replace("/", " ").split() if len(token) >= 4]
        if significant and not any(token in text for token in significant):
            failures.append({"code": "event_specific_evidence_missing", "record_id": rid, "event_name": row.get("event_name")})

    for finding in evidence_set_overlap(events, identity_fields=("event_id", "event_name")):
        failures.append({"code": "event_evidence_overlap_excessive", **finding})

    sensitivities = [row for row in tables.get("financial_sensitivity", []) if isinstance(row, dict)]
    for row in sensitivities:
        rid = str(row.get("financial_sensitivity_id") or "unknown")
        company_id = str(row.get("company_id") or "")
        security_id = str(row.get("security_id") or "")
        if not company_id:
            failures.append({"code": "financial_sensitivity_company_missing", "record_id": rid})
            continue
        if company_id not in companies:
            failures.append({"code": "financial_sensitivity_company_unresolved", "record_id": rid, "company_id": company_id})
        if security_id and security_id not in securities:
            failures.append({"code": "financial_sensitivity_security_unresolved", "record_id": rid, "security_id": security_id})
        if not _nonblank(row, "formula_or_logic", "causal_chain", "mechanism"):
            failures.append({"code": "financial_sensitivity_causal_bridge_missing", "record_id": rid})
        evidence_ids = list(map(str, row.get("evidence_ids") or []))
        text = _evidence_text(evidence_map, evidence_ids)
        company_name = str((companies.get(company_id) or {}).get("company_name") or "").lower()
        generic_company_tokens = {"solar", "energy", "power", "systems", "technologies", "technology", "company", "corporation", "corp", "inc", "limited", "ltd", "holdings", "group"}
        company_tokens = [token for token in company_name.replace("&", " ").split() if len(token) >= 4 and token not in generic_company_tokens]
        ticker = str((securities.get(security_id) or {}).get("ticker") or "").lower()
        if company_tokens and not any(token in text for token in company_tokens) and (not ticker or ticker not in text):
            failures.append({"code": "company_specific_sensitivity_evidence_missing", "record_id": rid, "company_id": company_id})

    for finding in evidence_set_overlap(sensitivities, identity_fields=("financial_sensitivity_id", "company_id", "driver_name")):
        failures.append({"code": "company_sensitivity_evidence_overlap_excessive", **finding})

    falsifiers = [
        row for row in tables.get("risks_falsifiers", [])
        if isinstance(row, dict) and str(row.get("record_type") or "").lower() == "falsifier"
    ]
    for row in falsifiers:
        rid = str(row.get("risk_falsifier_id") or "unknown")
        missing = [field for field in ("monitor_variable", "threshold_operator", "threshold_value") if row.get(field) in (None, "", [], {})]
        if missing:
            failures.append({"code": "falsifier_machine_threshold_missing", "record_id": rid, "missing_fields": missing})

    return {
        "schema_version": "phase10-stage3-specificity-v1",
        "event_count": len(events),
        "financial_sensitivity_count": len(sensitivities),
        "falsifier_count": len(falsifiers),
        "failure_count": len(failures),
        "passed": not failures,
        "failures": failures,
    }
