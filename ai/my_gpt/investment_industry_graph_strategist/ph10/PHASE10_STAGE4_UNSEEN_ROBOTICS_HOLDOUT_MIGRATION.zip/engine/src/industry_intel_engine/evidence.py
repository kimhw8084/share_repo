from __future__ import annotations

import hashlib
import json
import re
from datetime import date, datetime, timezone
from pathlib import Path

from .atomic import write_json_atomic
from .grounding import (
    contains_generated_language,
    locate_exact_span,
    minimum_support_threshold,
    semantic_support,
    verify_capture_contract,
)
from .ids import stable_id
from .safety import validate_workspace_path

_TIERS = {"tier_1_primary", "tier_2_authoritative", "tier_3_reputable_secondary", "tier_4_context_only"}
_CONFLICT = {"none", "corroborated", "conflicting", "superseded"}
_EVIDENCE_TYPES = {"direct_quote", "quantitative_fact", "policy_fact", "company_disclosure"}
_BOILERPLATE = re.compile(r"(cookie policy|privacy policy|terms of use|all rights reserved|subscribe to our newsletter|javascript is disabled)", re.I)
_METADATA_ONLY = re.compile(r"^(title|publisher|publication date|source url|captured at|fetched at)\s*[:=]", re.I)


def _load(path: Path):
    if path.is_symlink():
        raise ValueError(f"symlink input is prohibited: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _snapshot_bytes(root: Path, row: dict) -> bytes:
    snap = row.get("snapshot") or {}
    rel = snap.get("relative_path")
    if not rel:
        raise ValueError("source has no captured snapshot")
    path = (root / rel).resolve()
    if root.resolve() not in path.parents or path.is_symlink() or not path.is_file():
        raise ValueError("snapshot path is unsafe or missing")
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != snap.get("sha256"):
        raise ValueError("snapshot hash mismatch")
    return data


def review_source(workspace: str | Path, decision_file: str | Path) -> dict:
    root = validate_workspace_path(workspace)
    decision = _load(Path(decision_file))
    if not isinstance(decision, dict):
        raise ValueError("review decision must be an object")
    source_id = str(decision.get("source_id", "")).strip()
    outcome = str(decision.get("decision", "")).strip()
    reviewer = str(decision.get("reviewer", "")).strip()
    reviewer_role = str(decision.get("reviewer_role", "source_reviewer")).strip()
    rationale = str(decision.get("rationale", "")).strip()
    if outcome not in {"accept", "reject"} or not source_id or not reviewer or not reviewer_role or len(rationale) < 10:
        raise ValueError("decision, source_id, reviewer, reviewer_role and substantive rationale are required")
    ledger_path = root / "source_ledger.json"
    ledger = _load(ledger_path)
    matches = [r for r in ledger if isinstance(r, dict) and r.get("source_id") == source_id]
    if len(matches) != 1:
        raise ValueError("source_id must resolve to exactly one source")
    row = matches[0]
    reviewed_at = decision.get("reviewed_at") or _now()
    if outcome == "accept":
        if row.get("status") != "snapshot_captured_pending_acceptance_review":
            raise ValueError("only captured snapshots may be accepted")
        _snapshot_bytes(root, row)
        tier = str(decision.get("source_tier", ""))
        source_type = str(decision.get("source_type", "")).strip()
        source_native_attestation = decision.get("source_native_attestation") is True
        contract = (row.get("snapshot") or {}).get("capture_contract") or {}
        if tier not in _TIERS or not source_type:
            raise ValueError("valid source_tier and source_type are required")
        if not source_native_attestation:
            raise ValueError("source_native_attestation=true is required for evidence eligibility")
        if contract.get("eligible_for_source_quotation") is not True:
            raise ValueError(f"capture is not source-native eligible: {contract.get('failure_reasons') or ['unknown_capture_contract_failure']}")
        row["source_native_review"] = {
            "approved": True,
            "reviewer": reviewer,
            "reviewer_role": reviewer_role,
            "attestation": "Reviewer confirms the capture is an immutable source-native document or verifiable source-native response, not a generated summary.",
            "reviewed_at": reviewed_at,
        }
        row.update({
            "status": "accepted_for_evidence_extraction",
            "eligible_for_evidence": True,
            "source_tier": tier,
            "source_type": source_type,
            "acceptance_review": {"decision": "accept", "reviewer": reviewer, "reviewer_role": reviewer_role, "rationale": rationale, "reviewed_at": reviewed_at},
        })
    else:
        row.update({
            "status": "rejected_after_snapshot_review",
            "eligible_for_evidence": False,
            "acceptance_review": {"decision": "reject", "reviewer": reviewer, "reviewer_role": reviewer_role, "rationale": rationale, "reviewed_at": reviewed_at},
        })
        rejected_path = root / "rejected_sources.json"
        rejected = _load(rejected_path)
        rejected.append({"rejection_id": stable_id("rejreview", source_id, reviewed_at), "source_id": source_id, "reasons": ["rejected_after_snapshot_review"], "rationale": rationale, "reviewer": reviewer, "rejected_at": reviewed_at})
        write_json_atomic(rejected_path, rejected)
    write_json_atomic(ledger_path, ledger)
    candidate_path = root / "source_candidate_ledger.json"
    if candidate_path.exists():
        candidates = _load(candidate_path)
        for candidate in candidates:
            if isinstance(candidate, dict) and candidate.get("source_id") == source_id:
                candidate["candidate_status"] = "accepted_for_evidence" if outcome == "accept" else "rejected_after_review"
                candidate["review_decision"] = outcome
                candidate["reviewed_at"] = reviewed_at
                candidate["source_native_review_approved"] = row.get("source_native_review", {}).get("approved", False)
        write_json_atomic(candidate_path, candidates)
    return {"source_id": source_id, "status": row["status"], "eligible_for_evidence": row["eligible_for_evidence"]}


def _canonical_tables(root: Path) -> set[str]:
    graph = _load(root / "artifact_graph.json")
    out = set()
    for row in graph.get("canonical_tables", []):
        artifact = str(row.get("artifact", ""))
        if artifact:
            out.add(Path(artifact).stem)
    return out


def extract_evidence(workspace: str | Path, proposals_file: str | Path) -> dict:
    root = validate_workspace_path(workspace)
    payload = _load(Path(proposals_file))
    rows = payload.get("evidence") if isinstance(payload, dict) else None
    if not isinstance(rows, list) or not rows:
        raise ValueError("evidence proposal requires a non-empty evidence array")
    ledger = _load(root / "source_ledger.json")
    source_map = {r.get("source_id"): r for r in ledger if isinstance(r, dict)}
    evidence_path = root / "atomic_evidence.json"
    evidence = _load(evidence_path)
    tables = _canonical_tables(root)
    existing_keys = {(e.get("source_id"), e.get("quote"), e.get("linked_table"), e.get("linked_field")) for e in evidence if isinstance(e, dict)}
    accepted = 0
    rejected = []
    for index, item in enumerate(rows):
        reasons: list[str] = []
        if not isinstance(item, dict):
            rejected.append({"index": index, "reasons": ["not_an_object"]}); continue
        sid = str(item.get("source_id", ""))
        source = source_map.get(sid)
        if not source or source.get("status") != "accepted_for_evidence_extraction" or source.get("eligible_for_evidence") is not True:
            reasons.append("source_not_accepted_for_evidence")
        if source:
            capture_ok, capture_reasons = verify_capture_contract(source)
            if not capture_ok:
                reasons.extend(capture_reasons)
        claim = str(item.get("claim", "")).strip()
        quote = re.sub(r"\s+", " ", str(item.get("quote", "")).strip())
        table = str(item.get("linked_table", "")).strip()
        field = str(item.get("linked_field", "")).strip()
        etype = str(item.get("evidence_type", "direct_quote")).strip()
        conflict = str(item.get("conflict_status", "none")).strip()
        if len(claim) < 15: reasons.append("claim_too_short")
        if len(quote) < 20: reasons.append("quote_too_short")
        if _BOILERPLATE.search(quote): reasons.append("boilerplate_prohibited")
        if _METADATA_ONLY.search(quote): reasons.append("metadata_not_evidence")
        if contains_generated_language(quote): reasons.append("generated_or_output_derived_quote")
        if table not in tables: reasons.append("invalid_linked_table")
        if not field or not re.fullmatch(r"[a-z][a-z0-9_]{1,63}", field): reasons.append("invalid_linked_field")
        if etype not in _EVIDENCE_TYPES: reasons.append("invalid_evidence_type_or_analyst_inference")
        if conflict not in _CONFLICT: reasons.append("invalid_conflict_status")
        span = None
        support = semantic_support(claim, quote)
        if source:
            raw_text = _snapshot_bytes(root, source).decode("utf-8", errors="replace")
            span, span_reasons = locate_exact_span(raw_text, quote, item.get("source_span") if isinstance(item.get("source_span"), dict) else None)
            reasons.extend(span_reasons)
        threshold = minimum_support_threshold(table)
        if float(support.get("semantic_score", 0) or 0) < threshold:
            reasons.append("semantic_support_below_table_threshold")
        if support.get("missing_numeric_tokens"):
            reasons.append("claim_numeric_tokens_not_supported")
        key = (sid, quote, table, field)
        if key in existing_keys: reasons.append("duplicate_atomic_evidence")
        if reasons:
            rejected.append({
                "index": index,
                "source_id": sid or None,
                "reasons": sorted(set(reasons)),
                "semantic_support": support,
            }); continue
        as_of = item.get("as_of_date") or source.get("publication_date")
        freshness = "unknown"
        if as_of:
            try:
                age = (date.today() - date.fromisoformat(str(as_of)[:10])).days
                freshness = "current" if age <= 365 else "stale_review_required"
            except ValueError:
                reasons.append("invalid_as_of_date")
        if reasons:
            rejected.append({"index": index, "source_id": sid, "reasons": reasons}); continue
        eid = stable_id("ev", sid, quote, table, field, length=24)
        evidence.append({
            "evidence_id": eid,
            "source_id": sid,
            "claim": claim,
            "quote": quote,
            "linked_table": table,
            "linked_field": field,
            "evidence_type": etype,
            "as_of_date": as_of,
            "freshness_status": freshness,
            "conflict_status": conflict,
            "analyst_note": item.get("analyst_note"),
            "extracted_at": _now(),
            "eligible": True,
            "snapshot_sha256": source["snapshot"]["sha256"],
            "source_span": {**(span or {}), "document_sha256": source["snapshot"]["sha256"], "source_url": source.get("canonical_url") or source.get("url")},
            "semantic_support": support,
            "grounding_status": "source_native_span_verified",
        })
        existing_keys.add(key); accepted += 1
    write_json_atomic(evidence_path, evidence)
    write_json_atomic(root / "evidence_extraction_audit.json", {
        "schema_version": "phase10-stage3-evidence-audit-v1",
        "generated_at": _now(),
        "proposal_count": len(rows),
        "accepted_count": accepted,
        "rejected_count": len(rejected),
        "rejections": rejected,
    })
    state_path = root / "run_state.json"
    state = _load(state_path)
    state["eligible_evidence_count"] = len([e for e in evidence if e.get("eligible") is True])
    state["status"] = "evidence_extracted_pending_data_population" if accepted else state.get("status")
    state["updated_at"] = _now()
    write_json_atomic(state_path, state)
    return {"accepted_evidence_count": accepted, "rejected_proposal_count": len(rejected), "total_eligible_evidence_count": state["eligible_evidence_count"], "rejections": rejected, "status": state["status"]}
