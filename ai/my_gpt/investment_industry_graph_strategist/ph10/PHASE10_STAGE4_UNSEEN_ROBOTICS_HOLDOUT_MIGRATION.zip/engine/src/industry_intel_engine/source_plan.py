from __future__ import annotations

from .ids import stable_id
from .models import ArchetypeResolution, BoundaryResolution, SourcePlanItem


_BASE_FAMILIES = [
    ("official_statistics", 1, True, "Establish market structure, production, demand, employment, trade, or capacity facts.", ["industry_boundary", "industry_segments", "demand_drivers", "supply_constraints"]),
    ("regulator_policy", 1, True, "Establish legal, regulatory, policy, licensing, safety, reimbursement, or geopolitical constraints.", ["regulation_policy", "event_catalysts", "risks_falsifiers"]),
    ("company_filings", 1, True, "Map public-company exposure, segment economics, risks, customers, capex, margins, and catalysts.", ["company_universe", "security_master", "company_segment_exposure", "financial_sensitivity"]),
    ("industry_associations_standards", 2, True, "Validate terminology, technical standards, value-chain structure, and operating metrics.", ["industry_segments", "value_chain_nodes", "value_chain_edges", "technology_disruption"]),
    ("technical_primary", 2, True, "Validate technical bottlenecks, process constraints, performance limits, and substitution risk.", ["value_chain_nodes", "supply_constraints", "technology_disruption"]),
    ("transaction_data", 2, False, "Measure volumes, prices, utilization, take rates, shipments, or other operating signals where permitted.", ["demand_drivers", "profit_pools", "financial_sensitivity", "quantamental_signals"]),
    ("customer_channel", 2, True, "Map end customers, procurement, channels, switching costs, adoption, and service dynamics.", ["end_customers", "demand_drivers", "competitive_structure"]),
    ("event_catalyst", 2, True, "Identify current dated catalysts, milestones, policy decisions, earnings events, and disruptions.", ["event_catalysts", "scenario_assumptions", "risks_falsifiers"]),
    ("private_market", 3, False, "Map private-company archetypes, ownership, funding, consolidation, and PE/growth relevance.", ["company_universe", "pe_growth_diligence", "opportunity_zones"]),
    ("negative_risk", 1, True, "Actively search for bear cases, failures, litigation, substitution, customer loss, overcapacity, and thesis breaks.", ["risks_falsifiers", "scenario_assumptions", "opportunity_zones"]),
]


_GLOBAL_RECALL_MODULES = [
    ("current_report_freshness", 1, True, "Execute a last-mile sweep for current reports, releases, filings and standards before research can stop.", ["demand_drivers", "event_catalysts", "company_universe", "regulation_policy"]),
    ("geography_local_language", 1, True, "Search material producing, consuming, regulating and technology-leading geographies in relevant local languages.", ["supply_constraints", "regulation_policy", "competitive_structure", "technology_disruption"]),
]

_ARCHETYPE_MODULES = {
    "financial_network": [
        ("payments_rail_statistics", 1, True, "Measure rail volumes, values, take rates, fraud, settlement and adoption.", ["quantamental_signals", "money_flows", "financial_sensitivity"]),
        ("financial_regulation_enforcement", 1, True, "Capture network, consumer, prudential, competition and enforcement constraints.", ["regulation_policy", "risks_falsifiers", "event_catalysts"]),
    ],
    "software_platform": [
        ("software_unit_economics", 1, True, "Capture retention, recurring revenue, implementation, gross margin and customer concentration.", ["profit_pools", "financial_sensitivity", "company_segment_exposure"]),
        ("private_ownership_transactions", 2, True, "Capture sponsor ownership, funding, consolidation and exit pathways.", ["company_universe", "opportunity_zones", "competitive_structure"]),
    ],
    "healthcare_regulated": [
        ("reimbursement_workflow_standards", 1, True, "Capture reimbursement, coding, transaction standards, payer/provider workflow and compliance.", ["regulation_policy", "value_chain_nodes", "money_flows"]),
        ("healthcare_cyber_resilience", 1, True, "Capture concentration, outage, privacy, cyber and patient-safety failure modes.", ["risks_falsifiers", "event_catalysts", "supply_constraints"]),
    ],
    "energy_commodity": [
        ("commodity_price_trade_flows", 1, True, "Capture prices, production, reserves, trade, capacity and geographic concentration.", ["quantamental_signals", "supply_constraints", "cost_structure"]),
        ("project_pipeline_policy_incentives", 1, True, "Capture project commissioning, incentives, permitting and policy-linked capacity.", ["event_catalysts", "regulation_policy", "demand_drivers"]),
    ],
    "industrial_manufacturing": [
        ("installed_base_aftermarket", 1, True, "Capture installed base, replacement cycles, service attach, distribution and technician capacity.", ["demand_drivers", "profit_pools", "end_customers"]),
        ("shipments_backlog_capacity", 1, True, "Capture orders, backlog, shipments, capacity, lead times and utilization.", ["quantamental_signals", "supply_constraints", "financial_sensitivity"]),
    ],
    "infrastructure_asset": [
        ("utility_permitting_project_pipeline", 1, True, "Capture interconnection, permitting, utility constraints, project pipeline and capital intensity.", ["supply_constraints", "event_catalysts", "cost_structure"]),
    ],
}


def build_source_plan(boundary: BoundaryResolution, archetype: ArchetypeResolution) -> list[SourcePlanItem]:
    industry = boundary.resolved_industry_name
    plan: list[SourcePlanItem] = []
    for family, priority, mandatory, purpose, tables in _BASE_FAMILIES:
        effective_mandatory = mandatory
        if family == "private_market" and archetype.private_market_stress_expected:
            effective_mandatory = True
        if family == "transaction_data" and archetype.live_quant_stress_expected:
            effective_mandatory = True
        queries = [
            f'"{industry}" {family.replace("_", " ")}',
            f'"{industry}" market structure value chain economics',
        ]
        if family == "company_filings":
            queries.append(f'"{industry}" annual report 10-k investor presentation')
        if family == "negative_risk":
            queries.extend([
                f'"{industry}" risks failure overcapacity substitution',
                f'"{industry}" litigation regulation customer loss bear case',
            ])
        plan.append(SourcePlanItem(
            plan_item_id=stable_id("sp", boundary.industry_id, family),
            source_family=family,
            priority=priority,
            mandatory=effective_mandatory,
            purpose=purpose,
            target_tables=tables,
            target_fields=[],
            query_templates=queries,
            acceptance_requirements=[
                "materially relevant to at least one target table or open gap",
                "publisher/title/date/type metadata captured where available",
                "source is not placeholder, synthetic, example, or fixture-only",
                "source quality tier and freshness status assigned",
                "accept/reject rationale recorded",
            ],
            stop_condition="Mandatory family checked and target-table coverage is supported or explicitly gapped.",
        ))
    seen = {item.source_family for item in plan}
    for family, priority, mandatory, purpose, tables in _GLOBAL_RECALL_MODULES:
        if family in seen:
            continue
        seen.add(family)
        plan.append(SourcePlanItem(
            plan_item_id=stable_id("sp", boundary.industry_id, family),
            source_family=family,
            priority=priority,
            mandatory=mandatory,
            purpose=purpose,
            target_tables=tables,
            target_fields=[],
            query_templates=[
                f'"{industry}" latest report current outlook {boundary.geographic_scope}',
                f'"{industry}" policy manufacturing technology local language regional report',
            ],
            acceptance_requirements=[
                "publication date and reporting period captured",
                "material geographies and relevant local-language authorities represented",
                "current-report sweep executed after the main research pass",
                "missed authoritative domains remain visible in the recall audit",
            ],
            stop_condition="Freshness sweep and geography/language coverage audit pass, or an explicit material gap blocks stop approval.",
        ))
    module_keys = [archetype.primary_archetype, *archetype.secondary_archetypes]
    for module_key in module_keys:
        for family, priority, mandatory, purpose, tables in _ARCHETYPE_MODULES.get(module_key, []):
            if family in seen:
                continue
            seen.add(family)
            plan.append(SourcePlanItem(
                plan_item_id=stable_id("sp", boundary.industry_id, family),
                source_family=family,
                priority=priority,
                mandatory=mandatory,
                purpose=purpose,
                target_tables=tables,
                target_fields=[],
                query_templates=[
                    f'"{industry}" {family.replace("_", " ")}',
                    f'"{industry}" {purpose.lower()}',
                ],
                acceptance_requirements=[
                    "materially relevant to the archetype-specific analytical module",
                    "independent corroboration sought where company self-reporting is material",
                    "publisher/title/date/type metadata captured",
                    "accept/reject rationale persisted in the candidate funnel",
                ],
                stop_condition="Archetype-specific family is covered, independently corroborated, or explicitly recorded as a material gap.",
            ))
    return plan
