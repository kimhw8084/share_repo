from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from .archetypes import classify_archetype
from .artifact_graph import build_artifact_graph
from .atomic import write_json_atomic, write_text_atomic
from .boundary import resolve_boundary
from .ids import slugify, stable_id
from .models import RunRequest
from .providers import NullSearchProvider, SearchProvider
from .safety import validate_workspace_path
from .source_plan import build_source_plan
from .state import save_state, transition


SOURCE_LAW_FILES = [
    "INDUSTRY_INTELLIGENCE_CANONICAL_PROJECT_GOAL.md",
    "INDUSTRY_INTELLIGENCE_FOUNDATION_PHASE_PLAN.md",
    "INDUSTRY_RESEARCH_DATA_CONTRACT.md",
    "INDUSTRY_SOURCE_STRATEGY_AND_REFERENCE_PLAYBOOK.md",
    "INDUSTRY_ACCEPTANCE_CRITERIA_AND_VALIDATION_GATES.md",
    "INDUSTRY_HTML_PACKET_TEMPLATE_SPEC.md",
    "INDUSTRY_SIMULATION_ENGINE_CONTRACT.md",
    "INDUSTRY_VALIDATOR_AND_SCORING_SPEC.md",
    "INDUSTRY_ONE_PROTOTYPE_EXECUTION_PLAN.md",
    "INDUSTRY_FIVE_INDUSTRY_CROSS_SECTOR_TEST_PLAN.md",
    "BUG_REGISTER.md",
    "INDUSTRY_TWENTY_INDUSTRY_MASS_TEST_AND_REGRESSION_PLAN.md",
    "INDUSTRY_ENGINE_HARDENING_AND_PRODUCTIONIZATION_PLAN.md",
    "INDUSTRY_IMPLEMENTATION_READINESS_AND_BUILD_SEQUENCE_PLAN.md",
]


def _hash_payload(payload: dict) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def initialize_run(
    request: RunRequest,
    workspace: str | Path,
    *,
    run_id: str | None = None,
    provider: SearchProvider | None = None,
) -> dict:
    industry = " ".join(request.industry_name.split()).strip()
    if not industry:
        raise ValueError("industry_name must be non-empty")
    root = validate_workspace_path(workspace)
    root.mkdir(parents=True, exist_ok=True)
    if root.is_symlink():
        raise ValueError("Resolved workspace must not be a symlink")

    existing_state_path = root / "run_state.json"
    if existing_state_path.exists():
        existing = json.loads(existing_state_path.read_text(encoding="utf-8"))
        expected_request_hash = _hash_payload(request.to_dict())
        if existing.get("request_hash") != expected_request_hash:
            raise ValueError("Workspace already belongs to a different run request")
        return existing

    created_at = datetime.now(timezone.utc).isoformat()
    run_id = run_id or f"run_{slugify(industry)}_{stable_id('id', industry, created_at, length=8).split('_', 1)[1]}"
    request_payload = request.to_dict()
    request_hash = _hash_payload(request_payload)
    state = {
        "run_id": run_id,
        "status": "initialized",
        "created_at": created_at,
        "updated_at": created_at,
        "request_hash": request_hash,
        "production_claim": False,
        "maturity": "seed_incomplete",
        "source_count": 0,
        "eligible_evidence_count": 0,
        "history": [],
    }
    write_json_atomic(root / "run_request.json", {"run_id": run_id, **request_payload, "request_hash": request_hash})
    write_json_atomic(root / "source_law_lock.json", {
        "status": "locked_by_name_with_external_hash_verification_pending",
        "controlling_files_in_order": SOURCE_LAW_FILES,
        "research_authorized": True,
        "claim_inflation_prohibited": True,
        "notes": [
            "Hashes must be reconciled in the execution environment where all active Project Sources are mounted.",
            "Archived prompts, old manifests, and migration summaries are non-controlling.",
        ],
    })
    save_state(existing_state_path, state)

    boundary = resolve_boundary(request)
    write_json_atomic(root / "tables" / "industry_boundary.json", [boundary.to_dict()])
    state = transition(state, "boundary_resolved", reason="Pre-research boundary hypothesis generated", artifact="tables/industry_boundary.json")
    save_state(existing_state_path, state)

    archetype = classify_archetype(industry)
    write_json_atomic(root / "industry_archetype.json", archetype.to_dict())
    plan = build_source_plan(boundary, archetype)
    write_json_atomic(root / "source_plan.json", {
        "run_id": run_id,
        "industry_id": boundary.industry_id,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "mandatory_family_count": sum(1 for item in plan if item.mandatory),
        "items": [item.to_dict() for item in plan],
    })
    write_json_atomic(root / "artifact_graph.json", build_artifact_graph())
    write_json_atomic(root / "source_candidate_ledger.json", [])
    write_json_atomic(root / "source_ledger.json", [])
    write_json_atomic(root / "atomic_evidence.json", [])
    write_json_atomic(root / "search_log.json", [])
    write_json_atomic(root / "rejected_sources.json", [])
    write_json_atomic(root / "research_stop_decision.json", {"schema_version": "phase10-stage3-stop-v1", "decision": "not_recorded", "approved": False})
    write_json_atomic(root / "independent_corroboration_graph.json", {"schema_version": "phase10-stage3-quality-v1", "groups": []})
    boundary_gap = boundary.gap_ids[0]
    write_json_atomic(root / "gap_register.json", [{
        "gap_id": boundary_gap,
        "severity": "blocker",
        "category": "source_collection",
        "description": "No real sources have been collected. Boundary, segmentation, and all analytical outputs remain unvalidated.",
        "status": "open",
        "next_action": "Configure an approved search/fetch provider and execute the mandatory source-family plan.",
    }])
    state = transition(state, "source_plan_ready", reason="Adaptive mandatory source-family plan created", artifact="source_plan.json")
    save_state(existing_state_path, state)

    effective_provider = provider or NullSearchProvider()
    try:
        # Probe intentionally uses a real provider contract. Null provider fails closed.
        effective_provider.search(plan[0].query_templates[0], max_results=1)
        state = transition(state, "collecting_sources", reason="Search provider available")
    except Exception as exc:
        state = transition(state, "blocked_source_collection", reason=str(exc))
    save_state(existing_state_path, state)

    progress = {
        "run_id": run_id,
        "status": state["status"],
        "artifact_backed": True,
        "completed_steps": [
            "run_request_persisted",
            "source_law_lock_created",
            "boundary_hypothesis_created",
            "archetype_classified",
            "adaptive_source_plan_created",
            "artifact_graph_created",
            "candidate_and_rejection_funnel_initialized",
            "research_stop_gate_initialized",
            "empty_ledgers_initialized",
            "source_collection_gate_evaluated",
        ],
        "blocked_steps": ["source_collection", "evidence_extraction", "analytical_transforms", "simulation", "validation", "html_packet"],
        "source_count": 0,
        "eligible_evidence_count": 0,
        "progress_percent": 8,
        "progress_basis": "8 durable initialization/gate artifacts out of the canonical 26-step workflow; research completion is 0%.",
    }
    write_json_atomic(root / "progress_ledger.json", progress)
    write_text_atomic(root / "final_summary.md", f"""# Industry Intelligence run summary\n\n- **Run ID:** `{run_id}`\n- **Industry input:** {industry}\n- **Status:** `{state['status']}`\n- **Maturity:** `seed_incomplete`\n- **Accepted sources:** 0\n- **Eligible atomic evidence:** 0\n- **HTML packet:** not generated\n- **Production claim:** false\n\nA durable boundary hypothesis, archetype classification, adaptive source plan, artifact graph, and empty auditable ledgers were created. The run is blocked at source collection because no real approved search/fetch provider was configured. No synthetic source or evidence row was counted.\n""")
    return state
