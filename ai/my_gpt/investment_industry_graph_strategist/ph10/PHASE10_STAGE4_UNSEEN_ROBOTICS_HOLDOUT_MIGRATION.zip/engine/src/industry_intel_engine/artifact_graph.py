from __future__ import annotations


REQUIRED_HTML_TABS = [
    "Executive Investment View",
    "Industry Boundary and Segmentation",
    "Value Chain Map",
    "Node Economics and Profit Pools",
    "Company and Security Exposure",
    "Demand, Customers, and End Markets",
    "Supply, Bottlenecks, and Constraints",
    "Competitive Structure",
    "Regulation, Policy, and Geopolitics",
    "Technology and Disruption",
    "Financial Sensitivity and Valuation Context",
    "Quantamental Signals",
    "Catalysts and Event Calendar",
    "Scenario Simulator",
    "Opportunity Zones and Long/Short Implications",
    "PE / Growth Equity Diligence View",
    "Risks, Bear Case, and Falsifiers",
    "Evidence Ledger",
    "Quality, Validation, and Gaps",
]

CORE_TABLES = [
    "industry_boundary", "industry_segments", "source_ledger", "atomic_evidence",
    "value_chain_nodes", "value_chain_edges", "money_flows", "profit_pools",
    "cost_structure", "demand_drivers", "end_customers", "supply_constraints",
    "competitive_structure", "regulation_policy", "technology_disruption",
    "company_universe", "security_master", "company_segment_exposure",
    "financial_sensitivity", "quantamental_signals", "event_catalysts",
    "scenario_assumptions", "formula_registry", "simulation_outputs",
    "opportunity_zones", "risks_falsifiers", "gap_register",
]


def build_artifact_graph() -> dict:
    return {
        "canonical_tables": [
            {"artifact": f"tables/{name}.json", "status": "pending", "required": True}
            for name in CORE_TABLES
        ],
        "ledgers": [
            {"artifact": "source_candidate_ledger.json", "status": "initialized", "required": True},
            {"artifact": "search_log.json", "status": "initialized", "required": True},
            {"artifact": "rejected_sources.json", "status": "initialized", "required": True},
            {"artifact": "progress_ledger.json", "status": "initialized", "required": True},
            {"artifact": "research_stop_decision.json", "status": "initialized", "required": True},
            {"artifact": "independent_corroboration_graph.json", "status": "initialized", "required": True},
            {"artifact": "evidence_extraction_audit.json", "status": "pending", "required": True},
            {"artifact": "analytical_specificity_audit.json", "status": "pending", "required": True},
            {"artifact": "authoritative_source_recall.json", "status": "conditional", "required": False},
        ],
        "packet": {
            "artifact": "index.html",
            "status": "blocked",
            "mode": "not_generated",
            "required_tabs": REQUIRED_HTML_TABS,
            "blocked_by": ["source_collection", "evidence_extraction", "analytical_transforms", "validation"],
        },
        "validation": [
            {"artifact": "validation_report.json", "status": "pending", "required": True},
            {"artifact": "validation_report.md", "status": "pending", "required": True},
        ],
        "package": [
            {"artifact": "industry_dataset.json", "status": "pending", "required": True},
            {"artifact": "manifest.json", "status": "pending", "required": True},
            {"artifact": "final_summary.md", "status": "initialized", "required": True},
        ],
    }
