from __future__ import annotations

from .ids import stable_id
from .models import BoundaryResolution, RunRequest


def resolve_boundary(request: RunRequest) -> BoundaryResolution:
    raw = " ".join(request.industry_name.split()).strip()
    if not raw:
        raise ValueError("industry_name must be non-empty")
    resolved = raw.title()
    industry_id = stable_id("ind", raw.lower())
    gap_id = stable_id("gap", industry_id, "boundary-source-validation")
    return BoundaryResolution(
        industry_id=industry_id,
        industry_name_input=raw,
        resolved_industry_name=resolved,
        definition=(
            f"Organizations, products, services, enabling inputs, distribution channels, "
            f"customers, and regulatory structures materially involved in {resolved}."
        ),
        included_scope=[
            "core products and services",
            "critical upstream inputs and enabling infrastructure",
            "distribution, channels, and aftermarket/service layers",
            "material customer/end-market demand",
            "public and private company exposure where discoverable",
        ],
        excluded_scope=[
            "adjacent activities with no material economic exposure",
            "consumer or enterprise use cases that do not affect industry economics",
            "unsupported speculative extensions",
        ],
        adjacent_industries=[
            "upstream inputs",
            "downstream customers",
            "substitutes and complements",
        ],
        geographic_scope=request.geography,
        time_horizon=request.horizon,
        investability_scope=request.investability_scope,
        boundary_confidence="low",
        assumptions=[
            "Boundary is a pre-research operating hypothesis.",
            "Source collection must validate, narrow, or expand the boundary before analytical claims are generated.",
        ],
        gap_ids=[gap_id],
    )
