from __future__ import annotations

import csv
import hashlib
import html
import json
import os
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .artifact_graph import CORE_TABLES, REQUIRED_HTML_TABS
from .atomic import write_json_atomic, write_text_atomic
from .safety import validate_workspace_path

HTML_SCHEMA_VERSION = "phase16-stage6-v1"
HTML_TEMPLATE_VERSION = "phase10-html-v1"

TAB_TABLES: dict[str, tuple[str, ...]] = {
    "Executive Investment View": ("opportunity_zones", "risks_falsifiers", "event_catalysts", "professional_lenses"),
    "Industry Boundary and Segmentation": ("industry_boundary", "industry_segments"),
    "Value Chain Map": ("value_chain_nodes", "value_chain_edges", "money_flows"),
    "Node Economics and Profit Pools": ("profit_pools", "cost_structure", "money_flows", "value_chain_nodes"),
    "Company and Security Exposure": ("company_universe", "security_master", "company_segment_exposure"),
    "Demand, Customers, and End Markets": ("demand_drivers", "end_customers", "industry_segments"),
    "Supply, Bottlenecks, and Constraints": ("supply_constraints", "cost_structure", "value_chain_nodes"),
    "Competitive Structure": ("competitive_structure", "company_universe"),
    "Regulation, Policy, and Geopolitics": ("regulation_policy",),
    "Technology and Disruption": ("technology_disruption",),
    "Financial Sensitivity and Valuation Context": ("financial_sensitivity", "security_master", "company_segment_exposure"),
    "Quantamental Signals": ("quantamental_signals",),
    "Catalysts and Event Calendar": ("event_catalysts",),
    "Scenario Simulator": ("scenario_assumptions", "formula_registry", "simulation_outputs"),
    "Opportunity Zones and Long/Short Implications": ("opportunity_zones", "risks_falsifiers", "event_catalysts"),
    "PE / Growth Equity Diligence View": ("industry_segments", "value_chain_nodes", "money_flows", "profit_pools", "cost_structure", "competitive_structure", "company_universe"),
    "Risks, Bear Case, and Falsifiers": ("risks_falsifiers", "supply_constraints", "regulation_policy"),
    "Evidence Ledger": ("atomic_evidence", "source_ledger"),
    "Quality, Validation, and Gaps": ("gap_register", "professional_lenses"),
}

SIMULATION_FILES = (
    "scenario_outputs", "node_impact_outputs", "edge_impact_outputs", "company_impact_outputs",
    "security_impact_outputs", "financial_sensitivity_outputs", "event_simulation_outputs",
    "opportunity_ranking_outputs", "thesis_break_outputs", "sensitivity_outputs",
    "valuation_outputs", "simulation_gap_outputs", "formula_registry_compiled", "scenario_reports",
)

DISPLAY_FIELDS: dict[str, tuple[str, ...]] = {
    "industry_boundary": ("resolved_industry_name", "definition", "included_scope", "excluded_scope", "geographic_scope", "time_horizon", "boundary_confidence"),
    "industry_segments": ("segment_name", "segment_dimension", "definition"),
    "value_chain_nodes": ("node_name", "node_type", "node_description", "economic_role"),
    "value_chain_edges": ("from_node_id", "to_node_id", "flow_type", "flow_description", "materiality"),
    "money_flows": ("payer_node_id", "receiver_node_id", "payment_for"),
    "profit_pools": ("node_id", "profit_pool_description", "relative_attractiveness"),
    "cost_structure": ("cost_category", "materiality", "node_id", "company_id"),
    "demand_drivers": ("driver_name", "driver_type", "description", "direction", "time_horizon", "confidence_level"),
    "end_customers": ("customer_group", "direct_or_final"),
    "supply_constraints": ("constraint_name", "constraint_type", "severity", "affected_node_id"),
    "competitive_structure": ("market_structure", "competitive_description", "concentration_level", "barriers_to_entry", "rivalry_intensity"),
    "regulation_policy": ("regulation_name", "jurisdiction", "regulation_type", "status"),
    "technology_disruption": ("technology_name", "description"),
    "company_universe": ("company_name", "ownership_type", "business_description", "industry_relevance"),
    "security_master": ("security_id", "company_id", "security_type", "ticker", "exchange"),
    "company_segment_exposure": ("company_id", "security_id", "node_id", "segment_id", "exposure_type", "exposure_direction", "exposure_magnitude", "confidence_level"),
    "financial_sensitivity": ("company_id", "security_id", "driver_name", "driver_type", "sensitivity_direction", "sensitivity_magnitude", "confidence_level"),
    "quantamental_signals": ("signal_name", "signal_definition", "history_available", "backtest_status", "confidence_level"),
    "event_catalysts": ("event_name", "event_type", "event_date", "impact_magnitude"),
    "scenario_assumptions": ("scenario_type", "assumption_name", "variable_name", "variable_value", "unit", "allowed_min", "allowed_max", "confidence_level"),
    "formula_registry": ("formula_name", "formula_expression", "output_field", "version", "status", "limitations"),
    "simulation_outputs": ("scenario_type", "output_type", "direction", "impact_score", "output_explanation", "confidence_level"),
    "opportunity_zones": ("opportunity_name", "opportunity_type", "investment_implication", "upside_logic", "downside_logic", "time_horizon", "evidence_strength", "confidence_level", "valuation_context"),
    "risks_falsifiers": ("record_type", "name", "risk_type", "description", "impact_magnitude", "measurable_threshold"),
    "atomic_evidence": ("claim", "quote", "linked_table", "linked_field", "evidence_type", "confidence_level", "freshness_status", "conflict_status"),
    "source_ledger": ("title", "publisher", "source_type", "source_tier", "publication_date", "canonical_url", "status"),
    "gap_register": ("gap_name", "gap_reason", "severity", "status", "next_action", "blocks_institutional_status"),
    "professional_lenses": ("lens_id", "status", "coverage_percent", "missing_tables"),
}

ID_FIELDS = (
    "industry_id", "segment_id", "node_id", "edge_id", "money_flow_id", "profit_pool_id", "cost_id",
    "demand_driver_id", "customer_id", "constraint_id", "competitive_structure_id", "regulation_id",
    "technology_id", "company_id", "security_id", "exposure_id", "financial_sensitivity_id", "signal_id",
    "event_id", "assumption_id", "formula_id", "simulation_output_id", "opportunity_id", "risk_falsifier_id",
    "evidence_id", "source_id", "gap_id", "lens_id",
)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_safe_for_script(payload: Any) -> str:
    text = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return text.replace("</", "<\\/").replace("<!--", "<\\!--")


def _csv_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows if isinstance(row, dict) for key in row})
    if not fields:
        fields = ["_empty"]
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        with tmp.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow({field: _csv_value(row.get(field)) for field in fields})
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()


def _record_id(row: dict[str, Any], fallback: str) -> str:
    for field in ID_FIELDS:
        value = row.get(field)
        if value not in (None, ""):
            return str(value)
    return fallback


def _normalize_rows(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    if isinstance(value, dict):
        return [value]
    return []


def _claim_inventory(tables: dict[str, list[dict[str, Any]]], simulation: dict[str, list[dict[str, Any]]]) -> list[dict[str, Any]]:
    claims: list[dict[str, Any]] = []
    for table, rows in tables.items():
        for index, row in enumerate(rows):
            rid = _record_id(row, f"{table}_{index}")
            evidence_ids = sorted({str(x) for x in row.get("evidence_ids", []) if x})
            source_ids = sorted({str(x) for x in row.get("source_ids", []) if x})
            if table == "atomic_evidence":
                evidence_ids = [str(row.get("evidence_id"))] if row.get("evidence_id") else []
                source_ids = [str(row.get("source_id"))] if row.get("source_id") else []
            elif table == "source_ledger":
                source_ids = [str(row.get("source_id"))] if row.get("source_id") else []
            fields = [field for field in DISPLAY_FIELDS.get(table, ()) if row.get(field) not in (None, "", [], {})]
            if table == "gap_register":
                kind = "gap"
            elif table == "industry_boundary" and not evidence_ids and not source_ids and row.get("gap_ids"):
                kind = "hypothesis"
            elif table in {"scenario_assumptions"}:
                kind = "assumption"
            elif table in {"simulation_outputs"}:
                kind = "derived_output"
            elif table in {"professional_lenses", "source_ledger", "atomic_evidence"}:
                kind = "ledger_or_structural"
            else:
                kind = "fact_or_interpretation"
            claims.append({
                "claim_id": f"claim:{table}:{rid}",
                "claim_kind": kind,
                "table": table,
                "record_id": rid,
                "fields": fields,
                "evidence_ids": evidence_ids,
                "source_ids": source_ids,
                "formula_ids": sorted({str(x) for x in row.get("formula_ids", []) if x}),
                "lineage_status": "gap" if kind == "gap" else ("resolved" if evidence_ids or source_ids or table in {"professional_lenses", "source_ledger"} else "derived_or_structural"),
            })
    for name, rows in simulation.items():
        for index, row in enumerate(rows):
            rid = _record_id(row, f"{name}_{index}")
            claims.append({
                "claim_id": f"claim:simulation/{name}:{rid}",
                "claim_kind": "derived_output" if name != "simulation_gap_outputs" else "gap",
                "table": f"simulation/{name}",
                "record_id": rid,
                "fields": sorted(key for key in row if key not in {"record_metadata", "field_lineage"}),
                "evidence_ids": sorted({str(x) for x in row.get("evidence_ids", []) if x}),
                "source_ids": sorted({str(x) for x in row.get("source_ids", []) if x}),
                "formula_ids": sorted({str(x) for x in row.get("formula_ids", []) if x}),
                "lineage_status": "gap" if name == "simulation_gap_outputs" else "formula_and_assumption_lineage",
            })
    return claims


def _table_export(root: Path, name: str, rows: list[dict[str, Any]], json_path: str) -> dict[str, Any]:
    csv_path = root / "exports" / f"{name}.csv"
    _write_csv(csv_path, rows)
    return {
        "name": name,
        "json_path": json_path,
        "csv_path": csv_path.relative_to(root).as_posix(),
        "row_count": len(rows),
        "csv_sha256": _sha256(csv_path),
    }


def _collect_data(root: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    run_state = _load_json(root / "run_state.json", {})
    request = _load_json(root / "run_request.json", {})
    dataset = _load_json(root / "industry_dataset.json", {})
    completeness = _load_json(root / "completeness_report.json", {})
    readiness = _load_json(root / "simulation_readiness.json", {
        "status": "disabled_not_prepared", "simulation_maturity_level": 0,
        "simulation_maturity_label": "No Valid Simulation", "blocker_count": 1,
        "valuation_status": "disabled_missing_simulation_preparation",
    })
    tables: dict[str, list[dict[str, Any]]] = {}
    dataset_tables = dataset.get("tables") if isinstance(dataset.get("tables"), dict) else {}
    for name in CORE_TABLES:
        table_rows = _normalize_rows(_load_json(root / "tables" / f"{name}.json", []))
        if name not in dataset_tables:
            raise ValueError(f"industry_dataset.json is missing canonical table: {name}")
        if table_rows != _normalize_rows(dataset_tables.get(name)):
            raise ValueError(f"synchronized canonical table drift detected: {name}")
        tables[name] = table_rows
    tables["professional_lenses"] = _normalize_rows(_load_json(root / "tables" / "professional_lenses.json", []))

    simulation: dict[str, list[dict[str, Any]]] = {}
    for name in SIMULATION_FILES:
        simulation[name] = _normalize_rows(_load_json(root / "simulation" / f"{name}.json", []))

    export_rows: list[dict[str, Any]] = []
    for name, rows in tables.items():
        json_path = f"tables/{name}.json" if (root / "tables" / f"{name}.json").exists() else f"{name}.json"
        export_rows.append(_table_export(root, name, rows, json_path))
    for name, rows in simulation.items():
        export_rows.append(_table_export(root, f"simulation_{name}", rows, f"simulation/{name}.json"))
    for name in ("source_candidate_ledger", "search_log", "rejected_sources", "progress_ledger", "field_lineage", "research_stop_decision", "independent_corroboration_graph", "final_state_reconciliation"):
        rows = _normalize_rows(_load_json(root / f"{name}.json", []))
        export_rows.append(_table_export(root, name, rows, f"{name}.json"))

    boundary = tables.get("industry_boundary", [])
    primary_boundary = boundary[0] if boundary else {}
    source_rows = tables.get("source_ledger", [])
    evidence_rows = [row for row in tables.get("atomic_evidence", []) if row.get("eligible", True)]
    open_gaps = [row for row in tables.get("gap_register", []) if row.get("status") != "closed"]
    blockers = [row for row in open_gaps if row.get("severity") == "blocker" or row.get("blocks_institutional_status")]
    stale_sources = [row for row in source_rows if ((row.get("freshness") or {}).get("stale_status") not in (None, "current") or row.get("freshness_status") in {"stale", "review_required"})]
    conflict_evidence = [row for row in evidence_rows if row.get("conflict_status") not in (None, "", "none", "resolved")]
    production_claim = bool(run_state.get("production_claim", False))
    validation = _load_json(root / "validation_report.json", {})
    score = validation.get("overall_score")
    research_quality_score = validation.get("research_quality_score")
    maturity_score = validation.get("maturity_score")
    operational_integrity_score = validation.get("operational_integrity_score")
    active_score_caps = validation.get("active_score_caps", [])
    hard_fail = validation.get("hard_fail_status", "not_evaluated_phase10")
    maturity = validation.get("maturity_level") or run_state.get("maturity") or "structured_with_visible_gaps"
    score_confidence = validation.get("score_confidence", "not_scored_stage7_pending")

    payload = {
        "schema_version": HTML_SCHEMA_VERSION,
        "template_version": HTML_TEMPLATE_VERSION,
        "generated_at": _now(),
        "header": {
            "industry_name": primary_boundary.get("resolved_industry_name") or request.get("industry_name") or request.get("industry_name_input") or "Unresolved industry",
            "industry_id": primary_boundary.get("industry_id") or dataset.get("industry_id") or run_state.get("industry_id") or "unresolved",
            "run_id": run_state.get("run_id") or dataset.get("run_id") or "unresolved",
            "maturity": maturity,
            "overall_score": score,
            "research_quality_score": research_quality_score,
            "maturity_score": maturity_score,
            "operational_integrity_score": operational_integrity_score,
            "active_score_caps": active_score_caps,
            "score_confidence": score_confidence,
            "hard_fail_status": hard_fail,
            "source_count": len(source_rows),
            "evidence_count": len(evidence_rows),
            "last_updated": run_state.get("updated_at") or readiness.get("generated_at") or _now(),
            "schema_version": dataset.get("schema_version", "phase16-stage4-v1"),
            "source_playbook_version": "project-source-current",
            "validation_gate_version": "stage7-pending",
            "html_template_version": HTML_TEMPLATE_VERSION,
            "simulation_model_version": readiness.get("schema_version", "not_active"),
            "stale_source_warning": len(stale_sources),
            "unresolved_conflict_warning": len(conflict_evidence),
            "production_claim": production_claim,
        },
        "tables": tables,
        "simulation": simulation,
        "simulation_readiness": readiness,
        "completeness": completeness,
        "validation": validation,
        "exports": export_rows,
        "required_tabs": REQUIRED_HTML_TABS,
        "tab_tables": {tab: list(names) for tab, names in TAB_TABLES.items()},
        "claims": _claim_inventory(tables, simulation),
        "source_funnel": validation.get("source_funnel") or {"discovered_candidate_count": len(_normalize_rows(_load_json(root / "source_candidate_ledger.json", []))), "review_accepted_source_count": len(source_rows)},
        "research_stop_decision": _load_json(root / "research_stop_decision.json", {"decision": "not_recorded", "approved": False}),
        "independent_corroboration": _load_json(root / "independent_corroboration_graph.json", {"claim_group_count": 0, "independently_corroborated_count": 0}),
        "warnings": {
            "open_gap_count": len(open_gaps),
            "blocker_count": len(blockers),
            "stale_source_count": len(stale_sources),
            "unresolved_conflict_count": len(conflict_evidence),
            "fixture_only": (root / "FIXTURE_ONLY.md").exists(),
            "not_investment_grade": not production_claim or score is None or bool(blockers),
        },
    }
    return payload, export_rows


def _render_nav() -> str:
    return "\n".join(
        f'<button class="tab-link" role="tab" aria-selected="{str(i == 0).lower()}" data-tab-target="tab-{i+1}" data-tab-name="{html.escape(tab)}"><span class="tab-number">{i+1:02d}</span>{html.escape(tab)}</button>'
        for i, tab in enumerate(REQUIRED_HTML_TABS)
    )


def _render_sections() -> str:
    sections = []
    for i, tab in enumerate(REQUIRED_HTML_TABS):
        tables = TAB_TABLES[tab]
        sections.append(
            f'<section class="tab-panel{(" active" if i == 0 else "")}" id="tab-{i+1}" role="tabpanel" data-tab-name="{html.escape(tab)}">'
            f'<div class="section-kicker">MODULE {i+1:02d}</div><h2>{html.escape(tab)}</h2>'
            f'<div class="tab-status" data-tab-status="{i+1}"></div>'
            f'<div class="panel-grid" data-render-tables="{html.escape(",".join(tables))}"></div>'
            f'</section>'
        )
    return "\n".join(sections)


def _html_template(payload: dict[str, Any]) -> str:
    embedded = _json_safe_for_script(payload)
    nav = _render_nav()
    sections = _render_sections()
    return f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="dark light">
<title>{html.escape(payload["header"]["industry_name"])} — Industry Intelligence</title>
<style>
:root{{--bg:#071018;--bg2:#0d1823;--panel:#111f2c;--panel2:#172a3a;--text:#eef6fb;--muted:#9fb4c4;--line:#294052;--accent:#60d6c6;--warn:#ffca6a;--danger:#ff7d7d;--ok:#7ee2a8;--shadow:0 18px 55px rgba(0,0,0,.22)}}
*{{box-sizing:border-box}}html{{scroll-behavior:smooth}}body{{margin:0;background:radial-gradient(circle at 80% -20%,#1d3f4e 0,transparent 35%),var(--bg);color:var(--text);font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;line-height:1.45}}button,input,select{{font:inherit}}a{{color:var(--accent)}}
header{{position:sticky;top:0;z-index:20;background:rgba(7,16,24,.94);backdrop-filter:blur(18px);border-bottom:1px solid var(--line)}}.header-main{{display:flex;gap:24px;align-items:flex-start;padding:16px 22px}}.brand{{min-width:260px}}.brand .eyebrow,.section-kicker{{letter-spacing:.16em;text-transform:uppercase;color:var(--accent);font-size:.7rem;font-weight:800}}h1{{font-size:1.25rem;margin:.25rem 0 0}}.header-metrics{{display:grid;grid-template-columns:repeat(6,minmax(110px,1fr));gap:8px;flex:1}}.metric{{border:1px solid var(--line);background:var(--panel);padding:9px 11px;border-radius:10px}}.metric span{{display:block;color:var(--muted);font-size:.68rem;text-transform:uppercase;letter-spacing:.08em}}.metric strong{{font-size:.9rem;word-break:break-word}}.warning-strip{{display:flex;gap:10px;flex-wrap:wrap;padding:0 22px 12px}}.badge{{color:var(--text);display:inline-flex;align-items:center;padding:5px 9px;border-radius:999px;background:var(--panel2);border:1px solid var(--line);font-size:.75rem}}.badge.warn{{color:var(--warn);border-color:#795f2d}}.badge.danger{{color:var(--danger);border-color:#713c42}}.badge.ok{{color:var(--ok);border-color:#315c46}}
.layout{{display:grid;grid-template-columns:300px minmax(0,1fr);min-height:calc(100vh - 120px)}}aside{{position:sticky;top:128px;height:calc(100vh - 128px);overflow:auto;border-right:1px solid var(--line);padding:16px;background:rgba(9,21,31,.7)}}.global-search{{width:100%;background:var(--panel);border:1px solid var(--line);color:var(--text);border-radius:9px;padding:10px 12px;margin-bottom:12px}}.tab-link{{width:100%;display:grid;grid-template-columns:32px 1fr;text-align:left;gap:8px;align-items:start;border:0;border-left:2px solid transparent;background:transparent;color:var(--muted);padding:8px 8px;cursor:pointer;border-radius:0 8px 8px 0;font-size:.79rem}}.tab-link:hover,.tab-link[aria-selected="true"]{{color:var(--text);background:var(--panel);border-left-color:var(--accent)}}.tab-number{{font-family:ui-monospace,monospace;color:var(--accent)}}main{{padding:28px;min-width:0}}.tab-panel{{display:none;max-width:1500px;margin:0 auto}}.tab-panel.active{{display:block}}h2{{font-size:clamp(1.6rem,3vw,2.7rem);margin:.25rem 0 8px;letter-spacing:-.03em}}.tab-status{{color:var(--muted);margin-bottom:20px}}.panel-grid{{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:14px}}.panel{{grid-column:span 6;background:linear-gradient(145deg,var(--panel),#0d1a25);border:1px solid var(--line);border-radius:14px;overflow:hidden;box-shadow:var(--shadow)}}.panel.wide{{grid-column:1/-1}}.panel-head{{display:flex;justify-content:space-between;gap:12px;align-items:center;padding:14px 16px;border-bottom:1px solid var(--line)}}.panel-head h3{{margin:0;font-size:1rem}}.panel-count{{color:var(--muted);font-size:.75rem}}.empty-state{{padding:24px;color:var(--muted)}}.gap-card{{border-left:3px solid var(--warn);padding:12px;background:rgba(255,202,106,.06);margin:10px 14px;border-radius:7px}}.table-wrap{{overflow:auto;max-height:440px}}table{{width:100%;border-collapse:collapse;font-size:.78rem}}th,td{{padding:9px 10px;border-bottom:1px solid rgba(41,64,82,.7);vertical-align:top;text-align:left}}th{{position:sticky;top:0;background:#122332;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;font-size:.64rem}}tr.claim-row{{cursor:pointer}}tr.claim-row:hover{{background:rgba(96,214,198,.07)}}.value-list{{display:flex;gap:4px;flex-wrap:wrap}}.value-chip{{padding:2px 6px;background:var(--panel2);border-radius:4px;border:1px solid var(--line)}}.score{{font-variant-numeric:tabular-nums}}.scenario-controls{{display:grid;grid-template-columns:220px 1fr;gap:18px;padding:16px}}.scenario-controls select,.scenario-controls input[type=range]{{width:100%}}.scenario-result{{font-size:2.4rem;font-weight:800;letter-spacing:-.04em}}.scenario-meta{{color:var(--muted)}}.disabled{{opacity:.66}}.export-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px;padding:14px}}.export-link{{display:block;border:1px solid var(--line);border-radius:8px;padding:9px;text-decoration:none;background:var(--panel2)}}.drawer{{position:fixed;inset:0 0 0 auto;width:min(600px,94vw);z-index:40;background:#0a151f;border-left:1px solid var(--line);box-shadow:-20px 0 60px rgba(0,0,0,.45);transform:translateX(105%);transition:transform .2s ease;overflow:auto;padding:22px}}.drawer.open{{transform:translateX(0)}}.drawer-close{{float:right;background:var(--panel);border:1px solid var(--line);color:var(--text);border-radius:7px;padding:7px 10px;cursor:pointer}}.drawer pre{{white-space:pre-wrap;word-break:break-word;background:var(--panel);border:1px solid var(--line);padding:12px;border-radius:8px}}.evidence-item{{margin:12px 0;padding:12px;background:var(--panel);border:1px solid var(--line);border-radius:9px}}.footer-note{{color:var(--muted);font-size:.75rem;padding:26px 0}}#selftest-output{{display:none}}@media(max-width:1100px){{.header-metrics{{grid-template-columns:repeat(3,1fr)}}.layout{{grid-template-columns:1fr}}aside{{position:relative;top:0;height:auto;border-right:0;border-bottom:1px solid var(--line);display:grid;grid-template-columns:repeat(3,1fr);gap:5px}}.global-search{{grid-column:1/-1}}.tab-link{{font-size:.7rem}}}}@media(max-width:720px){{.header-main{{display:block}}.header-metrics{{grid-template-columns:repeat(2,1fr);margin-top:12px}}aside{{grid-template-columns:1fr}}main{{padding:18px}}.panel{{grid-column:1/-1}}.scenario-controls{{grid-template-columns:1fr}}}}
</style>
</head>
<body>
<header id="persistent-header"><div class="header-main"><div class="brand"><div class="eyebrow">Industry Intelligence</div><h1 id="industry-name"></h1></div><div class="header-metrics" id="header-metrics"></div></div><div class="warning-strip" id="warning-strip"></div></header>
<div class="layout"><aside><input class="global-search" id="global-search" type="search" placeholder="Search companies, claims, sources, nodes…" aria-label="Global search">{nav}</aside><main>{sections}<div class="footer-note">Research implications only; not personalized financial advice. Unsupported data is shown as a gap or disabled state.</div></main></div>
<aside class="drawer" id="evidence-drawer" aria-hidden="true"><button class="drawer-close" id="drawer-close">Close</button><div id="drawer-content"></div></aside>
<pre id="selftest-output"></pre>
<script id="packet-data" type="application/json">{embedded}</script>
<script>
(() => {{
'use strict';
const DATA = JSON.parse(document.getElementById('packet-data').textContent);
const $ = (s, r=document) => r.querySelector(s); const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}}[c]));
const pretty = value => Array.isArray(value) ? `<div class="value-list">${{value.map(v=>`<span class="value-chip">${{esc(typeof v==='object'?JSON.stringify(v):v)}}</span>`).join('')}}</div>` : (value && typeof value==='object' ? `<code>${{esc(JSON.stringify(value))}}</code>` : esc(value));
const human = s => String(s).replace(/_/g,' ').replace(/\\b\\w/g,c=>c.toUpperCase());
const H=DATA.header;
$('#industry-name').textContent=H.industry_name;
const metrics=[['Industry ID',H.industry_id],['Maturity',H.maturity],['Overall score',H.overall_score ?? 'Pending Phase 10'],['Research quality',H.research_quality_score ?? 'Pending'],['Maturity score',H.maturity_score ?? 'Pending'],['Operational integrity',H.operational_integrity_score ?? 'Pending'],['Active cap',(H.active_score_caps||[]).length?Math.min(...H.active_score_caps):'None'],['Score confidence',H.score_confidence],['Hard fail',H.hard_fail_status],['Candidates / accepted',`${{DATA.source_funnel.discovered_candidate_count||0}} / ${{H.source_count}}`],['Sources / evidence',`${{H.source_count}} / ${{H.evidence_count}}`],['Research stop',String(DATA.research_stop_decision.approved||false)],['Last updated',H.last_updated],['Schema',H.schema_version],['Simulation',DATA.simulation_readiness.simulation_maturity_label || DATA.simulation_readiness.status],['Production claim',String(H.production_claim)]];
$('#header-metrics').innerHTML=metrics.map(([k,v])=>`<div class="metric"><span>${{esc(k)}}</span><strong>${{esc(v)}}</strong></div>`).join('');
const warns=[]; if(DATA.warnings.not_investment_grade)warns.push(['danger','Not investment-grade yet']); if(!DATA.research_stop_decision.approved)warns.push(['warn','Research stop not gap-approved']); if((H.active_score_caps||[]).length)warns.push(['warn',`Active score cap: ${{Math.min(...H.active_score_caps)}}`]); if(DATA.warnings.blocker_count)warns.push(['danger',`${{DATA.warnings.blocker_count}} blocker gaps`]); if(DATA.warnings.open_gap_count)warns.push(['warn',`${{DATA.warnings.open_gap_count}} open gaps`]); if(H.stale_source_warning)warns.push(['warn',`${{H.stale_source_warning}} stale/review sources`]); if(H.unresolved_conflict_warning)warns.push(['warn',`${{H.unresolved_conflict_warning}} unresolved conflicts`]); if(DATA.warnings.fixture_only)warns.push(['warn','Fixture-only demonstration']); if(!warns.length)warns.push(['ok','No global warning flags']);
$('#warning-strip').innerHTML=warns.map(([c,t])=>`<span class="badge ${{c}}">${{esc(t)}}</span>`).join('');
function activate(id){{$$('.tab-panel').forEach(x=>x.classList.toggle('active',x.id===id));$$('.tab-link').forEach(x=>x.setAttribute('aria-selected',String(x.dataset.tabTarget===id)));history.replaceState(null,'','#'+id);}}
$$('.tab-link').forEach(b=>b.addEventListener('click',()=>activate(b.dataset.tabTarget)));
const initial=location.hash && $(location.hash) ? location.hash.slice(1) : 'tab-1'; activate(initial);
function evidenceIds(row){{return Array.from(new Set([...(row.evidence_ids||[]),...Object.values(row.field_lineage||{{}}).flat()]));}}
function sourceIds(row){{return Array.from(new Set(row.source_ids||[]));}}
function rowId(row,i){{return DATA.claims.find(c=>c.table && c.record_id && (Object.values(row).includes(c.record_id)))?.record_id || Object.entries(row).find(([k,v])=>/_id$/.test(k)&&typeof v==='string')?.[1] || `row-${{i}}`;}}
function openDrawer(table,row,i){{const evIds=evidenceIds(row);const srcIds=sourceIds(row);const ev=DATA.tables.atomic_evidence.filter(x=>evIds.includes(x.evidence_id));const src=DATA.tables.source_ledger.filter(x=>srcIds.includes(x.source_id)||ev.some(e=>e.source_id===x.source_id));let body=`<div class="section-kicker">Claim trace</div><h2>${{esc(human(table))}}</h2><pre>${{esc(JSON.stringify(row,null,2))}}</pre>`;body+=`<h3>Evidence (${{ev.length}})</h3>`+(ev.length?ev.map(e=>`<div class="evidence-item"><strong>${{esc(e.claim||e.claim_text||'Evidence')}}</strong><p>${{esc(e.exact_quote_short||e.quote||e.paraphrase||'')}}</p><small>${{esc(e.linked_table||'')}}.${{esc(e.linked_field||'')}} · ${{esc(e.freshness_status||'')}} · conflict: ${{esc(e.conflict_status||'none')}}</small></div>`).join(''):'<div class="gap-card">No atomic evidence is linked to this row. Treat it as structural, derived, or a visible gap.</div>');body+=`<h3>Sources (${{src.length}})</h3>`+(src.length?src.map(s=>`<div class="evidence-item"><strong>${{esc(s.title)}}</strong><p>${{esc(s.publisher||'')}} · ${{esc(s.source_tier||s.source_quality_tier||'')}}</p>${{(s.canonical_url||s.url)?`<a href="${{esc(s.canonical_url||s.url)}}" rel="noopener noreferrer">Open source</a>`:''}}</div>`).join(''):'<div class="gap-card">No source row is directly linked.</div>');$('#drawer-content').innerHTML=body;$('#evidence-drawer').classList.add('open');$('#evidence-drawer').setAttribute('aria-hidden','false');}}
$('#drawer-close').addEventListener('click',()=>{{$('#evidence-drawer').classList.remove('open');$('#evidence-drawer').setAttribute('aria-hidden','true')}});
function renderTable(name,rows){{const fields=DATA.display_fields?.[name] || null;const chosen=fields || Array.from(new Set(rows.flatMap(r=>Object.keys(r).filter(k=>!['record_metadata','field_lineage','evidence_ids','source_ids'].includes(k))))).slice(0,8);let inner=`<div class="panel-head"><h3>${{esc(human(name))}}</h3><span class="panel-count">${{rows.length}} rows</span></div>`;if(!rows.length){{const related=DATA.tables.gap_register.filter(g=>g.missing_table===name&&g.status!=='closed');inner+=`<div class="empty-state">No synchronized records available.${{related.map(g=>`<div class="gap-card"><strong>${{esc(g.severity)}} gap</strong><br>${{esc(g.gap_reason)}}<br><small>Next: ${{esc(g.next_action)}}</small></div>`).join('')}}</div>`;return `<article class="panel" data-table="${{esc(name)}}">${{inner}}</article>`;}}inner+=`<div class="table-wrap"><table><thead><tr>${{chosen.map(f=>`<th>${{esc(human(f))}}</th>`).join('')}}<th>Trace</th></tr></thead><tbody>${{rows.map((row,i)=>`<tr class="claim-row" data-table="${{esc(name)}}" data-row-index="${{i}}">${{chosen.map(f=>`<td>${{pretty(row[f])}}</td>`).join('')}}<td><button class="badge">Evidence</button></td></tr>`).join('')}}</tbody></table></div>`;return `<article class="panel ${{rows.length>8?'wide':''}}" data-table="${{esc(name)}}">${{inner}}</article>`;}}
function scenarioPanel(){{const R=DATA.simulation_readiness;const assumptions=DATA.tables.scenario_assumptions||[];if((R.simulation_maturity_level||0)<1||R.blocker_count>0||!assumptions.length){{return `<article class="panel wide disabled" id="scenario-control-panel"><div class="panel-head"><h3>Scenario controls disabled</h3></div><div class="empty-state">${{esc(R.status||'disabled')}}. ${{(R.gaps||[]).map(g=>`<div class="gap-card">${{esc(g.gap_reason)}}<br><small>${{esc(g.next_action)}}</small></div>`).join('')}}</div></article>`;}}const opts=assumptions.map((a,i)=>`<option value="${{i}}">${{esc(a.scenario_name||a.scenario_type)}}</option>`).join('');return `<article class="panel wide" id="scenario-control-panel"><div class="panel-head"><h3>Bounded deterministic scenario control</h3><span class="panel-count">No valuation / no probability inference</span></div><div class="scenario-controls"><div><label>Canonical scenario<select id="scenario-select">${{opts}}</select></label><p class="scenario-meta" id="scenario-description"></p></div><div><label id="assumption-label"></label><input id="assumption-slider" type="range"><div><output id="assumption-value"></output> <span id="assumption-unit"></span></div><div class="scenario-result" id="custom-impact"></div><div class="scenario-meta" id="custom-explanation"></div></div></div></article>`;}}
function exportsPanel(){{return `<article class="panel wide"><div class="panel-head"><h3>Synchronized exports</h3><span class="panel-count">${{DATA.exports.length}} files</span></div><div class="export-grid">${{DATA.exports.map(x=>`<a class="export-link" href="${{esc(x.csv_path)}}" download>${{esc(human(x.name))}}<br><small>${{x.row_count}} rows · CSV</small></a>`).join('')}}</div></article>`;}}
function qualityPanels(){{const F=DATA.source_funnel||{{}};const C=DATA.completeness||{{}};const R=DATA.validation?.role_lens_scores||{{}};const G=DATA.validation?.source_native_grounding||{{}};const A=DATA.validation?.authoritative_source_recall||{{}};const cap=(H.active_score_caps||[]).length?Math.min(...H.active_score_caps):'none';const nativeRatio=G.evidence_count?Math.round(100*(G.source_span_grounded_count||0)/G.evidence_count):0;const recall=A.recall_percent??'not tested';return `<article class="panel wide"><div class="panel-head"><h3>Phase 10 quality diagnostics</h3><span class="panel-count">cap ${{cap}}</span></div><div class="export-grid"><div class="metric"><span>Discovered candidates</span><strong>${{F.discovered_candidate_count||0}}</strong></div><div class="metric"><span>Rejected / duplicates</span><strong>${{(F.pre_snapshot_rejected_count||0)+(F.duplicate_candidate_count||0)}}</strong></div><div class="metric"><span>Source-native grounded evidence</span><strong>${{nativeRatio}}%</strong></div><div class="metric"><span>Authoritative recall</span><strong>${{recall}}${{typeof recall==='number'?'%':''}}</strong></div><div class="metric"><span>Direct-evidence tables</span><strong>${{C.direct_evidence_table_completeness_percent||0}}%</strong></div><div class="metric"><span>Role-lens depth</span><strong>${{R.average_quality_score||0}}</strong></div><div class="metric"><span>Independent corroboration</span><strong>${{DATA.independent_corroboration.independently_corroborated_count||0}} / ${{DATA.independent_corroboration.claim_group_count||0}}</strong></div><div class="metric"><span>Stop decision</span><strong>${{DATA.research_stop_decision.decision||'not recorded'}}</strong></div></div></article>`;}}
$$('[data-render-tables]').forEach(container=>{{const names=container.dataset.renderTables.split(',').filter(Boolean);let content='';if(container.closest('[data-tab-name="Scenario Simulator"]'))content+=scenarioPanel();for(const name of names)content+=renderTable(name,DATA.tables[name]||[]);if(container.closest('[data-tab-name="Quality, Validation, and Gaps"]'))content+=qualityPanels()+exportsPanel();container.innerHTML=content;const total=names.reduce((n,name)=>n+(DATA.tables[name]||[]).length,0);container.closest('.tab-panel').querySelector('.tab-status').textContent=total?`${{total}} synchronized records across ${{names.length}} canonical modules.`:`No synchronized records; explicit gaps shown.`;}});
$$('tr.claim-row').forEach(tr=>tr.addEventListener('click',()=>{{const name=tr.dataset.table;openDrawer(name,DATA.tables[name][Number(tr.dataset.rowIndex)],Number(tr.dataset.rowIndex));}}));
function setupScenario(){{const select=$('#scenario-select');if(!select)return;const slider=$('#assumption-slider');function updateScenario(){{const a=DATA.tables.scenario_assumptions[Number(select.value)];slider.min=String(a.allowed_min ?? a.range_low ?? a.variable_value);slider.max=String(a.allowed_max ?? a.range_high ?? a.variable_value);slider.step='0.001';slider.value=String(a.variable_value);$('#assumption-label').textContent=`${{a.variable_name}} (bounded ${{slider.min}} to ${{slider.max}})`;$('#scenario-description').textContent=`${{a.scenario_type}} · ${{a.period||'unspecified horizon'}} · confidence ${{a.confidence_level||'not rated'}}`;$('#assumption-unit').textContent=a.unit||'';recompute();}}function recompute(){{const a=DATA.tables.scenario_assumptions[Number(select.value)];const v=Number(slider.value);const baseline=Number(a.baseline_value||0);const coefficient=Number(a.sensitivity_coefficient||0);const output=(v-baseline)*coefficient;$('#assumption-value').textContent=v.toFixed(3);$('#custom-impact').textContent=Number.isFinite(output)?output.toFixed(3):'disabled';$('#custom-explanation').textContent=`Deterministic recomputation: (variable value − baseline) × sensitivity coefficient. Formula ${{a.formula_id||'missing'}}. This is directional, not a valuation or forecast.`;}}select.addEventListener('change',updateScenario);slider.addEventListener('input',recompute);updateScenario();}}
setupScenario();
$('#global-search').addEventListener('input',e=>{{const q=e.target.value.toLowerCase().trim();$$('tr.claim-row').forEach(row=>row.hidden=q&&!row.textContent.toLowerCase().includes(q));$$('.panel').forEach(p=>{{const rows=$$('tr.claim-row',p);if(rows.length)p.hidden=q&&rows.every(r=>r.hidden);}});}});
function selftest(){{const results=[];const check=(name,ok,detail='')=>results.push({{name,ok:Boolean(ok),detail}});check('exact_tab_count',$$('.tab-link').length===19,$$('.tab-link').length);check('exact_tab_names',JSON.stringify($$('.tab-link').map(x=>x.dataset.tabName))===JSON.stringify(DATA.required_tabs));$$('.tab-link').forEach(b=>{{b.click();check('tab_activation:'+b.dataset.tabName,$('#'+b.dataset.tabTarget).classList.contains('active'));}});activate('tab-1');const first=$('tr.claim-row');if(first){{first.click();check('evidence_drawer_opens',$('#evidence-drawer').classList.contains('open'));$('#drawer-close').click();check('evidence_drawer_closes',!$('#evidence-drawer').classList.contains('open'));}}else check('evidence_drawer_available',true,'no rows');const search=$('#global-search');search.value='zzzz-no-match';search.dispatchEvent(new Event('input'));check('global_search_filters',$$('tr.claim-row').every(r=>r.hidden));search.value='';search.dispatchEvent(new Event('input'));if($('#assumption-slider')){{const slider=$('#assumption-slider');const before=$('#custom-impact').textContent;slider.value=String(Math.min(Number(slider.max),Number(slider.value)+0.01));slider.dispatchEvent(new Event('input'));check('bounded_scenario_recompute',$('#custom-impact').textContent!==before);check('scenario_bounds',Number(slider.value)>=Number(slider.min)&&Number(slider.value)<=Number(slider.max));}}else check('simulation_disabled_state',Boolean($('#scenario-control-panel.disabled')));check('exports_present',DATA.exports.length>0);const out={{status:results.every(r=>r.ok)?'passed':'failed',results}};const el=$('#selftest-output');el.textContent=JSON.stringify(out);el.style.display='block';document.title='SELFTEST:'+out.status;return out;}}
if(new URLSearchParams(location.search).get('selftest')==='1')setTimeout(selftest,50);
window.__INDUSTRY_INTEL_PACKET__={{data:DATA,activate,selftest}};
}})();
</script>
</body></html>'''


def _static_verify(root: Path, payload: dict[str, Any]) -> list[dict[str, Any]]:
    html_text = (root / "index.html").read_text(encoding="utf-8")
    checks = [
        {"name": "exact_tab_count", "passed": html_text.count('class="tab-link"') == 19},
        {"name": "exact_tab_names", "passed": all(f'data-tab-name="{html.escape(tab)}"' in html_text for tab in REQUIRED_HTML_TABS)},
        {"name": "persistent_header", "passed": 'id="persistent-header"' in html_text},
        {"name": "global_search", "passed": 'id="global-search"' in html_text},
        {"name": "evidence_drawer", "passed": 'id="evidence-drawer"' in html_text},
        {"name": "scenario_contract", "passed": 'Bounded deterministic scenario control' in html_text and 'assumption-slider' in html_text},
        {"name": "valuation_safeguard_visible", "passed": 'No valuation / no probability inference' in html_text},
        {"name": "embedded_packet_data", "passed": 'id="packet-data"' in html_text},
        {"name": "exports_generated", "passed": bool(payload.get("exports")) and all((root / x["csv_path"]).exists() for x in payload["exports"])},
        {"name": "claim_inventory", "passed": len(payload.get("claims", [])) > 0},
        {"name": "no_external_scripts", "passed": '<script src=' not in html_text.lower()},
    ]
    return checks


def generate_html_packet(workspace: str | Path) -> dict[str, Any]:
    root = validate_workspace_path(workspace)
    if not root.exists() or not (root / "run_state.json").exists():
        raise ValueError("workspace is not an initialized Phase 16 run")
    if (root / "index.html").exists() and (root / "index.html").is_symlink():
        raise ValueError("index.html must not be a symlink")
    for required in ("industry_dataset.json", "artifact_graph.json", "gap_register.json"):
        if not (root / required).exists():
            raise ValueError(f"required synchronized artifact is missing: {required}")

    payload, exports = _collect_data(root)
    payload["display_fields"] = {key: list(value) for key, value in DISPLAY_FIELDS.items()}
    write_json_atomic(root / "packet_data.json", payload)
    write_json_atomic(root / "exports_manifest.json", {"schema_version": HTML_SCHEMA_VERSION, "generated_at": payload["generated_at"], "exports": exports})
    write_text_atomic(root / "index.html", _html_template(payload))
    static_checks = _static_verify(root, payload)
    audit = {
        "schema_version": HTML_SCHEMA_VERSION,
        "template_version": HTML_TEMPLATE_VERSION,
        "generated_at": payload["generated_at"],
        "status": "generated_pending_browser_verification" if all(c["passed"] for c in static_checks) else "failed_static_contract",
        "mode": "interactive_pending_browser_test",
        "required_tabs": REQUIRED_HTML_TABS,
        "rendered_tab_count": 19,
        "exact_tab_names_passed": all(c["passed"] for c in static_checks if c["name"] == "exact_tab_names"),
        "static_checks": static_checks,
        "browser_checks": [],
        "claim_count": len(payload["claims"]),
        "claims_with_evidence": sum(1 for x in payload["claims"] if x["evidence_ids"]),
        "gap_claim_count": sum(1 for x in payload["claims"] if x["claim_kind"] == "gap"),
        "source_count": payload["header"]["source_count"],
        "evidence_count": payload["header"]["evidence_count"],
        "open_gap_count": payload["warnings"]["open_gap_count"],
        "simulation_status": payload["simulation_readiness"].get("status"),
        "valuation_status": payload["simulation_readiness"].get("valuation_status"),
        "production_claim": False,
        "index_html_sha256": _sha256(root / "index.html"),
        "packet_data_sha256": _sha256(root / "packet_data.json"),
        "export_count": len(exports),
    }
    write_json_atomic(root / "html_packet_audit.json", audit)

    graph = _load_json(root / "artifact_graph.json", {})
    packet = graph.setdefault("packet", {})
    packet.update({
        "artifact": "index.html", "status": audit["status"], "mode": audit["mode"],
        "required_tabs": REQUIRED_HTML_TABS, "rendered_tabs": REQUIRED_HTML_TABS,
        "blocked_by": ["validation"], "audit_artifact": "html_packet_audit.json",
        "packet_data_artifact": "packet_data.json", "exports_manifest": "exports_manifest.json",
    })
    write_json_atomic(root / "artifact_graph.json", graph)

    state = _load_json(root / "run_state.json", {})
    state.update({
        "status": "html_generated_pending_browser_verification",
        "html_packet_status": audit["status"],
        "html_tab_count": 19,
        "html_interactive_tested": False,
        "updated_at": _now(),
        "production_claim": False,
    })
    write_json_atomic(root / "run_state.json", state)
    return {
        "status": audit["status"], "mode": audit["mode"], "tab_count": 19,
        "claim_count": audit["claim_count"], "export_count": len(exports),
        "simulation_status": audit["simulation_status"], "production_claim": False,
        "html_path": str(root / "index.html"),
    }


def _find_browser(explicit: str | None) -> str | None:
    if explicit:
        resolved = shutil.which(explicit) or (explicit if Path(explicit).is_file() else None)
        return str(resolved) if resolved else None
    for candidate in ("chromium", "chromium-browser", "google-chrome", "google-chrome-stable"):
        found = shutil.which(candidate)
        if found:
            return found
    return None


def verify_html_packet(workspace: str | Path, *, browser: str | None = None, require_browser: bool = True) -> dict[str, Any]:
    root = validate_workspace_path(workspace)
    index = root / "index.html"
    audit_path = root / "html_packet_audit.json"
    packet_path = root / "packet_data.json"
    if not index.exists() or not audit_path.exists() or not packet_path.exists():
        raise ValueError("generate-html must complete before verify-html")
    payload = _load_json(packet_path, {})
    audit = _load_json(audit_path, {})
    static_checks = _static_verify(root, payload)
    browser_path = _find_browser(browser)
    browser_checks: list[dict[str, Any]] = []
    browser_status = "not_run"
    if browser_path:
        try:
            from playwright.sync_api import sync_playwright  # optional operational dependency
        except Exception as exc:
            browser_status = "playwright_missing"
            browser_checks = [{"name": "playwright_available", "passed": False, "detail": str(exc)}]
        else:
            try:
                with sync_playwright() as playwright:
                    launched = playwright.chromium.launch(
                        headless=True, executable_path=browser_path,
                        args=["--no-sandbox", "--disable-dev-shm-usage"],
                    )
                    page = launched.new_page()
                    page.set_content(index.read_text(encoding="utf-8"), wait_until="load", timeout=30000)
                    raw_result = page.evaluate("window.__INDUSTRY_INTEL_PACKET__.selftest()")
                    launched.close()
                browser_checks = [
                    {"name": row["name"], "passed": bool(row["ok"]), "detail": row.get("detail", "")}
                    for row in raw_result.get("results", [])
                ]
                browser_status = raw_result.get("status", "failed")
            except Exception as exc:
                browser_status = "browser_execution_failed"
                browser_checks = [{"name": "browser_execution", "passed": False, "detail": str(exc)}]
    elif require_browser:
        browser_status = "browser_missing"
        browser_checks = [{"name": "browser_available", "passed": False, "detail": "Chromium/Chrome was not found"}]

    static_passed = all(row["passed"] for row in static_checks)
    browser_passed = bool(browser_checks) and all(row["passed"] for row in browser_checks)
    fully_interactive = static_passed and browser_passed
    passed = fully_interactive or (not require_browser and not browser_path and static_passed)
    audit.update({
        "verified_at": _now(),
        "status": "interactive_verified" if fully_interactive else ("static_verified_browser_pending" if passed else "verification_failed"),
        "mode": "interactive_tested" if fully_interactive else ("interactive_pending_browser_test" if passed else "interactive_unverified"),
        "static_checks": static_checks,
        "browser": browser_path,
        "browser_status": browser_status,
        "browser_checks": browser_checks,
        "production_claim": False,
        "index_html_sha256": _sha256(index),
        "packet_data_sha256": _sha256(packet_path),
    })
    write_json_atomic(audit_path, audit)
    graph = _load_json(root / "artifact_graph.json", {})
    graph.setdefault("packet", {}).update({"status": audit["status"], "mode": audit["mode"], "browser_test_status": browser_status})
    write_json_atomic(root / "artifact_graph.json", graph)
    state = _load_json(root / "run_state.json", {})
    state.update({
        "status": "html_interactive_verified_pending_validation" if fully_interactive else ("html_generated_pending_browser_verification" if passed else "html_verification_failed"),
        "html_packet_status": audit["status"], "html_interactive_tested": fully_interactive,
        "updated_at": _now(), "production_claim": False,
    })
    write_json_atomic(root / "run_state.json", state)
    result = {
        "status": audit["status"], "mode": audit["mode"], "static_check_count": len(static_checks),
        "browser_check_count": len(browser_checks), "browser_status": browser_status,
        "failed_checks": [row["name"] for row in static_checks + browser_checks if not row["passed"]],
        "production_claim": False,
    }
    if not passed:
        raise ValueError("HTML packet verification failed: " + ", ".join(result["failed_checks"]))
    return result
