"""One-input Industry Intelligence research engine."""

__version__ = "0.10.0"
