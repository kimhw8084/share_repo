from __future__ import annotations

import ast
import hashlib
import json
import math
import os
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .atomic import write_json_atomic, write_text_atomic
from .ids import stable_id
from .safety import validate_workspace_path
from .dataset import _completeness, _update_artifact_graph

CANONICAL_SCENARIOS = ("base", "bull", "bear", "shock", "structural_transition")
SCENARIO_ALIASES = {
    "transition": "structural_transition",
    "structural": "structural_transition",
    "structural-transition": "structural_transition",
    "custom": "custom_user",
    "custom_user_scenario": "custom_user",
}
OUTPUT_FILES = (
    "scenario_outputs",
    "node_impact_outputs",
    "edge_impact_outputs",
    "company_impact_outputs",
    "security_impact_outputs",
    "financial_sensitivity_outputs",
    "valuation_outputs",
    "opportunity_ranking_outputs",
    "sensitivity_outputs",
    "thesis_break_outputs",
    "event_simulation_outputs",
    "simulation_gap_outputs",
)

_BUILTIN_FORMULAS = [
    {
        "formula_id": "builtin_edge_materiality_v1",
        "formula_name": "Directional edge materiality bridge",
        "expression": "node_impact_score * edge_materiality_factor",
        "input_fields": ["node_impact_score", "edge_materiality_factor"],
        "input_units": {"node_impact_score": "score", "edge_materiality_factor": "unitless"},
        "output_fields": ["edge_impact_score"],
        "output_unit": "score",
        "scenario_scope": list(CANONICAL_SCENARIOS) + ["custom_user"],
        "version": "1.0.0",
        "status": "engine_builtin",
        "limitations": "Directional bridge only; it does not infer physical pass-through or timing without explicit edge calibration.",
        "source_or_theory_reference": "Industry Intelligence Simulation Engine Contract sections 9.2-9.4",
    },
    {
        "formula_id": "builtin_company_exposure_v1",
        "formula_name": "Node-to-company exposure bridge",
        "expression": "node_impact_score * exposure_magnitude_factor * exposure_direction_multiplier",
        "input_fields": ["node_impact_score", "exposure_magnitude_factor", "exposure_direction_multiplier"],
        "input_units": {"node_impact_score": "score", "exposure_magnitude_factor": "unitless", "exposure_direction_multiplier": "unitless"},
        "output_fields": ["company_impact_score"],
        "output_unit": "score",
        "scenario_scope": list(CANONICAL_SCENARIOS) + ["custom_user"],
        "version": "1.0.0",
        "status": "engine_builtin",
        "limitations": "Uses ordinal exposure mappings and does not replace company-specific financial modeling.",
        "source_or_theory_reference": "Industry Intelligence Simulation Engine Contract section 10",
    },
    {
        "formula_id": "builtin_opportunity_aggregation_v1",
        "formula_name": "Scenario opportunity impact aggregation",
        "expression": "linked_impact_sum / linked_impact_count",
        "input_fields": ["linked_impact_sum", "linked_impact_count"],
        "input_units": {"linked_impact_sum": "score", "linked_impact_count": "count"},
        "output_fields": ["opportunity_impact_score"],
        "output_unit": "score",
        "scenario_scope": list(CANONICAL_SCENARIOS) + ["custom_user"],
        "version": "1.0.0",
        "status": "engine_builtin",
        "limitations": "Equal-weights linked impacts because unsupported portfolio weights are forbidden.",
        "source_or_theory_reference": "Industry Intelligence Simulation Engine Contract sections 14 and 21",
    },
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load(path: Path) -> Any:
    if path.is_symlink():
        raise ValueError(f"symlink input is prohibited: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def _finite_number(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field} must be numeric")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{field} must be finite")
    return result


@contextmanager
def _simulation_lock(root: Path):
    path = root / ".simulation.lock"
    if path.is_symlink():
        raise ValueError("simulation lock must not be a symlink")
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise ValueError("another simulation transaction is active") from exc
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(json.dumps({"pid": os.getpid(), "created_at": _now()}, sort_keys=True))
            handle.flush()
            os.fsync(handle.fileno())
        yield
    finally:
        try:
            path.unlink()
        except FileNotFoundError:
            pass


_ALLOWED_BINOPS = (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod)
_ALLOWED_UNARY = (ast.UAdd, ast.USub)
_ALLOWED_FUNCTIONS = {"abs": abs, "min": min, "max": max, "round": round}


def _compile_expression(expression: str, input_fields: list[str]) -> ast.Expression:
    if not expression or len(expression) > 1000:
        raise ValueError("formula expression must be non-empty and at most 1000 characters")
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as exc:
        raise ValueError(f"formula expression is invalid: {exc.msg}") from exc
    allowed_names = set(input_fields) | set(_ALLOWED_FUNCTIONS)
    for node in ast.walk(tree):
        if isinstance(node, ast.Expression | ast.Load | ast.Constant | ast.Name):
            if isinstance(node, ast.Name) and node.id not in allowed_names:
                raise ValueError(f"formula uses undeclared name: {node.id}")
            if isinstance(node, ast.Constant) and not isinstance(node.value, (int, float)):
                raise ValueError("formula constants must be numeric")
            continue
        if isinstance(node, ast.BinOp):
            if not isinstance(node.op, _ALLOWED_BINOPS):
                raise ValueError("formula contains a prohibited binary operation")
            continue
        if isinstance(node, ast.UnaryOp):
            if not isinstance(node.op, _ALLOWED_UNARY):
                raise ValueError("formula contains a prohibited unary operation")
            continue
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name) or node.func.id not in _ALLOWED_FUNCTIONS:
                raise ValueError("formula calls a prohibited function")
            if node.keywords:
                raise ValueError("formula function keyword arguments are prohibited")
            continue
        if isinstance(node, _ALLOWED_BINOPS + _ALLOWED_UNARY):
            continue
        raise ValueError(f"formula contains prohibited syntax: {type(node).__name__}")
    return tree


def _evaluate(tree: ast.Expression, context: dict[str, float]) -> float:
    try:
        value = eval(compile(tree, "<formula>", "eval"), {"__builtins__": {}}, {**_ALLOWED_FUNCTIONS, **context})
    except (ArithmeticError, ValueError, TypeError) as exc:
        raise ValueError(f"formula evaluation failed: {exc}") from exc
    return _finite_number(value, "formula output")


def _normal_scenario(value: Any) -> str:
    raw = str(value or "").strip().lower().replace(" ", "_")
    return SCENARIO_ALIASES.get(raw, raw)


def _direction(score: float) -> str:
    if score > 1e-12:
        return "positive"
    if score < -1e-12:
        return "negative"
    return "neutral"


def _magnitude(score: float) -> str:
    absolute = abs(score)
    if absolute >= 0.20:
        return "high"
    if absolute >= 0.05:
        return "medium"
    if absolute > 1e-12:
        return "low"
    return "neutral"


def _confidence(rows: list[dict[str, Any]]) -> str:
    levels = [str(row.get("confidence_level", "unknown")) for row in rows]
    if levels and all(level == "high" for level in levels):
        return "high"
    if any(level == "low" for level in levels):
        return "low"
    return "medium" if levels else "unknown"


def _factor(value: Any, mapping: dict[str, float], field: str) -> float:
    key = str(value or "").strip().lower()
    if key not in mapping:
        raise ValueError(f"unsupported {field}: {value}")
    return mapping[key]


def _formula_registry(rows: list[dict[str, Any]]) -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
    compiled: dict[str, dict[str, Any]] = {}
    serialized: list[dict[str, Any]] = []
    for row in rows:
        formula_id = str(row.get("formula_id", "")).strip()
        if not formula_id:
            raise ValueError("formula_registry row lacks formula_id")
        if formula_id in compiled:
            raise ValueError(f"duplicate formula_id: {formula_id}")
        status = str(row.get("status", "")).strip().lower()
        if status not in {"active", "disabled"}:
            raise ValueError(f"formula {formula_id} has unsupported status: {status}")
        input_fields = row.get("input_fields")
        if not isinstance(input_fields, list) or not input_fields or any(not isinstance(x, str) or not x for x in input_fields):
            raise ValueError(f"formula {formula_id} requires a non-empty input_fields array")
        expression = str(row.get("formula_expression") or row.get("expression") or "")
        output_fields = row.get("output_fields") or ([row.get("output_field")] if row.get("output_field") else [])
        if not isinstance(output_fields, list) or not output_fields or any(not isinstance(x, str) or not x for x in output_fields):
            raise ValueError(f"formula {formula_id} requires output_field or output_fields")
        input_units = row.get("input_units") or (row.get("units") or {}).get("inputs")
        output_unit = row.get("output_unit") or (row.get("units") or {}).get("output")
        scenario_scope = row.get("scenario_scope")
        version = str(row.get("version", "")).strip()
        limitations = str(row.get("limitations", "")).strip()
        if not isinstance(input_units, dict) or set(input_fields) - set(input_units):
            raise ValueError(f"formula {formula_id} must declare units for every input")
        if not output_unit:
            raise ValueError(f"formula {formula_id} lacks output_unit")
        if isinstance(scenario_scope, str):
            scenario_scope = [scenario_scope]
        if not isinstance(scenario_scope, list) or not scenario_scope:
            raise ValueError(f"formula {formula_id} lacks scenario_scope")
        normalized_scope = [_normal_scenario(item) for item in scenario_scope]
        if any(item not in set(CANONICAL_SCENARIOS) | {"custom_user"} for item in normalized_scope):
            raise ValueError(f"formula {formula_id} has invalid scenario_scope")
        if not version or not limitations:
            raise ValueError(f"formula {formula_id} requires version and limitations")
        tree = _compile_expression(expression, input_fields)
        item = deepcopy(row)
        item.update({
            "expression": expression,
            "input_fields": list(input_fields),
            "input_units": {str(k): str(v) for k, v in input_units.items()},
            "output_fields": list(output_fields),
            "output_unit": str(output_unit),
            "scenario_scope": normalized_scope,
            "version": version,
            "limitations": limitations,
            "compiled_status": "validated" if status == "active" else "disabled",
        })
        compiled[formula_id] = {"record": item, "tree": tree}
        serialized.append(item)
    serialized.extend(deepcopy(_BUILTIN_FORMULAS))
    return compiled, serialized


def _assumption_context(assumption: dict[str, Any], formula: dict[str, Any]) -> dict[str, float]:
    variable = _finite_number(assumption.get("variable_value"), "variable_value")
    baseline = _finite_number(assumption.get("baseline_value"), "baseline_value")
    coefficient = _finite_number(assumption.get("sensitivity_coefficient"), "sensitivity_coefficient")
    allowed_min = assumption.get("allowed_min", assumption.get("range_low"))
    allowed_max = assumption.get("allowed_max", assumption.get("range_high"))
    if allowed_min is not None and variable < _finite_number(allowed_min, "allowed_min"):
        raise ValueError(f"assumption {assumption.get('assumption_id')} is below allowed_min")
    if allowed_max is not None and variable > _finite_number(allowed_max, "allowed_max"):
        raise ValueError(f"assumption {assumption.get('assumption_id')} is above allowed_max")
    unit = str(assumption.get("unit", "")).strip()
    if not unit:
        raise ValueError(f"assumption {assumption.get('assumption_id')} lacks unit")
    base_context: dict[str, float] = {
        "variable_value": variable,
        "baseline_value": baseline,
        "delta": variable - baseline,
        "delta_ratio": 0.0 if baseline == 0 else (variable - baseline) / abs(baseline),
        "sensitivity_coefficient": coefficient,
    }
    formula_inputs = assumption.get("formula_inputs", {})
    if formula_inputs is not None and not isinstance(formula_inputs, dict):
        raise ValueError("formula_inputs must be an object")
    for key, value in (formula_inputs or {}).items():
        base_context[str(key)] = _finite_number(value, f"formula_inputs.{key}")
    actual_units = {
        "variable_value": unit,
        "baseline_value": unit,
        "delta": unit,
        "delta_ratio": "ratio",
        "sensitivity_coefficient": str(assumption.get("sensitivity_unit", "unitless")),
    }
    extra_units = assumption.get("formula_input_units", {}) or {}
    if not isinstance(extra_units, dict):
        raise ValueError("formula_input_units must be an object")
    actual_units.update({str(k): str(v) for k, v in extra_units.items()})
    required_inputs = formula["record"]["input_fields"]
    missing = [name for name in required_inputs if name not in base_context]
    if missing:
        raise ValueError(f"assumption {assumption.get('assumption_id')} lacks formula inputs: {', '.join(missing)}")
    for name in required_inputs:
        expected = formula["record"]["input_units"].get(name)
        actual = actual_units.get(name)
        if actual is None:
            raise ValueError(f"assumption {assumption.get('assumption_id')} lacks unit for formula input {name}")
        if str(expected) != str(actual):
            raise ValueError(f"formula unit mismatch for {name}: expected {expected}, got {actual}")
    return {name: base_context[name] for name in required_inputs}


def _validate_assumptions(
    assumptions: list[dict[str, Any]],
    formulas: dict[str, dict[str, Any]],
    table_ids: dict[str, set[str]],
) -> tuple[list[dict[str, Any]], dict[str, list[dict[str, Any]]]]:
    normalized: list[dict[str, Any]] = []
    by_scenario: dict[str, list[dict[str, Any]]] = {}
    seen: set[str] = set()
    for row in assumptions:
        assumption_id = str(row.get("assumption_id", "")).strip()
        if not assumption_id or assumption_id in seen:
            raise ValueError(f"invalid or duplicate assumption_id: {assumption_id}")
        seen.add(assumption_id)
        scenario = _normal_scenario(row.get("scenario_type") or row.get("scenario_id"))
        if scenario not in set(CANONICAL_SCENARIOS) | {"custom_user"}:
            raise ValueError(f"assumption {assumption_id} has unsupported scenario_type")
        owner = str(row.get("assumption_owner", "")).strip()
        if owner not in {"source_backed", "derived", "analyst_estimate", "user_defined", "model_default", "gap"}:
            raise ValueError(f"assumption {assumption_id} has invalid assumption_owner")
        if owner == "gap":
            continue
        if owner in {"analyst_estimate", "model_default", "user_defined"}:
            if not str(row.get("rationale", "")).strip() or not str(row.get("limitations", "")).strip():
                raise ValueError(f"assumption {assumption_id} requires rationale and limitations")
        if owner in {"source_backed", "derived"} and (not row.get("source_ids") or not row.get("evidence_ids")):
            raise ValueError(f"assumption {assumption_id} lacks source/evidence lineage")
        formula_id = str(row.get("formula_id", "")).strip()
        if not formula_id or formula_id not in formulas:
            raise ValueError(f"assumption {assumption_id} has unresolved formula_id")
        formula = formulas[formula_id]
        if formula["record"].get("compiled_status") != "validated":
            raise ValueError(f"assumption {assumption_id} references a disabled formula")
        if scenario not in formula["record"]["scenario_scope"]:
            raise ValueError(f"formula {formula_id} does not cover scenario {scenario}")
        nodes = row.get("affected_nodes", [])
        if not isinstance(nodes, list) or not nodes:
            raise ValueError(f"assumption {assumption_id} must affect at least one value-chain node")
        unresolved_nodes = sorted(str(node) for node in nodes if str(node) not in table_ids["value_chain_nodes"])
        if unresolved_nodes:
            raise ValueError(f"assumption {assumption_id} has unresolved nodes: {', '.join(unresolved_nodes)}")
        companies = row.get("affected_companies", []) or []
        if not isinstance(companies, list):
            raise ValueError("affected_companies must be an array")
        unresolved_companies = sorted(str(company) for company in companies if str(company) not in table_ids["company_universe"])
        if unresolved_companies:
            raise ValueError(f"assumption {assumption_id} has unresolved companies: {', '.join(unresolved_companies)}")
        context = _assumption_context(row, formula)
        score = _evaluate(formula["tree"], context)
        if abs(score) > 100:
            raise ValueError(f"assumption {assumption_id} produced an unbounded impact score")
        item = deepcopy(row)
        item["scenario_type"] = scenario
        item["evaluated_context"] = context
        item["node_impact_score"] = score
        normalized.append(item)
        by_scenario.setdefault(scenario, []).append(item)
    return normalized, by_scenario


def _ids(tables: dict[str, list[dict[str, Any]]]) -> dict[str, set[str]]:
    id_fields = {
        "value_chain_nodes": "node_id", "value_chain_edges": "edge_id", "company_universe": "company_id",
        "security_master": "security_id", "company_segment_exposure": "exposure_id",
        "financial_sensitivity": "financial_sensitivity_id", "opportunity_zones": "opportunity_id",
        "risks_falsifiers": "risk_falsifier_id", "event_catalysts": "event_id",
    }
    return {table: {str(row.get(field)) for row in tables.get(table, []) if row.get(field)} for table, field in id_fields.items()}


def _sim_row(
    run_id: str, industry_id: str, scenario_id: str, output_type: str, target: str,
    score: float | None, assumption_ids: list[str], logic: str, explanation: str,
    confidence: str, formula_ids: list[str], **extra: Any,
) -> dict[str, Any]:
    row = {
        "simulation_output_id": stable_id("sim", run_id, scenario_id, output_type, target, length=24),
        "run_id": run_id,
        "scenario_id": scenario_id,
        "industry_id": industry_id,
        "output_type": output_type,
        "direction": _direction(score or 0.0) if score is not None else "uncertain",
        "magnitude": _magnitude(score or 0.0) if score is not None else "unknown",
        "impact_score": round(score, 8) if score is not None else None,
        "formula_or_logic": logic,
        "formula_ids": sorted(set(formula_ids)),
        "input_assumption_ids": sorted(set(assumption_ids)),
        "output_explanation": explanation,
        "confidence_level": confidence,
        "limitations": [],
        "record_origin_type": "formula_derived",
    }
    row.update(extra)
    return row


def _build_outputs(
    run_id: str,
    industry_id: str,
    tables: dict[str, list[dict[str, Any]]],
    assumptions: list[dict[str, Any]],
    by_scenario: dict[str, list[dict[str, Any]]],
    compiled_formulas: dict[str, dict[str, Any]],
) -> tuple[dict[str, list[dict[str, Any]]], list[dict[str, Any]]]:
    outputs = {name: [] for name in OUTPUT_FILES}
    aggregate: list[dict[str, Any]] = []
    node_rows = {str(row["node_id"]): row for row in tables["value_chain_nodes"]}
    company_rows = {str(row["company_id"]): row for row in tables["company_universe"]}
    security_rows = {str(row["security_id"]): row for row in tables["security_master"]}
    risks = {str(row["risk_falsifier_id"]): row for row in tables["risks_falsifiers"]}

    node_by_scenario: dict[str, dict[str, list[dict[str, Any]]]] = {}
    for assumption in assumptions:
        scenario = assumption["scenario_type"]
        scenario_id = str(assumption.get("scenario_id") or scenario)
        formula_id = str(assumption["formula_id"])
        for node_id in assumption["affected_nodes"]:
            score = float(assumption["node_impact_score"])
            row = _sim_row(
                run_id, industry_id, scenario_id, "node_ranking", str(node_id), score,
                [str(assumption["assumption_id"])], f"formula:{formula_id}",
                f"{assumption.get('variable_name')} changes the {node_rows[str(node_id)].get('node_name')} node directionally.",
                str(assumption.get("confidence_level", "unknown")), [formula_id],
                affected_node_id=str(node_id), scenario_type=scenario,
                source_ids=assumption.get("source_ids", []), evidence_ids=assumption.get("evidence_ids", []),
            )
            outputs["node_impact_outputs"].append(row)
            aggregate.append(row)
            node_by_scenario.setdefault(scenario, {}).setdefault(str(node_id), []).append(row)

    edge_factor = {"critical": 1.0, "high": 0.8, "medium": 0.5, "low": 0.25, "unknown": 0.25}
    for scenario, node_map in node_by_scenario.items():
        for edge in tables["value_chain_edges"]:
            relevant = node_map.get(str(edge.get("from_node_id")), []) + node_map.get(str(edge.get("to_node_id")), [])
            if not relevant:
                continue
            score = sum(float(row["impact_score"]) for row in relevant) / len(relevant)
            score *= _factor(edge.get("materiality", "unknown"), edge_factor, "edge materiality")
            scenario_id = str(relevant[0]["scenario_id"])
            row = _sim_row(
                run_id, industry_id, scenario_id, "edge_impact", str(edge["edge_id"]), score,
                [aid for item in relevant for aid in item["input_assumption_ids"]],
                "builtin_edge_materiality_v1",
                f"Directional transmission through {edge.get('flow_type')} edge {edge.get('edge_id')}; no unobserved pass-through is inferred.",
                _confidence(relevant), ["builtin_edge_materiality_v1"],
                affected_edge_id=str(edge["edge_id"]), scenario_type=scenario,
                from_node_id=edge.get("from_node_id"), to_node_id=edge.get("to_node_id"),
            )
            outputs["edge_impact_outputs"].append(row)
            aggregate.append(row)

    magnitude_factor = {"high": 1.0, "medium": 0.6, "low": 0.3, "unknown": 0.0}
    direction_factor = {"benefits": 1.0, "benefit": 1.0, "positive": 1.0, "hurt": -1.0, "hurts": -1.0, "negative": -1.0, "mixed": 0.0, "uncertain": 0.0, "unknown": 0.0}
    company_by_scenario: dict[str, dict[str, list[dict[str, Any]]]] = {}
    for scenario, node_map in node_by_scenario.items():
        for exposure in tables["company_segment_exposure"]:
            node_id = str(exposure.get("node_id", ""))
            relevant = node_map.get(node_id, [])
            if not relevant:
                continue
            base_score = sum(float(row["impact_score"]) for row in relevant) / len(relevant)
            score = base_score * _factor(exposure.get("exposure_magnitude", "unknown"), magnitude_factor, "exposure magnitude")
            score *= _factor(exposure.get("exposure_direction", "unknown"), direction_factor, "exposure direction")
            company_id = str(exposure["company_id"])
            scenario_id = str(relevant[0]["scenario_id"])
            row = _sim_row(
                run_id, industry_id, scenario_id, "company_ranking", company_id, score,
                [aid for item in relevant for aid in item["input_assumption_ids"]],
                "builtin_company_exposure_v1",
                f"Node impact is bridged to {company_rows[company_id].get('company_name')} using explicit exposure direction and magnitude.",
                _confidence([exposure, *relevant]),
                ["builtin_company_exposure_v1"], affected_company_id=company_id,
                affected_node_id=node_id, scenario_type=scenario, exposure_id=exposure.get("exposure_id"),
            )
            outputs["company_impact_outputs"].append(row)
            aggregate.append(row)
            company_by_scenario.setdefault(scenario, {}).setdefault(company_id, []).append(row)
            security_id = exposure.get("security_id")
            if security_id:
                sec = _sim_row(
                    run_id, industry_id, scenario_id, "security_directional", str(security_id), score,
                    row["input_assumption_ids"], "company impact passed to security; valuation impact disabled",
                    f"Directional operating exposure for {security_rows[str(security_id)].get('ticker') or security_id}; no price target or valuation output is produced.",
                    row["confidence_level"], ["builtin_company_exposure_v1"],
                    affected_company_id=company_id, affected_security_id=str(security_id), scenario_type=scenario,
                    valuation_status="disabled_missing_live_market_data_and_human_approval",
                )
                outputs["security_impact_outputs"].append(sec)
                aggregate.append(sec)

    for scenario, company_map in company_by_scenario.items():
        for fs in tables["financial_sensitivity"]:
            company_id = str(fs.get("company_id", ""))
            relevant = company_map.get(company_id, [])
            if not relevant and fs.get("node_id"):
                node_relevant = node_by_scenario.get(scenario, {}).get(str(fs.get("node_id")), [])
                relevant = node_relevant
            if not relevant:
                continue
            score = sum(float(row["impact_score"]) for row in relevant) / len(relevant)
            sensitivity_direction = str(fs.get("sensitivity_direction", "unknown"))
            score *= _factor(sensitivity_direction, {"positive": 1.0, "negative": -1.0, "mixed": 0.0, "unknown": 0.0}, "financial sensitivity direction")
            scenario_id = str(relevant[0]["scenario_id"])
            row = _sim_row(
                run_id, industry_id, scenario_id, "financial_sensitivity", str(fs["financial_sensitivity_id"]), score,
                [aid for item in relevant for aid in item["input_assumption_ids"]],
                str(fs.get("formula_or_logic") or "explicit directional financial sensitivity bridge"),
                f"Scenario impact is bridged to {fs.get('driver_name')} with {sensitivity_direction} sensitivity.",
                str(fs.get("confidence_level", "unknown")), [],
                affected_company_id=fs.get("company_id"), affected_security_id=fs.get("security_id"),
                affected_node_id=fs.get("node_id"), scenario_type=scenario,
                financial_sensitivity_id=fs.get("financial_sensitivity_id"), driver_type=fs.get("driver_type"),
            )
            outputs["financial_sensitivity_outputs"].append(row)
            aggregate.append(row)

    impact_lookup: dict[str, dict[str, list[float]]] = {}
    for scenario in by_scenario:
        impact_lookup[scenario] = {"node": {}, "company": {}, "security": {}}  # type: ignore[assignment]
    for row in outputs["node_impact_outputs"]:
        impact_lookup[row["scenario_type"]]["node"].setdefault(str(row["affected_node_id"]), []).append(float(row["impact_score"]))
    for row in outputs["company_impact_outputs"]:
        impact_lookup[row["scenario_type"]]["company"].setdefault(str(row["affected_company_id"]), []).append(float(row["impact_score"]))
    for row in outputs["security_impact_outputs"]:
        impact_lookup[row["scenario_type"]]["security"].setdefault(str(row["affected_security_id"]), []).append(float(row["impact_score"]))

    for scenario, scenario_assumptions in by_scenario.items():
        scenario_id = str(scenario_assumptions[0].get("scenario_id") or scenario)
        scenario_nodes = [row for row in outputs["node_impact_outputs"] if row["scenario_type"] == scenario]
        scenario_companies = [row for row in outputs["company_impact_outputs"] if row["scenario_type"] == scenario]
        summary_score = sum(float(row["impact_score"]) for row in scenario_nodes) / len(scenario_nodes) if scenario_nodes else None
        report = _sim_row(
            run_id, industry_id, scenario_id, "scenario_summary", scenario, summary_score,
            [str(row["assumption_id"]) for row in scenario_assumptions],
            "aggregate of explicit assumption-driven node impacts",
            f"Scenario {scenario} contains {len(scenario_assumptions)} assumptions, {len(scenario_nodes)} node outputs, and {len(scenario_companies)} company outputs.",
            _confidence(scenario_assumptions), sorted({str(row["formula_id"]) for row in scenario_assumptions}),
            scenario_type=scenario,
            affected_node_ids=sorted({str(row["affected_node_id"]) for row in scenario_nodes}),
            affected_company_ids=sorted({str(row["affected_company_id"]) for row in scenario_companies}),
        )
        outputs["scenario_outputs"].append(report)
        aggregate.append(report)

        for opportunity in tables["opportunity_zones"]:
            falsifier_ids = opportunity.get("falsifier_ids", [])
            if not falsifier_ids or any(str(fid) not in risks for fid in falsifier_ids):
                continue
            scores: list[float] = []
            for node in opportunity.get("linked_nodes", []) or []:
                scores.extend(impact_lookup[scenario]["node"].get(str(node), []))
            for company in opportunity.get("linked_companies", []) or []:
                scores.extend(impact_lookup[scenario]["company"].get(str(company), []))
            for security in opportunity.get("linked_securities", []) or []:
                scores.extend(impact_lookup[scenario]["security"].get(str(security), []))
            score = sum(scores) / len(scores) if scores else None
            row = _sim_row(
                run_id, industry_id, scenario_id, "opportunity_change", str(opportunity["opportunity_id"]), score,
                [str(item["assumption_id"]) for item in scenario_assumptions],
                "builtin_opportunity_aggregation_v1" if scores else "no linked scenario impact available",
                f"Scenario-adjusted directional view for {opportunity.get('opportunity_name')}; this is a research output, not personal advice.",
                str(opportunity.get("confidence_level", "unknown")), ["builtin_opportunity_aggregation_v1"] if scores else [],
                opportunity_id=str(opportunity["opportunity_id"]), scenario_type=scenario,
                falsifier_ids=list(falsifier_ids), linked_impact_count=len(scores), rank_status="directional_only",
            )
            outputs["opportunity_ranking_outputs"].append(row)
            aggregate.append(row)

        for risk in tables["risks_falsifiers"]:
            if str(risk.get("record_type")) not in {"falsifier", "both"}:
                continue
            variable = risk.get("monitor_variable")
            operator = risk.get("threshold_operator")
            threshold = risk.get("threshold_value")
            triggered: bool | None = None
            matched: list[dict[str, Any]] = []
            if variable and operator and threshold is not None:
                matched = [item for item in scenario_assumptions if item.get("variable_name") == variable]
                if matched:
                    value = _finite_number(matched[0].get("variable_value"), "falsifier variable")
                    target = _finite_number(threshold, "threshold_value")
                    operations = {"lt": value < target, "lte": value <= target, "gt": value > target, "gte": value >= target, "eq": value == target}
                    if operator not in operations:
                        raise ValueError(f"unsupported threshold_operator: {operator}")
                    triggered = operations[str(operator)]
            score = -1.0 if triggered is True else (0.0 if triggered is False else None)
            row = _sim_row(
                run_id, industry_id, scenario_id, "thesis_break", str(risk["risk_falsifier_id"]), score,
                [str(item["assumption_id"]) for item in (matched or scenario_assumptions)],
                "explicit threshold evaluation" if triggered is not None else "threshold not machine-evaluable",
                f"Falsifier {risk.get('name')} is {'triggered' if triggered is True else 'not triggered' if triggered is False else 'not machine-evaluable'} in {scenario}.",
                _confidence(matched or scenario_assumptions), [],
                risk_falsifier_id=str(risk["risk_falsifier_id"]), scenario_type=scenario,
                trigger_status="triggered" if triggered is True else "not_triggered" if triggered is False else "not_evaluable",
                measurable_threshold=risk.get("measurable_threshold"),
            )
            outputs["thesis_break_outputs"].append(row)
            aggregate.append(row)

    for assumption in assumptions:
        formula_id = str(assumption["formula_id"])
        low = assumption.get("range_low", assumption.get("allowed_min"))
        high = assumption.get("range_high", assumption.get("allowed_max"))
        if low is None or high is None:
            continue
        formula = compiled_formulas[formula_id]
        endpoint_scores: dict[str, float] = {}
        for label, value in (("low", low), ("base", assumption["variable_value"]), ("high", high)):
            variant = deepcopy(assumption)
            variant["variable_value"] = value
            context = _assumption_context(variant, formula)
            endpoint_scores[label] = _evaluate(formula["tree"], context)
        outputs["sensitivity_outputs"].append({
            "simulation_output_id": stable_id("sim", run_id, str(assumption["scenario_id"]), "sensitivity", str(assumption["assumption_id"]), length=24),
            "run_id": run_id,
            "scenario_id": assumption["scenario_id"],
            "industry_id": industry_id,
            "output_type": "one_way_sensitivity",
            "assumption_id": assumption["assumption_id"],
            "variable_name": assumption["variable_name"],
            "low_value": low,
            "base_value": assumption["variable_value"],
            "high_value": high,
            "low_output_score": round(endpoint_scores["low"], 8),
            "base_output_score": round(endpoint_scores["base"], 8),
            "high_output_score": round(endpoint_scores["high"], 8),
            "unit": assumption["unit"],
            "formula_ids": [formula_id],
            "input_assumption_ids": [assumption["assumption_id"]],
            "direction": "mixed",
            "magnitude": "range",
            "formula_or_logic": f"one-way bounded input range through formula:{formula_id}",
            "output_explanation": "Low, base, and high bounds are deterministically recomputed; Stage 5 does not infer probabilities.",
            "confidence_level": assumption.get("confidence_level", "unknown"),
            "limitations": ["Two-way and tornado ranking require at least two calibrated assumptions."],
            "record_origin_type": "formula_derived",
        })
    aggregate.extend(outputs["sensitivity_outputs"])
    return outputs, aggregate


def _simulation_gaps(
    tables: dict[str, list[dict[str, Any]]],
    scenarios_present: set[str],
    outputs: dict[str, list[dict[str, Any]]],
) -> list[dict[str, Any]]:
    gaps: list[dict[str, Any]] = []

    def add(code: str, severity: str, reason: str, next_action: str, blocker: bool = False) -> None:
        gaps.append({
            "gap_id": stable_id("sim_gap", code, reason),
            "gap_code": code,
            "severity": severity,
            "gap_reason": reason,
            "next_action": next_action,
            "blocks_simulation": blocker,
            "status": "open",
        })

    if not tables["value_chain_nodes"]:
        add("missing_value_chain_nodes", "blocker", "Value-chain nodes are absent.", "Populate evidence-backed value-chain nodes.", True)
    if not tables["value_chain_edges"]:
        add("missing_value_chain_edges", "blocker", "Value-chain edges are absent, so transmission paths cannot be audited.", "Populate evidence-backed value-chain edges.", True)
    if not tables["money_flows"]:
        add("missing_money_flows", "blocker", "Money-flow links are absent, so economic propagation is incomplete.", "Populate payer/receiver money-flow records.", True)
    if not tables["formula_registry"]:
        add("missing_formula_registry", "blocker", "No executable formula registry is present.", "Populate and validate at least one transparent formula.", True)
    if not tables["scenario_assumptions"]:
        add("missing_scenario_assumptions", "blocker", "No scenario assumptions are present.", "Populate explicit scenario assumptions.", True)
    for scenario in CANONICAL_SCENARIOS:
        if scenario not in scenarios_present:
            add(f"missing_{scenario}_scenario", "blocker", f"Canonical {scenario} scenario is absent.", f"Add evidence-linked {scenario} assumptions.", True)
    if tables["company_universe"] and not tables["company_segment_exposure"]:
        add("missing_company_exposure", "blocker", "Company universe exists without node/segment exposure mapping.", "Populate company_segment_exposure.", True)
    if tables["security_master"] and not outputs["security_impact_outputs"]:
        add("missing_security_propagation", "blocker", "Securities exist but no scenario impact reached them.", "Complete company/security exposure mapping.", True)
    if not tables["opportunity_zones"]:
        add("missing_opportunity_zones", "blocker", "No opportunity zones are available for scenario ranking.", "Populate downside-balanced opportunity zones with falsifiers.", True)
    if not tables["risks_falsifiers"]:
        add("missing_risks_falsifiers", "blocker", "No risks or falsifiers are present.", "Populate measurable risks and falsifiers.", True)
    elif any(not row.get("measurable_threshold") for row in tables["risks_falsifiers"] if row.get("record_type") in {"falsifier", "both"}):
        add("non_machine_readable_falsifiers", "major", "One or more falsifiers lack a measurable threshold.", "Add monitor_variable, threshold operator/value, and measurable threshold.")
    if not tables["financial_sensitivity"] and tables["security_master"]:
        add("missing_financial_bridge", "major", "Security exposure lacks financial sensitivity bridges.", "Populate revenue, margin, cash-flow, or valuation sensitivities.")
    add("valuation_disabled", "major", "Valuation and price-target outputs are disabled without live market provenance and human approval.", "Provide current market data provenance, bounded valuation method, and explicit approval.")
    probabilities = [row.get("scenario_probability") for row in tables["scenario_assumptions"] if row.get("scenario_probability") is not None]
    if not probabilities:
        add("expected_value_disabled", "minor", "Expected-value output is disabled because scenario probabilities are absent.", "Add explicit, labeled, bounded probabilities only if defensible.")
    if len(outputs["sensitivity_outputs"]) < 2:
        add("two_way_sensitivity_unavailable", "major", "Too few bounded calibrated assumptions exist for two-way sensitivity.", "Add bounded ranges for at least two key assumptions.")
    return gaps


def _merge_gaps(root: Path, industry_id: str, simulation_gaps: list[dict[str, Any]]) -> list[dict[str, Any]]:
    path = root / "gap_register.json"
    prior = _load(path)
    if not isinstance(prior, list):
        raise ValueError("gap register is malformed")
    retained = [deepcopy(row) for row in prior if row.get("category") != "simulation_readiness"]
    now = _now()
    for gap in simulation_gaps:
        retained.append({
            "gap_id": gap["gap_id"],
            "industry_id": industry_id,
            "gap_name": str(gap["gap_code"]).replace("_", " ").title(),
            "gap_reason": gap["gap_reason"],
            "severity": gap["severity"],
            "affected_output": ["simulation", "scenario_simulator", "opportunity_zones"],
            "next_action": gap["next_action"],
            "blocks_institutional_status": gap["blocks_simulation"],
            "created_at": now,
            "status": "open",
            "category": "simulation_readiness",
        })
    # Close generic missing-table gaps when Stage 5 has materially populated the table.
    table_paths = {"formula_registry", "scenario_assumptions", "simulation_outputs"}
    for row in retained:
        if row.get("missing_table") in table_paths:
            table = str(row["missing_table"])
            table_rows = _load(root / "tables" / f"{table}.json")
            if table_rows:
                row["status"] = "closed"
                row["closed_at"] = now
                row["closure_reason"] = "Stage 5 populated the required table."
    return retained


def _read_tables(root: Path, dataset: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    required = (
        "value_chain_nodes", "value_chain_edges", "money_flows", "company_universe", "security_master",
        "company_segment_exposure", "financial_sensitivity", "event_catalysts", "scenario_assumptions",
        "formula_registry", "simulation_outputs", "opportunity_zones", "risks_falsifiers",
    )
    tables = dataset.get("tables")
    if not isinstance(tables, dict):
        raise ValueError("industry_dataset tables are malformed")
    out: dict[str, list[dict[str, Any]]] = {}
    for table in required:
        disk = _load(root / "tables" / f"{table}.json")
        if not isinstance(disk, list):
            raise ValueError(f"canonical table is malformed: {table}")
        if disk != tables.get(table):
            raise ValueError(f"industry_dataset is not synchronized with canonical table: {table}")
        out[table] = disk
    return out


def _update_artifacts(root: Path, status: str, output_counts: dict[str, int]) -> None:
    graph = _load(root / "artifact_graph.json")
    graph["simulation"] = {
        "artifact": "simulation_readiness.json",
        "status": status,
        "required": True,
        "output_tables": {name: {"artifact": f"simulation/{name}.json", "row_count": count} for name, count in output_counts.items()},
    }
    for item in graph.get("canonical_tables", []):
        if item.get("artifact") == "tables/simulation_outputs.json":
            item["status"] = "populated" if output_counts.get("simulation_outputs", 0) else "empty_with_gap"
            item["row_count"] = output_counts.get("simulation_outputs", 0)
    packet = graph.get("packet", {})
    blocked = [item for item in packet.get("blocked_by", []) if item != "analytical_transforms"]
    if status != "ready_basic_deterministic":
        blocked.append("analytical_transforms")
    packet["blocked_by"] = sorted(set(blocked))
    write_json_atomic(root / "artifact_graph.json", graph)


def _run_unlocked(root: Path) -> dict[str, Any]:
    dataset_path = root / "industry_dataset.json"
    if not dataset_path.is_file():
        raise ValueError("industry_dataset.json is required before simulation")
    dataset = _load(dataset_path)
    if dataset.get("production_claim") is not False:
        raise ValueError("Stage 5 only accepts fail-closed non-production datasets")
    tables = _read_tables(root, dataset)
    run_id = str(dataset.get("run_id", ""))
    industry_id = str(dataset.get("industry_id", ""))
    if not run_id or not industry_id:
        raise ValueError("industry_dataset lacks run_id or industry_id")

    compiled_formulas: dict[str, dict[str, Any]] = {}
    compiled_serialized: list[dict[str, Any]] = deepcopy(_BUILTIN_FORMULAS)
    assumptions: list[dict[str, Any]] = []
    by_scenario: dict[str, list[dict[str, Any]]] = {}
    if tables["formula_registry"]:
        compiled_formulas, compiled_serialized = _formula_registry(tables["formula_registry"])
    table_ids = _ids(tables)
    if tables["scenario_assumptions"] and compiled_formulas:
        assumptions, by_scenario = _validate_assumptions(tables["scenario_assumptions"], compiled_formulas, table_ids)

    outputs = {name: [] for name in OUTPUT_FILES}
    aggregate: list[dict[str, Any]] = []
    if assumptions:
        outputs, aggregate = _build_outputs(run_id, industry_id, tables, assumptions, by_scenario, compiled_formulas)

    gaps = _simulation_gaps(tables, set(by_scenario), outputs)
    blockers = [gap for gap in gaps if gap["blocks_simulation"]]
    required_scenarios_present = all(scenario in by_scenario for scenario in CANONICAL_SCENARIOS)
    has_node_outputs = bool(outputs["node_impact_outputs"])
    has_company_requirement = bool(tables["company_universe"])
    company_ok = not has_company_requirement or bool(outputs["company_impact_outputs"])
    if not blockers and required_scenarios_present and has_node_outputs and company_ok:
        level = 2
        label = "Basic Deterministic"
        status = "ready_basic_deterministic"
        maturity = "basic_deterministic_with_visible_gaps"
    else:
        level = 0
        label = "No Valid Simulation"
        status = "disabled_insufficient_inputs"
        maturity = "simulation_disabled_with_gaps"
        # Disabled simulation cannot leave analytical rows that look usable.
        outputs = {name: [] for name in OUTPUT_FILES}
        aggregate = []

    gap_rows: list[dict[str, Any]] = []
    for gap in gaps:
        row = _sim_row(
            run_id, industry_id, "simulation_readiness", "simulation_gap", str(gap["gap_id"]), None, [],
            "fail-closed simulation readiness gate", gap["gap_reason"], "unknown", [],
            gap_id=gap["gap_id"], gap_code=gap["gap_code"], severity=gap["severity"],
            blocks_simulation=gap["blocks_simulation"], next_action=gap["next_action"],
        )
        gap_rows.append(row)
    outputs["simulation_gap_outputs"] = gap_rows
    aggregate.extend(gap_rows)

    sim_dir = root / "simulation"
    sim_dir.mkdir(parents=True, exist_ok=True)
    if sim_dir.is_symlink():
        raise ValueError("simulation output directory must not be a symlink")
    for name in OUTPUT_FILES:
        write_json_atomic(sim_dir / f"{name}.json", outputs[name])
    write_json_atomic(sim_dir / "formula_registry_compiled.json", compiled_serialized)
    write_json_atomic(sim_dir / "scenario_reports.json", outputs["scenario_outputs"])
    write_json_atomic(root / "tables" / "simulation_outputs.json", aggregate)

    merged_gaps = _merge_gaps(root, industry_id, gaps)
    write_json_atomic(root / "gap_register.json", merged_gaps)
    write_json_atomic(root / "tables" / "gap_register.json", merged_gaps)

    source_backed = sum(1 for row in assumptions if row.get("assumption_owner") == "source_backed")
    valuation_status = "disabled_missing_live_market_data_and_human_approval"
    expected_value_status = "disabled_missing_valid_probabilities"
    readiness = {
        "schema_version": "phase16-stage5-v1",
        "run_id": run_id,
        "industry_id": industry_id,
        "generated_at": _now(),
        "status": status,
        "simulation_maturity_level": level,
        "simulation_maturity_label": label,
        "production_claim": False,
        "canonical_scenarios_required": list(CANONICAL_SCENARIOS),
        "canonical_scenarios_present": sorted(set(by_scenario) & set(CANONICAL_SCENARIOS)),
        "assumption_count": len(assumptions),
        "source_backed_assumption_count": source_backed,
        "active_formula_count": sum(1 for item in compiled_serialized if item.get("compiled_status") == "validated"),
        "compiled_formula_count_including_builtins": len(compiled_serialized),
        "output_counts": {name: len(outputs[name]) for name in OUTPUT_FILES},
        "aggregate_simulation_output_count": len(aggregate),
        "usable_simulation_output_count": len(aggregate) - len(outputs["simulation_gap_outputs"]),
        "valuation_status": valuation_status,
        "expected_value_status": expected_value_status,
        "blocker_count": len(blockers),
        "major_gap_count": sum(1 for gap in gaps if gap["severity"] == "major"),
        "gaps": gaps,
        "limitations": [
            "Stage 5 outputs are directional deterministic research transforms, not personalized investment advice.",
            "No valuation or price-target output is permitted without live market provenance and human approval.",
            "The engine does not infer probabilities, pass-through coefficients, or portfolio weights.",
        ],
    }
    readiness_bytes = json.dumps(readiness, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    readiness["readiness_sha256"] = hashlib.sha256(readiness_bytes).hexdigest()
    write_json_atomic(root / "simulation_readiness.json", readiness)

    dataset["schema_version"] = "phase16-stage5-v1"
    dataset["generated_at"] = _now()
    dataset["maturity"] = maturity
    dataset["tables"]["simulation_outputs"] = aggregate
    dataset["tables"]["gap_register"] = merged_gaps
    dataset["analytical_transforms"] = {
        "simulation_readiness": readiness,
        "compiled_formula_registry_path": "simulation/formula_registry_compiled.json",
        "scenario_reports_path": "simulation/scenario_reports.json",
        "output_table_paths": {name: f"simulation/{name}.json" for name in OUTPUT_FILES},
    }
    dataset["gap_summary"] = {
        "open": sum(1 for gap in merged_gaps if gap.get("status") == "open"),
        "blockers": sum(1 for gap in merged_gaps if gap.get("status") == "open" and gap.get("blocks_institutional_status") is True),
        "major": sum(1 for gap in merged_gaps if gap.get("status") == "open" and gap.get("severity") == "major"),
    }
    lineage_entries = _load(root / "field_lineage.json")
    if not isinstance(lineage_entries, list):
        raise ValueError("field_lineage.json is malformed")
    completeness = _completeness(dataset["tables"], lineage_entries)
    dataset["completeness"] = completeness
    write_json_atomic(root / "completeness_report.json", completeness)
    _update_artifact_graph(root, dataset["tables"], completeness)
    dataset.pop("dataset_sha256", None)
    dataset_bytes = json.dumps(dataset, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    dataset["dataset_sha256"] = hashlib.sha256(dataset_bytes).hexdigest()
    write_json_atomic(dataset_path, dataset)

    state = _load(root / "run_state.json")
    state.update({
        "status": status,
        "maturity": maturity,
        "simulation_maturity_level": level,
        "simulation_output_count": len(aggregate),
        "simulation_blocker_count": len(blockers),
        "populated_required_table_count": completeness["populated_required_table_count"],
        "required_table_count": completeness["required_table_count"],
        "open_gap_count": dataset["gap_summary"]["open"],
        "blocker_gap_count": dataset["gap_summary"]["blockers"],
        "updated_at": _now(),
    })
    write_json_atomic(root / "run_state.json", state)
    progress = _load(root / "progress_ledger.json")
    progress.update({
        "status": status,
        "progress_percent": 70 if level >= 2 else min(int(progress.get("progress_percent", 0)), 60),
        "progress_basis": "Artifact-backed analytical-transform progress; simulation advances only when formulas, canonical scenarios, value-chain propagation, exposure mapping, and falsifiers pass.",
        "simulation_maturity_level": level,
        "simulation_output_count": len(aggregate),
        "simulation_blocker_count": len(blockers),
        "populated_required_table_count": completeness["populated_required_table_count"],
        "required_table_count": completeness["required_table_count"],
        "open_gap_count": dataset["gap_summary"]["open"],
        "blocker_gap_count": dataset["gap_summary"]["blockers"],
        "blocked_steps": ["validation", "html_packet", "final_packaging"] if level >= 2 else ["simulation", "validation", "html_packet", "final_packaging"],
    })
    completed = list(progress.get("completed_steps", []))
    for step in ["formula_registry_validated", "scenario_assumptions_validated", "simulation_readiness_written"]:
        if step not in completed:
            completed.append(step)
    if level >= 2:
        for step in ["node_impacts_generated", "company_security_propagation_generated", "opportunity_falsifier_links_generated", "directional_simulation_outputs_written"]:
            if step not in completed:
                completed.append(step)
    progress["completed_steps"] = completed
    write_json_atomic(root / "progress_ledger.json", progress)
    _update_artifacts(root, status, {**{name: len(outputs[name]) for name in OUTPUT_FILES}, "simulation_outputs": len(aggregate)})

    write_text_atomic(root / "final_summary.md", f"""# Industry Intelligence run summary

- **Run ID:** `{run_id}`
- **Status:** `{status}`
- **Maturity:** `{maturity}`
- **Simulation maturity:** Level {level} — {label}
- **Canonical scenarios present:** {len(set(by_scenario) & set(CANONICAL_SCENARIOS))} / {len(CANONICAL_SCENARIOS)}
- **Validated assumptions:** {len(assumptions)}
- **Aggregate simulation outputs:** {len(aggregate)}
- **Simulation blockers:** {len(blockers)}
- **Valuation output:** disabled without live provenance and human approval
- **HTML packet:** not generated
- **Production claim:** false

Stage 5 uses only explicit canonical assumptions, versioned formulas, value-chain links, company/security exposure, and falsifiers. Missing calibration produces a visible disabled state rather than a decorative simulator.
""")
    return {
        "status": status,
        "simulation_maturity_level": level,
        "simulation_maturity_label": label,
        "canonical_scenarios_present": len(set(by_scenario) & set(CANONICAL_SCENARIOS)),
        "assumption_count": len(assumptions),
        "aggregate_simulation_output_count": len(aggregate),
        "usable_simulation_output_count": len(aggregate) - len(outputs["simulation_gap_outputs"]),
        "node_output_count": len(outputs["node_impact_outputs"]),
        "company_output_count": len(outputs["company_impact_outputs"]),
        "security_output_count": len(outputs["security_impact_outputs"]),
        "opportunity_output_count": len(outputs["opportunity_ranking_outputs"]),
        "thesis_break_output_count": len(outputs["thesis_break_outputs"]),
        "blocker_count": len(blockers),
        "valuation_status": valuation_status,
        "readiness_sha256": readiness["readiness_sha256"],
        "dataset_sha256": dataset["dataset_sha256"],
    }


def prepare_simulation(workspace: str | Path) -> dict[str, Any]:
    root = validate_workspace_path(workspace)
    transaction_id = stable_id("simulation_txn", str(root.resolve()), _now(), length=20)
    journal = root / "simulation_transaction_journal.json"
    with _simulation_lock(root):
        write_json_atomic(journal, {"transaction_id": transaction_id, "status": "started", "started_at": _now()})
        try:
            result = _run_unlocked(root)
        except Exception as exc:
            write_json_atomic(journal, {"transaction_id": transaction_id, "status": "failed", "failed_at": _now(), "error": str(exc)})
            raise
        write_json_atomic(journal, {"transaction_id": transaction_id, "status": "completed", "completed_at": _now(), "result": result})
        return result
