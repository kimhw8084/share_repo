from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class SourceCandidate:
    url: str
    title: str
    publisher: str
    publication_date: str | None = None
    snippet: str | None = None
    source_family: str | None = None
    provider_result_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ContentSnapshot:
    content: bytes
    content_type: str
    fetched_at: str
    final_url: str
    status_code: int
    metadata: dict[str, Any] = field(default_factory=dict)


class SearchProvider(ABC):
    @abstractmethod
    def search(self, query: str, *, max_results: int = 10) -> list[SourceCandidate]:
        raise NotImplementedError


class SnapshotProvider(ABC):
    @abstractmethod
    def fetch(self, url: str) -> ContentSnapshot:
        raise NotImplementedError
