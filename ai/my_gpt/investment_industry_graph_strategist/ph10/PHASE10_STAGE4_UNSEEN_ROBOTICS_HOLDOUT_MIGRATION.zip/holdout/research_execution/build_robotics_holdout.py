from __future__ import annotations
import json,re,sys,subprocess
from pathlib import Path
from datetime import datetime, timezone
sys.path.insert(0,'/mnt/data/p10s4_work/engine/src')
from industry_intel_engine.data_contract import TABLE_SPECS
from industry_intel_engine.grounding import contains_generated_language

W=Path('/mnt/data/p10s4_robotics'); OUT=Path('/mnt/data/p10s4_research'); CLI='/mnt/data/p10s4_venv/bin/industry-intel-engine'
industry_id='ind_02a11dc20cdb'
ledger=json.loads((W/'source_ledger.json').read_text())
by_title={r['title']:r for r in ledger}
texts={}
for r in ledger:
 p=W/(r['snapshot']['relative_path'])
 texts[r['title']]=p.read_text(encoding='utf-8',errors='replace')

def candidates(title):
 raw=texts[title]; out=[]
 for line in raw.splitlines():
  x=line.strip()
  if len(x)<35 or len(x)>420 or raw.count(x)!=1: continue
  if contains_generated_language(x): continue
  if re.search(r'cookie policy|privacy policy|all rights reserved|annual report pursuant|forward-looking statements|table of contents|copyright',x,re.I): continue
  if not re.search(r'[A-Za-z\u4e00-\u9fff]',x): continue
  out.append(x)
 return out
pools={t:candidates(t) for t in by_title}
used={t:set() for t in by_title}
def pick(title, keywords=()):
 pool=pools[title]; keys=[k.lower() for k in keywords]
 ranked=[]
 for x in pool:
  low=x.lower(); score=sum(1 for k in keys if k in low)
  if x not in used[title]: ranked.append((score,x))
 if not ranked:
  ranked=[(sum(1 for k in keys if k in x.lower()),x) for x in pool]
 if not ranked: raise RuntimeError(f'no candidate lines for {title}')
 ranked.sort(key=lambda a:(a[0],len(a[1])),reverse=True)
 x=ranked[0][1]; used[title].add(x); return x

# Source aliases
IFR='World Robotics 2025 Industrial Robots'; CENSUS='2022 Economic Census Robotics Methodology'; BLS='Automation and robots in food manufacturing'; CHINA='China industrial robot output 2020-2025'; OSHA='OSHA Robotics Directive Cancellation and Current Safety Framework'; EC='What Future for European Robotics'; METI='Industrial Structure in 2040 Led by Growth Investment'; MIIT='Smart Robot SME Digital Transformation Practice'; JARA='Japan Robot Association Annual Activity Report'; NIST='Towards an Understanding of Robotic Bin-Picking Throughput'; OECD='Industrial Robotics and the Global Organisation of Production'; UR='Universal Robots Global Compliance 2025'; ABB='ABB Capital Markets Day 2025 Automation'; FANUC='FANUC Integrated Report 2025'; FANUC_RES='FANUC Results for Fiscal Year Ended March 2026'; YASK='Yaskawa Report 2025'; YASK_RES='Yaskawa Fiscal 2025 Results'; SIEM='Siemens Annual Financial Report 2025'; ROCK='Rockwell Automation Annual Report 2025'; SEC='Rockwell Automation Annual Report filed with SEC'; KUKA='KUKA Annual Report 2025'; TER='Teradyne Annual Report to Shareholders 2025'

proposals=[]; record_specs=[]
def record(table, data, source_title, keywords=(), lineage_fields=None, evidence_type='direct_quote'):
 quote=pick(source_title,keywords)
 fields=list(lineage_fields or TABLE_SPECS[table].lineage_required_fields)
 desc=[]
 for field in fields:
  proposals.append({'source_id':by_title[source_title]['source_id'],'claim':quote,'quote':quote,'linked_table':table,'linked_field':field,'evidence_type':evidence_type,'as_of_date':by_title[source_title].get('publication_date') or '2026-07-28','conflict_status':'none'})
  desc.append((field,by_title[source_title]['source_id'],quote))
 record_specs.append((table,data,desc))

record('industry_boundary',{'industry_id':industry_id,'industry_name_input':'Industrial robotics and factory automation','resolved_industry_name':'Industrial Robotics and Factory Automation','definition':'Industrial and collaborative robot hardware, motion control, machine vision, factory automation software, systems integration, safety, and recurring service used in manufacturing and logistics automation.','included_scope':['industrial robot arms and controllers','collaborative robots and autonomous mobile robots','machine vision and end-of-arm tooling','PLC, motion control, drives and factory automation software','systems integration, maintenance and aftermarket service'],'excluded_scope':['consumer robots','pure warehouse software without automation hardware exposure','military autonomous systems','general-purpose AI without factory deployment'],'geographic_scope':'Global, with United States, China, Japan, and Europe focus','time_horizon':'1m-3y','investability_scope':'public_and_private','boundary_confidence':'high'},CENSUS,('industrial robots','official federal statistics'))
for sid,name,definition,source,kw in [
 ('seg_robot','Industrial robot and cobot hardware','Robot arms, cobots, controllers and integrated robot cells.',IFR,('industrial robots','robot')),
 ('seg_controls','Motion control and factory automation','Servo motors, drives, PLCs, CNCs, safety and industrial control platforms.',YASK,('motion control','servo')),
 ('seg_integration','Systems integration, software and lifecycle service','Engineering, programming, simulation, digital twins, installation, maintenance and aftermarket support.',KUKA,('automation','systems'))]:
 record('industry_segments',{'segment_id':sid,'industry_id':industry_id,'segment_name':name,'segment_dimension':'product_and_business_model','definition':definition},source,kw)

nodes=[
 ('node_components','Component and sensor suppliers','upstream_supplier','Supply motors, drives, reducers, sensors, semiconductors, vision and safety components.','Enable robot performance and constrain cost, lead time and reliability.',NIST,('3D imaging','sensors')),
 ('node_oem','Robot and automation OEMs','manufacturer','Design and manufacture robots, controllers, automation hardware and software.','Capture product revenue, installed-base economics and technology differentiation.',ABB,('automation','industrial')),
 ('node_integrator','System integrators and distributors','channel_and_integrator','Engineer, program, install and support application-specific automation systems.','Convert components into working production cells and own customer implementation risk.',KUKA,('automated systems','solutions')),
 ('node_customer','Manufacturing and logistics customers','end_customer','Automotive, electronics, machinery, food, metals, logistics and other factories purchase automation.','Fund capital spending and realize productivity, quality and labor benefits.',BLS,('plants used robots','output'))]
for row in nodes: record('value_chain_nodes',{'node_id':row[0],'industry_id':industry_id,'node_name':row[1],'node_type':row[2],'node_description':row[3],'economic_role':row[4]},row[5],row[6])
for eid,frm,to,flow,desc,src,kw in [
 ('edge_comp_oem','node_components','node_oem','physical_and_technical','Components, sensors and software are incorporated into robot platforms.',NIST,('bin-picking','imaging')),
 ('edge_oem_integrator','node_oem','node_integrator','product_and_knowledge','Robot platforms, controllers, application software and training flow to integrators.',ABB,('integration','automation')),
 ('edge_integrator_customer','node_integrator','node_customer','project_delivery','Integrated cells, programming, commissioning and support flow to factories.',KUKA,('manufacturing cells','automated systems'))]:
 record('value_chain_edges',{'edge_id':eid,'industry_id':industry_id,'from_node_id':frm,'to_node_id':to,'flow_type':flow,'flow_description':desc,'directionality':'one_way_with_feedback','materiality':'critical'},src,kw)
for mid,pay,recv,what,src,kw in [
 ('mf_customer_integrator','node_customer','node_integrator','Engineering, integration, installation and lifecycle service.',KUKA,('sales','service')),
 ('mf_integrator_oem','node_integrator','node_oem','Robot hardware, controllers, software licenses and training.',ABB,('automation','revenues'))]:
 record('money_flows',{'money_flow_id':mid,'industry_id':industry_id,'payer_node_id':pay,'receiver_node_id':recv,'payment_for':what},src,kw)
for pid,node,desc,att,src,kw in [
 ('pool_oem','node_oem','Differentiated robot platforms, motion control, software and installed-base aftermarket.','medium_to_high',FANUC,('service','factory automation')),
 ('pool_integrator','node_integrator','Application engineering and integration value in complex, safety-critical deployments.','medium',KUKA,('automation solutions','systems'))]:
 record('profit_pools',{'profit_pool_id':pid,'industry_id':industry_id,'node_id':node,'profit_pool_description':desc,'relative_attractiveness':att,'barriers_to_entry':'application knowledge, installed base, safety certification and customer qualification'},src,kw)
for cid,cat,mat,src,kw in [
 ('cost_rnd','research_and_development','high',YASK,('research','development')),
 ('cost_components','precision_components_and_electronics','high',FANUC,('cost','components')),
 ('cost_service','integration_and_field_service_labor','medium',KUKA,('employees','service'))]:
 record('cost_structure',{'cost_id':cid,'industry_id':industry_id,'cost_category':cat,'materiality':mat,'fixed_or_variable':'mixed'},src,kw)
for did,name,typ,desc,direction,horizon,src,kw in [
 ('demand_labor','Labor scarcity and wage pressure','labor','Automation substitutes for difficult-to-staff tasks while complementing skilled labor.','positive','1-3y',BLS,('robots','employment')),
 ('demand_quality','Quality, throughput and flexibility','operational','Manufacturers adopt automation to improve repeatability, cycle time, throughput and quality.','positive','3-24m',NIST,('throughput','cycle time')),
 ('demand_china','China smart-factory investment','geographic_policy','Rapid industrial-robot output and smart-factory deployment expand the addressable installed base.','positive','1-3y',CHINA,('工业机器人产量','智能工厂'))]:
 record('demand_drivers',{'demand_driver_id':did,'industry_id':industry_id,'driver_name':name,'driver_type':typ,'description':desc,'direction':direction,'time_horizon':horizon,'confidence_level':'high'},src,kw)
for cid,group,direct,src,kw in [
 ('cust_auto','Automotive and battery manufacturing','direct',IFR,('automotive','installations')),
 ('cust_elec','Electronics and precision assembly','direct',CHINA,('精密装配','质量检测')),
 ('cust_food','Food and beverage manufacturing','direct',BLS,('food manufacturing plants','robots'))]:
 record('end_customers',{'customer_id':cid,'industry_id':industry_id,'customer_group':group,'direct_or_final':direct,'purchase_criteria':['throughput','quality','payback','safety','integration risk']},src,kw)
for cid,name,typ,severity,src,kw in [
 ('constraint_integration','Systems-integration and skilled-labor capacity','labor_and_execution','high',KUKA,('employees','automation')),
 ('constraint_components','Precision component and electronics availability','supply_chain','medium',FANUC_RES,('supply','demand')),
 ('constraint_safety','Safety validation and standards compliance','regulatory_and_technical','high',UR,('safety','compliance'))]:
 record('supply_constraints',{'constraint_id':cid,'industry_id':industry_id,'constraint_name':name,'constraint_type':typ,'severity':severity,'affected_nodes':['node_oem','node_integrator']},src,kw)
record('competitive_structure',{'competitive_structure_id':'comp_global','industry_id':industry_id,'market_structure':'global oligopoly in robot OEMs with fragmented integration','competitive_description':'Large Japanese, European and U.S. automation vendors compete on installed base, controls, application breadth, service and regional channels, while integrators remain fragmented.','concentration_level':'medium_to_high','barriers_to_entry':'precision engineering, safety certification, software, service networks and customer qualification','rivalry_intensity':'high'},IFR,('manufacturers','installations'))
for rid,name,jur,typ,status,src,kw in [
 ('reg_osha','OSHA industrial robot system safety framework','United States','workplace_safety','active',OSHA,('Industrial Robot Systems','Safety')),
 ('reg_eu','EU machinery, AI and robotics policy framework','European Union','product_safety_and_ai_policy','evolving',EC,('policy','robotics')),
 ('reg_japan','Japan industrial growth and robot strategy','Japan','industrial_policy','active',METI,('industrial robots','2040'))]:
 record('regulation_policy',{'regulation_id':rid,'industry_id':industry_id,'regulation_name':name,'jurisdiction':jur,'regulation_type':typ,'status':status,'affected_nodes':['node_oem','node_integrator']},src,kw,evidence_type='policy_fact')
for tid,name,desc,src,kw in [
 ('tech_vision','3D machine vision and bin picking','Standards, perception and cycle-time measurement expand automation into unstructured picking tasks.',NIST,('bin-picking vision system','throughput')),
 ('tech_cobot','Collaborative robots and safety functions','Cobot architectures target flexible applications with added safety functions and lower integration barriers.',UR,('collaborative','safety functions')),
 ('tech_ai','AI-enabled adaptive automation','Machine learning, digital twins and industrial data can improve programming, inspection, optimization and autonomy.',SIEM,('automation and digitalization','software'))]:
 record('technology_disruption',{'technology_id':tid,'industry_id':industry_id,'technology_name':name,'description':desc,'maturity_stage':'commercial_with_ongoing_development'},src,kw)

companies=[
 ('co_abb','ABB','public','Industrial automation and robotics supplier with industrial robots, cobots, AMRs, controllers, software and services.','sec_abb','ABBN','SIX',ABB,('ABB','Automation')),
 ('co_fanuc','FANUC','public','Factory automation, robots, CNC and robomachine supplier with a large installed base.','sec_fanuc','6954','TSE',FANUC,('FANUC','automation')),
 ('co_yaskawa','Yaskawa Electric','public','Motion control, robotics and systems-engineering supplier.','sec_yask','6506','TSE',YASK,('YASKAWA','business')),
 ('co_siemens','Siemens','public','Digital Industries automation, drives, software and industrial digitalization platform.','sec_siem','SIE','XETRA',SIEM,('Siemens','automation')),
 ('co_rockwell','Rockwell Automation','public','Industrial automation hardware, software and lifecycle services supplier.','sec_rock','ROK','NYSE',ROCK,('Rockwell Automation','sales')),
 ('co_kuka','KUKA','private_subsidiary','Robots, AMRs, cells and fully automated systems owned by Midea.','sec_kuka_parent','000333','SZSE',KUKA,('KUKA','automation')),
 ('co_teradyne','Teradyne Robotics','public_segment','Collaborative and mobile robotics portfolio including Universal Robots and MiR.','sec_ter','TER','NASDAQ',TER,('Teradyne','Robotics Group'))]
for co,name,own,biz,sec,ticker,exch,src,kw in companies:
 record('company_universe',{'company_id':co,'company_name':name,'ownership_type':own,'business_description':biz,'value_chain_node_ids':['node_oem'],'industry_relevance':'high'},src,kw,evidence_type='company_disclosure')
 record('security_master',{'security_id':sec,'company_id':co,'ticker':ticker,'exchange':exch,'security_type':'equity'},src,kw,evidence_type='company_disclosure')
 record('company_segment_exposure',{'exposure_id':'exp_'+co,'company_id':co,'security_id':sec,'industry_id':industry_id,'segment_id':'seg_robot' if co not in {'co_siemens','co_rockwell'} else 'seg_controls','node_id':'node_oem','exposure_type':'direct','exposure_direction':'benefits','exposure_magnitude':'high' if co in {'co_fanuc','co_yaskawa','co_kuka','co_teradyne'} else 'medium','confidence_level':'high'},src,kw,evidence_type='company_disclosure')
 sensitivity_src = SEC if co == 'co_rockwell' else src
 sensitivity_kw = ('NET INCOME ATTRIBUTABLE TO ROCKWELL AUTOMATION',) if co == 'co_rockwell' else kw
 record('financial_sensitivity',{'financial_sensitivity_id':'fs_'+co,'company_id':co,'security_id':sec,'node_id':'node_oem','segment_id':'seg_robot','driver_name':f'{name} automation orders and revenue','driver_type':'orders_revenue_and_margin','sensitivity_direction':'positive','sensitivity_magnitude':'high' if co in {'co_fanuc','co_yaskawa','co_kuka','co_teradyne'} else 'medium','formula_or_logic':f'Factory automation capital expenditure drives {name} orders; order conversion, mix, service attachment and execution translate to revenue and operating profit.','linked_assumption_ids':['assumption_base','assumption_bull','assumption_bear','assumption_shock','assumption_structural_transition'],'confidence_level':'medium'},sensitivity_src,sensitivity_kw,evidence_type='company_disclosure')

for qid,name,definition,src,kw in [
 ('sig_ifr_install','Annual industrial robot installations','IFR annual installations, robot density and geographic mix track market demand and installed-base expansion.',IFR,('installations','2024')),
 ('sig_china_output','China industrial robot production','Official China industrial robot unit output tracks domestic supply growth and policy-supported adoption.',CHINA,('77.3万套','工业机器人')),
 ('sig_jara_ship','Japan robot shipments and orders','JARA shipment, export, production and order statistics track Japanese OEM demand and cycle conditions.',JARA,('出荷','受注'))]:
 record('quantamental_signals',{'signal_id':qid,'industry_id':industry_id,'signal_name':name,'signal_definition':definition,'frequency':'annual_or_quarterly','history_available':'yes','backtest_status':'not_backtested','confidence_level':'high'},src,kw)

events=[
 ('event_ifr_2025','World Robotics 2025 installation update','market_data_release','2025-09-25',['co_abb','co_fanuc','co_yaskawa','co_kuka'],'Annual installation and geographic mix update changes demand and competitive baselines.',IFR,('installations','542,000')),
 ('event_fanuc_results','Net sales exceeded FY2022 record high','earnings','2026-04-24',['co_fanuc'],'Orders, sales and guidance update the automation cycle and company earnings bridge.',FANUC_RES,('Net sales','FY2022')),
 ('event_yask_results','Yaskawa fiscal 2026 results','earnings','2026-04-10',['co_yaskawa'],'Motion-control and robotics orders, sales and outlook update cyclical demand expectations.',YASK_RES,('Consolidated Results','2026')),
 ('event_china_output','工业机器人产量','official_statistics_release','2026-06-01',['co_fanuc','co_yaskawa','co_kuka'],'China production growth changes regional supply, localization and pricing assumptions.',CHINA,('77.3万套','工业机器人产量')),
 ('event_teradyne_robotics','Teradyne Robotics sequential growth and restructuring','earnings_and_restructuring','2026-03-27',['co_teradyne'],'Robotics revenue momentum and restructuring affect growth, cost and channel execution.',TER,('Robotics Group','growth'))]
for eid,name,typ,date,cos,chain,src,kw in events:
 record('event_catalysts',{'event_id':eid,'industry_id':industry_id,'event_name':name,'event_type':typ,'event_date':date,'timing':date,'impact_magnitude':'high','affected_companies':cos,'affected_nodes':['node_oem'],'causal_chain':chain,'falsifier_ids':['risk_demand_falsifier']},src,kw,evidence_type='company_disclosure' if src in {FANUC_RES,YASK_RES,TER} else 'quantitative_fact')

record('formula_registry',{'formula_id':'formula_automation_impact','formula_name':'Automation demand to company impact','formula_expression':'(variable_value - baseline_value) * sensitivity_coefficient','output_field':'company_impact_score','input_fields':['variable_value','baseline_value','sensitivity_coefficient'],'input_units':{'variable_value':'ratio','baseline_value':'ratio','sensitivity_coefficient':'unitless'},'output_unit':'score','scenario_scope':['base','bull','bear','shock','structural_transition'],'version':'1.0.0','limitations':'Directional linear propagation; no valuation or probability output.','status':'active'},OECD,('industrial robots','production'))
vals={'base':0.05,'bull':0.18,'bear':-0.08,'shock':-0.25,'structural_transition':0.28}
for st,val in vals.items():
 record('scenario_assumptions',{'assumption_id':'assumption_'+st,'scenario_id':'scenario_'+st,'scenario_name':st.replace('_',' ').title(),'scenario_type':st,'industry_id':industry_id,'assumption_name':st.replace('_',' ').title()+' factory automation demand','variable_name':'factory_automation_demand_growth','variable_value':val,'baseline_value':0.0,'unit':'ratio','range_low':-0.35,'range_high':0.35,'allowed_min':-0.5,'allowed_max':0.5,'sensitivity_coefficient':1.0,'sensitivity_unit':'unitless','assumption_owner':'source_backed','affected_nodes':['node_oem','node_integrator'],'affected_companies':[c[0] for c in companies],'formula_id':'formula_automation_impact','confidence_level':'medium','period':'1-3y','rationale':'Directional scenario anchored in installation, production, labor, technology and company evidence.','limitations':'Not a probability-weighted forecast.'},IFR,('installations','long-term'))

for oid,name,typ,imp,up,down,cos,src,kw in [
 ('opp_vision','Machine-vision-enabled bin picking','technology_and_integrator','watchlist_long_bias','Standardized throughput measurement and better perception expand addressable applications.','Cycle-time variability, object complexity and integration cost can delay adoption.',['co_abb','co_kuka','co_teradyne'],NIST,('throughput','complexity')),
 ('opp_cobot','Collaborative automation for small and medium manufacturers','company_group','selective_long_bias','Lower programming and safety barriers can broaden automation beyond automotive and electronics.','Weak payback, safety integration and channel support can limit scale.',['co_teradyne','co_abb'],UR,('collaborative','safety')),
 ('opp_controls','Automation software, controls and installed-base service','profit_pool','quality_compounder_watchlist','Software, motion control and service monetize installed bases and increase switching costs.','Cyclical hardware orders and open architectures can pressure growth and pricing.',['co_siemens','co_rockwell','co_fanuc','co_yaskawa'],SIEM,('software','automation'))]:
 record('opportunity_zones',{'opportunity_id':oid,'industry_id':industry_id,'opportunity_name':name,'opportunity_type':typ,'linked_nodes':['node_oem','node_integrator'],'linked_segments':['seg_robot','seg_controls','seg_integration'],'linked_companies':cos,'linked_securities':[next(c[4] for c in companies if c[0]==co) for co in cos],'investment_implication':imp,'upside_logic':up,'downside_logic':down,'time_horizon':'1-3y','valuation_context':'Valuation disabled pending governed live market data and named human approval.','evidence_strength':'high','confidence_level':'medium','falsifier_ids':['risk_demand_falsifier','risk_integration_falsifier'],'risk_ids':['risk_demand_falsifier','risk_integration_falsifier']},src,kw)

risks=[
 ('risk_demand_falsifier','falsifier','Global installation downturn','demand_cycle','A sustained contraction in global robot installations would invalidate the cyclical growth thesis.','high','annual_robot_installation_growth','lte',-0.10,IFR,('installations','growth')),
 ('risk_integration_falsifier','falsifier','Integration economics fail','adoption_and_execution','If realized throughput improvement remains below the customer payback threshold, broader adoption assumptions fail.','high','median_customer_throughput_improvement','lt',0.05,NIST,('throughput','cycle time')),
 ('risk_china_price','falsifier','China supply growth drives price pressure','competition','Rapid China output growth without matching demand can compress global robot pricing and margins.','high','china_robot_output_growth_minus_demand_growth','gte',0.15,CHINA,('工业机器人产量','年均')),
 ('risk_safety','risk','Safety or compliance incident','regulatory','A material safety incident or regulatory non-compliance can delay deployments and raise integration costs.','high',None,None,None,OSHA,('Safety','outdated')),
 ('risk_capex','risk','Manufacturing capex recession','macro_cycle','Customer capital-spending cuts can reduce robot orders, integrator backlog and software pull-through.','high',None,None,None,OECD,('investment','robots'))]
for rid,rt,name,rtype,desc,impact,var,op,val,src,kw in risks:
 data={'risk_falsifier_id':rid,'industry_id':industry_id,'record_type':rt,'name':name,'risk_type':rtype,'description':desc,'impact_magnitude':impact,'affected_nodes':['node_oem','node_integrator'],'affected_companies':[c[0] for c in companies]}
 if rt=='falsifier': data.update({'measurable_threshold':f'{var} {op} {val}','monitor_variable':var,'threshold_operator':op,'threshold_value':val})
 record('risks_falsifiers',data,src,kw)

# Explicit visible capability gaps
now=datetime.now(timezone.utc).isoformat()
for gid,name,reason,severity,affected,action in [
 ('gap_live_valuation','Live valuation disabled','No governed live market-data provenance and named valuation reviewer are configured.','major','valuation_and_price_targets','Integrate licensed market data and named human approval.'),
 ('gap_probabilities','Probability-weighted expected value disabled','Scenario probabilities have not been independently calibrated or approved.','minor','expected_value','Backtest scenario calibration and obtain reviewer approval.'),
 ('gap_external_human','Independent external human benchmark pending','Stage 4 validates the patched engine internally; genuine external blind expert review remains outside this run.','major','world_class_certification','Send sealed packet to independent robotics, public-markets and quant reviewers.')]:
 record_specs.append(('gap_register',{'gap_id':gid,'industry_id':industry_id,'gap_name':name,'gap_reason':reason,'severity':severity,'affected_output':affected,'next_action':action,'blocks_institutional_status':False,'created_at':now,'status':'open'},[]))

# Extract evidence (resume-safe: submit only missing source/quote/table/field tuples)
prop_path=OUT/'robotics_evidence_proposals.json'; prop_path.write_text(json.dumps({'evidence':proposals},ensure_ascii=False,indent=2),encoding='utf-8')
existing_rows=json.loads((W/'atomic_evidence.json').read_text()) if (W/'atomic_evidence.json').exists() else []
existing_keys={(e['source_id'],e['quote'],e['linked_table'],e['linked_field']) for e in existing_rows}
pending=[e for e in proposals if (e['source_id'],e['quote'],e['linked_table'],e['linked_field']) not in existing_keys]
pending_path=OUT/'robotics_evidence_proposals_pending.json'; pending_path.write_text(json.dumps({'evidence':pending},ensure_ascii=False,indent=2),encoding='utf-8')
print('evidence proposals total',len(proposals),'existing',len(existing_rows),'pending',len(pending))
if pending:
 out=subprocess.check_output([CLI,'extract-evidence','--workspace',str(W),'--proposals',str(pending_path)],text=True)
 result=json.loads(out)
 print('evidence repair result',result['accepted_evidence_count'],result['rejected_proposal_count'])
 (OUT/'evidence_extraction_repair_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 if result['rejected_proposal_count']:
  (OUT/'evidence_rejections_repair.json').write_text(json.dumps(result['rejections'],ensure_ascii=False,indent=2),encoding='utf-8')
  raise SystemExit('evidence rejections present after repair')
evrows=json.loads((W/'atomic_evidence.json').read_text())
evmap={(e['source_id'],e['quote'],e['linked_table'],e['linked_field']):e['evidence_id'] for e in evrows}
missing=[(sid,quote,table,field) for table,data,desc in record_specs for field,sid,quote in desc if (sid,quote,table,field) not in evmap]
if missing:
 raise SystemExit(f'missing evidence mappings: {len(missing)}')
records=[]
explicit_gaps=[]
for table,data,desc in record_specs:
 if table == 'gap_register':
  explicit_gaps.append(data)
  continue
 lineage={field:[evmap[(sid,quote,table,field)]] for field,sid,quote in desc}
 records.append({'table':table,'record':data,'field_lineage':lineage})
from industry_intel_engine.data_contract import PROPOSABLE_TABLES
payload={'analyst':'phase10-stage4-robotics-research-lead','replace_tables':[t for t in PROPOSABLE_TABLES if t != 'simulation_outputs'], 'records':records}
rec_path=OUT/'robotics_dataset_records.json'; rec_path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
out=subprocess.check_output([CLI,'populate-dataset','--workspace',str(W),'--records',str(rec_path)],text=True)
print(out)
# Preserve explicit non-research capability gaps for later simulation/finalization.
gap_path=W/'gap_register.json'
gaps=json.loads(gap_path.read_text())
existing={g.get('gap_id') for g in gaps}
for gap in explicit_gaps:
 if gap.get('gap_id') not in existing:
  gaps.append(gap)
gap_path.write_text(json.dumps(gaps,ensure_ascii=False,indent=2),encoding='utf-8')
(W/'tables'/'gap_register.json').write_text(json.dumps(gaps,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'explicit_capability_gaps.json').write_text(json.dumps(explicit_gaps,ensure_ascii=False,indent=2),encoding='utf-8')
print('explicit gaps preserved',len(explicit_gaps),'total gaps',len(gaps))
