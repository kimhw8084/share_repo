# Industry Intelligence run summary

- **Run ID:** `run_industrial-robotics-and-factory-automation_a746c6d8`
- **Status:** `validated_production_candidate`
- **Maturity:** Institutional-Grade Candidate
- **Overall score:** **89.1 / 100**
- **Research Quality:** 87.09 / 100
- **Maturity score:** 87.45 / 100
- **Operational Integrity:** 100.0 / 100
- **Active score caps:** [92, 95]
- **Discovered source candidates:** 24
- **Accepted sources:** 22
- **Eligible atomic evidence:** 314
- **Research stop approved:** true
- **Average professional-lens depth:** 79.88 / 100
- **Simulation maturity:** Level 2
- **HTML packet:** generated and browser verified
- **Open gaps:** 5
- **Blocker gaps:** 0
- **Hard fails:** 0
- **Valuation output:** disabled without live market provenance and human approval
- **Production claim:** true

This summary is synchronized with the Phase 10 quality, maturity, operational-integrity, stop-decision, and final-state controls. It is not an investment recommendation.
