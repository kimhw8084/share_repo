# Validation Report — Industrial Robotics and Factory Automation

- **Run ID:** `run_industrial-robotics-and-factory-automation_a746c6d8`
- **Industry ID:** `ind_02a11dc20cdb`
- **Validated at:** 2026-07-29T00:00:44.414015+00:00
- **Disposition:** `pass_with_major_gaps`
- **Maturity:** Institutional-Grade Candidate
- **Score:** **89.1 / 100** (Institutional-Grade)
- **Research Quality score:** 87.09
- **Maturity score:** 87.45
- **Operational Integrity score:** 100.0
- **Combined score before caps:** 89.1
- **Confidence:** high
- **Hard-fail status:** `none`
- **Production claim:** `true`

## Score decomposition

| Component | Score | Weight |
|---|---:|---:|
| source_quality_and_coverage | 9.88 | 15 |
| atomic_evidence_and_field_coverage | 13.06 | 15 |
| data_contract_and_relationship_integrity | 14.60 | 15 |
| value_chain_money_flows_and_economics | 10.00 | 10 |
| company_and_security_exposure | 10.00 | 10 |
| simulation_validity | 8.80 | 10 |
| investment_logic_and_opportunity_ranking | 11.76 | 15 |
| role_lens_coverage | 3.99 | 5 |
| ui_and_artifact_readiness | 5.00 | 5 |

## Validator results

| Validator | Status | Severity | Result |
|---|---|---|---|
| VAL_ARTIFACT_REQUIRED_FILES | pass | info | Required pre-finalization artifacts are present. |
| VAL_STATE_COUNT_CONSISTENCY | pass | info | Source and evidence counts reconcile across canonical dataset, state, and HTML audit. |
| VAL_EVIDENCE_INTEGRITY | pass | info | Evidence rows=314; exact duplicates=0; unresolved conflicts=0. |
| VAL_SOURCE_NATIVE_GROUNDING | pass | info | Source-native captures=22/22; span-grounded evidence=314/314; generated quotes=0; weak semantic support=0. |
| VAL_ANALYTICAL_SPECIFICITY | pass | info | Specificity failures=0; critical=0; missing machine-readable falsifier thresholds=0. |
| VAL_AUTHORITATIVE_SOURCE_RECALL | pass | info | Recall=100.00% against 20 frozen domains; required >=85%. |
| VAL_SCHEMA_REQUIRED_TABLES | pass | info | Required-table population=100.00%; minimum-complete=96.30%; missing core=[]. |
| VAL_SOURCE_FAMILY_COVERAGE | pass | minor | Accepted sources=22; recognized source families=5; tier quality ratio=0.98. |
| VAL_SOURCE_CANDIDATE_FUNNEL | pass | info | Discovered=24; duplicates=1; pre-review rejected=2; accepted=22; evidence-eligible sources=21. |
| VAL_RESEARCH_STOP_DECISION | pass | info | Research stop is approved with marginal-yield and gap-closure evidence. |
| VAL_ROLE_LENS_DEPTH | pass | info | Average table coverage=100.00%; depth/actionability quality=79.88. |
| VAL_FINAL_STATE_ATOMICITY | pass | info | Final tracked artifacts reconcile by hash. |
| VAL_SIMULATION_VALIDITY | pass | info | Simulation level=2; canonical simulation records=178; status=ready_basic_deterministic. |
| VAL_HTML_PACKET_TRUTH | pass | info | HTML exact tabs=19; browser=passed; unresolved material claims=0; exports=50. |
| VAL_REAL_PROVIDER_ACCEPTANCE | pass | info | No fixture-only marker is present and all evidence resolves to accepted captured snapshots. |

## Source and evidence statistics

- Discovered source candidates: **24**
- Rejected or duplicate candidates: **3**
- Accepted sources: **22**
- Recognized source families: **8**
- Eligible atomic evidence: **314**
- Evidence-covered tables: **23**
- Unresolved conflicts: **0**

## Professional-lens quality

- Average table coverage: **100.0%**
- Average depth/actionability quality: **79.88 / 100**

## Research stop decision

- Decision: `stop_approved`
- Approved: `true`

## Gaps

- Open gaps: **5**
- Blocker gaps: **0**
- Major gaps: **3**

## Top weaknesses

- Source-family diversity is incomplete.
- Independent corroboration is thin.
- Investment implications lack sufficient catalyst/falsifier/actionability depth.
- Simulation is deterministic and directional; historical calibration is absent.

## Required next actions

- None required.

## Active score caps

`[92, 95]`

The score is subordinate to hard-fail, maturity, evidence, and benchmark gates. It is not an investment recommendation.
