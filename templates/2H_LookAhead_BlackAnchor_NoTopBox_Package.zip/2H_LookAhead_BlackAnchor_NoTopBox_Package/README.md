# 2H Look-Ahead — Black Anchor Package

This version removes the top-right black box.

Black is now used as a cleaner organizational anchor:
- short black rule above each page title
- black vertical anchor on the strategic message
- black header strip on the 2H operating shift block
- black pillar number tags
- black roadmap table headers
- black left anchor on the closing line

This keeps black as the reset / organization color without a heavy badge in the header.

## Files

```text
static/
  2H_LookAhead_BlackAnchor_NoTopBox_STATIC.html

editable/
  index.html
  content.json
  render.js
  style.css

snippets/
  static_body.html
  style.css

README.md
```

## Open first

```text
static/2H_LookAhead_BlackAnchor_NoTopBox_STATIC.html
```
