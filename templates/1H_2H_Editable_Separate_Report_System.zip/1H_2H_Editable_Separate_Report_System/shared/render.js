
function esc(value){
  return String(value ?? '')
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;');
}
function metricHTML(metrics){
  return metrics.map(m => {
    const cls = /[A-Za-z+]/.test(m.value) ? ' text' : '';
    return `<div class="metric"><div class="metric-value-zone"><div class="metric-value${cls}">${esc(m.value)}</div></div><div class="metric-label">${esc(m.label)}</div></div>`;
  }).join('');
}
function renderHeader(data){
  return `<div class="top-anchor"></div>
  <header class="card-header">
    <div>
      <div class="eyebrow">${esc(data.eyebrow)}</div>
      <h1 class="title">${esc(data.title)}</h1>
      <div class="subtitle">${esc(data.subtitle)}</div>
      <div class="mode-band"><div class="mode-pill">${esc(data.modeLabel)}</div><div class="mode-line"></div></div>
    </div>
    <aside class="story-card">
      <div class="story-label">${esc(data.storyLabel)}</div>
      <div class="story-text">${esc(data.story)}</div>
    </aside>
  </header>`;
}
function render1H(data){
  const labels = data.columnLabels.map(x => `<div class="lane-label">${esc(x)}</div>`).join('');
  const lanes = data.lanes.map(lane => {
    const items = lane.items.map(i => `<div class="lane-item">${esc(i)}</div>`).join('');
    return `<section class="lane"><div class="lane-head"><div class="lane-title">${esc(lane.title)}</div><div class="lane-signal">${esc(lane.signal)}</div></div><div class="lane-body">${items}</div><div class="lane-outcome"><div class="lane-outcome-label">Operating signal</div><div class="lane-outcome-text">${esc(lane.signal)}</div></div></section>`;
  }).join('');
  const proofs = data.proofs.map(p => `<article class="proof"><div class="proof-title">${esc(p.title)}</div><div class="proof-body">${esc(p.body)}</div></article>`).join('');
  return `<article class="card current">${renderHeader(data)}<section class="metrics">${metricHTML(data.metrics)}</section><div class="lane-label-row"><div class="lane-label-spacer"></div>${labels}<div class="lane-label outcome">Operating signal</div></div><section class="lanes">${lanes}</section><section class="proof-grid" style="--proof-count:${data.proofs.length}">${proofs}</section><section class="impact">${esc(data.impact)}</section><footer class="footer">${esc(data.footer)}</footer></article>`;
}
function render2H(data){
  const tracks = data.tracks.map(tr => `<section class="future-track"><div class="future-track-head"><div class="future-stage">${esc(tr.stage)}</div><div class="future-track-title">${esc(tr.name)}</div></div><div class="future-track-body"><div class="future-cell"><div class="future-cell-label">Why it matters</div><div class="future-cell-text">${esc(tr.why)}</div></div><div class="future-cell"><div class="future-cell-label">2H work</div><div class="future-cell-text">${esc(tr.work)}</div></div><div class="future-cell outcome"><div class="future-cell-label">Expected outcome</div><div class="future-cell-text">${esc(tr.outcome)}</div></div></div></section>`).join('');
  const timeline = data.timeline.map(t => `<div class="time-item"><div class="time-label">${esc(t.label)}</div><div class="time-text">${esc(t.text)}</div></div>`).join('');
  return `<article class="card future">${renderHeader(data)}<section class="metrics">${metricHTML(data.metrics)}</section><section class="north-star">${esc(data.northStar)}</section><section class="future-layout"><div class="track-stack">${tracks}</div><aside class="timeline-panel"><div class="timeline-title">How to read 2H</div><div class="timeline">${timeline}</div><div class="read-guide"><div class="guide-title">Reader guide</div><div class="guide-text">Each row answers three questions immediately: why this matters, what the team will do in 2H, and what operating outcome should exist by the end.</div></div></aside></section><section class="impact">${esc(data.impact)}</section><footer class="footer">${esc(data.footer)}</footer></article>`;
}
async function loadReport(type){
  const response = await fetch('./content.json');
  const data = await response.json();
  const report = type === '2H' ? render2H(data) : render1H(data);
  document.getElementById('report').innerHTML = `<main class="deck">${report}</main>`;
}
async function loadPreview(){
  const [oneH, twoH] = await Promise.all([
    fetch('../1H/content.json').then(r=>r.json()),
    fetch('../2H/content.json').then(r=>r.json())
  ]);
  document.getElementById('report').innerHTML = `<main class="deck"><div style="width:1600px;background:#fff;border:1px solid #d6d6dc;padding:14px 18px;font-size:13px;color:#73737c;font-weight:650">Optional preview only. Main reports are separate: 1H/index.html and 2H/index.html.</div>${render1H(oneH)}${render2H(twoH)}</main>`;
}
