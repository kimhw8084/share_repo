# 1H + 2H Editable Separate Report System

You were right: a folder with only `index.html` is not good enough for maintenance.

This package is now a real editable system.

## Folder structure

```text
1H/
  index.html
  content.json
  OPEN_WITH_SERVER_NOTE.txt

2H/
  index.html
  content.json
  OPEN_WITH_SERVER_NOTE.txt

shared/
  design-system.css
  render.js

preview/
  1H_2H_preview.html

README.md
```

## How to update text

Edit:

```text
1H/content.json
```

or:

```text
2H/content.json
```

Do not edit the HTML for normal text changes.

## How to update design

Edit:

```text
shared/design-system.css
```

## How to update layout logic

Edit:

```text
shared/render.js
```

## How to view locally

Because `index.html` loads `content.json`, open it through a local server.

From the package root:

```bash
python -m http.server 8000
```

Then open:

```text
http://localhost:8000/1H/
http://localhost:8000/2H/
http://localhost:8000/preview/1H_2H_preview.html
```

## Why this is better

- 1H and 2H are separate reports.
- Content is editable in JSON.
- Design is shared.
- Layout/rendering is reusable.
- Preview is optional, not the main output.
