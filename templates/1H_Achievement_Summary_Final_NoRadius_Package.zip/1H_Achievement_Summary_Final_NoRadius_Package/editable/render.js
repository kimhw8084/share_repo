function render() {
  const d = window.REPORT_CONTENT;
  const card = document.getElementById("card");

  const metric = (m) => `
    <div class="metric ${m.tone}">
      <div class="metric-value-zone"><div class="metric-value">${m.value}</div></div>
      <div class="metric-copy">
        <div class="metric-label">${m.label}</div>
        ${m.sublabel ? `<div class="metric-sublabel">${m.sublabel}</div>` : ""}
      </div>
    </div>`;

  const lane = (l) => `
    <article class="lane ${l.tone}">
      <div class="lane-head">
        <div class="lane-number">${l.number}</div>
        <div class="lane-title">${l.title}</div>
      </div>
      <div class="lane-body">
        <div class="cell"><div class="cell-label">Challenge</div><div class="cell-text">${l.challenge}</div></div>
        <div class="cell"><div class="cell-label">Team Action</div><div class="cell-text">${l.action}</div></div>
        <div class="cell"><div class="cell-label">1H Impact</div><div class="cell-text">${l.impact}</div></div>
      </div>
    </article>`;

  const proof = (p) => `
    <article class="proof ${p.tone}">
      <div>
        <div class="proof-label">${p.label}</div>
        <div class="proof-text">${p.text}</div>
      </div>
    </article>`;

  card.innerHTML = `
    <header class="header">
      <section>
        <div class="kicker">${d.reportLabel}</div>
        <h1>${d.title}</h1>
        <div class="subtitle">${d.subtitle}</div>
      </section>
      <section class="story">
        <div class="story-bar"></div>
        <div>
          <div class="story-label">Strategic Story</div>
          <div class="story-text">${d.strategicStory}</div>
        </div>
      </section>
    </header>
    <section class="metrics">${d.metrics.map(metric).join("")}</section>
    <div class="divider"><span>Operating Capability Expansion</span></div>
    <section class="lanes">${d.lanes.map(lane).join("")}</section>
    <section class="proof-grid">${d.proofBlocks.map(proof).join("")}</section>
    <footer class="impact">
      <div class="impact-label">Overall Impact</div>
      <div class="impact-text">${d.overallImpact}</div>
    </footer>`;
}
render();