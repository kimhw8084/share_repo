(function(){
  const FIT_RULES = [
    [".metric-value", 18],
    [".metric-label", 10.5],
    [".metric-sublabel", 9.5],
    [".lane-title", 18],
    [".cell-text", 12.5],
    [".proof-text", 11.5],
    [".impact-text", 18],
    [".subtitle", 16],
    [".story-text", 15]
  ];

  function overflows(el){
    return el.scrollWidth > el.clientWidth + 1 || el.scrollHeight > el.clientHeight + 1;
  }

  function fitOne(el, minSize){
    if(!el) return false;
    el.classList.add("fit");

    const computed = window.getComputedStyle(el);
    const original = parseFloat(el.dataset.originalFont || computed.fontSize);
    el.dataset.originalFont = String(original);
    el.style.fontSize = original + "px";

    let size = original;
    let guard = 0;
    while(overflows(el) && size > minSize && guard < 80){
      size -= 0.5;
      el.style.fontSize = size + "px";
      guard++;
    }

    const failed = overflows(el);
    el.dataset.fitStatus = failed ? "needs-shorter-text" : "ok";
    return failed;
  }

  function fitAll(){
    let warnings = 0;
    FIT_RULES.forEach(([selector, minSize]) => {
      document.querySelectorAll(selector).forEach(el => {
        if(fitOne(el, minSize)) warnings++;
      });
    });

    const card = document.querySelector(".card");
    const note = document.getElementById("fitNote");
    if(note && card){
      const h = Math.round(card.getBoundingClientRect().height);
      const heightMsg = h > 900
        ? `Content is ${h}px tall, above the 900px 16:9 target. No horizontal spill is allowed.`
        : `Content is ${h}px tall, within the 900px 16:9 target.`;
      const warningMsg = warnings
        ? `${warnings} block(s) are too long and were silently clipped after shrinking. Shorten those blocks in content.js.`
        : `No text overflow detected.`;
      note.innerHTML = `<strong>No-overflow check:</strong> ${heightMsg} ${warningMsg}`;
    }
  }

  window.addEventListener("load", fitAll);
  window.addEventListener("resize", fitAll);
  if(document.fonts && document.fonts.ready){ document.fonts.ready.then(fitAll); }
  const observer = new MutationObserver(() => requestAnimationFrame(fitAll));
  window.addEventListener("DOMContentLoaded", () => {
    const card = document.querySelector(".card");
    if(card) observer.observe(card, {childList:true, subtree:true, characterData:true});
    fitAll();
  });
})();