window.REPORT_CONTENT = {
  reportLabel: "Internal Executive Review",
  title: "1H Achievement Summary",
  subtitle: "Scaling operating capability for new fab readiness and AI-enabled operations",
  strategicStory:
    'The team became a <strong>scalability engine</strong> by converting <strong>new fab complexity</strong>, manual reporting, fragmented automation, monitoring scale, and emerging AI into <strong>repeatable operating capabilities</strong>.',

  metrics: [
    { tone: "blue", value: "5", label: "major system setup efforts" },
    { tone: "blue", value: "2", label: "June-critical systems delivered on time" },
    { tone: "green", value: "0", label: "unexpected FAB-impacting issues after maintenance day" },
    { tone: "orange", value: "4", label: "automation tracks advanced", sublabel: "recipe creation · quality alerts · FastAPI · KPI dashboard" },
    { tone: "purple", value: "AI", label: "RAG + OpenCode practical AI use cases" }
  ],

  lanes: [
    {
      number: "01",
      tone: "blue",
      title: "New Fab + Production Stability",
      challenge: "<strong>New fab R&R</strong>, HQ coordination across time zones, vendor alignment, schedule pressure, and limited maintenance window.",
      action: "Owned the <strong>setup lifecycle</strong>; aligned internal, vendor, and HQ teams; executed validation; maintained <strong>reprocessing readiness</strong> and mobile equipment lookup support.",
      impact: "Delivered <strong>June-critical systems on time</strong> with no team-caused delay; completed maintenance day with <strong>0 unexpected FAB-impacting issues</strong>."
    },
    {
      number: "02",
      tone: "green",
      title: "Automation + Quality Governance",
      challenge: "<strong>Manual reporting</strong>, fragmented scripts, false alerts, and long-open VoC/CPM visibility gaps limited fast follow-up.",
      action: "Advanced <strong>4 automation tracks</strong>: recipe creation automation, quality alerts, FastAPI platform, and KPI dashboarding.",
      impact: "Improved <strong>reporting speed</strong>, reduced manual effort, lowered human-error risk, and strengthened <strong>quality follow-up</strong>."
    },
    {
      number: "03",
      tone: "purple",
      title: "Monitoring Scale + AI Enablement",
      challenge: "<strong>60+ servers</strong>, new fab expansion, server-by-server checks, and AI needing practical business use.",
      action: "Standardized Prometheus/Splunk monitoring; added process/service visibility; built <strong>RAG and OpenCode workflows</strong>.",
      impact: "Created a <strong>scalable monitoring foundation</strong> and positioned AI as a practical accelerator for <strong>knowledge retrieval and automation</strong>."
    }
  ],

  proofBlocks: [
    {
      tone: "blue",
      label: "Key Proof",
      text: "<strong>5 setup efforts</strong>; <strong>2 June-critical systems</strong> delivered on time; <strong>0 post-maintenance FAB-impacting issues</strong>."
    },
    {
      tone: "orange",
      label: "Key Build",
      text: "<strong>Recipe automation</strong>, quality alerts, FastAPI standardization, KPI dashboarding, VoC/CPM reporting, monitoring standardization, RAG and OpenCode."
    },
    {
      tone: "purple",
      label: "Challenges Addressed",
      text: "New fab R&R, HQ coordination, schedule pressure, manual workload, fragmented visibility, monitoring scale, quality governance, and <strong>practical AI adoption</strong>."
    }
  ],

  overallImpact:
    "Stronger readiness, lower production risk, faster reporting, reduced manual effort, better quality governance, scalable monitoring, and <strong>practical AI adoption</strong>."
};