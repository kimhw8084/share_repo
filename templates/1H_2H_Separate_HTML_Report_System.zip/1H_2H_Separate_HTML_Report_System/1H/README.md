# 1H Report

Open:

```text
index.html
```

This is the standalone 1H current-state report.

Design:
- Blue current-state achievement scheme
- Explicit lane column labels
- Columns: Scope / work advanced, Execution result, Operating leverage, Operating signal
