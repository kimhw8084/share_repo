# 1H + 2H Separate HTML Report System

This package separates 1H and 2H into independent report folders.

## Main files

```text
1H/
  index.html
  README.md

2H/
  index.html
  README.md

shared/
  design-system.css
  README.md

preview/
  1H_2H_preview.html
  README.md
```

## Open these first

1H report only:

```text
1H/index.html
```

2H report only:

```text
2H/index.html
```

Optional comparison preview:

```text
preview/1H_2H_preview.html
```

## Why this structure is better

- 1H and 2H can be presented independently.
- Each report has its own folder.
- Shared design-system reference is kept in `shared/`.
- Combined preview is optional only.
- This scales better for Q3, Q4, annual, and monthly reports.

## Current design

1H:
- Blue current-state achievement report
- Labeled lane columns
- Columns: Scope / work advanced, Execution result, Operating leverage, Operating signal

2H:
- Green future-state roadmap
- Reader-first layout
- Each track explains: why it matters, 2H work, expected outcome
