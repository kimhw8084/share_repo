# Optional Preview

Open:

```text
1H_2H_preview.html
```

This is only for comparison. The main reports are separate:

```text
../1H/index.html
../2H/index.html
```
