# Shared Design System

`design-system.css` was extracted from the standalone report CSS.

The `1H/index.html` and `2H/index.html` files are standalone and can open directly. For future refactoring, move the embedded style blocks to this shared CSS file and link them from both reports.
