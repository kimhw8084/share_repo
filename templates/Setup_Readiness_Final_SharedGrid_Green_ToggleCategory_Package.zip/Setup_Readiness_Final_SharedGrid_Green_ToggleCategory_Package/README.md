# Setup Readiness Final Package — Category Toggle

This is the same approved shared-grid fixed-bar green version, with an easy category toggle added.

## One-change toggle

Edit:

```text
editable/config.json
```

Change:

```json
"showCategory": true
```

to:

```json
"showCategory": false
```

That hides the category column.

Change it back to `true` to show category again.

## Manual one-class toggle

Show category:

```html
<section class="diagram">
```

Hide category:

```html
<section class="diagram hide-category">
```

## Why this works

The component uses one shared grid:

```css
.progress-grid{
  display:grid;
  grid-template-columns:var(--grid-template);
}
```

Default:

```css
--grid-template:max-content max-content var(--bar-width) var(--status-width);
```

When hidden:

```css
.diagram.hide-category{
  --grid-template:max-content var(--bar-width) var(--status-width);
}
```

And the category cells are hidden with:

```css
.diagram.hide-category .progress-grid > :nth-child(4n + 2){
  display:none;
}
```

## Files

```text
static_visible/
  Setup_Readiness_FINAL_ToggleCategory_SHOW_STATIC.html
  Setup_Readiness_FINAL_ToggleCategory_HIDE_STATIC.html

dynamic_standalone/
  Setup_Readiness_FINAL_Dynamic_ToggleCategory.html

editable/
  index.html
  config.json
  render.js
  styles.css

snippets/
  setup_readiness_toggle_category_snippet_SHOW.html
  setup_readiness_toggle_category_snippet_HIDE.html
  setup_readiness_toggle_category_styles.css
```

## Best file to test first

Open:

```text
static_visible/Setup_Readiness_FINAL_ToggleCategory_SHOW_STATIC.html
```

Then compare with:

```text
static_visible/Setup_Readiness_FINAL_ToggleCategory_HIDE_STATIC.html
```

## Editable workflow

```bash
cd editable
python -m http.server 8000
```

Open:

```text
http://localhost:8000
```

Then toggle `showCategory` in `config.json`.