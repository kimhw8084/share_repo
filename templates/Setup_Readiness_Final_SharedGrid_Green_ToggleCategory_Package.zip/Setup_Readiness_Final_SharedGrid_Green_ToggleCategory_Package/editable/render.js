function renderSetupReadinessDiagram(config, mountSelector){
  const root = document.querySelector(mountSelector);
  if(!root || !config) return;

  const esc = (v) => String(v ?? '')
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;');

  const cols = config.columns || [];
  const rows = config.rows || [];
  const layout = config.layout || {};
  const barWidth = Number(layout.barWidthPx || 280);
  const statusWidth = Number(layout.statusWidthPx || 68);
  const accent = layout.accentColor || '#2FB344';
  const active = layout.activeColor || '#6F737B';
  const pending = layout.pendingColor || '#EEEEF2';
  const showCategory = layout.showCategory !== false;
  const diagramClass = showCategory ? 'diagram' : 'diagram hide-category';

  const stageTrack = cols
    .map(c => `<div class="stage-label">${esc(c.label || c.key)}</div>`)
    .join('');

  const gridCells = [
    '<div class="grid-spacer"></div>',
    '<div class="grid-spacer"></div>',
    `<div class="stage-track">${stageTrack}</div>`,
    '<div class="grid-spacer"></div>'
  ];

  rows.forEach(r => {
    const rowClass = String(r.status || '').toLowerCase().startsWith('delivered') ? 'delivered' : 'next';
    const segments = cols.map(c => {
      const key = c.key;
      const status = ['done','active','pending'].includes(r.segments?.[key]) ? r.segments[key] : 'pending';
      const label = (r.segmentLabels && r.segmentLabels[key] && status === 'active')
        ? `<span class="segment-label">${esc(r.segmentLabels[key])}</span>`
        : '';
      return `<div class="segment ${status}" title="${esc(r.id)} · ${esc(key)} · ${esc(status)}">${label}</div>`;
    }).join('');

    gridCells.push(
      `<div class="cell id-cell ${rowClass}">${esc(r.id)}</div>`,
      `<div class="cell category-cell ${rowClass}">${esc(r.category)}</div>`,
      `<div class="cell bar-cell ${rowClass}"><div class="progressbar">${segments}</div></div>`,
      `<div class="cell status-cell ${rowClass}">${esc(r.status)}</div>`
    );
  });

  const legend = (config.legend || [])
    .map(item => `<span class="legend-item"><span class="legend-swatch ${esc(item.key)}"></span>${esc(item.label)}</span>`)
    .join('');

  root.innerHTML = `
    <section class="${diagramClass}" style="--col-count:${cols.length};--bar-width:${barWidth}px;--status-width:${statusWidth}px;--accent:${accent};--active:${active};--pending:${pending}" aria-label="Setup readiness shared grid fixed bar progress diagram">
      <header class="header">
        <div class="title">${esc(config.meta?.title || 'Setup Readiness')}</div>
        <div class="kpis">
          <div class="kpi"><strong>${esc(config.meta?.metricPrimaryValue || '')}</strong><span>${esc(config.meta?.metricPrimaryLabel || '')}</span></div>
          <div class="kpi"><strong>${esc(config.meta?.metricSecondaryValue || '')}</strong><span>${esc(config.meta?.metricSecondaryLabel || '')}</span></div>
        </div>
      </header>
      <section class="progress-grid">${gridCells.join('')}</section>
      <footer class="legend">${legend}</footer>
    </section>`;
}